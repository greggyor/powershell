param([string]$siteUrl, [string]$listName, [string]$keyColumnName, [string]$valueColumnName, [bool]$addWordVariants, [string]$output)

Add-PsSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue 

function createCEEDictionaryFromSPList ($url, $listName, $keyFieldName, $valueFieldName, $addWordVariants){
    $output = "Key,Display form`r`n"
    $output += createListEntries $url $listName $keyFieldName $valueFieldName $addWordVariants
    return $output
}

function createWordVariations($phrase)
{
    $words = $phrase.ToLower().Split(" ")
    $binaryStr = ""
    
    for($i = 0; $i -lt $words.Length; $i++)
    {
        $binaryStr += "1"
    }
    
    $variationCount = [System.Convert]::ToInt32($binaryStr, 2) + 1
    
    $phraseVariations = @()
    
    for($i = 0; $i -lt $variationCount; $i++)
    {
        $x = 0
        [int]$deci = $i
        
        do
        {
            $remainder = $deci % 2
            if($remainder -eq 0) {
                $words[$x] = $words[$x].ToLower()
            } else {
                if($words[$x].Length -gt 1) {
                    $words[$x] = ([string]$words[$x][0]).ToUpper() + $words[$x].SubString(1)
                } elseif($words[$x].Length -eq 0) {
                    $words[$x] = $words[$x].ToUpper()
                } 
            }
            $x += 1
            
            $deci = [System.Math]::Floor($deci / 2)
        }
        while($deci -gt 0)
        
        $phraseVariations += [System.String]::Join(" ", $words)
    }
    
    return $phraseVariations
}


function createListEntries ($url, $listName, $keyFieldName, $valueFieldName, $addWordVariants)
{
    # Get list from specified Sharepoint web
    $SPWeb = get-spweb $url

    $uniqueKeyValue = new-object System.Collections.Specialized.NameValueCollection
    
    if($listName -is [array]) {
        foreach($name in $listName)
        {
            $reflist = $SPWeb.Lists.TryGetList($name)
            $keyFName = $keyFieldName[$name]
            $valueFName = $valueFieldName[$name]
            
            foreach ($listItem in $reflist.Items) {
                $keyFieldValue = $listItem[$keyFName]
                $valueFieldValue = $listItem[$valueFName]

                if($keyFieldValue) {
                    if($addWordVariants -and $valueFieldValue) {
                      $uniqueKeyValue.add($keyFieldValue, $valueFieldValue)
                    } else {
                      $uniqueKeyValue.add($keyFieldValue, $keyFieldValue)
                    }
                }
            }
        }
    } else {
        $reflist = $SPWeb.Lists.TryGetList($listName)
        
        foreach ($listItem in $reflist.Items) {
            $keyFieldValue = $listItem[$keyFieldName]
            $valueFieldValue = $listItem[$valueFieldName]
            
            if($keyFieldValue) {
                if($addWordVariants -and $valueFieldValue) {
                  $uniqueKeyValue.add($keyFieldValue, $valueFieldValue)
                } else {
                  $uniqueKeyValue.add($keyFieldValue, $keyFieldValue)
                }
            }
        }
    }
     
    $result = ""

    foreach ($key in ($uniqueKeyValue.AllKeys | sort))
    {
        $result += "`"{0}`",`"{1}`"`r`n" -f $(escape-Csv($key)), $(escape-Csv($uniqueKeyValue.GetValues($key)))
    }
    
    $SPWeb.Dispose()
    
    return $result
}

function escape-Csv( [string] $text )
{
    $text = $text -replace "`"", "`"`""

    return $text
}


createCEEDictionaryFromSPList $siteUrl $listName $keyColumnName $valueColumnName $addWordVariants | out-file $output -encoding "UTF8"