gps |
    fl * 
        gsv|
               sort -property name   |    
               
            ft name, status     -AutoSize