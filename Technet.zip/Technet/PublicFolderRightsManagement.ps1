﻿<#

PublicFolderRightsManagement (Recursive)

(_______|____  \(_____ \  Fashion Operations GmbH
 _       ____)  )_____) ) 
| |     |  __  (|  __  /  
| |_____| |__)  ) |  \ \  
 \______)______/|_|   |_| 

Intention: 
The Intention of this script, is to change the PublicFolder Rights for Users within a Public Folder Infrastructure. 

$Variables
There are a few Variables, that can be Edited, or Outlined (just comment them out) if not needed



#>
#Declaration of the Parent Public Folder 
$Parent="\"
#Declaration of First Exchange-Server (not Needed if run on Exchange-Server) 
$Server1=""
#Declaration of Second Exchange-Server (not Needed if run on Exchange-Server)
$Server2=""
#Declaration of Mailserver Prefix. This is needed to determine a Valid E-mail Adress for the User. 
#Reason for this is, that a User Account need a Valid E-mail Address to grant Public folder rights. 
$MailServerPrefix="**"
#Declaration of the Access-Right for the Query (including the "*")
$changeFromQry="*Owner*"
##Declaration of the Access-Right to change FROM
$ChangeFrom="Owner"
#Declaration of Access-Right to Change INTO
$ChangeTo="PublishingEditor"
#Declaration of Exceptional Accounts that should not be touched! (Service-Accounts, Administrators, Manager ...)
$Exception1="*service*"
$Exception2="*service*"
$Exception3="*service*"
$Exception4="*service*"
$Exception5="*service*"
#Declaration of a Test-User to run this script for a Specific Test-user first. (if not Needed-please outline line 53!) 
$testuser="*testuser"
$ErrorActionPreference = "Continue"
Get-PublicFolder -Identity $Parent -Recurse -Server $Server1 |
Get-PublicFolderClientPermission -Server $Server2 |
ForEach-Object{ if ($_.AccessRights -like $changeFromQry -and
$_.User -notlike  $Exception1 -and
$_.User -notlike $Exception2 -and
$_.User -notlike $Exception3 -and
$_.User -notlike $Exception4 -and
#If no Testuser is needed, or test completed, please out-comment next line. 
$_.User -like $testuser
){
$GM=""
$GM=Get-Mailbox -Identity $_.User.ActiveDirectoryIdentity.Name -ErrorAction SilentlyContinue
$GG=""
$GG=Get-Group $_.User.ActiveDirectoryIdentity -ErrorAction SilentlyContinue
if ($GM.ServerName -like $MailServerPrefix){
remove-PublicFolderClientpermission -Identity $_.Identity -User $_.User -AccessRights $ChangeFrom -Confirm:$False
Add-PublicFolderClientpermission -Identity $_.Identity -User $_.User -AccessRights $ChangeTo -Confirm:$false
Write-Host -BackgroundColor Green -ForegroundColor Black $GM.DisplayName "for" $_.Identity
}
elseif ($GG.IsValid -like "True"){
remove-PublicFolderClientpermission -Identity $_.Identity -User $_.User -AccessRights $ChangeFrom -Confirm:$False|
Add-PublicFolderClientpermission -Identity $_.Identity -User $_.User -AccessRights $ChangeTo -Confirm:$false
Write-Host -BackgroundColor Green -ForegroundColor Black $GG.SamAccountName "for" $_.Identity
}
else {
Write-Host -BackgroundColor Red -ForegroundColor Black $_.User
}
}
}

<#
Script by Gerrit Grote 
Please let my Signature under the Script, that I can see, where I find it :)

For Questions or Remarks for this Script, 
please don't hesitate to get in Contact with me using: Grote.Scripts@googlemail.com 

#>