﻿[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") |
    Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") |
    Out-Null


$SqlServerPrimName = "ALWAYSON1"
$SqlServerSecName = "ALWAYSON2"
$SqlAgName = "MyTestAg"
$SqlAgDatabase = "AdventureWorks2012"
$AgListenerName = "AgListener1"
$AgListenerPort = 1433
$AgListenerIpAddress = "192.168.1.100"
$AgListenerSubnetMask = "255.255.255.0"
$HadrEndpointName = "HadrEndpoint"
$HadrEndpointPort = 5022
$BackupDirectory = "\\Your\Backup\Directory"

$SqlServerPrim = New-Object Microsoft.SqlServer.Management.Smo.Server($SqlServerPrimName)
$SqlServerSec = New-Object Microsoft.SqlServer.Management.Smo.Server($SqlServerSecName)


try {

    # backup the database (full database backup)
    $DbBackup = New-Object Microsoft.SqlServer.Management.Smo.Backup
    $DbBackup.Database = $SqlAgDatabase
    $DbBackup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database
    $DbBackup.Initialize = $true
    $DbBackup.Devices.AddDevice("$BackupDirectory\$($SqlAgDatabase)_AgSetup_full.bak", 
        [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
    $DbBackup.SqlBackup($SqlServerPrim)

    # backup the database (transaction log backup)
    $DbBackup = New-Object Microsoft.SqlServer.Management.Smo.Backup
    $DbBackup.Database = $SqlAgDatabase
    $DbBackup.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Log
    $DbBackup.Initialize = $true
    $DbBackup.Devices.AddDevice("$BackupDirectory\$($SqlAgDatabase)_AgSetup_log.trn", 
        [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
    $DbBackup.SqlBackup($SqlServerPrim)


    # restore the database (full database restore)
    $DbRestore = New-Object Microsoft.SqlServer.Management.Smo.Restore
    $DbRestore.Database = $SqlAgDatabase
    $DbRestore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Database
    $DbRestore.Devices.AddDevice("$BackupDirectory\$($SqlAgDatabase)_AgSetup_full.bak", 
        [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
    $DbRestore.NoRecovery = $true
    $DbRestore.SqlRestore($SqlServerSec)

    # restore the database (transaction log restore)
    $DbRestore = New-Object Microsoft.SqlServer.Management.Smo.Restore
    $DbRestore.Database = $SqlAgDatabase
    $DbRestore.Action = [Microsoft.SqlServer.Management.Smo.RestoreActionType]::Log
    $DbRestore.Devices.AddDevice("$BackupDirectory\$($SqlAgDatabase)_AgSetup_log.trn", 
        [Microsoft.SqlServer.Management.Smo.DeviceType]::File)
    $DbRestore.NoRecovery = $true
    $DbRestore.SqlRestore($SqlServerSec)


    # create the endpoint if it doesn't exist on the primary replica
    $EndpointPrim = $SqlServerPrim.Endpoints | 
        Where-Object {$_.EndpointType -eq [Microsoft.SqlServer.Management.Smo.EndpointType]::DatabaseMirroring}
    if(!$EndpointPrim) {
        $EndpointPrim = New-Object Microsoft.SqlServer.Management.Smo.Endpoint($SqlServerPrim, $HadrEndpointName)
        $EndpointPrim.EndpointType = [Microsoft.SqlServer.Management.Smo.EndpointType]::DatabaseMirroring
        $EndpointPrim.ProtocolType = [Microsoft.SqlServer.Management.Smo.ProtocolType]::Tcp
        $EndpointPrim.Protocol.Tcp.ListenerPort = $HadrEndpointPort
        $EndpointPrim.Payload.DatabaseMirroring.ServerMirroringRole = [Microsoft.SqlServer.Management.Smo.ServerMirroringRole]::All
        $EndpointPrim.Payload.DatabaseMirroring.EndpointEncryption = [Microsoft.SqlServer.Management.Smo.EndpointEncryption]::Required
        $EndpointPrim.Payload.DatabaseMirroring.EndpointEncryptionAlgorithm = [Microsoft.SqlServer.Management.Smo.EndpointEncryptionAlgorithm]::Aes

        $EndpointPrim.Create()
        $EndpointPrim.Start()
    }

    # create the endpoint if it doesn't exist on the secondary replica
    $EndpointSec = $SqlServerSec.Endpoints | 
        Where-Object {$_.EndpointType -eq [Microsoft.SqlServer.Management.Smo.EndpointType]::DatabaseMirroring}
    if(!$EndpointSec) {
        $EndpointSec = New-Object Microsoft.SqlServer.Management.Smo.Endpoint($SqlServerSec, $HadrEndpointName)
        $EndpointSec.EndpointType = [Microsoft.SqlServer.Management.Smo.EndpointType]::DatabaseMirroring
        $EndpointSec.ProtocolType = [Microsoft.SqlServer.Management.Smo.ProtocolType]::Tcp
        $EndpointSec.Protocol.Tcp.ListenerPort = $HadrEndpointPort
        $EndpointSec.Payload.DatabaseMirroring.ServerMirroringRole = [Microsoft.SqlServer.Management.Smo.ServerMirroringRole]::All
        $EndpointSec.Payload.DatabaseMirroring.EndpointEncryption = [Microsoft.SqlServer.Management.Smo.EndpointEncryption]::Required
        $EndpointSec.Payload.DatabaseMirroring.EndpointEncryptionAlgorithm = [Microsoft.SqlServer.Management.Smo.EndpointEncryptionAlgorithm]::Aes

        $EndpointSec.Create()
        $EndpointSec.Start()
    }
    
    
    $AvailabilityGroup = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityGroup($SqlServerPrim, $SqlAgName)

    # create the primary replica object
    $PrimaryReplica = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityReplica($AvailabilityGroup, $SqlServerPrimName)
    $PrimaryReplica.EndpointUrl = "TCP://$($SqlServerPrim.NetName):$($EndpointPrim.Protocol.Tcp.ListenerPort)"
    $PrimaryReplica.FailoverMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaFailoverMode]::Automatic
    $PrimaryReplica.AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit
    $AvailabilityGroup.AvailabilityReplicas.Add($PrimaryReplica)

    # create the secondary replica object
    $SecondaryReplica = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityReplica($AvailabilityGroup, $SqlServerSecName)
    $SecondaryReplica.EndpointUrl = "TCP://$($SqlServerSec.NetName):$($EndpointSec.Protocol.Tcp.ListenerPort)"
    $SecondaryReplica.FailoverMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaFailoverMode]::Automatic
    $SecondaryReplica.AvailabilityMode = [Microsoft.SqlServer.Management.Smo.AvailabilityReplicaAvailabilityMode]::SynchronousCommit
    $AvailabilityGroup.AvailabilityReplicas.Add($SecondaryReplica)

    # create the availability group database object
    $AvailabilityDb = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityDatabase($AvailabilityGroup, $SqlAgDatabase)
    $AvailabilityGroup.AvailabilityDatabases.Add($AvailabilityDb)


    # create the listener object
    $AgListener = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityGroupListener($AvailabilityGroup, $AgListenerName)
    $AgListenerIp = New-Object Microsoft.SqlServer.Management.Smo.AvailabilityGroupListenerIPAddress($AgListener)
    $AgListener.PortNumber = $AgListenerPort
    $AgListenerIp.IsDHCP = $false
    $AgListenerIp.IPAddress = $AgListenerIpAddress
    $AgListenerIp.SubnetMask = $AgListenerSubnetMask
    $AgListener.AvailabilityGroupListenerIPAddresses.Add($AgListenerIp)
    $AvailabilityGroup.AvailabilityGroupListeners.Add($AgListener)


    # create the availability group
    $SqlServerPrim.AvailabilityGroups.Add($AvailabilityGroup)
    $AvailabilityGroup.Create()
    
    # on the secondary replica, join the replica to the AG, and join the database to the AG
    $SqlServerSec.JoinAvailabilityGroup($SqlAgName)
    $SqlServerSec.AvailabilityGroups[$SqlAgName].AvailabilityDatabases[$SqlAgDatabase].JoinAvailablityGroup()
}
catch {
    Write-Error $_.Exception
}