﻿# This script assumes that you have the RSAT Active Directory tools installed
Import-Module ActiveDirectory # Imports the active directory powershell module
$Username = Read-Host 'UserName' # Prompt for User Name
# Below list the user inputed above AD Groups then just selects the Name and sorts from A-Z if you want the distinguishedName info replace Name with distinguishedName 
Get-ADPrincipalGroupMembership -Identity $Username -OutVariable Name | Select-Object Name | Sort-Object Name