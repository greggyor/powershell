Function Get-HKCUValue {
    Param ($username,$computername,$key,$value)
    $objUser = New-Object System.Security.Principal.NTAccount("$username")
    $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
        Get-RegValue -ComputerName $computername -Hive Users -Key ($strSID.value + "\" + $key) -Value $value}