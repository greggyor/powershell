﻿#Function to delete files older than a date

Function Delete-Files([string] $Path, [String] $Filefilter, [int] $DaysThreshold)
{
	
	get-ChildItem -Path $Path -Filter $Filefilter | where {$_.creationTime -lt (Get-Date).AddDays($DaysThreshold*(-1))} | remove-Item
}

Delete-Files -Path "C:\tmp" -Filefilter "*.bak" -DaysThreshold 1



