﻿############################################################
#
# Copyright (c) Microsoft. All rights reserved.
# This code is licensed under the Microsoft Public License.
# THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
# ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
# IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
# PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
############################################################

##############################################################
#
# ConfigureStorageCluster.ps1
# ------------------------
#
# Configures Storage cluster as part of the Cloud Technologies 
#   sample
#  
#  - Configures storage spaces
#  - Creates a new cluster if it doesn't already exist.
#  - Or joins the existing storage cluster.
#  - Sets cluster quorum
#  - Configures storage disks and CSV shares for the cluster
#
# Depends on constructors in the Cloud.psm1 module file
##############################################################

<#
.PARAMETER Name
The name of the cluster to create if cluster is not found

.PARAMETER StaticAddress
Static addresses of the cluster. Passed to the new-cluster cmdlet.

.PARAMETER IgnoreNetwork
Passed to the new-cluster cmdlet

.PARAMETER ClusterAccess
Accounts that will need full cluster access

.PARAMETER FileServerName
The name of the fileserver role to create.

.PARAMETER SpacesSetting 
Hashtable that specifies storage spaces configuration
Constructors for the object model are defined in the cloud module.
$SpacesSetting = SpacesSetting -Friendlyname 'ClusterStoragePool' -Bustype 'SAS' -ReserveQuorum $ReserveQuorum -VirtualDisks @( 
                virtualdisk -FriendlyName 'VMShareDisk' -size (200 * 1GB)
                virtualdisk -FriendlyName 'VMLibraryDisk' -size (200 * 1GB)
                virtualdisk -FriendlyName 'WitnessShareDisk' -size (1 * 1GB)
                virtualdisk -FriendlyName 'QuorumDisk' -size (1 * 1gb)
                ) -QuorumVirtualDisk 'QuorumDisk'

.PARAMETER PreparedQuorumDisk
Specifies the disk to set as quorum.
can be a string containing an unsigned integer or a hashtable that specifies the disk per machine.

.PARAMETER NetworkRoleSetting
ClusterNetworkRoleSetting parameter hashtable arrays that define the network role.  
    ClusterNetworkRoleSetting -Name *ClusterNet    -Role 1 -metric 999
    ClusterNetworkRoleSetting -Name *LMNet         -Role 3 
    ClusterNetworkRoleSetting -Name *ManagementNet -Role 3
        
.PARAMETER featureSet
Features to install with add-windowsfeature.

#>
param(
    [Parameter(Mandatory=$false)]
    [string]
    $Name,
    [Parameter(Mandatory=$false)]
    [string[]]
    $StaticAddress,
    [string[]]
    $IgnoreNetwork,
    [hashtable[]]
    $ClusterAccess,
    [string]
    $FileServerName,
    [hashtable]
    $SpacesSetting,
    [string]
    $PreparedQuorumDisk,
    [hashtable[]]
    $NetworkRoleSetting,
    [string[]]
    $FeatureSet  
    )
  
Set-strictMode -version 2
 
# Install necessary server features
Import-Module ServerManager
$featureSet = 'FileAndStorage-Services', 'Failover-Clustering', 'File-Services', 'FS-FileServer', 'RSAT-Clustering-Powershell'
$timeout = 10
$Sleep = 3
#$ParentProgressId = 1 

$Progress = @{
    Activity         = 'Configuring Storage Cluster' 
    Status           = 'Cluster' 
    CurrentOperation = 'Checking for existing cluster' 
    PercentComplete  = ( 0 )
    ParentID         = 1
    ID               = 2
} 

function UpdateProgress {
    Param(
    [string] 
    $Activity, 
    [string] 
    $Status, 
    [string]
    $CurrentOperation, 
    [uint32]
    $PercentComplete,
    [int]
    $id,
    $ParentID 
    )
    $PsboundParameters.GetEnumerator() | % { $Progress[$_.key]= $_.value }
    write-progress @Progress
}

function New-FileServer {
    Param( $FileServerName )
    If (-not (test-path variable:ParentProgressID)) { $ParentProgressId = -1 }
    $Progress = @{
        Activity         = ( "Configuring FileServer {0}... " -f  $FileServerName ) 
        ParentID         = $ParentProgressId
    } 
    
    UpdateProgress -Status ( "Creating FileServer... " ) -CurrentOperation 'Adding Role' -PercentComplete 0
    
    Add-ClusterScaleoutFileServerRole -Name $FileServerName  
    if( $? )
    {
        UpdateProgress -Status ( "Created FileServer {0}... " -f  $FileServerName ) -CurrentOperation 'Added' -PercentComplete 25
    }
    else
    {
        Throw ("Fileserver: {0} could not be created" -f $FileServerName )

    }
    UpdateProgress -Status ( "Onlining FileServer {0}... " -f  $FileServerName ) -CurrentOperation 'Waiting' -PercentComplete 50
    # Online the fileserver group 
    Get-ClusterGroup $FileServerName | Start-ClusterGroup
    if( $? )
    {
        #
        # Configure CSV
        #
        
        UpdateProgress -Status ( "FileServer {0} online " -f  $FileServerName ) -CurrentOperation 'Getting cluster available disks' -PercentComplete 75
        
        Get-ClusterAvailableDisk | % { 
            UpdateProgress -CurrentOperation "Adding disks $($_.name)" -PercentComplete 80; $_ 
                } |
                Add-ClusterDisk | % { 
                    UpdateProgress -CurrentOperation "Adding CSV $($_.name)" -PercentComplete 90 ; $_ 
                        } |
                Add-ClusterSharedVolume | % { UpdateProgress -CurrentOperation "CSV done" -PercentComplete 100 }
    }
    else
    {
        throw 'File server not online'
    }
    Write-Progress -Activity $progress.Activity -ParentId $ParentProgressId -Completed 
}

function Set-ClusterNetworkRoleSetting {
    Param(
        [Parameter( Mandatory=$True )]
        [switch]
            $RegexMatch,
        [Parameter( Mandatory=$True, 
            ParameterSetName = 'ClusterNetworkInterfaceName'
            )]
        [Alias('Name')]
        [string]
            $ClusterNetworkInterfaceName,
                [Parameter( Mandatory=$True, 
            ParameterSetName = 'ClusterNetworkInterfaceAddress'
            )]
        [Alias('Address')] 
        [ValidateScript({[IPAddress]::Parse($_)})]
        [string]
            $ClusterNetworkInterfaceAddress,
        [Parameter( Mandatory=$True, 
            ParameterSetName = 'ClusterNetworkInterfaceID'
            )]
        [Alias('ID')] 
        [guid]
            $ClusterNetworkInterfaceID,
        [ValidateSet(0,1,3)]
        [int]
            $Role,  
        [uint32]
            $Metric
    )
   
    $Progress = @{
        Activity         = 'Configuring Storage Cluster' 
        ParentID         = $ParentProgressId
    } 
 
    switch( $PSBoundParameters ){
        {$_.ClusterNetworkInterfaceName }{
            $Property = 'Name'
            $Value = $ClusterNetworkInterfaceName
            }
        {$_.ClusterNetworkInterfaceAddress }{
            $Property = 'Address'
            $Value = $ClusterNetworkInterfaceAddress
            }
        {$_.ClusterNetworkInterfaceID }{
            $Property = 'ID'
            $Value = $ClusterNetworkInterfaceID
        }
    }


    #get the cluster network  
    if( $RegexMatch )
    {
        $ClusterNetwork = ( Get-ClusterNetworkInterface | ? {$_."$Property" -Match $Value} ) | select -expand network
    }
    else
    {
        $ClusterNetwork = ( Get-ClusterNetworkInterface | ? {$_."$Property" -like $Value} ) | select -expand network
    }
    
    if(-not $clusternetwork){write-warning  "Cluster Network interface $Value not found"}
    if( $Role   ){ $ClusterNetwork | % {$_.Role = $Role } }
    if( $Metric ){ $ClusterNetwork | % {$_.Metric = $Metric } }
}


If( $FeatureSet ){
    $FeatureSet = $FeatureSet
}
 
$result = Add-WindowsFeature -Name $featureSet 
if( $result.restartneeded -ne 'No' )
{
    $result
    throw "Restart needed"
}
else
{
    $result
}

Import-Module FailoverClusters
$joinWait = 20
if( $Name -and $StaticAddress ){
    
    $joinAddress = $StaticAddress | % {($_ -split '/')[0]}

    # Join existing cluster if available
    start-sleep -Seconds $joinWait   
    
    $ConfirmedAddresses = $joinAddress | %{ 
                UpdateProgress  -Status "Checking for existing cluster addresses" -CurrentOperation "Testing $($_)" ;
                $_
                } | ?{ Test-connection -ComputerName $_ -quiet -Count 1 } | % { 
                        UpdateProgress -Status 'Cluster address found'  ; 
                        $_ 
                    }
    
    if ( $ConfirmedAddresses )
    {
            Foreach ($Address in $ConfirmedAddresses)  {
                UpdateProgress  -Status "Attempting to Join cluster $Name at Address: $address... " -CurrentOperation 'Joining'
                $Cluster = Add-ClusterNode -Cluster $Address -name $Env:computername  -ErrorAction stop
                if( $? ){ 
                    UpdateProgress -Status "Node $Env:COMPUTERNAME added to cluster at $address" -CurrentOperation 'joined'
                    $cluster
                }
                else
                {
                    UpdateProgress -Status "Node $Env:COMPUTERNAME could not join cluster at $address" -CurrentOperation 'failed'
                    Write-Warning "$Env:computername could not join $Name" 
                }
            } # foreach         
    }
    else
    {
        UpdateProgress  -Status "Configuring new Cluster on $Env:COMPUTERNAME" -CurrentOperation " " -PercentComplete 0
        $ParentProgressID = 2
        
        #
        # Configure Spaces (if using)
        #
        
        if( $SpacesSetting )
        {
            if (-not (test-path variable:ParentProgressID)) { $ParentProgressId = -1 }
            $SpacesProgress = @{
                Activity = "Configuring Storage Spaces" 
                Status   = "Configuring pool" 
                ParentId = $ParentProgressId 
                PercentComplete = 0
                }
            Write-progress @SpacesProgress
            
            # get the parameters table for new-storagepool cmdlet
            $PoolSetting = $SpacesSetting.NewStoragePoolSetting
            
            # Get the physical disks for our storage pool 
            # getphysicaldiskparameter is a hashtable to splat against 
            # the get-PhysicalDisk parameter to get the physical disk you want
            if( $SpacesSetting['GetPhysicalDiskParameter'] )
            {
                # If a known set of physical disks is specified get the physical disk set.
                # e.g. 
                # GetPhysicalDiskParameter = @{FriendlyName = @('PhysicalDisk4','PhysicalDisk3','PhysicalDisk5','PhysicalDisk6')}
                $Parameter = $SpacesSetting.GetPhysicalDiskParameter
                $PhysicalDisks = Get-PhysicalDisk @Parameter
            }
            else
            {
                # If a Physical Disk set is not specified, use all the physical disks
                $PhysicalDisks = Get-PhysicalDisk | ? { -not $_.ispooled }
            }
            # Get only the disks of the type we are going to use for storage. The SAS bus disks for instance.
            if( $SpacesSetting.BusType) 
            {
                $PhysicalDisks = $PhysicalDisks| ? { $_.Bustype -eq $SpacesSetting.BusType }
            }
            
            # Reserve quorum disk. 
            # grab one of the physical disks to be the quorum
            if( -not $PreparedQuorumDisk )
            {
                if( $spacessetting['ReserveQuorum'] )
                {         
                    Write-progress @SpacesProgress -CurrentOperation "Reserving Physical disk for quorum"
                    # Reserve a physical disk 
                    $QuorumPDisk = $physicalDisks | select -First 1
            
                    # get the disk that matches 
                    $QuorumDisk = Get-disk | ?{ $_.serialNumber -eq  $QuorumDisk.serialnumber } 
                    
                    $SpacesProgress.percentcomplete += 10 
                    Write-progress  @SpacesProgress -CurrentOperation "Prepping Quorum disk"
                    
                    # Prepare the storage disk
                    if( $quorumdisk.partitionstyle -eq "RAW")
                    {
                        $QuorumDisk | Initialize-Disk  # Initialize the Disk
                    }
                    $partition = $QuorumDisk | get-disk | New-Partition # Partition the disk 
                    $partition | Format-Volume -Confirm:$false  -Force # Format the volume
                
                    # Update everything
                    $quorumdisk = $quorumdisk | get-disk
           
                    Update-StorageProviderCache -DiscoveryScope Full
                    $SpacesProgress.percentcomplete += 10 
                    Write-progress  @SpacesProgress 
                    
                    # After formatting the Quorum disk it will no longer be available for pooling and will not be 
                    # returned by get-physicaldisk so we update the variable here.
                    $Physicaldisks = Get-PhysicalDisk
                    if( $SpacesSetting.BusType )
                    {
                        $PhysicalDisks = $PhysicalDisks |? { $_.Bustype -eq $SpacesSetting.BusType }
                    }
                }
            }  
            # Check if pool already exists, if so use it.
            $storagepool = Get-StoragePool -FriendlyName $PoolSetting.FriendlyName  -ErrorAction SilentlyContinue
            
            if( -not $storagepool )
            { 
                #If no pool with this name exists create it
                $SpacesProgress.percentcomplete += 10
                Write-progress @SpacesProgress -CurrentOperation ("Creating new StoragePool {0}... " -f $SpacesSetting.NewStoragePoolSetting.FriendlyName )
                
                $storagepool = New-StoragePool @PoolSetting -PhysicalDisks $PhysicalDisks -erroraction stop
                if( $? )
                {
                    $SpacesProgress.percentcomplete = 100
                     Write-progress @SpacesProgress -CurrentOperation "Pool done" 
                }
            }
            else
            {
                Write-Warning ("Pool {0} exists. Using existing pool." -f $SpacesSetting.NewStoragePoolSetting.FriendlyName  )
            }
            
            $SpacesProgress.Status = "Creating Virtual Disks"
            $SpacesProgress.Percentcomplete = 0
            
            # Create virtual disks   
            @( $SpacesSetting.VirtualDisk ) | % { $Count = 0} {

                    Write-progress @SpacesProgress -CurrentOperation $_.FriendlyName 
                    $SpacesProgress.Percentcomplete = (100 * $count/$SpacesSetting.VirtualDisk.count)
                    
                    # Check for name collision.  
                    $ExistingDisk = Get-VirtualDisk -FriendlyName $_.FriendlyName -ErrorAction SilentlyContinue
                    if( -not $ExistingDisk )
                    {
                        $NewDisk = New-VirtualDisk @_ -StoragePoolFriendlyName $SpacesSetting.NewStoragePoolSetting.FriendlyName -ErrorAction stop

                        if( -not $? )
                        {
                            Write-error ("Disk `'{0}`' could not be created." -f  $_.FriendlyName )
                        } 
                    }
                    else
                    {
                        write-warning ("Virtual Disk `'{0}`' exists. Using existing disk" -f $_.FriendlyName )
                    } 
                    $Count++
                }
                $SpacesProgress.Percentcomplete = 100
                Write-progress @SpacesProgress -CurrentOperation " "   
                
            # get the virtual disks just created.
            
            $VirtualDisks = Get-VirtualDisk -FriendlyName ( $SpacesSetting.VirtualDisk |% { $_.FriendlyName } )
                  
            # Initialize the virtual disks
            $SpacesProgress.Status = "Prepping virtual disks" 
            $SpacesProgress.Percentcomplete = 0
            
            @( $VirtualDisks ) | % { Write-progress @SpacesProgress -CurrentOperation $_.FriendlyName ; $_ } | 
                Initialize-Disk -passthru -ErrorAction stop |  
                    New-Partition  -UseMaximumSize -ErrorAction stop|   
                         Format-Volume -ErrorAction stop -Confirm:$false -Force # Format the volume
           
           $SpacesProgress.PercentComplete = 100
           Write-progress @SpacesProgress -CurrentOperation 'Done' -Completed
        }  

        #
        # Create cluster
        #
       
        $Params = @{
            Name = $Name 
            StaticAddress = $StaticAddress
        }
        if( $IgnoreNetwork ){ $params["IgnoreNetwork"] = $IgnoreNetwork }
        
        UpdateProgress -Status "Creating new Cluster" -PercentComplete 50 -CurrentOperation 'Waiting...'
        $cluster =  New-Cluster -nostorage @Params -erroraction stop
        if( $? )
        {
            UpdateProgress -Status "Configuring Cluster" -PercentComplete 60 -CurrentOperation "Cluster Access" 
            
            # Grant access to the cluster administrators/users
            @($ClusterAccess) | % { Grant-ClusterAccess @_ }  
            
            #
            # Configure quorum disk
            #
            
           UpdateProgress -Status "Configuring Cluster" -PercentComplete 70 -CurrentOperation "Setting Quorum" 
            
           function WaitAndSetQuorum {
                Param($QuorumDiskClusterResource)
                for($Count = 0; $QuorumDiskClusterResource.State -ne 'online' -or $Count -lt $TimeOut ; $Count++ ) 
                { 
                    Start-Sleep $Sleep
                }
                
                if($QuorumDiskClusterResource.State -eq 'online') 
                {                 
                    #Set the quorum disk
                    Set-ClusterQuorum -NodeAndDiskMajority $QuorumDiskClusterResource.Name  
                } 
                else 
                {
                    Write-warning "Set-Quorum timed out. Quorum may not be set"
                }
           }
           
           if( $PreparedQuorumDisk )
            {   
                # NonSpaces: if not using spaces confgure quorum from $PreparedQuorumDisk or accept
                # cluster defaults
                $QuorumDisk = Get-Disk -Number $PreparedQuorumDisk  
                        
                $QuorumDiskClusterResource = $QuorumDisk | Add-ClusterDisk  
                       
                WaitAndSetQuorum $QuorumDiskClusterResource
            } 
            elseif ( $SpacesSetting )
            {
                if((-not $spacesSetting[ 'ReserveQuorum' ] ) -and ($SpacesSetting['QuorumVirtualDisk'] -ne $null) )
                {
                    $QuorumDisk = Get-VirtualDisk -FriendlyName $SpacesSetting.QuorumVirtualDisk | Get-Disk
                }
                       
                $QuorumDiskClusterResource = Get-ClusterAvailableDisk -disk $QuorumDisk |
                    Add-clusterDisk

                WaitAndSetQuorum $QuorumDiskClusterResource
            }

            #
            # Configure Cluster preferred networks  
            #
            
            UpdateProgress -Status "Configuring Cluster" -PercentComplete 80 -CurrentOperation "NetworkRole Setting" 
            
            if( $NetworkRoleSetting )
            {
                $NetworkRoleSetting | % { 
                        Set-ClusterNetworkRoleSetting @_
                    }
            }   
        }
        else
        {
            throw 'Cluster could not be created'
        }  
    }
}

if( $FileServerName ){   
        if (((get-service clussvc -erroraction silentlycontinue).status -eq 'Running') -and -not ( get-clusterGroup $FileServerName -ErrorAction silentlycontinue)){
            UpdateProgress -Status "Configuring FileServer" -PercentComplete 80 -CurrentOperation "FileServer" 
            New-FileServer -FileserverName $FileServerName
            }
}

UpdateProgress -Activity "End"  -Status "Completing" -PercentComplete 100 -CurrentOperation "Exiting"
Write-Progress -Activity "Configuring Cluster" -id $progress['id'] -Completed