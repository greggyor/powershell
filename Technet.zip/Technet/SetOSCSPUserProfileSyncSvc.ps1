﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Load Microsoft SharePoint Snapin
if ((Get-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null) {Add-PSSnapin Microsoft.SharePoint.PowerShell}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
	   [Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
	   [Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
	   [Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
	   [Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
	   $exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
	   $customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
	   return $customError
	}
}

Function Set-OSCSPUserProfileSyncSvc
{
	<#
		.SYNOPSIS
		Set-OSCSPUserProfileSyncSvc is an advanced function which can be used to set the service account for user profile synchronization service in Microsoft SharePoint Server 2010.
		.DESCRIPTION
		Set-OSCSPUserProfileSyncSvc is an advanced function which can be used to set the service account for user profile synchronization service in Microsoft SharePoint Server 2010.
		.PARAMETER DisplayName
		Indicates the display name a SharePoint User Profile Service Application.
		.PARAMETER FarmAccount
		Indicates the name of Farm Account. Please use Get-Credential for generating the object.
		.EXAMPLE
		#Set the service account for User Profile Synchronization Service.
		Set-OSCSPUserProfileSyncSvc -DisplayName "User Profile Service Application" -FarmAccount (Get-Credential "domain\farmaccountname") -Verbose
		.LINK
		Plan for profile synchronization (SharePoint Server 2010) - Plan account permissions
		http://technet.microsoft.com/en-us/library/ff182925.aspx#permission
		.LINK
		User Profile Service troubleshooting
		http://technet.microsoft.com/en-us/library/gg750253.aspx
	#>

	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$DisplayName,
		[Parameter(Mandatory=$true,Position=2)]
		[System.Management.Automation.PSCredential]$FarmAccount
	)
	Process
	{
		Try
		{
			#Get SharePoint Service Application according to the specified display name.
			$verboseMsg = $Messages.GetSPSvcApp
			$verboseMsg = $verboseMsg -replace "Placeholder01",$DisplayName
			$pscmdlet.WriteVerbose($verboseMsg)
			$spSvcApp = Get-SPServiceApplication -Name $DisplayName -ErrorAction Stop -Verbose:$false
		}
		Catch
		{
			#If Get-SPServiceApplication failed for any reason, this function will be terminated.
			$errorMsg = $Messages.CannotFindAppWithSpecifiedDisplayName
			$errorMsg = $errorMsg -replace "Placeholder01",$DisplayName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null
		}
		#If $spSvcApp is not a User Profile Service Application, this function will be terminated.
		if ($spSvcApp.TypeName -eq "User Profile Service Application") {
			#Get related information from environment and user input.
			$computerName = $env:ComputerName
			$farmAccountUserName = $FarmAccount.UserName
			$farmAccountPassword = $FarmAccount.Password
			if ($farmAccountUserName -ne $((Get-SPFarm -Verbose:$false).DefaultServiceAccount.Name)) {
				$errorMsg = $Messages.WrongSvcAccount
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				return $null			
			}
			#Get SharePoint User Profile Synchronization Service instance and modify the properties.
			$verboseMsg = $Messages.GetUPSS
			$pscmdlet.WriteVerbose($verboseMsg)
			$spSvcInstance = Get-SPServiceInstance -Verbose:$false | Where-Object {$_.TypeName -eq "User Profile Synchronization Service"}
			if ($spSvcInstance.Status -eq [Microsoft.SharePoint.Administration.SPObjectStatus]::Disabled) {
				$verboseMsg = $Messages.UpdateSvcAcct
				$pscmdlet.WriteVerbose($verboseMsg)				
				$spSvcApp.SetSynchronizationMachine($computerName,$spSvcInstance.Id,$farmAccountUserName,$farmAccountPassword)
				$spSvcInstance.Status = [Microsoft.SharePoint.Administration.SPObjectStatus]::Provisioning
				$spSvcInstance.IsProvisioned = $false
				$spSvcInstance.UserProfileApplicationGuid = $spSvcApp.Id
				$spSvcInstance.Update()
			} else {
				$errorMsg = $Messages.CannotSetUPSyncSvc
				$errorMsg = $errorMsg -replace "Placeholder01",$($spSvcInstance.Status)
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
			}
		} else {
			$errorMsg = $Messages.WrongSvcAppType
			$errorMsg = $errorMsg -replace "Placeholder01",$DisplayName
			$errorMsg = $errorMsg -replace "Placeholder02",$($spSvcApp.TypeName)
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null			
		}
	}
}

