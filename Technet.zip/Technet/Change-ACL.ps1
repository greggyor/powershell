cls
ipmo activedirectory

function mod-ACL {
	param($scope,$grp)

	$oct1 = $scope.Split(".")[0]
	$oct2 = $scope.Split(".")[1]
	$oct3 = $scope.Split(".")[2]
	$ptr = $oct3 + "." + $oct2 + "." + $oct1 + ".in-addr.arpa" # define the PTR zone name
	$ptrobjdn = "DC=" + $ptr + ",CN=MicrosoftDNS,DC=dnszones,DC=myDomain,DC=net" # define the object distinguishedName

	Write-Host -ForegroundColor DarkGreen $ptr
	$acl = Get-Acl ("AD:\" + $ptrobjdn) -ErrorAction SilentlyContinue -ErrorVariable a # get the ACL of the zone
	
	if ($a -like "*Cannot find path*"){Write-Host -ForegroundColor DarkCyan "Zone" $ptr "does not exist."}
	else{
		foreach ($entry in $acl.Access){if ($entry.IdentityReference -eq ("DOMmyDomain01\" + $grp.SamAccountName)){$grpexist = 1}}
		if (!$grpexist){
			Write-Host "Adding group" $grp.SamAccountName "to ACL."
			$p = New-Object System.Security.Principal.SecurityIdentifier $grp.SID
			$ace = new-object System.DirectoryServices.ActiveDirectoryAccessRule $p,"GenericAll","Allow"
			$acl.AddAccessRule($ace) # modify the ACL

			Set-Acl -ACLObject $acl -Path ("AD:\" + $ptrobjdn)
			
			$acl = Get-Acl ("AD:\" + $ptrobjdn)
			foreach ($entry in $acl.Access){if ($entry.IdentityReference -eq ("DOMmyDomain01\" + $grp.SamAccountName)){$grpexist = 1}} # check the new ACL of the zone
			if ($grpexist){Write-Host -ForegroundColor DarkGreen "Group added."}
			else {Write-Host -ForegroundColor DarkRed "ERROR !"}
		} else {Write-Host -ForegroundColor Green "OK"}
		$grpexist = $null
	}
}

$sitename = "mySite" # site name in AD sites&services
$grp = Get-ADGroup myGroup # group you want to add to the ACL
$search = "CN=" + $sitename + ",CN=Sites,CN=Configuration,DC=myDomain,DC=net" # search string for the site in AD
$siteobjbl = (Get-ADObject -Identity $search -Properties siteObjectBL).siteObjectBL # get the associated IP ranges

foreach ($subnet in $siteobjbl){
	$scope = (($subnet.split(",")[0]).split("=")[1]).split("/")[0] # define the IP range
	[int]$mask = (($subnet.split(",")[0]).split("=")[1]).split("/")[1] # define the subnet mask
	
	if ($mask -eq "16"){[int]$count = 255}
	if ($mask -eq "17"){[int]$count = 127}
	if ($mask -eq "18"){[int]$count = 63}
	if ($mask -eq "19"){[int]$count = 31}
	if ($mask -eq "20"){[int]$count = 15}
	if ($mask -eq "21"){[int]$count = 7}
	if ($mask -eq "22"){[int]$count = 3}
	if ($mask -eq "23"){[int]$count = 1}
	
	# if the subnet mask is below 24 handle all subnets in that range
	if ($mask -ge "24"){mod-acl $scope $grp}
	else {
		$oct1 = $scope.Split(".")[0]
		$oct2 = $scope.Split(".")[1]
		[int]$oct3 = $scope.Split(".")[2]
		for($i = 0;$i -le $count;$i++){
			$oct = $oct3 + $i
			$subscope = $oct1 + "." + $oct2 + "." + $oct + ".0"
			mod-acl $subscope $grp
		}
	}
}