﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 2.0

Function Remove-OSCSlideNotes
{
<#
 	.SYNOPSIS
        Remove-OSCSlideNotes is an advanced function which can be used to remove notes in powerpoint.
    .DESCRIPTION
        Remove-OSCSlideNotes is an advanced function which can be used to remove notes in powerpoint.
    .PARAMETER  <Path>
		Specify the path of slide.
    .EXAMPLE
        C:\PS> Remove-OSCSlideNotes -Path D:\PPT\
		File_Name                               Action(Remove Notes)
		---------                               --------------------
		Microsoft1.pptx                         Success
		Microsoft2.pptx                         Success
		Microsoft3.pptx                         Success
		Microsoft4.pptx                         Success
    .EXAMPLE
        C:\PS> Remove-OSCSlideNotes -Path D:\PPT\Microsoft1.pptx
		File_Name                               Action(Remove Notes)
		---------                               --------------------
		Microsoft1.pptx                         Success
#>
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		[Parameter(Mandatory=$true,Position=0,HelpMessage="Please input the path of folder.")]
		[Alias('p')][string]$Path
	)
	
	if($PSCmdlet.ShouldProcess("Remove speaker slide notes"))
	{
		if(Test-Path -Path $Path)
		{
			#Add the office assembly to the current Windows PowerShell session
			Add-type -AssemblyName Office
			#Create the PowerPoint application object
			$Application = New-Object -ComObject PowerPoint.Application
			
			foreach($file in (Get-ChildItem -Path $Path))
			{
				$filename = Split-Path -Path $file.FullName -Leaf
				
				if($file.Extension -match "ppt|pptx|pptm|ppsx|pps|ppsm|potx|pot|potm|odp")
				{
					$Objs = @()
					$Presentation = $Application.Presentations.Open($file.FullName,$null,$null,[Microsoft.Office.Core.MsoTriState]::msoFalse)
					$Slides = $Presentation.Slides
					
					try
					{
						foreach($Slide in $Slides)
						{
							if($Slide.NotesPage.Shapes.Count -gt 0)
							{		
								foreach($Shape in $Slide.Notespage.Shapes)
								{
									#remove speaker notes in slides
									if($Shape.TextFrame.HasText)
									{
										$Shape.TextFrame.TextRange=""
									}
								}
							}
						}
						$obj = New-Object -TypeName PSObject
						$obj|Add-Member -MemberType NoteProperty -Name "File Name" -Value $filename
						$obj|Add-Member -MemberType NoteProperty -Name "Action(Remove Notes)" -Value "Success"
						$Objs += $obj
						$Objs
					}
					catch
					{
						$obj = New-Object -TypeName PSObject
						$obj|Add-Member -MemberType NoteProperty -Name "File Name" -Value $filename
						$obj|Add-Member -MemberType NoteProperty -Name "Action(Remove Notes)" -Value "Failure"
						$Objs += $obj
						$Objs
					}
					$Presentation.Save()
					$Presentation.Close()
				}				
			}
			$Application.Quit()
			
			[void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Presentation)
			[void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Application)
			#garbage collection is called
			[GC]::Collect()
			
			#close the legacy process
			if(Get-Process|Where-Object {$_.Name -eq "POWERPNT"})
			{
				Stop-Process -Name "POWERPNT"
			}	
		}
		else
		{
			Write-Warning "The path does not exist, plese input the correct path."
		}
	}
}