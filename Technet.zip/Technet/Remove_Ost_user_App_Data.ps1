﻿<#

Date: 13-Feb-2012 ; 22:58
Author: Aman Dhally
Email: amandhally@gmail.com
www: www.amandhally.net/blog
blog: http://newdelhipowershellusergroup.blogspot.com/

Version : 1

				/^(o.o)^\ 
							
#>


$OstPath = $Env:LocalAppData + "\Microsoft" + "\Outlook"
$ost = get-ChildItem $OstPath | where { $_.Extension -eq ".ost"} 
$ost | remove-Item -WhatIf ## remove -wahtif to remove the files 

