# Copyright (c) Microsoft 
# All rights reserved.
# Microsoft Limited Public License:
# This license governs use of the accompanying software. If you use the software, you 
# accept this license. If you do not accept the license, do not use the software.
# 1. Definitions 
# The terms "reproduce," "reproduction," "derivative works," and "distribution" have the 
# same meaning here as under U.S. copyright law. 
# A "contribution" is the original software, or any additions or changes to the software. 
# A "contributor" is any person that distributes its contribution under this license. 
# "Licensed patents" are a contributor's patent claims that read directly on its contribution.
# 2. Grant of Rights 
# (A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create. 
# (B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made, use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the contribution in the software.
# 3. Conditions and Limitations 
# (A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks. 
# (B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software, your patent license from such contributor to the software ends automatically. 
# (C) If you distribute any portion of the software, you must retain all copyright, patent, trademark, and attribution notices that are present in the software. 
# (D) If you distribute any portion of the software in source code form, you may do so only under this license by including a complete copy of this license with your distribution. If you distribute any portion of the software in compiled or object code form, you may only do so under a license that complies with this license. 
# (E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties, guarantees or conditions. You may have additional consumer rights under your local laws which this license cannot change. To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability, fitness for a particular purpose and non-infringement.
# (F) Platform Limitation - The licenses granted in sections 2(A) and 2(B) extend only to the software or derivative works that you create that run on a Microsoft Windows operating system product.

#File version: 1.0.1.0
function Get-OverrideParameters
{
    $RunDeployParmFile = (Join-Path $AxBuildDir "OverrideParameters.txt")
    if ((Test-Path $RunDeployParmFile) -ne $false)
    {
        $fileContent = Get-Content $RunDeployParmFile
        foreach ($line in $fileContent)
        {
            $line = $line.split("=")
            [System.Environment]::SetEnvironmentVariable($line[0],$line[1])     
        }       
    }   
    
    $script:CompileCILTimeout        = [int](Set-Parameter "CompileCILTimeout" "60" )
    $script:SyncTimeout              = [int](Set-Parameter "SyncTimeout" "60" )
    $script:ImportTimeout            = [int](Set-Parameter "ImportTimeout" "60" )
    $script:CombineTimeout           = [int](Set-Parameter "CombineTimeout" "60" )
    $script:AOSRestartTimeout        = [int](Set-Parameter "AOSRestartTimeout" "60" )
    $script:CompileAllTimeout        = [int](Set-Parameter "CompileAllTimeout" "360" )
    $script:SetupRegistryPath        = (Set-Parameter "SetupRegistryPath" "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup" )
    $script:ServerRegistryPath       = (Set-Parameter "ServerRegistryPath" "HKLM:\SYSTEM\CurrentControlSet\services\Dynamics Server\6.0" )
    $script:ClientRegistryPath       = (Set-Parameter "ClientRegistryPath" "HKCU:\SOFTWARE\Microsoft\Dynamics\6.0\Configuration" )
    $script:labelsFolder             = (Set-Parameter "LabelsFolder" "label files" )
}

function Get-ImportOverrideParameters
{
    Write-InfoLog ("Start Get-ImportOverrideParameters : {0}" -f (Get-Date)) 
    $RunDeployParmFile = (Join-Path $AxBuildDir "ImportOverrideParameters.txt")
    if ((Test-Path $RunDeployParmFile) -ne $false)
    {
        $script:importOverrideParams = @{}

        $fileContent = Get-Content $RunDeployParmFile
        Write-InfoLog ("Override file content :")
        Write-InfoLog $fileContent 
        foreach ($line in $fileContent)
        {
            $line = $line.split("=")
            $importOverrideParams.Set_Item($line[0].Trim(),$line[1].Trim())
        }       
    }
    
    Write-InfoLog ("Import override params:")
    Write-InfoLog $importOverrideParams
    
    Write-InfoLog ("End Get-ImportOverrideParameters : {0}" -f (Get-Date))        
}

function Set-Parameter($name, $defaultVal)
{
    $value = GetEnvironmentVariable($name)
    if($value -eq $null)
    {
        $value = $defaultVal
    }
    
    $value
}

function Write-InfoLog($message)
{
    Write-Output ($message) 
}

function Write-ErrorLog($message)
{
    Write-InfoLog (" ")
    Write-InfoLog ("ERROR: *********")
    Write-InfoLog ($message)
    Write-InfoLog ("****************")
    Write-InfoLog (" ")
    
    if($transcriptStarted -eq $true)
    {
        if($scriptName -eq 'DEPLOY')
        {
            if($currentLogFolder -ne $null)
            {
                $message | out-file -append (join-path $currentLogFolder 'DeployErrors.err')
            }
        }
        else
        {
            if($dropLocation -ne $null)
            {
                $message | out-file -append (join-path $dropLocation 'BuildErrors.err')
            }
        }
    }
}

function Write-TerminatingErrorLog($message, $errorMsg)
{
    Write-ErrorLog $message
    Write-InfoLog $errorMsg
 
    if($buildModelStarted -eq $true)
    {
        $script:buildModelStarted = $false
        try
        {
            if($NoCleanOnError -ne $true)
            {
                Write-InfoLog ("                                                                 ") 
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("****************TRYING TO REVERT BUILD***************************") 
                Clean-Build
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("                                                                 ") 
            }
        }
        catch
        {
            Write-ErrorLog ("Failed to revert build.")
            Write-ErrorLog ($Error[0])
        }
    }

    Write-InfoLog ("{0} Failed" -f $scriptName)    
    Exit
}

function Register-SQLSnapIn
{
    Write-InfoLog ("Begin: Register-SQLSnapIn: {0}" -f (Get-Date)) 
    if ( Get-PSSnapin -Registered | where {$_.name -eq 'SqlServerProviderSnapin100'} ) 
    { 
        if( !(Get-PSSnapin | where {$_.name -eq 'SqlServerProviderSnapin100'})) 
        {  
            Add-PSSnapin SqlServerProviderSnapin100 | Out-Null 
        } ;  
        if( !(Get-PSSnapin | where {$_.name -eq 'SqlServerCmdletSnapin100'})) 
        {  
            Add-PSSnapin SqlServerCmdletSnapin100 | Out-Null 
        } 
    } 
    else 
    { 
        if( !(Get-Module | where {$_.name -eq 'sqlps'})) 
        {  
            Import-Module 'sqlps' �DisableNameChecking 
        } 
    }
    Write-InfoLog ("End: Register-SQLSnapIn: {0}" -f (Get-Date))  
}

function Check-PowerShellVersion
{
    $pv = get-host
    if($pv -ne $null -and $pv.Version -ne $null -and $pv.Version.Major -ne 2)
    {
        Write-TerminatingErrorLog ("Powershell version {0} not supported." -f $pv.Version.Major)
    }
}

function GetEnvironmentVariable($variableName)
{
    if ([System.Environment]::GetEnvironmentVariable($variableName) -ne $null)
    {
        ([System.Environment]::GetEnvironmentVariable($variableName).Trim())
    }
}

function Create-CurrentLogFolder
{
    $date = "Logs" + (Get-Date)
    $date = $date.Replace(' ', '')
    $date = $date.Replace('/', '')
    $date = $date.Replace(':', '')
    $script:currentLogFolder = (join-path $logFolder $date)
    New-Item $currentLogFolder -type directory
}

function Create-BuildFolders
{
    if ((Test-Path (Join-Path $dropLocation $currentVersion)) -eq $false) {$n = New-Item (Join-Path $dropLocation $currentVersion) -ItemType directory}
    $script:dropLocation = join-path $dropLocation $currentVersion
    if ((Test-Path (Join-Path $dropLocation "Logs")) -eq $false) {$n = New-Item (Join-Path $dropLocation "Logs") -ItemType directory}
    $script:currentLogFolder = join-path $dropLocation "Logs"
    if ((Test-Path (Join-Path $currentLogFolder "DetailedLogs")) -eq $false) {$n = New-Item (Join-Path $currentLogFolder "DetailedLogs") -ItemType directory}
    if ((Test-Path (Join-Path $dropLocation "Application")) -eq $false) {$n = New-Item (Join-Path $dropLocation "Application") -ItemType directory}
    if ((Test-Path (Join-Path $dropLocation "Application\bin")) -eq $false) {$n = New-Item (Join-Path $dropLocation "Application\bin") -ItemType directory}
    if ((Test-Path (Join-Path $dropLocation "Application\Appl")) -eq $false) {$n = New-Item (Join-Path $dropLocation "Application\Appl") -ItemType directory}
}

############################################################################################
#COMMON AX FUNCTIONS
############################################################################################
function Synchronize-AX
{
	Write-InfoLog ("Start synchronize : {0}" -f (Get-Date)) 
	$SynchStartTime = Get-Date 
	$arguments = '-lazyclassloading -lazytableloading -StartupCmd=Synchronize -internal=noModalBoxes'
    Write-InfoLog ("Calling Start-Process Synchronize: {0}" -f (Get-Date)) 
    $axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments -OutVariable out
	Write-InfoLog $out
    if ($axProcess.WaitForExit(60000*$SyncTimeout) -eq $false)
	{
		Write-ErrorLog("Error: AX synchronize did not complete within {0} minutes" -f $SyncTimeout)
		$axProcess.Kill()
		foreach($event in Get-EventLog Application | Where-Object {$_.Source -eq "Dynamics Server 01" -and $_.EntryType -eq "Error" -and $_.Timegenerated -gt $SynchStartTime})
		{
			Write-ErrorLog($event.Message.Substring($event.Message.IndexOf('[SQL Server]')+'[SQL Server]'.get_length()))
		}	
		Write-TerminatingErrorLog("Synchronize doesn't finished on time. Stopping the build")
	}
	Write-InfoLog ("Synchronize finished : {0}" -f (Get-Date)) 
    Write-InfoLog (" ")
}

function Stop-AOS
{
    Write-InfoLog ("Begin: Stop-AOS method : {0}" -f (Get-Date)) 
    $startDateTime = $(get-date)
    
    Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
    $aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName"""  -OutVariable out -Verbose
    Write-InfoLog $out
    if ($aos.State -ne [system.ServiceProcess.ServiceControllerStatus]::Stopped) 
    {
        Write-InfoLog ("Stopping AOS")        
        $rv = $aos.StopService().ReturnValue 
        
        if ($rv -ne 0) { 
           Write-TerminatingErrorLog ("AOS cannot be stopped. Got error code {0}" -f $rv)        
        }
    }
    
    Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
    $aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName"""  -OutVariable out -Verbose
    Write-InfoLog $out
	while ($aos.State -ne [system.ServiceProcess.ServiceControllerStatus]::Stopped)
	{
		if (($(get-date) - $startDateTime).get_Minutes() -gt $AOSRestartTimeout)
		{
     		Write-TerminatingErrorLog('The AOS can not be stopped after {0} minutes.' -f $AOSRestartTimeout)			
    		break
		}
		Start-Sleep 20
        Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
		$aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName""" -OutVariable out -Verbose
        Write-InfoLog $out
	}
    Write-InfoLog ("End: Stop-AOS method : {0}" -f (Get-Date)) 	
    Write-InfoLog (" ") 	
}

function Start-AOS
{
    Write-InfoLog ("Begin: Start-AOS method : {0}" -f (Get-Date)) 
	$startDateTime = $(get-date)

    Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
    $aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName""" -OutVariable out
    Write-InfoLog $out

    Write-InfoLog ("Current AOS state : {0}" -f ($aos.State)) 
    if ($aos.State -ne [system.ServiceProcess.ServiceControllerStatus]::Running)
    {
	   	Write-InfoLog ("Starting AOS")
        $rv = $aos.StartService().ReturnValue
        if ($rv -ne 0) {
            Write-TerminatingErrorLog ("AOS service can't be started. Got error code {0}" -f $rv)        
        } 
    }   

    Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
	$aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName""" -OutVariable out
    Write-InfoLog $out

	while ($aos.State -ne [system.ServiceProcess.ServiceControllerStatus]::Running)
	{
		if (($(get-date) - $startDateTime).get_Minutes() -gt $AOSRestartTimeout)
		{
			Write-TerminatingErrorLog('The AOS can not be started after {0} minutes.' -f $AOSRestartTimeout)			
			break
		}
		Start-Sleep 20
        
        Write-InfoLog ("Calling Get-WmiObject Win32_Service: {0}" -f (Get-Date)) 
		$aos = Get-WmiObject Win32_Service -ComputerName $AxAOSServerName -Filter "name=""$AOSName""" -OutVariable out
        Write-InfoLog $out
	}		
    Write-InfoLog ("End: Start-AOS method : {0}" -f (Get-Date)) 
    Write-InfoLog (" ") 	
}       

function Read-AXClientConfiguration
{
    $Path = $clientRegistryPath 
	$Path = Join-Path $Path (Get-ItemProperty (get-item ($Path)).PSPath).Current
	$script:clientBinDir = (Get-ItemProperty (get-item ($Path)).PSPath).bindir.TrimEnd('\')
	$script:clientLogDir = (Get-ItemProperty (get-item ($Path)).PSPath).logdir.TrimEnd('\')
	$script:AxAOS 	  	 = (Get-ItemProperty (get-item ($Path)).PSPath).aos2
	$script:clientLogDir = [System.Environment]::ExpandEnvironmentVariables("$clientLogDir")    
	$script:clientBinDir = [System.Environment]::ExpandEnvironmentVariables("$clientBinDir")    
    $script:ax32  = join-path $clientBinDir "ax32.exe"
    
    $parts = ($AxAOS.Split(';')[0]).Split('@')
    if($parts.Length -eq 2)
    {
        $AxAOSServerName = $parts[1]
        $AxAOSInstance = $parts[0]
    }
    elseif($parts.Length -eq 1) { $AxAOSServerName = $parts[0] }
    
    $parts = $AxAOSServerName.Split(':')
    if($parts.Length -eq 2) { 
        $AxAOSServerName = $parts[0]
        $port = $parts[1] }
    elseif($parts.Length -eq 1) { $AxAOSServerName = $parts[0] }

    $script:AxAOSServerName  = $AxAOSServerName
    $script:AxAOSInstance  = $AxAOSInstance
    $script:port  = $port
}

function Read-AxServerConfiguration 
{    
    if($env:computername -eq $axaosservername)
    {
        $serverPath = $serverRegistryPath 
    	foreach ($item in Get-ChildItem $serverPath)
    	{
    		$subpath = Join-Path $serverPath $item.PSChildName
    		$InstanceName = (Get-ItemProperty (get-item ($subPath)).PSPath).InstanceName
            if ( ($AxAOSInstance -eq $null) -or ($InstanceName -eq $AxAOSInstance) -or ($portNumber -eq $port))
    		{
    			$AOSName = $script:AOSname = "AOS60`${0}" -f $item.PSChildName #The ` character makes powershell know that the next character is to be handled as a part of the string
    			$CurrentServerConfig =  (Get-ItemProperty (get-item ($subPath)).PSPath).current
    		    $Path = Join-Path $subPath $CurrentServerConfig
                $portNumber = (Get-ItemProperty (get-item ($Path)).PSPath).port
                if( $port -eq $null -or ($portNumber -eq $port))
                {
        			$script:sqlServer 	  = (Get-ItemProperty (get-item ($Path)).PSPath).dbserver
        			$script:sqlDatabase   = (Get-ItemProperty (get-item ($Path)).PSPath).database
        	    	$script:serverBinDir  = (Get-ItemProperty (get-item ($Path)).PSPath).bindir.TrimEnd('\') 
        	    	$script:serverApplDir = (Get-ItemProperty (get-item ($Path)).PSPath).directory + "\Appl\" +
        	        	                    (Get-ItemProperty (get-item ($Path)).PSPath).application 
                    $script:AxAOSServerName = $AxAOSServerName
                }
    		}		
    	}
    }	    
}

############################################################################################
#END COMMON AX FUNCTIONS
############################################################################################


############################################################################################
#COMPILE-AX
############################################################################################
function Compile-Build
{
    try
    {
        #Step: Compile layer
        if ($AxCompileAll -eq "True")   
        {
            $script:compileErrors = $false
            
            $aolParm = ''
            $compileInLayerParm = ''
            if($compileInLayer -ne $null)
            {
                $AolCode = Get-AolCode $compileInLayer
                if ($aolCode -ne '') {$aolParm = '-aolCode={0}' -f $aolCode}
                
                $compileInLayerParm = '-aol={0}' -f $compileInLayer
            }
                    
            $arguments = '{0} {1} -lazyclassloading -lazytableloading -StartupCmd=compileall -novsprojcompileall -internal=noModalBoxes' -f $compileInLayerParm,$aolParm
            Write-InfoLog ("Calling CompileAll API : {0}" -f (Get-Date)) 
            $axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments -OutVariable out
            Write-InfoLog $out
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("                                                                 ") 

            if ($axProcess.WaitForExit(60000*$CompileAllTimeout) -eq $false)
            {
                $axProcess.Kill()
                Throw ("Error: AX compile did not complete within {0} minutes" -f $CompileAllTimeout)
            }
            
            Copy-Item -Path (Join-Path $clientLogDir AxCompileAll.html) -Destination (join-path $currentLogFolder AxCompileAll_Pass1.html) -Force -ErrorAction SilentlyContinue 
            
            #Step: Compile CIL
            if ($CompileCIL -eq 'True') 
            {
                if ($scriptName -eq 'Build')
                {
                    Compile-VSComponents

                    Stop-AOS
                    Start-AOS
                    Write-InfoLog (" ")
                    
                    $arguments = '{0} {1} -lazyclassloading -lazytableloading -StartupCmd=compilepartial -novsprojcompileall -internal=noModalBoxes' -f $compileInLayerParm,$aolParm
                    Write-host ("Calling CompilePartial API : {0}" -f (Get-Date)) 
                    $axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments -OutVariable out
                    Write-host $out
                    Write-InfoLog (" ")
                    Write-InfoLog (" ")
                    if ($axProcess.WaitForExit(60000*$CompileAllTimeout) -eq $false)
                    {
                        $axProcess.Kill()
                        Throw ("Error: AX compile partial did not complete within {0} minutes" -f $CompileAllTimeout)
                    }
                }

                Compile-CIL
        
                Write-InfoLog ("                                                                 ") 
                Write-InfoLog ("                                                                 ") 
            }
                
            #Step 
            Stop-AOS
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("                                                                 ") 
            
            #Step 
            Start-AOS
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("                                                                 ") 

            #Step 
            Synchronize-AX
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("                                                                 ") 
        }
    }
    finally
    {
        if($AxCompileAll -eq $true)
        {
            #Step     
            Check-CompilerErrors
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("                                                                 ") 
            Write-InfoLog ("Collecting AxCompileAll.html: {0}" -f (Get-Date)) 
            Copy-Item -Path (Join-Path $clientLogDir AxCompileAll.html) -Destination $currentLogFolder -Force -ErrorAction SilentlyContinue 
            Copy-Item -Path (Join-Path $clientLogDir AOTprco.log) -Destination $currentLogFolder -Force -ErrorAction SilentlyContinue 
            Copy-Item -Path (Join-Path $clientLogDir AOTcomp.log) -Destination $currentLogFolder -Force -ErrorAction SilentlyContinue 

            if ($CompileCIL -eq 'True') 
            {
                Check-CILErrors
                if((Test-path (join-path $serverBinDir XppIL)) -eq $True)
                {
                    Copy-Item -Path (Join-Path (join-path $serverBinDir XppIL) Dynamics.Ax.Application.dll.log) -Destination $currentLogFolder -Force -ErrorAction SilentlyContinue 
                }
            }
        }    
    }
}

function Compile-AX
{
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("*****************************************************************") 
    Write-InfoLog ("****************COMPILE AX***************************************") 
    Write-InfoLog ("Begin: AX compile : {0}" -f (Get-Date)) 
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 
    
    #Step 1: Stop AOS
    Stop-AOS
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 
    
    #Step 2: Update compiler Info
    Update-CompilerInfo
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 
    
    #Step 3: Delete auc files
    Remove-Item -Path (Join-Path $env:LOCALAPPDATA "ax_*.auc") -ErrorAction SilentlyContinue
    if((Test-path ($serverBinDir)) -eq $True)
    {
        $xpplPath = join-path $serverBinDir XppIL
        if (((Test-path ($xpplPath)) -eq $True) -and ((Test-path (join-path $xpplPath Dynamics.Ax.Application.dll.log)) -eq $True))
        {
            Remove-Item -Path (join-path $xpplPath Dynamics.Ax.Application.dll.log) -ErrorAction SilentlyContinue    
        }
    }
        
    #Step 4: Restart AOS
    Start-AOS
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 

    #Step 5: Set model store
    Write-InfoLog ("Calling Set-AXModelStore: {0}" -f (Get-Date)) 
    Set-AXModelStore -NoInstallMode -Server $sqlServer -Database $sqlDatabase -Verbose   
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("Starting compile : {0}" -f (Get-Date)) 
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 

    #Step 6:
    Synchronize-AX
    Write-InfoLog ("                                                                 ") 
    Write-InfoLog ("                                                                 ") 
        
    Compile-Build   
    
    Write-InfoLog ("Compile finished : {0}" -f (Get-Date)) 

    Write-InfoLog ("End: AX compile : {0}" -f (Get-Date)) 
    Write-InfoLog ("*****************************************************************") 
    Write-InfoLog ("*****************************************************************")
    Write-InfoLog ("                                                                 ")
}

function Compile-CIL
{
   	Write-InfoLog ("Starting CIL compile : {0}" -f (Get-Date)) 
	$CilXmlFile = join-path $currentLogFolder 'GenerateIL.XML'
	$CilLogFile = join-path $currentLogFolder 'GenerateIL.log' 
	$newFile = @()
	$newFile += '<?xml version="1.0" encoding="utf-8"?>' 
	$newFile += '<AxaptaAutoRun version="4.0" logFile="{0}">' -f $CilLogFile
	$newFile += '<Run type="class" name="SysCompileIL" method="generateIL" parameters="true" />'
	$newfile += '</AxaptaAutoRun>'
	$newfile | Out-File $CilXmlFile -Encoding Default
	$arguments = '-lazyclassloading -lazytableloading "-StartupCmd=autorun_{0}"' -f $CilXmlFile
   	$axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments 
	if ($axProcess.WaitForExit(60000*$CompileCILTimeout) -eq $false)
	{
		$axProcess.Kill()
		Throw ("Error: AX CIL compile did not complete within {0} minutes" -f $CompileCILTimeout)
	}
    
    try
    {
    	[xml]$LogFile = Get-Content($CilLogFile)
    	$Infolog = $LogFile.AxaptaAutoRun.Infolog.Split([char]10)
    	foreach($line in $Infolog)
    	{
    		if ($line.Length -gt 0)
    		{
    			$i = $line.LastIndexOf([char]9)
    			if ($i -gt 0) {$line = $line.Substring($i+1)}
    			if ($line.Contains('Service group started:') -eq $false)
    			{
    				if ($line -eq 'The full CIL generation from X++ is done.')
    				{
    					Write-InfoLog '.   ' + $line 
    				}			
    				else
    				{
    					Write-ErrorLog(('Compile-CIL Error   ' + $line))
    				}
    			}			
    		}			
    	}
    }
    catch
    {
        Write-ErrorLog "Exception in Compile-CIL."
        Write-ErrorLog $Error[0].Exception
    }
    
    Write-InfoLog ("End CIL compile : {0}" -f (Get-Date)) 	
}

function Update-CompilerInfo
{
    Write-InfoLog ("Starting update compiler info : {0}" -f (Get-Date)) 
    try
    {
        #Compiler settings
        $query = "select COMPILERWARNINGLEVEL,DEBUGINFO,id from {0}..USERINFO where NETWORKALIAS = '{1}'" -f $sqlDatabase,$env:USERNAME
        $table = Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
        if($table -ne $null)
        {
            foreach($row in $table)  
            {
                $COMPILERWARNINGLEVEL = $row.get_Item('COMPILERWARNINGLEVEL')
                $DEBUGINFO            = $row.get_Item('DEBUGINFO')
                $AxId                 = $row.get_Item('ID')
            }
            if  (($COMPILERWARNINGLEVEL -ne 4) -or ($DEBUGINFO -ne 524))
            {
                $query = "update {0}..USERINFO set COMPILERWARNINGLEVEL=4, DEBUGINFO=524 where NETWORKALIAS = '{1}'" -f $sqlDatabase,$env:USERNAME
                Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
            }
        }
        if ($AxId -ne $null)
        {
            #Best Practise settings
            $query = "select LAYERSETTING,WARNINGLEVEL from {0}..SYSBPPARAMETERS where USERID = '{1}'" -f $sqlDatabase,$AxId
            $table = Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
            if($table -ne $null)
            {
                foreach($row in $table)  
                {
                    $LayerSetting = $row.get_Item('LAYERSETTING')
                    $WARNINGLEVEL = $row.get_Item('WARNINGLEVEL')
                }
                if (($LayerSetting -ne 1) -or ($WARNINGLEVEL -ne 0))
                {
                    $query = "update {0}..SYSBPPARAMETERS set LAYERSETTING=1, WARNINGLEVEL=0 where USERID = '{1}'" -f $sqlDatabase,$AxId
                    Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
                }
            }
        }
    }
    catch{
       Write-TerminatingErrorLog  "Exception in Update-CompilerInfo" $Error[0]
    }    
    
    Write-InfoLog ("Done update compiler info : {0}" -f (Get-Date))
}

function Check-CILErrors
{
    Write-InfoLog ("Begin Check-CILErrors: {0}" -f (Get-Date))

    $xpplPath = join-path $serverBinDir XppIL
    if (((Test-path ($xpplPath)) -eq $True) -and ((Test-path (join-path $xpplPath Dynamics.Ax.Application.dll.log)) -eq $True))
    {
        foreach ($line in (Get-Content (join-path $xpplPath Dynamics.Ax.Application.dll.log)))
		{
            if($line -ne $null -and $line.Trim() -ne '')
            {
                if($lastLine -ne $null)
                {
                    $secondLastLine = $lastLine
                    $lastLine = $line
                }
                else
                {
                    $lastLine = $line
                }
            }
        }
        
        if($secondLastLine -ne $null) 
        {
            if($secondLastLine.Contains('Errors:') -and $secondLastLine.Split(':')[0].Trim() -eq 'Errors' -and $secondLastLine.Split(':')[1].Trim() -ne 0)
            { 
                Write-ErrorLog "IL Compile errors. See Dynamics.Ax.Application.dll.log file."}
        }
        
        if($lastLine -ne $null) 
        {
            if($lastLine.Contains('Warnings:') -and $lastLine.Split(':')[0].Trim() -eq 'Warnings' -and $lastLine.Split(':')[1].Trim() -ne 0)
            { Write-Warning "Warnings while compiling IL."}
        }
    }
    
    Write-InfoLog ("End Check-CILErrors: {0}" -f (Get-Date))
}
    
function Check-CompilerErrors
{
    Write-InfoLog ("Begin Check-CompilerErrors: {0}" -f (Get-Date))
    $compileErrors = $false
 	if ((test-Path (join-path $clientLogDir "AxCompileAll.html")) -eq $true)
	{
		foreach ($line in (Get-Content (join-path $clientLogDir "AxCompileAll.html")))
		{
			if (($XMLstarted -eq $true) -and ($line.Contains('</XML>')))
			{
				$XMLstarted = $false
				$xmlContent += $line.Replace('</XML>','')
			}
			if ($XMLstarted -eq $true) {$xmlContent += $line}
			if ($line -eq '<XML ID="compilerinfo">') {$XMLstarted = $true}
		}	
		[xml]$AxXml = $xmlcontent
		foreach($record in $axXml.AxaptaCompilerOutput.Record)
		{
			if ($record -ne $null -and (($record.field[7]).get_InnerText()) -eq "0") 
			{
                $compileErrors = $true
				$line = "Compiler ERROR: {0}\{1} : {2}" -f ($record.field[0]).get_InnerText(),($record.field[6]).get_InnerText(),($record.field[10]).get_InnerText()		
				Write-ErrorLog($line)
			}
		}		
	}
    
    if ($compileErrors -eq $true)
    {
        Write-ErrorLog "Errors while compiling code."
    }
        
    Write-InfoLog ("End Check-CompilerErrors: {0}" -f (Get-Date))		
}

function Compile-VSComponents
{
	Write-InfoLog ("BEGIN: Compile-VSComponents: {0}" -f (Get-Date)) 
    if($modelLayerMap -ne $null)
    {        
        foreach($m in ($modelLayerMap.GetEnumerator()))
        {
            if($m -ne $null)
            {
                foreach($file in $m.Value)
                {
                    $fileInfo = Get-Item -Path $file
                    if($fileInfo -ne $null)
                    {
                        if($fileInfo.Name -eq 'Model.xml')
                        {
                            Compile-VisualStudioProjects ($fileInfo)
                        }
                    }
                }
            }
        }
    }
    
	Write-InfoLog ("END: Compile-VSComponents: {0}" -f (Get-Date)) 
}

function Compile-VisualStudioProjects([System.IO.FileSystemInfo]$model)
{
    Write-InfoLog ("Begin: Compile-VisualStudioProjects: {0}" -f (Get-Date)) 
    $manifest = new-object "System.Xml.XmlDocument"
    $manifest.Load($model.FullName)
    [String]$modelName=$manifest.SelectSingleNode("//Name").get_InnerText()
    $publisher=$manifest.SelectSingleNode("//Publisher").get_InnerText()
    $axLayer= $manifest.SelectSingleNode("//Layer").get_InnerText()
    
    $aolCode = Get-AolCode $axlayer
    $aolParm = ''
    if ($aolCode -ne '') {$aolParm = '/p:axAolCode={0}' -f $aolCode}
    $projPath = (join-path $AxBuildDir 'CompileVSProjects.proj')
    $logFile = join-path $currentLogFolder ('VSCompile.{0}.log' -f $modelName)
    $errlogFile = join-path $currentLogFolder ('VSCompileError.{0}.err' -f $modelName)
    $wrnlogFile = join-path $currentLogFolder ('VSCompileWarning.{0}.wrn' -f $modelName)
    
    $arguments =  '{0} /p:srcFolder="{1}" /p:axLayer={2} {3} /p:ModelName="{4}" /p:Configuration=Release /l:FileLogger,Microsoft.Build.Engine;logfile="{5}" /p:ModelPublisher="{6}" /flp1:errorsonly;logfile="{7}" /flp2:WarningsOnly;logfile="{8}" /p:RDLParameterLanguage="{9}"' -f $projPath, $Model.Directory.FullName,$axLayer,$aolParm,$modelName,$logFile, $publisher,$errlogFile, $wrnlogFile,$rdlLanguage
    Write-InfoLog 'Msbuild arguments'
    Write-InfoLog $arguments
    $axProcess = Start-Process "msbuild.exe" -WorkingDirectory $msBuildPath -PassThru -WindowStyle minimized -ArgumentList $arguments -Verbose
    if ($axProcess.WaitForExit(60000*$CompileCILTimeout) -eq $false)
    {
        $axProcess.Kill()
        Throw ("Error: Visual studio project didn't compile in {0} min." -f $CompileCILTimeout)
    }

    $retError = $true
    if((test-path $logfile) -eq $true)
    {
        $fileContent = Get-Content $logFile -ErrorAction SilentlyContinue
        $lineNum = 0
        foreach ($line in $fileContent)
        {
            $err = $line.Contains('0 Error(s)')
            if($err -eq $true)
            {
                $retError = $false
            }
        }
    }
    
    if((test-path $errlogFile) -eq $true)
    {
        $fileContent = Get-Content $errlogFile -ErrorAction SilentlyContinue
        if($errlogFile -eq $null -or $errlogFile.Trim() -eq '')
        {
            $retError = $false        
        }
    }
    
    if($retError -eq $true)
    {
        Write-TerminatingErrorLog('Failed to compile VS project for model {0}' -f $modelName)
    }
}

###############################################################################################
#END COMPILE-AX
###############################################################################################

###############################################################################################
#COMBINE AND EXPORT-AX
###############################################################################################

#Read the VCSDEF.xml file with the AX TFS setup.
function Get-ModelsToBuild
{
    #Write-InfoLog ("Start getting models to build: {0}" -f (Get-Date)) 
    $Definition = new-object "System.Xml.XmlDocument"
    $Definition.Load($LocalProject)
    $Definition.SelectSingleNode("//VCSParameters").SelectSingleNode("//Models")
}

function Get-AolCode([string]$Layer)
{
    $aolCode = ''
    foreach ($fileName in Get-ChildItem $AxBuildDir -Filter 'aolcodes.*' ) 
    {
        $fileContent = Get-Content $fileName.fullName
        foreach ($line in $fileContent)
        {
            $line = $line.Trim().Split(':')
            if ($line[0].length -ge 2)
            {
                if ($Layer.SubString(0,2).ToUpper() -eq $line[0].SubString(0,2).ToUpper())
                {
                    $aolCode = $line[1]
                }                   
            }           
        }
    }       
    $aolCode
}

function Get-Model([System.IO.FileSystemInfo]$model)
{
    Write-InfoLog ("Begin Get-Model: {0}" -f (Get-Date))		
    Write-InfoLog ("Model: {0}" -f $model.FullName)		
    $manifest = new-object "System.Xml.XmlDocument"
    $manifest.Load($model.FullName)
    [String]$ModelLayer         = $manifest.SelectSingleNode("//Layer").get_InnerText()
    [String]$script:ModelName   = $manifest.SelectSingleNode("//Name").get_InnerText()
    [String]$ModelVssersion       = $manifest.SelectSingleNode("//Version").get_InnerText()
	$script:AolCode = Get-AolCode $ModelLayer
    $script:AxLayer = $ModelLayer
    $script:ModelVersion = $ModelVssersion
    Write-InfoLog ("End Get-Model: {0}" -f (Get-Date))		
}

function Combine-Xpos([System.IO.FileSystemInfo]$modelPath)
{
    Write-InfoLog ("Begin: Combine-Xpos: {0}" -f (Get-Date))  
    Start-Sleep 2
    $arguments = ' -XpoDir "{0}" -Verbose -CombinedXpoFile "{1}" -utf8' -f $modelPath,(Join-Path $currentLogFolder ("Combined.{0}.xpo" -f $modelName))
    $cmdName = Join-Path $AxBuildDir 'combinexpos.exe'
    $logfile = Join-Path $CurrentLogFolder ('Combined.{0}.log' -f $modelName)
    Write-InfoLog ("Calling Start-Process: {0}" -f (Get-Date)) 
    $result = Start-Process $cmdName -WorkingDirectory $axbuildDir -PassThru -ArgumentList $arguments -RedirectStandardOutput $logFile
    Write-InfoLog $result
    if ($result.WaitForExit(60000*$CombineTimeout) -eq $false)
    {
        $axProcess.Kill()
        Throw ("Combine XPO for {0} didn't complete after {1} minutes." -f $modelName, $CombineTimeout)			
    }
    
    Write-InfoLog ("End: Combine-Xpos: {0}" -f (Get-Date))  
}

function Check-CombineXpoError
{    
    $logfile = Join-Path $CurrentLogFolder ('Combined.{0}.log' -f $modelName)
    $fileContent = Get-Content $logFile -ErrorAction SilentlyContinue
    $lineNum = 0
    foreach ($line in $fileContent)
    {
        $lineNum++
        if (($lineNum -gt 1) -and ($line -eq 'Ok')) {$importOk = $true}         
    }
    $importOk
}

###############################################################################################
#END COMBINE AND EXPORT-AX
###############################################################################################

function Create-AXModel($AxModelManifest)
{
    Write-InfoLog ("Begin: Create-AXModel: {0}" -f (Get-Date))  

    Write-InfoLog ("Calling Set-AXModelStore: {0}" -f (Get-Date)) 
    $Result = Set-AXModelStore -NoInstallMode -Server $sqlServer -Database $sqlDatabase -Verbose
    
    Write-InfoLog ("Calling New-AXModel: {0}" -f (Get-Date)) 
    $Result = New-AXModel -ManifestFile $AxModelManifest -Server $sqlServer -Database $sqlDatabase -OutVariable out
    Write-InfoLog $out
    Write-InfoLog ("End: Create-AXModel: {0}" -f (Get-Date))  
}

function Put-BuildNumber($AxModelManifest)
{
    Write-InfoLog ("Begin: Put-BuildNumber: {0}" -f (Get-Date))  
    #update the build number in the model.xml file
    $manifest = new-object "System.Xml.XmlDocument"
    $manifest.Load($AxModelManifest)
    
    Write-InfoLog ("Calling Edit-AXModelManifest: {0}" -f (Get-Date)) 
    $Result = Edit-AXModelManifest -ManifestFile $AxModelManifest -ManifestProperty ('Version={0}' -f $ModelVersion) -Server $sqlServer -Database $sqlDatabase -OutVariable out
    Write-InfoLog $out
    
    Write-InfoLog ("End: Put-BuildNumber: {0}" -f (Get-Date))  
}

function Install-DependentBinaries
{
    Write-InfoLog ("Start Install-DependentBinaries: {0}" -f (Get-Date)) 
    if ($dependencyPath -ne $null -and (Test-Path $dependencyPath) -eq $True)
    {
        $Path = Join-Path $dependencyPath "Bin"
        if((Test-Path $Path) -eq $True)
        {
            foreach ($file in (Get-ChildItem -Path $Path -Recurse -ErrorAction Stop))
            {
                if ($file.PSIsContainer -eq $False)
                {
                    Copy-Item -Path (Join-Path $file.directory $file.Name) -Destination $serverBinDir -Force 
                    Copy-Item -Path (Join-Path $file.directory $file.Name) -Destination $clientBinDir -Force 
                }   
            }
        }       
    }
    Write-InfoLog ("End Install-DependentBinaries: {0}" -f (Get-Date)) 
}       

function Import-AxCode([System.IO.FileSystemInfo]$model)
{
    Delete-Axmodel $model.FullName
    Write-InfoLog ("Import {0} Starting : {1}" -f $model.FullName,(Get-Date)) 
    Create-AXModel $model.FullName
    #Import the combined XPO into AX
    Get-Model $model
    
    Put-BuildNumber $model.FullName
    
    Write-InfoLog ("Import combined xpo for model {0}: {1}" -f $modelName,(Get-Date))
    $aolParm = ''
    if ($aolCode -ne '') {$aolParm = '-aolCode={0}' -f $aolCode}
    
    $xpoName = ("Combined.{0}.xpo" -f $modelName)
    $arguments = '-aol={0} {1} "-aotimportfile={2}\{4}" -lazyclassloading -lazytableloading -nocompileonimport -internal=noModalBoxes "-model=@{3}"' -f $axLayer,$aolParm,$currentLogFolder,$Model.FullName, $xpoName
    $axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments -Verbose
    if ($axProcess.WaitForExit(60000*$ImportTimeout) -eq $false)
    {
        $axProcess.Kill()
        Throw ("Error: AX .XPO import did not complete within {0} minutes" -f $ImportTimeout)
    }
    
    Write-InfoLog ("Done Import combined xpo for model {0}: {1}" -f $modelName,(Get-Date))
    
    Write-InfoLog ("Import {0} Lables   : {1}" -f $modelName,(Get-Date))
    $AxModelLabelsFolder = Join-Path $Model.Directory $labelsFolder
    foreach ($file in (Get-ChildItem -Path $AxModelLabelsFolder -Filter "*.ald" -Recurse -ErrorAction SilentlyContinue))
    {
		Write-InfoLog "Label file to import is " $file.FullName " into " $ModelName
        $arguments = '-aol={0} {1} "-startupcmd=aldimport_{2}" "-model=@{3}"' -f $axLayer,$aolParm,$file.FullName,$Model.FullName
        $axProcess = Start-Process $ax32 -WorkingDirectory $clientBinDir -PassThru -WindowStyle minimized -ArgumentList $arguments -Verbose
        if ($axProcess.WaitForExit(60000*$ImportTimeout) -eq $false)
        {
            $axProcess.Kill()
            Throw ("Error: AX label import did not complete within {0} minutes" -f $ImportTimeout)
        }
    }
    
    Build-VisualStudioProjects ($model)
    Write-InfoLog ("Import {0} finished : {1}" -f $modelName,(Get-Date)) 
}   

function Build-VisualStudioProjects([System.IO.FileSystemInfo]$model)
{
    Write-InfoLog ("Begin: Importing Visual Studio Project : {0}" -f (Get-Date)) 
    $manifest = new-object "System.Xml.XmlDocument"
    $manifest.Load($model.FullName)
    [String]$modelName=$manifest.SelectSingleNode("//Name").get_InnerText()
    $publisher=$manifest.SelectSingleNode("//Publisher").get_InnerText()

    $aolParm = ''
    if ($aolCode -ne '') {$aolParm = '/p:axAolCode={0}' -f $aolCode}
    $projPath = (join-path $AxBuildDir 'ImportVSProjects.proj')
    $logFile = join-path $currentLogFolder ('VSImport.{0}.log' -f $modelName)
    $errlogFile = join-path $currentLogFolder ('VSImportError.{0}.err' -f $modelName)
    $wrnlogFile = join-path $currentLogFolder ('VSImportWarning.{0}.wrn' -f $modelName)

    $arguments =  '{0} /p:srcFolder="{1}" /p:axLayer={2} {3} /p:ModelName="{4}" /p:Configuration=Release /l:FileLogger,Microsoft.Build.Engine;logfile="{5}" /p:ModelPublisher="{6}" /flp1:errorsonly;logfile="{7}" /flp2:WarningsOnly;logfile="{8}"' -f $projPath, $Model.Directory.FullName,$axLayer,$aolParm,$modelName,$logFile, $publisher,$errlogFile, $wrnlogFile
    $msBuild = "'{0}\msbuild.exe'" -f $msBuildPath
    Write-InfoLog 'Msbuild arguments'
    Write-InfoLog $arguments
    $axProcess = Start-Process "msbuild.exe" -WorkingDirectory $msBuildPath -PassThru -WindowStyle minimized -ArgumentList $arguments -Verbose
    if ($axProcess.WaitForExit(60000*$ImportTimeout) -eq $false)
    {
        $axProcess.Kill()
        Throw ("Error: Visual studio project didn't import in {0} min." -f $ImportTimeout)
    }

    $retError = $true
    if((test-path $logfile) -eq $true)
    {
        $fileContent = Get-Content $logFile -ErrorAction SilentlyContinue
        $lineNum = 0
        foreach ($line in $fileContent)
        {
            $err = $line.Contains('0 Error(s)')
            if($err -eq $true)
            {
                $retError = $false
            }
        }
    }

    if((test-path $errlogFile) -eq $true)
    {
        $fileContent = Get-Content $errlogFile -ErrorAction SilentlyContinue
        if($errlogFile -eq $null -or $errlogFile.Trim() -eq '')
        {
            $retError = $false        
        }
    }
    
    if($retError -eq $true)
    {
        Write-TerminatingErrorLog('Failed to import VS project for model {0}' -f $modelName)
    }
}

function Create-ModelList
{
    Write-InfoLog ("Begin: Create-ModelList: {0}" -f (Get-Date))  

    $modelList = @()
    foreach($m in ($modelLayerMap.GetEnumerator()))
    {
        if($m -ne $null)
        {
            foreach($file in $m.Value)
            {
                $fileInfo = Get-Item -Path $file
                if($fileInfo -ne $null)
                {
                    if($fileInfo.Extension -eq '.axmodel')
                    {
                        $modelList += ($fileInfo.Name) +[char]10
                    }
                    elseif($fileInfo.Name -eq 'Model.xml')
                    {
                        $manifest = new-object "System.Xml.XmlDocument"
                        $manifest.Load($fileInfo.FullName)
                        [String]$modelName=$manifest.SelectSingleNode("//Name").get_InnerText()
                        $modelList += ('{0}.axmodel' -f $modelName) +[char]10
                    }
                }
            }
        }
    }

    $modelList | Out-File (join-path (Join-Path $dropLocation "Application\Appl\") "ModelList.txt") -Encoding Default
    Write-InfoLog $modelList
}

function Install-Model($folder, $file)
{
    Write-InfoLog ("Begin Install-Model: {0}" -f (Get-Date))
    Write-InfoLog ("Model file:")
    Write-InfoLog ($file)
    Write-InfoLog (" ")

    if($file -ne $null -and $folder -ne $null)
    {
        $extraArguments = ''
        if($importOverrideParams -ne $null)
        {
            if($importOverrideParams.Contains($file))
            {
                $extraArguments = $importOverrideParams.Get_Item($file)    
            }        
        }
        $file = join-path $folder $file
        if((test-path $file) -eq $true)   
        { 
            Write-InfoLog ("Calling Install-AXModel: {0}" -f (Get-Date))
            $exp = 'Install-AXModel {0} -File "{1}" -Details -NoPrompt -Server "{2}" -Database "{3}" -OutVariable out -Verbose' -f $extraArguments, $file, $sqlServer, $sqlDatabase
            Write-InfoLog $exp
            Invoke-Expression $exp 
            Write-InfoLog $out
        }
    }
    
    Write-InfoLog ("End Install-Model: {0}" -f (Get-Date))
}

function Load-Models($folder, $list)
{
	Write-InfoLog ("Begin: Load-Models : {0}" -f (Get-Date)) 

    $modelList = (Join-Path $folder $list)
    if ((Test-Path $modelList) -ne $false)
    {
        $fileContent = Get-Content $modelList
        foreach ($line in $fileContent)
        {
            if(($line -ne $null) -and ($line.Trim() -ne ''))
            {
                Install-Model $folder $line.Trim()
            }
        }       
    }   
    else
    {
        foreach ($file in (Get-ChildItem -Path $folder -Filter "*.axmodel" -ErrorAction SilentlyContinue))
        {
            Install-Model $folder $file.Name
        }
    }
	Write-InfoLog ("End: Load-Models : {0}" -f (Get-Date)) 
}

function Read-ModelList($folder)
{
    $models = @()

    $modelList = (Join-Path $folder ModelList.txt)
    if ((Test-Path $modelList) -ne $false)
    {
        $fileContent = Get-Content $modelList
        foreach ($line in $fileContent)
        {
            if(($line -ne $null) -and ($line.Trim() -ne ''))
            {
                $models += $line.Trim()
            }
        }       
    }   
    else
    {
        foreach ($file in (Get-ChildItem -Path $folder -Filter "*.axmodel" -ErrorAction SilentlyContinue))
        {
            $models += $file.Name
        }
    }

    return $models
}

function Create-ModelMap
{    
    if($dependencyPath -ne $null -and ((Test-path (join-path $dependencyPath 'appl')) -eq $true))
    {
        Set-ModelLayerOrder (join-path $dependencyPath 'appl')
    }
}

function Set-ModelLayerOrder($folder)
{
    Write-InfoLog ("Begin: Set-ModelLayerOrder: {0}" -f (Get-Date)) 

    $models = Read-ModelList ($folder)
    if($models -ne $null)
    {
        foreach($model in $models)
        {
            Write-InfoLog ("Calling Get-AXModelManifest: {0}" -f (Get-Date)) 
            $modelManifest = Get-AXModelManifest -file (join-path $folder $model) -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
            Write-InfoLog $out
            if($modelManifest -ne $null)
            {
                Add-LayerOrder (join-path $folder $model) $modelManifest.Layer
            }
        }
    }
    
    Write-InfoLog ("Begin: Set-ModelLayerOrder: {0}" -f (Get-Date)) 
}

function Get-LayerId([string]$layerName)
{    
    $query = "SELECT ID FROM {0}..Layer where Name = '{1}'" -f $sqlDatabase,$layerName
	
    $table = Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
    foreach($row in $table)  
    {
        $layerId = $row.get_Item('ID')
    }
	
    if ($layerId -ge $higestLayer) 
    {
        $script:higestLayer = $layerId
        $script:compileInLayer = $layerName
    }

    $layerId
}   

function Add-LayerOrder($name, $modelLayer)
{
    $layerId = Get-LayerId($modelLayer)
    if($layerId -ne $null)
    {
        if($modelLayerMap.ContainsKey($layerId))
        {
            $list = $modelLayerMap.Get_Item($layerId)
            $list += $name
            $modelLayerMap.Set_Item($layerId, $list)
        }
        else
        {
            $list = @()
            $list += $name
            $modelLayerMap.Add($layerId, $list) 
        }
    }
}

function Import-BuildModels
{
	Write-InfoLog ("BEGIN: Import-BuildModels: {0}" -f (Get-Date)) 
    if($modelLayerMap -ne $null)
    {        
        foreach($m in ($modelLayerMap.GetEnumerator()))
        {
            if($m -ne $null)
            {
                foreach($file in $m.Value)
                {
                    $fileInfo = Get-Item -Path $file
                    if($fileInfo -ne $null)
                    {
                        if($fileInfo.Extension -eq '.axmodel')
                        {
                            Install-Model $fileInfo.Directory.FullName $fileInfo.Name
                        }
                        elseif($fileInfo.Name -eq 'Model.xml')
                        {
                            Import-AxCode $fileInfo
                        }
                    }
                }
            }
        }
    }
    
	Write-InfoLog ("END: Import-BuildModels: {0}" -f (Get-Date)) 
}

############################################################################################
#Collect-Build
############################################################################################
function Collect-Build([System.Array]$models)
{
    Write-InfoLog (" ") 
    Write-InfoLog ("*****************************************************************") 
    Write-InfoLog ("****************COMPILE AX***************************************") 
	Write-InfoLog ("Begin: Collect-Build : {0}" -f (Get-Date)) 
    Write-InfoLog (" ") 
    Write-InfoLog (" ") 

    Start-AOS
    Write-InfoLog (" ") 
    Write-InfoLog (" ") 

    Write-InfoLog ("Collecting model files: {0}" -f (Get-Date)) 
    Write-InfoLog (" ") 

    if($models -ne $null)
    {
        foreach ($model in $models)
        {   
            $manifest = new-object "System.Xml.XmlDocument"
            $manifest.Load($model.FullName)
            [String]$modelName=$manifest.SelectSingleNode("//Name").get_InnerText()
            $modelFile = Join-Path (join-Path $dropLocation "Application\Appl\") ('{0}.axmodel' -f $modelName)
            Remove-Item $modelFile -ErrorAction SilentlyContinue
            if($signkey -ne $null)
            {
                Write-InfoLog ("Calling Export-AXModel: {0}" -f (Get-Date)) 
                $result = Export-AXModel -Model $modelName -Key $signkey -File $modelFile -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
                Write-InfoLog $out
            }
            else
            {
                Write-InfoLog ("Calling Export-AXModel: {0}" -f (Get-Date)) 
                $result = Export-AXModel -Model $modelName -File $modelFile -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
                Write-InfoLog $out
            }
        }
    }
    
    if($dependencyPath -ne $null)
    {
        Write-InfoLog ("Collecting dependent model files: {0}" -f (Get-Date)) 
        Write-InfoLog (" ") 

        $Path = Join-Path $dependencyPath "Appl"
        if( (Test-path $Path) -eq $true)
        {
            foreach ($file in (Get-ChildItem -Path $Path -Filter "*.axmodel" -ErrorAction SilentlyContinue))
            {
                Copy-Item -Path (Join-Path $file.directory $file.Name) -Destination (Join-Path $dropLocation "Application\Appl") -Force 
            }
        }
    }       

    if($dependencyPath -ne $null)
    {
        Write-InfoLog ("Collecting binaries: {0}" -f (Get-Date)) 
        Write-InfoLog (" ") 
        $Path = Join-Path $dependencyPath "Bin"
        if( (Test-path $Path) -eq $true)
        {
            foreach ($file in (Get-ChildItem -Path $Path -ErrorAction SilentlyContinue))
            {
                if ($file.PSIsContainer -eq $False)
                {
                    Copy-Item -Path (Join-Path $file.directory $file.Name) -Destination (Join-Path $dropLocation "Application\bin") -Force 
                }   
            }
        }   
    }
        
    Write-InfoLog ("Completed: Collect-Build : {0}" -f (Get-Date)) 
}
############################################################################################
#END Collect-Build
############################################################################################

############################################################################################
#Clean-Build
############################################################################################

function Clean-Build
{
	Write-InfoLog ("Begin: Clean-Build : {0}" -f (Get-Date)) 

	Write-InfoLog ("Deleting models : {0}" -f (Get-Date)) 
    if($scriptName -eq 'DEPLOY')
    {
        Clean-Models 
    }
    else
    {
        Clean-BuildModels
    }
    
    Write-InfoLog ("Models deleted : {0}" -f (Get-Date)) 

    Clean-DependentBinaries
    
    Write-InfoLog ("Calling Set-AXModelStore: {0}" -f (Get-Date)) 
    Set-AXModelStore -NoInstallMode -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
    Write-InfoLog $out
    Stop-AOS
    Start-AOS
    Synchronize-AX
	Write-InfoLog ("Completed: Clean-Build : {0}" -f (Get-Date)) 
}

function Clean-BuildModels
{
	Write-InfoLog ("BEGIN: Clean-BuildModels: {0}" -f (Get-Date)) 
    if($modelLayerMap -ne $null)
    {      
        $modelLayerMap = $modelLayerMap.GetEnumerator() | Sort-Object Name -descending
        if($modelLayerMap -eq $null)
        {
            $modelLayerMap = @{}
        }
        if($modelLayerMap.GetType().Name -eq 'DictionaryEntry')
        {
            $modelLayerMap = @{ $modelLayerMap.Name = $modelLayerMap.Value}
        }
  
        foreach($m in ($modelLayerMap.GetEnumerator()))
        {
            if($m -ne $null)
            {
                foreach($file in $m.Value)
                {
                    $fileInfo = Get-Item -Path $file
                    if($fileInfo -ne $null)
                    {
                        if($fileInfo.Extension -eq '.axmodel')
                        {
                            Delete-ModelByFileName $fileInfo.FullName
                        }
                        elseif($fileInfo.Name -eq 'Model.xml')
                        {
                            Delete-AXModel $fileInfo.FullName
                        }
                    }
                }
            }
        }
    }
    
	Write-InfoLog ("END: Clean-BuildModels: {0}" -f (Get-Date)) 
}

function Clean-Models
{
	Write-InfoLog ("Begin: Clean-Models : {0}" -f (Get-Date)) 
    $folder = (join-Path $dropLocation "Application\Appl\")
    $modelList = (Join-Path $folder 'ModelList.txt')
    if ((Test-Path $modelList) -ne $false)
    {
        Write-InfoLog ("Getting models from modellist.txt: {0}" -f $modelList) 
        $models = @()
        $fileContent = Get-Content $modelList
        foreach ($line in $fileContent)
        {
            if(($line -ne $null) -and ($line.Trim() -ne ''))
            {
                $models += $line.Trim()
            }
        }
        
        for ($idx = $models.Length - 1; $idx -ge 0;$idx--)
        {   
            $modelFile = (join-path $folder $models.Get($idx))
            Delete-ModelByFileName $modelFile
        }                        
    }   
    else
    {
        Write-Warning "Running clean models without sequence might cause issues."
        foreach ($file in (Get-ChildItem -Path $folder -Filter "*.axmodel" -ErrorAction SilentlyContinue))
        {
            Delete-ModelByFileName $file.FullName
        }
    }
	Write-InfoLog ("End: Clean-Models : {0}" -f (Get-Date)) 
}

function Delete-ModelByFileName($model)
{
    Write-InfoLog ("Begin: Delete-ModelByFileName : {0}" -f (Get-Date)) 
    
    Write-InfoLog ("Calling Get-AXModelManifest: {0}" -f (Get-Date)) 
    if((test-path $model) -eq $true)
    {
        $modelManifest = Get-AXModelManifest -file $model -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
        Write-InfoLog $out
        if($modelManifest -ne $null)
        {
            try{
            Write-InfoLog ("Calling Uninstall-AXModel: {0}" -f (Get-Date))
            $Result = Uninstall-AXModel -Model $modelManifest.Name -Details -NoPrompt -Server $sqlServer -Database $sqlDatabase -OutVariable out -Verbose
            Write-InfoLog $out
            }
            catch
            {
                Write-InfoLog "Uninstall-AXModel Failed."
                Write-InfoLog $Error[0]
            }
        }
    }

    Write-InfoLog ("End: Delete-ModelByFileName : {0}" -f (Get-Date)) 
}

function Delete-AXModel($model)
{
    Write-InfoLog ("Begin: Delete-AXModel : {0}" -f (Get-Date)) 
    $manifest = new-object "System.Xml.XmlDocument"
    $manifest.Load($Model)
    [String]$ModelName=$manifest.SelectSingleNode("//Name").get_InnerText()

    $modelData = Get-AXModel -Model $ModelName -Server $sqlServer -Database $sqlDatabase
    if($modelData -ne $null)
    {
        $Result = Uninstall-AXModel -Model $ModelName -NoPrompt -Server $sqlServer -Database $sqlDatabase
    }
    Write-InfoLog ("Completed: Delete-AXModel : {0}" -f (Get-Date)) 
}

function Clean-DependentBinaries
{
    Stop-AOS
	Write-InfoLog ("Deleting dependent binaries : {0}" -f (Get-Date)) 
    if($dependencyPath -ne $null -and ((test-path $dependencyPath) -eq $true))
    {
        $Path = Join-Path $dependencyPath "Bin"
        if( (Test-path $Path) -eq $true)
        {
            foreach ($file in (Get-ChildItem -Path $Path -ErrorAction SilentlyContinue))
            {
                Remove-item (Join-Path $serverBinDir $file.Name) -Force -ErrorAction SilentlyContinue 
                Remove-item (Join-Path $clientBinDir $file.Name) -Force -ErrorAction SilentlyContinue 
            }
        }     
    }
    Start-AOS
	Write-InfoLog ("Dependent binaries deleted: {0}" -f (Get-Date)) 
}

############################################################################################
#END Clean-Build
############################################################################################

############################################################################################
#TFS
############################################################################################
function GET-TFS (
    [string] $serverName = $(Throw 'serverName is required')
)
{
    # load the required dll
    [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client")

    $propertiesToAdd = (
        ('VCL', 'Microsoft.TeamFoundation.VersionControl.Client', 'Microsoft.TeamFoundation.VersionControl.Client.VersionControlLabel'),
        ('VCS', 'Microsoft.TeamFoundation.VersionControl.Client', 'Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer')
    )

    [psobject] $tfs = [Microsoft.TeamFoundation.Client.TeamFoundationServerFactory]::GetServer($serverName)
       foreach ($entry in $propertiesToAdd) {
        $scriptBlock = '
            [System.Reflection.Assembly]::LoadWithPartialName("{0}") > $null
            $this.GetService([{1}])
        ' -f $entry[1],$entry[2]
        $tfs | add-member scriptproperty $entry[0] $ExecutionContext.InvokeCommand.NewScriptBlock($scriptBlock)
        }
    return $tfs
}

function Apply-Label
{
    Write-InfoLog ("Creating label : {0}" -f (Get-Date)) 

    $tfs = GET-TFS $tfsUrl
    $labelName = ($tfsLabelPrefix) -f $currentVersion
    $comments = $labelComments -f $currentVersion
    $label = new-object Microsoft.TeamFoundation.VersionControl.Client.VersionControlLabel  ($tfs.vcs, $labelName, $tfs.VCS.AuthenticatedUser, $null, $comments)
    $itemSpec = new-object Microsoft.TeamFoundation.VersionControl.Client.ItemSpec ($TFSWorkspace, 2)
    $versionSpec = [Microsoft.TeamFoundation.VersionControl.Client.VersionSpec]::Latest
    $labelItemSpec += new-object Microsoft.TeamFoundation.VersionControl.Client.LabelItemSpec ($itemSpec, $versionSpec, $false);

    # construct the label
    $xyz = $tfs.vcs.CreateLabel($label, $labelItemSpec, 1)
    Write-InfoLog ("Label Created")
    Write-InfoLog (" ")
}

function Sync-FilesToALabel
{    
    Write-InfoLog ("Sync files {0}" -f (get-date)) 
    [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client")

    $tfs = GET-TFS $tfsUrl
    if($tfsLabel -ne $null)
    {
        $labelSpec = new-object Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec ($tfslabel)
    }
    else
    {
        $labelSpec = [Microsoft.TeamFoundation.VersionControl.Client.VersionSpec]::Latest
    }
    
    $script:w = $tfs.VCS.GetWorkspace($ApplicationSourceDir)
    
    try
    {
        Write-InfoLog ("Sync files started") 
        $g = $w.Get($labelSpec, 1)
       
        Write-InfoLog ("Sync files done") 
        Write-InfoLog (" ")
    }
    catch
    {
        Write-TerminatingErrorLog "Exception while mapping TFS workspace." $Error[0]
    }
    
    Write-InfoLog ("End Sync files {0}" -f (get-date))     
}

function Sync-Files
{    
    Write-InfoLog ("Sync files {0}" -f (get-date)) 

    $tfs = GET-TFS $tfsUrl

    $guid = [Guid]::NewGuid().ToString()
    $wName = 'AXBuild_' + $guid
    Write-InfoLog ("Creating workspace {0}" -f $wName) 
    $labelName = ($tfsLabelPrefix) -f $currentVersion
    $label = new-object Microsoft.TeamFoundation.VersionControl.Client.VersionControlLabel  ($tfs.vcs, $labelName, $tfs.VCS.AuthenticatedUser, $null, $labelComments)
    $itemSpec = new-object Microsoft.TeamFoundation.VersionControl.Client.ItemSpec ($TFSWorkspace, 2)
    $versionSpec = [Microsoft.TeamFoundation.VersionControl.Client.VersionSpec]::Latest
    
    $script:w = $tfs.VCS.CreateWorkspace($wName, $tfs.VCS.AuthenticatedUser)
    try
    {
        $w.Map($tfsWorkspace, $ApplicationSourceDir)    
        
        Write-InfoLog ("Sync files started") 
        $g = $w.Get($versionSpec, 1)
       
        Write-InfoLog ("Sync files done") 
        Write-InfoLog (" ")
    }
    catch
    {
        Write-TerminatingErrorLog "Exception while mapping TFS workspace." $Error[0]
    }
    
    Write-InfoLog ("End Sync files {0}" -f (get-date))     
}

function Enable-VCS
{
    Write-InfoLog ("Starting Enable-VCS: {0}" -f (Get-Date)) 
    try
    {
        if($vcsDisabled -eq $true)
        {
            $query = "update {0}..sysversioncontrolparameters set VCSENABLED=0" -f $sqlDatabase
            Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
        }
    }
    catch{
       Write-TerminatingErrorLog  "Exception while updating version control parameters" $Error[0]
    }    
    
    Write-InfoLog ("Done Enable-VCS: {0}" -f (Get-Date))
}

function Disable-VCS
{
    Write-InfoLog ("Starting Disable-VCS: {0}" -f (Get-Date)) 
    try
    {
        #Compiler settings
        $query = "select VCSENABLED from {0}..sysversioncontrolparameters" -f $sqlDatabase
        $table = Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
        if($table -ne $null)
        {
            foreach($row in $table)  
            {
                $VCSEnabled = $row.get_Item('VCSENABLED')
            }
            if  ($VCSEnabled -eq 0)
            {
                $query = "update {0}..sysversioncontrolparameters set VCSENABLED=1" -f $sqlDatabase
                Invoke-Sqlcmd -Query "$query" -ServerInstance "$SQLserver" -Verbose
                $script:vcsDisabled = $true
            }
        }
    }
    catch{
       Write-TerminatingErrorLog  "Exception while updating version control parameters" $Error[0]
    }    
    
    Write-InfoLog ("Done Disable-VCS: {0}" -f (Get-Date))
}

############################################################################################
#END TFS
############################################################################################

Add-Type -AssemblyName system.ServiceProcess

# SIG # Begin signature block
# MIIY2gYJKoZIhvcNAQcCoIIYyzCCGMcCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUfLMncb93QquCNQbHhDAFgmej
# xGygghOsMIIEmjCCA4KgAwIBAgIKYQeDRQAAAAAAEDANBgkqhkiG9w0BAQUFADB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgVGltZXN0YW1waW5nIFBDQTAeFw0xMjAxMDkyMTUzNThaFw0xMzA0
# MDkyMTUzNThaMIGzMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIERTRSBFU046N0QyRS0z
# NzgyLUIwRjcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCqOYA2cofc4+9/ZQha5gI6
# 73Dzx2nkBahvpuBs49IQUa15z+kpSG3stuBAeo2C0OQD3BxSdymGqfEyYG3DzGMm
# a9OwuKCd1fpO8/V3tcFGbMCYlnHeI1KkD4LA7r+yiVAGNQr5VWKMFHnj+y/SqrgT
# lvsfZ6NfWJ/n8r5sdWBagJmuue/XSQ1phAvE7MsV2jtBvagRgCQO3/M1T8yDpjGx
# 2dcL+R71rtKWNtWOfo0Pax6H/sW7ozIwFcA24J5jRVyp8RUgRQgpaKFZko7zXHov
# cjiZ7O4VBRNvRsuer8Htf9VyrhN/2GP0+xSGLSAK+rl/ZdTFYFpXr/lTiX0l+N77
# AgMBAAGjgegwgeUwHQYDVR0OBBYEFOEbm/0SuFL4h+9hMzzQs+lg4x9FMB8GA1Ud
# IwQYMBaAFG/oTj+XuTSrS4aPvJzqrDtBQ8bQMEQGA1UdHwQ9MDswOaA3oDWGM2h0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL3RzcGNhLmNy
# bDBIBggrBgEFBQcBAQQ8MDowOAYIKwYBBQUHMAKGLGh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvdHNwY2EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MA0GCSqGSIb3DQEBBQUAA4IBAQB34v+FOOZIMqubtd4LRX06XFmd3bO2WIvcXQ5f
# Y7Dr2TkkCWJuxXXfLee9eg3OJAoBu7URRGMGA7tuMjbxxVPm9AWSNwB6qd4UAWUA
# REg9Dmh0/b3eZ4Eeg8e3CMJvSVrMW4ewyFGuHKjrY408yhUY3JeNdxQmi1AU7euz
# A/g5udRlXfZCqjqfZFk0k6HfRg3LmsZP284xd/RUwJKaHbG3u1oc10VM2MXEdUuX
# wylPfE5owyW3Vm4SPoAo0rNv8tntKJyap6TyNnE1tn+EInccIzXmstErW8ZKDS7R
# aZkYQU/o9ZkZ0AE/SMyDbBnomV0Jec/6+aZtfM4kZi23VRKhMIIEnTCCA4WgAwIB
# AgIQaguZT8AAJasR20UfWHpnojANBgkqhkiG9w0BAQUFADBwMSswKQYDVQQLEyJD
# b3B5cmlnaHQgKGMpIDE5OTcgTWljcm9zb2Z0IENvcnAuMR4wHAYDVQQLExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBSb290IEF1dGhv
# cml0eTAeFw0wNjA5MTYwMTA0NDdaFw0xOTA5MTUwNzAwMDBaMHkxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBU
# aW1lc3RhbXBpbmcgUENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 3Ddu+6/IQkpxGMjOSD5TwPqrFLosMrsST1LIg+0+M9lJMZIotpFk4B9QhLrCS9F/
# Bfjvdb6Lx6jVrmlwZngnZui2t++Fuc3uqv0SpAtZIikvz0DZVgQbdrVtZG1KVNvd
# 8d6/n4PHgN9/TAI3lPXAnghWHmhHzdnAdlwvfbYlBLRWW2ocY/+AfDzu1QQlTTl3
# dAddwlzYhjcsdckO6h45CXx2/p1sbnrg7D6Pl55xDl8qTxhiYDKe0oNOKyJcaEWL
# 3i+EEFCy+bUajWzuJZsT+MsQ14UO9IJ2czbGlXqizGAG7AWwhjO3+JRbhEGEWIWU
# brAfLEjMb5xD4GrofyaOawIDAQABo4IBKDCCASQwEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwgaIGA1UdAQSBmjCBl4AQW9Bw72lyniNRfhSyTY7/y6FyMHAxKzApBgNVBAsT
# IkNvcHlyaWdodCAoYykgMTk5NyBNaWNyb3NvZnQgQ29ycC4xHjAcBgNVBAsTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFJvb3QgQXV0
# aG9yaXR5gg8AwQCLPDyIEdE+9mPs30AwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0O
# BBYEFG/oTj+XuTSrS4aPvJzqrDtBQ8bQMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBBQUA
# A4IBAQCUTRExwnxQuxGOoWEHAQ6McEWN73NUvT8JBS3/uFFThRztOZG3o1YL3oy2
# OxvR+6ynybexUSEbbwhpfmsDoiJG7Wy0bXwiuEbThPOND74HijbB637pcF1Fn5LS
# zM7djsDhvyrNfOzJrjLVh7nLY8Q20Rghv3beO5qzG3OeIYjYtLQSVIz0nMJlSpoo
# Jpxgig87xxNleEi7z62DOk+wYljeMOnpOR3jifLaOYH5EyGMZIBjBgSW8poCQy97
# Roi6/wLZZflK3toDdJOzBW4MzJ3cKGF8SPEXnBEhOAIch6wGxZYyuOVAxlM9vamJ
# 3uhmN430IpaczLB3VFE61nJEsiP2MIIEqTCCA5GgAwIBAgITMwAAAIhZDjxRH+Jq
# ZwABAAAAiDANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xMjA3MjYyMDUwNDFaFw0xMzEwMjYyMDUwNDFaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCzdHTQgjyHp5rUjrIEQoCXJS7kQc6TYzZfE/K0eJiAxih+zIoT7z03
# jDsJoNgUxVxe2KkdfwHBs5gbUHfs/up8Rc9/4SEOxYTKnw9rswk4t3TEVx6+8Eio
# eVrfDpscmqi8yFK1DGmPhM5xVXv/CSC/QHc3ITB0W5Xfd8ug5cFyEgY98shVbK/B
# +2oWJ8j1s2Hj2c4bDx705M1MNGw+RxHnAitfFHoEB/XXPYvbZ31XPjXrbY0BQI0a
# h5biD3dMibo4nPuOApHbIg/l0DapuDdF0Cr8lo3BYHEzpYix9sIEMIdbw9cvsnkR
# 2ItlYqKKEWZdfn8FenOKH3qF5c0oENE9AgMBAAGjggEdMIIBGTATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUJls+W12WX+L3d4h/XkVTWKguW7gwDgYDVR0P
# AQH/BAQDAgeAMB8GA1UdIwQYMBaAFMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljQ29kU2lnUENBXzA4LTMxLTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IB
# AQAP3kBJiJHRMTejRDhpsmor1JH7aIWuWLseDI9W+pnXypcnTOiFjnlpLOS9lj/l
# cGaXlTBlKa3Gyqz1D3moZ79p9A+X4woPv+6WdimyItAzxv+LSa2usv2/JervJ1DA
# 6xn4GmRqoOEXWa/xz+yBqInosdIUBuNqbXRSZNqWlCpcaWsf7QWZGtzoZaqIGxWV
# GtOkUZb9VZX4Y42fFAyxnn9KBP/DZq0Kr66k3mP68OrDs7Lrh9vFOK22c9J4ZOrs
# IVtrO9ZEIvSBUqUrQymLDKEqcYJCy6sbftSlp6333vdGms5DOegqU+3PQOR3iEK/
# RxbgpTZq76cajTo9MwT2JSAjMIIFvDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkq
# hkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQB
# GRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkwHhcNMTAwODMxMjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNy
# b3NvZnQgQ29kZSBTaWduaW5nIFBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBALJyWVwZMGS/HZpgICBCmXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay
# 7P/ewkJOI9VyANs1VwqJyq4gSfTwaKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB
# 2/O98jakyVxF3K+tPeAoaJcap6Vyc1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpn
# Uo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ+NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049
# oDI9kM2hOAaFXE5WgigqBTK3S9dPY+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJG
# zzc8OJ60d1ylF56NyxGPVjzBrAlfA9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQF
# MAMBAf8wHQYDVR0OBBYEFMsR6MrStBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIB
# hjASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGY
# YDuoMW+mPLzYLTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAW
# gBQOrIJgQFYnl+UlE/wq4QpTlVnkpDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290
# Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDAN
# BgkqhkiG9w0BAQUFAAOCAgEAWTk+fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddD
# rQv+y+ktMaMjzHxQmIAhXaw9L0y6oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6Wc
# IC36C1DEVs0t40rSvHDnqA2iA6VW4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqk
# ghyT4pQHHfLiTviMocroE6WRTsgb0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5
# Y1ZEolHN+emjWFbdmwJFRC9f9Nqu1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6
# EiYJZTiU8XofSrvR4Vbo0HiWGFzJNRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjH
# Ce6FDoxPbQ4TTj18KUicctHzbMrB7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI
# 5nI3EvRvsTxngvlSso0zFmUeDordEN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMn
# QK3k+eGpf0a7B2BHZWBATrBC7E7ts3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9Q
# Fi58vwUheuKVQSdpw5OPlcmN2Jshrg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMk
# uYjPaqhHMS+a3ONxPdcAfmJH0c6IybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjW
# wz0xggSYMIIElAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAA
# AIhZDjxRH+JqZwABAAAAiDAJBgUrDgMCGgUAoIG4MBkGCSqGSIb3DQEJAzEMBgor
# BgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3
# DQEJBDEWBBQ4+LFt4+/kskf61lWZFN6vZnSSDDBYBgorBgEEAYI3AgEMMUowSKAW
# gBQAQwBvAG0AbQBvAG4ALgBwAHMAMaEugCxodHRwOi8vd3d3Lk1pY3Jvc29mdC5j
# b20vTWljcm9zb2Z0RHluYW1pY3MvIDANBgkqhkiG9w0BAQEFAASCAQCx+fgzoxwf
# uwzApGllm879zXDeBM+Ekhu+9rBXG+n7e0+7nrl72EWj0cO5F+vRW0HBa5bUJNBq
# 9p0DGSf75s1YY1D8J+cnAZT2XJmcEssYrzXkvdu4Pen11eX54VlJH1Xhxt6w9KUJ
# gAW/M66lfXvm+o2StxTFVSAL7CxNaHsSXUAvEiCNj2ganoo1n8RcgxnXUDSTHAH4
# Kd1+RoD/uM+wwM/qATZ6sAXU/udKxSNSgEV/TYk8lPCzq8ZoqszrqmRwRmZdRXfx
# UD8mL2ggx5gD50FAtKpl75yI8PrTlN1K31P5RGAUucD68WZ4mxw6dUH4P/bcCtuQ
# AklqA4INnZIfoYICITCCAh0GCSqGSIb3DQEJBjGCAg4wggIKAgEBMIGHMHkxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jv
# c29mdCBUaW1lc3RhbXBpbmcgUENBAgphB4NFAAAAAAAQMAkGBSsOAwIaBQCgXTAY
# BgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xMjA5MjQx
# NjI3MzhaMCMGCSqGSIb3DQEJBDEWBBQ31xffRLQZsaTx6QA1KfVH1TlJWDANBgkq
# hkiG9w0BAQUFAASCAQCConAHu3JzjDSWaAtQ8cpDjdFZw40AMqRLYZK9ouBlg97A
# JqAtlrP/y7NALrC3YLksBj0DCsmNx/j/wXsBGUKsnuw0647twE7mwmqSHv12dYfV
# TJfpCVPlEHMcEqBRbI4dfDT5uYx+aslgQJ+R3b34K8xPgy6mK8xjG0EXn1apfgMB
# zBMVSEeTvkUo2BkksBLjWr7UsTQNwGy5qyUBYtBI0/GMGFnGT6tevXqZpZKt+rt/
# 1b5BiAQs8YKWD4pB3FfC+fHbx6epCqSnZmFYKLbQtbZUi2B6vxPzQqcWUQ1YikWB
# D4yuqC3fUgdFLGvVUYu9kFReJ9chN0aBUxKxLecu
# SIG # End signature block
