﻿[System.Reflection.Assembly]::Load("Microsoft.SharePoint, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
[System.Reflection.Assembly]::Load("Microsoft.SharePoint.Portal, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")

<#
.SYNOPSIS
Gets the local farm. WARNING!  You have to dispose object by your own!
.DESCRIPTION
[Microsoft.SharePoint.Administration.SPFarm]::Local;
.EXAMPLE
Get-SPFarmV3
.NOTES 
 WARNING!  You have to dispose object by your own!
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
function Get-SPFarmV3 ()
{
    $farm = [Microsoft.SharePoint.Administration.SPFarm]::Local;
	writeDisposeObjectWarning;
    $farm;
}

<#
.SYNOPSIS
Gets the SPweb object. WARNING!  You have to dispose object by your own!
.DESCRIPTION
Gets the SPweb object. This function won't work for some reason in PowerGUI Script Editor. Use another ISE.
.EXAMPLE
Get-SPWebV3 http://localhost/apps/safety/projectsafe
.NOTES 
 WARNING!  You have to dispose object by your own!
 Function won't work in PowerGUI Script Editor. If you know the workaround please contact me through my blog.
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
function Get-SPWebV3 
(
[Parameter(Mandatory=$true)]
[ValidateNotNull()]
[string]$siteUrl
)
{
    if($site -ne '')
    {
        $site=[Microsoft.SharePoint.SPSite]($siteUrl);
        if($site -ne $null)
            {
               $web=$site.OpenWeb();
			   
            }
     }
	writeDisposeObjectWarning;
    $web;
}
<#
.SYNOPSIS
Gets the SPWebApplication object. WARNING!  You have to dispose object by your own!
.DESCRIPTION
Gets the SPWebApplication objects if the specific url hasn't not been specified.
This function won't work for some reason in PowerGUI Script Editor. Use another ISE.
.EXAMPLE
Retrieves all web applicatons from the local farm.
Get-SPWebApplicationV3 
.EXAMPLE
Retriave one web application based on web application url
$webapp_ = Get-SPWebApplicationV3 http://localhost
.NOTES 
 WARNING!  You have to dispose object by your own!
 Function won't work in PowerGUI Script Editor. If you know the workaround please contact me through my blog.
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
function Get-SPWebApplicationV3
(
[Parameter(Mandatory=$false)]
[string]$webAppUrl
)
{
	$farm = Get-SPFarmV3;
	$websvcs = $farm.Services | where -FilterScript {$_.GetType() -eq [Microsoft.SharePoint.Administration.SPWebService]}
	
	$webapps = @()
	foreach ($websvc in $websvcs) {
	    foreach ($webapp in $websvc.WebApplications) {	
		    if($webAppUrl -eq "")		
			{
	        $webapps = $webapps + $webapp;
			}
			else
			{
			 $site = $webapp.Sites| Select -First 1
			 if($site.Url -contains $webAppUrl)
			 {
			  $webapps=$webapp;
			 }			 
			}
			
	    }
	}
	writeDisposeObjectWarning;
	$webapps;
}


<#
.SYNOPSIS
Gets the SPweb objects for sites that are missing the web template. WARNING!  You have to dispose object by your own!
.DESCRIPTION
Retrieves all sites (SPweb object array) from local farms that are missing the web templates.
This function won't work for some reason in PowerGUI Script Editor. Use another ISE.
.EXAMPLE
Retrieves sites with missing templates and outputs info Site Url and WebTemplateId
$missingTemplates = Get-SitesWithMissingTemplate| FT Url,  WebTemplateId -AutoSize
.NOTES  
 Function won't work in PowerGUI Script Editor. If you know the workaround please contact me through my blog.
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
Function Get-SitesWithMissingTemplate
(
[Parameter(Mandatory=$false)]
[string]$webAppUrl
)
{
$wa = Get-SPWebApplicationV3 $webAppUrl;
$sites=$wa|foreach {$_.Sites|foreach {$_.AllWebs| where {$_.WebTemplate -eq ''}}};
$sites;
}

<#
.SYNOPSIS
Gets the Shared Services Provider Name.
.DESCRIPTION
Retrives the shared services provider name in the local farm. Works for a farm with one shared service provider.
This function won't work for some reason in PowerGUI Script Editor. Use another ISE.
.EXAMPLE
Retrieves sites with missing templates and outputs info Site Url and WebTemplateId
$missingTemplates = Get-SitesWithMissingTemplate| FT Url,  WebTemplateId -AutoSize
.NOTES 
Retrives the shared services provider name in the local farm. Works for a farm with one shared service provider.
 Function won't work in PowerGUI Script Editor. If you know the workaround please contact me through my blog.
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
Function Get-SSProvider()
{
$webapp = Get-SpwebApplicationV3| where {$_.IsAdministrationWebApplication -ne $true} |select -first 1;
$sspInfo = $webapp.Properties["Microsoft.Office.Server.SharedResourceProvider"];
$sspName = $sspInfo.Name;
$sspName;
}

<#
.SYNOPSIS
Gets the SharePoint version based on the  dll versions and a register key
.DESCRIPTION
Gets SharePoint product version based on Microsoft.SharePoint.dll, microsoft.sharepoint.portal.dll versions and register key "hklm:software\microsoft\shared tools\web server extensions\12.0"
.EXAMPLE
Get-SPVersionV3
.NOTES 
More details on how to retrieve version http://sharing-the-experience.blogspot.com/2011/05/where-to-look-for-sharepoint-version.html
AUTHOR: Natalia Tsymbalenko
BLOG: http://sharing-the-experience.blogspot.com/
#>
Function Get-SPVersionV3
()
{
$dlls = @((Get-Item "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\12\ISAPI\Microsoft.SharePoint.dll"),(Get-Item "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\12\ISAPI\microsoft.sharepoint.portal.dll"));
$dlls|foreach{ Write-Host $_.VersionInfo.ProductName " : " $_.VersionInfo.FileVersion };
$registerValue=(get-item "hklm:software\microsoft\shared tools\web server extensions\12.0").getValue("version");
Write-Host "The version in windows register :$registerValue"
}

function writeDisposeObjectWarning()
{
Write-Warning "You have to dispose object by your own!";
}

Export-ModuleMember -Function Get-SPFarmV3,Get-SPWebV3,Get-SPWebApplicationV3,Get-SitesWithMissingTemplate, Get-SSProvider, Get-SPVersionV3