﻿Set-DnsServerConditionalForwarderZone -Name:contosouniversity.edu -MasterServers:20.0.0.5
Clear-DnsServerCache -Force

