﻿# RestoreADMFiles function
# From Remove-ADM.ps1, located here: http://gallery.technet.microsoft.com/scriptcenter/Removing-ADM-files-from-b532e3b6

#If restore flag is specified, read backup file and backup path, then restore files
function RestoreADMFiles
{
    param([string]$logpath)
    
    $logData = import-csv $logpath
    foreach ($entry in $logData)
    {
       if($entry.BackupLocation -ne "")
       { 
           copy-item $entry.BackupLocation -destination $entry.FullPath    
           if($?)
           { 
             "Restored $($entry.FullPath)"
           }
       }
    }    
}