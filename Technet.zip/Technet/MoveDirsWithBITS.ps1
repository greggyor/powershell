﻿Import-Module BitsTransfer
$source = "C:\myDir"
$dest = "\\Server\myShare\myDir"
xcopy.exe /T /E $source $dest /Y
Get-ChildItem -Path $source -Recurse | ?{$_.PSisContainer} | foreach {$spath = $_.FullName.Remove(0,$source.Length+1); Start-BitsTransfer -Source $source\$spath\*.* -Destination $dest\$spath}
Start-BitsTransfer $source\*.* $dest
