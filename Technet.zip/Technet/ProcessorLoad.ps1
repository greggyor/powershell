﻿###################################################################################
# Title: Processor Load Monitor
# Version: 1.1
# Author: Chris Carter
# Contact: powershell@artfullyencoded.com
# 
# Purpose: To provide a notification icon that displays processor information
#          gained from WMI in the system tray.  Can get information from remote
#          computers, and can also show results for more than one processor.
#
# Acknowledgement: The basic idea and layout was gathered from a tutorial at this
#                  address: http://bytecookie.wordpress.com/2011/12/28/gui-creation-with-powershell-part-2-the-notify-icon-or-how-to-make-your-own-hdd-health-monitor/
#
###################################################################################

#Load needed assemblies
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

#Wrapper for VB code calling the ExtractIconEX function from the Windows API
#for extracting icons from .dll, .exe, etc.
#Obtained verbatim from Kazun's post at -
#http://social.technet.microsoft.com/Forums/en/winserverpowershell/thread/16444c7a-ad61-44a7-8c6f-b8d619381a27
$codeIconExtract = @"
using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace System
{
	public class IconExtractor
	{

	 public static Icon Extract(string file, int number, bool largeIcon)
	 {
	  IntPtr large;
	  IntPtr small;
	  ExtractIconEx(file, number, out large, out small, 1);
	  try
	  {
	   return Icon.FromHandle(largeIcon ? large : small);
	  }
	  catch
	  {
	   return null;
	  }

	 }
	 [DllImport("Shell32.dll", EntryPoint = "ExtractIconExW", CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
	 private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion, out IntPtr piSmallVersion, int amountIcons);

	}
}
"@

#Add Type to use wrapped Static function for icon extraction
Add-Type -TypeDefinition $codeIconExtract -ReferencedAssemblies System.Drawing

#Name of computer to query
$computer = "localhost"

#Used to poll the processor and format for NotifyIcon
Function Get-ProcessorLoad {
    
    Param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.NotifyIcon]$NotifyIcon
    ) 
    
    #Get Processor Information
    $processor = Get-WmiObject Win32_Processor -ComputerName $computer

    #Test if computer has more than one physical processor
    if ($processor -is [Array]) {
        $formatLoad = @("Processor Load on $($computer):")

        #Step through each processor and add info to formatted array
        foreach ($cpu in $processor) {
            $formatLoad += "$($cpu.DeviceID):  $($cpu.LoadPercentage)%"

            #Test for alert of high Processor load
            if ($cpu.LoadPercentage -ge 90) {
                $NotifyIcon.ShowBalloonTip(30000, "Processor Load Warning", "$($cpu.DeviceID) load has reached a critical level of $($cpu.LoadPercentage)%`n`nIf you are monitoring the local computer, click to go to the Task Manager", "Warning")
            }
        }

        #Set hover text from formatted array
        $NotifyIcon.Text = "$($formatLoad -join ("`n"))"
    }

    #Case for when there is only one physical processor in the machine
    else {
        $NotifyIcon.Text = "Processor Load on $computer is $($processor.LoadPercentage)%"

        #Test for alert of high Processor load
        if ($processor.LoadPercentage -ge 90) {
            $NotifyIcon.ShowBalloonTip(30000, "Processor Load Warning", "The processor load has reached a critical level of $($processor.LoadPercentage)%`n`nIf you are monitoring the local computer, click to go to the Task Manager", "Warning")
        }
    }
}

#Generate form objects
$form1 = New-Object System.Windows.Forms.Form
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$contextMenu = New-Object System.Windows.Forms.ContextMenu
$menuExit = New-Object System.Windows.Forms.MenuItem
$menuRefresh = New-Object System.Windows.Forms.MenuItem
$menuTask = New-Object System.Windows.Forms.MenuItem
$menuSep = New-Object System.Windows.Forms.MenuItem
$timer = New-Object System.Windows.Forms.Timer
$icon = [System.IconExtractor]::Extract("setupapi.dll", 21, $false)

#Hide form window
$form1.ShowInTaskbar = $false
$form1.WindowState = "minimized"

#Set Notify Icon defaults
$notifyIcon.Icon = $icon
$notifyIcon.ContextMenu = $contextMenu
$notifyIcon.Visible = $true

#Test for Monitoring of Local Computer before running Task Manager
if ($computer.ToLower() -eq "localhost" -or $computer.ToLower() -eq $env:COMPUTERNAME.ToLower()) {
    
    #Run Task Manager when alert balloon clicked
    $notifyIcon.add_BalloonTipClicked({Invoke-Expression -Command "taskmgr.exe"})

    #Add Task Manager shortcut to context menu 
    $notifyIcon.ContextMenu.MenuItems.AddRange(@($menuTask, $menuRefresh, $menuSep, $menuExit))

    #Configure Task Manager menu item
    $menuTask.Text = "Open Task Manager"
    $menuTask.add_Click({Invoke-Expression -Command "taskmgr.exe"})
}
else {
    #Do not add Task Manager menu item
    $notifyIcon.ContextMenu.MenuItems.AddRange(@($menuRefresh, $menuSep, $menuExit))
}    

#Timer used for polling, better choice than Start-Sleep
$timer.Interval = 300000 #in milliseconds; equals 5 minutes
$timer.add_Tick({Get-ProcessorLoad -NotifyIcon $notifyIcon})
$timer.Start()

#Adds a refresh option in the context menu
$menuRefresh.Text = "Refresh"
$menuRefresh.add_Click({
    $timer.Stop()
    $timer.Start()
})

#Add a separator line to the context menu
$menuSep.Text = "-" #Dash signifies the separator

#Adds a way to exit the script in the context menu
$menuExit.Text = "Exit"
$menuExit.add_Click({
    $timer.Stop()
    $notifyIcon.Visible = $False
    $form1.Close()
})

#Run function intially to populate the data before display
Get-ProcessorLoad -NotifyIcon $notifyIcon

#Add this to all WinForms GUIs, though not sure if it affects notifications
[void][System.Windows.Forms.Application]::EnableVisualStyles()

#Run the form
[void][System.Windows.Forms.Application]::Run($form1)