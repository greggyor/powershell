﻿<#
  .SYNOPSIS
    SSRS Wake-Up Call
#>

# Root url of SSRS Report Manager
# Example:
#   http://localhost/Reports               for a local default SSRS instance
#   http://servername/Reports_SQLEXPRESS   for a remote named SSRS instance "SQLEXPRESS"
[string] $url = "http://localhost/Reports";

# Create new WebClient.
[System.Net.WebClient] $wc = New-Object System.Net.WebClient;
# Use current account for authorization.
$wc.UseDefaultCredentials = $true;

try
{
    # Download start page.
    [string] $result = $wc.DownloadString($url);
    # Just to check the response:
    [int] $pos = $result.IndexOf("META Name=""Report Server""");
    if ($pos -gt -1)
    {
        Write-Output "Response is ok.";
    }
    else
    {
        Write-Output "Got response, but not as expected.";
    }
}
catch
{
    Write-Verbose $_.Exception.Message;
}

$wc.Dispose();


