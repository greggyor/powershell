﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

function OSCgetid ($id)
{
	if ($id -like "[123]")
	{
		switch ($id)
		{
			"1" {Uninstall-WindowsFeature Server-Gui-Mgmt-Infra,Server-Gui-Shell}
			"2" {Install-WindowsFeature Server-Gui-Mgmt-Infra,Server-Gui-Shell}
			"3" {
					Import-Module Dism
					Enable-WindowsOptionalFeature -online -Featurename ServerCore-FullServer,Server-Gui-Shell,Server-Gui-Mgmt
				}
		}
	}
	else
	{
	Write-Warning -Message "Incorrect input!"
	[string]$id=Read-Host -Prompt "Enter the number to select an option"
	OSCgetid $id
	}
}

$banner=@'
==============================================================
             Switch between GUI and server Core
==============================================================
[1] Switch to server CORE
[2] Switch to GUI
[3] Install GUI from online resource
'@


Write-Host $banner
[string]$ID=Read-Host -Prompt "Enter the number to select an option"
OSCgetid $id
write-host "It Will take effect after reboot, do you want to reboot?"
[string]$Reboot = Read-Host -Prompt "[Y] Yes  [N] No   (default is 'N')"

if ($Reboot -eq "y" -or $Reboot -eq "yes") {Restart-Computer}






