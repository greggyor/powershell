#----------------------------------------------------------------------------------
Import-Module ActiveDirectory

Clear-Host

$numberOfdays = 1095 #Three years

function Get-ADUserLastLogon([string]$userName)
{
  $domainControllers = Get-ADDomainController -Filter {Name -like "*"}
  $time = 0
  foreach($domainController in $domainControllers)
  { 
    $hostname = $domainController.HostName
    $user = Get-ADUser -Identity $userName | Get-ADObject -Properties lastLogon 
    if($user.LastLogon -gt $time) 
    {
      $time = $user.LastLogon
    }
  }
  $dateTime = [DateTime]::FromFileTime($time)
  Return  $dateTime
}

$myDomain = Get-ADDomain

$myDomainName = $myDomain.NetBIOSname

$userCollection = Search-ADAccount -AccountInactive -TimeSpan "$numberOfdays.00:00:00" | where {($_.ObjectClass -eq 'user') -and ($_.ObjectClass -ne 'computer')}

$csvFilePath = ".\$($myDomainName)AccountsNotLoggedIntoIn$($numberOfdays)Days.csv"

"USER OBJECT NAME,LAST LOGON DATE/TIME,CREATE DATE,PASSWORD LAST SET,DESCRIPTION" | Out-File $csvFilePath -Encoding "Default"

foreach ($userDN in $userCollection) {
	$userObject = Get-ADUser -Identity $userDN -Properties *
	$userObjectName = $userObject.sAMAccountName
	$userObjectName = $userObjectName.Replace(",", " ")
	$userObjectEnabled = $userObject.Enabled
	$userObjectCreateDate = $userObject.WhenCreated
	$userObjectPasswordLastSet = $userObject.PasswordLastSet
	$userObjectDescription = $userObject.Description
	$userObjectLastLogon = Get-ADUserLastLogon($userObjectName)
	if ($userObjectLastLogon = "12/31/1600 19:00:00") {
		$userObjectLastLogon = "Never"
	}
	if ($userObjectEnabled) {		 
		 if (!($userObjectName.Contains("$"))) {
		 	"$userObjectName,$userObjectLastLogon,$userObjectCreateDate,$userObjectPasswordLastSet,$userObjectDescription" | Out-File $csvFilePath -Append -Encoding "Default"
		 }
	}
}
#----------------------------------------------------------------------------------
