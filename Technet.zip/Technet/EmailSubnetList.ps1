﻿#=============================================================================#
#                    
# EmailSubnetlist.ps1
# Powershell Script to gather a list of all AD subnets, then email them to
# the team for use in determining caching servers and copy
# the files to the caching server
# Author: Nick Fields
# Last Modified: 11.29.2012
# Version: 1.22
#               
#=============================================================================#

##Import AD Module if needed
Import-Module ActiveDirectory -ErrorAction SilentlyContinue

#Set Required variables
$correctedSubnets = @()
$subnetCharsToRemove = [regex]"\/\d\d"
$outputServerPath = "\\CACHINGSERVER\FILESHARE\"
Set-Location c:\powershell

#Get list of subnet objects from AD
$configNCDN = (Get-ADRootDSE).ConfigurationNamingContext
$siteContainerDN = ("CN=Sites," + $configNCDN)
$subnetlist = Get-ADObject -SearchBase $siteContainerDN -filter { objectClass -eq "subnet" } -properties description

#Reformat list as custom objects and remove unneeded properties
foreach ($line in $subnetlist) {
	if ($line.Name -match "/24") {
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
	
		$newline = New-Object system.Object
		$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
		$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $subnet
	
		$correctedSubnets = $correctedSubnets + $newline
	}
	elseif ($line.Name -match "/22") {
		
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
		
		#Split IP address to generate /24 subnet list
		$i = 0
		$subnetarray = $subnet.Split(".")
		while ($i -le 3) {
			#Convert third octet to integer and increment
			$thirdoctet = [System.Convert]::ToInt32($subnetarray[2])
			$thirdoctet = $thirdoctet + $i
			
			#Convert back to subnet string
			$assemblesubnet = $subnetarray[0] + "." + $subnetarray[1] + "." + [System.Convert]::ToString($thirdoctet) + "." + $subnetarray[3]
			$newline = New-Object system.Object
			$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
			$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $assemblesubnet
	
			$correctedSubnets = $correctedSubnets + $newline
			$i++
		}
	}
		elseif ($line.Name -match "/21") {
		
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
		
		#Split IP address to generate /24 subnet list
		$i = 0
		$subnetarray = $subnet.Split(".")
		while ($i -le 7) {
			#Convert third octet to integer and increment
			$thirdoctet = [System.Convert]::ToInt32($subnetarray[2])
			$thirdoctet = $thirdoctet + $i
			
			#Convert back to subnet string
			$assemblesubnet = $subnetarray[0] + "." + $subnetarray[1] + "." + [System.Convert]::ToString($thirdoctet) + "." + $subnetarray[3]
			$newline = New-Object system.Object
			$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
			$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $assemblesubnet
	
			$correctedSubnets = $correctedSubnets + $newline
			$i++
		}
	}
		elseif ($line.Name -match "/20") {
		
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
	
		#Split IP address to generate /24 subnet list
		$i = 0
		$subnetarray = $subnet.Split(".")
		while ($i -le 15) {
			#Convert third octet to integer and increment
			$thirdoctet = [System.Convert]::ToInt32($subnetarray[2])
			$thirdoctet = $thirdoctet + $i
			
			#Convert back to subnet string
			$assemblesubnet = $subnetarray[0] + "." + $subnetarray[1] + "." + [System.Convert]::ToString($thirdoctet) + "." + $subnetarray[3]
			$newline = New-Object system.Object
			$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
			$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $assemblesubnet
	
			$correctedSubnets = $correctedSubnets + $newline
			$i++
		}
	}
		elseif ($line.Name -match "/19") {
		
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
	
		#Split IP address to generate /24 subnet list
		$i = 0
		$subnetarray = $subnet.Split(".")
		while ($i -le 31) {
			#Convert third octet to integer and increment
			$thirdoctet = [System.Convert]::ToInt32($subnetarray[2])
			$thirdoctet = $thirdoctet + $i
			
			#Convert back to subnet string
			$assemblesubnet = $subnetarray[0] + "." + $subnetarray[1] + "." + [System.Convert]::ToString($thirdoctet) + "." + $subnetarray[3]
			$newline = New-Object system.Object
			$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
			$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $assemblesubnet
	
			$correctedSubnets = $correctedSubnets + $newline
			$i++
		}
	}
		else {
		
		$subnet = $line.Name -replace ($subnetCharsToRemove,"") 
		$officeCode = $line.Description.Split("(")
	
		$newline = New-Object system.Object
		$newline | Add-Member -type Noteproperty -Name OfficeCode -Value $officeCode[0]
		$newline | Add-Member -type Noteproperty -Name IPSubnet -Value $subnet
	
		$correctedSubnets = $correctedSubnets + $newline
	}
}

#Export the subnet list to a CSV file for emailing
$correctedSubnets = $correctedSubnets | Sort-Object OfficeCode 
$correctedSubnets | Export-Csv c:\powershell\ADSubnetList.csv -NoTypeInformation

#Copy the subnet list to the appropriate server
Copy-Item c:\powershell\ADSubnetList.csv -Destination $outputServerPath

##Assembles and sends completion email with DL information##
$emailFrom = "SERVER@CONTOSO.COM"
$emailTo = "USERNAME@CONTOSO.COM"
$subject = "Subnet Report Script Complete"
$smtpServer = "SMTPSERVERNAME"
$body = "Please see the attached global subnet listing, the file has also been copied to: $outputServerPath"

Send-MailMessage -To $emailTo -From $emailFrom -Subject $subject -Body $body -SmtpServer $smtpServer -Attachments "c:\powershell\ADSubnetList.csv"