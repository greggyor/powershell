﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 2.0

Function Measure-OSCFileExtension
{
<#
 	.SYNOPSIS
        Measure-OSCFileExtension is an advanced function which can be used to calculate the number of file extension.
    .DESCRIPTION
        Measure-OSCFileExtension is an advanced function which can be used to calculate the number of file extension.
    .PARAMETER  <ListAllItems>
		Specifies the path of slide.
	.PARAMETER  <DeleteDaysBefore>
		Specifies the file extension you want to list.	
    .EXAMPLE
       C:\PS> Measure-OSCFileExtension -Path C:\Windows -Extension *.txt,*.exe
		
		Extension                       Count
		---------                       -----
		.txt                            1
		.exe                            12
    .EXAMPLE
        C:\PS> Measure-OSCFileExtension -Path C:\Windows
		
		Extension                          Count
		---------                          -----
		Folder/File without extension      69
		.NET                               1
		.xml                               3
		.bin                               2
		.INI                               6
		.exe                               12
		.dat                               1
		.log                               9
		.mif                               2
		.dll                               3
		.txt                               1
#>  
	[Cmdletbinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=0)]
		[Alias('p')][String]$Path,
		[Parameter(Mandatory=$false,Position=1)]
		[Alias('ext')][String[]]$Extension
	)
	
	$ExtensionInfo = Get-ChildItem -Path $Path | Group-Object -Property Extension -NoElement

	If ($Extension)
	{
		Foreach($FileExtension in $Extension)
		{
			$ExtensionInfo | Where-Object {$_.Name -like $FileExtension} | Select-Object @{Name="Extension";Expression={$_.Name}},Count
		}
	}
	Else
	{
		$ExtensionInfo | Select-Object @{Name="Extension";Expression={If($_.Name -eq ""){"Folder/File without extension"}Else{$_.Name}}},Count 
	}
}