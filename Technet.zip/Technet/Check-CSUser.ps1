# Check to see if User has a Communicator or Lync account.


# Prompt for User Account Name
cls
Write-Host
Write-Host "Does User have a Office Communicator or Lync Account?"
Write-Host
$User = Read-Host "Enter User Account Name (Ex: John.Doe) "


# Get User Information
$UserInfo = Get-CSADuser -identity $User
$Name=$UserInfo.Name

Write-Host

# Check accounts: No SIP=No Acct, No RegistrarPool= Communicator User
If (!($UserInfo.SipAddress))
	{
	Write-Host -ForegroundColor Red "$Name is NOT a Communicator or Lync User"
	}
ElseIf (!((get-csuser -identity $User).registrarpool.friendlyname))
	{
	Write-Host -ForegroundColor Yellow "$Name is a Office Communicator User"
	}
	Else
		{
		Write-Host -ForegroundColor Green "$Name is a Lync User"
		}
Write-Host
