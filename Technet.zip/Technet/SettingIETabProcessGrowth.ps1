﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#Requires -Version 2.0

$Message = New-Object PSObject
$Message | Add-Member NoteProperty LowerIEVersion `
	"'TabProcGrowth' only works on IE 8 or later." 

$Description = New-Object PSObject
$Description | Add-Member NoteProperty DescSmall `
	"TabProcGrowth='small': Maximum 5 tab processes in a logon session, requires 15 tabs to get the 3rd tab process." 
$Description | Add-Member NoteProperty DescMedium `
	"TabProcGrowth='medium': Maximum 9 tab processes in a logon session, requires 17 tabs to get the 5th tab process." 
$Description | Add-Member NoteProperty DescLarge `
	"TabProcGrowth='large': Maximum 16 tab processes in a logon session, requires 21 tabs to get the 9th tab process." 
$Description | Add-Member NoteProperty Desc0 `
	"TabProcGrowth=0 : Tabs and frames run within the same process; frames are not unified across MIC(mandatory integrity) levels." 
$Description | Add-Member NoteProperty Desc1 `
	"TabProcGrowth=1 : All tabs for a given frame process run in a single tab process for a given MIC(mandatory integrity) level." 
$Description | Add-Member NoteProperty DescGT1 `
	"TabProcGrowth>1 : Multiple tab processes will be used to execute the tabs at a given MIC(mandatory integrity) level for a single frame process. In general, new processes are created until the TabProcGrowth number is met, and then tabs are load balanced across the tab processes." 
$Description | Add-Member NoteProperty "NotSet" `
	"TabProcGrowth Not Set : The context-based algorithm is used and the curve is chosen based on the amount of physical memory on the machine." 

Function Set-OSCIETabProcGrowthProperty{
<#
    .SYNOPSIS
        Set-OSCIETabProcGrowthProperty can be used to set the TabProcGrowth setting for
		the Internet Explorer installed on your computer.
		
    .DESCRIPTION
        Set-OSCIETabProcGrowthProperty can be used to set the TabProcGrowth setting for
		the Internet Explorer installed on your computer.There are two algorithms used 
		by Internet Explorer to set ”TabProcGrowth” registry entry value.
			1. Context-based: By default, the context-based algorithm is used and the 
			curve is chosen based on the amount of physical memory on the machine. In 
			addition, the TabProcGrowth string registry value may be manually forced to:
				•small: Maximum 5 tab processes in a logon session, requires 15 tabs to 
				get the 3rd tab process.
				•medium: Maximum 9 tab processes in a logon session, requires 17 tabs to 
				get the 5th tab process.
				•large: Maximum 16 tab processes in a logon session, requires 21 tabs to 
				get the 9th tab process.

			2. The "Max-Number" algorithm: This specifies the maximum number of tab 
			processes that may be executed for a single isolation session for a single 
			frame process at a specific mandatory integrity level (MIC). Relative values 
			are:
				•TabProcGrowth=0 : tabs and frames run within the same process; frames 
				are not unified across MIC levels. 
				•TabProcGrowth =1: all tabs for a given frame process run in a single tab 
				process for a given MIC level.
				Note: On Terminal Server, the default value is the integer of 1.
				•TabProcGrowth >1: multiple tab processes will be used to execute the tabs 
				at a given MIC level for a single frame process. In general, new processes 
				are created until the TabProcGrowth number is met, and then tabs are load 
				balanced across the tab processes.
				Note: that the frame process is no longer allowed to execute at low-MIC. 
				If this is attempted, the process will exit.
		
	.PARAMETER  <TabProcGrowth>
		The value you want to set to TabProcGrowth of the Internet Explorer on your 
		computer.
		
    .EXAMPLE
        Set-OSCIETabProcGrowthProperty -TabProcGrowth "medium"
		Set the TabProcGrowth setting to "medium" for the Internet Explorer installed on your computer.
#>

	[CmdletBinding()]
	# Parameters for the function
	PARAM
	(
	    [Parameter(Mandatory = $true)]
		[ValidateSet("small","medium","large","0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16")]
	    $TabProcGrowth
	)
	
	#Environment params
	$Computer = $Env:COMPUTERNAME
	$IeVersion = Get-OSCIEVersion
	$IeVersionMajor = 7
	
	If($IeVersion -ne $null){
		$IeVersionMajor = ([Version]$IeVersion).Major
	}
	
	If($IeVersionMajor -lt 8){
		Throw $Message.LowerIEVersion
	}
	
	$OSCIETabProcGrowth = New-Object PSObject
	$OSCIETabProcGrowth | Add-Member NoteProperty "ComputerName" $Computer
	$OSCIETabProcGrowth | Add-Member NoteProperty "IEVersion" $IeVersion 
	$OSCIETabProcGrowth | Add-Member NoteProperty "TabProcGrowth" $null
	$OSCIETabProcGrowth | Add-Member NoteProperty "SettingType" $null
	$OSCIETabProcGrowth | Add-Member NoteProperty "Description" $null
	
	$BaseKeyTabProcGrowth = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(`
	[Microsoft.Win32.RegistryHive]::CurrentUser,$Computer)

	$KeyTabProcGrowth = $BaseKeyTabProcGrowth.OpenSubKey(`
	"Software\Microsoft\Internet Explorer\Main", $true)
	
	If($TabProcGrowth -ieq "small"){
		$OSCIETabProcGrowth.SettingType = [Microsoft.Win32.RegistryValueKind]::String
		$OSCIETabProcGrowth.Description = $Description.DescSmall
	}
	ElseIf($TabProcGrowth -ieq "medium"){
		$OSCIETabProcGrowth.SettingType = [Microsoft.Win32.RegistryValueKind]::String
		$OSCIETabProcGrowth.Description = $Description.DescMedium
	}
	ElseIf($TabProcGrowth -ieq "large"){
		$OSCIETabProcGrowth.SettingType = [Microsoft.Win32.RegistryValueKind]::String
		$OSCIETabProcGrowth.Description = $Description.DescLarge
	}
	Else{
		$OSCIETabProcGrowth.SettingType = [Microsoft.Win32.RegistryValueKind]::DWord
		
		If($TabProcGrowth -eq "0"){
			$OSCIETabProcGrowth.Description = $Description.Desc0
		}
		ElseIf($TabProcGrowth -eq "1"){
			$OSCIETabProcGrowth.Description = $Description.Desc1
		}
		Else{
			$OSCIETabProcGrowth.Description = $Description.DescGT1
		}
	}
	
	$KeyTabProcGrowth.SetValue("TabProcGrowth",$TabProcGrowth,$OSCIETabProcGrowth.SettingType)
	$OSCIETabProcGrowth.TabProcGrowth = $TabProcGrowth
	$OSCIETabProcGrowth
}

Function Get-OSCIETabProcGrowthProperty{
<#
    .SYNOPSIS
        Get-OSCIETabProcGrowthProperty can be used to get the TabProcGrowth setting for
		the Internet Explorer installed on your computer.
		
    .DESCRIPTION
        Get-OSCIETabProcGrowthProperty can be used to get the TabProcGrowth setting for
		the Internet Explorer installed on your computer.
		
    .EXAMPLE
        Get-OSCIETabProcGrowthProperty
		Show  the TabProcGrowth setting for the Internet Explorer installed on your 
		computer.
#>

	#Environment params
	$Computer = $Env:COMPUTERNAME
	$IeVersion = Get-OSCIEVersion
	$IeVersionMajor = 7
	
	If($IeVersion -ne $null){
		$IeVersionMajor = ([Version]$IeVersion).Major
	}
	
	If($IeVersionMajor -lt 8){
		Throw $Message.LowerIEVersion
	}
			
	$OSCIETabProcGrowth = New-Object PSObject
	$OSCIETabProcGrowth | Add-Member NoteProperty "ComputerName" $Computer
	$OSCIETabProcGrowth | Add-Member NoteProperty "IEVersion" $IeVersion 
	$OSCIETabProcGrowth | Add-Member NoteProperty "TabProcGrowth" $null
	$OSCIETabProcGrowth | Add-Member NoteProperty "SettingType" $null
	$OSCIETabProcGrowth | Add-Member NoteProperty "Description" $null
			
	$BaseKeyTabProcGrowth = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(`
	[Microsoft.Win32.RegistryHive]::CurrentUser,$Computer)

	$KeyTabProcGrowth = $BaseKeyTabProcGrowth.OpenSubKey(`
	"Software\Microsoft\Internet Explorer\Main", $false)
	
	Try{
		$OSCIETabProcGrowth.SettingType = $KeyTabProcGrowth.GetValueKind("TabProcGrowth")
		$OSCIETabProcGrowth.TabProcGrowth = $KeyTabProcGrowth.GetValue("TabProcGrowth")
	}
	Catch{
		$OSCIETabProcGrowth.SettingType = $null 
		$OSCIETabProcGrowth.TabProcGrowth = $null 
	}
	
	If($OSCIETabProcGrowth.TabProcGrowth -ieq "small"){
		$OSCIETabProcGrowth.Description = $Description.DescSmall
	}
	ElseIf($OSCIETabProcGrowth.TabProcGrowth -ieq "medium"){
		$OSCIETabProcGrowth.Description = $Description.DescMedium
	}
	ElseIf($OSCIETabProcGrowth.TabProcGrowth -ieq "large"){
		$OSCIETabProcGrowth.Description = $Description.DescLarge
	}
	ElseIf($OSCIETabProcGrowth.TabProcGrowth -ieq "0"){
		$OSCIETabProcGrowth.Description = $Description.Desc0
	}
	ElseIf($OSCIETabProcGrowth.TabProcGrowth -ieq "1"){
		$OSCIETabProcGrowth.Description = $Description.Desc1
	}
	ElseIf($OSCIETabProcGrowth.TabProcGrowth -gt 1){
		$OSCIETabProcGrowth.Description = $Description.DescGT1
	}
	Else{
		$OSCIETabProcGrowth.Description = $Description.NotSet
	}
	
	$OSCIETabProcGrowth
}

Function Get-OSCIEVersion{
<#
    .SYNOPSIS
        Get-OSCIEVersion can be used to get the version of Internet Explorer in the 
		current computer.
		
    .DESCRIPTION
        Get-OSCIEVersion can be used to get the version of Internet Explorer in the 
		current computer.
		
    .EXAMPLE
        Get-OSCIEVersion
		Show the version of Internet Explorer in the current computer.
#>

	$ieFilePath = -join($Env:ProgramFiles,"\Internet Explorer\iexplore.exe")
	$ieFile = Get-ItemProperty -Path $ieFilePath -ErrorAction SilentlyContinue
	$ieFile.VersionInfo.ProductVersion
}