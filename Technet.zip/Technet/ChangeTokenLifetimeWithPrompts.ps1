if ( (Get-PSSnapin -Name Microsoft.Adfs.Powershell -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin Microsoft.Adfs.Powershell
}

$relyingPartyName = Read-Host "Enter the name of the Relying Party"
$tokenLifetime = Read-Host "Enter the token lifetime"

Set-ADFSRelyingPartyTrust -TargetName $relyingPartyName -TokenLifeTime $tokenLifetime
Read-Host "The new Token Lifetime value has been saved. Press enter to exit."