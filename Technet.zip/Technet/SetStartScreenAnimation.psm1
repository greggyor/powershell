﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 3.0

Function Enable-OSCStartScreenAnimation
{
<#
 	.SYNOPSIS
        Set-OSCStartScreenanimation is an advanced function which can be used to enable the Start screen animation.
    .DESCRIPTION
        Set-OSCStartScreenanimation is an advanced function which can be used to enable the Start screen animation.
    .PARAMETER  UserNameSliderAnimationOffset
		Specifices a value to set the offset for user name shown on the Start menu.
    .PARAMETER  UserPictureSlideAnimationOffset
		Specifices a value to set the offset for user picture shown on the Start menu.
    .PARAMETER  RightToLeftAnimationOffset
		Specifices a value to set the tiles "far" distance animation shown on the Start menu.
    .PARAMETER  LeftToRightAnimationOffset
		Specifices a value to set the tiles close distance shown on the Start menu.
    .PARAMETER  Disableanimation
		Disable the Start screen animation.
    .EXAMPLE
        C:\PS> Set-OSCStartScreenanimation
		
		This command shows how to enable the Start screen animation by default mode.
    .EXAMPLE
        C:\PS> Set-OSCStartScreenanimation -Disableanimation
		
		This command shows how to disable the Start screen animation by default mode.
    .EXAMPLE
        C:\PS> Set-OSCStartScreenanimation -UserNameSliderAnimationOffset 1000 -UserPictureSlideAnimationOffset 2000 -RightToLeftAnimationOffset 1000 -LeftToRightAnimationOffset 100
		
		This command shows how to set the Start screen animation by customize mode.
#>
    [CmdletBinding(SupportsShouldProcess,DefaultParameterSetName="__AllParameterSets")]
    Param
    (
        [Parameter(Mandatory=$false,Position=0,ParameterSetName="Customize")]
        [Alias('username')]
        [Int]$UserNameSliderAnimationOffset,
        [Parameter(Mandatory=$false,Position=1,ParameterSetName="Customize")]
        [Alias('userpicture')]
        [Int]$UserPictureSlideAnimationOffset,
        [Parameter(Mandatory=$false,Position=2,ParameterSetName="Customize")]
        [Alias('rtl')]
        [Int]$RightToLeftAnimationOffset,
        [Parameter(Mandatory=$false,Position=3,ParameterSetName="Customize")]
        [Alias('ltr')]
        [Int]$LeftToRightAnimationOffset,
        [Parameter(Mandatory=$false,Position=4,ParameterSetName="Disable")]
        [Alias('off')]
        [Switch]$Disableanimation
    )
    
    Try
    {
        Set-OSCanimationRegKey -ShowOnValue 1 -UserPictureValue 0 -UserNameValue 0 -RightToLeftValue 0 -LeftToRightValue 0

        If ($UserNameSliderAnimationOffset)
        {
            Set-OSCanimationRegKey -UserNameValue $UserNameSliderAnimationOffset
        }
        If ($UserPictureSlideAnimationOffset)
        {
            Set-OSCanimationRegKey -UserPictureValue $UserPictureSlideAnimationOffset
        }
        If ($RightToLeftAnimationOffset)
        {
            Set-OSCanimationRegKey -RightToLeftValue $RightToLeftAnimationOffset
        }
        If ($LeftToRightAnimationOffset)
        {
            Set-OSCanimationRegKey -LeftToRightValue $LeftToRightAnimationOffset
        }

        If ($Disableanimation)
        {
            Set-OSCanimationRegKey -ShowOnValue 0 -UserPictureValue 0 -UserNameValue 0 -RightToLeftValue 0 -LeftToRightValue 0
        }

        Write-Host "Setting the Start screen anitmations successfully." -ForegroundColor Green
    }
    Catch
    {
        Write-Host "Failed to set the Start screen anitmations." -ForegroundColor Red
    }
}

Function Set-OSCanimationRegKey([Int]$ShowOnValue, [Int]$UserPictureValue, [Int]$UserNameValue, [Int]$RightToLeftValue, [Int]$LeftToRightValue)
{
    #Define the main registry key
    $KeyPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ImmersiveShell\Grid"
    $RegistryKey = Get-ItemProperty -Path $KeyPath

    $LoginAnimationRegKey = (Get-ItemProperty -Path $KeyPath).Launcher_SessionLoginAnimation_OnShow
    $UserPictureRegKey = (Get-ItemProperty -Path $KeyPath).Launcher_SessionLogin_Icon_Offset
    $UserNameRegKey = (Get-ItemProperty -Path $KeyPath).Launcher_SessionLogin_IconText_Offset
    $RightToLeftRegKey = (Get-ItemProperty -Path $KeyPath).Launcher_SessionLogin_IndividualTower_Offset
    $LeftToRightRegKey = (Get-ItemProperty -Path $KeyPath).Launcher_SessionLogin_Tower_Offset

    #Sets the "Login Animation" registry key
    If ($LoginAnimationRegKey -eq $null)
    {
        New-ItemProperty -Path $KeyPath -Name "Launcher_SessionLoginAnimation_OnShow" -Value $ShowOnValue -PropertyType DWord | Out-Null
        Write-Verbose -Message "Setting the ""Launcher_SessionLoginAnimation_OnShow"" registry key successfully."
    }
    Else
    {
        Set-ItemProperty -Path $KeyPath -Name "Launcher_SessionLoginAnimation_OnShow" -Value $ShowOnValue | Out-Null
        Write-Verbose -Message "Create the ""Launcher_SessionLoginAnimation_OnShow"" registry key successfully."
    }

    #Sets the "user picture" registry key
    If ($UserPictureRegKey -eq $null)
    {
        New-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_Icon_Offset" -Value $UserPictureValue -PropertyType DWord | Out-Null
        Write-Verbose -Message "Setting the ""Launcher_SessionLogin_Icon_Offset"" registry key successfully."
    }
    Else
    {
        Set-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_Icon_Offset" -Value $UserPictureValue | Out-Null
        Write-Verbose -Message "Create the ""Launcher_SessionLogin_Icon_Offset"" registry key successfully."
    }

    #Sets the "user name" registry key
    If ($UserNameRegKey -eq $null)
    {
        New-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_IconText_Offset" -Value $UserNameValue -PropertyType DWord | Out-Null
        Write-Verbose -Message "Setting the ""Launcher_SessionLogin_IconText_Offset"" registry key successfully."
    }
    Else
    {
        Set-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_IconText_Offset" -Value $UserNameValue | Out-Null
        Write-Verbose -Message "Create the ""Launcher_SessionLogin_IconText_Offset"" registry key successfully."
    }

    #Sets the "right to left" registry key
    If ($RightToLeftRegKey -eq $null)
    {
        New-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_IndividualTower_Offset" -Value $RightToLeftValue -PropertyType DWord | Out-Null
        Write-Verbose -Message "Setting the ""Launcher_SessionLogin_IndividualTower_Offset"" registry key successfully."
    }
    Else
    {
        Set-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_IndividualTower_Offset" -Value $RightToLeftValue | Out-Null
        Write-Verbose -Message "Create the ""Launcher_SessionLogin_IndividualTower_Offset"" registry key successfully." 
    }

    #Sets the "left to right" registry key
    If ($LeftToRightRegKey -eq $null)
    {
        New-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_Tower_Offset" -Value $LeftToRightValue -PropertyType DWord | Out-Null
        Write-Verbose -Message "Setting the ""Launcher_SessionLogin_Tower_Offset"" registry key successfully."
    }
    Else
    {
        Set-ItemProperty -Path $KeyPath -Name "Launcher_SessionLogin_Tower_Offset" -Value $LeftToRightValue | Out-Null
        Write-Verbose -Message "Create the ""Launcher_SessionLogin_Tower_Offset"" registry key successfully."
    }
}
