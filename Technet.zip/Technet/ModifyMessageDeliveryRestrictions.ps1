﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Add-OSCEXMessageDeliveryRestrictions
{
	<#
		.SYNOPSIS
		Add-OSCEXMessageDeliveryRestrictions is an advanced function which can be used to add recepients to AcceptMessagesOnlyFromSendersOrMembers list.
		.DESCRIPTION
		Add-OSCEXMessageDeliveryRestrictions is an advanced function which can be used to add recepients to AcceptMessagesOnlyFromSendersOrMembers list.
		.PARAMETER DistributionGroupFilter
		Indicates the OPath filter used to filter distribution group.
		.PARAMETER RecipientFilter
		Indicates the OPath filter used to filter recipients.
		.EXAMPLE
		#Add recipient which display name is TestUser01 to the AcceptMessagesOnlyFromSendersOrMembers list of the distribution group which alias starts with "TestDG1#".
		Add-OSCEXMessageDeliveryRestrictions -DistributionGroupFilter 'Alias -like "TestDG1*"' -RecipientFilter 'DisplayName -eq "TestUser01"' -Verbose
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Filterable Properties for the -Filter Parameter
		http://technet.microsoft.com/EN-US/library/bb738155.aspx
	#>
	
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$DistributionGroupFilter,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$RecipientFilter
	)
	Process
	{
		$exRecipients = Get-Recipient -Filter $RecipientFilter -ResultSize unlimited -Verbose:$false
		if ($exRecipients -ne $null) {
			#Get distribution group
			$distributionGroups = Get-DistributionGroup -Filter $DistributionGroupFilter -ResultSize unlimited -Verbose:$false
			if ($distributionGroups -ne $null) {
				foreach ($distributionGroup in $distributionGroups) {
					$dgName = $distributionGroup.Name
					if ($pscmdlet.ShouldProcess($dgName)) {
						foreach ($exRecipient in $exRecipients) {
							if (-not ($distributionGroup.AcceptMessagesOnlyFromSendersOrMembers.Contains($($exRecipient.distinguishedName)))) {
								$verboseMsg = $Messages.AddRecipienttoAcceptMessagesOnlyFrom
								$verboseMsg = $verboseMsg -replace "Placeholder01",$($exRecipient.DisplayName)
								$verboseMsg = $verboseMsg -replace "Placeholder02",$($dgName)
								$pscmdlet.WriteVerbose($verboseMsg)
								$distributionGroup.AcceptMessagesOnlyFromSendersOrMembers.Add($($exRecipient.distinguishedName))
							} else {
								$verboseMsg = $Messages.RecipientExistedinAcceptMessagesOnlyFrom
								$verboseMsg = $verboseMsg -replace "Placeholder01",$($exRecipient.DisplayName)
								$verboseMsg = $verboseMsg -replace "Placeholder02",$($dgName)
								$pscmdlet.WriteVerbose($verboseMsg)
							}
						}
					}
					Set-DistributionGroup -Identity $distributionGroup -AcceptMessagesOnlyFromSendersOrMembers $distributionGroup.AcceptMessagesOnlyFromSendersOrMembers -Verbose:$false
				}
			} else {
				#Cannot find distribution group with specified filter
				$errorMsg = $Messages.CannotFindDG
				$errorMsg = $errorMsg -replace "Placeholder01",$DistributionGroupFilter
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				return $null
			}
		} else {
			#Cannot find distribution group with specified filter
			$errorMsg = $Messages.CannotFindUser
			$errorMsg = $errorMsg -replace "Placeholder01",$RecipientIdentity
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null
		}
	}
}

Function Remove-OSCEXMessageDeliveryRestrictions
{
	<#
		.SYNOPSIS
		Remove-OSCEXMessageDeliveryRestrictions is an advanced function which can be used to remove recepients from AcceptMessagesOnlyFromSendersOrMembers list.
		.DESCRIPTION
		Remove-OSCEXMessageDeliveryRestrictions is an advanced function which can be used to remove recepients from AcceptMessagesOnlyFromSendersOrMembers list.
		.PARAMETER DistributionGroupFilter
		Indicates the OPath filter used to filter distribution group.
		.PARAMETER RecipientFilter
		Indicates the OPath filter used to filter recipients.
		.EXAMPLE
		#Remove recipient which display name is TestDG01 from the AcceptMessagesOnlyFromSendersOrMembers list of the distribution group which alias starts with "TestDG##".
		Remove-OSCEXMessageDeliveryRestrictions -DistributionGroupFilter 'Alias -like "TestDG1*"' -RecipientFilter 'DisplayName -eq "TestDG01"' -Verbose
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Filterable Properties for the -Filter Parameter
		http://technet.microsoft.com/EN-US/library/bb738155.aspx
	#>
	
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$DistributionGroupFilter,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$RecipientFilter
	)
	Process
	{
		$exRecipients = Get-Recipient -Filter $RecipientFilter -ResultSize unlimited -Verbose:$false
		if ($exRecipients -ne $null) {
			#Get distribution group
			$distributionGroups = Get-DistributionGroup -Filter $DistributionGroupFilter -ResultSize unlimited -Verbose:$false
			if ($distributionGroups -ne $null) {
				foreach ($distributionGroup in $distributionGroups) {
					$dgName = $distributionGroup.Name
					if ($pscmdlet.ShouldProcess($dgName)) {
						foreach ($exRecipient in $exRecipients) {
							if ($distributionGroup.AcceptMessagesOnlyFromSendersOrMembers.Contains($($exRecipient.distinguishedName))) {
								$verboseMsg = $Messages.RemoveRecipientfromAcceptMessagesOnlyFrom
								$verboseMsg = $verboseMsg -replace "Placeholder01",$($exRecipient.DisplayName)
								$verboseMsg = $verboseMsg -replace "Placeholder02",$($dgName)
								$pscmdlet.WriteVerbose($verboseMsg)
								$distributionGroup.AcceptMessagesOnlyFromSendersOrMembers.Remove($($exRecipient.distinguishedName)) | Out-Null
							}  else {
								$verboseMsg = $Messages.RecipientDoesNotExistinAcceptMessagesOnlyFrom
								$verboseMsg = $verboseMsg -replace "Placeholder01",$($exRecipient.DisplayName)
								$verboseMsg = $verboseMsg -replace "Placeholder02",$($dgName)
								$pscmdlet.WriteVerbose($verboseMsg)
							}
						}
					}
					Set-DistributionGroup -Identity $distributionGroup -AcceptMessagesOnlyFromSendersOrMembers $distributionGroup.AcceptMessagesOnlyFromSendersOrMembers -Verbose:$false
				}
			} else {
				#Cannot find distribution group with specified filter
				$errorMsg = $Messages.CannotFindDG
				$errorMsg = $errorMsg -replace "Placeholder01",$DistributionGroupFilter
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				return $null
			}
		} else {
			#Cannot find distribution group with specified filter
			$errorMsg = $Messages.CannotFindRecipient
			$errorMsg = $errorMsg -replace "Placeholder01",$RecipientIdentity
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null
		}
	}
}

