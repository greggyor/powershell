<# 
.NOTES 
    Name: DailyCheck 
    Author: Stefan van der Zyl 
    Requires: PowerShell V2, Exchange 2010 Management Shell. 
    Version History: 
    1.0 - 28/03/2012 - Initial Release. 
.SYNOPSIS 
    Creates a simple HTML formatted E-Mail for some properties of your Exchange Organization.
.DESCRIPTION 
    This script collects some Information about xour Echange Environment and build a simple HTML E-Mail which can be
    send to e.g. the Exchange Administrators.
    You have just to fill in an SMTP Server and a recipient address. 
.EXAMPLE   
    [PS] C:\>.\dailyChecks.ps1 <no parameters> 
    The script does not have any parameters. 
#> 


$a = "<style>"
$a = $a + "BODY{background-color:peachpuff;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:thistle}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:palegoldenrod}"
$a = $a + "</style>"

$f = get-date | select-object datetime | ConvertTo-HTML -head $a
$b = (Get-MailboxServer) | %{Get-Mailboxdatabasecopystatus -server $_} | select-object name, status,CopyQueueLength, ReplayQueueLength, LatestFullBackupTime | ConvertTo-HTML -head $a
$c = (Get-TransportServer) | %{get-queue -server $_}| select-object identity, Status, messagecount | ConvertTo-HTML -head $a
$d = (Get-MailboxServer) | %{Test-Replicationhealth -server $_} | select-object Server, Check, Result | ConvertTo-HTML -head $a
$e = (Get-ExchangeServer) | %{Test-ServiceHealth -Server $_} | select role, RequiredServicesRunning | ConvertTo-HTML -head $a
$g = get-mailboxdatabase -status | select-object name,databasesize,availablenewmailboxspace | ConvertTo-HTML -head $a

$Output = $f + "<br/>" + $b + "<br/>" + $c + "<br/>" + $d + "<br/>" + $e + "<br/>" + $g + "<br/>"


$smtpServer = �...� 
$mailaddress = �...� 

$msg = new-object Net.Mail.MailMessage

$msg.isBodyHtml = "true"
$smtp = new-object Net.Mail.SmtpClient($smtpServer)

$msg.From = $mailaddress 
$msg.To.Add($mailaddress) 
$msg.Subject = �Daily Check 2010� 
$msg.Body = $Output
$smtp.Send($msg)