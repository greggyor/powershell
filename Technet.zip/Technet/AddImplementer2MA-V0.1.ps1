Import-Module smlets

# Manual Activity ID
$MA = 'MA121'

#Display Name of Implementer
$Implementer = "Peter Pan"

# Get Manual Activity Class
$MAclass = Get-SCSMClass -Name  System.WorkItem.Activity.ManualActivity$
#Get Manual Activity by ID
$MAObject = Get-SCSMObject -Class $MAclass -Filter "ID -eq $MA"
#Get AD User Class
$UserClass = Get-SCSMClass -Name Microsoft.AD.User$
#Get User by displayname
$User = Get-SCSMObject -Class $UserClass �Filter "DisplayName -eq $Implementer"
#Get Relationship Manual Activity - Implementer
$ImplementerRelationship = Get-SCSMRelationshipClass -Name System.WorkItemAssignedToUser$
#Create a new Relationship Object Manual Activity - User (Implementer)
New-SCSMRelationshipObject -RelationShip $ImplementerRelationship -Source $MAObject -Target $User -Bulk

Remove-Module smlets -Force