﻿Function Get-OpenFiles
{
    <#
	.SYNOPSIS
	    Gets current open shared files on file server.

	.DESCRIPTION
	    The Get-OpenFiles cmdlet gets list of current open shared files on file server.
		
	.PARAMETER Server
	    Specifies a file server. 
		
	.EXAMPLE
		PS C:\> "MyFS" | Get-OpenFiles | Format-Table Server, ID, User, LockCount, Path -AutoSize

		Server ID     User       LockCount Path
		------ --     ----       --------- ----
		MyFS   108618 MG                 0 G:\Test\Test.txt
		
	.NOTES
		Author: Michal Gajda
		Blog  : http://commandlinegeeks.com/
	#>    
	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low"
	)]
	Param
	(
	[parameter(ValueFromPipeline=$true,
		ValueFromPipelineByPropertyName=$true)]	
	[String[]]$Server = "."
	)
	Begin{}

	Process
	{
		Write-Verbose "Start OpenFiles Scan..."
		Foreach($Srv in $Server)
		{
			Try
			{
				Write-Verbose "Connecting to $Server..."
				$ADSI = [ADSI]"WinNT://$Srv/LanmanServer"
				$ConnectedStatus = $true
			} #End Try
			Catch
			{
				Write-Verbose "Can't connect to $Server. Machine is unavailable or access denied!"
				$ConnectedStatus = $false
			} #End Catch
			
			If($Srv -eq ".")
			{
				$Srv = "LocalHost"
			} #End If $Srv -eq "."
			
			If($ConnectedStatus)
			{
				Write-Verbose "Geting open files list from $Srv"			
				$Resources = $adsi.psbase.invoke("Resources") 

				$NumberOfResource = 0
				$MaxNumberOfResource = ($Resources|measure).count
				$ResourcesList = @()
				Foreach($Resource in $Resources)
				{
					Write-Progress -Activity "Geting open files list from $Srv" -Status "Completed $NumberOfResource/$MaxNumberOfResource" -PercentComplete ([int]($NumberOfResource/$MaxNumberOfResource * 100))
					Try
					{
						$ServerResources = New-Object -TypeName PSobject -Property @{ 
							Server = $Srv
							ID = $Resource.GetType().InvokeMember("Name","GetProperty",$null,$Resource,$null)
							Path = $Resource.GetType().InvokeMember("Path","GetProperty",$null,$Resource,$null)
						 	User = $Resource.GetType().InvokeMember("User","GetProperty",$null,$Resource,$null)
							LockCount = $Resource.GetType().InvokeMember("LockCount","GetProperty",$null,$Resource,$null)
						} #End New-Object PSobject
					} #End Try
					Catch
					{
						Write-Verbose $_
					} #End Catch
					$ResourcesList += $ServerResources
					
					$NumberOfResource++
				} #End ForEach $Resource in $Resources
				$ResourcesList | Select-Object * -Unique
				
			} #End If $ConnectedStatus
		} #End ForEach $Srv in $Server
	} #End Process
	
	End{}			
} #In The End :)