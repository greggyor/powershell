﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 2

$Path = Read-Host "Please input the folder location you want to search"
$Objs = @() #define an empty array		
				
Function Set-Permission
{
	#Determines whether the path exist.
	if(Test-Path $Path) #it returns TRUE($true) then go to modify block.
	{
		$folders = Get-ChildItem -Path $Path -Force | Where-Object{$_.PsIsContainer} | ForEach-Object{$_.FullName}
		foreach ($folder in $folders)
		{
			$DesktopPath = Get-ChildItem $folder -Filter desktop.ini -Force
    		if ($DesktopPath -ne $null)
    		{
        		try
				{
					$desktopACL = (Get-Item $DesktopPath.FullName -Force).GetAccessControl("Access")
         			$AclSet = New-Object System.Security.Accesscontrol.Filesystemaccessrule("administrators","Read","Deny")
         			$desktopACL.SetAccessRule($AclSet)
         			Set-Acl $DesktopPath.FullName $desktopACL 
					$Status =  "Success"
				
					#define a custom object
					$objInfo = New-Object -TypeName PSObject
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Path" -Value $DesktopPath.FullName
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Permission" -Value "Read"
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Allow/Deny" -Value Deny
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Status" -Value $Status
					$Objs += $objInfo
				}
			 	<#If the error messages displays the "Attempted to perform an unauthorized operation",
				it means the operation is unsuccessful.#>
				catch
				{
					$Status =  "Not Modified"
				
					$objInfo = New-Object -TypeName PSObject
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Path" -Value $DesktopPath.FullName
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Permission" -Value "Read"
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Allow/Deny" -Value Deny
					Add-Member -InputObject $objInfo -MemberType NoteProperty -Name "Status" -Value $Status
					$Objs += $objInfo
				}
    		}
			else
			{
				Write-Host "The desktop.ini file was not found in the $folder." -ForegroundColor Red
			}
		}
		$Objs | Format-Table -AutoSize
	}
	else
	{
		Write-Host "Cannot find this location,it does not exist." -ForegroundColor Red
	}
}

Set-Permission

