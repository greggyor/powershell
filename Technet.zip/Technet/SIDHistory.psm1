<#-----------------------------------------------------------------------------
SID History PowerShell Module v1.4
Ashley McGlone, Microsoft Premier Field Engineer
http://blogs.technet.com/b/ashleymcglone
June, 2012

LEGAL DISCLAIMER
This Sample Code is provided for the purpose of illustration only and is not
intended to be used in a production environment.  THIS SAMPLE CODE AND ANY
RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  We grant You a
nonexclusive, royalty-free right to use and modify the Sample Code and to
reproduce and distribute the object code form of the Sample Code, provided
that You agree: (i) to not use Our name, logo, or trademarks to market Your
software product in which the Sample Code is embedded; (ii) to include a valid
copyright notice on Your software product in which the Sample Code is embedded;
and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and
against any claims or lawsuits, including attorneys� fees, that arise or result
from the use or distribution of the Sample Code.
-------------------------------------------------------------------------------

SIDHistory.psm1

-------------------------------------------------------------------------------
Version 1.4
June, 2012

Functions added in this release:
Export-SIDHistoryShare
Merge-CSV

Functions modified in this release:
Convert-SIDHistoryNTFS
Export-SIDMapping
Update-SIDMapping
Get-SIDHistory

Fixes:
Removed Test-Path validation on NewReport parameter of Update-SIDMapping.
Added file validation for DomainFile parameter of Get-SIDHistory.

-------------------------------------------------------------------------------
Version 1.3
December, 2011

Converted to module for importing
-------------------------------------------------------------------------------
Version 1.2
November, 2011

Functions added in this release:
Get-SIDHistory
Remove-SIDHistory
-------------------------------------------------------------------------------
Version 1.1
October, 2011

Functions added in this release:
Export-DomainSIDs
Update-SIDMapping
-------------------------------------------------------------------------------
Version 1.0
September, 2011

Functions added in this release:
Export-SIDMapping
Convert-SIDHistoryNTFS
-------------------------------------------------------------------------------


-------------------------------------------------------------------------------
Instructions for SID history documentation:
1. Import-Module SIDHistory
2. Export-DomainSIDs
3. Export-SIDMapping
4. Update-SIDMapping
5. Open the SIDMappingUpdated.csv file.

-------------------------------------------------------------------------------
Instructions for NTFS SID history clean up:
1. Import-Module SIDHistory
2. For instructions use Get-Help -Full to read about each function:
   Get-Help Convert-SIDHistoryNTFS -Full
3. Export-SIDMapping
4. Review the report files
5. Convert-SIDHistoryNTFS \\server\share\path -WhatIf
6. Review the report files
7. Convert-SIDHistoryNTFS \\server\share\path
8. Review the report files
9. Confirm access with affected users/groups
-----------------------------------------------------------------------------#>


function Export-SIDMapping {
    <#
    .SYNOPSIS
    This function builds two Active Directory SIDhistory reports.
    .DESCRIPTION
    This function queries Active Directory for SID history in order to build a SID mapping file for use with the ADMT to do security translation, especially in situations where the ADMT database has been lost.  In addition to the mapping file it also generates a full SID history report for viewing in Excel.
    .EXAMPLE
    Export-SIDMapping
    .NOTES
    This function must be run from a machine that has the Active Directory module for PowerShell installed (ie. Windows 7 with RSAT or Windows Server 2008 R2).  You must also have either a Windows Server 2008 R2 domain controller, or an older domain controller with the Active Directory Management Gateway Service (AD Web Service) installed.  For more information on ADWS see:
    http://blogs.technet.com/b/ashleymcglone/archive/2011/03/17/step-by-step-how-to-use-active-directory-powershell-cmdlets-against-2003-domain-controllers.aspx
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    .LINK
    http://blogs.technet.com/b/ashleymcglone/archive/2011/03/17/step-by-step-how-to-use-active-directory-powershell-cmdlets-against-2003-domain-controllers.aspx
    #>

    #Query SID history, current SID, and related fields from AD
    $ADQuery = Get-ADObject -LDAPFilter "(sIDHistory=*)" -Property objectClass, `
        samAccountName, DisplayName, objectSid, sIDHistory, distinguishedname

    #Create a full SID History report file for reference in Excel
    $ADQuery |
    Select-Object * -ExpandProperty sIDHistory |
    Select-Object objectClass, @{name="OldSID";expression={$_.Value}}, `
        @{name="NewSID";expression={$_.objectSID}}, samAccountName, DisplayName, `
        DistinguishedName, @{name="DateTimeStamp";expression={Get-Date -Format g}} |
    Export-CSV SIDReport.csv -NoTypeInformation

    #Create a SID Mapping text file for use with ADMT
    Get-ADObject -LDAPFilter "(sIDHistory=*)" -Property objectSID, sIDHistory |
    Select-Object * -ExpandProperty sIDHistory |
    Select-Object @{name="OldSID";expression={$_.Value}}, `
        @{name="NewSID";expression={$_.objectSID}} |
    Export-CSV SIDMap0.csv -NoTypeInformation

    #Peel out the quotes from the mapping file, because ADMT does not like those.
    Get-Content .\SIDMap0.csv | ForEach-Object {$_.Replace("`"","")} |
        Set-Content .\SIDMap.csv
    Remove-Item .\SIDMap0.csv

    "Output complete:"
    "SIDReport.csv  - full SID History report for reference in Excel"
    "SIDMap.csv     - file for use with ADMT to do security translation"

    #   ><>
}






function Parse-SDDL ($SDDLString) {
    #http://msdn.microsoft.com/en-us/library/aa374928.aspx
    # ace_type;ace_flags;rights;object_guid;inherit_object_guid;account_sid
    # 0       ;1        ;2     ;3          ;4                  ;5
    # 0       ;ID       ;2     ;3          ;4                  ;SID
    # O:S-1-5-21-124525005-000250630-1543110021-060600G:DUD:AI(A;;FA;;;S-1-5-21-3005000230-335460600-2062000006-1000)(A;OICIIO;GA;;;S-1-5-21-3005000230-335460600-2062000006-1000)(A;OICIID;FA;;;SY)(A;OICIID;FA;;;BA)(A;OICIID;FA;;;S-1-5-21-124525005-000250630-1543110021-060600)

    # Split the SDDL on the characer: (
    # Check index 0 for an owner SID
    # Process indexes 1 to end
    #   Split on character: ;
    #   If index 1 contains "ID" then ignore because inherited
    #   If index 5 contains a SID then process it
    #     If SID is in mapping file then replace
    #   If SDDL changed, then
    #     Re-Join SDDL text
    #     Commit SDDL change

    $SDDLSplit = $SDDLString.Split("(")
    $SDDLChanged = $false

    For ($i=1;$i -lt $SDDLSplit.Length;$i++) {
        $ACLSplit = $SDDLSplit[$i].Split(";")
        If ($ACLSplit[1].Contains("ID")) {
            "Inherited" | Out-File -FilePath $LogFile -Append
        } Else {
            $ACLEntrySID = $null
            # Remove the trailing ")"
            $ACLEntry = $ACLSplit[5].TrimEnd(")")
            $ACLEntrySIDMatches = [regex]::Matches($ACLEntry,"(S(-\d+){2,8})")
            $ACLEntrySIDMatches | ForEach-Object {$ACLEntrySID = $_.value}
            If ($ACLEntrySID) {
                $ACLEntrySID | Out-File -FilePath $LogFile -Append
                If ($SIDMapHash.Contains($ACLEntrySID)) {
                    "$($SIDMapHash.($ACLEntrySID)) new SID" | Out-File -FilePath $LogFile -Append
                    $SDDLSplit[$i] = $SDDLSplit[$i].Replace($ACLEntrySID,$SIDMapHash.($ACLEntrySID))
                    $SDDLChanged = $true

                    #Arrange the data we want into a custom object
                    $objTemp = New-Object PSObject -Property @{
                         # Parse out servername from the path, assuming it is in UNC format: \\servername\share\folder
                         ServerName=$StartPath.Substring(2,$StartPath.Substring(2,$StartPath.Length-3).IndexOf("\"));
                         StartPath=$StartPath;
                         Folder=$folder.FullName;
                         OldSID=$ACLEntrySID;
                         OldDomainSID=$ACLEntrySID.Substring(0,$ACLEntrySID.LastIndexOf("-"));
                         NewSID=$SIDMapHash.($ACLEntrySID);
                         NewDomainSID=$SIDMapHash.($ACLEntrySID).Substring(0,$SIDMapHash.($ACLEntrySID).LastIndexOf("-"));
                         ACLType="NTFS";
                         DateTimeStamp=Get-Date -Format g;
                        }
                    #Use array addition to add the new object to our report array
                    $script:report += $objTemp

                } Else {
                    "No SID history entry" | Out-File -FilePath $LogFile -Append
                }
            } Else {
                "Not inherited - No SID to translate" | Out-File -FilePath $LogFile -Append
            }
        }
    }

    If ($SDDLChanged) {
        $NewSDDLString = $SDDLSplit -Join "("
        "New SDDL string: $NewSDDLString" | Out-File -FilePath $LogFile -Append
        return $NewSDDLString
    } Else {
        "SDDL did not change." | Out-File -FilePath $LogFile -Append
        return $null
    }

}





function Convert-SIDHistoryNTFS {
    <#
    .SYNOPSIS
    This function replaces ACL SID entries based on a mapping file.
    .DESCRIPTION
    This function begins at the specified path and recursively scans all subfolder ACL ACE entries for SID matches in the mapping file specified.  Where non-inherited matches are found they are replaced with the mapping file SID value from the second column.
    .PARAMETER StartPath
    Specifies the root folder where the SID translation will begin.
    May be a local or UNC, absolute or relative file path.
    May be any NTFS file share platform (Windows, NAS, etc.).
    .PARAMETER MapFile
    CSV SID mapping file containing OldSID,NewSID entries.
    Looks for SIDMap.csv in the current folder if not specified.
    Use the function Export-SIDMapping to create this file.
    .PARAMETER LogFile
    Text log file for verbose output
    .PARAMETER ReportFile
    CSV log file documenting all changed SIDs and paths
    .PARAMETER WhatIf
    Runs without making any changes.  Logs what would change.
    .EXAMPLE
    Convert-SIDHistoryNTFS -StartPath \\fileserver\sharename\ -WhatIf
    .EXAMPLE
    Convert-SIDHistoryNTFS -StartPath \\fileserver\sharename\
    .EXAMPLE
    Convert-SIDHistoryNTFS -StartPath D:\folder\ -WhatIf
    .EXAMPLE
    Convert-SIDHistoryNTFS -StartPath D:\folder\
    .NOTES
    Script must be run with permissions to edit security on all subfolders in the path specified.
    This script may make changes to your environment when run without the WhatIf switch.
    Some backup programs treat ACL changes as a backup trigger.  Coordinate this with your backup administrator.
    .INPUTS
    Script takes input from a SID mapping file generated by the function "Export-SIDMapping".  This must be run first.
    .OUTPUTS
    LogFile is a txt file with a verbose record of everything found and changed.
    .OUTPUTS
    ReportFile is a CSV listing all affected folders, old SID, and new SID.  Run with the -WhatIf switch to create this report as an audit of SID history without making changes.
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    #>

    Param (
        [parameter(Mandatory=$true)]
        [string]
        [ValidateScript({Test-Path -Path $_})]
        $StartPath,
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $MapFile = ".\SIDMap.csv",
        [parameter()]
        [string]
        $LogFile = ".\NTFS_SID_Translation_Report_"+(Get-Date -UFormat %Y%m%d%H%M%S)+".txt",
        [parameter()]
        [string]
        $ReportFile = ".\NTFS_SID_Translation_Report_"+(Get-Date -UFormat %Y%m%d%H%M%S)+".csv",
        [parameter()]
        [switch]
        $WhatIf
    )

    <#-----------------------------------------------------------------------------
    Import mapfile.

    Get recursive folder list.

    For each folder
      Get-ACL | function for SDDL parsing
      If -not WhatIf then commit SDDL change
      Log output 
    -----------------------------------------------------------------------------#>

    # === BEGIN SETUP ===

    # Initiate log file
    Get-Date | Out-File -FilePath $LogFile

    If (-not $WhatIf) {
        ""
        "This script will update ACL entries recursively in the StartPath specified."
        "This could trigger a backup of all updated files."
        "Run the command using the -WhatIf switch first."
        $input = Read-Host "Are you sure you wish to proceed? (Y/N)"
        If ($input -eq "") { return } Else {
            If ($input.substring(0,1) -ne "y") { return }
        }
        "Security translation is live and changes will be committed." | Out-File -FilePath $LogFile -Append
    } Else {
        "AUDIT MODE: Security translation is not live and changes will not be committed." | Out-File -FilePath $LogFile -Append
    }

    "Log file is $LogFile" | Out-File -FilePath $LogFile -Append
    "Report file is $ReportFile" | Out-File -FilePath $LogFile -Append
    "Map file is $MapFile" | Out-File -FilePath $LogFile -Append
    "StartPath is $StartPath" | Out-File -FilePath $LogFile -Append
    "WhatIf is $WhatIf" | Out-File -FilePath $LogFile -Append

    # === END SETUP ===

    # === BEGIN BODY ===

    # Import SID mapping file
    # File format is:
    # OldSID,NewSID
    $SIDMapHash = @{}
    Import-CSV $MapFile | ForEach-Object {$SIDMapHash.Add($_.OldSID,$_.NewSID)}
    "SID mapping file imported." | Out-File -FilePath $LogFile -Append

    "" | Out-File -FilePath $LogFile -Append
    "Beginning security enumeration." | Out-File -FilePath $LogFile -Append
    "" | Out-File -FilePath $LogFile -Append

    # Initialize CSV report output
    $script:report = @()

    write-progress -activity "Collecting folders to scan..." -Status "Progress: " -PercentComplete 0

    # Get folder list for security translation
    # Start by grabbing the root folder itself
    # Add the folders in this order so that we hit the root first
    $folders = @()
    $folders += Get-Item $StartPath
    $subfolders = Get-Childitem $StartPath -recurse | Where-Object {$_.PSIsContainer -eq $true}
    # We don't want to add a null object to the list if there are no subfolders
    If ($subfolders) {$folders += $subfolders}
    $i = 0
    $FolderCount = $folders.count

    ForEach ($folder in $folders) {

        "=== Next Folder ===" | Out-File -FilePath $LogFile -Append

        write-progress -activity "Scanning folders" -CurrentOperation $folder.FullName -Status "Progress: " -PercentComplete ($i/$FolderCount*100)
        $i++

        $acl = Get-ACL -Path $folder.FullName
        $acl.path | Out-File -FilePath $LogFile -Append
        $acl.SDDL | Out-File -FilePath $LogFile -Append
        $acl.access | ForEach-Object {$_ | Out-File -FilePath $LogFile -Append}
        $NewSDDL = Parse-SDDL $acl.SDDL
        If ($NewSDDL -ne $null) {
            If (-not $WhatIf) {
                $acl.SetSecurityDescriptorSddlForm($NewSDDL)
                Set-Acl -Path $acl.path -ACLObject $acl
                "SDDL updated." | Out-File -FilePath $LogFile -Append
            }
        }
        "" | Out-File -FilePath $LogFile -Append
    }

    # === END BODY ===

    ""
    $script:report | Select-Object ServerName, StartPath, Folder, OldSID, OldDomainSID, NewSID, NewDomainSID, ACLType, DateTimeStamp | Export-CSV $ReportFile -NoTypeInformation
    "Find CSV report of security translation here:"
    $ReportFile

    "" | Out-File -FilePath $LogFile -Append

    Get-Date | Out-File -FilePath $LogFile -Append
    "Find complete log file here:"
    $LogFile
    ""

}






function Export-DomainSIDs {
    <#
    .SYNOPSIS
    This function creates a list of domain SIDs for the forest and trusts.
    .DESCRIPTION
    This function attempts to document all domain SIDs in the forest and across trusts.  Use the output to identify source domains for SID history.  Note that there may be domains in SID history which no longer exist and no longer have discoverable trusts to identify them.  The function follows these steps:
    - Gets the SID of the current domain where the script is running.
    - For each domain in the forest it gets a list of all trusted domains and their SIDs.
    - Gets all forest trusts and their domain SIDs.
    - For each trusted forest it gets all of their trusted domain SIDs.
    For best results run this function from each root domain across all forest trusts, then manually consolidate the results into a single CSV file and eliminate any duplicates.
    .PARAMETER File
    CSV output file containing Domain SID entries.
    If not specified defaults to .\DomainSIDs.csv
    .EXAMPLE
    Export-DomainSIDs
    .EXAMPLE
    Export-DomainSIDs -File C:\output\DomainSIDsForMyForest.csv
    .NOTES
    This function uses .NET 3.0 and WMI to collect all data.  Therefore it will run in legacy environments without the need for the PowerShell ActiveDirectory module.
    Forest trusts from the root domain will be included.
    External trusts will be included for any domain(s) inside the current forest.
    External trusts for remote trust partners will not be included.
    Trust discovery is limited to one hop due to permissions and lack of transitivity beyond one hop.
    Stale trusts will cause timeouts and extend the script run time, but it will finish.
    Use the Active Directory Topology Diagrammer (linked below) to draw a picture of all domains and trusts in the forest.
    .INPUTS
    Function has no inputs.
    .OUTPUTS
    Function creates a CSV file containing the FQDN and SID of each domain that it finds in the forest and across trusts.
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    .LINK
    http://www.microsoft.com/download/en/details.aspx?id=13380
    #>

    Param (
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $File = ".\DomainSIDs.csv"
    )

    # We know there will be some errors due to offline trust partners,
    # access denied to remote domains, and popping duplicate entries
    # into the hash table.
    $ErrorActionPreference = "SilentlyContinue"

    $DomainSIDList = @{}

    # Get my own local domain SID
    Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Domain"
    $MyDomainSID = gwmi -namespace root\MicrosoftActiveDirectory -class Microsoft_LocalDomainInfo | Select-Object DNSname, SID
    Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Domain" -Progress $MyDomainSID.DNSname
    $DomainSIDList.Add($MyDomainSID.DNSname, $MyDomainSID.SID)

    # Get list of all domains in local forest
    $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()

    # For each domain in local forest use WMI to get trust list
    # Use WMI, because .NET Domain class GetAllTrustRelationships method does not include SID (although the forest class version does)
    Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Forest Domain Trusts"
    $forest.Domains | ForEach-Object {
            Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Forest Domain Trusts" -Progress "Domain: $_.Name"
            gwmi -namespace root\MicrosoftActiveDirectory -class Microsoft_DomainTrustStatus -computername $_.Name |
             ForEach-Object {
                Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Forest Domain Trusts" -Progress "Trust: $_.TrustedDomain"
                $DomainSIDList.Add($_.TrustedDomain, $_.SID)
             }
        }

    # Get forest trusts from .NET
    Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Forest Trusts"
    $trusts = $forest.GetAllTrustRelationships()
    ForEach ($trust in $trusts) {
      $trust.TrustedDomainInformation |
        ForEach-Object {
            Write-Progress -Activity "Collecting Domain SIDs" -Status "Current Forest Trusts" -Progress "Trust: $_.DnsName"
            $DomainSIDList.Add($_.DnsName, $_.DomainSid)

            # Get all forest trusts from remote trusted forests
            Write-Progress -Activity "Collecting Domain SIDs" -Status "Remote Forest Trusts"
            $context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Forest",$_.DnsName)
            $remoteforest = [System.DirectoryServices.ActiveDirectory.Forest]::GetForest($context)
            $remotetrusts = $remoteforest.GetAllTrustRelationships()
            ForEach ($remotetrust in $remotetrusts) {
              $remotetrust.TrustedDomainInformation | 
                ForEach-Object {
                    Write-Progress -Activity "Collecting Domain SIDs" -Status "Remote Forest Trusts" -Progress "Trust: $_.DnsName"
                    $DomainSIDList.Add($_.DnsName, $_.DomainSid)
                }
            }
        }
    }

    # Dump the list to a CSV file after sorting and naming the columns
    $DomainSIDList.GetEnumerator() | Sort-Object Key | Select-Object @{name="Domain";expression={$_.Key}}, @{name="SID";expression={$_.Value}} | Export-CSV $File -NoTypeInformation

    ""
    "See the output file for results: $File"
    ""
}




Function Update-SIDMapping {
    <#
    .SYNOPSIS
    This function inserts a SourceDomain column into the SIDReport.csv file.
    .DESCRIPTION
    This function identifies the old domain name where the SID history originated.
    Then it updates the SIDReport.CSV file.  This makes the report more meaningful.
    .PARAMETER OldReport
    Path and name of the SIDReport.CSV file generated by the function Export-SIDMapping.
    Defaults to: .\SIDReport.csv
    .PARAMETER NewReport
    Path and name for the updated report file.
    Defaults to: .\SIDReportUpdated.csv
    .PARAMETER DomainFile
    Path and name of the DomainSIDs.csv file generated by the function Export-DomainSIDs.
    Defaults to: .\DomainSIDs.csv
    .EXAMPLE
    Update-SIDMapping
    .EXAMPLE
    Update-SIDMapping -OldReport "C:\SIDReport.csv" -NewReport "C:\SIDReportUpdated.csv" -DomainFile "C:\DomainSIDs.csv"
    .NOTES
    Prior to calling this function you need to run Export-DomainSIDs and Export-SIDMapping.
    .INPUTS
    SIDReport.csv
    .INPUTS
    DomainSIDs.csv
    .OUTPUTS
    SIDReportUpdated.csv
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    #>
    
    Param(
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $OldReport = ".\SIDReport.csv",
        [parameter()]
        [string]
        $NewReport = ".\SIDReportUpdated.csv",
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $DomainFile = ".\DomainSIDs.csv"
    )

    # Read in the old SID History Report file and append a new column to hold the SourceDomain update
    $SIDReport = Import-CSV $OldReport | Select-Object *, OldDomain, NewDomain, OldDomainSID, NewDomainSID

    # Read in the DomainSID CSV file and store it in a hash table
    $DomainSIDsHash = @{}
    Import-CSV $DomainFile | ForEach-Object {$DomainSIDsHash.Add($_.SID,$_.Domain)}

    # Process each line of the SID History Report file
    # Parse out the domain portion of the OldSID column
    # Match that to the domain SID in the hash table
    # Update the SourceDomain column with the domain name
    ForEach ($row in $SIDReport) {
        $row.OldDomain = $DomainSIDsHash.Item($row.OldSID.Substring(0,$row.OldSID.LastIndexOf("-")))
        $row.NewDomain = $DomainSIDsHash.Item($row.NewSID.Substring(0,$row.NewSID.LastIndexOf("-")))
        $row.OldDomainSID = $row.OldSID.Substring(0,$row.OldSID.LastIndexOf("-"))
        $row.NewDomainSID = $row.NewSID.Substring(0,$row.NewSID.LastIndexOf("-"))
    }

    # Write out the new SID History Report file and insert the SourceDomain column before the OldSID column
    $SIDReport | Select-Object ObjectClass, OldDomain, NewDomain, OldDomainSID, NewDomainSID, OldSID, NewSID, samAccountName, DisplayName, DistinguishedName, DateTimeStamp | Export-CSV $NewReport -NoTypeInformation
    
    ""
    "Updated SID History Report is located here: $NewReport"
    ""
}






function Remove-SIDHistory {
    <#
    .SYNOPSIS
    This function removes sIDHistory attribute entries for Active Directory objects.
    .DESCRIPTION
    This function retrieves an Active Directory object by distinguishedName and then removes the sIDHistory entry specified.
    .PARAMETER DistinguishedName
    Specifies the Active Directory object for which SID history will be removed.
    .PARAMETER SID
    Specifies the individual sIDHistory entry to be removed.
    .EXAMPLE
    Remove-SIDHistory -DistinguishedName "cn=user1,ou=department,dc=domain,dc=com" -SID S-1-5-21-2999376440-943217962-1153441346-1447
    .EXAMPLE
    Get-SIDHistory -samAccountName user1 | Remove-SIDHistory
    The easiest way to use Remove-SIDHistory is by piping the output from Get-SIDHistory.
    .EXAMPLE
    Get-SIDHistory -samAccountName user1 | Remove-SIDHistory -WhatIf
    Use the WhatIf parameters for testing.
    .EXAMPLE
    Get-SIDHistory -samAccountName user1 | Remove-SIDHistory -Confirm:$true
    Use the Confirm parameters for testing.
    .EXAMPLE
    Get-SIDHistory -MemberOf TestGroup | Remove-SIDHistory | Export-CSV removed.csv
    .NOTES
    Please note that removing SID history may cause significant impact to users if resource ACLs have not been migrated.
    Review the ADMT Guide and make sure all migration steps have been completed.
    As a backout plan make sure there is a verified system state backup from two DCs per domain.
    Use the WhatIf and/or Confirm parameters for testing.
    Use Export-SIDHistory to document all SID history in the environment before removing it.
    .INPUTS
    Function takes two mandatory parameters: DistinguishedName and SID.
    .OUTPUTS
    This script outputs three properties: DateModified, Status, DistinguishedName, SID.
    Pipe this output to a file or CSV for documentation of the change.
    Use the output for troubleshooting the specific time of the change if users are impacted.
    PS> Get-SIDHistory -MemberOf TestGroup | Remove-SIDHistory | Export-CSV removed.csv
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    .LINK
    Get-SIDHistory
    #>
    [CmdletBinding(SupportsShouldProcess=$true,
                   ConfirmImpact="Low")]
    Param (
        [parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [String]
        $DistinguishedName,
        [parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [String]
        $SID
    )

    Begin{}

    Process{
        #Purge a single sIDHistory entry for the specified distinguishedName
        Set-ADObject -Identity $DistinguishedName -Remove @{sIDHistory=$SID}
        1 | select-object @{name="DateModified";expression={Get-Date}}, @{name="Status";expression={"Removed"}}, @{name="DistinguishedName";expression={$DistinguishedName}}, @{name="SID";expression={$SID}}
    }

    End{}

}




function Get-SIDHistory {
    <#
    .SYNOPSIS
    This function retrieves sIDHistory attribute entries for Active Directory objects.
    .DESCRIPTION
    This function retrieves sIDHistory attribute entries for Active Directory objects.  Parameter switches can be used individually or in combination to shape the Active Directory query to target specfic objects.
    If an object has multiple sIDHistory entries it is not necessary to target all of them at once.  The DomainName and DomainSID parameters can retrieve specific values while ignoring others.  See the parameter help for more information.
    .PARAMETER DomainSID
    This is a string representing the domain portion of the sIDHistory entries to be returned.
    Example:
      -DomainSID S-1-5-21-2999376440-943117962-1153441346
    .PARAMETER DomainName
    This is the Fully Qualified Domain Name (FQDN) of the SID history domain to be retrieved.  When using this parameter you must supply a DomainSIDs.csv file created by the function Export-DomainSIDs.  Specify the path to the file using the switch DomainFile.  See the full help for Export-DomainSIDs for more information.
    .PARAMETER DomainFile
    Specifies the path to the DomainSIDs.csv file required by the DomainName parameter.  If omitted this parameter defaults to ".\DomainSIDs.csv".  This parameter has no effect if the DomainName parameter is omitted.  See the full help for Export-DomainSIDs for more information.
    .PARAMETER SamAccountName
    Specific user name, group name, or computer name.
    .PARAMETER MemberOf
    Specifies the name of a group to query for members.
    Note that this only returns users who are direct members of the group.
    It does not return nested groups or nested group membership.
    .PARAMETER SearchBase
    Specifies an Active Directory path under which to search.  Defaults to the root of the current domain.
      -SearchBase "ou=mfg,dc=noam,dc=corp,dc=contoso,dc=com"
    .PARAMETER SearchScope
    Specifies the scope of an Active Directory search. Possible values for this parameter are:
      Base or 0
      OneLevel or 1
      Subtree or 2
    A Base query searches only the current path or object.
    A OneLevel query searches the immediate children of that path or object.
    A Subtree query searches the current path or object and all children of that path or object.
    .PARAMETER ObjectClass
    This specifies the Active Directory ObjectClass for the query.  Valid options are:
      user
      computer
      group
    .EXAMPLE
    Get-SIDHistory
    .EXAMPLE
    Get-SIDHistory -SamAccountName ashleym
    .EXAMPLE
    Get-SIDHistory -DomainName fun.wingtiptoys.local -DomainFile DomainSIDs.csv
    .EXAMPLE
    Get-SIDHistory �DomainName wingtiptoys.com
    .EXAMPLE
    Get-SIDHistory �DomainName wingtiptoys.com �SamAccountName ashleym
    .EXAMPLE
    Get-SIDHistory �DomainSID "S-1-5-21-2371126157-4032412735-3953120161"
    .EXAMPLE
    Get-SIDHistory �ObjectClass group
    .EXAMPLE
    Get-SIDHistory �SearchBase "OU=Sales,DC=contoso,DC=com" -SearchScope onelevel
    .EXAMPLE
    Get-SIDHistory �ObjectClass user �SearchBase "OU=Sales,DC=contoso,DC=com" 
    .EXAMPLE
    Get-SIDHistory �MemberOf MigratedUsers
    .EXAMPLE
    Get-SIDHistory | Measure-Object
    Display count of all SID history entries.
    .EXAMPLE
    Get-SIDHistory -ObjectClass user | Measure-Object
    Display count of all user SID history entries.
    Note that this is not a user count but a SID history count.  It is possible for accounts to have multiple SID history entries.
    .NOTES
    This function is quite similar to Get-ADObject except for these two features:
      1. It uses ExpandProperty to guarantee a single row for each sIDHistory entry.
      2. It can selectively query sIDHistory based on a domain name.
    Note that it is possible to construct a query of mutually exclusive criteria which will give an empty result.
    For Example:
     Get-SIDHistory -SamAccountName AccountingUsers -ObjectClass user
    In this example the query is looking for a group but specifying the wrong object class.
    .INPUTS
    Takes a combination of search filters.
    .OUTPUTS
    Returns distinguishedName and sIDHistory entries matching the criteria.
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    .LINK
    Get-SIDHistory
    .LINK
    Export-DomainSIDs
    #>
    [CmdletBinding(DefaultParameterSetName="DomainCSV")]
    Param (
        [parameter(ParameterSetName="DomainCSV")]
        [string]
        $DomainName,
        [parameter(ParameterSetName="DomainCSV")]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $DomainFile = ".\DomainSIDs.csv",
        [parameter(ParameterSetName="DomainSID")]
        [string]
        $DomainSID,
        [parameter()]
        [string]
        [ValidateScript({(Get-ADObject -Filter 'SamAccountName -eq $_')})]
        $SamAccountName,
        [parameter()]
        [string]
        [ValidateScript({(Get-ADGroup $_)})]
        $MemberOf,
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path "AD:$_"})]
        $SearchBase = (Get-ADDomain).DistinguishedName,
        [parameter()]
        [string]
        [ValidateSet("Base", "OneLevel", "Subtree", "0", "1", "2")]
        $SearchScope = "subtree",
        [parameter()]
        [string]
        [ValidateSet("computer", "user", "group")]
        $ObjectClass
    )

    # Validate that the domain name passed actually exists in the csv file.
    If ($DomainName) {
        # Validate that the DomainFile CSV actually exists
        If (Test-Path $DomainFile) {
            $DomainSIDsHash = @{}
            Import-CSV $DomainFile | ForEach-Object {$DomainSIDsHash.Add($_.Domain,$_.SID)}
            If (-not ($DomainSIDsHash.Item($DomainName))) {
                Write-Host "DomainName ($DomainName) does not exist in DomainFile ($DomainFile)." -BackgroundColor Black -ForegroundColor Red
                break
            }
        } Else {
            Write-Host "Cannot find DomainFile ($DomainFile)." -BackgroundColor Black -ForegroundColor Red
            break
        }
    }

    # This is the core filter telling AD to return only entries with SID history.
    $Filter = 'sidHistory -like "*"'
    
    # Modify the filter based on parameters passed.  These are cumulative.
    If ($SamAccountName) {$Filter += ' -and samAccountName -eq "' + $SamAccountName + '"'}
    If ($ObjectClass) {$Filter += ' -and objectClass -eq "' + $ObjectClass + '"'}
    If ($MemberOf) {$Filter += ' -and MemberOf -eq "' + (Get-ADGroup $MemberOf).DistinguishedName + '"'}

    # This is the base query which we will modify according to the parameters passed.
    $QueryString = "Get-ADObject -Filter '$Filter' -Property sidHistory -SearchBase ""$SearchBase"" -SearchScope ""$SearchScope"" | Select-Object * -ExpandProperty sidHistory"

    # If specifid, then filter the sIDHistory entries by domain.
    # AccountDomainSid is an attribute of the SID object.  We'll filter on this.
    # http://msdn.microsoft.com/en-us/library/system.security.principal.securityidentifier.aspx
    If ($DomainName) {$QueryString += ' | Where-Object {$_.AccountDomainSid -eq "' + $DomainSIDsHash.Item($DomainName) +'"}'}
    If ($DomainSID) {$QueryString += ' | Where-Object {$_.AccountDomainSid -eq "' + $DomainSID +'"}'}

    # Structure the output properties to match the input properties for Remove-SIDHistory.
    # The "Value" property holds the sIDHistory entires split out by the ExpandProperty parameter.
    $QueryString += ' | Select-Object DistinguishedName, @{name="SID";expression={$_.Value}}'

    # The big finish... run the query.
    Invoke-Expression $QueryString
}




function Export-SIDHistoryShare {
    <#
    .SYNOPSIS
    This function enumerates shares on a server and then generates a CSV file documenting SID history instances in ACEs on the share ACLs.
    .DESCRIPTION
    This function enumerates shares on a server and then generates a CSV file documenting SID history instances in ACEs on the share ACLs.
    The output format of the CSV matches the NTFS CSV report so that they can be rolled up into the same database table.
    .PARAMETER ComputerName
    Specifies the Windows server where shares, ACLs, and ACEs will be scanned for SID history.
    .PARAMETER MapFile
    CSV SID mapping file containing OldSID,NewSID entries.
    Looks for SIDMap.csv in the current folder if not specified.
    Use the function Export-SIDMapping to create this file.
    .PARAMETER ReportFile
    CSV log file documenting all SID history ACEs on shares
    .EXAMPLE
    Export-SIDHistoryShare -ComputerName FileServer01
    .NOTES
    Script must be run with permissions to view security on all shares on the server, otherwise data returned will be incomplete.
    This script makes no changes to your environment.
    As this script requires WMI it will not work against NAS servers.
    .INPUTS
    Script takes input from a SID mapping file generated by the function "Export-SIDMapping".  This must be run first.
    .OUTPUTS
    ReportFile is a CSV listing shares, old SID, and new SID.  Note that only shares with SID history entries will be reported.
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    .LINK
    http://blogs.technet.com/b/heyscriptingguy/archive/2011/11/26/use-powershell-to-find-out-who-has-permissions-to-a-share.aspx
    #>

    Param (
        [parameter(Mandatory=$true)]
        [string]
        $ComputerName,
        [parameter()]
        [string]
        [ValidateScript({Test-Path -Path $_ -PathType Leaf})]
        $MapFile = ".\SIDMap.csv",
        [parameter()]
        [string]
        $ReportFile = ".\Share_SID_History_Report_"+(Get-Date -UFormat %Y%m%d%H%M%S)+".csv"
    )

    # Import SID mapping file
    # File format is:
    # OldSID,NewSID
    $SIDMapHash = @{}
    Import-CSV $MapFile | ForEach-Object {$SIDMapHash.Add($_.OldSID,$_.NewSID)}

    # Initialize CSV report output
    $Report = @()
    # Get the list of shares
    $Shares = Get-WmiObject Win32_Share -ComputerName $ComputerName -Filter "Caption <> 'Remote IPC' and Caption <> 'Remote Admin'"
    ForEach ($Share in $Shares) {
        # Get the ACEs of each share
        # This generates errors for some shares like C$; all others work fine.
        $query = "Associators of {win32_LogicalShareSecuritySetting='$($Share.name)'} Where resultclass = win32_sid"
        $gwmi  = Get-WmiObject -Query $query -ComputerName $ComputerName -ErrorAction:SilentlyContinue | Where-Object {$_.SidLength -gt 16}
        # Only proceed if the query returned any results
        If ($gwmi) {
            ForEach ($ACE in $gwmi) {
                Write-Progress -Activity "Scanning Share ACEs" -Status $Share.Name -CurrentOperation $ACE.SID
                If ($SIDMapHash.Contains($ACE.SID)) {

                    # Break out the share type
                    Switch ($Share.Type) {
                        0          {$ACLType = "Share File"};
                        2147483648 {$ACLType = "Share File"};
                        1          {$ACLType = "Share Printer"};
                        2147483649 {$ACLType = "Share Printer"};
                        Default    {$ACLType = "Share Other"}
                    }

                    #Arrange the data we want into a custom object
                    $objTemp = New-Object PSObject -Property @{
                         # Parse out servername from the path, assuming it is in UNC format: \\servername\share\folder
                         ServerName=$ComputerName;
                         StartPath="\\$($ComputerName)\$($Share.name)";
                         Folder="\\$($ComputerName)\$($Share.name)";
                         OldSID=$ACE.SID;
                         OldDomainSID=$ACE.SID.Substring(0,$ACE.SID.LastIndexOf("-"));
                         NewSID=$SIDMapHash.($ACE.SID);
                         NewDomainSID=$SIDMapHash.($ACE.SID).Substring(0,$SIDMapHash.($ACE.SID).LastIndexOf("-"));
                         ACLType=$ACLType;
                         DateTimeStamp=Get-Date -Format g;
                        }
                    #Use array addition to add the new object to our report array
                    $Report += $objTemp
                } Else {
                    # SID was not found in SID history map file
                }
            }
       } 
        
       # $Report += $gwmi |
       #   Select-Object @{Name="ServerName";Expression={$ComputerName}}, @{Name="Share";Expression={$Share.Name}}, @{Name="Type";Expression={ Switch ($Share.Type) {0 {"File"}; 1 {"Printer"}; Default {"Other"}} }}, ReferencedDomainName, AccountName, SID, SidLength
    }

    $Report | Select-Object ServerName, StartPath, Folder, OldSID, OldDomainSID, NewSID, NewDomainSID, ACLType, DateTimeStamp | Export-CSV $ReportFile -NoTypeInformation
    "`nFind CSV report of share SID history here:`n$ReportFile`n"

}



function Merge-CSV {
    <#
    .SYNOPSIS
    Combine all CSV files in a folder to a single file.
    .DESCRIPTION
    This function lists all CSV files in the specified path and then rolls them
    up into a single CSV file using the specified prefix as the file name.
    The intention of this function is that you can use it to roll up multiple CSV
    SID history ACL reports into a single file which can then be imported into a
    database for analysis.
    .PARAMETER Path
    Path to the folder where the CSV files reside.
    Defaults to the current folder.
    .PARAMETER Prefix
    This string will be prepended to the output file name.
    For example:  ACL_SID_History_20120405101500.csv
    Defaults to "ACL_SID_History".
    .EXAMPLE
    Merge-CSV
    .EXAMPLE
    Merge-CSV -Path "C:\Working Folder\Output Files"
    .EXAMPLE
    Merge-CSV -Prefix "All_SID_History"
    .EXAMPLE
    Merge-CSV -Path "C:\Working Folder\Output Files" -Prefix "All_SID_History"
    .NOTES
    The function automatically excludes previous generations of the combined CSV file as long as the prefix is the same as the one specified.
    Assumptions:
    - CSV files do not have type information row.
    - All CSV files share the same schema (column layout).
    .INPUTS
    Function takes optional Path and Prefix switches as described in the full help.
    .OUTPUTS
    The output file of combined CSVs will be created in the same path as the combined files.
    .LINK
    http://blogs.technet.com/b/ashleymcglone
    #>

    Param (
        [parameter()]
        [string]
        $Path = ".",
        [parameter()]
        [string]
        $Prefix = "ACL_SID_History"
    )

    $CombinedCSVFile = "$Path\$($Prefix)_$(Get-Date -UFormat %Y%m%d%H%M%S).csv"
    $AllCSV = Get-ChildItem -Path $Path -Filter "*.csv" | Where-Object {$_.name -notlike "$Prefix*" -and $_.Length -gt 0}

    # Grab the header of one representative CSV file
    Get-Content $AllCSV[0].Fullname | Select-Object -First 1 | Add-Content $CombinedCSVFile

    # Grab all non-header content of all CSV files
    ForEach ($csv in $AllCSV) {
        $FileContent = Get-Content $csv.FullName
        $Rows = $FileContent.Count
        $FileContent[1..$Rows] | Add-Content $CombinedCSVFile
    }

    "`nOutput here:`n$CombinedCSVFile`n"
}


# Export module members
Export-ModuleMember -Function Export-DomainSIDs
Export-ModuleMember -Function Export-SIDMapping
Export-ModuleMember -Function Update-SIDMapping
Export-ModuleMember -Function Convert-SIDHistoryNTFS
Export-ModuleMember -Function Get-SIDHistory
Export-ModuleMember -Function Remove-SIDHistory
Export-ModuleMember -Function Export-SIDHistoryShare
Export-ModuleMember -Function Merge-CSV
