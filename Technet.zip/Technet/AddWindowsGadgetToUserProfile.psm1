﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#Requires -Version 2.0

Function Add-OSCWindowsGadgets
{
<#
 	.SYNOPSIS
        Add-OSCWindowsGadgets is an advanced function which can be used to add windows gadgets to user profile.
    .DESCRIPTION
        Add-OSCWindowsGadgets is an advanced function which can be used to add windows gadgets to user profile.
    .PARAMETER  <ComputerName>
		Specifies the computer which you want to run the add operation.
	.PARAMETER  <GadgetSource>
		Specifies the path of Windows Gadgets source.
	.PARAMETER  <UserName>
		Specifies the name of user profile.
    .EXAMPLE
        C:\PS> Add-OSCWindowsGadgets -ComputerName "Win7" -GadgetSource "C:\WindowsGadgets"
		
		This command adds files of the C:\WindowsGadgets to the user profile of remote computer Win7.
    .EXAMPLE
		C:\PS> Add-OSCWindowsGadgets -ComputerName "Win7" -UserName "Win7" -GadgetSource "C:\WindowsGadgets"

		This command adds files of the C:\WindowsGadgets to the specify user profile on remote computer Win7.
#>
	[Cmdletbinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=0)]
		[String[]]$ComputerName,
		[Parameter(Mandatory=$true,Position=1)]
		[String]$GadgetSource,
		[Parameter(Mandatory=$false,Position=2)]
		[String]$UserName
	)
	
	foreach($CN in $ComputerName)
	{
		#test the computer connectivity
		$PingResult = Test-Connection -ComputerName $CN -Count 1 -Quiet
		
		#test the file path
		if(Test-Path -Path $GadgetSource) 
		{
			if($PingResult)
			{	
				$GadgetDestination = "\\$CN\C$\Users"
				if(Test-Path -Path $GadgetDestination)
				{
					try
					{
						if($UserName)
						{
							Write-Verbose "copy the entire contents of $GadgetSource to $GadgetDestination\$UserName\AppData\Local\Microsoft\Windows Sidebar"
							#copy items to specify user profile folder
							Copy-Item -Path "$GadgetSource\*" -Destination "$GadgetDestination\$UserName\AppData\Local\Microsoft\Windows Sidebar" -Force -Recurse
						}
						else
						{
							$AllUsers = Get-ChildItem $GadgetDestination -Exclude Public
							foreach($User in $AllUsers)
							{
								$UserName = $User.Name
								Write-Verbose "copy the entire contents of $GadgetSource to $GadgetDestination\$UserName\AppData\Local\Microsoft\Windows Sidebar"
								#copy items to each user profile folder
								Copy-Item -Path "$GadgetSource\*" -Destination "$GadgetDestination\$UserName\AppData\Local\Microsoft\Windows Sidebar" -Force -Recurse
							}
						}
					}
					catch
					{
						Write-Warning "Windows Gadget add operation failed."
					}
				}
			}
			else 
			{
				Write-Warning "$CN - fail to connect"
			}
		}
		else 
		{
			Write-Warning "$GadgetSource does not find,please input correct path."
		}
	}
}
