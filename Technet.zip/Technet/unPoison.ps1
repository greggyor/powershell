﻿Set-DnsServerConditionalForwarderZone -Name:contosouniversity.edu -MasterServers:20.0.0.1
Clear-DnsServerCache -Force