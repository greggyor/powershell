<#
 NAME: Get-MeetingRoomDetails.ps1 
 
 AUTHOR: 	Georg Koller
 EMAIL:		georg.koller@verbund.com 
 
 COMMENT: 
 
 You have a royalty-free right to use, modify, reproduce, and 
 distribute this script file in any way you find useful, provided that 
 you agree that the creator, owner above has no warranty, obligations, 
 or liability for such use. 
 
 VERSION HISTORY: 
 0.1 Alpha	12/10/2012
 1.0 Final	13/02/2013
#>

$verbose = $true
Set-Alias read Read-Host

# Import Module for ActiveDirectory
Import-Module ActiveDirectory
Clear-Host

function message($message) {
	write-host $message -f "Yellow"
}

function print_parameter($dictionary) {
	foreach($d in $dictionary.GetEnumerator()){
		write-host "$($d.Key): "-nonewline
		write-host $d.Value -foregroundcolor "green"
	}
	
}

try {
	message "`nTry not. Do, or do not. There is no try.`n"
	
	$meeting_room = read 'enter meeting room'
	#$meeting_room = "vvhbz05"
	
	$mb = Get-Mailbox $meeting_room
	$room = Get-CalendarProcessing $meeting_room

	message "`n$($mb.DisplayName)`n"
	
	$details_general = @{}
	$details_general.add("HiddenFromAddressList",$mb.HiddenFromAddressListsEnabled)
	$details_general.add("Company",$mb.Company)
	$details_general.add("Department",$mb.Department)
	$details_general.add("Office",$mb.Office)
	$details_general.add("ResourceCapacity",$mb.ResourceCapacity)
	print_parameter $details_general
		
	message "`nDetails`n"

	$details_specific = @{}
	$details_specific.add("AutomateProcessing",$room.AutomateProcessing)
	$details_specific.add("DeleteSubject",$room.DeleteSubject)
	$details_specific.add("AddOrganizerToSubject",$room.AddOrganizerToSubject)
	$details_specific.add("AllBookInPolicy",$room.AllBookInPolicy)
	$details_specific.add("AllRequestInPolicy",$room.AllRequestInPolicy)
	$details_specific.add("BookingWindowInDays",$room.BookingWindowInDays)
	$details_specific.add("MaximumDurationInMinutes",$room.MaximumDurationInMinutes)
	$details_specific.add("AllowRecurringMeetings",$room.AllowRecurringMeetings)
	$details_specific.add("ForwardRequestsToDelegates",$room.ForwardRequestsToDelegates)
	$details_specific.add("DeleteAttachments",$room.DeleteAttachments)
	$details_specific.add("DeleteComments",$room.DeleteComments)
	$details_specific.add("RemovePrivateProperty",$room.RemovePrivateProperty)
	$details_specific.add("TentativePendingApproval",$room.TentativePendingApproval)
	$details_specific.add("DeleteNonCalendarItems",$room.DeleteNonCalendarItems)
	$details_specific.add("EnforceSchedulingHorizon",$room.EnforceSchedulingHorizon)
	
	print_parameter $details_specific
	
	message "`nDas 'Who is Who' des Meeting Raums`n"
	
	$room.ResourceDelegates | ft @{Label="ResourceDelegates";Expression={$_.name}}
	$room.BookInPolicy | ft @{Label="BookInPolicy";Expression={$_.name}}
	$room.RequestInPolicy | ft @{Label="RequestInPolicy";Expression={$_.name}}
	$room.RequestOutOfPolicy | ft @{Label="RequestOutOfPolicy";Expression={$_.name}}
	
	# script finished
	message "`nFantastic!`n"
}
catch {
	Write-Host $Error[0].Exception;
	write-warning "I'm sorry, Dave. I'm afraid I can't do that."
}