﻿Param(
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVClusterName,
    [Parameter(Mandatory=$true)]
    [string]
    $ScaleOutFSName,
	[switch]
	$EnableLM = $true
)

# Add and import needed features
if ((Get-WindowsFeature | ? Name -Like "RSAT-AD-PowerShell") | ? InstallState -NotLike Installed)
{
    Install-WindowsFeature "RSAT-AD-PowerShell"
}
if ((Get-WindowsFeature | ? Name -Like "RSAT-Clustering-PowerShell") | ? InstallState -NotLike Installed)
{
    Install-WindowsFeature "RSAT-Clustering-PowerShell"
}
Import-Module -Name ActiveDirectory

# Build array of Hyper-V servers
$HyperVNodes = (Get-ClusterNode -Cluster $HyperVClusterName).Name

# Enable LM and CD 
$SMBServerAD = Get-ADComputer -Filter {Name -eq $ScaleOutFSName}
$AllowedToDelegateToSMB = @( 
    ("cifs/"+$SMBServerAD.Name), 
    ("cifs/"+$SMBServerAD.DNSHostName))

for ($serverCounter = 0; $serverCounter -lt $HyperVNodes.Count; $serverCounter++) 
{ 
    $AllowedToDelegateTo = $AllowedToDelegateToSMB 
    if ($EnableLM) 
    { 
        for ($deligateCounter = 0; $deligateCounter -lt $HyperVNodes.Count; $deligateCounter++) 
        { 
            if ($deligateCounter -ne $serverCounter) 
            { 
                $deligationServer = $HyperVNodes[$deligateCounter] | Get-ADComputer 
                $AllowedToDelegateTo += @( 
                    ("Microsoft Virtual System Migration Service/"+$deligationServer.Name), 
                    ("Microsoft Virtual System Migration Service/"+$deligationServer.DNSHostName))       
            } 
        } 
    } 
    ($HyperVNodes[$serverCounter] | Get-ADComputer) | Set-ADObject -Add @{"msDS-AllowedToDelegateTo"=$AllowedToDelegateTo} 
}