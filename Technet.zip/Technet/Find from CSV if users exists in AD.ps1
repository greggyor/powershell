﻿<# Imran Pathan > Find if the user exist in AD #>
   
$UserList=IMPORT-CSV C:\Imran\Support_Tools\My_Scripts\FINAL_SCRIPTS\findUsers.csv
$DC = 'AD-PDC002.gotransit.local'
Connect-QADService -service $DC
Function FindDomainUser
{
	Param(
		[string] $_SamAccountName
		)
	#-------------------- Find user --------------------------#
	if(Get-QADUser -SamAccountName $_SamAccountName)
     {
         Write-Host "User Exist - $_SamAccountName"
     }
     else
     {
 		Write-Host "User Don't Exist - $_SamAccountName" 
     }
}
#------------------ Find user End --------------------------#
FOREACH ($Person in $UserList) {
	FindDomainUser $Person.SamAccountName
}