$CSVFile = "D:\Scripts\pictureurls.csv"
$mySiteUrl = "http://mysite.contoso.com"

#Connect to the User Profile Manager
$site = Get-SPSite $mySiteUrl
$context = Get-SPServiceContext $site
$profileManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($context)


#Read CSV file and process each line
$csv = import-csv -path $CSVFile
foreach ($line in $csv) 
{
	$adAccount = '"' + $line.UserName + '"'
	$pictureUrl = $line.PictureURL

	
	$up = $profileManager.GetUserProfile($line.UserName)
	if ($up)
	{
		$up["PictureURL"].Value = $pictureUrl
		$up.Commit()
		write-host $up.DisplayName" --> ", $pictureUrl	
	}
	if (!$up) {
		write-host $adAccount, " --> no profile found"
	}
}
