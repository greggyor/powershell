﻿<#
			" Satnaam WaheGuru Ji"	
			
			Author  :  Aman Dhally
			E-Mail  :  amandhally@gmail.com
			website :  www.amandhally.net
			twitter : https://twitter.com/#!/AmanDhally
			facebook: http://www.facebook.com/groups/254997707860848/
			Linkedin: http://www.linkedin.com/profile/view?id=23651495
			Date	: 18 march 2013
			File	: Create Encrypted Folder
			Purpose : Encrypted Folder
			
			Version : 3

			


#>


# Setting variables
	
	#Provide a Folder Name to be Created
	$folderName = "Encrypted-Folder"
	
	# Provide a Folder Path	
	$FolderPath = "$Env:USERPROFILE\Desktop" + "\" + "$Foldername"

#   Script run for here
	#Script Logic

	# IF Folder Not-Exists Then Create a new one

	if (! (Test-Path $folderPath)) { 
		 Write-Host "Creating $foldername Folder."
		 New-Item -Name $folderName  -ItemType Directory -Path "$Env:USERPROFILE\Desktop" ;
     	 Write-Host "$folderName Created" -BackgroundColor Green
	   	 Write-Warning "Encrypting $foldername"
	     & cipher.exe /e $FolderPath
     } 
		else {
				
				 if ( (Get-ItemProperty $FolderPath).attributes -match "Encrypted" ) 
						{ 
						# If folder Exists and Attributes is encrypted then no need 
						#to do anything
						Write-Host "	$folderName is already encrypted, so no action required." -ForegroundColor 'Green'
						}
				else {
						# If Folder Exists but not encrypted, then encrypt it.
						Write-Host "$folderName is not encrypted, enabling encryption" -ForegroundColor 'Yellow'
						& cipher.exe /e $FolderPath
						}
	
	
			}


#### End of the Script ###
