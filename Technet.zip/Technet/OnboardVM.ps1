﻿############################################################
#
# Copyright (c) Microsoft. All rights reserved.
# This code is licensed under the Microsoft Public License.
# THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
# ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
# IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
# PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
############################################################

##############################################################
#
# OnboardVM.ps1
# ------------------------
#
# Onboards a VM as part of the Cloud Technologies sample
#  
#  - Creates a new VM on a remote machine.
#    with a vhd from a template library.
#  - Onboards the vm.
#
# See comments based help below or run:
#     ./onboardvm.ps1 -?
#     get-help -examples ./onboardvm.ps1 
# etc. for further help.
# Depends on the MonitorVM.ps1 file and the settings.ps1 file
##############################################################

<#
.SYNOPSIS
This scripts demonstrates onboarding a vm as part of the Cloud Technologies sample.

.DESCRIPTION
This scripts demonstrates onboarding a vm as part of the Cloud Technologies sample. 
An optional selection algorithm, currently random, selects a node from the cluster.
PSRemoting is used to remote to a machine which is a node of the cluster.
A differencing disk is created from a template VHD. A VM is created and added to the cluster.

.PARAMETER Name
Specifies the name of the vm to create and onboard.

.PARAMETER ComputerName
Specifies the remote host to onboard the vm to. 
If PlacementAlgorithm is specified then this is just a node used to access the cluster and not necessarily the vm host.

.PARAMETER ImageName
Specifies the VHD image to used in creating the new VM.

.PARAMETER SwitchName
The name of the switch to attach to the new VM.

.PARAMETER Memory
1GB or 2GB VMs can be created.

.PARAMETER PlacementAlgorithm
Specifies an optional placement algorithm to find a host for the vm.
Currently the only option is Random.

.PARAMETER VHDLibraryPath
Specifies the location of the parent VHD to build the differencing disk from.

.PARAMETER NICSettings
A hashtable of settings for the virtual NIC
NicSettings = @{
                    Rename = 'CA-Avez-NIC' # The name the VMNIC will be renamed to
					# nicparams is a nested hashtable that contains valid parameters to the Set-VMNetworkAdapter cmdlet 
                    NicParams = @{               
                        StaticMacAddress = '080808000002' # if $null one will be selected from pool in onboardnvtenant.ps1
                        VirtualSubnetID  = 4096 # if $null onboardnvtenant.ps1 value will be the one in customersettings
                                                 # if not in Customer settings then the subnet will get the nextVSID in the environment settings 
                    }
                }

.PARAMETER CopyParent 
Copies the Parent VHD before creating the VM. (Slow)
    
.OUTPUTS
The Cluster Virtual Machine Role object
.EXAMPLE
./OnboardVM.ps1 -Name tenantvm -Memory 2gb -Computername HVClusterNode1 -ImageName Image1.vhd -Switchname TenantVirtualSwitch1 

.EXAMPLE
./OnboardVM.ps1 -Name tenantvm2 -Memory 2gb -Computername HVClusterNode1 -ImageName Image1.vhd -VHDLibraryPath C:\clusterstorage\volume3\vms

.EXAMPLE
./OnboardVM.ps1 -Name tenantvm3 -Computername HVClusterNode1 -ImageName Image1.vhd -VHDLibraryPath \\fileserver\vmshare
#>

param(
[Parameter(
    Mandatory=$false 
    )]
[string]
    $Name = 'TenantVM',
[Parameter(
    Mandatory=$false 
    )]
[ValidateSet("1gb","2gb")]
[string]
    $Memory = "1gb",
[Parameter(
    Mandatory=$true 
    )]
[string]
    $ImageName,
[Parameter(
    Mandatory=$false
    )]
[string]
    $ComputerName = $ENV:Computername,
[Parameter(Mandatory=$false)]
[string]
    $SwitchName,
[Parameter(Mandatory=$false)]
[ValidateSet("Random")]
[string]
    $PlacementAlgorithm = $null,
[Parameter(Mandatory=$false)]
[string]
    $VHDLibraryPath,
[hashtable]
    $NicSettings,
[System.Management.Automation.PSCredential]
    $Credential,
[switch]
    $CopyParent   
)
 
Set-StrictMode -Version 2

$settings = & .\settings.ps1

if( -not $credential ){ $credential = get-credential -Credential $settings.AdminAccount } 
if( -not $Switchname ){ $switchname = $settings.VMSettings.vSwitchName } 

function UpdateProgress {
    Param(
    [string] 
    $Activity, 
    [string] 
    $Status, 
    [string]
    $CurrentOperation, 
    [uint32]
    $PercentComplete,
    [int]
    $id,
    $ParentID 
    )
    $PsboundParameters.GetEnumerator() | % { $Progress[$_.key]= $_.value }
    write-progress @Progress
}

switch( $PlacementAlgorithm ){
    "Random" {
                #Find a random node to place the vm on
                $Nodes = @(Invoke-Command -Authentication Credssp -credential $Credential -ComputerName $ComputerName -ScriptBlock { 
                                            param( $Name )
                                            Import-Module FailoverClusters
                                            Get-Cluster -Name $Name| 
                                                Get-ClusterNode 
                                        } -ArgumentList $Computername)                  
                if ( -not $Nodes )
                { 
                    throw "No nodes found"
                } 

                $Target = Get-Random -Maximum $Nodes.count -SetSeed (get-date).millisecond  

                $TargetName = $nodes[ $target ].name 
                
            }# end  Random

    Default {
                $targetName = $computername
            } #end Default

}# end Switch
 
# create a new vm from a library of vhds
if ( $VHDLibraryPath ){
 
    $VHDLibraryLocation = $VHDLibraryPath
}
else
{ 
    $VHDLibraryLocation = $Settings.Clusters.Storage.VHDLibrarylocation  
}
 
$ImagePath = Join-path -Path $VHDLibraryLocation -ChildPath $ImageName  -ErrorAction stop
 
$DefaultVHDLocation = Invoke-Command -ComputerName $TargetName -ScriptBlock { 
                                Import-Module Hyper-V
                                ( get-vmhost ).VirtualHardDiskPath  
                            }  
                            
if( -not $DefaultVHDLocation ){
   Throw 'Default VirtualHardDiskPath not found'
}

$Progress = @{
    Activity         = 'Onboarding VM' 
    Status           = ( "VM {0} on {1}. VHD Image: {2} " -f $Name, $TargetName, $imagename)
    CurrentOperation = 'Creating VM' 
    PercentComplete  = ( 0 )
    ParentID         = -1
    id = 1
} 
if($CopyParent){$Progress.CurrentOperation += " {copying...}"}
UpdateProgress 

$vm = Invoke-Command -computername $TargetName -Credential $Credential -Authentication CredSSP -ScriptBlock { 
                    param( $name, $memory, $ImagePath, $DefaultVHDLocation, $SwitchName, $NICSettings, $CopyParent )
                    Import-Module FailoverClusters, HYper-V
                    
                    function UniqueVHDPath {
                    Param(
                        [string] $Path
                    )
                        $CandidatePath = $Path
                        $collisionCount = 0
                     
                        While( test-path $CandidatePath ){  
                            $collisionCount++                      
                            $CandidatePath = $Path -replace '(\.vhd|\.vhdx)$', "#$collisionCount`$1"                          
                        }
                        $CandidatePath
                    }
                    
                    #test that paths in the argumentlist really do exist
                    if (-not ( Test-Path $DefaultVHDLocation ))
                    { 
                        throw "New VHD Location not found DefaultVHDLocation: $defaultVHDLocation"
                    } 
                    if (-not ( Test-Path $ImagePath ))
                    {  
                        throw "Parent VHD not found. ImagePath: $ImagePath"
                    }
 
                    # construct the path for the new differencing disk
                    $parent = Get-ChildItem $ImagePath
                     
                    # Change vhd name if there is a name collision 
                    $ChildPath = Join-path -Path $defaultVHDLocation -ChildPath ( $Name + $parent.extension )
                    $ChildPath = UniqueVHDPath -Path $ChildPath
                    
                    if( $copyParent ){
                        $NewParentPath = UniqueVHDPath -path ( Join-path -Path $DefaultVHDLocation -ChildPath $Parent.Name )
                        Copy-Item -path $parent -Destination $NewParentPath
                        $parent = Get-ChildItem $newParentpath
                        if(-not $?){throw "VHD could not be copied"}
                    }
                    
                    $NewVHD = New-VHD -ParentPath $Parent.fullname -Path $Childpath -Differencing 
             
                    #If the vhd was created  
                    if( $? )
                    {           
                        $vm = New-VM -name $Name -VHDPath $NewVHD.path -MemoryStartupBytes (1 * $Memory) -switchname $SwitchName
                    }
                    else
                    {
                        throw "New VHD not found at expected location. VHDpath: $VHDpath "
                    }
                    if( $NICSettings ){
                        $NicParams = $NICsettings.NICParams                
                        $vm.NetworkAdapters | %{      
                            Set-VMNetworkAdapter -VMNetworkAdapter $_ @Nicparams 
                            Rename-VMNetworkAdapter -VMNetworkAdapter $_ -NewName $Nicsettings.rename
                            } 
                    }
                    $vm 
            } -ArgumentList $Name, $Memory, $ImagePath, $DefaultVHDLocation, $SwitchName, $NicSettings , $CopyParent

UpdateProgress -CurrentOperation done -PercentComplete 50
  
#if the VM was created/imported onboard it
if( $null -ne $VM )
{   
    # Setup resource metering
    UpdateProgress -CurrentOperation ( 'Setting up resource metering' ) -PercentComplete 60
    
    Invoke-Command -ComputerName $TargetName  -FilePath .\MonitorVM.ps1 -ArgumentList $Settings.VMSettings, $VM.id, $True
    if( -not $? ){  
        throw "VM Not onboard. Metering could not be enabled"
    }
    
    UpdateProgress -CurrentOperation ( 'Setting up resource metering' ) -PercentComplete 70
    
    UpdateProgress -CurrentOperation ( "Adding VM {0} to Cluster" -f $Name ) -PercentComplete 75
    # Start the VM
    $ClusterGroup = Invoke-Command -computername $TargetName -Credential $Credential -Authentication CredSSP -ScriptBlock {
                        Param( $VMID )
                        Get-VM -Id $VMID | Start-VM -Passthru | Add-ClusterVirtualMachineRole;
                        
                    } -ArgumentList $VM.Id
    if($?){   
        UpdateProgress -CurrentOperation ( ("{0} is onboard." -f $ClusterGroup.name ) ) -PercentComplete 100 
        return $ClusterGroup
    }else {
        throw "VM Not onboard. VM Could not be clustered."
    }
}
else
{
    throw "VM Not onboard"
}
