﻿#requires -version 2.0

<#
Require Windows Server Backup PowerShell module

Manage WSB network backups:
- support of rotation via $MaxBackup variable
- support of mail notification (function EmailNotification())

Auteur: Augagneur Alexandre
Created: 11/09/2011
#>

#Initialize WSB cmdlets
if ( (Get-PSSnapin -Name Windows.ServerBackup -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin Windows.ServerBackup
}

#------------------------------------------------------------------
#Variables
#------------------------------------------------------------------ 

#Files server
$Nas = "\\FSVM001"

#Root folder
$HomeBkpDir = ($Nas+"\backup")

#Backup folder
$Filename = Get-Date -Format MMddyyyy_hhmmss

#Number of backup to retain (value "0" disable rotation)
$MaxBackup = 1

#List uncritical volumes
$Volumes = Get-WBVolume -AllVolumes | Where-Object { $_.Property -notlike "Critical*" }
 
#------------------------------------------------------------------ 
#Function to compare the number of folders to retain with
#$MaxBackup (No called if $MaxBackup equals 0)
#------------------------------------------------------------------ 
function Rotation()
{ 
 #List all backup folders
 $Backups = @(Get-ChildItem -Path $HomeBkpDir\*)

 #Number of backups folders
 $NbrBackups = $Backups.count

 $i = 0
 
 #Delete oldest backup folders
 while ($NbrBackups -ge $MaxBackup)
 {
  $Backups[$i] | Remove-Item -Force -Recurse -Confirm:$false
  $NbrBackups -= 1
  $i++
 }
}
 
#------------------------------------------------------------------
#Function to send email notification
#------------------------------------------------------------------ 
function EmailNotification()
{
 #Sender email
 $Sender = "sender.at.corpnet.net"

 #Receipt email
 $Receipt = "receipt.at.contoso.com"

 #SMTP Server
 $Server = "smtp.corpnet.net"
 
#Mail subject
 $Object = $env:computername+": Backup report of "+(Get-Date)
 
#Mail content
 $Content = Get-WBJob -Previous 1 | ConvertTo-Html -As List | Out-String
 
 $SMTPclient = new-object System.Net.Mail.SmtpClient $Server
 
 #Specify SMTP port if needed
 #$SMTPClient.port = 587
 
 #Activate SSL if needed
 #$SMTPclient.EnableSsl = $true
 
 #Specify email account credentials if needed
 #$SMTPAuthUsername = "login"
 #$SMTPAuthPassword = "password"
 #$SMTPClient.Credentials = New-Object System.Net.NetworkCredential($SMTPAuthUsername, $SMTPAuthPassword)
 
 $Message = new-object System.Net.Mail.MailMessage $Sender, $Receipt, $Object, $Content
 $Message.IsBodyHtml = $true;
 $SMTPclient.Send($Message)
}

#------------------------------------------------------------------
#Main
#------------------------------------------------------------------ 

#Execute rotation if enabled
if ($MaxBackup -ne 0)
{
 Rotation
}
 
#Backup folder creation
New-Item ($HomeBkpDir+"\"+$Filename)  -Type Directory | Out-Null
 
$WBPolicy = New-WBPolicy
 
#Enable BareMetal functionnality (system state included)
Add-WBBareMetalRecovery -Policy $WBPolicy | Out-Null
 
#Add backup target
$BackupLocation = New-WBBackupTarget -network ($HomeBkpDir+"\"+$Filename)
Add-WBBackupTarget -Policy $WBPolicy -Target $BackupLocation -force | Out-Null
 
#Add uncritical volumes
if ($Volumes -ne $null)
{
 Add-WBVolume -Policy $WBPolicy -Volume $Volumes | Out-null
}
 
$WBPolicy | Out-Null
Start-WBBackup -Policy $WBPolicy
 
#Call email notification function
EmailNotification
 
