﻿Function Close-OpenFiles
{
    <#
	.SYNOPSIS
	    Close specific file on file server.

	.DESCRIPTION
	    The Close-Session cmdlet close specific file on file server.
		
	.PARAMETER Server
	    Specifies a file server. 

	.PARAMETER ID
	    Specifies a ID of open file. 
		
	.EXAMPLE
		PS C:\> "MyFS" | Get-OpenFiles | Where {$_.User -eq "MG"} | Close-OpenFiles

		ID                                      Server                                  Status
		--                                      ------                                  ------
		312742                                  MyFS                                    File closed
		
	.NOTES
		Author: Michal Gajda
		Blog  : http://commandlinegeeks.com/
	#> 
	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low"
	)]
	Param
	(
	[parameter(ValueFromPipeline=$true,
		ValueFromPipelineByPropertyName=$true)]	
	[String[]]$Server = ".",
	[parameter(Mandatory=$true,
		ValueFromPipelineByPropertyName=$true)]
	[String[]]$ID
	)
	
	Begin{}

	Process
	{
		Foreach($Srv in $Server)
		{
			if(Test-Connection -ComputerName $Srv -Quiet)
			{
				Foreach($IDtmp in $ID)
				{
					$Result = Invoke-Command -ComputerName $Srv -ScriptBlock{param($IDtmp) NET FILE $IDtmp /CLOSE} -ArgumentList $IDtmp  
			
					Switch($Result)
					{
						{$_ -match "successfully"} {$Status = "File closed"; Break}
						{$_ -eq $null} {$Status = "ID doesn't exist"; Break}
					} #End Switch $Result
					
					$log = New-Object -TypeName PSobject -Property @{ 
						Server = $Srv
						ID = $IDtmp
						Status  = $Status 
					} #End New-Object PSobject
					$log
					
				} #End ForEach $IDtmp in $ID
			} #End If Test-Connection -ComputerName $Srv -Quiet
			Else
			{
				Write-Warning "Server doesn't exist"
			} #End Else	Test-Connection -ComputerName $Srv -Quiet	
		} #End ForEach $Srv in $Server
	} #End Process
	
	End{}			
} #In The End :)