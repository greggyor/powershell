﻿#set error action
$erroractionpreference = "SilentlyContinue"

# declear object filter 

$strFilter = "(objectCategory=User)"

# declare Vars for Domain

# connects to Domain at base OU of Exchange/recipients 
$obje2k3 = New-Object System.DirectoryServices.DirectoryEntry("LDAP://OU=Recipients,OU=Exchange,DC=exchange,DC=contoso,DC=com")
# Init AD Search in 2k domain 
$objSearche2k3 = New-Object System.DirectoryServices.DirectorySearcher
$objSearche2k3.SearchRoot = $obje2k3
$objSearche2k3.PageSize = 3000
$objSearche2k3.Filter = $strFilter
$objSearche2k3.SearchScope = "Subtree"

# Init Query 

$colProplist = "name", "personalTitle", "employeeType"
foreach ($i in $colPropList){$objSearche2k3.PropertiesToLoad.Add($i)}




# set main Vars
[array]$baseobjects 
[string]$new
$getcommand = get-mailbox -OrganizationalUnit "exchange.contoso.com/Exchange/Recipients/org1" -ResultSize Unlimited
$baseobjects = $getcommand

#start eval of each Object returned
foreach ($value in $baseobjects)
{ 
#Eval for employeeType based on personalTitle 
 if ($value.personalTitle -eq 'Civ' )
{
#Set Civilian employeeType = C
$new =  "C"
write-host "Employee Type for "$value.alias" set to:" $new -foregroundcolor White
$setcommand = set-mailbox $value.identity  -employeeType $new
$setcommand
}
 if ($value.personalTitle -eq 'CTR' )
{
#Set Contractor employeeType = E
$new =  "E"
write-host "Employee Type for "$value.alias" set to:" $new -foregroundcolor White
$setcommand = set-mailbox $value.identity  -employeeType $new
$setcommand
}
 else 
{
#Set Federal employeeType = A
$new =  "A"
write-host "Employee Type for "$value.alias" set to:" $new -foregroundcolor White
$setcommand = set-mailbox $value.identity  -employeeType $new
$setcommandnull
}
}