﻿Export-DnsServerDnsSecPublicKey -ZoneName contosouniversity.edu -ComputerName dns-dc1.contoso.edu -PassThru | 
    %{$_.RecordData | Add-DnsServerTrustAnchor -Name contosouniversity.edu}
