﻿#========================== 
# Autor: Andreas Werner   = 
# Create: 16.09.2012      = 
# Version: 1.0            = 
#========================== 

#---- S T A R T ----
Clear-Host

#Import AD Module
    Import-Module ActiveDirectory -Force

#Get all domains in the forest
    $DomainsInForest=(Get-ADForest).domains

#List Domains in Forest and resolve rid pool from dc in domain
ForEach ($DomainName in $DomainsInForest){
    $CurrentRIDMaster= (Get-ADDomain $DomainName).RIDMaster
    [string]$CurrentDomainDN=(GET-ADDomDN $DomainName)
    
    GET-RID_Scope -Domain $CurrentDomainDN -RIDMaster $CurrentRIDMaster
}


#----- F U N C T I O N S -----

function GET-ADDomDN {
param([string]$Domain="")

$SplitDomain=$Domain.ToString().Split(".")
[string]$DN=""
for ($i=0;$i -le ($SplitDomain.Count-2); $i++ )
{[string]$DN=$DN + 'DC=' + $SplitDomain[$i] +','}

[string]$DN=$DN + 'DC=' + $SplitDomain[($SplitDomain.Count-1)]
return $DN
}


function GET-RID_Scope {
param(
[string]$Domain,
[string]$RIDMaster)

$RWDCs=(Get-ADDomainController -Filter {IsReadOnly -eq $false} -Server $RIDMaster).HostName

$RID_Pool_List=@()

foreach ($DC in $RWDCs) 
{
$DN='CN=RID Set,' + (Get-ADDomainController -Server $DC).ComputerObjectDN
$RIDSet=(Get-ADObject -SearchBase $DN -Filter * -Properties * -Server $DC)
$RID_AvailablePool=$RIDSet.rIDAllocationPool
$RID_PreviousAllocationPool=$RIDSet.rIDPreviousAllocationPool
$CurrentRID=$RIDSet.rIDNextRID


#AvailablePool
[int32]$RID_high1=$RID_AvailablePool/[math]::pow(2,32)
[int64]$RIDtemp1=$RID_high1*[math]::pow(2,32)
[int64]$RID_low1=$RID_AvailablePool - $RIDtemp1

#PreviousAllocationPool
[int32]$RID_high2=$RID_PreviousAllocationPool/[math]::pow(2,32)
[int64]$RIDtemp2=$RID_high2*[math]::pow(2,32)
[int64]$RID_low2=$RID_PreviousAllocationPool - $RIDtemp2

$RID_Pool = New-Object system.object
$RID_Pool | Add-Member -Type NoteProperty -Name 'Domaincontroller' -Value $DC -Force
$RID_Pool | Add-Member -Type NoteProperty -Name 'Current-RID' -Value $CurrentRID -Force
$RID_Pool | Add-Member -Type NoteProperty -Name 'CURRENT: low-RID' -Value $RID_low2 -Force
$RID_Pool | Add-Member -Type NoteProperty -Name 'CURRENT: high-RID' -Value $RID_high2 -Force
$RID_Pool | Add-Member -Type NoteProperty -Name ' NEXT: low-RID' -Value $RID_low1 -Force
$RID_Pool | Add-Member -Type NoteProperty -Name 'NEXT: high-RID' -Value $RID_high1 -Force

$RID_Pool_List += $RID_Pool   
}

#--> Output
Write-Host "Domain: $Domain " -BackgroundColor Green -ForegroundColor Black
Write-Host "RID-Master: $RIDMaster " -BackgroundColor Yellow -ForegroundColor Black

$RID_Pool_List | Format-Table -AutoSize
}
