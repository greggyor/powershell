<#
.NOTES
    Name: SelectOptimalDatabases
    Author: Daniel Sheehan
    Requires: PowerShell V2, Exchange 2010 Management Shell.
    Version History:
    1.0 - 9/19/2011 - Initial Release.
.SYNOPSIS
    Selects the best database for new mailboxes in Exchange 2010 based upon the
    number of active mailboxes in the database.
.DESCRIPTION
    This script selects the 3 most optimal DAG databases for hosting new mailboxes
	in Exchange 2010, taking into account the number of active mailboxes in each 
    DAG database. It doesn't consider the amount of disconnected mailboxes as they 
    will soon be purged, and it ignores any unmounted databases and/or Recovery
    databases. Once it determines the 3 databases, it sets them to be used for
	automatic provisiong and configures the rest to not be used for automatic
	provisioning.
.EXAMPLE  
    [PS] C:\>.\SelectDatabase.ps1 <no parameters>
    The script does not have any parameters.
#>

# Create a DataTable to host the mailbox data.
$MBXDBTable = New-Object system.Data.DataTable �MBXDatabaseTable�
# Create the columns by defining their name and attribute type.
$MBXDBTable.Columns.Add("DatabaseName",[String]) | Out-Null
$MBXDBTable.Columns.Add("ActiveMBs",[Int]) | Out-Null
$MBXDBTable.Columns.Add("InactiveMBs",[Int]) | Out-Null
$MBXDBTable.Columns.Add("TotalMBs",[Int]) | Out-Null
$MBXDBTable.Columns.Add("TotalMBSize",[Decimal]) | Out-Null
$MBXDBTable.Columns.Add("AverageMBSize",[Decimal]) | Out-Null
$MBXDBTable.Columns.Add("ExcludeFromProvisiong",[String]) | Out-Null

# Query just the mailbox databases with "DAG" in the first part of the name, which avoids non-DAG mailbox server
#   databases, and skip any recovery databases or databases not mounted.
$Databases = Get-MailboxDatabase -status | Where {($_.Name -like "DAG*") -and ($_.Recovery -eq $False) `
	-and ($_.Mounted -eq "True")} | Sort-Object Name
# Set the loop count to 0. 
$LoopCount=0

# Loop through each database in the above query.
Foreach ($Database in $Databases) {
    # Show a status bar for progress while data is collected.
    $PercentComplete = [Math]::Round(($LoopCount++ / $Databases.Count * 100),1)
    $CurrentDB = $Database.Name
    Write-Progress -Activity "Mailbox Database Query in Progress" -PercentComplete $PercentComplete `
        -Status "$PercentComplete% Complete" -CurrentOperation "Current Database: $CurrentDB"
    # Define the query which specifies grabbing statistics for each mailbox in the database.
    # NOTE: This only grabs information on mailboxes that have been created in the database. New mailboxes that haven't 
    #   been "created" will not show up here.
    $DBStats = Get-MailboxStatistics -database $Database
    # Set the initial values to 0 for each database being processed.
    $TotalActiveMB = 0
    $TotalInactiveMB = 0
    $TotalNumberMB = 0
    $TotalDBSize = 0
    $AvgMBSize = 0
    # Loop through the statistics for each mailbox in the database.
    Foreach ($DBStat in $DBStats) {
        # Count the total number of mailboxes (active and inactive).
        $TotalNumberMB++
        # Add the size of the mailbox to the total size of all mailboxes in the database.
        $TotalDBSize = $TotalDBSize + $DBStat.TotalItemSize.Value.ToMB()
        # Count the number of mailboxes that are not disconnected (I.E. they are still active).
        If ($DBStat.DisconnectDate -eq $Null) {
            $TotalActiveMB++
        }
    }
    If ($TotalNumberMB -gt 0) {
        # Set the average mailbox size to collective mailbox size divided by the number of mailboxes.
        $AvgMBSize = $TotalDBSize/$TotalNumberMB
        # Calculate the number of inactive mailboxes by subtracting the active mailboxes.
        $TotalInactiveMB = ($TotalNumberMB - $TotalActiveMB)
        # Round out the average mailbox size.
        $AvgMBSize=[math]::round($AvgMBSize, 2)
    }
    # Add the gathered information to a new row in the table.
    $NewDTRow = $MBXDBTable.NewRow()
    $NewDTRow.DatabaseName = $Database.Name
    $NewDTRow.ActiveMBs = $TotalActiveMB
    $NewDTRow.InactiveMBs = $TotalInactiveMB
    $NewDTRow.TotalMBs = $TotalNumberMB
    $NewDTRow.TotalMBSize = $TotalDBSize
    $NewDTRow.AverageMBSize = $AvgMBSize
	$NewDTRow.ExcludeFromProvisiong = $Database.IsExcludedFromProvisioning
    $MBXDBTable.Rows.Add($NewDTRow)
}
# Close out the progress bar cleanly.
Write-Progress -Activity "Mailbox Database Query in Progress" -Completed -Status "Completed"
# Dump the sorted table to the screen.
Write-Host "The status of the DAG databases before any changes were made:"
$MBXDBTable | Sort-Object -Descending ActiveMBs | Format-Table -AutoSize
# Choose the optimal databases by sorting the DAG databases by the fewest active mailboxes, and selecting 
#   the first three. Set those database to be autoprovisionable and also their information on the screen. 
Write-Host -Foregroundcolor Green "The new optimal mailbox databases are as follows:" 
$OptimalDBs = ($MBXDBTable | Sort-Object ActiveMBs | Select -first 3)
Foreach ($OptimalDB in $OptimalDBs) {
	If ($OptimalDB.ExcludeFromProvisiong -like "True") {
		Set-MailboxDatabase $OptimalDB.DatabaseName -IsExcludedFromProvisioning:$False
		Write-Host "Database" $OptimalDB.DatabaseName "was chosen for having" $OptimalDB.ActiveMBs `
		  "mailboxes and was enabled for auto-provisioning."
	} Else {
		Write-Host "Database" $OptimalDB.DatabaseName "was chosen for having" $OptimalDB.ActiveMBs `
		  "mailboxes and was previously enabled for auto-provisioning."
	}
}
# Specify the rest of the DAG databases to not disable for autoprovisioning.
$NonOptimalDBs = ($MBXDBTable | Sort-Object ActiveMBs | Select -Skip 3)
Foreach ($NonOptimalDB in $NonOptimalDBs) {
	If ($NonOptimalDB.ExcludeFromProvisiong -like "False") {
		Set-MailboxDatabase $NonOptimalDB.DatabaseName -IsExcludedFromProvisioning:$True
		Write-Host "Database" $NonOptimalDB.DatabaseName "was disabled for auto-provisioning."
	}
}
# Note the report is finsihed and include a beep to get attention in case the operator became distracted.
Write-Host -Foregroundcolor Green "The report is finished.`a"
