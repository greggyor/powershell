# Copyright (c) Microsoft 
# All rights reserved.
# Microsoft Limited Public License:
# This license governs use of the accompanying software. If you use the software, you 
# accept this license. If you do not accept the license, do not use the software.
# 1. Definitions 
# The terms "reproduce," "reproduction," "derivative works," and "distribution" have the 
# same meaning here as under U.S. copyright law. 
# A "contribution" is the original software, or any additions or changes to the software. 
# A "contributor" is any person that distributes its contribution under this license. 
# "Licensed patents" are a contributor's patent claims that read directly on its contribution.
# 2. Grant of Rights 
# (A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create. 
# (B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made, use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the contribution in the software.
# 3. Conditions and Limitations 
# (A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks. 
# (B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software, your patent license from such contributor to the software ends automatically. 
# (C) If you distribute any portion of the software, you must retain all copyright, patent, trademark, and attribution notices that are present in the software. 
# (D) If you distribute any portion of the software in source code form, you may do so only under this license by including a complete copy of this license with your distribution. If you distribute any portion of the software in compiled or object code form, you may only do so under a license that complies with this license. 
# (E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties, guarantees or conditions. You may have additional consumer rights under your local laws which this license cannot change. To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability, fitness for a particular purpose and non-infringement.
# (F) Platform Limitation - The licenses granted in sections 2(A) and 2(B) extend only to the software or derivative works that you create that run on a Microsoft Windows operating system product.

#File version: 1.0.1.0
function Create-DeployCompleted
{
    $axbuildError = @() 
    
    $axbuildError | Out-File (join-path $currentLogFolder "DeployCompleted.txt") -Encoding Default 
}

function Get-InputVariables ($homePath)
{
    $script:AxBuildDir = $homePath
    $RunDeployParmFile = (Join-Path $AxBuildDir "DeployParameters.txt")
    Write-InfoLog "Input parameters"        
    if ((Test-Path $RunDeployParmFile) -ne $false)
    {
        $fileContent = Get-Content $RunDeployParmFile
        foreach ($line in $fileContent)
        {
            Write-InfoLog $line
        
            $line = $line.split("=")
            if($line.Count -eq 2)
            {
                [System.Environment]::SetEnvironmentVariable($line[0],$line[1])     
            }
            else
            {
                Write-InfoLog "Bad DeployParameters file content: {0}" -f $line
            }
        }       
    }   
    $script:SqlServer               = GetEnvironmentVariable("SqlServer")
    $script:SqlDatabase             = GetEnvironmentVariable("SqlDatabase")
    $script:dropLocation            = GetEnvironmentVariable("BuildLocation")
    $script:ServerBinDir            = GetEnvironmentVariable("ServerBinDir")
    $script:LogFolder               = GetEnvironmentVariable("LogFolder")
    $script:AOSname                 = GetEnvironmentVariable("AOSname")
    $script:AxCompileAll            = GetEnvironmentVariable("CompileAll")
    $script:CompileCIL              = GetEnvironmentVariable("CompileCIL")
    $script:TFSIntegration          = GetEnvironmentVariable("TFSIntegration")
    $script:TFSUrl                  = GetEnvironmentVariable("TFSUrl")
    $script:TFSLabel                = GetEnvironmentVariable("TFSLabel")
    $script:ApplicationSourceDir    = GetEnvironmentVariable("ApplicationSourceDir")
    $script:CleanOnly               = GetEnvironmentVariable("UninstallOnly")
    $script:AOSNotOnDeployBox       = GetEnvironmentVariable("AOSNotOnDeployBox")
    $script:NoCleanOnError          = GetEnvironmentVariable("NoCleanOnError")
    
    if ((Test-Path $RunDeployParmFile) -eq $false)
    {
        $private:buffer = @()
        $buffer += "SqlServer="+ $SqlServer
        $buffer += "SqlDatabase="+ $SqlDatabase
        $buffer += "BuildLocation="+ $dropLocation
        $buffer += "ServerBinDir="+ $ServerBinDir
        $buffer += "LogFolder="+ $LogFolder
        $buffer += "CompileAll=" + $AxCompileAll
        $buffer += "CompileCIL="+ $CompileCIL
        $buffer += "AOSname="+ $AOSname
        $buffer += "UninstallOnly="+ $CleanOnly                         
        $buffer += "AOSNotOnDeployBox="+ $AOSNotOnDeployBox
        $buffer += "NoCleanOnError="+ $NoCleanOnError
        $buffer += "TFSIntegration="+ $TFSIntegration
        $buffer += "TFSUrl="+ $TFSUrl
        $buffer += "TFSLabel="+ $TFSLabel   
        $buffer += "ApplicationSourceDir="+ $ApplicationSourceDir
        $buffer | Out-File $RunDeployParmFile -Encoding Default
    }       
}

function Validate-InputVariables
{
    $axbuildError = @()
    if ($dropLocation -eq $null)    {$axBuildError += "Folder containing models files to deploy is missing."+[char]10}
    if (($dropLocation -ne $null) -and (Test-path $dropLocation) -eq $false)    {$axBuildError += "Folder containing models files to deploy {0} is not a valid path." -f $dropLocation +[char]10}
    
    if ($dropLocation -ne $null -and (Test-path $dropLocation) -eq $true)
    {
        $appPath = join-path $dropLocation 'Application'
        if ((test-path ($appPath)) -eq $false -or (test-path (join-path $appPath 'appl')) -eq $false)
        {
            $axBuildError += "Drop folder doesn't have valid folders: {0}" -f (join-path $appPath 'appl') +[char]10
        }
        else
        {
            $appPath = join-path $appPath 'Appl'
            $x = Get-ChildItem -Path $appPath -Filter "*.axmodel" -ErrorAction SilentlyContinue
            if($x -eq $null)
            {
                $axBuildError += "Drop folder {0} doesn't contain model files." -f $appPath +[char]10
            }            
        }
    }
        
    if ($LogFolder -eq $null)    {$axBuildError += "Log Folder is missing."+[char]10}
    if ($LogFolder -ne $null -and (Test-path $LogFolder) -eq $false)    {$axBuildError += "Log Folder {0} is not a valid path." -f $LogFolder +[char]10}
    
    if ($ServerBinDir -eq $null) {
        $axBuildError += "The server bin dir is missing."+[char]10}
    if ($ServerBinDir -ne $null) {
        if ((Test-Path -Path $ServerBinDir) -eq $false) {$axBuildError += "The server bin dir {0} is not a valid path." -f $ServerBinDir +[char]10}}
    
    if ($SqlServer -eq $null)    {$axBuildError += "Sql server name is missing."+[char]10}
    if ($SqlDatabase -eq $null)    {$axBuildError += "Sql database name is missing."+[char]10}

    if ($clientBinDir -eq $null) {
        $axBuildError += "The client bin dir is missing."+[char]10}
    if ($clientBinDir -ne $null) {
        if ((Test-Path -Path $clientBinDir) -eq $false) {$axBuildError += "The client bin dir {0} is not a valid path." -f $clientBinDir +[char]10}}
    if ($AOSName -eq $null) {$axBuildError += "AOS name is missing." +[char]10}
    if ($axBuildError -ne $null) 
    {
        $axbuildError | Out-File (join-path "$currentLogFolder" "AxInputValidationErrors.txt") -Encoding Default
        Write-ErrorLog "DEPLOY Failed because of input parameter errors."
        Write-InfoLog $axbuildError
        $axbuildError
    }
}   

function Scan-InputErrors
{
    $retVal = $false
    $axbuildError = @() 
    if((Test-Path (join-path $AxBuildDir 'AxInputValidationErrors.txt')) -eq $True)
    {
        Copy-Item -Path (join-path $AxBuildDir "AxInputValidationErrors.txt") -Destination $currentLogFolder -Force 
        Remove-Item (join-path $AxBuildDir "AxInputValidationErrors.txt")
        $axBuildError += "Some parameters passed are wrong. See AxInputValidationErrors.txt in Logs"+[char]10
        $retVal = $true
    }
    
    if($retVal -eq $true)
    {
        $axbuildError | Out-File (join-path $currentLogFolder "DeployErrors.err") -Encoding Default 
    }
    
    $retVal
}

function Update-InputVariables
{
    if($dropLocation -ne $null -and ((Test-Path $dropLocation) -eq $true)) {
        $script:dependencyPath = join-path $dropLocation 'Application'
    }    
}

function Deploy-AX
{
	#Step 5
    #Set the install mode
    Write-InfoLog ("Calling Set-AXModelStore: {0}" -f (Get-Date)) 
    Set-AXModelStore -NoInstallMode -Database $sqlDatabase -Server $sqlServer -OutVariable out
    Write-InfoLog $out
    Write-InfoLog (" ")

    #Step 6
    Stop-AOS
    Write-InfoLog (" ")
    
    Remove-Item -Path (Join-Path $clientLogDir "*.*") -ErrorAction SilentlyContinue
    Remove-Item -Path (Join-Path $env:LOCALAPPDATA "ax_*.auc") -ErrorAction SilentlyContinue
    
    Clean-Build    
    if($CleanOnly -ne $true)
    {
        #Step 7
        Install-DependentBinaries
        
        #Step 8
        Start-AOS
        
        #Step 9
        Synchronize-AX
        
        #Step 11
        Load-Models (join-path $dropLocation 'application\appl') 'ModelList.txt'      
    }    
    #Step 12
    Compile-Ax
}


#Step
#Load common automation library
$c = . (join-path (Split-Path -Parent $MyInvocation.MyCommand.Path) "common.ps1")
$script:scriptName = 'DEPLOY'

try
{   
    $ErrorActionPreference = "Stop"
    Check-PowerShellVersion
    #Step 
    #Read environment variables comming from the build template (or the parm file)
    Get-InputVariables(Split-Path -Parent $MyInvocation.MyCommand.Path)
    
    if($logFolder -eq $null -or (Test-path $logFolder) -eq $false)
    {
        Write-TerminatingErrorLog "Log folder is not valid path."
    }
    
    Write-InfoLog ("Deploy Starting : {0}" -f (Get-Date)) 

    Write-InfoLog ("Creating output directories : {0}" -f (Get-Date)) 
    Create-CurrentLogFolder
}
catch
{
    Write-TerminatingErrorLog "Error occured while deploying." $Error[0]
}
    
try
{   
    $script:transcriptStarted = $true
    Start-Transcript (join-path $currentLogFolder 'DeployLogs.log')

    Get-OverrideParameters
    Get-ImportOverrideParameters
    #Load the AX PS libary
    $x = . (join-path (join-path (Get-Item $SetupRegistryPath).GetValue("InstallDir") "ManagementUtilities") "Microsoft.Dynamics.ManagementUtilities.ps1")
    
    #Step
    #Read the AX information from the registry
    Update-InputVariables
    Read-AXClientConfiguration
    if($AOSNotOnDeployBox -ne $True)
    {
        Read-AxServerConfiguration
    }
    Write-InfoLog ('Printing all variables')
    Write-InfoLog (Get-Variable)
    
    #Step 4
    if ((Validate-InputVariables) -eq $null)
    {
        Register-SQLSnapIn
        Disable-VCS

        if($tfsIntegration -eq $true)
        {
            Sync-FilesToALabel
        }
        
        $script:buildModelStarted = $true
        Deploy-AX
    	if((Test-Path (join-path $currentLogFolder 'DeployErrors.err')) -ne $true)
        {
            Create-DeployCompleted
            Write-InfoLog ("Deploy finished : {0}" -f (Get-Date)) 
            Write-InfoLog ("DEPLOY SUCCESS") 
        }
        else
        {
            #Compile failed so revert and clean environment.
            Write-TerminatingErrorLog "Compilation errors."
        }
    }
    else
    {
        Write-InfoLog ("Validation errors.") 
        Write-InfoLog ("Deploy finished : {0}" -f (Get-Date)) 
        Write-InfoLog ("DEPLOY FAILED")
    }
}
catch
{
    Write-ErrorLog ("Error occured while deploying.")
    Write-ErrorLog ($Error[0])
    
    if($buildModelStarted -eq $true)
    {
        $script:buildModelStarted = $false

        try
        {
            if($NoCleanOnError -ne $true)
            {
                Write-InfoLog ("                                                                 ") 
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("****************TRYING TO REVERT BUILD***************************") 
                Clean-Build
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("*****************************************************************") 
                Write-InfoLog ("                                                                 ") 
            }
        }
        catch
        {
            Write-ErrorLog ("Failed to revert build.")
            Write-ErrorLog ($Error[0])
        }
    }
    $ErrorActionPreference = "SilentlyContinue"
    Write-InfoLog ("Deploy finished : {0}" -f (Get-Date)) 
    Write-InfoLog ("DEPLOY FAILED")
}
finally
{
    Enable-VCS

    if($transcriptStarted -eq $true)
    {Stop-Transcript}
}

# SIG # Begin signature block
# MIIY3gYJKoZIhvcNAQcCoIIYzzCCGMsCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUMaBybhSxl65e4iAesjQGBfe5
# ogegghOsMIIEmjCCA4KgAwIBAgIKYQd5EAAAAAAADjANBgkqhkiG9w0BAQUFADB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgVGltZXN0YW1waW5nIFBDQTAeFw0xMjAxMDkyMTUzNTZaFw0xMzA0
# MDkyMTUzNTZaMIGzMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMScwJQYDVQQLEx5uQ2lwaGVyIERTRSBFU046MzFDNS0z
# MEJBLTdDOTExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCe9h2WIvJt7C+AOVEcHcqm
# E7v2URkjGfkUECKc9Qm8hw6I7TZ1xnBgM6MxJmmKiVEN/4yFKNgN6nPha9awQVaF
# 9rhkISLhkAWpBDBBkOP1AeVWI6fDFIkFJGI1okJkk4amiVbXHPT23s372uDRhR8c
# g87MkBHyT7otPJyuzt7YKGK4jW1NFvP58jVbLogiheMCPCRKN6yUMKQdSxy4POcY
# zcMyvSl1dSXqHNq+sRsNwNMIPTcmhmfIivo9q/3tNQceGXbm81U9Jnl8QoAwQiZT
# 70d4vhzcOQSpAZ6eCXgMVFcrUABjHxmhNaIMd1DssKvn2Z8gflZS37KoVg+gx8MZ
# AgMBAAGjgegwgeUwHQYDVR0OBBYEFBcAwPs2ZvhhbN5whjrwFkKUXP3HMB8GA1Ud
# IwQYMBaAFG/oTj+XuTSrS4aPvJzqrDtBQ8bQMEQGA1UdHwQ9MDswOaA3oDWGM2h0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL3RzcGNhLmNy
# bDBIBggrBgEFBQcBAQQ8MDowOAYIKwYBBQUHMAKGLGh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvdHNwY2EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MA0GCSqGSIb3DQEBBQUAA4IBAQCy0EyGYQJ1P4JTeRbH/HssFFchdUIsytmez5NR
# kkHx7g4gsK48czfn9eB9qiOZB9p/qb5CBItJPocQKIeuWw1cVMAgXhLF0mPxcMtf
# moeajiuRB4AyU3W6ROwF37KEiQQLbHDnFSYwHDo8eK8/DAa6hpydCc3MHZqzTuzX
# URDUfFeitXL0VQImwuLJIvjOp3f3AKFxzj3gZIMGpmwkXdFWwqgJik82tbpToGg9
# W4BVZsF3QtRypAZyXw6D8bEagMj9CdiMsYYGB/efAEDy6Ram8g2HNVBV8kUNgT0R
# XS4TYuYHELdgG/UEAKJMTCCBze/9jGiwHrbcxfH9ConjJTwLMIIEnTCCA4WgAwIB
# AgIQaguZT8AAJasR20UfWHpnojANBgkqhkiG9w0BAQUFADBwMSswKQYDVQQLEyJD
# b3B5cmlnaHQgKGMpIDE5OTcgTWljcm9zb2Z0IENvcnAuMR4wHAYDVQQLExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBSb290IEF1dGhv
# cml0eTAeFw0wNjA5MTYwMTA0NDdaFw0xOTA5MTUwNzAwMDBaMHkxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBU
# aW1lc3RhbXBpbmcgUENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 3Ddu+6/IQkpxGMjOSD5TwPqrFLosMrsST1LIg+0+M9lJMZIotpFk4B9QhLrCS9F/
# Bfjvdb6Lx6jVrmlwZngnZui2t++Fuc3uqv0SpAtZIikvz0DZVgQbdrVtZG1KVNvd
# 8d6/n4PHgN9/TAI3lPXAnghWHmhHzdnAdlwvfbYlBLRWW2ocY/+AfDzu1QQlTTl3
# dAddwlzYhjcsdckO6h45CXx2/p1sbnrg7D6Pl55xDl8qTxhiYDKe0oNOKyJcaEWL
# 3i+EEFCy+bUajWzuJZsT+MsQ14UO9IJ2czbGlXqizGAG7AWwhjO3+JRbhEGEWIWU
# brAfLEjMb5xD4GrofyaOawIDAQABo4IBKDCCASQwEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwgaIGA1UdAQSBmjCBl4AQW9Bw72lyniNRfhSyTY7/y6FyMHAxKzApBgNVBAsT
# IkNvcHlyaWdodCAoYykgMTk5NyBNaWNyb3NvZnQgQ29ycC4xHjAcBgNVBAsTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFJvb3QgQXV0
# aG9yaXR5gg8AwQCLPDyIEdE+9mPs30AwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0O
# BBYEFG/oTj+XuTSrS4aPvJzqrDtBQ8bQMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBBQUA
# A4IBAQCUTRExwnxQuxGOoWEHAQ6McEWN73NUvT8JBS3/uFFThRztOZG3o1YL3oy2
# OxvR+6ynybexUSEbbwhpfmsDoiJG7Wy0bXwiuEbThPOND74HijbB637pcF1Fn5LS
# zM7djsDhvyrNfOzJrjLVh7nLY8Q20Rghv3beO5qzG3OeIYjYtLQSVIz0nMJlSpoo
# Jpxgig87xxNleEi7z62DOk+wYljeMOnpOR3jifLaOYH5EyGMZIBjBgSW8poCQy97
# Roi6/wLZZflK3toDdJOzBW4MzJ3cKGF8SPEXnBEhOAIch6wGxZYyuOVAxlM9vamJ
# 3uhmN430IpaczLB3VFE61nJEsiP2MIIEqTCCA5GgAwIBAgITMwAAAIhZDjxRH+Jq
# ZwABAAAAiDANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xMjA3MjYyMDUwNDFaFw0xMzEwMjYyMDUwNDFaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCzdHTQgjyHp5rUjrIEQoCXJS7kQc6TYzZfE/K0eJiAxih+zIoT7z03
# jDsJoNgUxVxe2KkdfwHBs5gbUHfs/up8Rc9/4SEOxYTKnw9rswk4t3TEVx6+8Eio
# eVrfDpscmqi8yFK1DGmPhM5xVXv/CSC/QHc3ITB0W5Xfd8ug5cFyEgY98shVbK/B
# +2oWJ8j1s2Hj2c4bDx705M1MNGw+RxHnAitfFHoEB/XXPYvbZ31XPjXrbY0BQI0a
# h5biD3dMibo4nPuOApHbIg/l0DapuDdF0Cr8lo3BYHEzpYix9sIEMIdbw9cvsnkR
# 2ItlYqKKEWZdfn8FenOKH3qF5c0oENE9AgMBAAGjggEdMIIBGTATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUJls+W12WX+L3d4h/XkVTWKguW7gwDgYDVR0P
# AQH/BAQDAgeAMB8GA1UdIwQYMBaAFMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljQ29kU2lnUENBXzA4LTMxLTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IB
# AQAP3kBJiJHRMTejRDhpsmor1JH7aIWuWLseDI9W+pnXypcnTOiFjnlpLOS9lj/l
# cGaXlTBlKa3Gyqz1D3moZ79p9A+X4woPv+6WdimyItAzxv+LSa2usv2/JervJ1DA
# 6xn4GmRqoOEXWa/xz+yBqInosdIUBuNqbXRSZNqWlCpcaWsf7QWZGtzoZaqIGxWV
# GtOkUZb9VZX4Y42fFAyxnn9KBP/DZq0Kr66k3mP68OrDs7Lrh9vFOK22c9J4ZOrs
# IVtrO9ZEIvSBUqUrQymLDKEqcYJCy6sbftSlp6333vdGms5DOegqU+3PQOR3iEK/
# RxbgpTZq76cajTo9MwT2JSAjMIIFvDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkq
# hkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQB
# GRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkwHhcNMTAwODMxMjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNy
# b3NvZnQgQ29kZSBTaWduaW5nIFBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBALJyWVwZMGS/HZpgICBCmXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay
# 7P/ewkJOI9VyANs1VwqJyq4gSfTwaKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB
# 2/O98jakyVxF3K+tPeAoaJcap6Vyc1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpn
# Uo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ+NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049
# oDI9kM2hOAaFXE5WgigqBTK3S9dPY+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJG
# zzc8OJ60d1ylF56NyxGPVjzBrAlfA9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQF
# MAMBAf8wHQYDVR0OBBYEFMsR6MrStBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIB
# hjASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGY
# YDuoMW+mPLzYLTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAW
# gBQOrIJgQFYnl+UlE/wq4QpTlVnkpDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290
# Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDAN
# BgkqhkiG9w0BAQUFAAOCAgEAWTk+fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddD
# rQv+y+ktMaMjzHxQmIAhXaw9L0y6oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6Wc
# IC36C1DEVs0t40rSvHDnqA2iA6VW4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqk
# ghyT4pQHHfLiTviMocroE6WRTsgb0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5
# Y1ZEolHN+emjWFbdmwJFRC9f9Nqu1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6
# EiYJZTiU8XofSrvR4Vbo0HiWGFzJNRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjH
# Ce6FDoxPbQ4TTj18KUicctHzbMrB7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI
# 5nI3EvRvsTxngvlSso0zFmUeDordEN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMn
# QK3k+eGpf0a7B2BHZWBATrBC7E7ts3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9Q
# Fi58vwUheuKVQSdpw5OPlcmN2Jshrg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMk
# uYjPaqhHMS+a3ONxPdcAfmJH0c6IybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjW
# wz0xggScMIIEmAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAA
# AIhZDjxRH+JqZwABAAAAiDAJBgUrDgMCGgUAoIG8MBkGCSqGSIb3DQEJAzEMBgor
# BgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3
# DQEJBDEWBBQh4IzlLI75BlxuBNA+F+Duy1OoyjBcBgorBgEEAYI3AgEMMU4wTKAa
# gBgARABlAHAAbABvAHkAQQBYAC4AcABzADGhLoAsaHR0cDovL3d3dy5NaWNyb3Nv
# ZnQuY29tL01pY3Jvc29mdER5bmFtaWNzLyAwDQYJKoZIhvcNAQEBBQAEggEAiOEA
# 0f+Bt7OZF6VfSM5Lbk90Z2Krd5XC1p8icnFmhAS0Ssu6P/hnWvK3tZPzw0haiJLV
# 2TNqDWCP6X7glzWRBqUvam4D6pzvTd2u43t2Gz8bKtgguMZpCapf+Qep4gXNTUYT
# RQR86E4U6Dm/TjPxPeDRSsqGjiDVlROtSKJr0APsrhnGF1GtRv7VvXE6PEf9LLA/
# ERJF/0Ik1z4VCS3hXzs+YsOznX2Qwc38OLiPN3kJa+e1u7OdCOg62HAE0XlMfnsJ
# uUBlE0VZENngYaecC0jtvfaEvgg8Fhl0g5VERpnydpK3ot/d0ksKBZuMKGnlxo66
# 1m/WDFmVmEkLS3Ne66GCAiEwggIdBgkqhkiG9w0BCQYxggIOMIICCgIBATCBhzB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgVGltZXN0YW1waW5nIFBDQQIKYQd5EAAAAAAADjAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTIw
# OTI0MTYyNzM4WjAjBgkqhkiG9w0BCQQxFgQUBE7ZCWS1UT47wax6kID5uXKhA7Aw
# DQYJKoZIhvcNAQEFBQAEggEAQckQvHSkFu4USh/s2S5P+PIfu9nAjTp/Cvb93lue
# 6yUegePZqHUxAi/W7eZpPYbityxGAUI877uQyNyK0riOlGItqhEyizEiUyy0GzPn
# CH+tmTnvMPDEDyeCCCdtdRDNBnyL3U+oRACjnqy33fENszoOD/ARo/VIS1mYBX2e
# WK9TvdX/3wMXixcojM3BtuVW/1VSgcjxA1AO6fI8x6t5M4pCLRlHZekQwWlABvtu
# RrIBxN3aBo3EGY5WLcLyBr7N99OuuWq9bIbKIalcqUJP1KfpmL2EX0sVZ+YMFUOt
# 9SWHsKfpI+mDcn5TkZFNak4q40DOOAHU6723WasPemlClw==
# SIG # End signature block
