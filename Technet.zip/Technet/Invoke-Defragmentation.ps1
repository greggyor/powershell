﻿<#
	.SYNOPSIS
		Analyze fragmentation on all disks on a given system and defrag if necessary	
	.DESCRIPTION
    	For a given computer, the script will run fragmentation analysis on all local drives and display fragmentation percentage, free space percentage, and whether a defragmentation is recommended. The script can then defragment all drives where fragmentation is above the recommended percentage.
	.PARAMETER ComputerName
		Descriptor identifying a machine, (FQDN, DNS/NETBIOS name, IP address). "localhost" and "." are acceptable for the local machine. Default is "."
	.PARAMETER ForceDrives
		[NONE|ALL|RECOMMENDED] If "NONE", user is prompted for each drive where defragmentation is recommended. If "ALL", all drives are defragmented without user confirmation and regardless of recommendation. If "RECOMMENDED", all drives where defragmentation is recommended are defragmented without user confirmation. Default is "NONE"
	.PARAMETER ForceNotEnoughSpace
		If true, then force each defragmentation to run, even if there is not enough free space on disk.
	.PARAMETER Quiet
		Suppresses all output other than errors
	.INPUTS
		Array of ComputerName parameters
	.OUTPUTS
		Output presented to console
	.EXAMPLE
    	Invoke-Defragmentation
		Server: .
		Volumes: 3

		DriveLetter  PercentFragmentation  PercentFreeSpace  DefragRecommended
		-----------  --------------------  ----------------  -----------------
		C:                              8                52              False
		D:                              0                82              False
		F:                              0                98              False
	.EXAMPLE
		.\Invoke-Defragmentation.ps1 -ComputerName computer01 -ForceDrives all
		Server: computer01
		Volumes: 2

		DriveLetter  PercentFragmentation  PercentFreeSpace  DefragRecommended
		-----------  --------------------  ----------------  -----------------
		C:                             10                28              False
		E:                              0                42              False
		Defragmenting C:...  Success

		Defragmenting E:...  Success
		
		C:                              0                28              False
		E:                              0                42              False
	.EXAMPLE
		"computer01","computer02" | .\Invoke-Defragmentation.ps1
		Server: computer01
		Volumes: 1

		DriveLetter  PercentFragmentation              PercentFreeSpace             DefragRecommended
		-----------  --------------------              ----------------             -----------------
		C:                             27                            34                          True
		Defrag of C: recommended. Proceed with defrag? (y or n): n
		
		Server: computer02
		Volumes: 1
		C:                             13                            17                          True
		Defrag of C: recommended. Proceed with defrag? (y or n): n
		
	.NOTES
		NAME:  Invoke-Defragmentation.ps1
		AUTHOR: Charles Downing
		LASTEDIT: 05/24/2012
		KEYWORDS:
	.LINK
#>

[cmdletbinding(SupportsShouldProcess=$true)]

Param
(
	[Parameter(ValueFromPipeline=$true,Position=0)][string]$ComputerName = ".",
	[ValidateSet('NONE','ALL','RECOMMENDED')][string]$ForceDrives = "none",
	[switch][bool]$ForceNotEnoughSpace = $false,
	[switch][bool]$Quiet = $false
)

BEGIN {
	# Use Defrag function of Win32_Volume class to defragment $volume
	Function DefragDrive($volume)
	{
		if(!$Quiet)
		{
			Write-Host "Defragmenting $($volume.DriveLetter)...  " -noNewLine
		}
	               
	    $result = ($volume.Defrag($ForceNotEnoughSpace)).ReturnValue
		
		if(!$Quiet)
		{
		    switch ($result) {
		      0  {Write-Host 'Success'}
		      1  {Write-Host 'Access Denied'}
		      2  {Write-Host 'Not Supported'}
		      3  {Write-Host 'Volume Dirty Bit Set'}
		      4  {Write-Host 'Not Enough Free Space'}
		      5  {Write-Host 'Corrupt MFT Detected'}
		      6  {Write-Host 'Call Cancelled'}
		      7  {Write-Host 'Cancellation Request Requested Too Late'}
		      8  {Write-Host 'Defrag In Progress'}
		      9  {Write-Host 'Defrag Engine Unavailable'}
		      10 {Write-Host 'Defrag Engine Error'}
		      11 {Write-Host 'Unknown Error'}
		    }
			Write-Host ""
		}
	}

	# Get stats from defrag analysis for each volume
	Function AnalyzeDrives($drives)
	{
		foreach( $volume in $drives)
		{
			$analysis = $volume.defraganalysis()
				
			$volStats = New-Object PSObject
			$volStats | Add-Member -MemberType NoteProperty -Name DriveLetter $volume.DriveLetter
			$volStats | Add-Member -MemberType NoteProperty -Name PercentFragmentation $analysis.defraganalysis.FilePercentFragmentation
			$volStats | Add-Member -MemberType NoteProperty -Name PercentFreeSpace $analysis.defraganalysis.FreeSpacePercent
			$volStats | Add-Member -MemberType NoteProperty -Name DefragRecommended $analysis.DefragRecommended
			$volStats | Add-Member -MemberType NoteProperty -Name Volume $volume
				
			$vols.Add($volume.DriveLetter, $volStats)
		}
	}
}

#---------- Main execution block ----------#

PROCESS {
	if($Quiet -and ($ForceDrives -eq "none"))
	{
		Write-Host "-Quiet parameter only valid if -ForceDrives is set to `"Recommended`" or `"All`"" -ForegroundColor Red -BackgroundColor Black
	}
	else
	{
		if(Test-Connection -Count 2 -ComputerName $ComputerName -Quiet)
		{
			$vols = @{}
			
			# Get all logical volumes for $ComputerName
			$drives = Get-WmiObject win32_volume -ComputerName $ComputerName | 
				Where-Object { $_.DriveType -eq 3 -and $_.DriveLetter -ne $null}
			
			if(!$Quiet)
			{
				"Server: " + $ComputerName
			
				if($drives.length)
				{
					$count = $drives.length
				}
				else
				{
					$count = 1
				}
				"Volumes: " +  $count
			}

			# Analyze all drives and display report
			AnalyzeDrives($drives)
			if(!$Quiet)
			{
				$vols = $vols.getEnumerator() | Sort-Object Name
				foreach($vol in $vols)
				{
					$vol.Value | Select-Object DriveLetter,PercentFragmentation,PercentFreeSpace,DefragRecommended
				}
			}

			$defrag = $false
			foreach($obj in $vols)
			{
				switch($ForceDrives.ToLower())
				{
					# Do not force defrag on any drives. Prompt for all drives where defrag is recommended.
					"none"
					{
						if($obj.Value.DefragRecommended)
						{
							$proceed = Read-Host "Defrag of" $obj.Value.DriveLetter "recommended. Proceed with defrag? (y or n)"
							switch($proceed)
							{
								"y" {
									DefragDrive $obj.Value.Volume
									$defrag = $true
									break
								}
								"n" {
									break
								}
								DEFAULT {
									Write-Host $proceed.character "is an invalid entry."
									break
								}
							}
						}
					}
					# Defrag all drives, regardless of analysis. Do not prompt for confirmation.
					"all"
					{
						DefragDrive $obj.Value.Volume
						$defrag = $true
					}
					# Defrag all drives where recommended. Do not prompt for confirmation.
					"recommended"
					{
						if($obj.Value.DefragRecommended)
						{
							DefragDrive $obj.Value.Volume
							$defrag = $true
						}
					}
				}
			}

			# If any defrags were run, rerun analysis and output report
			if($defrag)
			{
				$vols = @{}
				# Analyze all drives and display report
				AnalyzeDrives($drives)
				if(!$Quiet)
				{
					$vols = $vols.getEnumerator() | Sort-Object Name
					foreach($vol in $vols)
					{
						$vol.Value | Select-Object DriveLetter,PercentFragmentation,PercentFreeSpace,DefragRecommended
					}
				}
			}
			if(!$Quiet)
			{
				Write-Host ""
			}
		}
		else
		{
			Write-Host "Cannot connect to $ComputerName" -ForegroundColor Red -BackgroundColor Black			
		}
	}
}