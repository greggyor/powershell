param(
    [parameter(Mandatory=$true,Position=0)]
    [ValidateNotNullOrEmpty()]
    [String] 
    $Server1,
    
    [parameter(Mandatory=$true,Position=1)]
    [ValidateNotNullOrEmpty()]
    [String] 
    $Server2, 
    
    [parameter(Mandatory=$true,Position=2)]
    [ValidateNotNullOrEmpty()]
    [String] 
    $ScopeId
)

$TOLERANCE = 5

# Compare the arrays of Lease objects
function CompareLeaseObjects($Object1, $Object2, $PrimaryKey)
{
    if ($null -eq $Object1 -and $null -eq $Object2)
    {
        Write-Warning "Both lease objects are NULL"
        return $true
    }
    elseif ($null -eq $Object1)
    {
        Write-Verbose "First lease object is NULL"
        return $false
    }
    elseif ($null -eq $Object2)
    {
        Write-Verbose "Second lease object is NULL"
        return $false
    }
    
    $RetVal = $true

    # Find objects to compare based on the primary key
    foreach ($Obj1 in $Object1)
    {
        $ObjFound = $false

        foreach ($Obj2 in $Object2)
        {
            if ($Obj1.$PrimaryKey -eq $Obj2.$PrimaryKey)
            {
                Write-Verbose $Obj1.IPAddress
                
                $ObjFound = $true
                
                # Compare lease objects
                $ObjMatch = CompareObjectProperties $Obj1 $Obj2 @("LeaseExpiryTime")
                
                # Compare expiry times of lease objects. The difference should be within the tolerance range
                [System.TimeSpan] $interval = $Obj1.LeaseExpiryTime - $Obj2.LeaseExpiryTime
                $absdiff = $interval.Duration()
                $TimeMatch = $absdiff -lt [System.TimeSpan]::FromSeconds($TOLERANCE)
                
                if (-not $TimeMatch)
                {
                    Write-Verbose "Value of LeaseExpiryTime property DID NOT MATCH"
                    Write-Verbose "Tolerance allowed: $TOLERANCE secs"
                    Write-Verbose "Actual difference found: $absdiff"
                }

                $IP = [String]$Obj1.IPAddress
                if ($ObjMatch -and $TimeMatch)
                {
                    Write-verbose "[$IP] : IDENTICAL`n`n`n"
                }
                else
                {
                    Write-host -foreground Magenta "[$IP] : DIFFERENT`n`n"
                    $RetVal = $false
                }
                 
                break
            }
        }
        if (-not $ObjFound)
        {
            $IP = [String]$Obj1.IPAddress
            Write-host -foreground Magenta "[$IP] : Not found on SERVER2`n`n"
            $RetVal = $false
        }
    }

    # Check if there are any objects in second list that are not available in first list
    foreach ($Obj2 in $Object2)
    {
        $ObjFound = $false
        foreach ($Obj1 in $Object1)
        {
            if ($Obj1.$PrimaryKey -eq $Obj2.$PrimaryKey)
            {
                $ObjFound = $true
                break
            }
        }
        if (-not $ObjFound)
        {
            $IP = $Obj2.IPAddress
            Write-host -foreground Magenta "[$IP] : Not found on SERVER1`n`n"
            $RetVal = $false
        }
    }
    
    return $RetVal
}

# Compare two objects while ignoring fields specified in ExclusionList
function CompareObjectProperties($Object1, $Object2, $ExclusionList = @())
{
    $Result = $true
    if ($null -eq $Object1 -and $null -eq $Object2)
    {
        $Result = $true
    }
    elseif($null -eq $Object1)
    {
        Write-Warning "First object is null"
        $Result = $false
    }
    elseif($null -eq $Object2)
    {
        Write-Warning "Second object is null"
        $Result = $false
    }
    else
    {
        # If Objects are of different types, return FALSE
        if ($Object1.GetType().Name -ne $Object2.GetType().Name)
        {
            Write-Warning "Input Objects TYPE MISMATCH"
            $Result = $false
        }
        else
        {
            $Object1 | Get-Member -MemberType Properties | %{$count=0} {$count += 1}
            $PropName = $Object1 | Get-Member -MemberType Properties | %{$_.Name}
            
            # Iterate through each property of Object1 and try matching it with that of Object2
            for ($i=0; $i -lt $count; ++$i)
            {
                if ($count -gt 1) { $key = $PropName[$i] }
                else { $key = $PropName }
                
                if ($true -eq $ExclusionList.Contains($key)) { continue }
                
                # Property is of a primitive type
                if ((($null -ne $Object1.$key) -and ($null -ne $Object2.$key)) -and 
                    ((($Object1.$key.GetType()).Name -eq "String") -or
                    (($Object1.$key.GetType()).Name -eq "Int32") -or
                    (($Object1.$key.GetType()).Name -eq "Int64") -or
                    (($Object1.$key.GetType()).Name -eq "UInt32") -or
                    (($Object1.$key.GetType()).Name -eq "UInt64") -or
                    (($Object1.$key.GetType()).Name -eq "Enum") -or
                    (($Object1.$key.GetType()).Name -eq "Boolean") -or
                    (($Object1.$key.GetType()).Name -eq "Double") -or
                    (($Object1.$key.GetType()).Name -eq "Decimal")))
                {
                    if ($Object1.$key -ne $Object2.$key)
                    {
                        Write-Verbose "Value of $key property DID NOT MATCH"
                        Write-Verbose $Object1.$key
                        Write-Verbose $Object2.$key
                        $Result = $false
                    }
                }
                else
                {
                    # If property is of non-primitive type then make a recursive call to compare it
                    $Retval = CompareObjectProperties $Object1.$key $Object2.$key
                    if ($false -eq $Retval) { $Result = $false }
                }                
            }
        }
    }

    return $Result
}


# Check if Scope exists on Server1
try {
    $Scope = $null
    $Scope = Get-DhcpServerv4Scope -scopeId $ScopeId -ComputerName $Server1
}
catch [Exception]
{
    Write-warning "Exception thrown while getting Scope Info from Server1"
    return
}

if ($null -eq $Scope)
{
    Write-warning "Scope not present on Server1"
    return
}


# Check if Scope exists on Server2
try {
    $Scope = $null
    $Scope = Get-DhcpServerv4Scope -scopeId $ScopeId -ComputerName $Server2
}
catch [Exception]
{
    Write-warning "Exception thrown while getting Scope Info from Server2"
    return
}

if ($null -eq $Scope)
{
    Write-warning "Scope not present on Server2"
    return
}

# Fetch leases from both servers
$Leases1 = Get-DhcpServerv4Lease -ScopeId $ScopeId -ComputerName $Server1 -AllLeases
$Leases2 = Get-DhcpServerv4Lease -ScopeId $ScopeId -ComputerName $Server2 -AllLeases

# Compare the leases
$Result = CompareLeaseObjects $Leases1 $Leases2 "IPAddress"


if ($true -eq $Result)
{
    Write-Host ""
    Write-Host -foreground Green "********************************"
    Write-Host -foreground Green "RESULT : All the leases MATCHED"
    Write-Host -foreground Green "********************************"
}
else
{
    Write-Host ""
    Write-Host -foreground Red "********************************"
    Write-Host -foreground Red "RESULT : Leases DID NOT MATCH"
    Write-Host -foreground Red "********************************"
}
