<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

#Define functions that will be added to the profile.
$connectToOffice365 = @'
Function Connect-OSCExchangeOnline
{
	if (($O365Session -eq $null) -or ($O365Session.State -eq "Closed")) {
		$global:O365Session = New-PSSession -ConfigurationName Microsoft.Exchange `
		-ConnectionUri "https://ps.outlook.com/powershell" -Credential $Credential `
		-Authentication Basic -AllowRedirection
		if ($O365Session -ne $null) {
			Import-PSSession -Session $O365Session
		}
	} else {
		Write-Host "The connection to Office 365 has been established already."
	}
}
'@

$disconnectFromOffice365 = @'
Function Disconnect-OSCExchangeOnline
{
	if ((Get-Variable O365Session -Scope Global -ErrorAction SilentlyContinue) -ne $null) {
		Remove-PSSession -Session $O365Session
	}
}
'@

Function Set-OSCEXOProfile
{
	#.EXTERNALHELP Set-OSCEXOProfile-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[ValidateSet("CurrentUserCurrentHost","CurrentUserAllHosts","AllUsersCurrentHost","AllUsersAllHosts")]
		[string]$ProfileType="CurrentUserCurrentHost"
	)
	Process
	{
		#Get profile path
		Switch ($ProfileType)
		{
			"CurrentUserCurrentHost" {
				$profilePath = $PROFILE.CurrentUserCurrentHost
			}
			"CurrentUserAllHosts" {
				$profilePath = $PROFILE.CurrentUserAllHosts
			}
			"AllUsersCurrentHost" {
				$profilePath = $PROFILE.AllUsersCurrentHost
			}
			"AllUsersAllHosts" {
				$profilePath = $PROFILE.AllUsersAllHosts
			}
			Default {
				$profilePath = $PROFILE
			}
		}
		
		#If profile exists, append functions to the profile.
		#Otherwise, create a new profile and add functions.
		if (Test-Path -Path $profilePath) {
			$verboseMsg = $Messages.ProfileExists
			$pscmdlet.WriteVerbose($verboseMsg)
			Try
			{
				#Check the existence of two functions
				$isAdded = Select-String -Path $profilePath -Pattern "[Connect|Disconnect]-OSCExchangeOnline" -Quiet
				$content = "`r`n`r`n$connectToOffice365`r`n`r`n$disconnectFromOffice365"
				if (-not $isAdded) {
					Out-File -FilePath $profilePath -InputObject $content -Encoding "ascii" -Append
					$verboseMsg = $Messages.RestartPowerShell
					$pscmdlet.WriteVerbose($verboseMsg)
				} else {
					$verboseMsg = $Messages.IsAdded
					$pscmdlet.WriteVerbose($verboseMsg)
				}
			}
			Catch
			{
				$pscmdlet.ThrowTerminatingError($_)
			}
		} else {
			$verboseMsg = $Messages.ProfileDoesNotExist
			$pscmdlet.WriteVerbose($verboseMsg)
			Try
			{
				#Create new profile.
				$parentFolder = Split-Path -Path $profilePath
				if (-not (Test-Path -Path $parentFolder)) {
					New-Item -Path $parentFolder -ItemType Directory | Out-Null
				}
				$file = New-Item -Path $profilePath -ItemType File
				
				#Add functions to the newly created profile.
				if ($file -ne $null) {
					Out-File -FilePath $file.FullName -InputObject "$connectToOffice365`r`n`r`n$disconnectFromOffice365" -Encoding "ascii"
					$verboseMsg = $Messages.RestartPowerShell
					$pscmdlet.WriteVerbose($verboseMsg)
				}
			}
			Catch
			{
				$pscmdlet.ThrowTerminatingError($_)
			}
		}
	}
}

Export-ModuleMember -Function "Set-OSCEXOProfile"