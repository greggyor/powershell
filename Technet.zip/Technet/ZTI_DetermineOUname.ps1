$TSEnv = New-Object -COMObject Microsoft.SMS.TSEnvironment 
$VarDumpFile = "$TSEnv:LogPath\ZTIVariablesExport.log"

Dir TSEnv: | FT -Auto | Out-File $VarDumpFile

#As explained in the article, we use the last 4 characters of the computer name to determine whether the pc is a normal pc, or a special device such as a kiosk
#The line below counts all characters in the OSDComputerName variable (using the .length method) and then substract 4
#this will allow me to use the .remove method of a string object and keep exactly the part of the computername that I need to test against.
$CharsToRemove=$TSEnv:OSDComputerName.length-4
Write-Host "Hostname is $TSEnv:OSDComputerName and contains"$TSEnv:OSDComputerName.length"characters. The last 4: ("$TSEnv:OSDComputerName.Remove(0,$CharsToRemove)") will be used to determine whether pc is a kiosk or not"

If ($TSEnv:OSDComputerName.StartsWith("0-")) 
	{
	 Write-Host "Found computer name starting with 0-, will try to find matching department for Division 0"
	 If ($TSEnv:OSDComputerName.Remove(0,$CharsToRemove).StartsWith("K")) 
		{	
		 Write-Host "PC naming matches Division 0 Kiosk PC's"
		 $TSEnv:MachineObjectOU="OU=Kiosk,OU=Div0,OU=MyOU,DC=domain,DC=local"
		}
	 ElseIf ($TSEnv:OSDComputerName -match "0-ICT") 
		{
		 Write-Host "PC naming matches ICT department"
		 $TSEnv:MachineObjectOU="OU=WS,OU=ICT,OU=Div0,OU=MyOU,DC=domain,DC=local"
		 }
	 Else
		{
		 Write-Host "Cannot Determine Destination OU, using NonCompliant OU"
		}
	}		 
ElseIf ($TSEnv:OSDComputerName.StartsWith("1-")) 
	{
	 Write-Host "Found computer name starting with 1-, will try to find matching department for Division 1"
	 If ($TSEnv:OSDComputerName.Remove(0,$CharsToRemove).StartsWith("K")) 
		{	
		 Write-Host "PC naming matches Division 1 Kiosk PC's"
		 $TSEnv:MachineObjectOU="OU=Kiosk,OU=Div1,OU=MyOU,DC=domain,DC=local"
		}
	 ElseIf ($TSEnv:OSDComputerName -match "1-HRM") 
		{
		 Write-Host "PC naming matches HRM department"
		 $TSEnv:MachineObjectOU="OU=WS,OU=HRM,OU=Div1,OU=MyOU,DC=domain,DC=local"
		}
	 Else
		{
		 Write-Host "Cannot Determine Destination OU, using NonCompliant OU"
		}
    }
ElseIf ($TSEnv:OSDComputerName.StartsWith("2-")) 
	{
	 Write-Host "Found computer name starting with 2-, will try to find matching department for Division 2"
	 If ($TSEnv:OSDComputerName.Remove(0,$CharsToRemove).StartsWith("K")) 
		{	
		 Write-Host "PC naming matches Division 2 Kiosk PC's"
		 $TSEnv:MachineObjectOU="OU=Kiosk,OU=Div2,OU=MyOU,DC=domain,DC=local"
		}
	 ElseIf ($TSEnv:OSDComputerName -match "2-NEUR") 
		{
		 Write-Host "PC naming matches Neurology department"
		 $TSEnv:MachineObjectOU="OU=WS,OU=NEUR,OU=Div2,OU=MyOU,DC=domain,DC=local"	 
		}
	Else
		{
		 Write-Host "Cannot Determine Destination OU, using NonCompliant OU"
		}
	}
Else
	{
	 Write-Host "Name does not match 0-, 1- or 2- as starting characters. Will not be able to determine Destination OU, using NonCompliant OU."
	 $TSEnv:MachineObjectOU="OU=NonCompliant,OU=MyOU,DC=domain,DC=local"
	}

Write-Host "Target OU = $TSEnv:MachineObjectOU"		
Dir TSEnv: | FT -Auto | Out-File $VarDumpFile -Append
