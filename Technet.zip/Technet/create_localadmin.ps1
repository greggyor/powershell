$servers=get-content c:\temp\serverlist.txt
$usern="test-account"
$desc="test description"
$pwd="S3cur3P4ssW0rd"

foreach ($server in $servers) {
	if(Test-Connection -Cn $server -BufferSize 16 -Count 1 -ea 0) {
		[ADSI]$remcomp="WinNT://$server"
		$Account=$remcomp.create("User",$usern)
		$Account.SetPassword($pwd)
		$Account.Put("Description",$desc)
		$PwNoExpFlag=$Account.userflags.value -bor 0x10000
		$Account.Put("userflags", $PwNoExpFlag)
		$Account.SetInfo()
		[ADSI]$GroupN="WinNT://$server/Administrators,Group"
		$GroupN.Add($Account.Path)
	}
	ELSE {
@"
Machine name: $server
Server offline
------------------------------------
"@ >> c:\temp\badresults.txt
	}
}