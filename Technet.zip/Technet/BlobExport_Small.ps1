<# SYNOPSIS
      Export of small BLOB data with Ado.Net
   DESCRIPTION
      Export of small BLOB data using the GetSqlBinary of Ado.Net SqlDataReader without any conversions. 
      It has a good performance for BLOB data less then ~ 1 GB. Existing files will be overwritten.
   NOTES
      Author  : Olaf Helper
      Requires: PowerShell Version 2.0, Ado.Net assembly
   LINK
      GetSqlBinary: http://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqldatareader.getsqlbinary.aspx
#>

# Configuration data
[string] $server   = ".\SQLEXPRESS";          # SQL Server Instance
[string] $database = "AdventureWorks";      # Database containing the BLOB data.
[string] $folder   = "D:\Export\";          # Path to export to

# Select-Statement for file name & blob data with filter.
$sql = "SELECT [DOC].[FileName], [DOC].[Document]
        FROM [Production].[Document] AS [DOC]
        WHERE [DOC].[FileExtension] = '.doc'";

# Open ADO.NET Connection with Windows authentification.
$con = New-Object Data.SqlClient.SqlConnection;
$con.ConnectionString = "Data Source=$server;Initial Catalog=$database;Integrated Security=True;";
$con.open();

Write-Output ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Started ...");

# New command and reader.
$cmd = New-Object Data.SqlClient.SqlCommand $sql, $con;
$rd = $cmd.ExecuteReader();

# Looping through all selected datasets.
While ($rd.Read())
{
    try
    {
        Write-Output ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Exporting {0}" -f $rd.GetString(0));
        
        # New BinaryWriter; existing file will be overwritten.
        $fs = New-Object System.IO.FileStream ($folder + $rd.GetString(0)), Create, Write;
        $bw = New-Object System.IO.BinaryWriter $fs;
       
        # Read of complete Blob with GetSqlBinary
        $bt = $rd.GetSqlBinary(1).Value;
        $bw.Write($bt, 0, $bt.Length);    
        $bw.Flush();        
        $bw.Close();
        $fs.Close();
    }
    catch
    {
        Write-Output ($_.Exception.Message)
    }
    finally
    {
        $fs.Dispose();        
    }
}

# Closing & Disposing all objects
$rd.Close();
$cmd.Dispose();
$con.Close();
$con.Dispose();

Write-Output ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Finished");