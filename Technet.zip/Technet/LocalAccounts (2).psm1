#region Internal
function Connect-Commputer([string] $ComputerName)
{
	$computer = [adsi]"WinNT://$ComputerName"
	
	#check if the computer could be contacted, then the SchemaClassName should be 'computer'
	if ($computer.SchemaClassName -eq "Computer")
	{
		return $computer
	}
	else
	{
		throw "Computer not found"
	}
}

function Get-IdentityPathElements([string] $IdentityString)
{
	$numberOfSlashes = ($IdentityString.ToCharArray() -eq '/').Count
	$result = @{ Domain = ""; Computer = ""; Name = "" }
	
	if ($numberOfSlashes -eq 1) #syntax = computer/user
	{
		$result.Item('Computer') = $IdentityString.Split('/')[0]
		$result.Item('Name') = $IdentityString.Split('/')[1]
	}
	elseif ($numberOfSlashes -eq 2) #syntax = domain/computer/user
	{
		$result.Item('Domain') = $IdentityString.Split('/')[0]
		$result.Item('Computer') = $IdentityString.Split('/')[1]
		$result.Item('Name') = $IdentityString.Split('/')[2]
	}
	
	return $result
}
#endregion Internal

#region New-LocalUser
function New-LocalUser
{
<#
	.SYNOPSIS
		The command creates a new local user on the specified computer.
		
	.DESCRIPTION
		The command creates a new local user on the specified computer. If the computer is not specified the user is created on the computer the command is running on.
		
		To create a user the name and the password is required. Also the description can be defined.
	
	.INPUTS
		An PSObject containing the properties Name,ComputerName and Password.
	
	.OUTPUTS
		None or LocalAccount.LocalUser
    	This command returns an object for the new user only if the parameter PassThru is used. Without PassThrhu the command has no output.

	.PARAMETER Name
		The name of the new user account.
	
	.PARAMETER Password
		The password for the new user account.
		
	.PARAMETER ComputerName
		The NetBIOS Name of the computer to create the user on.

	.PARAMETER FullName
		The full name for the new user account.
		
	.PARAMETER Description
		The description for the new user account.
		
	.PARAMETER PassThru
		Returns a LocalAccount.LocalUser object for each user created.
		
	.EXAMPLE
		PS C:\> New-LocalUser -Name JohnD -FullName "John Doe" -Description "Standard User" -Password test123

		Description
		-----------
		This command creates a new user on the local machine.
		
	.EXAMPLE
		PS C:\> 1..15 | ForEach-Object { New-LocalUser -Name ("Test_{0:00}" -f $_) -Password ("Test_{0:00}" -f $_) -Description Testing -Verbose }

		Description
		-----------
		This command creates a 15 new user on the local machine. The format operator (-f) is used to have number as a double figure. In Verbose mode the command also writes a line for each user created to the host.
		
	.EXAMPLE
		PS C:\> $users = 1..15 | ForEach-Object { New-LocalUser -Name ("Test_{0:00}" -f $_) -Password ("Test_{0:00}" -f $_) -Description Testing -PassThru }
		PS C:\> $group = Get-LocalGroup -Identity Client1\TestGroup1
		PS C:\> $group | Add-LocalGroupMembership -Members $users

		Description
		-----------
		This command creates a 15 new user on the local machine. The format operator (-f) is used to have number as a double figure. The PassThru switch is used to return all new users for a later use.
		
		It then gets the group TestGroup1 of the machine Client1 (Client1\TestGroup1) and puts all the new users in that group
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$Name,
		
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$Password,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$ComputerName = $env:COMPUTERNAME,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$FullName,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$Description,
		
		[switch]$PassThru
	)
	
	process
	{
		try
		{
			if ($Name.Contains('/'))
			{
				$IdentityElements = Get-IdentityPathElements $Name
				$ComputerName = $IdentityElements.Item('Computer')
				$Name = $IdentityElements.Item('Name')
			}
			
			$computer = Connect-Commputer -ComputerName $ComputerName

			$user = $computer.Create("user", $Name)
			[Void]$user.SetPassword($password)
			if ($Description) { [Void]$user.Put("Description", $Description) }
			if ($FullName) { [Void]$user.Put("FullName", $FullName) }
			[Void]$user.SetInfo()
			
			Write-Verbose "User $Name created on computer $ComputerName"
			if ($PassThru)
			{
				return (Get-LocalUser -Identity (New-Object LocalAccount.LocalUser($user)))
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not create the local user $($ComputerName)/$($Name): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion New-LocalUser

#region Get-LocalUser
function Get-LocalUser
{
<#
	.SYNOPSIS
		The command gets a specific or all local user accounts from the specified computer.
		
	.DESCRIPTION
		The command gets a specific user. The user has to be specified in the the format ComputerName/UserName.
		
		For reading all local user accounts, use the -All switch. In this case also the ComputerName parameter has to be used.
		
		This command also reads users from a domain. This is needed if you want to add domain users to a local group using Add-LocalGroupMembership. See the examples provided with Add-LocalGroupMembership for further information.
	
	.INPUTS
		An PSObject containing the property Identity.
	
	.OUTPUTS
		LocalAccount.LocalUser

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
	
	.PARAMETER All
		If this switch is set, the command reads all local users from the specified computer. This does not work with domains.
		
	.PARAMETER ComputerName
		Specifies the computer from which all users should be read.
		
	.EXAMPLE
		PS C:\> Get-LocalUser Client1\Test

		Name FullName Description SID
		---- -------- ----------- ---
		Test Test                 S-1-5-21-1840872026-3697960037-2259357903-1004

		Description
		-----------
		This command gets the user 'Test' from the machine 'Client1'
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All -ComputerName Client1 | Where-Object { $_.Description -eq "Testing" }

		Name    FullName Description SID
		----    -------- ----------- ---
		Test_01 Test_01  Testing     S-1-5-21-1840872026-3697960037-2259357903-1068
		Test_02 Test_02  Testing     S-1-5-21-1840872026-3697960037-2259357903-1069
		Test_03 Test_03  Testing     S-1-5-21-1840872026-3697960037-2259357903-1070
		Test_04 Test_04  Testing     S-1-5-21-1840872026-3697960037-2259357903-1071
		Test_05 Test_05  Testing     S-1-5-21-1840872026-3697960037-2259357903-1072

		Description
		-----------
		This command gets all users from the machine Client1 whose description is 'Testing'
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true,ParameterSetName="ByName")]
		[LocalAccount.LocalUser]$Identity,
		
		[Parameter(ParameterSetName="All")]
		[string]$ComputerName,
		
		[Parameter(ParameterSetName="All")]
		[switch]$All
	)
	
	process
	{
		$IdentityElements = Get-IdentityPathElements $Identity
		
		switch ($pscmdlet.ParameterSetName)
		{
			"ByName"
			{
				return $Identity
			}
			"All"
			{
				try
				{
					if ($ComputerName -eq [string]::Empty)
					{
						$ComputerName = $env:COMPUTERNAME
					}
					
					$computer = Connect-Commputer -ComputerName $ComputerName
					
					$computer.Children.SchemaFilter.Add("User")
					foreach ($user in $computer.Children)
					{
						(New-Object LocalAccount.LocalUser($user))
					}
				}
				catch [Exception]
				{
					Write-Error -Message "Could not get local users from machine $($ComputerName): $($_.Exception.Message)" -Exception $_.Exception
				}	
			}
		}
	}
}
#endregion Get-LocalUser

#region Set-LocalUser
function Set-LocalUser
{
<#
	.SYNOPSIS
		The command sets a local user on the specified computer.
		
	.DESCRIPTION
		This command takes a LocalUser object and changes it depending on the given parameters.
		
		Chaning the name, fullname and description is possible.
	
	.INPUTS
		An LocalUser object or a string (machine/username) pointing to a local user.
	
	.OUTPUTS
		None or LocalAccount.LocalUser
    	This command returns an object for the changed user only if the parameter PassThru is used. Without PassThrhu the command has no output.

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
		
	.PARAMETER Name
		The new name for the new user account. In fact this renames the account.

	.PARAMETER FullName
		The new full name for the new user account.
		
	.PARAMETER Description
		The new description for the new user account.
		
	.PARAMETER PassThru
		Returns a LocalAccount.LocalUser object for each user created.
		
	.EXAMPLE
		PS C:\> Set-LocalUser -Identity Client1\T1 -Description "Test Account 1" -FullName ""

		Description
		-----------
		This command sets a new Description for the account T1 on machine Client1. It also removes the fullname.
		
	.EXAMPLE
		PS C:\> Set-LocalUser -Identity Client1\T1 -Name T2 -Description "Test Account 2"

		Description
		-----------
		This command renames the account T1 on machine Client1 to T2 and also set the description accordingly.
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All | Where-Object { $_.Name -like "Test_*" } | ForEach-Object { Set-LocalUser -Identity $_ -Description ("Test Account " + [regex]::Match($_.Name, "\d+").Value) -PassThru }
		
		Name    FullName Description     SID
		----    -------- -----------     ---
		Test_01 Test_01  Test Account 01 S-1-5-21-4004058760-1322732122-2562739762-1107
		Test_02 Test_02  Test Account 02 S-1-5-21-4004058760-1322732122-2562739762-1108
		Test_03 Test_03  Test Account 03 S-1-5-21-4004058760-1322732122-2562739762-1109
		Test_04 Test_04  Test Account 04 S-1-5-21-4004058760-1322732122-2562739762-1110
		Test_05 Test_05  Test Account 05 S-1-5-21-4004058760-1322732122-2562739762-1111
		...

		Description
		-----------
		This command changes the description of all account with the name 'Test_*'. The description is a combination of the fixes string 'Test Account ' and the number of the account in the name extracted using a regular expression.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalUser]$Identity,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$Name,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$Description,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$FullName,
		
		[switch]$PassThru
	)
	
	process
	{
		$IdentityElements = Get-IdentityPathElements $Identity
		
		try
		{
			if ($Name)
			{
				$Identity.BaseObject.Rename($Name)
			}
			if ($PSBoundParameters.ContainsKey("Description"))
			{
				$Identity.BaseObject.Description = $Description
				$Identity.BaseObject.SetInfo()
			}
			if ($PSBoundParameters.ContainsKey("FullName"))
			{
				$Identity.BaseObject.FullName = $FullName
				$Identity.BaseObject.SetInfo()
			}
			
			Write-Verbose "User $Identity changed"
			
			if ($PassThru)
			{
				return (Get-LocalUser -Identity $Identity.ToString())
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not set the local user $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Get-LocalUser

#region Remove-LocalUser
function Remove-LocalUser
{
<#
	.SYNOPSIS
		The command removes a local user on the specified computer.
		
	.DESCRIPTION
		This command takes a LocalUser object and removes it from the respective machine.
	
	.INPUTS
		An LocalUser object or a string (machine/username) pointing to a local user.
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
		
	.EXAMPLE
		PS C:\> PS C:\Users\raandree\Documents> Remove-LocalUser -Identity Client1\JohnDoe
		WARNING: User Client1/JohnDoe deleted

		Description
		-----------
		This command removes the local user JohnDoe from the machine Client1.
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All | Where-Object { $_.Name -like "Test_*" } | Remove-LocalUser
		WARNING: User WORKGROUP/Client1/Test_01 deleted
		WARNING: User WORKGROUP/Client1/Test_02 deleted
		WARNING: User WORKGROUP/Client1/Test_03 deleted
		WARNING: User WORKGROUP/Client1/Test_04 deleted
		WARNING: User WORKGROUP/Client1/Test_05 deleted
		...
		
		Description
		-----------
		This command read all test users from the local machine and removes them.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalUser]$Identity
	)
	
	process
	{
		try
		{
			$IdentityElements = Get-IdentityPathElements $Identity
			
			$computer = Connect-Commputer -ComputerName $IdentityElements.Item('Computer')
			$computer.Children.Remove($Identity.BaseObject)
			
			Write-Warning "User $Identity deleted"
		}
		catch [Exception]
		{
			Write-Error -Message "Could not delete the local user $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Remove-LocalUser

#region Enable-LocalUser
function Enable-LocalUser
{
<#
	.SYNOPSIS
		The command enables the specified user
		
	.DESCRIPTION
		This command takes a LocalUser object and enables it from the respective machine.
	
	.INPUTS
		An LocalUser object or a string (machine/username) pointing to a local user.
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
		
	.PARAMETER PassThru
		Returns a LocalAccount.LocalUser object for each user enabled.
		
	.EXAMPLE
		PS C:\> PS C:\Users\raandree\Documents> Enable-LocalUser -Identity Client1\JohnDoe

		Description
		-----------
		This command enables the local user JohnDoe on the machine Client1.
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All | Where-Object { $_.Name -like "Test_*" } | Enable-LocalUser
		
		Description
		-----------
		This command read all test users from the local machine and enables them.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalUser]$Identity,
		
		[switch]$PassThru
	)
	
	process
	{
		try
		{
			$IdentityElements = Get-IdentityPathElements $Identity
			
			$Identity.BaseObject.AccountDisabled = $false
			$Identity.BaseObject.SetInfo()
			Write-Verbose "User $Identity enabled"
			
			if ($PassThru)
			{
				return $Identity
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not enable the local user $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Enable-LocalUser

#region Disable-LocalUser
function Disable-LocalUser
{
<#
	.SYNOPSIS
		The command disables the specified user
		
	.DESCRIPTION
		This command takes a LocalUser object and disables it from the respective machine.
	
	.INPUTS
		An LocalUser object or a string (machine/username) pointing to a local user.
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
		
	.PARAMETER PassThru
		Returns a LocalAccount.LocalUser object for each user disabled.
		
	.EXAMPLE
		PS C:\> PS C:\Users\raandree\Documents> Enable-LocalUser -Identity Client1\JohnDoe

		Description
		-----------
		This command disables the local user JohnDoe on the machine Client1.
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All | Where-Object { $_.Name -like "Test_*" } | Enable-LocalUser
		
		Description
		-----------
		This command read all test users from the local machine and disables them.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalUser]$Identity,
		
		[switch]$PassThru
	)
	
	process
	{
		try
		{
			$IdentityElements = Get-IdentityPathElements $Identity
			
			$Identity.BaseObject.AccountDisabled = $true
			$Identity.BaseObject.SetInfo()
			Write-Verbose "User $Identity disabled"
			
			if ($PassThru)
			{
				return $Identity
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not enable the local user $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Disable-LocalUser

#region Reset-LocalUserPassword
function Reset-LocalUserPassword
{
<#
	.SYNOPSIS
		The command resets the password for the specified user
		
	.DESCRIPTION
		This command takes a LocalUser object and resets the password for it on the respective machine.
	
	.INPUTS
		An LocalUser object or a string (machine/username) pointing to a local user.
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/UserName or DomainName/UserName (also back-slash is allowed).
		
	.PARAMETER Password
		The new password for the account. This is not treated as a System.SecureString and will be handled in memory in plain text.
		
	.EXAMPLE
		PS C:\> PS C:\Users\raandree\Documents> Reset-LocalUserPassword -Identity Client1\JohnDoe -Password test123

		Description
		-----------
		This command resets the password for the local user JohnDoe on the machine Client1.
		
	.EXAMPLE
		PS C:\> Get-LocalUser -All | Where-Object { $_.Name -like "Test_*" } | Reset-LocalUserPassword -Password test123
		
		Description
		-----------
		This command read all test users from the local machine and sets a new password for them.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalUser]$Identity,
		
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[string]$Password
	)
	
	process
	{
		try
		{
			$IdentityElements = Get-IdentityPathElements $Identity
			
			$Identity.BaseObject.SetPassword($Password)
			Write-Verbose "Ppassword for user $Identity has been reset"
		}
		catch [Exception]
		{
			Write-Error -Message "Could not reset password for the local user $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Reset-LocalUserPassword

#----------------------------------------------------------------------------------

#region New-LocalGroup
function New-LocalGroup
{
<#
	.SYNOPSIS
		The command creates a new local group on the specified computer.
		
	.DESCRIPTION
		The command creates a new local group on the specified computer. If the computer is not specified the group is created on the computer the command is running on.
		
		To create a group just the name is required. Also the description can be defined.
	
	.INPUTS
		An PSObject containing the properties Name,ComputerName.
	
	.OUTPUTS
		None or LocalAccount.LocalGroup
    	This command returns an object for the new user only if the parameter PassThru is used. Without PassThrhu the command has no output.

	.PARAMETER Name
		The name of the new group account.
		
	.PARAMETER ComputerName
		The NetBIOS Name of the computer to create the group on.

	.PARAMETER Description
		The description for the new group account.
		
	.PARAMETER PassThru
		Returns a LocalAccount.LocalGroup object for each user created.
		
	.EXAMPLE
		PS C:\> New-LocalGroup -Name StandardUsers -Description "Standard Users"

		Description
		-----------
		This command creates a new group on the local machine.
		
	.EXAMPLE
		PS C:\> Import-Csv .\groups.csv -Delimiter ';' | New-LocalGroup -PassThru

		Name   Description    SID
		----   -----------    ---
		Users1 Standard Users S-1-5-21-3237331522-1427718024-1612564886-1004
		Users2 Power Users    S-1-5-21-3237331522-1427718024-1612564886-1005
		Admins Administrators S-1-5-21-3237331522-1427718024-1612564886-1006
		Test   Test Users     S-1-5-21-3237331522-1427718024-1612564886-1007

		Description
		-----------
		This command creates all groups defined in the file 'group.csv'. The CSV file must have the columns Name and Description and optionally the ComputerName.
		
		This is the file used for this command:
		
			Name;Description;ComputerName
			Users1;Standard Users;MSADRAP2
			Users2;Power Users;MSADRAP2
			Admins;Administrators;MSADRAP2
			Test;Test Users;MSADRAP2
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[string]$Name,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$ComputerName = $env:COMPUTERNAME,
		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[string]$Description,
		
		[switch]$PassThru
	)
	
	process
	{
		try
		{
			if ($Name.Contains('/'))
			{
				$IdentityElements = Get-IdentityPathElements $Name
				$ComputerName = $IdentityElements.Item('Computer')
				$Name = $IdentityElements.Item('Name')
			}
			
			$computer = Connect-Commputer -ComputerName $ComputerName

			$group = $computer.Create("group", $Name)
			[Void]$group.Put("Description", $Description) 
			[Void]$group.SetInfo()
			
			Write-Verbose "Group $Name created on computer $ComputerName"
			if ($PassThru)
			{
				return (Get-LocalGroup -Identity (New-Object LocalAccount.LocalGroup($group)))
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not create the local group $($ComputerName)/$($Name): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion New-LocalGroup

#region Get-LocalGroup
function Get-LocalGroup
{
<#
	.SYNOPSIS
		The command gets a specific or all local group accounts from the specified computer.
		
	.DESCRIPTION
		The command gets a specific group. The group has to be specified in the the format ComputerName/GroupName.
		
		For reading all local group accounts, use the -All switch. In this case also the ComputerName parameter has to be used.
	
	.INPUTS
		An LocalGroup object or a string (machine/username) pointing to a local group.
	
	.OUTPUTS
		LocalAccount.LocalGroup

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/GroupName or DomainName/GroupName (also back-slash is allowed).
	
	.PARAMETER All
		If this switch is set, the command reads all local groups from the specified computer. This does not work with domains.
		
	.PARAMETER ComputerName
		Specifies the computer from which all groups should be read.
		
	.EXAMPLE
		PS C:\> Get-LocalGroup -Identity Client1\TestGroup1

		Name       Description SID
		----       ----------- ---
		TestGroup1 Testing     S-1-5-21-4004058760-1322732122-2562739762-1106

		Description
		-----------
		This command gets the group 'TestGroup1' from the machine 'Client1'
		
	.EXAMPLE
		PS C:\> Get-LocalGroup -All

		WARNING: column "SID" does not fit into the display and was removed.

		Name                                       Description
		----                                       -----------
		Administrators                             Administrators have complete and unrestricted access to the computer/domain
		Backup Operators                           Backup Operators can override security restrictions for the sole purpose of backing up or restoring files
		Cryptographic Operators                    Members are authorized to perform cryptographic operations.
		Distributed COM Users                      Members are allowed to launch, activate and use Distributed COM objects on this machine.
		Event Log Readers                          Members of this group can read event logs from local machine
		Guests                                     Guests have the same access as members of the Users group by default, except for the Guest account whic...
		...

		Description
		-----------
		This command gets all groups form the current machine.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true,ParameterSetName="ByName")]
		[LocalAccount.LocalGroup]$Identity,
		
		[Parameter(ParameterSetName="All")]
		[string]$ComputerName,
		
		[Parameter(ParameterSetName="All")]
		[switch]$All
	)
	
	process
	{
		$IdentityElements = Get-IdentityPathElements $Identity
		
		switch ($pscmdlet.ParameterSetName)
		{
			"ByName"
			{
				return $Identity
			}
			"All"
			{
				try
				{
					if ($ComputerName -eq [string]::Empty)
					{
						$ComputerName = $env:COMPUTERNAME
					}
					
					$computer = Connect-Commputer -ComputerName $ComputerName
					
					[Void]$computer.Children.SchemaFilter.Add("Group")
					foreach ($group in $computer.Children)
					{
						(New-Object LocalAccount.LocalGroup($group))
					}
				}
				catch [Exception]
				{
					Write-Error -Message "Could not get the local groups from computer $($ComputerName): $($_.Exception.Message)" -Exception $_.Exception
				}	
			}
		}
	}
}
#endregion Get-LocalGroup

#region Remove-LocalGroup
function Remove-LocalGroup
{
<#
	.SYNOPSIS
		The command removes a local group on the specified computer.
		
	.DESCRIPTION
		This command takes a LocalGroup object and removes it from the respective machine.
	
	.INPUTS
		An LocalGroup object or a string (machine/groupname) pointing to a local group.
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/GroupName or DomainName/GroupName (also back-slash is allowed).
		
	.EXAMPLE
		PS C:\> PS C:\Users\raandree\Documents> Remove-LocalGroup -Identity Client1\TestGroup1
		WARNING: Group Client1/TestGroup1 deleted

		Description
		-----------
		This command removes the local group TestGroup1 from the machine Client1.
		
	.EXAMPLE
		PS C:\> Get-LocalGroup -All | Where-Object { $_.Name -like "Test_*" } | Remove-LocalGroup
		WARNING: User WORKGROUP/Client1/TestGroup_01 deleted
		WARNING: User WORKGROUP/Client1/TestGroup_02 deleted
		WARNING: User WORKGROUP/Client1/TestGroup_03 deleted
		WARNING: User WORKGROUP/Client1/TestGroup_04 deleted
		WARNING: User WORKGROUP/Client1/TestGroup_05 deleted
		...
		
		Description
		-----------
		This command read all test groups from the local machine and removes them.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalGroup]$Identity
	)
	
	process
	{
		try
		{
			$IdentityElements = Get-IdentityPathElements $Identity
			
			$computer = Connect-Commputer -ComputerName $IdentityElements.Item('Computer')
			$computer.Children.Remove($Identity.BaseObject)
			
			Write-Warning "Group $Identity deleted"
		}
		catch [Exception]
		{
			Write-Error -Message "Could not delete the local group $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Remove-LocalGroup

#region Get-LocalGroupMembership
function Get-LocalGroupMembership
{
<#
	.SYNOPSIS
		The command gets the members of a group.
		
	.DESCRIPTION
		The command gets the members of a specific group. The group has to be specified in the the format ComputerName/GroupName.
		
		The group you want to get the members from can also be piped into the cmdlet.
	
	.INPUTS
		An PSObject containing the property Identity or the 
	
	.OUTPUTS
		LocalAccount.LocalUser

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/GroupName or DomainName/GroupName (also back-slash is allowed).
	
	.EXAMPLE
		PS C:\> Get-LocalGroup Client1\Administrators | Get-LocalGroupMembership

		Name          FullName Description                                            SID
		----          -------- -----------                                            ---
		Administrator          Built-in account for administering the computer/domain S-1-5-21-4004058760-1322732122-2562739762-500
		User1                                                                         S-1-5-21-4004058760-1322732122-2562739762-1000

		Description
		-----------
		This command gets all member of the group 'Administrators' on machine 'Client1'.
		
	.EXAMPLE
		PS C:\> Get-LocalGroup -All | ForEach-Object { $_ | Get-LocalGroupMembership | Add-Member -Name Group -MemberType NoteProperty -Value $_ -PassThru } | Format-Table Group,Name,FullName,SID -AutoSize

		Group                              Name          FullName Sid
		-----                              ----          -------- ---
		WORKGROUP/Client1/Administrators   Administrator          Client1\Administrator (S-1-5-21-4004058760-1322732122-2562739762-500)
		WORKGROUP/Client1/Administrators   raandree               Client1\raandree (S-1-5-21-4004058760-1322732122-2562739762-1000)
		WORKGROUP/Client1/Guests           Guest                  Client1\Guest (S-1-5-21-4004058760-1322732122-2562739762-501)
		WORKGROUP/Client1/Users            Test          Test     Client1\Test (S-1-5-21-4004058760-1322732122-2562739762-1009)

		Description
		-----------
		This command gets all groups form the current machine and retreives all their members. The group is then added to each member to also report the group with the members.
		
		As the newly created property 'Group' is not part of the default formatter we have to use Format-Table to make it appear on the console.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalGroup]$Identity
	)
	
	process
	{
		try
		{
			$memberObjects = $Identity.BaseObject.psbase.Invoke("Members")
			foreach ($memberObject in $memberObjects)
			{
				$adsPath = $memberObject.GetType().InvokeMember("ADSPath", 'GetProperty', $null, $memberObject, $null)
				$class = $memberObject.GetType().InvokeMember("Class", 'GetProperty', $null, $memberObject, $null)
				
				if ($adsPath.Contains("S-1-5"))
				{
					Write-Warning "Could not resolve an entry in the group membership list: The entry is $adsPath"
					continue
				}
				
				if ($class -eq "user")
				{
					New-Object LocalAccount.LocalUser($adsPath.Substring(8))
				}
				elseif ($class -eq "computer")
				{
					New-Object LocalAccount.LocalGroup($adsPath.Substring(8))
				}
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not get local group members of group $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Get-LocalGroupMembership

#region Add-LocalGroupMembership
function Add-LocalGroupMembership
{
<#
	.SYNOPSIS
		The command adds members to a group.
		
	.DESCRIPTION
		The command adds all entries in the member parameter to a specific group. The group has to be specified in the the format ComputerName/GroupName.
		
		The group you want to add the members to can also be piped into the cmdlet.
	
	.INPUTS
		An PSObject containing the property Identity or the 
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/GroupName or DomainName/GroupName (also back-slash is allowed).
		
	.PARAMETER Members
		A single LocalUser object or a list of LocalUser objects retreived with Get-LocalUser that will be added to the group membership list.
	
	.EXAMPLE
		PS C:\> Get-LocalGroup -Identity Client1/TestGroup1 | Add-LocalGroupMembership -Members (Get-LocalUser -Identity Client1/JohnD)
		Client1/JohnD was added to Client1/TestGroup1

		Description
		-----------
		This command adds the local user 'JohnD' to the group 'TestGroup1'.
		
	.EXAMPLE
		PS C:\> Get-LocalGroup -Identity Client1/TestGroup1 | Add-LocalGroupMembership -Members (Get-LocalUser -All | Where-Object { $_.Description -eq "Testing" })
		WORKGROUP/Client1/JohnD was added to Client1/TestGroup1
		WORKGROUP/Client1/LucyS was added to Client1/TestGroup1

		Description
		-----------
		This command adds all users with the description 'Testing' to the local group 'TestGroup1'.
		
	.EXAMPLE
		PS C:\> New-LocalGroup -Name TestGroup2 -Description Testing -PassThru | Add-LocalGroupMembership -Members (Get-LocalGroup -Identity Client1/TestGroup1 | Get-LocalGroupMembership)
		WORKGROUP/Client1/JohnD was added to WORKGROUP/Client1/TestGroup2
		WORKGROUP/Client1/LucyS was added to WORKGROUP/Client1/TestGroup2

		Description
		-----------
		This command creates a new group names 'TestGroup2' and copies the group membership for the new group from 'TestGroup1'.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalGroup]$Identity,
		
		[LocalAccount.LocalPrincipal[]]$Members
	)
	
	process
	{
		try
		{
			foreach ($member in $Members)
			{
				$Identity.BaseObject.psbase.Invoke("Add", $member.BaseObject.Path)
				Write-Host "$Member was added to $Identity" -ForegroundColor DarkGreen
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not add members to local group $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Add-LocalGroupMembership

#region Remove-LocalGroupMembership
function Remove-LocalGroupMembership
{
<#
	.SYNOPSIS
		The command removes members from a group.
		
	.DESCRIPTION
		The command removes all entries in the member parameter from a specific group. The group has to be specified in the the format ComputerName/GroupName.
		
		The group you want to remove the members from can also be piped into the cmdlet.
	
	.INPUTS
		An PSObject containing the property Identity or the 
	
	.OUTPUTS
		None

	.PARAMETER Identity
		This paramter must be specified in the synatx ComputerName/GroupName or DomainName/GroupName (also back-slash is allowed).
		
	.PARAMETER Members
		A single LocalUser object or a list of LocalUser objects retreived with Get-LocalUser that will be removed from the group membership list.
	
	.EXAMPLE
		PS C:\> Get-LocalGroup -Identity Client1/TestGroup1 | Remove-LocalGroupMembership -Members (Get-LocalUser -Identity Client1/JohnD)
		Client1/JohnD was added to Client1/TestGroup1

		Description
		-----------
		This command removes the local user 'JohnD' from the group 'TestGroup1'.
		
	.EXAMPLE
		PS C:\Users\raandree\Desktop> Get-LocalGroup -Identity Client1/TestGroup1 | Remove-LocalGroupMembership -Members (Get-LocalUser -All | Where-Object { $_.Description -eq 'Testing' })
		WORKGROUP/Client1/JohnD was removed from Client1/TestGroup1
		WORKGROUP/Client1/LucyS was removed from Client1/TestGroup1

		Description
		-----------
		This command removes all users with the description 'Testing' from the local group 'TestGroup1'.
#>
	[CmdletBinding()]
	Param(
	 	[Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[LocalAccount.LocalGroup]$Identity,
		
		[LocalAccount.LocalPrincipal[]]$Members
	)
	
	process
	{
		try
		{
			foreach ($member in $Members)
			{
				if ($Identity.BaseObject.psbase.Invoke("IsMember", $member.BaseObject.Path))
				{
					$Identity.BaseObject.psbase.Invoke("Remove", $member.BaseObject.Path)
					Write-Host "$Member was removed from $Identity" -ForegroundColor DarkGreen
				}
				else
				{
					Write-Warning "$Member was not a member of $Identity and could not be removed"
				}
				
			}
		}
		catch [Exception]
		{
			Write-Error -Message "Could not remove members to local group $($Identity): $($_.Exception.Message)" -Exception $_.Exception
		}
	}
}
#endregion Remove-LocalGroupMembership