#Requires �Version 2.0 
#========================================================================
# This PS driven by:   http://about.me/DavidTesar 
# This script is not officially supported by Microsoft, but will respond 
# as "best effort" to bug inquiries at ad2aad@microsoft.com.  
# This script is designed to work in conjunction with the quickstart guide 
# found at http://aka.ms/AD2AAD.
#
# Script Version 1.0, Released 3/7/2013
#========================================================================

#region ----- script-level variables -----

Set-Variable -Name CurrentExecutingPath -Scope 'script' -Option 'ReadOnly'-Value (Split-Path $MyInvocation.MyCommand.Definition)

Set-Variable -Name CertificateFriendlyName -Scope 'script' -option 'ReadOnly' -Value 'AD to AAD QuickStart ADFS Certificate'

$script:ADFSDomainName = $null
$script:ADFSAccountName = $null
$script:ADFSAccountPassword = $null
$script:ADFSSubjectName = $null
$script:ADFSSubjectDomainName = $null
$script:ADFSCredentials = $null

$script:MsolCredential = $null

$script:ADFSSite = $null

$script:MSOLConnected = $false

$script:CertificateFileName = $script:CurrentExecutingPath + '\ADFSSelfSigned.pfx'

# http://msdn.microsoft.com/en-us/library/aa374830.aspx
$script:AltNameType = @{
	DNS_NAME = 3 # A Domain Name System (DNS) name such as MyDomain.Microsoft.com.
	IP_ADDRESS = 8 # An Internet Protocol (IP) address in dotted decimal format 123.456.789.123.
}

#endregion

#region ----- support functions -----

function Write-QSCompletionMessage {
	Write-Host ''
	Write-Host 'Completed. Press "Enter" to continue.'
	Read-Host
	Write-Host ''
}

# Writes an error message to the host
function Write-QSError {
	param (
		[Parameter(Mandatory=$true, HelpMessage="The error message.")]
		[string] $Message
	)
	#Write-Error $Message
	Write-Host ''
	Write-Host -BackgroundColor 'Black' -ForegroundColor 'Red' $Message
	Write-Host ''
}

# Writes a warning message to the host
function Write-QSWarning {
	param (
		[Parameter(Mandatory=$true, HelpMessage="The warning message.")]
		[string] $Message
	)
	Write-Host ''
	Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' $Message
	Write-Host ''
}

# Returns $true if the current execution environment is elevated.
function Get-QSElevationStatus {
	$wid = [System.Security.Principal.WindowsIdentity]::GetCurrent()
	$prp = New-Object System.Security.Principal.WindowsPrincipal($wid)
	$adm = [System.Security.Principal.WindowsBuiltInRole]::Administrator
	$IsAdmin = $prp.IsInRole($adm)
	return $IsAdmin
}

# Is this a 32-bit process on a 64-bit system?
function Test-QSWow64() {
    return (Test-QSWin32) -and (Test-Path env:\PROCESSOR_ARCHITEW6432)
}

# Is this a 64 bit process?
function Test-QSWin64() {
    return [IntPtr]::size -eq 8
}

# Is this a 32 bit process?
function Test-QSWin32() {
    return [IntPtr]::size -eq 4
}

# Is this a server OS SKU?
function Test-QSServerOS() {
	return ((Get-WmiObject Win32_OperatingSystem).ProductType -ne 1)
}

# Is this server 2012/Windows 8 or later?
function Test-QSWindows8OrLater() {
	return ((Get-WmiObject Win32_OperatingSystem).Version -ge (New-Object System.Version(6,2,0,0)))
}

# Writes a nicely formatted title for an area.
function Write-QSTitle {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The title of the current area.')]
		[string] $Title,
		[Parameter(Mandatory=$false, HelpMessage='Indicates a double dashed line should be used.')]
		[switch] $DoubleDashedLine
	)
	$DashedLine = '-' * ($Title.Length + 10)
	Write-Host ''
	Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' $DashedLine
	if ($DoubleDashedLine) {
		Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' $DashedLine
	}
	Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' "     $Title     "
	Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' $DashedLine
	if ($DoubleDashedLine) {
		Write-Host -BackgroundColor 'Black' -ForegroundColor 'Yellow' $DashedLine
	}
	Write-Host ''
}

# asks the user for an item from a list
function Read-QSListChoice {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The list of choices.')]
		[string[]] $Choices,
		[Parameter(Mandatory=$true, HelpMessage='The title for the choice.')]
		[string] $Title,
		[Parameter(Mandatory=$true, HelpMessage='The user prompt for the choice.')]
		[string] $Prompt
	)
	if ($Choices.Count -eq 0) {
		return $null
	}
	if ($Choices.Count -eq 1) {
		return $Choices[0]
	}
	Write-Host ' '
	Write-Host $Title
	Write-Host ' '
	Write-Host ' 0) NONE'
	for ($Counter = 0; $Counter -lt $Choices.Count; $Counter++) {
		Write-Host ('{0,2}) {1}' -f ($Counter + 1), $Choices[$Counter])
	}
	Write-Host ''
	$Choice = Read-Host $Prompt
	if ($Choice -eq 0) {
		Write-QSWarning 'Cancelled.'
		return $null
	}
	return $Choices[$Choice-1]
}

function Require-QSDownloadableFile {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The name of the file that should be downloaded if it is not present.')]
		[string] $FileName,
		[Parameter(Mandatory=$true, HelpMessage='The URL source for the file for downloading if it is not present.')]
		[string] $URL
	)
	if ((Test-Path "$Filename") -ne $true) {
		Write-Host "Downloading $Filename`n            from $URL`n            please wait..."
		$webClient = New-Object System.Net.WebClient
		try {
			$webClient.DownloadFile($url, "$Filename")
			Unblock-File -Path "$Filename"
		}
		catch {
			return $false
		}
	}
	$true
}

function Require-QSLocalFile {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The name of the file that should be present.')]
		[string] $FileName
	)
	if ((Test-Path $Filename) -ne $true) {
		Write-QSError "Required local file not present: $Filename"
		return $false
	}
	$true
}

function Require-QSProduct {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The display name of the MSI package as shown in "Add/Remove Programs".')]
		[string] $DisplayName,
		[Parameter(Mandatory=$true, HelpMessage='The filename for the MSI source for the installation')]
		[string] $FileName,
		[Parameter(Mandatory=$true, HelpMessage='The download URL for the MSI if it is not available locally.')]
		[string] $URL
	)
	Write-Host "Checking to see if machine already has product $DisplayName installed..."
	$Product = Get-WmiObject -Class Win32_Product -ComputerName . | Where-Object -FilterScript { $_.Name -eq $DisplayName }
	if ($Product -eq $null) {
		$MSIFilename = $script:CurrentExecutingPath + "\$FileName"
		if (Require-QSDownloadableFile -url $URL -filename $MSIFilename) {
			Write-Host "Installing MSI $MSIFilename`n               please wait..."
			$ExitCode = (Start-Process -Wait -PassThru -FilePath msiexec -ArgumentList /i, $msiFilename, /qb, /l*vx, $env:TEMP\$FileName.txt).ExitCode
			if ($ExitCode -eq 0) {
				Write-Host 'Installation complete.'
				return $true
			} else {
				Write-Error "FAILURE ON INSTALL: $ExitCode"
				return $false
			}
		} else {
			Write-Error "Could not download $MSIFilename from $URL"
			return $false
		}
	} else {
		Write-Host 'Product is already installed, will not reinstall.'
		return $true
	}
}

Function Require-QSModule {
	param (
		[Parameter(Mandatory=$true, HelpMessage='Name of the PowerShell module that is required.')]
		[string] $Name,
		[Parameter(Mandatory=$false, HelpMessage='Return a status code of false rather than failing if not found.')]
		[switch] $PoliteCheck
	)
	if (-not (Get-Module -name $Name)) { 
		Write-Host "Attempting to load system module $Name" -ErrorAction 'SilentlyContinue'
		Import-Module -Name $Name -ErrorAction 'SilentlyContinue'
		$Results = $?
		if ($PoliteCheck) {
			return $Results
		} else {
			Test-QSRequirement -Requirement $Results -Message "Could not load required PowerShell module $Name."
		}
	}
	if ($PoliteCheck) {
		return $true
	}
}

# Ensures a feature is installed on the local machine.
function Require-QSWindowsFeature {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The name of the Windows feature that is required.')]
		[string] $FeatureName
	)
	if ((Get-WindowsFeature $FeatureName).Installed -eq $false) {
		Write-Host "Local Windows Feature $FeatureName missing, installing..."
		$InstallResult = Install-WindowsFeature $FeatureName
		Test-QSRequirement -Requirement $InstallResult.Success -Message "Required Windows feature $FeatureName failed to install."
	}
}

# Runs a command and waits for it to exit
function Invoke-QSCommand() {
    param (
		[Parameter(Mandatory=$true, HelpMessage='The name of the executable to execute.')]
		[string] $Program,
		[Parameter(Mandatory=$false, HelpMessage='The arguments to the command.')]
        [string] $ArgumentString = ''
	)

    $psi = New-Object 'Diagnostics.ProcessStartInfo'
    $psi.FileName = $Program 
    $psi.Arguments = $ArgumentString
	$psi.RedirectStandardError = $false
	$psi.RedirectStandardOutput = $false
    $proc = [Diagnostics.Process]::Start($psi)
    $proc.WaitForExit();
}

# gets the list of UPN suffixes for the current forest
function Get-QSDomainSuffixes {
	Require-QSWindowsFeature RSAT-AD-Powershell
	Require-QSModule ActiveDirectory
	$Domain = Get-ADDomain
	$DomainDN = $Domain.distinguishedName
	$UPNDN = "cn=Partitions,cn=Configuration,$domaindn"            
	$UPNSuffixes = Get-ADObject -Identity $UPNDN -Properties upnsuffixes | Foreach-Object { $_.upnsuffixes }
	if ($UPNSuffixes -eq $null) {
		$UPNSuffixes = @( $Domain.DNSRoot )
	} else {
		if ($UPNSuffixes.count -eq 1) {
			$UPNSuffixes = @($UPNSuffixes)
		}
		$UPNSuffixes += $Domain.DNSRoot
	}
	return $UPNSuffixes
}

# Checks a local requirement based on the boolean passed in and reports an error and exits if the requirement is
# not met.
function Test-QSRequirement {
	param (
		[Parameter(Mandatory=$true, HelpMessage='Requirement that is being checked that must be $true.')]
		[boolean] $Requirement,
		[Parameter(Mandatory=$true, HelpMessage='The message to present to the user if the requirement is not met.')]
		[string] $Message
	) 
	
	if (-not $Requirement) {
		Write-QSError $Message
		Write-Host 'Cannot continue - exiting.'
		Exit
	}
}

# Installs the sign-in assistant
function Install-QSSignInAssistant {
	return Require-QSProduct -URL 'http://go.microsoft.com/fwlink/p/?linkid=236300' -FileName 'msoidcrl.msi' -DisplayName 'Microsoft Online Services Sign-in Assistant'	
}

# Installs the MSOL PowerShell module MSI
function Install-QSMsolServicesModule {
	Require-QSWindowsFeature Net-Framework-Core
	Require-QSWindowsFeature PowerShell-V2
	$InstallResults = Install-QSSignInAssistant
	Test-QSRequirement -Requirement $InstallResults -Message 'Cannot install MSOL PowerShell without Sign-In Assistant'
	return Require-QSProduct -URL 'http://go.microsoft.com/fwlink/p/?linkid=236297' -FileName 'AdministrationConfig-en.msi' -DisplayName 'Microsoft Online Services Module for Windows PowerShell'
}

# Require we have an active MSOL connection.
function Require-QSActiveMsolConnection {
	if ($script:MSOLConnected) {
		return
	}
	if (-not (Require-QSModule -Name MSOnline -PoliteCheck)) {
		Write-Host 'The required Microsoft Online Services Module for Windows PowerShell is not installed. It will be installed now.'
		Test-QSRequirement -Requirement (Install-QSMsolServicesModule) -Message 'Required module did not install, so script cannot continue.'
		Require-QSModule -Name MSOnline
	}
	Write-Host 'Checking for connection to Microsoft Online Services...'
	$script:MSOLConnected = $false
	while (-not $script:MSOLConnected) {
		$MSOLDomains = Get-MsolDomain -ErrorAction 'SilentlyContinue'
		if($?) {
    		$script:MSOLConnected = $true
		} else {
			Write-Host 'Getting credentials for connecting to Microsoft Online Services tenant.'
			$script:MsolCredential = $null
			$script:MsolCredential = Get-Credential -ErrorAction 'SilentlyContinue' -Message 'Microsoft Online Services Administrator'
			Test-QSRequirement -Requirement ($script:MsolCredential -ne $null) -Message 'Credential entry cancelled.'
			Connect-MsolService -Credential $script:MsolCredential
		}
	}
}

# Gets the list of all unverified domains.
function Get-QSUnverifiedDomains {
	Require-QSActiveMsolConnection
	Write-Host 'Getting unverified domain list...'
	return (Get-MsolDomain | Where-Object { $_.Status -ne 'Verified' })
}

# Gets the list of all verified domains that are custom domains.
function Get-QSCustomDomains {
	Require-QSActiveMsolConnection
	Write-Host 'Getting custom domain list...'
	return (Get-MsolDomain | Where-Object { -not ( $_.Name -like '*.onmicrosoft.com' ) } )
}

# Asks the user for a password with confirmation
function Read-QSHostConfirmedPassword {
	while (1) {
		$Password = Read-Host '        Password' -AsSecureString
		$Confirm  = Read-Host 'Confirm password' -AsSecureString
		if ((ConvertFrom-QSSecureStringToPlaintext $Password) -eq (ConvertFrom-QSSecureStringToPlaintext $Confirm)) {
			return $Password
		}
		Write-QSWarning 'Passwords did not match, try again.'
	}
}

# Converts a secure string to a plaintext string
function ConvertFrom-QSSecureStringToPlaintext {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The secure string to convert back to plaintext.')]
		[System.Security.SecureString] $SecureString
	)
	
	return [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString))
}

# gets a yes-no answer from the user
function Read-QSHostYesNo {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The title for the yes/no question.')]
		[string] $Title,
		[Parameter(Mandatory=$true, HelpMessage='The prompt for the yes/no question.')]
		[string] $Prompt,
		[Parameter(Mandatory=$true, HelpMessage='The description of what "yes" means.')]
		[string] $YesDescription,
		[Parameter(Mandatory=$true, HelpMessage='The description of what "no" means.')]
		[string] $NoDescription,
		[Parameter(Mandatory=$false, HelpMessage='Indicates the default choice should be "yes".')]
		[switch] $YesDefault
	)
	$Yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", $YesDescription
	$No = New-Object System.Management.Automation.Host.ChoiceDescription "&No", $NoDescription
	$Options = [System.Management.Automation.Host.ChoiceDescription[]]($Yes, $No)
	if ($YesDefault) {
		$DefaultValue = 0
	} else {
		$DefaultValue = 1
	}
	$Result = $Host.UI.PromptForChoice($Title, $Prompt, $Options, $DefaultValue)
	return ($Result -eq 0)
}

# Reads generic credentials with confirmed password
function Read-QSHostCredentials {
	param (
		[Parameter(Mandatory=$false, HelpMessage='Indicates a domain name should be requested for the account.')]
		[switch] $NeedDomainName,
		[Parameter(Mandatory=$true, HelpMessage='Indicates the user-visible purpose for the account.')]
		[string] $Purpose
	)
	$DomainName = $null
	if ($NeedDomainName) {
		$DomainName = Read-Host "Domain name for $Purpose"
		if (($DomainName -eq $null) -or ($DomainName -eq '')) {
			Write-QSWarning 'Cancelled.'
			return $null
		}
	}
	$AccountName = Read-Host "SAM account name for $Purpose"
	if (($AccountName -eq $null) -or ($AccountName -eq '')) {
		Write-QSWarning 'Cancelled.'
		return $null
	}
	$AccountPassword = Read-QSHostConfirmedPassword
	if ((ConvertFrom-QSSecureStringToPlaintext $AccountPassword) -eq '') {
		Write-QSWarning 'Cancelled.'
		return $null
	}
	return New-Object Object | `
		Add-Member -PassThru -MemberType 'NoteProperty' -Name 'Domain'   -Value $DomainName | `
		Add-Member -PassThru -MemberType 'NoteProperty' -Name 'Account'  -Value $AccountName | `
		Add-Member -PassThru -MemberType 'NoteProperty' -Name 'Password' -Value $AccountPassword
}

# Gets ADFS service account credentials from the user
function Read-QSHostADFSServiceCredentials {
	if ($script:ADFSCredentials -ne $null) {
		if (Read-QSHostYesNo -Title 'Existing Credentials' `
			-Prompt "You have previously supplied credentials for ADFS service use, use the same ones?" `
			-YesDefault `
			-NoDescription 'No, supply new credentials' `
			-YesDescription 'Yes, use previously supplied credentials') {
			return $true
		}
	}
	$Credentials = Read-QSHostCredentials -NeedDomainName -Purpose 'ADFS service account'
	if ($Credentials -eq $null) {
		return $false
	}
	$script:ADFSDomainName = $Credentials.Domain
	$script:ADFSAccountName = $Credentials.Account
	$script:ADFSAccountPassword = $Credentials.Password
	$script:ADFSCredentials =  New-Object System.Management.Automation.PSCredential("$script:ADFSDomainName\$script:ADFSAccountName", $script:ADFSAccountPassword)
	$true
}

# Gets a domain name from the verified list
function Read-QSHostDomainChoice {
	Require-QSActiveMsolConnection
	$Domains = Get-QSCustomDomains | Foreach-Object { $_.Name }
	if ($Domains.Count -eq 0) {
		Write-Error 'No verified custom domains exist in the tenant.'
		return $null
	}
	Read-QSListChoice -Choices $Domains -Prompt 'Domain to use' -Title 'Select a verified domain'
}

# Gets a web site from the local list
function Read-QSWebSite {
	Require-QSModule WebAdministration
	$Sites = @(Get-Website | Foreach-Object { $_.Name })
	if ($Sites.Count -eq 0) {
		Write-Error 'No web sites exist on the current machine.'
		return $null
	}
	return Read-QSListChoice -Choices $Sites -Prompt 'IIS site to host the ADFS Proxy' 'Select a web site'
}

# Determines the ADFS subject name
function Require-QSADFSSubjectName {
	if ($script:ADFSSubjectName -eq $null) {
		$Domain = Read-QSHostDomainChoice
		if ($Domain -eq $null) {
			return $false
		}
		$script:ADFSSubjectDomainName = $Domain
		$script:ADFSSubjectName = "adfs.$Domain"
	}
	$true
}

# removes a COM object reference
function Release-QSCOMObject {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The object to release.')]
		[object] $Object
	) 
	[void] [System.Runtime.Interopservices.Marshal]::ReleaseComObject($Object)
}

# gets the local ADFS certificate and validates it
function Get-QSADFSCertificate {
	param (
		[Parameter(Mandatory=$false, HelpMessage='Indicates no error should be reported if there is no certificate.')]
		[switch] $Silent,
		[Parameter(Mandatory=$false, HelpMessage='Indicates verification is unnecessary.')]
		[switch] $SkipVerification
	) 
	$PossibleCertificates = @(Get-ChildItem 'Cert:\LocalMachine\My' | Where-Object { $_.FriendlyName -eq $script:CertificateFriendlyName} )
	if ($PossibleCertificates.GetLength(0) -eq 0) {
		if (-not $Silent) {
			Write-QSError "Expected certficate with friendly name `"$script:CertificateFriendlyName`" not found."
		}
		return $null
	}
	if ($PossibleCertificates.GetLength(0) -gt 1) {
		Write-QSWarning "More than one certficate with friendly name `"$script:CertificateFriendlyName`" exists.`nSelecting the first one."
	}
	$PossibleCertificate = $PossibleCertificates[0]
	if (-not $SkipVerification) {
		if (-not (Require-QSADFSSubjectName)) {
			return $null
		}
		if (-not ($PossibleCertificate.Subject.Contains("CN=$script:ADFSSubjectName"))) {
			Write-QSError "The certificate does not have the expected subject of `"CN=$script:ADFSSubjectName`". It cannot be used."
			return $null
		}
		if ($PossibleCertificate.NotBefore -gt (Get-Date)) {
			Write-QSError 'The certificate is not yet valid. It cannot be used.'
			return $null
		}
		if ($PossibleCertificate.NotAfter -lt (Get-Date)) {
			Write-QSError 'The certificate has expired. It cannot be used.'
			return $null
		}
		if (-not ($PossibleCertificate.HasPrivateKey)) {
			Write-QSError "The certificate's private key is not present on this machine. The certificate cannot be used."
			return $null
		}
		if (-not ($PossibleCertificate.Verify())) {
			Write-QSError 'The certificate fails verification; this likely means a missing trusted root or intermediate CA. The certificate cannot be used. '
			return $null
		}
	}
	return $PossibleCertificate
}

# get the verification value for a specific domain
function Get-QSMsolDNSVerificationText {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The domain name to query.')]
		[object] $Domain
	) 
	return (Get-MsolDomainVerificationDns -DomainName $Domain ).Label.Split('.')[0]
}

# get a DNS server address
function Read-QSHostDNSServerAddress {
	$DNSServerList = @()
	$Adapters = ([System.Net.NetworkInformation.NetworkInterface])::GetAllNetworkInterfaces()
	foreach ($Adapter in $Adapters) {
		$AdapterDNSServers = $Adapter.GetIPProperties().DnsAddresses
		foreach ($AdapterDNSServer in $AdapterDNSServers) {
			$DNSIP = $AdapterDNSServer.IPAddressToString
			if ($DNSIP -match '^.*\..*\..*\..*$') {
				if (-not ($DNSServerList -contains $DNSIP)) {
					$DNSServerList += $DNSIP
				}
			}
		}
	}
	if ($DNSServerList.Count -eq 0) {
		Write-Warning 'This machine does not appear to be a DNS client.'
		return $null;
	}
	return Read-QSListChoice -Choices $DNSServerList -Title 'Select a DNS server for the creation request' -Prompt 'DNS server'
}

# Require the given key name
function Require-QSRegistryKey {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The key that is required.')]
		[string] $KeyName
	)
	if (-not (Test-Path $KeyName)) {
		$Created = New-Item -Path $KeyName -Type Directory -Force
		if ($?) {
			return $true
		} else {
			return $false
		}
	}
	return $false
}

# Require the given key name
function Require-QSRegistryValue {
	param (
		[Parameter(Mandatory=$true, HelpMessage='The value name that is required.')]
		[string] $Name,
		[Parameter(Mandatory=$true, HelpMessage='The parent key.')]
		[string] $Key,
		[Parameter(Mandatory=$true, HelpMessage='The required value.')]
		[string] $Value,
		[Parameter(Mandatory=$false, HelpMessage='The type of the value.')]
		[string] $PropertyType = 'String'
	)
	$Set = Require-QSRegistryKey -KeyName $Key
	if ((Get-ItemProperty -Path $Key -Name $Name -ErrorAction 'SilentlyContinue') -eq $null) {
		$Created = New-ItemProperty -Path $Key -PropertyType $PropertyType -Name $Name -Value $Value
		return $true
	} else {
		if ((Get-ItemProperty $Key -Name $Name).$Name -eq $Value) {
			return $false
		}
		$Reset = Set-ItemProperty -Path $Key -PropertyType $PropertyType -Name $Name -Value $Value
		return $true
	}
}

function Disable-QSInternetExplorerESC {
	$DidIt = $false
	if (Require-QSRegistryValue -Key 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}' -Name 'IsInstalled' -Value 0) {
		$DidIt = $true
	    Write-Host 'IE Enhanced Security Configuration (ESC) has been disabled for Administrators.' -ForegroundColor Green
	}
	if (Require-QSRegistryValue -Key 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}' -Name 'IsInstalled' -Value 0) {
		$DidIt = $true
	    Write-Host 'IE Enhanced Security Configuration (ESC) has been disabled for Users.' -ForegroundColor Green
	}
	if ($DidIt) {
    	Stop-Process -Name Explorer
		Start-Process -FilePath Explorer
		Write-Host 'Restarted Windows Explorer to complete IE ESC configuration.'
	}
}

function Configure-QSIISAuthentication {
	Require-QSADFSSubjectName 
	if ($script:ADFSSite -eq $null) {
		$script:ADFSSite = Read-QSWebSite
		if ($script:ADFSSite -eq $null) {
			return $false
		}
	}

	Write-Host 'Configuring Windows Authentication provider order in IIS...'
	Invoke-QSCommand -Program "$env:SystemRoot\system32\inetsrv\appcmd.exe" -ArgumentString "set config '$script:ADFSSite/adfs/ls' -section:system.webServer/security/authentication/windowsAuthentication /enabled:true /commit:apphost"
	Invoke-QSCommand -Program "$env:SystemRoot\system32\inetsrv\appcmd.exe" -ArgumentString "set config '$script:ADFSSite/adfs/ls' -section:system.webServer/security/authentication/windowsAuthentication /~providers /commit:apphost"
	Invoke-QSCommand -Program "$env:SystemRoot\system32\inetsrv\appcmd.exe" -ArgumentString "set config '$script:ADFSSite/adfs/ls' -section:system.webServer/security/authentication/windowsAuthentication /+`"providers.[value='NTLM']`" /commit:apphost"
	Invoke-QSCommand -Program "$env:SystemRoot\system32\inetsrv\appcmd.exe" -ArgumentString "set config '$script:ADFSSite/adfs/ls' -section:system.webServer/security/authentication/windowsAuthentication /+`"providers.[value='Negotiate']`" /commit:apphost"

	Write-Host 'Checking/configuring local registry to support loopback testing...'
	$Set = Require-QSRegistryValue -Key 'HKLM:\System\CurrentControlSet\Control\Lsa' -Name 'DisableLoopbackCheck' -PropertyType 'DWord' -Value 1
	if (-not $Set) {
		Write-Host 'Registry modifications unnecessary.'
	} else {
		$Values += $script:ADFSSubjectName
		Set-ItemProperty 'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0' 'BackConnectionHostName' $Values
		Write-QSWarning 'Changes made to system requirements require a reboot.'
		Write-Host 'Script exiting.'
		Exit
	}
}

function Configure-QSIISSSL {
	Write-Host 'Configuring SSL...'
	Require-QSModule WebAdministration
	if ($script:ADFSSite -eq $null) {
		$script:ADFSSite = Read-QSWebSite
	}
	if ($script:ADFSSite -eq $null) {
		return $false
	}
	$Certificate = Get-QSADFSCertificate
	if ($Certificate -eq $null) {
		return $false
	}
	$BindingOnSite = $false
	$SslBindings = @(Get-ChildItem 'IIS:\SslBindings')
	if ($SslBindings.Count -ne 0) {
		$ExistingBinding = $null
		foreach ($SslBinding in $SslBindings) {
			foreach ($Site in $SslBinding.Sites) {
				if ($Site.Value.Contains($script:ADFSSite)) {
					Write-QSWarning 'SSL binding found on existing web site will be removed.'
					$ExistingBinding = $SslBinding
				}
			}
		}
		if ($ExistingBinding -ne $null) {
			Write-Host 'Removing existing binding from the ADFS site...'
			Remove-Item -Path $SslBinding.PSPath
		}	
	}
	$Sites = Get-ChildItem 'IIS:\Sites'
	foreach ($Site in $Sites) {
	    $Bindings = $Site.Bindings.Collection
		foreach ($Binding in $Bindings) {
			$BindingInformation = $Binding.bindingInformation.Split(':')
			#$BindingIP = $BindingInformation[0]
			$BindingPort = $BindingInformation[1]
			#$BindingHostname = $BindingInformation[2]
			if ($BindingPort -eq 443) {
				$BindingOnSite = $true
			}
		}
	}
	if (-not $BindingOnSite) {
		New-WebBinding -Name $script:ADFSSite -IP '*' -Port 443 -Protocol 'https'
	}
	$Certificate | New-Item 'IIS:\SslBindings\0.0.0.0!443'
	$true
}

#endregion

#region ----- menu choices -----

function Install-QSSignInAssistantExplicit {
	Write-QSTitle 'Install Microsoft Online Services Sign-In Assistant'
	$results = Install-QSSignInAssistant
}

function Install-QSMsolServicesModuleExplicit {
	Write-QSTitle 'Install Microsoft Online Services Module for Windows PowerShell'
	$results = Install-QSMsolServicesModule
}

# Download and run the Office 365 Deployment Readiness Tool
function Launch-QSOffice365DeploymentReadinessTool {
	Write-QSTitle 'Download and run the Office 365 Deployment Readiness Tool'
	$EXEFilename = $script:CurrentExecutingPath + '\office365deploymentreadinesstool.exe'
	$ZipFilename = $script:CurrentExecutingPath + '\office365deploymentreadinesstool.zip'
	if (-not (Test-Path $EXEFilename)) {
		if (-not (Require-QSDownloadableFile -FileName $ZipFilename -URL 'https://bposast.vo.msecnd.net/O365ReadinessTool.80/office365deploymentreadinesstool.zip')) {
			Write-QSError 'Tool download failed.'
			return
		}
		$ShellApplication = New-Object -ComObject 'Shell.Application'
		$ZipFile = $ShellApplication.Namespace($ZipFilename)
		$Destination = $ShellApplication.Namespace($script:CurrentExecutingPath)
		# 0x10 = overwrite, 0x4 = hide copy dialog
		$Destination.CopyHere($ZipFile.Items(), 0x14)
		Release-QSCOMObject $Destination
		Release-QSCOMObject $ZipFile
		Release-QSCOMObject $ShellApplication
	}
	Start-Process -FilePath $EXEFilename
}

function Add-QSMsolDomain {
	Write-QSTitle 'Add local UPN suffix as domain in Windows Azure Active Directory'
	Require-QSActiveMsolConnection
	Write-Host 'Checking for unused UPN suffixes...'
	$UpnSuffixes = Get-QSDomainSuffixes
	$ActiveDomains = Get-MsolDomain | Foreach-Object { $_.Name }
	$UnusedList = @()
	foreach ($UpnSuffix in $UpnSuffixes) {
		if (-not ($ActiveDomains -contains $UpnSuffix)) {
			$UnusedList += $UpnSuffix;
		} else {
			Write-Host "Found already added domain: $UpnSuffix"
		}
	}
	if ($UnusedList.Count -eq 0) {
		Write-Host ' '
		Write-Host 'All possible domains have already been added to the service.'
		return
	}
	$SelectedSuffix = Read-QSListChoice -Choices $UnusedList -Prompt 'UPN suffix to add to Windows Azure Active Directory' -Title 'UPN Selection'
	if ($SelectedSuffix -eq $null) {
		return
	}
	New-MsolDomain -Name $SelectedSuffix -Authentication Federated
	$Domain = Get-MsolDomain -DomainName $SelectedSuffix
	if ($Domain.Status -eq 'Verified') {
		Write-Host ' '
		Write-Host 'Domain is verified. If it is a subdomain of an existing domain, this is automatic.'
		Write-Host ' '
	} else {
		Write-Host ' '
		Write-Host -NoNewline 'Domain verification code: '
		Get-QSMsolDNSVerificationText -Domain $SelectedSuffix
		Write-Host ' '	
	}
}	

# Looks up DNS verification record information
function Get-QSMsolDomainVerificationDnsAll {
	Write-QSTitle 'Retrieve verification information for domains in Windows Azure Active Directory'
	Require-QSActiveMsolConnection
	$UnverifiedDomains = Get-QSUnverifiedDomains
	if ($UnverifiedDomains.Count -eq 0) {
		Write-Host 'There are no unverified domains in the current tenant.'
		return
	}
	$Results = @();
	foreach ($UnverifiedDomain in $UnverifiedDomains) {
		$Result = `
			New-Object Object | `
			Add-Member -PassThru -MemberType 'NoteProperty' -Name 'Domain Name'        -Value $UnverifiedDomain.Name | `
			Add-Member -PassThru -MemberType 'NoteProperty' -Name 'Verification Value' -Value ( Get-QSMsolDNSVerificationText -Domain $UnverifiedDomain.Name )
		$Results += $Result
	}
	return $Results
}

# Enables DirSync support
function Set-QSMsolDirSyncEnabled {
	Write-QSTitle 'Enable directory synchronization (DirSync) on the tenant'
	Require-QSActiveMsolConnection
	if ((Get-MSOLCompanyInformation).DirectorySynchronizationEnabled) {
		Write-Host 'Directory synchronization support is already enabled for the current tenant.'
		return
	}
	Write-Host 'Requesting directory sync to be enabled. This may take up to 24 hours to complete.'
	Set-MsolDirSyncEnabled -EnableDirSync $true
}

# Add ADFS role to this server
function Install-QSADFSRole {
	Write-QSTitle 'Add the ADFS role to this server'
	Require-QSWindowsFeature ADFS-Federation
}

# Create a service account in the local domain for ADFS use
function New-QSADFSServiceAccount {
	Write-QSTitle 'Create a service account in the local domain for ADFS use'
	if (-not (Read-QSHostADFSServiceCredentials)) {
		return
	}
	if (($script:ADFSDomainName.ToLower() -ne $env:USERDOMAIN.ToLower()) -and `
		($script:ADFSDomainName.ToLower() -ne $env:USERDNSDOMAIN.ToLower())) {
		Write-QSError 'The domain for the service account must match the domain of the ADFS server.'
		return
	}
	Require-QSWindowsFeature RSAT-AD-Powershell
	Require-QSModule ActiveDirectory
	$ExistingUser = $null
	try {
		$ExistingUser = Get-ADUser $script:ADFSAccountName
	}
	catch {
	}
	if ($?) {
		Write-QSWarning 'User already exists, skipping creation.'
		return
	}
	Write-Host "Creating user `"$script:ADFSAccountName`"..."
	New-ADUser -Name $script:ADFSAccountName `
		-SamAccountName $script:ADFSAccountName `
		-DisplayName 'ADFS Service Account' `
		-AccountPassword $script:ADFSAccountPassword `
		-ChangePasswordAtLogon $false `
		-PasswordNeverExpires $true `
		-Enabled $true
	if ($?) {
		Write-Host -ForegroundColor 'Green' -BackgroundColor 'Black' 'Creation successful.'
		return
	} else {
		Write-QSError 'Creation failed, please review earlier messages and try again.'
		$script:ADFSAccountName = $null
	}
}

# Create an internal DNS entry for ADFS
function Add-QSADFSDNSEntry {
	Write-QSTitle 'Create an internal DNS entry for ADFS'
	$Domain = Read-QSHostDomainChoice
	if ($Domain -eq $null) {
		return
	}
	$LocalHostname = $env:COMPUTERNAME.ToLower()
	$LocalDNSDomainName = $env:USERDNSDOMAIN.ToLower()
	if (($LocalHostname -eq 'adfs') -and ($Domain -eq $LocalDNSDomainName)) {
		Write-QSError 'You cannot use a server with the name "ADFS" for hosting ADFS.'
		return
	}
	$ServerAddress = Read-QSHostDNSServerAddress
	if ($ServerAddress -eq $null) {
		return
	}
	$IPAddresses = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE").IPAddress | Select-String -Pattern '^.*\..*\..*\..*$'
	$IPAddress = Read-QSListChoice -Choices $IPAddresses -Prompt 'Main ADFS service IP address' -Title 'Local IP Addresses'
	if ($IPAddress -eq $null) {
		return
	}
	Require-QSWindowsFeature RSAT-DNS-Server
	Require-QSModule DnsServer
	Write-Host 'Attempting to add DNS record...'
	Add-DnsServerResourceRecordA -ComputerName $ServerAddress -ZoneName $Domain -Name 'adfs' -IPv4Address $IPAddress
	if ($?) {
		Write-Host 'Complete.'
	} else {
		Write-QSError 'Record addition failed.'
	}
}

# Process SSL certificate for ADFS
function Process-QSCertificate {
	Write-QSTitle 'Process SSL certificate for ADFS'
	Write-Host 'Checking for existing certificate...'
	$Certificate = Get-QSADFSCertificate -SkipVerification -Silent
	if ($Certificate -ne $null) {
		Write-QSWarning ('Local certificate with friendly name "' + $script:CertificateFriendlyName + '" already exists.')
		$ValidateChoice = Read-QSHostYesNo -Title 'Validate Existing?' `
			-Prompt 'The certificate already exists. Validate the existing certificate?' `
			-YesDefault `
			-YesDescription 'Validate the certificate' `
			-NoDescription 'Skip validation'
		if ($ValidateChoice) {
			$Certificate = Get-QSADFSCertificate
			if ($Certificate -eq $null) {
				Write-QSError 'Validation failed.'
			} else {
				Write-Host -ForegroundColor 'Green' -BackgroundColor 'Black' 'Validation successful.'
			}
		} else {
			Write-QSWarning 'Validation skipped.'
		}
		return
	}
	if (-not (Require-QSADFSSubjectName)) {
		return
	}
	if (-not (Read-QSHostYesNo -Title 'Confirm Self-Signed' `
		-Prompt 'Create self-signed certificate?' `
		-YesDefault `
		-YesDescription 'Create self-signed certificate' `
		-NoDescription 'Do not create certificate')) {
		Write-QSWarning 'Creation skipped.'
		return
	}
	Write-Host 'Creating private key...'
	# subject name
	$Name = New-Object -ComObject 'X509Enrollment.CX500DistinguishedName.1' 
	$Name.Encode("CN=$script:ADFSSubjectName", 0)
	# new key pair
	$Key = New-Object -ComObject 'X509Enrollment.CX509PrivateKey.1' 
	$Key.ProviderName = 'Microsoft RSA SChannel Cryptographic Provider' 
	$Key.KeySpec = 1
	$Key.Length = 2048
	$Key.SecurityDescriptor = 'D:PAI(A;;0xd01f01ff;;;SY)(A;;0xd01f01ff;;;BA)(A;;0x80120089;;;NS)' 
	$Key.MachineContext = 1
	$Key.ExportPolicy = 1
	$Key.FriendlyName = $script:CertificateFriendlyName
	$Key.Create()
	Write-Host 'Creating certificate request details...'
	$EnhancedKeyUsageOIDs = New-Object -ComObject 'X509Enrollment.CObjectIds.1' 
	$ServerAuthenticationOID = New-Object -ComObject 'X509Enrollment.CObjectId.1' 
	$ServerAuthenticationOID.InitializeFromValue('1.3.6.1.5.5.7.3.1')
	$EnhancedKeyUsageOIDs.add($ServerAuthenticationOID)
	$EnhancedKeyUsageExtension = New-Object -ComObject 'X509Enrollment.CX509ExtensionEnhancedKeyUsage.1' 
	$EnhancedKeyUsageExtension.InitializeEncode($EnhancedKeyUsageOIDs)
	Write-Host 'Creating certificate request...'
	$Certificate = New-Object -ComObject 'X509Enrollment.CX509CertificateRequestCertificate.1' 
	# 2 in first parameter = ContextMachine
	# '' in third parameter = no template specified
	$Certificate.InitializeFromPrivateKey(2, $Key, '')
	$Certificate.Subject = $Name 
	$Certificate.Issuer = $Certificate.Subject
	$Certificate.NotBefore = Get-Date
	$Certificate.NotAfter = $Certificate.NotBefore.AddDays(365)
	$Certificate.X509Extensions.Add($EnhancedKeyUsageExtension)
	if ($script:ADFSSubjectDomainName.ToLower -ne $env:USERDNSDOMAIN) {
		$AltNamesCollection = New-Object -ComObject 'X509Enrollment.CAlternativeNames'
	    $ExtNames = New-Object -ComObject 'X509Enrollment.CX509ExtensionAlternativeNames'
   		$AltDnsName = New-Object -ComObject 'X509Enrollment.CAlternativeName'
	    $AltDnsName.InitializeFromString($script:AltNameType.DNS_NAME, ($env:COMPUTERNAME + '.' + $env:USERDNSDOMAIN))
	    $AltNamesCollection.Add($AltDnsName)
   		$MainDnsName = New-Object -ComObject 'X509Enrollment.CAlternativeName'
	    $MainDnsName.InitializeFromString($script:AltNameType.DNS_NAME, $script:ADFSSubjectName)
	    $AltNamesCollection.Add($MainDnsName)
	    $ExtNames.InitializeEncode($AltNamesCollection)
 		$Certificate.X509Extensions.Add($ExtNames)
	}
	$Certificate.Encode()
	Write-Host 'Submitting request...'
	$Enrollment = New-Object -ComObject 'X509Enrollment.CX509Enrollment.1' 
	$Enrollment.InitializeFromRequest($Certificate)
	$Enrollment.CertificateFriendlyName = $Key.FriendlyName
	$CertificateData = $Enrollment.CreateRequest(0)
	Write-Host 'Installing response...'
	# 2 in first parameter = AllowUntrustedCertificate
	# 0 in third parameter = XCN_CRYPT_STRING_BASE64HEADER
	# '' in fourth parameter = no certificate password
	$Enrollment.InstallResponse(2, $CertificateData, 0, '')
	# cleanup COM objects
	if ($AltNamesCollection -ne $null) {
   		Release-QSCOMObject $MainDnsName; $MainDnsName = $null
   		Release-QSCOMObject $AltDnsName; $AltDnsName = $null
	    Release-QSCOMObject $ExtNames; $ExtNames = $null
		Release-QSCOMObject $AltNamesCollection; $AltNamesCollection = $null
	}
	Release-QSCOMObject $Enrollment; $Enrollment = $null
	Release-QSCOMObject $Certificate; $Certificate = $null
	Release-QSCOMObject $EnhancedKeyUsageExtension; $EnhancedKeyUsageExtension = $null
	Release-QSCOMObject $ServerAuthenticationOID; $ServerAuthenticationOID = $null
	Release-QSCOMObject $EnhancedKeyUsageOIDs; $EnhancedKeyUsageOIDs = $null
	Release-QSCOMObject $Key; $Key = $null
	Release-QSCOMObject $Name; $Name = $null
	# Trust the certificate
	$Certificate = Get-QSADFSCertificate -SkipVerification
	Write-Host 'Importing as trusted root...'
	$Store = Get-Item 'cert:\LocalMachine\Root'
	$Store.Open('ReadWrite')
	$Store.Add($Certificate)
	$Store.Close()
	Write-Host 'Importing as enterprise trust...'
	$Store = Get-Item 'cert:\LocalMachine\Trust'
	$Store.Open('ReadWrite')
	$Store.Add($Certificate)
	$Store.Close()
	Write-Host 'Importing as trusted third-party root...'
	$Store = Get-Item 'cert:\LocalMachine\AuthRoot'
	$Store.Open('ReadWrite')
	$Store.Add($Certificate)
	$Store.Close()
	Write-Host 'Complete.'
}

# Export SSL certificate with private key
function Export-QSCertificate {
	Write-QSTitle 'Export SSL certificate with private key'
	Write-Host 'Exporting...'
	$FinalCertificate = Get-QSADFSCertificate
	if ($FinalCertificate -eq $null) {
		Write-Error 'Cannot find the self-signed certificate; export failed.'
		return
	}
	$CERFilename = $Script:CertificateFileName.Replace('.pfx', '.cer')
	[System.IO.File]::WriteAllBytes($CERFilename, $FinalCertificate.Export('CER'))
	[System.IO.File]::WriteAllBytes($script:CertificateFileName, $FinalCertificate.Export('PFX', 'secret'))
	Write-Host 'Complete.'
}

# Configure ADFS with basic configuration
function Configure-QSADFS {
	Write-QSTitle 'Configure ADFS with basic configuration'
	Require-QSWindowsFeature ADFS-Federation
	if (-not (Require-QSADFSSubjectName)) {
		return
	}
	if (-not (Read-QSHostADFSServiceCredentials)) {
		return
	}
	$Certificate = Get-QSADFSCertificate
	if ($Certificate -eq $null) {
		Write-QSError 'No certificate found to use for the installation.'
		return
	}
	if (-not (Configure-QSIISSSL)) {
		return
	}
	#Write-Host 'Stopping Windows Internal Database (if started)...'
	#Stop-Service -Name 'Windows Internal Database'
	#Write-Host 'Deleting old ADFS databases (if present)...'
	#Remove-Item "$env:SystemRoot\WID\Data\Adfs*.*" -ErrorAction 'SilentlyContinue'
	Write-Host "Configuring ADFS to run as $script:ADFSDomainName\$script:ADFSAccountName`n" `
		'           with certificate thumbprint ' $Certificate.Thumbprint '...'
	Install-AdfsFarm -CertificateThumbprint $Certificate.Thumbprint `
		-FederationServiceName $script:ADFSSubjectName `
		-ServiceAccountCredential $script:ADFSCredentials `
		-OverwriteConfiguration
	
	if ($?) {
		Configure-QSIISAuthentication
	}
}

# Confirm/configure Windows Firewall for port 443
function Configure-QSWindowsFirewall {
	Write-QSTitle 'Confirm/configure Windows Firewall for port 443'
	Require-QSModule NetSecurity
	$Rules = Get-NetFirewallPortFilter | Where-Object { ($_.LocalPort -eq 443) -and ($_.Protocol -eq 'TCP') } `
		| Get-NetFirewallRule `
		| Where-Object { ($_.Direction -eq 'Inbound') -and $_.Enabled -and ($_.Profile -eq 'Any') } `
		| Get-NetFirewallAddressFilter | Where-Object { $_.RemoteAddress -eq 'Any' } `
		| Get-NetFirewallRule `
		| Get-NetFirewallApplicationFilter | Where-Object { @('any', 'system').Contains($_.Program.ToLower()) } `
		| Get-NetFirewallRule `
		| Get-NetFirewallInterfaceFilter | Where-Object { $_.InterfaceAlias -eq 'Any' } `
		| Get-NetFirewallRule `
		| Get-NetFirewallInterfaceTypeFilter | Where-Object { $_.InterfaceType -eq 'Any' } `
		| Get-NetFirewallRule	
	if (-not $?) {
		Write-QSWarning 'Unable to get firewall rules - Windows Firewall disabled? You must configure any local firewall manually.'
		return
	}
	if ($Rules.Count -eq 0) {
		Write-Host 'Adding new SSL incoming rule (TCP port 443).'
		New-NetFirewallRule -DisplayName 'ADFS SSL Incoming [TCP 443]' -Direction Inbound -Action Allow -EdgeTraversalPolicy Allow -Protocol TCP -LocalPort 443
	} else {
		Write-Host 'Windows Firewall appears open for TCP port 443, no changes made.'
	}
}

# Launch test web pages
function Launch-QSIETestPages {
	Write-QSTitle 'Launch test web pages'
	if (-not (Require-QSADFSSubjectName)) {
		return
	}
	Write-Host 'Page launch will take about 10 seconds...'
	$JunkResults = [Diagnostics.Process]::Start("$env:SystemRoot\system32\ipconfig.exe", '/flushdns')
	Start-Sleep -Seconds 3
	$JunkResults = [Diagnostics.Process]::Start("https://$script:ADFSSubjectName/adfs/services/trust/mex")
	Start-Sleep -Seconds 3
	$JunkResults = [Diagnostics.Process]::Start("https://$script:ADFSSubjectName/FederationMetadata/2007-06/FederationMetadata.xml")
	Start-Sleep -Seconds 3
	$JunkResults = [Diagnostics.Process]::Start("https://$script:ADFSSubjectName/adfs/ls/IdpInitiatedSignon.aspx")
}

# Import certificates for ADFS Proxy
function Import-QSCertificates {
	Write-QSTitle 'Import certificates for ADFS Proxy'
	if (-not (Require-QSLocalFile $script:CertificateFileName)) {
		return
	}
	Require-QSModule PKI
	$CertificatePassword = ConvertTo-SecureString -String 'secret' -Force -AsPlainText
	Write-Host 'Importing as enterprise trust...'
	$Results = Import-PfxCertificate -FilePath $script:CertificateFileName -CertStoreLocation 'cert:\LocalMachine\Trust' -Exportable -Password $CertificatePassword
	Write-Host 'Importing as trusted root...'
	$Results = Import-PfxCertificate -FilePath $script:CertificateFileName -CertStoreLocation 'cert:\LocalMachine\Root' -Exportable -Password $CertificatePassword
	Write-Host 'Importing to certificate store...'
	$Results = Import-PfxCertificate -FilePath $script:CertificateFileName -CertStoreLocation 'cert:\LocalMachine\My' -Exportable -Password $CertificatePassword
	Write-Host 'Complete.'
}

# Add the ADFS Proxy role to this server
function Install-QSADFSProxyRole {
	Write-QSTitle 'Add the ADFS Proxy role to this server'
	Require-QSWindowsFeature ADFS-Proxy
}

# Configure IIS SSL and authentication
function Configure-QSIISSSLExplicit {
	Write-QSTitle 'Configure IIS SSL and authentication'
	if (-not (Configure-QSIISSSL)) {
		return
	}
	Configure-QSIISAuthentication
}

# Add a HOSTS file entry for ADFS access from the proxy
function Add-HostsEntryForADFS {
	Write-QSTitle 'Add a HOSTS file entry for ADFS access from the proxy'
	$Domain = Read-QSHostDomainChoice
	if ($Domain -eq $null) {
		return
	}
	$IPAddress = Read-Host 'Enter the IP address of the internal ADFS server'
	if ($IPAddress -eq '') {
		Write-QSWarning 'Cancelled.'
		return
	}
	$NeedToAdd = $true
	$HostsPath = "$env:SystemRoot\System32\drivers\etc\HOSTS"
	Copy-Item $HostsPath "$HostsPath.backup"
	$Hosts = get-content $hostsPath
	$Hosts = $Hosts | Foreach {
		if ($_ -match "(.*?\d{1,3}.*?adfs\.$Domain*)") {
			Write-QSWarning 'Will remove existing entry'
		} else {
			$_
		}
	}
	$Hosts = $Hosts + "`n$IPAddress adfs.$Domain"
	$Hosts | Out-File $HostsPath -Encoding ASCII
}

# Configure ADFS Proxy with basic configuration
function Configure-QSADFSProxyRole {
	Write-QSTitle 'Configure ADFS Proxy with basic configuration'
	Require-QSWindowsFeature ADFS-Proxy
	if (-not (Read-QSHostADFSServiceCredentials)) {
		return
	}
	Write-Host 'Checking for local certificate...'
	$Certificate = Get-QSADFSCertificate
	if ($Certificate -eq $null) {
		return
	}
	Write-Host 'Checking for ADFS subject name...'
	if (-not (Require-QSADFSSubjectName)) {
		return
	}
	Write-Host 'Configuring ADFS Proxy...'	
	Add-AdfsProxy -FederationServiceName $script:ADFSSubjectName `
		-FederationServiceTrustCredential $script:ADFSCredentials
	# Pre-Windows Server 2012 command line to configure ADFS
    # Start-Process -FilePath ("$env:SystemRoot\ADFS\FSPConfigWizard.exe") -Wait -ArgumentList @( `
	#	'/Hostname', $script:ADFSSubjectName, `
	#	'/Username', $script:ADFSAccountName, `
	#	'/Password', (ConvertFrom-QSSecureStringToPlaintext -SecureString $script:ADFSAccountPassword) `
	#)
	Configure-QSIISAuthentication
}

# Looks up TXT DNS records for unverified domains
function Test-QSExternalDNSRecords {
	Write-QSTitle 'Check DNS records for TXT entries for unverified domains'
	Require-QSActiveMsolConnection
	# Level 3: resolver1.level3.net
	$ExternalServer = "209.244.0.3"
	$NewHost = Read-Host "Enter the IP address for the external DNS server to query`nor hit Enter for the default of $ExternalServer"
	if ($NewHost -ne '') {
		$ExternalServer = $NewHost
	}
	$LookupResults = nslookup www.microsoft.com $ExternalServer 2>&1
	if ($LookupResults -match 'Request to .* timed-out') {
		Write-QSError "Cannot access external DNS server $ExternalServer."
		return		
	}
	$UnverifiedDomains = Get-QSUnverifiedDomains
	foreach ($UnverifiedDomain in $UnverifiedDomains) {
		Write-Host -NoNewline ('Checking for TXT for "' + $UnverifiedDomain.Name + '"... ')
		$LookupResults = nslookup -type=TXT $UnverifiedDomain.Name $ExternalServer 2>&1
		$Matched = $LookupResults -match '(MS=ms[0-9]*)+'
		if ($Matched.Count -eq 0) {
			Write-Host -ForegroundColor 'Red' -BackgroundColor 'Black' 'Failure.'
			Write-Host 'No records found. Full results:'
			Write-Host $LookupResults
		} else {
			if ($Matched.Count -ne 1) {
				Write-Host -ForegroundColor 'Red' -BackgroundColor 'Black' 'Failure.'			
				Write-Host 'Expected exactly one record, found' $Matched.Count'.'
			} else {
				Write-Host -ForegroundColor 'Green' -BackgroundColor 'Black' 'Success.'
				Write-Host 'Record found: ' $Matched[0]
				$Matched[0] -match 'ms[0-9]+' | Out-Null
				$Found = $matches[0]
				$Expected = Get-QSMsolDNSVerificationText -Domain $UnverifiedDomain.Name
				Write-Host -NoNewLine 'Validating record... '
				if ($Found -eq $Expected) {
					Write-Host -ForegroundColor 'Green' -BackgroundColor 'Black' 'Success.'
					Write-Host 'Record located matched expected record.'
				} else {
					Write-Host -ForegroundColor 'Red' -BackgroundColor 'Black' 'Failure.'			
					Write-Host "Found $Found but expected $Expected."
				}
			}
		}
	}
}

# Configure Windows Azure AD connection to ADFS
function Convert-QSMsolDomain {
	Write-QSTitle 'Configure Windows Azure AD connection to ADFS'
	Require-QSActiveMsolConnection
	$Domain = Read-QSHostDomainChoice
	if ($Domain -eq $null) {
		return
	}
	Write-Host 'Configuring the Windows Azure AD connection to ADFS...' 
	New-MsolFederatedDomain -DomainName $Domain
	if ($?) {
		Write-Host 'Finished.'
	}
}

# Create sign-in test user
function New-QSTestUser {
	Write-QSTitle 'Create sign-in test user'
	$Credentials = Read-QSHostCredentials -Purpose 'Test user'
	if ($Credentials -eq $null) {
		Write-QSWarning 'Cancelled.'
		return
	}
	$AccountName = $Credentials.Account
	$FirstName = Read-Host 'First (given) name of new user'
	if ($FirstName -eq '') {
		Write-QSWarning 'Cancelled.'
		return
	}
	$LastName = Read-Host 'Last (family) name of new user'
	if ($LastName -eq '') {
		Write-QSWarning 'Cancelled.'
		return
	}
	$UPNDomain = Read-QSHostDomainChoice
	if ($UPNDomain -eq $null) {
		return
	}
	Require-QSWindowsFeature RSAT-AD-Powershell
	Require-QSModule ActiveDirectory
	$LocalUser = $null
	try {
		$LocalUser = Get-ADUser $AccountName -Properties 'DisplayName'
	}
	catch {
	}
	if ($?) {
		Write-QSWarning 'Local user already exists, skipping creation.'
	} else {
		Write-Host "Creating user `"$AccountName`"..."
		New-ADUser -Name $AccountName `
			-SamAccountName $AccountName `
			-DisplayName 'ADFS Test Account' `
			-AccountPassword $Credentials.Password `
			-ChangePasswordAtLogon $false `
			-PasswordNeverExpires $true `
			-Enabled $true `
			-UserPrincipalName "$AccountName@$UPNDomain" `
			-GivenName $FirstName `
			-Surname $LastName
		if (-not $?) {
			Write-QSError 'Windows Azure Active Directory user creation failed, please review earlier messages and try again.'
			return
		}
		$LocalUser = Get-ADUser $AccountName -Properties 'DisplayName'
	}
	Write-Host 'Creating corresponding Windows Azure Active Directory user...'
	Require-QSActiveMsolConnection
	$GUID = $LocalUser.ObjectGuid
	$Base64 = [System.Convert]::ToBase64String($GUID.ToByteArray())
	New-MsolUser -DisplayName $LocalUser.DisplayName `
		-ImmutableId $Base64 `
		-UserPrincipalName $LocalUser.UserPrincipalName `
		-FirstName $FirstName `
		-LastName $LastName `
}

# Download, install, and configure the DirSync tool
function Install-QSDirSync {
	Write-QSTitle 'Download, install, and configure the DirSync tool'
	$DirSyncFilename = $script:CurrentExecutingPath + '\DirSync.exe'
	if (-not (Require-QSDownloadableFile -FileName $DirSyncFilename -URL 'http://g.microsoftonline.com/0BX10en/571')) {
		Write-QSError 'DirSync download failed.'
		return
	}
	Write-Host 'Running DirSync installer...'
	Start-Process -FilePath $DirSyncFilename -ArgumentList @('/quiet') -Wait
	$ConfigWizardFilename = $env:ProgramFiles + '\Microsoft Online Directory Sync\ConfigWizard.exe'
	if (-not (Test-Path $ConfigWizardFilename)) {
		Write-QSError "Installation appears to have failed, try running $DirSyncFilename interactively."
		return
	}
	Write-QSWarning 'You must sign out and sign in again to continue.'
	Write-Host 'Script exiting.'
	Exit
}

# Configure the DirSync tool
function Configure-QSDirSync {
	Write-QSTitle 'Configure the DirSync tool'
	Add-PSSnapIn Coexistence-Configuration
	Require-QSActiveMsolConnection
	Write-Host 'Requesting synchonization credentials...'
	$TargetCredentials = Get-Credential -Message 'Permanent Synchronization Credentials'
	Write-Host 'Requesting local credentials...'
	$SourceCredentials = Get-Credential -Message 'Local Active Directory Administrator'
	Write-Host 'Requesting online coexistence configuration information...'
	$Configuration = Get-CoexistenceConfiguration -TargetCredentials $script:MsolCredential
	Write-Host 'Configuring local coexistence configuration information...'
	Set-CoexistenceConfiguration -SourceCredentials $SourceCredentials -TargetCredentials $TargetCredentials
	Write-Host 'Requesting an immediate synchronization...'
	Start-OnlineCoexistenceSync
}

# Get the latest Directory Synchronization events
function Get-QSEventLogSyncronizationEvents {
	Write-QSTitle 'Get the latest Directory Synchronization events'
	Get-EventLog -After ((Get-Date).AddMinutes(-30)) -LogName 'Application' -Source 'Directory Synchronization' | Sort-Object -Property TimeGenerated
}

#endregion

#region ----- main code -----

Test-QSRequirement -Requirement (Get-QSElevationStatus) -Message 'You must launch this script as an administrator.'
Test-QSRequirement -Requirement (-not (Test-QSWin32)) -Message 'You must launch this script in a 64-bit PowerShell session.'
Test-QSRequirement -Requirement (Test-QSServerOS) -Message 'You must run this script on a Server OS SKU.'
Test-QSRequirement -Requirement (Test-QSWindows8OrLater) -Message 'You must run this script on Windows Server 2012 or later.'

Disable-QSInternetExplorerESC

while (1) {
	Write-QSTitle -DoubleDashedLine -Title 'Active Directory to Windows Azure Active Directory QuickStart Tool'
@"
Select an operation to continue:
 
 0) EXIT
	
	ADFS Server Options (Part 1)
	----------------------------
 1) Install Microsoft Online Services Sign-In Assistant
 2) Install Microsoft Online Services Module for Windows PowerShell
 3) Download and run the Office 365 Deployment Readiness Tool
 4) Add local UPN suffix as domain in Windows Azure Active Directory
 5) Retrieve verification information for domains in Windows Azure Active Directory
 6) Enable directory synchronization (DirSync) on the tenant
 7) Add the ADFS role to this server
 8) Create a service account in the local domain for ADFS use
 9) Create an internal DNS entry for ADFS
10) Process SSL certificate for ADFS
11) Export SSL certificate with private key
12) Configure ADFS with basic configuration
13) Confirm/configure Windows Firewall for port 443
14) Launch test web pages
	
	ADFS Proxy Options
	------------------
15) Import certificates for ADFS Proxy
16) Add the ADFS Proxy role to this server
17) Configure IIS SSL and authentication
18) Add a HOSTS file entry for ADFS access from the proxy
19) Configure ADFS Proxy with basic configuration
20) Confirm/configure Windows Firewall for port 443
21) Launch test web pages

	ADFS Server Options (Part 2)
	----------------------------
22) Check DNS records for TXT entries for unverified domains
23) Configure Windows Azure AD connection to ADFS
24) Create a single sign-on test user
25) Download and install the DirSync tool
26) Configure the DirSync tool
27) Get the latest Directory Synchronization events
	
"@

	$Choice = Read-Host 'Enter your selection'

	switch ($Choice) {
		 0 { exit }
		 1 { Install-QSSignInAssistantExplicit; Write-QSCompletionMessage }
		 2 { Install-QSMsolServicesModuleExplicit; Write-QSCompletionMessage }
		 3 { Launch-QSOffice365DeploymentReadinessTool; Write-QSCompletionMessage }
		 4 { Add-QSMsolDomain; Write-QSCompletionMessage }
		 5 { Get-QSMsolDomainVerificationDnsAll; Write-QSCompletionMessage }
		 6 { Set-QSMsolDirSyncEnabled; Write-QSCompletionMessage }
		 7 { Install-QSADFSRole; Write-QSCompletionMessage }
		 8 { New-QSADFSServiceAccount; Write-QSCompletionMessage }
		 9 { Add-QSADFSDNSEntry; Write-QSCompletionMessage }
		10 { Process-QSCertificate; Write-QSCompletionMessage }
		11 { Export-QSCertificate; Write-QSCompletionMessage }
		12 { Configure-QSADFS; Write-QSCompletionMessage }
		13 { Configure-QSWindowsFirewall; Write-QSCompletionMessage }
		14 { Launch-QSIETestPages; Write-QSCompletionMessage }
		15 { Import-QSCertificates; Write-QSCompletionMessage }
		16 { Install-QSADFSProxyRole; Write-QSCompletionMessage }
		17 { Configure-QSIISSSLExplicit; Write-QSCompletionMessage }
		18 { Add-HostsEntryForADFS; Write-QSCompletionMessage } 
		19 { Configure-QSADFSProxyRole; Write-QSCompletionMessage }
		20 { Configure-QSWindowsFirewall; Write-QSCompletionMessage }
		21 { Launch-QSIETestPages; Write-QSCompletionMessage }
		22 { Test-QSExternalDNSRecords; Write-QSCompletionMessage }
		23 { Convert-QSMsolDomain; Write-QSCompletionMessage }
		24 { New-QSTestUser; Write-QSCompletionMessage }
		25 { Install-QSDirSync; Write-QSCompletionMessage }
		26 { Configure-QSDirSync; Write-QSCompletionMessage }
		27 { Get-QSEventLogSyncronizationEvents; Write-QSCompletionMessage }
	}
}

#endregion
