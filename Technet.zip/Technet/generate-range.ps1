# generate-range.ps1
# Implements New-IPRangeWithExclusions
# Usage: import-module <path>\generate-range.ps1

function IP2LongRev {
 param([System.Net.IPAddress] $ip)
 [byte[]] $b = $ip.GetAddressBytes()
 [System.Array]::Reverse($b)
 [System.BitConverter]::ToUInt32($b,0)
}

function IP2Long {
 param([System.Net.IPAddress] $ip)
 [byte[]] $b = $ip.GetAddressBytes()
 [System.BitConverter]::ToUInt32($b,0)
}

function ByteSwap {
 param([UInt32] $val)
 [byte[]] $b = [System.BitConverter]::GetBytes($val)
 [System.Array]::Reverse($b)
 [System.BitConverter]::ToUInt32($b,0)
}

function NextIP {
 param([System.Net.IPAddress] $ip)
 $longRep = IP2LongRev($ip)
 $longRep += 1
 $rev = ByteSwap($longRep)
 new-object System.Net.IPAddress($rev)
}

function PreviousIP {
 param([System.Net.IPAddress] $ip)
 $longRep = IP2LongRev($ip)
 $longRep -= 1
 $rev = ByteSwap($longRep)
 new-object System.Net.IPAddress($rev)
}

function New-IPRangeWithExclusions {
 [CmdletBinding()]
 param(
  [parameter(Mandatory=$true, Position=1, ValueFromPipeline=$true)]
  [System.Net.IPAddress[]] $exclusions
 )

 begin {}

 process {
  $max = [System.Net.IPAddress]::Parse("255.255.255.255")
  $min = [System.Net.IPAddress]::Parse("0.0.0.0")
  $sortedExclusionList = new-object System.Collections.SortedList
  $rangeList = new-object System.Collections.ArrayList
  $exclusions | foreach-object {
   $sortVal = IP2LongRev($_)
   $sortedExclusionList.Add($sortVal,$_) | out-null
  }
  foreach ($ip in $sortedExclusionList.Values)
  {
    if ((IP2Long($ip)) -eq 0)
    {
      $min=NextIP($ip)
      continue
    }
    if ((IP2Long($ip)) -eq 4294967295)
    {
      $max=PreviousIP($max)
      continue
    }
    $rangeStart = $min
    $rangeEnd = PreviousIP($ip)
    $rangeList.Add(($rangeStart.ToString())+"-"+($rangeEnd.ToString())) | out-null
    $min=NextIP($ip)
  }
  $rangeList.Add(($min.ToString())+"-"+($max.ToString())) | out-null
  [System.String]::Join(",",$rangeList.ToArray())
 }

 end {}

}
