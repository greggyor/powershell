﻿function Get-HBAWin { 
param( 
[String[]]$ComputerName = $ENV:ComputerName  
) 
 
$ComputerName | ForEach-Object { 
$Computer = $_ 
$Namespace = "root\WMI"  
Get-WmiObject -class MSFC_FCAdapterHBAAttributes -computername $Computer -namespace $namespace | 
ForEach-Object { 
$hash=@{ 
ComputerName     = $_.__SERVER 
NodeWWN          = (($_.NodeWWN) | ForEach-Object {"{0:x}" -f $_}) -join ":" 
Active           = $_.Active 
DriverName       = $_.DriverName 
DriverVersion    = $_.DriverVersion 
FirmwareVersion  = $_.FirmwareVersion 
Model            = $_.Model 
ModelDescription = $_.ModelDescription 
} 
New-Object psobject -Property $hash 
}#Foreach-Object(Adapter) 
}#Foreach-Object(Computer) 
 
}#Get-HBAWin