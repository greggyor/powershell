﻿$script:WarningPreference = "SilentlyContinue"

function OutputResults ($objects){

	If ($objects -eq $null){
		"" | Out-Host
		"" | Out-Host
		"Custom MaxReceiveSize or MaxSendSize not found" | Out-Host
		"" | Out-Host
		"" | Out-Host
	}
	Else{
		$objects | Select-Object DisplayName, MaxReceiveSize, MaxSendSize | fl
	}
}

"" | Out-Host
"Transport Config" | Out-Host 
"----------------" | Out-Host 
Get-TransportConfig | Select-Object MaxReceiveSize, MaxSendSize | fl

"AD Site Links" | Out-Host 
"-------------" | Out-Host 
Get-ADSiteLink | Select-Object Name, MaxMessageSize | fl

"Receive Connectors" | Out-Host
"------------------" | Out-Host
Get-ReceiveConnector | Select-Object Name, Server, MaxMessageSize | fl

"Send Connectors" | Out-Host
"---------------" | Out-Host
Get-SendConnector | Select-Object Name, MaxMessageSize | fl

"Foreign Connectors" | Out-Host
"------------------" | Out-Host
If(Get-ForeignConnector){
	Get-ForeignConnector | Select-Object Name, MaxMessageSize | fl
}
Else{
	"" | Out-Host
	"" | Out-Host
	"No Foreign Connectors Configured"
	"" | Out-Host
	"" | Out-Host
}

"Distribution Groups" | Out-Host
"-------------------" | Out-Host
OutputResults(Get-DistributionGroup -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})

"Dynamic Distribution Groups" | Out-Host
"---------------------------" | Out-Host
OutputResults(Get-DynamicDistributionGroup -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})

"Mailboxes" | Out-Host
"---------" | Out-Host
OutputResults(Get-Mailbox -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})

"Mail Contacts" | Out-Host
"-------------" | Out-Host
OutputResults(Get-MailContact -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})

"Mail Public Folders" | Out-Host
"-------------------" | Out-Host
OutputResults(Get-MailPublicFolder -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})

"Mail Users" | Out-Host
"----------" | Out-Host
OutputResults(Get-MailPublicFolder -ResultSize Unlimited | Where-Object {($_.MaxReceiveSize -ne "unlimited") -or ($_.MaxSendSize -ne "unlimited")})