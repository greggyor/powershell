﻿        #// The text being edited.
        $script:_text = New-Object Text.StringBuilder;

        #// The text as it is rendered (replaces [char]1 with ^A on display for example).
        [string] $script:_renderedText = "" 
        
        #// The current cursor position, indexes into "text", for an index
        #// into rendered_text, use TextToRenderPos
        [int] $script:_cursor = 0;

        #// The row where we started displaying data.
        [int] $script:_homeRow = 0;

        #// The maximum length that has been displayed on the screen
        [int] $script:_maxRendered = 0;
        
        #// If we are done editing, $this breaks the interactive loop
        [bool] $script:_done = $false;
        
        #// The contents of the kill buffer (cut/paste in Emacs parlance)
        [string] $private:_killBuffer = "";
        
        [int] $script:LineCount = 0
        Set-PSBreakpoint -Mode Read -Variable LineCount -Action {
             $null, $script:LineCount = GetScreenPos $script:_text.cursor -row 0
#            $script:LineCount = [Math]::DivRem($script:_shownPrompt.Length + $script:_renderedText.Length, [Console]::WindowWidth, [ref]$null);
            }
            
        [int] $private:_historyhead = 0
        
        [int] $script:HistoryID = (Get-History -Count 1).ID
        Set-PSBreakpoint -Mode Read -Variable HistoryID -Action {
            $lastID = (Get-History -Count 1).ID
            $firstID = [Math]::Max(1, $lastID - ($MaximumHistoryCount-1))
            if ( $script:HistoryID -gt $lastID ) { $script:HistoryID = $lastID }
            elseif ( $script:HistoryID -lt $firstID ) { $script:HistoryID = $firstID }
            }
        
        [bool] $script:completing = $false
        
        #Set-PSBreakpoint -var completing -Mode Write -Action { $Host.UI.RawUI.WindowTitle = $global:MyInvocation.MyCommand }
        
        $script:ncompletions = @()
        
        [int] $script:completionID = 0
        Set-PSBreakpoint -Mode Read -Variable completionID -Action {
            if ($script:ncompletions.CompletionMatches.Count -eq 1) { $script:completionID = 0 }
            elseif ( $script:completionID -gt ($script:ncompletions.CompletionMatches.Count-1) ) { $script:completionID -= $script:ncompletions.CompletionMatches.Count }
            elseif ( $script:completionID -lt 0 ) { $script:completionID = ($script:completionID += $script:ncompletions.CompletionMatches.Count) }
            }
            
        [int] $script:DleteLength = 0
        
        [int] $script:reversing = $false
        
        #// Used to implement the Kill semantics (multiple Alt-Ds accumulate)
        [scriptblock] $script:_lastHandler = $null;
        
        #// The thread where the Editing started taking place
        $script:_editThread = [Threading.Thread]::CurrentThread;
        
        #// The prompt specified, and the prompt shown to the user.
        [scriptblock] $script:_prompt = $null;

        [string] $script:_shownPrompt = $null;

        #// powershell already evaluates the prompt, so we should not but still take it into account
        [bool] $script:_shouldShowPrompt = $true;
        
        [string] $script:_defaultPrompt = "";
        
        [bool] $script:_selectingL = $false;
        
        [bool] $script:_selectingR = $false;
        
        [int] $script:_selecthead = 0
        
        [int] $script:_selecttail = 0
        
        [int] $script:_selectinglength = 0

        $script:_point = New-Object Win32.kernel32+COORD
        
        Add-Type -AssemblyName System.Windows.Forms
        $script:_clip = New-Object System.Windows.Forms.TextBox;
        $script:_clip.Multiline = $true

        $script:_exceptingEnter_Tab = -join [char[]](0..8 + 11..12 + 14..25)

        #//
        #// Commands
        #//
        function CmdDone()
        {
            $this._done = $true;
            $this.completing = $false;
            InitSelecting;
        }
        
        function NewLine()
        {
            $this._text.Insert($this._cursor, "`r`n") > $null
            $fill = $Host.UI.RawUI.BufferSize.Width - $Host.UI.RawUI.CursorPosition.X
            [Console]::Write(' ' * $fill)
            
            $col, $rowCurrent = GetScreenPos ($this._cursor)
            $null, $rowEnd = GetScreenPos ($this._text.Length)
            [Console]::Write(' ' * $Host.UI.RawUI.BufferSize.Width * ($rowEnd-$rowCurrent))
            
            ForceCursor ($this._cursor + 2) -NewLine;
            [Console]::Write($this._text.ToString().SubString($this._cursor))
            ForceCursor ($this._cursor) -NewLine;
        }
        
        function CmdBackspace()
        {
            if ( $this._selectingL -or $this._selectingR ) { DeleteSelectedText; }
            
            $this.completing = $false
            InitSelecting;
            
            if ($this._cursor -eq 0) { return; }

            $this._text.Remove(--$this._cursor, 1) > $null;
            ComputeRendered;
            RenderAfter ($this._cursor);
#            $Host.UI.RawUI.WindowTitle = 'CursorPosition.Y : {0}  $this._homeRow : {1}   $this._cursor {2}  $this.LineCount  {3}' -f $Host.UI.RawUI.CursorPosition.Y, $this._homeRow, $this._cursor, $this.LineCount
        }

        function CmdDeleteChar()
        {
            if ( $this._selectingL -or $this._selectingR ) { DeleteSelectedText; }
            
            $this.completing = $false
            InitSelecting;
            
            #// If there is no input, $this behaves like EOF
            if ($this._text.Length -eq 0)
            {
                $this._done = $true;
                $this._text = $null;
                [Console]::WriteLine();
                return;
            }

            if ($this._cursor -eq $this._text.Length) { return; }
            $this._text.Remove($this._cursor, 1) > $null;
            ComputeRendered;
            RenderAfter ($this._cursor);
            
        }
        
        function CmdHome()
        {
            UpdateCursor (0);
            $this.completing = $false
            InitSelecting;
        }

        function CmdEnd()
        {
            UpdateCursor ($this._text.Length);
            $this.completing = $false
            InitSelecting;
        }
        
        function CmdClearLine()
        {
            SetText "";
            $this.completing = $false
            InitSelecting;
        }
        
        function CmdLeft()
        {
            $this.completing = $false
            InitSelecting;
            
            if ($this._cursor -eq 0) { return; }

            if ( $this._text.ToString()[$this._cursor-1] -eq "`n" ) {
            UpdateCursor ($this._cursor - 2);
            } else {
            UpdateCursor ($this._cursor - 1);
            }

        }

        function CmdRight()
        {
            $this.completing = $false
            InitSelecting;
            if ($this._cursor -eq $this._text.Length) { return; }

            if ( $this._text.ToString()[$this._cursor] -eq "`r" ) {
            UpdateCursor ($this._cursor + 2);
            } else {
            UpdateCursor ($this._cursor + 1);
            }
        }

        function CmdUp()
        {
        
            $this.completing = $false
            InitSelecting;

            [int] $row = 0;
            
            $null, $row = GetScreenPos ($this._cursor)
            if ($row -eq $this._homeRow) { return; }
            
            $_text = $this._text.ToString()
            
            $diffprev = $this._cursor - $_text.LastIndexOf("`n", $this._cursor)
            $this._cursor -= $diffprev + 1
            $diffafter = $this._cursor - $_text.LastIndexOf("`n", $this._cursor)
            
            if ($diffafter -gt $diffprev) { $this._cursor -= $diffafter-$diffprev }
            
            ForceCursor ($this._cursor);
        }


        function CmdDown()
        {
            [int] $col = 0;  
            $this.completing = $false
            InitSelecting;
  
            [int] $rowCurrent = [int] $rowEnd = 0;  
            
            $col, $rowCurrent = GetScreenPos ($this._cursor)
            $null, $rowEnd = GetScreenPos ($this._text.Length)
            
            if ($rowCurrent -eq $rowEnd) { return; }
            
            $_text = $this._text.ToString()
            
            $diffprev = $_text.IndexOf("`n", $this._cursor) - $this._cursor
            $this._cursor += $diffprev + 1
            
            if ($rowCurrent+1 -eq $rowEnd) {
                $diffafter = $_text.Length - $this._cursor
            } else {
                $diffafter = $_text.IndexOfAny("`n", $this._cursor) - $this._cursor
            }
            
            if ($col -gt $diffafter) {
                $this._cursor += $diffafter
            } else {
                $this._cursor += $col
            }

            ForceCursor ($this._cursor);
        }
        
        
        function SelectLeft()
        {
            if ($this._cursor -eq 0) { return; }
            
            if ( $this._selectingR ) {
                ReverseTextColor -reverse:$false
                $this._selecttail = ($this._cursor - 1)
                UpdateCursor ($this._cursor - 1);
                UpdateHomeRow ($this._cursor);
                $this._selectinglength--
                if (!$this._selectinglength) { $this._selectingR = $false }
                return;
            }
            elseif ( !$this._selectingL ) {
                $this._selectinglength = 1
                $this._selectingL = $true;
                $this._selecttail = $this._cursor
            }
            else {
                $this._selectinglength++
            }
            
            ReverseTextColor
            $this._selecthead = ($this._cursor - 1)
            UpdateCursor ($this._cursor - 1);
            UpdateHomeRow ($this._cursor);
            $this.completing = $false
        }

        function SelectRight()
        {
            if ($this._cursor -eq $this._text.Length) { return; }
            
            if ( $this._selectingL ) {
                ReverseTextColor -reverse:$false
                $this._selecthead = ($this._cursor + 1)
                UpdateCursor ($this._cursor + 1);
                UpdateHomeRow ($this._cursor);
                $this._selectinglength--
                if (!$this._selectinglength) { $this._selectingL = $false }
                return;
            }
            elseif ( !$this._selectingR ) {
                $this._selectinglength = 1
                $this._selectingR = $true;
                $this._selecthead = $this._cursor
            }
            else {
                $this._selectinglength++
            }
            
            ReverseTextColor
            $this._selecttail = ($this._cursor + 1)
            UpdateCursor ($this._cursor + 1);
            UpdateHomeRow ($this._cursor);
            $this.completing = $false
        }

        function CmdCopyText {
            $this.completing = $false
            if ( !$this._selectingL -and !$this._selectingR ) { return; }
            $this._clip.Text = $this._text.ToString().Substring($this._selecthead, $this._selectinglength)
            $this._clip.SelectAll()
            $this._clip.Copy()
        }
        
        function CmdCutText {
            $this.completing = $false
            if ( !$this._selectingL -and !$this._selectingR ) { return; }
            $this._clip.Text = $this._text.ToString().Substring($this._selecthead, $this._selectinglength)
            $this._clip.SelectAll()
            $this._clip.Copy()
            DeleteSelectedText
        }
        
        function CmdPasteText {
            $this.completing = $false
            if ( $this._selectingL -or $this._selectingR ) { DeleteSelectedText; }
            
            $this._clip.Text = ""
            $this._clip.Paste()
            InsertTextAtCursor $this._clip.Text
            InitSelecting;
        }        
        
        function InitText([string] $initial)
        {
            $this._text = New-Object Text.StringBuilder ($initial);
            ComputeRendered;
            $this._cursor = $this._text.Length;
            Render;
            ForceCursor ($this._cursor);
        }
        
        function InitSelecting {
            $this._selectingR = $this._selectingL = $false;
            $this._selectinglength = 0;
            $this._selecthead = $this._selecttail = 0;
            ReverseTextColor -pos:$this._shownPrompt.Length -row:$this._homeRow -length:$this._text.Length -reverse:$false
        }
        
        function SetText([string] $newtext)
        {
            $this.completing = $false
            [Console]::SetCursorPosition(0, $this._homeRow);
            InitText ($newtext);
        }

        function InsertTextAtCursor([string] $str)
        {
            [int] $prevLines = $script:LineCount;
            $this._text.Insert($this._cursor, $str) > $null;
            ComputeRendered;
            if ($prevLines -ne $script:LineCount)
            {
                [Console]::SetCursorPosition(0, $this._homeRow);
                Render;
                $this._cursor += $str.Length;
                ForceCursor ($this._cursor);
            }
            else
            {
                RenderFrom ($this._cursor);
                $this._cursor += $str.Length;
                ForceCursor ($this._cursor);
                UpdateHomeRow  ($this._cursor);
            }
        }
        
        function DeleteInsertedText([int] $length)
        {
            $this._cursor -= $length
            $this._text.Remove($this._cursor, $length) > $null;
            ComputeRendered;
            RenderAfter ($this._cursor);
        }        
        
        function DeleteSelectedText()
        {
            $this._cursor = $this._selecthead
            $this._text.Remove($this._cursor, $this._selectinglength) > $null;
            ComputeRendered;
            RenderAfter ($this._cursor);
            InitSelecting;
        }      
        
        function CmdHistoryPrev()
        {
            [Console]::SetCursorPosition(0, $this._homeRow)
            [Console]::Write(' ' * $Host.UI.RawUI.BufferSize.Width*10)
            ForceCursor $this._cursor
            
            --$script:HistoryID;
            SetText (Get-History -Id $script:HistoryID).CommandLine;
                        
            $this.completing = $false
            InitSelecting;
        }

        function CmdHistoryNext()
        {
            [Console]::SetCursorPosition(0, $this._homeRow)
            [Console]::Write(' ' * $Host.UI.RawUI.BufferSize.Width*10)
            ForceCursor $this._cursor      
            
            ++$script:HistoryID;
            SetText (Get-History -Id $script:HistoryID).CommandLine;
                       
            $this.completing = $false
            InitSelecting;
        }
        
        function WordForward([int] $p)
        {
            if ($p -ge $this._text.Length) { return -1; }

            [int] $i = $p;
            if ([Char]::IsPunctuation($this._text.ToString()[$p]) -or [Char]::IsWhiteSpace($this._text.ToString()[$p]))
            {
                for (; $i -lt $this._text.Length; $i++)
                {
                    if ([Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
                for (; $i -lt $this._text.Length; $i++)
                {
                    if (![Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
            }
            else
            {
                for (; $i -lt $this._text.Length; $i++)
                {
                    if (![Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
            }
            if ($i -ne $p) { return $i; }
            return -1;
        }

        function WordBackward([int] $p)
        {
            if ($p -eq 0) { return -1; }

            [int] $i = $p - 1;
            if ($i -eq 0) { return 0; }

            if ([Char]::IsPunctuation($this._text.Chars($i)) -or [Char]::IsSymbol($this._text.Chars($i)) -or [Char]::IsWhiteSpace($this._text.Chars($i)))
            {
                for (; $i -ge 0; $i--)
                {
                    if ([Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
                for (; $i -ge 0; $i--)
                {
                    if (![Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
            }
            else
            {
                for (; $i -ge 0; $i--)
                {
                    if (![Char]::IsLetterOrDigit($this._text.Chars($i))) { break; }
                }
            }
            $i++;

            if ($i -ne $p) { return $i; }

            return -1;
        }

        function CmdBackwardWord()
        {
            $this.completing = $false
            InitSelecting;
            
            [int] $p = WordBackward($this._cursor);
            if ($p -eq -1) { return; }
            UpdateCursor ($p);
        }

        function CmdForwardWord()
        {
            $this.completing = $false
            InitSelecting;
            
            [int] $p = WordForward($this._cursor);
            if ($p -eq -1) { return; }
            UpdateCursor ($p);
        }
        
        function CmdDeleteWord()
        {
            $this.completing = $false
            InitSelecting;
            
            [int] $pos = WordForward ($this._cursor);

            if ($pos -eq -1) { return; }

            [string] $k = $this._text.ToString($this._cursor, $pos - $this._cursor);

            if ($this._lastHandler -eq $function:CmdDeleteWord) { $this._killBuffer = $this._killBuffer + $k; }
            else { $this._killBuffer = $k;}

            $this._text.Remove($this._cursor, $pos - $this._cursor) > $null;
            ComputeRendered;
            RenderAfter ($this._cursor);
            
        }

        function CmdDeleteBackword()
        {
            $this.completing = $false
            InitSelecting;
            
            [int] $pos = WordBackward ($this._cursor);
            if ($pos -eq -1) { return; }

            [string] $k = $this._text.ToString($pos, $this._cursor - $pos);

            if ($this._lastHandler -eq $function:CmdDeleteBackword) { $this._killBuffer = $k + $this._killBuffer; }
            else { $this._killBuffer = $k; }

            $this._text.Remove($pos, $this._cursor - $pos) > $null;
            ComputeRendered;
            RenderAfter ($pos);
            
        }

        function CmdTabOrComplete()
        {
            if ( $this._text -notmatch '^\s*$' -or $this.completing )
            {
                if (!$this.completing) {
                    $this.ncompletions = [System.Management.Automation.CommandCompletion]::CompleteInput($this._text.ToString(), $this._cursor, $null )
                    $this.DleteLength = $this.ncompletions.ReplacementLength
                    DeleteInsertedText $this.DleteLength
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID++].CompletionText.Length
                    $this.completing = $true
                }
                elseif (!$this.reversing) {
                    DeleteInsertedText $this.DleteLength
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID++].CompletionText.Length
                }
                else  {
                    DeleteInsertedText $this.DleteLength
                    $this.completionID+=2
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID++].CompletionText.Length
                }
                
                $this.reversing = $false
            }
            else { HandleChar ("`t"); }
        }

        function ReverseCmdTabOrComplete()
        {
            if ( $this._text -notmatch '^\s*$' -or $this.completing )
            {        
                if (!$this.completing) {
                    $this.ncompletions = [System.Management.Automation.CommandCompletion]::CompleteInput($this._text.ToString(), $this._cursor, $null )
                    $this.DleteLength = $this.ncompletions.ReplacementLength
                    DeleteInsertedText $this.DleteLength
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID--].CompletionText.Length
                    $this.completing = $true
                }
                elseif ($this.reversing) {
                    DeleteInsertedText $this.DleteLength
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID--].CompletionText.Length
                }
                else  {
                    DeleteInsertedText $this.DleteLength
                    $this.completionID-=2
                    InsertTextAtCursor $this.ncompletions.CompletionMatches[$this.completionID].CompletionText
                    $this.DleteLength = $this.ncompletions.CompletionMatches[$this.completionID--].CompletionText.Length
                }
                
                $this.reversing = $true
            }
            else { HandleChar ("`t"); }
        }
        
        #//
        #// Render functions
        #//

        function ComputeRendered()
        {
            $this._renderedText = $this._text
            0..8 + 11..12 + 14..25 |
            % { $this._renderedText = $this._renderedText -replace [char]$_, ("^" + [char]($_+[int][char]"A"-1)) }
            $this._renderedText = $this._renderedText -replace "`t", "    "
        }
        
        function UpdateHomeRow([int] $pos)
        {
            $null, [int] $lines = GetScreenPos $pos -row 0

            $this._homeRow = [Console]::CursorTop - $lines;

            if ($this._homeRow -lt 0) { $this._homeRow = 0; }
        }        
        
        function Render([switch]$IncludePromptLength)
        {
            if ($_shouldShowPrompt)
            {
                [Console]::Write($this._shownPrompt);
            }
            [Console]::Write($this._renderedText);
            $renderedByteCount = [Console]::InputEncoding.GetByteCount($this._renderedText)

            [int] $max = [Math]::Max($renderedByteCount + $this._shownPrompt.Length, $this._maxRendered);

            for ([int] $i = $renderedByteCount + $this._shownPrompt.Length; $i -lt $this._maxRendered; $i++)
            {
                [Console]::Write(' ');
            }
            $this._maxRendered = $this._shownPrompt.Length + $renderedByteCount;

            #// Write one more to ensure that we always wrap around properly if we are at the
            #// end of a line.
            [Console]::Write(' ');

            UpdateHomeRow ($this._cursor);
        }
        
        function RenderAfter([int] $p)
        {
            ForceCursor ($p);
            RenderFrom ($p);
            ForceCursor ($this._cursor);
        }
        
        function ForceCursor ([int] $newpos, [switch]$NewLine)
        {
            [int] $col = 0;
            [int] $row = 0;
            $this._cursor = $newpos;
            
            $col, $row = GetScreenPos ($this._cursor)

            if ($NewLine) { $col = 0 }

            [Console]::SetCursorPosition($col, $row);
        }

        function UpdateCursor([int] $newpos)
        {
            if ($this._cursor -eq $newpos) { return; }

            ForceCursor ($newpos);
        }
        
        function DownCursor([switch]$NewLine)
        {
            $col, $row = GetScreenPos $this._cursor
            [Console]::SetCursorPosition($col, $row+1);
        }
        
        function RenderFrom([int] $pos)
        {
            [int] $rpos = TextToRenderPosS ($pos);
            $_text = $this._renderedText.ToString().SubString($rpos, ($this._renderedText.Length-$rpos))
            [Console]::Write($_text)

            [int] $maxExtra = $this._maxRendered - $this._shownPrompt.Length;
            
            if (($this._shownPrompt.Length + $this._renderedText.Length) -gt $this._maxRendered)
            {
                $this._maxRendered = $this._shownPrompt.Length + [Console]::InputEncoding.GetByteCount($this._renderedText);
            }
            else
            {
                $DeletionRange =  $maxExtra - $this._renderedText.Length
                [Console]::Write(' ' * $DeletionRange)
            }

        }        
        
        function TextToRenderPosS([int] $pos)
        {
            $text = ($this._text.ToString().substring(0,$pos) -replace $_exceptingEnter_Tab, '@@') -replace "`t", '@@@@'
            return $text.Length
        }

        function TextToRenderPosB([int] $pos, [string] $text = $this._text.ToString().substring(0,$local:pos) )
        {
            $text = ($text -replace $_exceptingEnter_Tab, '@@') -replace "`t", '@@@@'
            return [Console]::InputEncoding.GetByteCount($text)
        }
        
#        function TextToScreenPos([int] $pos)
#        {
#            return $this._shownPrompt.Length + (TextToRenderPosB ($pos));
#        }        

        function GetScreenPos ($pos, [int] $row = $this._homeRow) {
            [int] $col = [int] $col2 = 0;            
            [int] $actualPos = 0;
            
            $_text = $this._text.ToString().SubString(0, $pos)
            $_text = [Regex]::Split($_text, "\r\n");
            
            $actualPos = $this._shownPrompt.Length + [Console]::InputEncoding.GetByteCount($_text[0])
            $row += [Math]::DivRem($actualPos, [Console]::WindowWidth, [ref]$col);

            foreach ( $line in $_text[1.. $_text.Count] ) {
            $line = ($line -replace $_exceptingEnter_Tab, '@@') -replace "`t", '@@@@'
            $actualPos = [Console]::InputEncoding.GetByteCount($line)
            $row += [Math]::DivRem($actualPos, [Console]::WindowWidth, [ref]$col2) + 1
            }
            
            if ($row -ge [Console]::BufferHeight) { $row = [Console]::BufferHeight - 1; }
            
            if ( $_text.Count -gt 1 ) { $col = $col2 }
            echo $col $row
        }
        
        function ReverseTextColor ( $pos=$this._cursor, [int] $row, [int] $length=1, [bool]$reverse=$true ) {
            
            $hc = [Win32.kernel32]::GetStdHandle(-11) # STD_OUTPUT_HANDLE -11 
            
            if (!$row) {
                $col, $row = GetScreenPos $this._cursor
            } else {
                $col, $null = GetScreenPos $this._cursor
            }
            
            $this._point.X, $this._point.Y = $col, $row

            if ($reverse) {
            [int] $fg = [Console]::BackgroundColor
            [int] $bg = [Console]::ForegroundColor
            }
            else {
            [int] $fg = [Console]::ForegroundColor
            [int] $bg = [Console]::BackgroundColor
            }
            
            [Win32.kernel32]::FillConsoleOutputAttribute( $hc, $fg+$bg*16, $length, $this._point, [ref]$null) > $null
        }

#        function ClearScreen ([char]$fill=" ", $lines=20) {
#            $hc = [Win32.kernel32]::GetStdHandle(-11)
#            $length = $Host.UI.RawUI.WindowSize.Width * $lines
#            $col, $null = GetScreenPos $this._cursor
#            $this._point.X, $this._point.Y = $col, $row
#            
#            [Win32.kernel32]::FillConsoleOutputCharacter($hc, " ", $length , $this._point, [ref]$null)
#        }


#        function ReverseTextColor ( $pos=$this._cursor, [int] $row, [int] $length=1, [bool]$reverse=$true ) {
#            
#            $hc = [Win32.kernel32]::GetStdHandle(-11) # STD_OUTPUT_HANDLE -11 
#            
#            if (!$row) {
#                [int] $actualPos = $this._shownPrompt.Length + (TextToRenderPosB ($this._cursor));
#                [int] $row = $this._homeRow + [Math]::DivRem($actualPos, [Console]::WindowWidth, [ref]$null);
#            }
#            
#            $this._point.X, $this._point.Y = (($this._shownPrompt.Length + $pos) % [Console]::WindowWidth), $row
#
#            if ($reverse) {
#            [int] $fg = [Console]::BackgroundColor
#            [int] $bg = [Console]::ForegroundColor
#            }
#            else {
#            [int] $fg = [Console]::ForegroundColor
#            [int] $bg = [Console]::BackgroundColor
#            }
#            
#            [Win32.kernel32]::FillConsoleOutputAttribute( $hc, $fg+$bg*16, $length, $this._point, [ref]$null) > $null
#        }

        
        function InsertChar([char] $c)
        {
            if ( $this._selectingL -or $this._selectingR ) { DeleteSelectedText; }  
            
            [int] $prevLines = $script:LineCount;
            $this._text.Insert($this._cursor, $c) > $null;
            ComputeRendered;

            if ($prevLines -ne $script:LineCount)
            {
                [Console]::SetCursorPosition(0, $this._homeRow);
                Render;
                ForceCursor (++$this._cursor);
            }
            else
            {
                RenderFrom ($this._cursor);
                ForceCursor (++$this._cursor);
                UpdateHomeRow $this._cursor;
            }
            $this.completing = $false
        }        

        function HandleChar([char] $c)
        {
            InsertChar ($c)
        }

        
        $Handler = New-Module -AsCustomObject -ScriptBlock {

            function ConsoleKey([ConsoleKey] $key, [ScriptBlock] $h)
            {
                @{ KeyInfo =  New-Object ConsoleKeyInfo ([char]0, $key, $false, $false, $false);
                   KeyHandler = $h;
                }
                
            }

            function char([char] $c, [ScriptBlock] $h)
            {
                #// Use the "Zoom" as a flag that we only have a character.
                @{ KeyInfo = New-Object ConsoleKeyInfo ($c, [ConsoleKey]::Zoom, $false, $false, $false);
                   KeyHandler = $h;
                }
            }

            function ConsoleKeyInfo([ConsoleKeyInfo] $keyInfo, [ScriptBlock] $h)
            {
                @{ KeyInfo =  $keyInfo;
                   KeyHandler = $h;
                }
            }

            function Control([char] $c, [ScriptBlock] $h)
            {
                return char ([char]([int]$c - [int][char]'A' + 1))  $h;
            }
            
            function ControlBackspace([ScriptBlock] $h)
            {
                @{ KeyInfo = New-Object ConsoleKeyInfo ([ConsoleKey]::F16, [ConsoleKey]::Backspace, $false, $false, $true);
                   KeyHandler = $h;
                }
            }
            
            function ControlMeta([ConsoleKey] $key, [ScriptBlock] $h)
            {
                @{ KeyInfo = New-Object ConsoleKeyInfo ([char]0, $key, $false, $false, $true);
                   KeyHandler = $h;
                }
            }
            
            function Shift([ConsoleKey] $key, [ScriptBlock] $h)
            {
                @{ KeyInfo = New-Object ConsoleKeyInfo ([char]0, $key, $true, $false, $false);
                   KeyHandler = $h;
                }
            }
            
            function Alt([char] $c, [ConsoleKey] $k, [ScriptBlock] $h)
            {
                $cki = New-Object ConsoleKeyInfo ($c, $k, $false, $false, $false)
                return ConsoleKeyInfo $cki $h;
            }
            
            Export-ModuleMember *
        }
        
        $script:_handlers = @(
                            $Handler.ConsoleKey([ConsoleKey]::Home, $function:CmdHome),
                            $Handler.ConsoleKey([ConsoleKey]::End, $function:CmdEnd),
                            $Handler.ConsoleKey([ConsoleKey]::Escape, $function:CmdClearLine),
                            $Handler.ConsoleKey([ConsoleKey]::LeftArrow, $function:CmdLeft),
                            $Handler.ConsoleKey([ConsoleKey]::RightArrow, $function:CmdRight),
                            $Handler.ConsoleKey([ConsoleKey]::UpArrow, $function:CmdUp),
                            $Handler.ConsoleKey([ConsoleKey]::DownArrow, $function:CmdDown),
                            $Handler.ConsoleKey([ConsoleKey]::Enter, $function:NewLine),
                            $Handler.ConsoleKey([ConsoleKey]::Backspace, $function:CmdBackspace),
                            $Handler.ConsoleKey([ConsoleKey]::Delete, $function:CmdDeleteChar),
                            $Handler.ConsoleKey([ConsoleKey]::Tab, $function:CmdTabOrComplete),
                            $Handler.Shift([ConsoleKey]::Tab, $function:ReverseCmdTabOrComplete),
                            $Handler.Shift([ConsoleKey]::Enter, $function:CmdDone),
                            $Handler.Shift([ConsoleKey]::LeftArrow, $function:SelectLeft),
                            $Handler.Shift([ConsoleKey]::RightArrow, $function:SelectRight),
                            $Handler.Control('C', $function:CmdCopyText),
                            $Handler.Control('V', $function:CmdPasteText),
                            $Handler.Control('W', $function:CmdCutText),
                            $Handler.Control('X', $function:CmdCutText),
                            $Handler.ControlMeta([ConsoleKey]::LeftArrow, $function:CmdBackwardWord),
                            $Handler.ControlMeta([ConsoleKey]::RightArrow, $function:CmdForwardWord), 
                            $Handler.ControlMeta([ConsoleKey]::UpArrow, $function:CmdHistoryPrev),
                            $Handler.ControlMeta([ConsoleKey]::DownArrow, $function:CmdHistoryNext),
                            $Handler.ControlBackspace($function:CmdDeleteBackword),
                            $Handler.ControlMeta([ConsoleKey]::Delete, $function:CmdDeleteWord)
                            )
                            
        function EditLoop()
        {

            while (!$this._done)
            {
                $cki = [Console]::ReadKey($true);
                $mod = $cki.Modifiers

                $handled = $false;

                foreach ($handler in $_handlers)
                {
                    [ConsoleKeyInfo] $t = $handler.KeyInfo;

                    if (($t.Key -eq $cki.Key) -and ($t.Modifiers -eq $mod))
                    {
                        $handled = $true;
                        $handler.KeyHandler.invoke();
                        $this._lastHandler = $handler.KeyHandler;
                        break;
                    }
                    if (($t.KeyChar -eq $cki.KeyChar) -and ($t.Key -eq [ConsoleKey]::Zoom))
                    {
                        $handled = $true;
                        $handler.KeyHandler.invoke();
                        $this._lastHandler = $handler.KeyHandler;
                        break;
                    }
                }
                
                if ($handled)
                {
                    continue;
                }
                
                if ($cki.KeyChar -ne [char]0) { HandleChar ($cki.KeyChar); }
            }
        }

        function InterruptEdit([Object] $sender, [ConsoleCancelEventArgs] $a)
        {
            #// Do not abort our program:
            $a.Cancel = $true;

            #// Interrupt the editor
            $this._editThread.Abort();
        }
        
        function GetPromptSafe() {
            [string] $promptText = $_defaultPrompt;
            try {
                $promptText = $this._prompt.invoke();
            }
            catch [Exception] {
                #// swallow prompt delegate errors
                [Diagnostics.Trace]::WriteLine("GetPromptSafe error: " + $_);
            }
            return $promptText;
        }
        
        function SetPrompt([string] $newprompt)
        {
            $this._shownPrompt = $newprompt;
            [Console]::SetCursorPosition(0, $this._homeRow);
            Render;
            ForceCursor ($this._cursor);
        }
        
        #/// <summary>
        #/// 
        #/// </summary>
        #/// <param name="promptHandler"></param>
        #/// <param name="defaultPrompt"></param>
        #/// <param name="shouldShowPrompt"> </param>
        #/// <param name="initialText"></param>
        #/// <returns></returns>
        function Edit([scriptblock] $promptHandler = $null, [bool] $shouldShowPrompt = $true, [string] $initialText = "", [string] $defaultPrompt = "PS> ")
        {
            $this._defaultPrompt = $defaultPrompt;

            $this._done = $false;
            
            $this._prompt = $promptHandler;
            $this._shownPrompt = if ($promptHandler -ne $null) { GetPromptSafe }
                                 else { [String]::Empty; }
            $this._shouldShowPrompt = $shouldShowPrompt;

            InitText ($initialText);

            [Console]::TreatControlCAsInput = $true
            
            do
            {
                try
                {
                    EditLoop;
                }
                catch [Threading.ThreadAbortException]
                {
                    [Threading.Thread]::ResetAbort();
                    [Console]::WriteLine();
                    SetPrompt (GetPromptSafe);
                    SetText ([String]::Empty);
                }
            }
            while (!$this._done);
            
            [Console]::TreatControlCAsInput = $false
            
            [Console]::WriteLine();

            if ($this._text -eq $null)
            {
                return $null;
            }

            [string] $result = $this._text.ToString();

            return $result;
        }


Export-ModuleMember -Function * -Variable *