$ver = $host | select version
if ($ver.Version.Major -gt 1) {$Host.Runspace.ThreadOptions = "ReuseThread"}
Add-PsSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

##
#Set Variables
##
$TargetWeb = "http://contoso/web"
$TargetLibrary = "Shared Documents"
$Filename = "MyFile.txt"

##
#Begin Script
##

$MyWeb = Get-SPWeb $TargetWeb
$MyList = $MyWeb.GetFolder($TargetLibrary)
$MyFile = $MyList.Files | ? {$_.title -eq $Filename}
$MyFile.UndoCheckOut()
$MyFile.Update()