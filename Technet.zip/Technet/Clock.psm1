﻿$timer= New-Object System.Timers.Timer
$timer.AutoReset = $false
$clock=@{}
$clock["Rest"]= New-TimeSpan -Seconds 20
$clock["LastStart"]= [datetime]::Now
$global:SongAlarm = 'C:\Users\Kael\Valhala\Music\Almah - Motion `[2011`]\05 Zombies Dictator.mp3'
$sb= { ii $global:SongAlarm}
function Start([Nullable[int]]$hour, [Nullable[int]]$minute, [Nullable[int]]$second)
{
    
    if($psboundparameters.count -ne 0){
        
        $total = New-TimeSpan
        if($hour -ne $null){$wtf1=new-timespan -Hours $hour;$total+=$wtf1}
        if($minute -ne $null){$wtf2=new-timespan -Minutes $minute;$total+=$wtf2}
        if($second -ne $null){$wtf3=new-timespan -Seconds $second;$total+=$wtf3}
        $clock.Rest = $total
    }
    $timer.Interval = $clock.Rest.TotalMilliseconds
    $clock.LastStart = [DateTime]::Now
    Unregister-Event -SourceIdentifier Clock -errorAction SilentlyContinue
    Register-ObjectEvent -InputObject $timer -EventName Elapsed -SourceIdentifier Clock -action $sb 
	$timer.Start()
}
function Pause
{
    $timer.stop()
    $clock.Rest=$clock.rest.Subtract([DateTime]::Now.Subtract($clock.LastStart))
   
}
function Reset([Nullable[int]]$hour, [Nullable[int]]$minute, [Nullable[int]]$second)
{
    if($psboundparameters.count -ne 0){
        
        $total = New-TimeSpan
        if($hour -ne $null){$wtf1=new-timespan -Hours $hour;$total+=$wtf1}
        if($minute -ne $null){$wtf2=new-timespan -Minutes $minute;$total+=$wtf2}
        if($second -ne $null){$wtf3=new-timespan -Seconds $second;$total+=$wtf3}
        $clock.Rest = $total
    }else{
        try{
            "Enter Estimated time hh:mm:ss"
            $clock.Rest=[TimeSpan](Read-Host)
        }catch{
            "Bad format, applying default time (2h)"    
            $clock.Rest=[TimeSpan]"02:00:00"
        }
        
	}
    $timer.stop()
}

export-modulemember -function Start,Pause,Reset -variable clock

