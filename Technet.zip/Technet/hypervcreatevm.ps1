﻿#
# hyperv_create_vm.ps1
# by Maikel Gaedker
# http://www.bloggin-it.de
#

### environment settings
$templatepath = “D:\Hyper-V\w2k8r2_template.vhdx”
$path = "D:\Hyper-V"
$vmlist = "test_diff" # comma-seperated list of VM-Names
### selesct one of these 3 Disktypes ###
$vhdtype = "Differencing"
#$vhdtype = "Fixed"
#$vhdtype = "Dynamic"
### configure RAM-settings ###
$maxbytes = 2GB
$minbytes = 512MB
$startbytes = 1GB

foreach ($vm in $vmlist)
{
#prepare folder
$vmpath = “$path\$vm”
New-Item -Path $vmpath -ItemType “Directory”
# create VHD
if ($vhdtype -eq „Differencing“)
 {
 New-VHD -ParentPath $templatepath -Path "$vmpath\Disk0.vhdx" -Differencing
 }
 else
 {
 if ($vhdtype -eq „Fixed“)
 {
 Convert-VHD $templatepath $vmpath\Disk0.vhd -VHDType $vhdtype
 }
 else
 {
 Copy-Item $templatepath $vmpath\Disk0.vhdx
 }
 }
if ($vhdtype -eq „Fixed“)
 {
 New-VM -VHDPath $vmpath\Disk0.vhd -Name $vm -Path $vmpath -SwitchName ext
 }
 else
 {
 New-VM -VHDPath $vmpath\Disk0.vhdx -Name $vm -Path $vmpath -SwitchName ext
 }
Set-VMMemory -VMName $vm -DynamicMemoryEnabled $True -MaximumBytes $maxbytes -MinimumBytes $minbytes -StartupBytes $startbytes
Start-VM $vm
}