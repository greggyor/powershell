﻿Function Get-FileTimeStamp {
    <#
        .SYSNOPSIS
            Retrieves the timestamps for a given file.

        .DESCRIPTION
            Retrieves the timestamps for a given file. This not only shows the LastAccess, LastWrite and Creation timestamps, 
            but also shows the ChangeTime timestamp, which is not viewable just by looking at the properties of a file.

        .PARAMETER File
            Name of the file to get timestamps from.

        .NOTES
            Name: Get-FileTimeStamp
            Author: Boe Prox
            DateCreated: 26 Feb 2013
            DateModified: 26 Feb 2013
            Version: 1.0 - Initial Creation

        .LINK
            http://learn-powershell.net

        .INPUTS
            System.String

        .OUPUTS
            None

        .EXAMPLE
            Get-FileTimeStamp -File 'SystemError.txt'
            CreationDate   : 2/13/2013 7:56:13 AM
            ChangeTime     : 2/26/2013 8:49:28 AM
            LastWriteTime  : 2/13/2013 7:56:13 AM
            LastAccessTime : 2/26/2013 8:48:00 AM
            FileName       : C:\users\Administrator\desktop\SystemError.txt


            Description
            -----------
            Displays all timestamps for the file SystemError.txt


    #>
    [cmdletbinding()]
    Param (
        [parameter(ValueFromPipeline = $True)]
        [string[]]$File = "C:\users\proxb\desktop\SystemError.txt"
    )
    Begin {
        #region Debug Information
        $PSBoundParameters.GetEnumerator() | ForEach {
            Write-Verbose ("{0}" -f $_)
        }
        Write-Verbose ("Using ParameterSetName: {0}" -f $PSCmdlet.ParameterSetName)
        #endregion Debug Information

        #region Create signature from inline C# code
        $sig = @'
        using System;
        using System.Runtime.InteropServices; // for DllImport and friends
        using Microsoft.Win32.SafeHandles; // for SafeHandle
        using System.Collections.Generic; // for ParseFileAttributes helper function (List<FileAttributes> only
        using System.IO; // for test main (FileStream) only
        using System.Text; // for test main (Encoding) only
        using System.Threading; // for test main (Thread.Sleep) only
        using System.Diagnostics; // for test main (Trace.Write[Line]) only
        public class Nt
        {

            struct IO_STATUS_BLOCK
            {
                internal uint status;
                internal ulong information;
            }
            enum FILE_INFORMATION_CLASS
            {
                FileDirectoryInformation = 1,        // 1
                FileFullDirectoryInformation,        // 2
                FileBothDirectoryInformation,        // 3
                FileBasicInformation,            // 4
                FileStandardInformation,        // 5
                FileInternalInformation,        // 6
                FileEaInformation,            // 7
                FileAccessInformation,            // 8
                FileNameInformation,            // 9
                FileRenameInformation,            // 10
                FileLinkInformation,            // 11
                FileNamesInformation,            // 12
                FileDispositionInformation,        // 13
                FilePositionInformation,        // 14
                FileFullEaInformation,            // 15
                FileModeInformation = 16,        // 16
                FileAlignmentInformation,        // 17
                FileAllInformation,            // 18
                FileAllocationInformation,        // 19
                FileEndOfFileInformation,        // 20
                FileAlternateNameInformation,        // 21
                FileStreamInformation,            // 22
                FilePipeInformation,            // 23
                FilePipeLocalInformation,        // 24
                FilePipeRemoteInformation,        // 25
                FileMailslotQueryInformation,        // 26
                FileMailslotSetInformation,        // 27
                FileCompressionInformation,        // 28
                FileObjectIdInformation,        // 29
                FileCompletionInformation,        // 30
                FileMoveClusterInformation,        // 31
                FileQuotaInformation,            // 32
                FileReparsePointInformation,        // 33
                FileNetworkOpenInformation,        // 34
                FileAttributeTagInformation,        // 35
                FileTrackingInformation,        // 36
                FileIdBothDirectoryInformation,        // 37
                FileIdFullDirectoryInformation,        // 38
                FileValidDataLengthInformation,        // 39
                FileShortNameInformation,        // 40
                FileHardLinkInformation = 46        // 46    
            }
            [StructLayout(LayoutKind.Explicit)]
            struct FILE_BASIC_INFORMATION
            {
                [FieldOffset(0)]
                internal long CreationTime;
                [FieldOffset(8)]
                internal long LastAccessTime;
                [FieldOffset(16)]
                internal long LastWriteTime;
                [FieldOffset(24)]
                internal long ChangeTime;
                [FieldOffset(32)]
                internal ulong FileAttributes;
            }
            [DllImport("ntdll.dll", SetLastError = true)]
            static extern IntPtr NtQueryInformationFile(SafeFileHandle fileHandle, ref IO_STATUS_BLOCK IoStatusBlock, IntPtr pInfoBlock, uint length, FILE_INFORMATION_CLASS fileInformation);

            public static bool GetFourFileTimes(string path2file,
                    out DateTime creationTime, out DateTime lastAccessTime, out DateTime lastWriteTime, out DateTime changeTime, out string errMsg)
            {
                bool brc = false;
                creationTime = default(DateTime);
                lastAccessTime = default(DateTime);
                lastWriteTime = default(DateTime);
                changeTime = default(DateTime);
                errMsg = string.Empty;
                IntPtr p_fbi = IntPtr.Zero;
                try
                {
                    FILE_BASIC_INFORMATION fbi = new FILE_BASIC_INFORMATION();
                    IO_STATUS_BLOCK iosb = new IO_STATUS_BLOCK();
                    using (FileStream fs = new FileStream(path2file, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        p_fbi = Marshal.AllocHGlobal(Marshal.SizeOf(fbi));                
                        IntPtr iprc = NtQueryInformationFile(fs.SafeFileHandle, ref iosb, p_fbi, (uint)Marshal.SizeOf(fbi), FILE_INFORMATION_CLASS.FileBasicInformation);
                        brc = iprc == IntPtr.Zero && iosb.status == 0;
                        if (brc)
                        {
                            brc = false;
                            fbi = (FILE_BASIC_INFORMATION)Marshal.PtrToStructure(p_fbi, typeof(FILE_BASIC_INFORMATION));
                            creationTime = DateTime.FromFileTime(fbi.CreationTime);
                            lastAccessTime = DateTime.FromFileTime(fbi.LastAccessTime);
                            lastWriteTime = DateTime.FromFileTime(fbi.LastWriteTime);
                            changeTime = DateTime.FromFileTime(fbi.ChangeTime);
                            brc = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    brc = false;
                    errMsg = ex.Message;
                }
                finally
                {
                    if (p_fbi != IntPtr.Zero) { Marshal.FreeHGlobal(p_fbi); }
                }
                return brc;
            }
        }
'@
        #endregion Create signature from inline C# code

        #region Create Win32 API object
        If (-Not $Global:NTQueryFile) {
            $Global:NTQueryFile = Add-Type -TypeDefinition $sig -PassThru
        }
        #endregion Create Win32 API object

        #region Create reference variables
        $creationTime = (Get-Date)
        $lastAccessTime = (Get-Date)
        $lastWriteTime = (Get-Date)
        $changeTime = (Get-Date)
        $errorMsg = $null
        #endregion Create reference variables
    }
    Process {
        #region Check file name
        ForEach ($item in $File) {
            If (-Not ([uri]$item).IsAbsoluteUri) {
                Write-Verbose ("{0} is not a full path, using current directory: {1}" -f $item,$pwd)
                $item = (Join-Path $pwd ($item -replace "\.\\",""))
            }
            #endregion Check file name

            #region Get file timestamps
            $return = [NT]::GetFourFileTimes($item,
                                  [ref]$creationTime,
                                  [ref]$lastAccessTime,
                                  [ref]$lastWriteTime,
                                  [ref]$changeTime,
                                  [ref]$errorMsg
                                  )
            If ($return) {
                If (-Not $errorMsg) {
                    $object = New-Object PSObject -Property @{
                        FileName = $item
                        CreationDate = $creationTime
                        LastWriteTime = $lastWriteTime
                        LastAccessTime = $lastAccessTime 
                        ChangeTime = $changeTime
                    }
                    $object.pstypenames.insert(0,'System.File.TimeStamp')
                    Write-Output $object
                } Else {
                    Write-Warning ("{0}" -f $errorMsg)
                }
            } Else {
                Write-Warning ("An issue occurred querying the timestamp!")
            }
        }
        #endregion Get file timestamps
    }
    End {}
}