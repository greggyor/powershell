##Query-EventViewerLogs
##**Parses saved Event Viewer logs based on the SQL query defined in the script body.

Begin{
	#Creating objects for Log Query
	$Parser = New-Object -COM MSUtil.LogQuery
	$InputType = New-Object -COM MSUtil.LogQuery.EventLogInputFormat
	$OutputType = New-Object -COM MSUtil.LogQuery.CSVOutputFormat
	
	#This is the directory that contains the event log files. Collects the files and builds an array.
	$LogDir = "<File_Location>"
	$Files = Get-ChildItem $LogDir
	Foreach ($File in $Files){
		$Extension = [System.IO.Path]::GetExtension($File).ToString()
		If ($Extension -eq ".evtx" -or $Extension -eq ".evt"){
			$theFile = $File.Name
			[Array]$LogFiles +=$theFile	
		}
	}
	# Gets the directory the script was executed from and creates a directory for output files.
	$OutPath = (Get-Location).Path
	If (!(Test-Path $OutPath\LogQuery)){
		New-Item -Path "$OutPath\LogQuery" -ItemType Directory -Force
	}
}
Process{
	#Builds and executes the query based on the variables defined above. Also the output path is defined.
	Foreach ($LogFile in $LogFiles){
		$Input = "$LogDir\$LogFile"
		$Output = "$OutPath\LogQuery\EventLogSearch_$LogFile.csv"
		$Query = @"
			SELECT TimeGenerated,EventID,EventType,EventTypeName,EventCategory,EventCategoryName,SourceName,Strings,ComputerName,SID,Message 
			INTO '$Output'	
			FROM '$Input' 
			WHERE TO_LOWERCASE(Message) LIKE '%applicationname%'' /* Be sure to replace this with the actual name of the application */
			ORDER BY TimeGenerated
"@
		$Parser.ExecuteBatch($Query, $InputType, $OutputType)
	}
}
End{
	#Closing parser objects
	Remove-Variable -Name Parser -Force
	Remove-Variable -Name InputType -Force
	Remove-Variable -Name OutputType -Force
}