﻿Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue

function Get-SPWebApplicationBlockedFileExtension {
<#
.Synopsis
 This function gets the Blocked File Extensions for a SharePoint Web Application. It can also report whether a specific extension exists in the collection of Blocked File Extensions.

.Description
 This function gets the Blocked File Extensions for a SharePoint Web Application. It can also report whether a specific extension exists in the collection of Blocked File Extensions.
 This is the list of Blocked File Extensions that cannot be saved within the specified Web Application.
 This function has been verified to work with:
 ---All SharePoint 2010 and 2013 versions
 ---Will execute on Windows Server 2008, 2008 R2 and 2012

.Example
 Get-SPWebApplicationBlockedFileExtension -WebApplication http://yourwebapplication

 This example gets the BlockedFileExtensions collection for the SharePoint Web Application http://yourwebapplication

.Example
 Get-SPWebApplicationBlockedFileExtension -WebApplication http://yourwebapplication -Verbose

 This example gets the BlockedFileExtensions collection for the SharePoint Web Application http://yourwebapplication
 Verbose function execution notes will be displayed.

.Example
 Get-SPWebApplicationBlockedFileExtension -WebApplication http://yourwebapplication -Extension "html"

 This example will inform you whether or not the "html" file extension is included in the BlockedFileExtensions collection for the Web Application http://yourwebapplication
 
 Instead of the BlockedFileExtensions collection, the output will be a custom PSObject containing:
 -[string]WebApplicationName - the Web Application Name, 
 -[string]Extension a string indicating the specified by the $Extension input parameter in this case "html"
 -[bool]ExtensionBlocked - indicates whether or not the specified file extension is in the BlockedFileExtensions collection for the specified Web Application http://yourwebapplication

.Example
 Get-SPWebApplication | ForEach-Object {Get-SPWebApplicationBlockedFileExtension -WebApplication $_ -Extension "html"}

 This example will inform you whether or not the "html" file extension is included in the BlockedFileExtensions collection for all SharePoint Web Applications (excluding Central Administration)
 
 Instead of the BlockedFileExtensions collection, the output will be a custom PSObject collection containing:
 -[string]WebApplicationName - the Web Application Name, 
 -[string]Extension a string indicating the specified by the $Extension input parameter in this case "html"
 -[bool]ExtensionBlocked - indicates whether or not the specified file extension is in the BlockedFileExtensions collection for the specified Web Application http://yourwebapplication

.PARAMETER WebApplication
 Required. SPWebApplicationPipeBind. Specifies a single SharePoint Web Application.

.PARAMETER Extension
 Optional. String. Specify the file extension to determine if it exists within the specified WebApplication BlockedFileExtensions collection. If specified, the function will return a collection of custom PSObjects reporting if the file extension exists in the WebApplication BlockedFileExtensions collection. See examples for more details. This parameter is forced to lower case within the script.

.Notes
 Name: Get-SPWebApplicationBlockedFileExtension
 Author: Craig Lussier
 Last Edit: 3/3/2013

.Link
http://www.craiglussier.com
http://twitter.com/craiglussier
http://social.technet.microsoft.com/profile/craig%20lussier/

# Requires PowerShell Version 2.0 or Version 3.0
#>
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true, ValueFromPipeline=$true, Position=0)]
[Microsoft.SharePoint.PowerShell.SPWebApplicationPipeBind]$WebApplication,

[Parameter(Mandatory=$false, ValueFromPipeline=$true, Position=1)]
[string]$Extension
)

    Process {
        Write-Verbose "Entering Process Block - Get-SPWebApplicationBlockedFileType"


        try {
           Write-Verbose "Get Web Application"
           $WebApp = Get-SPWebApplication $WebApplication

           

           if($Extension) {
                Write-Verbose "--Create custom PSObject for Web Application"
                $object = New-Object PSObject -Property @{                           
                    WebApplicationName = $WebApp.DisplayName              
                    ExtensionBlocked = $null
                    Extension = $null                                               
                } 
                $ContainsBlockedExtension = $WebApp.BlockedFileExtensions -contains $Extension.ToLower().ToString()
                $object.Extension = $Extension.ToLower().ToString()
                $object.ExtensionBlocked = $ContainsBlockedExtension

                Write-Output $object | select WebApplicationName, Extension, ExtensionBlocked

           }
           Else {
                Write-Verbose "Output Blocked File Extensions to the pipeline"
                Write-Output $WebApp.BlockedFileExtensions
            }

        }
        catch {
           Write-Error "There has been an issue getting the Blocked File Extensions."
           Write-Error $_
        }
        Write-Verbose "Leaving Process Block - Get-SPWebApplicationBlockedFileType"
    }

}