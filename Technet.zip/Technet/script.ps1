#set-executionpolicy unrestricted
#create folder for each NAV service

$services = get-wmiobject -query 'select * from win32_service where pathname like "%Dynamics.Nav%"'
[string]$Folder = get-location
$Folder = $Folder + "\Results"
foreach ($S in $Services) {
	$Path = ""
	[string]$SName = $S.Name
	new-item -path $Folder -Name $S.Name -type "directory" -erroraction silentlycontinue
	$Len=$S.pathname.length
	do
	{
		$Char=$S.Pathname[$Len - 1]
		$Len--
	} until ($Char -eq '\')
	for ($Counter = 0;$Counter -ile $Len;$Counter++) {
		$Path = $Path + $S.PathName[$Counter]
	}
	$Path = $Path.replace('"','')
	get-childitem $Path | format-list | out-file "$Folder\$SName\FileList.txt"
	$Path = $Path + 'CustomSettings.config'
	copy-item "$Path" -destination "$Folder\$SName" -erroraction silentlycontinue
}
$services | format-list name, startname, pathname, status, displayname, Description, status, servicetype, started, state, startmode, systemname, __server | out-file "$Folder\Servers.txt"
 
# List of NAV Service accounts and SPNs
$UsrArray = @()
foreach ($S in $Services)
{
	$Pos = 0
	$Usr = ""
	[String]$Acct = $S.StartName
	$Len = $Acct.length
	do {
		$Char = $Acct[$Len - 1]
		$Len--
		if ($Char -eq '\'){$Pos = $Len + 1}
	} until ($Len -eq 1)
	for ($Counter = $Pos;$Counter -ile $Acct.length;$Counter++) {
		[string]$Usr = $Usr + $Acct[$Counter]
	}
	$Usr
	$UsrArray = $UsrArray + $Usr
}
$UsrArray2 = @()
for ($i = 0;$i -lt $UsrArray.count;$i++) {
	$Dup = 0
	for($j = 0;$j -lt $i;$j++) {
		if ($UsrArray[$i] -eq $UsrArray2[$j]){
			$Dup = 1
		}
	}
	if ($Dup -eq 0){
		$UsrArray2 = $UsrArray2 + $UsrArray[$i]
	}
}

$Search = new-object DirectoryServices.DirectorySearcher([ADSI]"")
foreach ($Usr in $UsrArray2){
	$Search.Filter = "(SAMAccountName=$Usr)"
	$Results = $Search.Findall()
	foreach($Result in $Results){
		$Usr2 = ""
		$Usr2 = $Result.GetDirectoryEntry()
		$FileName = $Folder + "\" +$Usr2.SamAccountName + ".txt"
		$Usr2 | format-list name, UserAccountControl,SAMAccountName, msDS-AllowedToDelegateTo, objectCategory | out-file $FileName ;$FileName = $FileName + "SPN.txt"
		setspn -l $Usr | out-file $FileName
	}
}
 
#setspn x
$FileName = $Folder + "\SetSPNX.txt"
setspn -x | out-file $FileName
 
# GEt ALL SPNs
$searcher = new-object DirectoryServices.DirectorySearcher([ADSI]"") 
$searcher.filter = "(serviceprincipalname=*)" 
$Searcher.PageSize = 100
$Searcher.findall()
