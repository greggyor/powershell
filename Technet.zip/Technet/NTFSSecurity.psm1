﻿#region Internals
#region Invoke-Ternary
function Invoke-Ternary ([scriptblock]$decider, [scriptblock]$ifTrue, [scriptblock]$ifFalse) 
{
	if (&$decider)
	{ 
		&$ifTrue
	}
	else
	{
		&$ifFalse
	}
}
Set-Alias ?? Invoke-Ternary -Option AllScope -Description "Ternary Operator like '?' in C#"
#endregion
#endregion

#region Add-Ace
function Add-Ace 
{
<#
	.SYNOPSIS
		Add permission to the ACL of a file or folder. 
		
	.DESCRIPTION
		The function adds an ACE to the items ACL. The cmdlet needs to have the following information for that:
		- Path
		- Account (SamAccountName or SID)
		- AccessRights (Read, Change, FullControl, etc., ...)
		- AccessType (Allow or Deny)
		- InheritanceFlags (ObjectInherit or ContainerInherit) or -NoInheritance
		
		All the options are explained in the paramter section.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.FileSystemAccessRule2
    	Add-Ace returns objects that represent the item's Access Control Entries.
		Add-Ace returns an object that shows the item's permissions only if the parameter PassThru is used. Without PassThrhu the function has no output

	.PARAMETER Path
		Specifies the path to a resource. Get-Ace gets the permissions on the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-Ace with Get-ChilfItem or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
		
	.PARAMETER Account
		Takes the account that is will be the new owner. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'.
	
	.PARAMETER AccessRights
		The right the account shall get. This parameter is of the type System.Security.AccessControl.FileSystemRights so the following values are valid:
		ListDirectory, ReadData, WriteData, CreateFiles, CreateDirectories, AppendData, ReadExtendedAttributes, WriteExtendedAttributes, Traverse, ExecuteFile,DeleteSubdirectoriesAndFiles, ReadAttributes, WriteAttributes, Write, Delete, ReadPermissions, Read, ReadAndExecute, Modify, ChangePermissions, TakeOwnership, Synchronize, FullControl
		
	.PARAMETER AccessType
		The type of access you want to give, either Allow or Deny (System.Security.AccessControl.AccessControlType)
		
	.PARAMETER NoInheritance
		When used the access granted or denied only applied to the current item. It will not be inherited.
		
	.PARAMETER InheritanceFlags
		Defines what child items are going to inherit the permissions. If not defined, permissions will be inherited by files and folders (ContainerInherit | ObjectInherit)
		
		There are three options:
		- None
			The permission will not be inherited by any child item
		- ContainerInherit
			The permission will be inherited only by Containers
		- ObjectInherit
		
	.PARAMETER PassThru
		Returns FileSystemAccessRule2 item's ACE. By default, this cmdlet does not generate any output.

	.EXAMPLE
		PS C:\> dir | Add-Ace -Account forest3\test -AccessRights Read -PassThru

			Path: C:\data\Test (Inheritance enabled)

		Identity                       Rights		Inheritance          Type	IsInherited
		--------                       ------       -----------          ----	-----------
		raandree1\Test (S-1-5-21-30... FullControl  ContainerInherit,... Allow	False

		Description
		-----------
		Add read permissions to the test user account. Per default the inheritance is set to files and folders.
		
	.EXAMPLE
		PS C:\data> dir | Add-Ace -Account raandree1\test -AccessRights Read -NoInheritance -PassThru

			Path: C:\data\Test (Inheritance enabled)

		Identity                       Rights				Inheritance   Type	IsInherited
		--------                       ------               -----------   ----	-----------
		raandree1\Test (S-1-5-21-30... Read, Synchronize    None          Allow	False

			Path: C:\data\File1.txt (Inheritance enabled)

		Identity                       Rights               Inheritance	  Type	IsInherited
		--------                       ------               -----------   ----	-----------
		raandree1\Test (S-1-5-21-30... Read, Synchronize    None          Allow False

		Description
		-----------
		Adds read access to the test account to all items 'dir' returns without inheriting the access to files or folder below.
#>
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="SimpleInheritance")]
	
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("FileSystemRights")]
		[System.Security.AccessControl.FileSystemRights] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="SimpleInheritance")]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.InheritanceFlags] $InheritanceFlags,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.PropagationFlags] $PropagationFlags = [System.Security.AccessControl.PropagationFlags]::None,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin { }
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$ir = New-Object System.Security.Principal.SecurityIdentifier($Account.Sid)
			switch ($pscmdlet.ParameterSetName)
			{
				"SimpleInheritance"
				{
					if ($item -is [System.IO.FileInfo])
					{
						$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir, $AccessRights, $AccessType)
					}
					elseif ($item -is [System.IO.DirectoryInfo])
					{				
						$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir,
							$AccessRights,
							(?? {$NoInheritance} { [Security.AccessControl.InheritanceFlags]::None } {[Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit}),
							[Security.AccessControl.PropagationFlags]::None,
							$AccessType)
					}
				}
				"ComplexInheritance"
				{
					$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir,
						$AccessRights,
						$InheritanceFlags,
						$PropagationFlags,
						$AccessType)
				}
			}
			
			try
			{
				$sd.AddAccessRule($ace)
				$item.SetAccessControl($sd)
			}
			catch [Exception]
			{
				Write-Error -Message "Error adding ACE to item: $($_.Exception.Message)" -Exception $_.Exception
			}
			Write-Verbose "ACE for user $Account added to ACL of $($item.FullName)"
			
			if ($PassThru)
			{
				$item | Get-Ace -ExcludeInherited
			}
		}
	}
	
	end { }
}
#endregion

#region Remove-Ace
<#
	.SYNOPSIS
		Removes permission of the ACL of a file or folder. 
		
	.DESCRIPTION
		The function adds an ACE to the items ACL. The cmdlet needs to have the following information for that:
		- Path
		- Account (SamAccountName or SID)
		- AccessRights (Read, Change, FullControl, etc., ...)
		- AccessType (Allow or Deny)
		
		All the options are explained in the paramter section.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.FileSystemAccessRule2
    	Remove-Ace returns objects that represent the item's Access Control Entries.
		Remove-Ace returns an object that shows the item's permissions only if the parameter PassThru is used. Without PassThrhu the function has no output

	.PARAMETER Path
		Specifies the path to a resource. Get-Ace gets the permissions on the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-Ace with Get-ChilfItem or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
		
	.PARAMETER Account
		Takes the account that is will be the new owner. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'.
	
	.PARAMETER AccessRights
		The right the account shall get. This parameter is of the type System.Security.AccessControl.FileSystemRights so the following values are valid:
		ListDirectory, ReadData, WriteData, CreateFiles, CreateDirectories, AppendData, ReadExtendedAttributes, WriteExtendedAttributes, Traverse, ExecuteFile,DeleteSubdirectoriesAndFiles, ReadAttributes, WriteAttributes, Write, Delete, ReadPermissions, Read, ReadAndExecute, Modify, ChangePermissions, TakeOwnership, Synchronize, FullControl
		
	.PARAMETER AccessType
		The type of access you want to give, either Allow or Deny (System.Security.AccessControl.AccessControlType)
		
	.PARAMETER NoInheritance
		When used the access granted or denied only applied to the current item. It will not be inherited.
	
	.PARAMETER PassThru
		Returns FileSystemAccessRule2 item's ACE. By default, this cmdlet does not generate any output.

	.EXAMPLE
		PS C:\> dir | Remove-Ace -Account BUILTIN\Users -PassThru

    		Path: D:\Tools\zoomit.exe (Inheritance disabled)

		Identity                       Rights            Inheritance       Type              IsInherited     
		--------                       ------            -----------       ----              -----------     
		NT AUTHORITY\Authenticated ... Modify, Synchr... None              Allow             False           
		NT AUTHORITY\SYSTEM (S-1-5-18) FullControl       None              Allow             False           
		BUILTIN\Administrators (S-1... FullControl       None              Allow             False     

		Description
		-----------
		Removes all permissions of all files returned by 'dir' for the group BUILTIN\Users.
		
	.EXAMPLE
		PS C:\data> dir | Get-Ace -ExcludeInherited | Remove-Ace

		Description
		-----------
		Removes all explicitly assigned permissions of all files returned by 'dir'. This might be useful after enabling inheritance and you want to do a cleanup.
#>
#dir | Get-Ace -ExcludeInherited | Remove-Ace
function Remove-Ace
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("FileSystemRights")]
		[Security2.FileSystemRights2] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin { }
	
	process
	{
		$acesToRemove = $null
		
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$acl = $sd.GetAccessRules($true, $false, [System.Security.Principal.NTAccount])
			
			$acesToRemove = @($acl | Where-Object { $_.IdentityReference -eq $Account })
			
			foreach ($ace in $acesToRemove)
			{
				try
				{
					if (($ace.FileSystemRights -eq $AccessRights) -or (-not $AccessRights))
					{
						$sd.RemoveAccessRule($ace) | Out-Null
					}
					else
					{
						if ([int]$ace.FileSystemRights -lt [int]$AccessRights)
						{
							continue
						}
						[Void]$sd.RemoveAccessRule($ace)
						#Create new access rule if only a portion of an existing ACE should have been removed
						$newAccessRight = [int]$ace.FileSystemRights -bxor [int]$AccessRights
						if ($newAccessRight)
						{
							$ace = New-Object System.Security.AccessControl.FileSystemAccessRule($ace.IdentityReference,
								([int]$ace.FileSystemRights -bxor [int]$AccessRights),
								$ace.InheritanceFlags,
								$ace.PropagationFlags,
								$ace.AccessControlType)
							$sd.AddAccessRule($ace)
						}
					}
					$item.SetAccessControl($sd)
					Write-Verbose "$($acesToRemove.Count) ACE(s) removed from item $($item.Name)"
				}
				catch [Exception]
				{
					Write-Error -Message "Error removing ACE(s) from item: $($_.Exception.Message)" -Exception $_.Exception
				}
			}
			
			if ($PassThru)
			{
				$item | Get-Ace -ExcludeInherited
			}
		}
	}
	
	end { }
}
#endregion RemoveAccess

#region Get-Ace
function Get-Ace
{
<#
	.SYNOPSIS
		Gets all Access Control Entries in the item's Discretionary Access Control List.
		
	.DESCRIPTION
		The function returns all ACEs defined on the item. You can filter the ACEs using the switches ExcludeExplicit and ExcludeInherited.
		
		Whether the item inherits the permissions from its parant is indicated in the output as well.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.FileSystemAccessRule2
    	Get-Ace returns objects that represent the item's Access Control Entries.

	.PARAMETER Path
		Specifies the path to a resource. Get-Ace gets the permissions on the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-Ace with Get-ChilfItem or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
		
	.PARAMETER ExcludeExplicit
		If set, only inherited ACEs are returned.
	
	.PARAMETER ExcludeInherited
		If set, only explicitly non-inherited ACEs are returned.
			
	.EXAMPLE
		PS C:\> Get-Item c:\ | Get-Ace

		    Path: C:\ (Inheritance disabled)

		Identity                       Rights         Inheritance    Type           IsInherited
		--------                       ------         -----------    ----           -----------
		NT AUTHORITY\Authenticated ... AppendData     None           Allow          False
		NT AUTHORITY\Authenticated ... -536805376     ContainerIn... Allow          False
		NT AUTHORITY\SYSTEM (S-1-5-18) FullControl    None           Allow          False
		NT AUTHORITY\SYSTEM (S-1-5-18) 268435456      ContainerIn... Allow          False
		BUILTIN\Administrators (S-1... 268435456      ContainerIn... Allow          False
		BUILTIN\Administrators (S-1... FullControl    None           Allow          False
		BUILTIN\Users (S-1-5-32-545)   ReadAndExec... ContainerIn... Allow          False

		Description
		-----------
		Get all ACEs defined on the root of drive C:
		
	.EXAMPLE
		PS C:\> dir | Where-Object { $_.PSIsContainer } | Get-Ace -ExcludeInherited

		Description
		-----------
		This command returns only explicitly set ACEs on all folders.
		
	.EXAMPLE
		PS C:\> dir | Get-Ace | Where-Object { $_.ID -eq "BUILTIN\Users" }

		Description
		-----------
		This command returns only explicitly set ACEs on all folders.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
	
	begin { }
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
				{
					$ace = [Security2.FileSystemAccessRule2]$ace
					$ace.FullName = $item.FullName
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.FileSystemAccessRule2]$ace
				}
		}
	}
	
	end { }
}
#endregion

#region Get-OrphanedAce
function Get-OrphanedAce
<#
	.SYNOPSIS
		Does almost the same like Get-Ace but returns only ACE that do no longer to existing accounts.
		
	.DESCRIPTION
		Please see the help for Get-Ace, that explains how this function works. Get-OrphanedAce returns only ACEs whose accounts can not be resolved.
		
		When you delete a local account or an account in Active Directory the permissions on the file service are not cleaned up automatically. To retreive all orphaned ACEs, use this cmdlet.
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.FileSystemAccessRule2
    	Get-OrphanedAce returns objects that represent the item's Access Control Entries.

	.PARAMETER Path
		Specifies the path to a resource. Get-OrphanedAce gets the orphaned permissions on the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-OrphanedAce with Get-ChilfItem or Get-Item is the easiest way if you want to get the orphaned permissions of multiple files and folders.
		
	.PARAMETER ExcludeExplicit
		If set, only inherited orphaned ACEs are returned.
	
	.PARAMETER ExcludeInherited
		If set, only explicitly orphaned non-inherited ACEs are returned.
			
	.EXAMPLE
		PS C:\> Get-Item .\Test | Get-OrphanedAce

    		Path: C:\Test (Inheritance enabled)

		Identity                                     Rights      Inheritance                     Type  IsInherited
		--------                                     ------      -----------                     ----  -----------
		S-1-5-21-3004578928-807432287-770619659-2645 FullControl ContainerInherit, ObjectInherit Allow False
		S-1-5-21-3004578928-807432287-770619659-5489 FullControl ContainerInherit, ObjectInherit Allow False

		Description
		-----------
		Get all ACEs defined on the root of drive C:
		
	.EXAMPLE
		PS C:\> dir | Get-OrphanedAce -ExcludeInherited | Remove-Ace

		Description
		-----------
		This command line removes all orphaned ACEs of all files and folders in the current directory.
		
		BE CAREFUL WITH THIS: If the communication to the domain controller isn't working for some reason, also existing accounts might be considered as orphaned, as the system may not be able to resolve the SIDs.
		
		To make sure an account is really orphaned, try to get the orphaned SIDs two or three times. If the account is considered orphaned all three times it might be safe to remove the permissions.
		
	.EXAMPLE
		PS C:\> dir -Recurse | Get-OrphanedAce | Select-Object -Property ID -Unique
		
		ID
		--
		S-1-5-21-3004578928-807432287-770619659-2645
		S-1-5-21-3004578928-807432287-770619659-5489
		S-1-5-21-3004578928-807432287-770619659-5490

		Description
		-----------
		This returns a list of all unique orphaned SIDs found recursively.
#>
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
		
	begin { }
	
	process
	{
		[bool] $hasOrphanedSIDs = $false
		$orphanedSidCount = 0
		
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
		
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
			{
				$ace = [Security2.FileSystemAccessRule2]$ace
				
				if (-not $ace.IdentityReference.AccountName)
				{
					$ace.FullName = $item.FullName
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.FileSystemAccessRule2]$ace
					
					$hasOrphanedSIDs = $true
					$orphanedSidCount++
				}
			}
	
			
			
			if ($hasOrphanedSIDs)
			{
				Write-Verbose ("Item {0} knows about {1} orphaned SIDs in its ACL" -f $item.FullName, $orphanedSidCount)
			}
		}
	}
}
#endregion Get-OrphanedAce

#region Get-Owner
function Get-Owner
{
<#
	.SYNOPSIS
		Gets the owner for a file or folder.
		
	.DESCRIPTION
		The function gets the owner for a file or filder.
		
		All the function needs to know is the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.ItemOwner
    	Get-Owner returns an object that represents the item's ownership.

	.PARAMETER Path
		Specifies the path to a resource. Get-Owner gets the ownership of the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
			
	.EXAMPLE
		PS C:\Users> dir | Get-Owner

		Item                                                     Account
		----                                                     -------
		C:\Users\Public                                          BUILTIN\Administrators (S-1-5-32-544)
		C:\Users\raandree                                        NT AUTHORITY\SYSTEM (S-1-5-18)

		Description
		-----------
		This command gets the owner of all items in C:\Users
		
	.EXAMPLE
		PS F:\> dir | Get-Owner | Where-Object { "S-1-1-0" -eq $_.Account.SID }

		Item                                                     Account
		----                                                     -------
		F:\Tools                                                 Everyone (S-1-1-0)
		F:\lib1.ps1                                              Everyone (S-1-1-0)
		
		Description
		-----------
		This command returns all items whose owner is the Everyone group.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$owner = New-Object Security2.FileSystemOwner
			$owner.Item = $item
			$owner.Account = $item.Owner
			Write-Output $owner
		}
	}
	
	end { }
}
#endregion Get-Owner

#region Set-Owner
function Set-Owner
{
<#
	.SYNOPSIS
		Sets the owner for a certain account on a file or folder.
		
	.DESCRIPTION
		The function sets the given owner on a file or folder to. This task requires the Restore and TakeOwnership privilege. If you do not have these privileges the script will not start.
		
		All the function needs to know is the file or folder path and the account (Domain\Username) to set as the new owner. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
		
		As the Restore and TakeOwnership privilege is needed you may want to use the function in an elevated PowerShell.
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.ItemOwner
    	Set-Owner returns an object that represents the item's ownership only if the parameter PassThru is used. Without PassThrhu the function has no output

	.PARAMETER Path
		Specifies the path to a resource. Set-Owner sets the owner of the item indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER Account
		Takes the account that is will be the new owner. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'.
	
	.PARAMETER PassThru
		Returns a ItemOwner object for each item worked on. By default, this cmdlet does not generate any output.
		
	.EXAMPLE
		PS C:\> Get-Item F:\Tools | Set-Owner -Account 'NT Authority\Everyone' -PassThru

		Item                                                     Account
		----                                                     -------
		F:\Tools                                                 Everyone (S-1-1-0)

		Description
		-----------
		This command sets the owner of the tools folder to Everyone and shows the result.
		
	.EXAMPLE
		PS C:\Users> dir | Where-Object { $_.PSIsContainer } | ForEach-Object { Set-Owner -Path $_.FullName -Account "C1\$($_.Name)" -PassThru }

		Item                                         Account
		----                                         -------
		C:\Users\administrator                       C1\Administrator (S-1-5-21-3872441409-162...		
		C:\Users\dev                                 C1\Dev (S-1-5-21-3872441409-1623757310-16...
		C:\Users\devadmin                            C1\DevAdmin (S-1-5-21-3872441409-16237573...
		C:\Users\t1                                  C1\t1 (S-1-5-21-3872441409-1623757310-164...
		C:\Users\t11                                 C1\t11 (S-1-5-21-3872441409-1623757310-16...		
		
		Description
		-----------
		This command sets the owners for all items in the current directory. The directory name is taken as the respective account name. This can be useful to correct the ownership on terminal service profiles.
	.EXAMPLE
		PS C:\Tools> dir | Disable-Inheritance
		PS C:\Tools> dir | Set-Owner -Account raandree3\raandree
		PS C:\Tools> dir | Add-Ace -Account raandree3\raandree -AccessRights FullControl
		
		Description
		-----------
		This sequence of commands removes the inheritance of all items dir return. If you are not the owner of the files and there are no explicitly assigned permissions, than noting works anymore and also the explorer cannot show the ACE anmore.
		
		To solve the issue, we first have to take ownership of the elements and then we can give someone our ourselves permissions to the objects.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | Select-Object -ExpandProperty Privilege
		if ($privileges -notcontains "TakeOwnership" -or $privileges -notcontains "Restore")
		{
			throw New-Object System.Exception("The TakeOwnership or Restore privilege is not available. The ownership cannot be set without this privilege")
			return
		}
		else
		{
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership) | Out-Null
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Restore) | Out-Null
		}
	}
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}

			try
			{
				$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Owner)
			}
			catch
			{
				if ($item -is [System.IO.FileInfo])
				{
					$sd = New-Object System.Security.AccessControl.FileSecurity
				}
				else
				{
					$sd = New-Object System.Security.AccessControl.DirectorySecurity
				}
			}
			$sd.SetOwner($Account)
			
			$item.SetAccessControl($sd)
			
			if ($PassThru)
			{
				$item | Get-Owner
			}
		}
	}
	
	end
	{
		$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership) | Out-Null
		$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Restore) | Out-Null
	}
}
#endregion Set-Owner

#region Get-Inheritance
function Get-Inheritance
{
<#
	.SYNOPSIS
		Gets the inheritance information.
		
	.DESCRIPTION
		Gets the inheritance information and returns an object that contains just the file and a boolean value indicating whether the item inherits the permission from its parent.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.ItemInheritanceInfo
    	Get-Owner returns an object that represents the item's inheritance setting.

	.PARAMETER Path
		Specifies the path to a resource. Get-Owner gets the ownership of the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
			
	.EXAMPLE
		PS C:\> dir | Get-Inheritance
		WARNING: This module already adds the property 'IsInheritanceBlocked' to the file system items. This infomation is displayed by default in the column 'Inherits' and can be used for filtering or sorting.

		Name                InheritanceEnabled
		----                ------------------
		PerfLogs            True
		Program Files       False
		Program Files (x86) False
		Users               False
		Windows             False
		.rnd                True

		Description
		-----------
		This command gets the inheritance setting for all items in C:\.
		
		The same information get be get through the Get-ChildItem cmdlet. The module adds some properties to files and folders and also one that tells if the inheritance is enabled or blocked:
		
		PS C:\> dir

		    Directory: C:\

		Mode    Inherits             LastWriteTime    Size(M) Name
		----    --------             -------------    ------- ----
		d----       True      14.07.2009     05:20            PerfLogs
		d-r--      False      19.03.2011     01:18            Program Files
		d-r--      False      19.03.2011     13:59            Program Files (x86)
		d-r--      False      18.03.2011     23:40            Users
		d----      False      19.03.2011     11:23            Windows
		-a---       True      19.03.2011     01:26          0 .rnd
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path
	)
	
	begin
	{
		Write-Verbose "This module already adds the property 'IsInheritanceBlocked' to the file system items. This infomation is displayed by default in the column 'Inherits' and can be used for filtering or sorting."
	}
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$ii = New-Object Security2.FileSystemInheritanceInfo
			$ii.Item = $item
			$ii.InheritanceEnabled = !$item.IsInheritanceBlocked
			Write-Output $ii
		}
	}
	
	end { }
}
#endregion Get-Inheritance

#region Enable-Inheritance
function Enable-Inheritance
{
<#
	.SYNOPSIS
		Enables the security inheritance on the item.
		
	.DESCRIPTION
		The command enables the inheritance on the specified item.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.ItemInheritanceInfo
    	Enable-Inheritance returns an object that represents the item's inheritance setting only if the parameter PassThru is used. Without PassThrhu the function has no output.

	.PARAMETER Path
		Specifies the path to a resource. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining this function with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER RemoveInheritedPermissions
		If defined the permissions that were inherited by the item previously are removed, otherwise the permissions are copied to the item. The same choice must be done when disabling inheritance using the UI.
		
	.EXAMPLE
		PS F:\Data> dir | Where-Object { $_.PSIsContainer } | Enable-Inheritance -PassThru

		Name       InheritanceEnabled
		----       ------------------
		Project_01 True
		Project_02 True
		Project_03 True
		Project_04 True
		Project_05 True

		Description
		-----------
		This command enables the inheritance on all folders in the current container. PassThru returns the inheritance info afterwards
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$sd.SetAccessRuleProtection($false, $false)
			$item.SetAccessControl($sd)
			
			if ($PassThru)
			{
				$item | Get-Inheritance
			}
		}
	}
	
	end { }
}
#endregion Enable-Inheritance

#region Disable-Inheritance
function Disable-Inheritance
{
<#
	.SYNOPSIS
		Disabled the security inheritance on the item.
		
	.DESCRIPTION
		The command disables or blocks the inheritance on the specified item. The already inherited permissions can be copied or removed from the item using the parameter RemoveInheritedPermissions. 
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.ItemInheritanceInfo
    	Disable-Inheritance returns an object that represents the item's inheritance setting only if the parameter PassThru is used. Without PassThrhu the function has no output.

	.PARAMETER Path
		Specifies the path to a resource. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining combining this function with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER RemoveInheritedPermissions
		If defined the permissions that are inherited by the item are removed, otherwise the permissions are copied to the item. The same choice must be done when disabling inheritance using the Explorer UI.
		
	.EXAMPLE
		PS F:\Data> dir | Where-Object { $_.PSIsContainer } | Disable-Inheritance -PassThru

		Name       InheritanceEnabled
		----       ------------------
		Project_01 False
		Project_02 False
		Project_03 False
		Project_04 False
		Project_05 False

		Description
		-----------
		This command disables the inheritance on all folders in the current container. PassThru returns the inheritance info afterwards
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[switch] $RemoveInheritedPermissions,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$acl = $sd.GetAccessRules($false, $true, [System.Security.Principal.NTAccount])
			$sd.SetAccessRuleProtection($true, !$RemoveInheritedPermissions)
			$item.SetAccessControl($sd)
			
			if ($PassThru)
			{
				$item | Get-Inheritance
			}
		}
	}
	
	end { }
}
#endregion Disable-Inheritance

#region Get-EffectivePermissions
function Get-EffectivePermissions
{
<#
	.SYNOPSIS
		Gets the effective permissions for a certain account on a file or folder.
		
	.DESCRIPTION
		The function uses the Win32 function GetEffectiveRightsFromAcl to get the effective rights for a certain account from an DACL. It requires a path and an account to read the effective rights. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
		
		If you do not have access to a certain item, the security privilege is used to read the security descriptor. If the security priviledge is not held, a warning is displayed and also an error for each item that your do not have access to.
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.EffectivePermissionEntry
    	Get-EffectivePermissions returns an object that represents the effective permissions.

	.PARAMETER Path
		Specifies the path to a resource. Get-EffectivePermissions gets the effective permissions of the resource indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER Account
		Takes the account to get the effective rights for. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'. If not specified the effective permission the current account has are reported.

	.EXAMPLE
		PS C:\> dir | Get-EffectivePermissions

		Name                Access                 AccessMask Account
		----                ------                 ---------- -------
		PerfLogs            {FullControl}          2032127    Client1\Test
		Program Files       {Modify,  Synchronize} 1245631    Client1\Test
		Program Files (x86) {Modify,  Synchronize} 1245631    Client1\Test
		Users               {FullControl}          2032127    Client1\Test
		Windows             {Modify,  Synchronize} 1245631    Client1\Test
		.rnd                {FullControl}          2032127    Client1\Test
		
		Description
		-----------
		This command gets the effective rights of the account Client1\Test of all items in the C:\ directory.
		
	.EXAMPLE
		PS C:\> dir c:\ | Get-EffectivePermissions -Account Client1\Test

		Name                Access                         AccessMask Account
		----                ------                         ---------- -------
		PerfLogs            {None}                         0          Client1\Test
		Program Files       {ReadAndExecute,  Synchronize} 1179817    Client1\Test
		Program Files (x86) {ReadAndExecute,  Synchronize} 1179817    Client1\Test
		Users               {ReadAndExecute,  Synchronize} 1179817    Client1\Test
		Windows             {ReadAndExecute,  Synchronize} 1179817    Client1\Test
		
		Description
		-----------
		This command gets the effective rights of the account Client1\Test of all items in the C:\ directory.
		
	.EXAMPLE
		PS C:\> dir d:\ -Recurse | Where-Object { $_.PSIsContainer } | Get-EffectivePermissions -Account Client1\Test | Where-Object { $_.AccessAsString.Contains("FullControl") }

		Name                                    Access        AccessMask Account
		----                                    ------        ---------- -------
		AD                                      {FullControl} 2032127    Client1\Test
		AD Group Scripts                        {FullControl} 2032127    Client1\Test
		Dependency Walker                       {FullControl} 2032127    Client1\Test
		Kerberos Tools                          {FullControl} 2032127    Client1\Test
		Netscape Tools                          {FullControl} 2032127    Client1\Test
		WCAT                                    {FullControl} 2032127    Client1\Test

		Description
		-----------
		This command retreives all folders the user Client1\Test has full control to.
	
	.EXAMPLE
		PS C:\> $accounts = Get-ADUser -SearchBase 'OU=Work,DC=c1,DC=f3,DC=net' -Filter *
		PS C:\> dir C:\Users | ForEach-Object { $item = $_; $accounts | ForEach-Object { $item | Get-EffectivePermissions -Account $_.SID } }

		Name                 Access                         AccessMask Account
		----                 ------                         ---------- -------
		administrator        {ReadAndExecute,  Synchronize} 1179817    C1\Test
		administrator        {None}	                    	2032127    C1\Dev
		administrator        {FullControl}                  2032127    C1\DevAdmin
		dev                  {None}                         0          C1\Test
		dev                  {FullControl}                  2032127    C1\Dev
		dev                  {FullControl}                  2032127    C1\DevAdmin
		devadmin             {None}                         0          C1\Test
		devadmin             {None}	                    	2032127    C1\Dev
		devadmin             {FullControl}                  2032127    C1\DevAdmin
		Public               {None}                         0          C1\Test
		Public               {None}	                    	2032127    C1\Dev
		Public               {FullControl}                  2032127    C1\DevAdmin
		Test                 {FullControl}                  2032127    C1\Test
		Test                 {FullControl}                  2032127    C1\Dev
		Test                 {FullControl}                  2032127    C1\DevAdmin
		
		Description
		-----------
		This command retreives the effective rights for all profiles in C:\Users for all users in the OU 'OU=Work'.
	
	.EXAMPLE
		PS C:\Users\raandree\Desktop> dir d:\ -Recurse | Get-EffectivePermissions -Account 'NT Authority\Everyone' | Where-Object { -not $_.AccessAsString.Contains("None") }

		Name         Access                         AccessMask Account
		----         ------                         ---------- -------
		New-MAML.ps1 {ReadAndExecute,  Synchronize} 1179817    NT Authority\Everyone
		
		Description
		-----------
		This command shows all items in d:\ the Everyone group has any access to.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("FullName")]
		[string[]] $Path,
		[Parameter(Position=1)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account
	)
	
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | Select-Object -ExpandProperty Privilege
		if ($privileges -notcontains "Security")
		{
			Write-Warning "The Security privilege is not available. This privilege might be required to show effective permissions on certain items."
		}
		else
		{
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Security) | Out-Null
		}
	}
	
	process
	{
		foreach ($p in $Path)
		{
			if (!$Account)
			{	
				$Account = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
			}
			
			if ([System.IO.File]::Exists($p))
			{
				$item = New-Object System.IO.FileInfo($p)
			}
			elseif ([System.IO.Directory]::Exists($p))
			{
				$item = New-Object System.IO.DirectoryInfo($p)
			}
			else
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$accessMask = 0

			try
			{
				$accessMask = [Security2.EffectivePermissions]::GetEffectivePermissions($item.GetAccessControl(),
					$Account,
					$item.PSIsContainer)
				
				New-Object Security2.FileSystemEffectivePermissionEntry($Account, $accessMask, $item.FullName)
			}
			catch
			{
				Write-Error "Error reading effective permissions."
			}
		}
	}
	
	end
	{
		if ($privileges -contains "Security")
		{
			$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Security) | Out-Null
		}
	}
}
#endregion Get-EffectivePermissions