﻿#=============================================================================#
#                                                                             #
# Start-MaintenanceMode.ps1                                                   #
# Powershell Script to put a SCOM agent into maintenance mode from the RMS.   #
# If the server is a member of a cluster, it will put the rest of the         #
# cluster into maintenance mode as well.                                      #
# Modified by: Nick Fields													  #
# Original Author: Jeremy Engel                                               #
# Last Modified: 20.2.2012                                                    #
# Version: 1.2.1                                                              #
#                                                                             #
#=============================================================================#

#Get alertid parameter  
Param($alertid)  
$alertID = $alertid.toString()
$RootMS = "RMSSERVERNAME"
$Minutes = 20

#Hashtable for reason codes
$Specialcodes = @{"Application: Installation (Planned)"="ApplicationInstallation";
				"Loss of network connectivity (Unplanned)"="LossOfNetworkConnectivity";
				"Operating System: Recovery (Planned)"="UnplannedOther";
				"Application: Maintenance (unplanned)"="UnplannedOther";
				"No title for this reason could be found"="PlannedOther";
				"Other (Planned)"="PlannedOther";
				"Hardware: Maintenance (Planned)"="PlannedHardwareMaintenance";
				"Hardware: Installation (Planned)"="PlannedHardwareInstallation";
				"Operating System: Reconfiguration (Planned)"="PlannedOperatingSystemReconfiguration";
				"Application: Maintenance (Planned)"="PlannedApplicationMaintenance";
				"Hardware: Maintenance (unplanned)"="UnplannedHardwareMaintenance";
				"Hardware: Installation (unplanned)"="UnplannedHardwareInstallation";
				"Operating System: Reconfiguration (unplanned)"="UnplannedOperatingSystemReconfiguration";
				"Other (unplanned)"="UnplannedOther";
				"Application: Unresponsive"="ApplicationUnresponsive";
				"Application: Unstable"="ApplicationUnstable";
				"Security Issue"="SecurityIssue";
				}

#Setting up SCOM connection
Add-PSSnapin "Microsoft.EnterpriseManagement.OperationsManager.Client" -ErrorAction SilentlyContinue
$originalPath = Get-Location
Set-Location "OperationsManagerMonitoring::"
$null = New-ManagementGroupConnection -ConnectionString $RootMS
Set-Location $RootMS -ErrorVariable errSnapin

#Parsing alert
$alert = Get-Alert -id $alertID
$agent = Get-Agent | Where-Object { $_.DisplayName -eq $alert.MonitoringObjectDisPlayName }
$description = $alert.Description
$Server = $agent.DisplayName
$startTime = (Get-Date).ToUniversalTime()
$endTime = $startTime.AddMinutes($Minutes)
$username = $description | Select-String -pattern "(?<=of user )(.*?)(?=for)"
$reason = $description | Select-String -pattern "(?<=following reason: )(.*)"
$shutdowntype = $description | Select-String -pattern "(?<=shutdown type: )(.*)"
$comment = $description | Select-String -pattern "(?<=comment: )(.*)"

#Formatting vars for maintenance mode cmdlet
$reason1 = $reason.Matches[0].Value.ToString()
$username = $username.Matches[0].Value.ToString()
$shutdowntype = $shutdowntype.Matches[0].Value.ToString()

if ($comment.Matches[0].Value -eq $null) {
	$comment1 = "$username has initiated a $shutdowntype of $server with no comment provided"
}
else {
	$comment = $comment.Matches[0].Value.ToString()
	$comment1 = "$username has initiated a $shutdowntype of $server with the following comment: $comment"
}

if ($Specialcodes.ContainsKey($reason1)) {
	$reason1 = $Specialcodes[$reason1]
}
else {
	$reason1 = "PlannedOther"
}

#Setting maintenance mode for computer object and/or cluster components
if(($clusters = $agent.GetRemotelyManagedComputers())) {
  $clusterNodeClass = Get-MonitoringClass -Name Microsoft.Windows.Cluster.Node
  foreach($cluster in $clusters) {
    $clusterObj = Get-MonitoringClass -Name Microsoft.Windows.Cluster | Get-MonitoringObject -Criteria "Name='$($cluster.ComputerName)'"
    if($clusterObj) {
      $clusterObj.ScheduleMaintenanceMode($startTime,$endTime,$reason1,$Comment1,"Recursive")
      $nodes = $clusterObj.GetRelatedMonitoringObjects($clusterNodeClass)
      if($nodes) {
        foreach($node in $nodes) {
          Write-Host "Putting $node into maintenance mode." -ForeGroundColor Green
          }
        }
      }
    Write-Host "Putting $($cluster.Computer) into maintenance mode." -ForeGroundColor Green
    New-MaintenanceWindow -StartTime $startTime -EndTime $endTime -MonitoringObject $cluster.Computer -Reason $reason1 -Comment $comment1
    }
  }
else {
  Write-Host "Putting $Server into maintenance mode." -ForeGroundColor Green
  New-MaintenanceWindow -StartTime $startTime -EndTime $endTime -MonitoringObject $agent.HostComputer -Reason $reason1 -Comment $comment1
  }

#Sends notification email only if server did not reboot itself (i.e. Windows updates)
if ($username -ne "NT AUTHORITY\SYSTEM") {
	#Assemble email components
	$emailFrom = "SCOMSERVER@COMPANY.COM"
	$emailTo = "ITADMINS@COMPANY.COM"
	$subject = "$server has been rebooted/shutdown"
	$smtpServer = "MAILSERVER.COMPANY.COM"
	$body = "Alert Description: $description" + "`r`n" + "`r`n" +
			"The server will be placed into maintenance mode for 20 minutes based on the information provided by the shutdown event." + "`r`n" + "`r`n" +
			"Alert ID: $alertID"

	Send-MailMessage -To $emailTo -From $emailFrom -Subject $subject -Body $body -SmtpServer $smtpServer -Priority Low
	
}

Set-Location $originalPath