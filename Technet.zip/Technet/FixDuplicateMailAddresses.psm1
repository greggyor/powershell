﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

#Add System.DirectoryServices.Protocols Assembly
Add-Type -AssemblyName System.DirectoryServices.Protocols

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Export-OSCADObjectEmailAddress
{
	#.EXTERNALHELP Export-OSCADObjectEmailAddress-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[string]$EmailAddress,		
		[Parameter(Mandatory=$true,Position=2)]
		[string]$Path,
		[Parameter(Mandatory=$false,Position=3)]
		[string]$SearchBase,
		[Parameter(Mandatory=$false,Position=4)]
		[System.DirectoryServices.Protocols.SearchScope]$SearchScope="SubTree",
		[Parameter(Mandatory=$false,Position=5)]
		[System.Management.Automation.PSCredential]$Credential
	)
	Begin
	{
		$results = @()

		#Try to establish connection to target domain
		Try
		{
			if ([System.String]::IsNullOrEmpty($SearchBase)) {
                $currentDomain = New-Object System.DirectoryServices.DirectoryEntry
                $currentDomainDN = $currentDomain.distinguishedName.ToString().ToLower()
				$targetDomainFqdn = $currentDomainDN.Replace(",dc=",".").Replace("dc=","").TrimStart(".")
			} else {
				if (-not $SearchBase.ToLower().StartsWith("dc=")) {
					$firstDcIndex = $SearchBase.ToLower().IndexOf(",dc=")
					$domainDN = $SearchBase.ToLower().Substring($firstDcIndex)
				} else {
					$domainDN = $SearchBase.ToLower()
				}
				$targetDomainFqdn = $domainDN.Replace(",dc=",".").Replace("dc=","").TrimStart(".")
			}
			
			$verboseMsg = $Messages.EstablishDomainConnection
			$verboseMsg = $verboseMsg -f $targetDomainFqdn
			$pscmdlet.WriteVerbose($verboseMsg)
			
			if ($Credential -ne $null) {
				$networkCred = $Credential.GetNetworkCredential()
				$ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn, 3268)
				$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier,$networkCred)
			} else {
				$ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn, 3268)
				$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier)
			}
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
        
		#Prepare default value for SearchBase
		if ([System.String]::IsNullOrEmpty($SearchBase)) {
			$SearchBase = ""
		}
	}
	Process
	{
		#Define return attributes
		$returnAttributes = [string[]]("name","distinguishedName","mail","proxyAddresses","targetAddress","objectGUID")
		
		#Define well known exclusion patterns
		$wellKnownExclusionPatterns = @("Admini*", "CAS_{*", "DiscoverySearchMailbox*", "FederatedEmail*", "Guest*", 
										"HTTPConnector*", "krbtgt*",  "iusr_*",  "iwam*",
										"msol*", "support_*", "SystemMailbox*",  "WWIOadmini*", "*$")

		#Define LDAP search filter
		$ldapSearchFilter = "(&(|(objectCategory=user)(objectCategory=contact)(objectCategory=group))" + `
							"(|(mail=$EmailAddress)(proxyAddresses=*$EmailAddress*)(targetAddress=$EmailAddress)))"

		#Enable Paged Search
		$pagedSearch = New-Object System.DirectoryServices.Protocols.PageResultRequestControl(1000)

		#Prepare a new search request
		$ldapConnection.SessionOptions.ReferralChasing = [System.DirectoryServices.Protocols.ReferralChasingOptions]::All
		$searchRequest = New-Object System.DirectoryServices.Protocols.SearchRequest(`
						 $SearchBase,$ldapSearchFilter,$SearchScope,$returnAttributes)
		$searchRequest.Controls.Add($pagedSearch) | Out-Null

		#Send search request
		$verboseMsg = $Messages.SendSearchRequest
		$pscmdlet.WriteVerbose($verboseMsg)
		
        Try
        {
		    $searchResponse = [System.DirectoryServices.Protocols.SearchResponse]$ldapConnection.SendRequest($searchRequest)
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }
		
		if ($searchResponse.Resultcode -ne 0) {
			$errorMsg = $searchResponse.ErrorMessage
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)			
		}

		#Iterate each search response entry
		$verboseMsg = $Messages.HandleSearchResponse
		$pscmdlet.WriteVerbose($verboseMsg)		
		
		if ($searchResponse.Entries.Count -gt 1) {
			$tempResults = @()
			foreach ($searchResponseEntry in $searchResponse.Entries) {
				$objectGuid = $searchResponseEntry.Attributes.objectguid.GetValues("byte[]")
				$objectGuidBase64String = [System.Convert]::ToBase64String($objectGuid[0])				
				$name = [string]($searchResponseEntry.Attributes.name.GetValues("string"))
				$distinguishedName = [string]($searchResponseEntry.Attributes.distinguishedname.GetValues("string"))
				if ($searchResponseEntry.Attributes.Contains("mail")) {
					$mail = [string]($searchResponseEntry.Attributes.mail.GetValues("string"))
				} else {
					$mail = [System.String]::Empty
				}
				if ($searchResponseEntry.Attributes.Contains("proxyaddresses")) {
					$proxyAddresses = [string[]]($searchResponseEntry.Attributes.proxyaddresses.GetValues("string"))
                    $proxyAddresses =  "'" + $($proxyAddresses -join "' '") + "'"
				} else {
					$proxyAddresses = [System.String]::Empty
				}
				if ($searchResponseEntry.Attributes.Contains("targetaddress")) {
					$targetAddress = [string]($searchResponseEntry.Attributes.targetaddress.GetValues("string"))
				} else {
					$targetAddress = [System.String]::Empty
				}
				
				$result = New-Object System.Management.Automation.PSObject
				$result | Add-Member -MemberType NoteProperty -Name DistinguishedName -Value $distinguishedName
				$result | Add-Member -MemberType NoteProperty -Name Name -Value $name
				$result | Add-Member -MemberType NoteProperty -Name Mail -Value $mail
				$result | Add-Member -MemberType NoteProperty -Name ProxyAddresses -Value $proxyAddresses
				$result | Add-Member -MemberType NoteProperty -Name TargetAddress -Value $targetAddress
				$result | Add-Member -MemberType NoteProperty -Name ObjectGUID -Value $objectGuidBase64String
				$tempResults += $result
			}
			
			foreach ($tempResult in $tempResults) {
				$matchWellKnownPattern = $false
				foreach ($wellKnownExclusionPattern in $wellKnownExclusionPatterns) {
					if ($tempResult.Name -like $wellKnownExclusionPattern) {
						$matchWellKnownPattern = $true
						break
					}
				}
				if (-not $matchWellKnownPattern) {
					$results += $tempResult
				}
			}
		} else {
            $warningMsg = $Messages.CannotFindDuplicateObject
            $warningMsg = $warningMsg -f $EmailAddress
            $PSCmdlet.WriteWarning($warningMsg)
        }
	}
	End
	{
		#Export the result
		$infoMsg = $Messages.ExportResult
		$infoMsg = $infoMsg -f ($results | Measure-Object).Count
		$pscmdlet.WriteObject($infoMsg)
		
		Try
		{
			$results | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -NoClobber
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
	}
}

Function Import-OSCADObjectEmailAddress
{
	#.EXTERNALHELP Import-OSCADObjectEmailAddress-Help.xml

	[cmdletbinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Path,
		[Parameter(Mandatory=$false,Position=2)]
		[System.Management.Automation.PSCredential]$Credential
	)
	Begin
	{
		$validObjects = @{}
        $invalidObjectsCount = 0
        $invalidMailAddressChars= @('[','!','#','$','%','&','*','+','/','=','?','^','`','{','}',']')
        $invalidProxyAddressChars= @("'>','<',']','[','\',','")
        
        $properties = @("mail","proxyaddresses","targetaddress")

		#Import file that contains correct mail addresses for each object
		Try
		{
			$rawObjects = Import-Csv -Path $Path
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
        
        #Verify each mail address
        foreach ($rawObject in $rawObjects) {
			if ([System.String]::IsNullOrEmpty($rawObject.DistinguishedName)) {continue}
			
			$isValid = $true
			
			foreach ($property in $properties) {
				if ([System.String]::IsNullOrEmpty($rawObject.$property)) {continue}
				switch -Regex ($property)
				{
					"mail|targetaddress" {
						#Verify the length of mail and targetAddress
						if (($rawObject.$property.Length -gt 256)) {
							$warningMsg = $Messages.InvalidLength
							$warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property
							$PSCmdlet.WriteWarning($warningMsg)
                            $isValid = $false
						}

						#Verify mail and targetAddress
                        foreach ($invalidMailAddressChar in $invalidMailAddressChars) {
						    if ($rawObject.$property.Contains($invalidMailAddressChar)) {
							    $warningMsg = $Messages.InvalidAddress
							    $warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property,$rawObject.$property
							    $PSCmdlet.WriteWarning($warningMsg)
                                $isValid = $false
                                break
						    }
                        }
					}
					"proxyaddresses" {
						#Verify proxyAddress
                        $proxyAddresses = $rawObject.ProxyAddresses.Trim().Trim("'") -split "' '"
						foreach ($proxyAddress in $proxyAddresses) {
                            if ($proxyAddress -contains ":") {
                                $proxyAddressProtocol = $proxyAddress.Split(":")[0]
                                $proxyAddressBody = $proxyAddress.Split(":")[1]
                            } else {
                                break
                            }
							
							#Handle incorrect proxyAddress in the input file.
							#Invalid: "'sip:janed@corp.contoso.com SMTP:janed@corp.contoso.com'"
							#Invalid: "'sip:janed@corp.contoso.com''SMTP:janed@corp.contoso.com'"
							#Invalid: "'sip:janed@corp.contoso.comSMTP:janed@corp.contoso.com'"
							#Invalid: "' sip:janed@corp.contoso.com' 'SMTP:janed@corp.contoso.com'"
							#Invalid: "'sip: janed@corp.contoso.com' 'SMTP:janed@corp.contoso.com'"

							if ($proxyAddressProtocol -match "\s") {
								$warningMsg = $Messages.InvalidAddress
								$warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property,$proxyAddress
								$PSCmdlet.WriteWarning($warningMsg)
								$isValid = $false
								break
							}
							
							if ($proxyAddressBody -match "'|\s|sip|x500|smtp") {
								$warningMsg = $Messages.InvalidAddress
								$warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property,$proxyAddress
								$PSCmdlet.WriteWarning($warningMsg)
								$isValid = $false
								break
							}							
							
                            switch -regex ($proxyAddressProtocol) {
                                "smtp|sip" {
                                    foreach ($invalidMailAddressChar in $invalidMailAddressChars) {
						                if ($proxyAddressBody.Contains($invalidMailAddressChar)) {
							                $warningMsg = $Messages.InvalidAddress
							                $warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property,$rawObject.$property
							                $PSCmdlet.WriteWarning($warningMsg)
                                            $isValid = $false
                                            break
						                }
                                    }                                
                                }
                                Default {
                                    foreach ($invalidProxyAddressChar in $invalidProxyAddressChars) {
						                if ($proxyAddressBody.Contains($invalidProxyAddressChar)) {
							                $warningMsg = $Messages.InvalidAddress
							                $warningMsg = $warningMsg -f $rawObject.DistinguishedName,$property,$rawObject.$property
							                $PSCmdlet.WriteWarning($warningMsg)
                                            $isValid = $false
                                            break
						                }
                                    }
                                }
                            }
						}
					}
				}
            }
			
			if (-not $isValid) {
				$invalidObjectsCount++
			} else {
				$validObjects.Add($rawObject.DistinguishedName,$rawObject)
			}
        }

		#Input file should meet the requirement of mailAddress, targetAddress and proxyAddresses.
		if ($invalidObjectsCount -gt 0) {
			$warningMsg = $Messages.InvalidPropertyValue
			$warningMsg = $warningMsg -f $invalidObjectsCount
			$pscmdlet.WriteWarning($warningMsg)
		}
	}
	Process
	{
		#Iterate each object to update properties
		foreach ($validObject in $validObjects.GetEnumerator()) {
			$objectDN = $validObject.Name

            if ($PSCmdlet.ShouldProcess($objectDN)) {
			    #Get domain FQDN from distinguishedName
			    $firstDcIndex = $objectDN.ToLower().IndexOf(",dc=")
			    $domainDN = $objectDN.ToLower().Substring($firstDcIndex)
			    $targetDomainFQDN = $domainDN.ToLower().Replace(",dc=",".").TrimStart(".")

			    #Try to establish connection to target domain if necessary
			    if ($ldapConnection -ne $null) {
				    $ldapConnDirSvr = [string]($ldapConnection.Directory.Servers)
			    }

			    if (($ldapConnection -eq $null) -or ($ldapConnDirSvr -ne $targetDomainFQDN)) {
				    Try
				    {
					    if ($Credential -ne $null) {
						    $networkCred = $Credential.GetNetworkCredential()
						    $ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn)
						    $ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier,$networkCred)
					    } else {
						    $ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn)
						    $ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier)
					    }
				    }
				    Catch
				    {
					    $PSCmdlet.ThrowTerminatingError($_)
				    }
			    }

			    #Send modify request to modify mail, proxyAddresses and targetAddress
			    foreach ($property in $properties) {
				    #Send modify request to update the property
				    Try
				    {
					    if (-not [System.String]::IsNullOrEmpty($validObject.Value.$property)) {
                            Switch ($property)
                            {
                                "proxyAddresses" {
                                    $proxyAddresses = $validObject.Value.ProxyAddresses.Trim("'") -split "' '"
							        $modifyRequest = New-Object System.DirectoryServices.Protocols.ModifyRequest(`
							        $objectDN,`
							        [System.DirectoryServices.Protocols.DirectoryAttributeOperation]::Replace,
							        $property,$proxyAddresses)
                                }
                                Default {
							        $modifyRequest = New-Object System.DirectoryServices.Protocols.ModifyRequest(`
							        $objectDN,`
							        [System.DirectoryServices.Protocols.DirectoryAttributeOperation]::Replace,`
							        $property,$validObject.Value.$property.Trim())                                    
                                }
                            }
					    } else {
						    $modifyRequest = New-Object System.DirectoryServices.Protocols.ModifyRequest(`
						    $objectDN,`
						    [System.DirectoryServices.Protocols.DirectoryAttributeOperation]::Replace,`
						    $property,$null)                        
					    }
					    $requestResponse = $ldapConnection.SendRequest($modifyRequest)
				    }
				    Catch
				    {
					    $PSCmdlet.WriteError($_)
				    }
			    }
            }
		}
	}
	End	{}
}

Export-ModuleMember -Function "Export-OSCADObjectEmailAddress","Import-OSCADObjectEmailAddress"