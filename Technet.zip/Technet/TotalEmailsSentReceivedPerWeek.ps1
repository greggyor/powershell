﻿# Script:	TotalEmailsSentReceivedPerWeek.ps1
# Purpose:	Get the number of e-mails sent and received per week
# Author:	Nuno Mota
# Date:		October 2010

# From date should be a MONDAY
$From = Get-Date "06/02/2012"
$To = $From.AddDays(7)

[Int64] $intTotalSentSize = $intTotalSent = 0
[Int64] $intTotalRecSize = $intTotalRec = 0

Write-Host "From, To, # Sent, Size Sent, # Received, Size Received"

Do
{
	#Get-ExchangeServer | ? {$_.AdminDisplayVersion -match "8.3" -and $_.IsHubTransportServer -eq $True} | Get-MessageTrackingLog -ResultSize Unlimited -Start $FromSmall -End $ToSmall | ForEach {
	Get-TransportServer | Get-MessageTrackingLog -ResultSize Unlimited -Start $From -End $To | ? {$_.MessageSubject -ne "Folder Content"} | ForEach {
		# Sent E-mails
		If ($_.EventId -eq "RECEIVE" -and $_.Source -eq "STOREDRIVER")
		{
			$intTotalSentSize += $_.TotalBytes
			$intTotalSent++
		}
		
		# Received E-mails
		If ($_.EventId -eq "DELIVER")
		{
			$intTotalRecSize += $_.TotalBytes
			$intTotalRec++
		}
	}

	# Convert the size to MB and round it 
	$intTotalSentSize = [Math]::Round($intTotalSentSize/1MB, 0)
	$intTotalRecSize = [Math]::Round($intTotalRecSize/1MB, 0)

	# Create a TempTo variable as when we are searching the logs we search up to the next day, but we want to print the day before 
	$TempTo = ($To.AddDays(-1)).ToShortDateString()
	$FromSmall = $From.ToShortDateString()
	Write-Host "$FromSmall, $TempTo, $intTotalSent, $intTotalSentSize, $intTotalRec, $intTotalRecSize"

	# Reset the variables to do another search
	$From = $From.AddDays(7)
	$To = $From.AddDays(7)
	$intTotalSentSize = $intTotalSent = 0
	$intTotalRecSize = $intTotalRec = 0
}
While ($To -lt (Get-Date))