﻿
####################################

"Loaded Supporting Functions MultiSite"


####################################
Function SetV4EndpointRoutingCorp()
{

 If ($SingleNic)
    {
    "Skipping V4 Routing Single NIC"
    }
    Else
    {
        "Setting Corp2 Route"
    
        $Result = New-NetRoute –InterfaceAlias "Private Corpnet" –AddressFamily IPv4 –DestinationPrefix 10.2.0.0/24 –Nexthop 10.0.0.254
        $Result
      
        "Completed Corp2 Route"

  }
}
#####################################
Function SetV4EndpointRoutingCorp2()
{

        "Setting Corp Route"
       
        $Result = New-NetRoute –InterfaceAlias "2-Private Corpnet" –AddressFamily IPv4 –DestinationPrefix 10.0.0.0/24 –Nexthop 10.2.0.254
        $Result
     
        "Completed Corp Route"
    

}

################################################ 
#### Build AD Sites
Function BuildADSitesMultiSite()
{
    "BuildADSites Called...giving system a few minutes to boot"
    timeout /t 45
    "Trying to start adws"
    start-service adws   
    
      "Creating new site"

    ipmo activedirectory

    new-adreplicationsite $SecondaryDomain 
    new-adreplicationsubnet -name  "10.0.0.0/24"  -Site "Default-First-Site-Name" -Location $Domain -Description $Domain
    If (-not $nov6){
        new-adreplicationsubnet -name "2001:db8:DC::/48"  -Site "Default-First-Site-Name" -Location $Domain -Description $Domain
    }

    new-adreplicationsubnet -name "10.2.0.0/24"  -Site $SecondaryDomain  -Location $SecondaryDomain  -Description $SecondaryDomain 
    If (-not $nov6){
    new-adreplicationsubnet -name "2001:db8:FA::/48"  -Site $SecondaryDomain  -Location $SecondaryDomain  -Description $SecondaryDomain   
     }

    Set-ADReplicationSiteLink “DEFAULTIPSITELINK” -SitesIncluded @{Add=$SecondaryDomain,”Default-First-Site-Name”}

}



################################################ 
Function CreateCorp2GPSettings()
{ 
#Yaniv functions

  

Add-Type -AssemblyName "Microsoft.GroupPolicy.Management.Interop, Version=2.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
Add-Type -AssemblyName "Microsoft.GroupPolicy.Management, Version=2.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
 

$domain = New-Object Microsoft.GroupPolicy.GPDomain $SecondaryDomainFQDN
$som = $domain.GetSom($SecondaryDomainX500)
 = $DomainFQDN+"\Administrator"

"Attempting to give $Account permissions to $SecondaryDomainFQDN, $SecondaryDomainX500"
$user = new-object System.Security.Principal.NTAccount($Account)
$sid = $user.Translate([System.Security.Principal.SecurityIdentifier]).Value
 
$collection = $som.GetSecurityInfo()
 
$perm = New-Object Microsoft.GroupPolicy.GPPermission($sid, [Microsoft.GroupPolicy.GPPermissionType]::SomCreateWmiFilter, $false) 
$collection.Add($perm)
$perm = New-Object Microsoft.GroupPolicy.GPPermission($sid, [Microsoft.GroupPolicy.GPPermissionType]::SomLink, $false) 
$collection.Add($perm)
$perm = New-Object Microsoft.GroupPolicy.GPPermission($sid, [Microsoft.GroupPolicy.GPPermissionType]::SomCreateGpo, $false) 
$collection.Add($perm)
$som.SetSecurityInfo($collection)

}

#################################################
Function ForceRepl($Server = "DC1")
{

    $DC1FQDN = "DC1."+$DomainFQDN
    $2DC1FQDN = "2-DC1."+$SecondaryDomainFQDN
    
    "DC1 FQDN $DC1FQDN, X500: $DomainX500 "
    "2DC1 FQDN $2DC1FQDN, X500: $SecondaryDomainX500 "

    Get-Date

    Switch ($Server)
    {
    
        "DC1"
        {
               "Local Replication Option"
               "Replication Status on DC1"
            cmd.exe /c " Repadmin /replsummary >> c:\config\logs\replicationstatus.txt"
               "Replication of config on DC1"            
            cmd.exe /c " repadmin /replicate $2DC1FQDN $DC1FQDN $DomainX500 /force /full >> c:\config\logs\replicationstatus.txt"    
            cmd.exe /c " repadmin /replicate $DC1FQDN $2DC1FQDN $SecondaryDomainX500 /force /full >> c:\config\logs\replicationstatus.txt "    
               "Replication of content on DC1"
            cmd.exe /c " repadmin /syncall /kcc /e /A /P /d /q >> c:\config\logs\replicationstatus.txt"    
               "Replication Status on DC1"
            cmd.exe /c " Repadmin /replsummary >> c:\config\logs\replicationstatus.txt"
        }

        "2-DC1"
        {
               "Local Replication Option"
               "Replication Status on 2-DC1"
            cmd.exe /c " Repadmin /replsummary >> c:\config\logs\replicationstatus.txt"
                
               "Replication of config on 2-DC1"
            cmd.exe /c " repadmin /replicate $2DC1FQDN $DC1FQDN $DomainX500 /force /full >> c:\config\logs\replicationstatus.txt "    
            cmd.exe /c " repadmin /replicate $DC1FQDN $2DC1FQDN $SecondaryDomainX500 /force /full >> c:\config\logs\replicationstatus.txt "    
            Timeout /t 120
               "Replication of content on 2-DC1 "
            cmd.exe /c " repadmin /syncall /e /A /P /d /q >> c:\config\logs\replicationstatus.txt"    

               "Replication Status on 2-DC1 "
            cmd.exe /c " Repadmin /replsummary >> c:\config\logs\replicationstatus.txt"
        }

    }
    Get-Date
         
}


