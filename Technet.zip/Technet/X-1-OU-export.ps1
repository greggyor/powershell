# OU-Export - 8/12/11
# Copyright Greg Martin gmartin@gmartin.org
# License MS-LPL 
# 
# Part of the copyAD suite of Powershell scripts
# Exports a list of OUs generated with this command
# 
#Import-Module ActiveDirectory -ErrorAction SilentlyContinue  

$outcsv = 'e:\data\ADexport\OUexport.csv'

get-AdorganizationalUnit -filter * | export-csv $outcsv 