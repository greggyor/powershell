﻿Function Get-Cert
{
<# 
	.SYNOPSIS 
		Get info about certificate.
		
	.DESCRIPTION 
		Use Get-Cert to check content of certification file.

	.PARAMETER Path 
		Path to cer or pfx file with certificate data.

	.PARAMETER secureString
		The password required to access the X.509 certificate data. Can be placed as SecureString or as plain Text.

	.EXAMPLE 
		PS P:\> Get-Cert -Path P:\cert.cer | Select-Object *

		Archived           : False
		Extensions         : {System.Security.Cryptography.Oid, System.Security.Cryptography.Oid, System.Security.Cryptography.
		                     Oid}
		FriendlyName       :
		IssuerName         : System.Security.Cryptography.X509Certificates.X500DistinguishedName
		NotAfter           : 2111-04-02 10:45:10
		NotBefore          : 2011-04-26 10:45:10
		HasPrivateKey      : False
		PrivateKey         :
		PublicKey          : System.Security.Cryptography.X509Certificates.PublicKey
		RawData            : {48, 130, 2, 237...}
		SerialNumber       : 110352BA99D4C2A54B7C66FCF31C57A0
		SubjectName        : System.Security.Cryptography.X509Certificates.X500DistinguishedName
		SignatureAlgorithm : System.Security.Cryptography.Oid
		Thumbprint         : B40BEE7CDF39981C041B42FA3C8DC4C77F969192
		Version            : 3
		Handle             : 41276464
		Issuer             : CN=mg
		Subject            : CN=mg
		
	.EXAMPLE 
		PS P:\> $pass = ConvertTo-SecureString 'P@ssw0rd' -AsPlainText -Force
		PS P:\> Get-Cert -Path P:\cert.pfx -secureString $pass
		
		Thumbprint                                Subject
		----------                                -------
		B40BEE7CDF39981C041B42FA3C8DC4C77F969192  CN=mg

	.NOTES 
		Author: Michal Gajda 
#>

	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low" 
	)]	
	param(
		[parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[String]$Path,
		$secureString
	)

	Begin{}

	Process
	{
		if ($pscmdlet.ShouldProcess("$Path","Get certificate details"))
		{
			Try
			{
				Write-Verbose "Trying open cert: $Path"
				if($secureString -ne $null)
				{
					$certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($Path,$secureString)	
				}
				else
				{
					$certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($Path)
				}
			}
			Catch
			{
				Write-Warning "Can't open cert: $Path"
			}
			
			Return $certObj
		}
	}
	
	End{}
}

Function Import-Cert
{
<# 
	.SYNOPSIS 
		Import certificate.
		
	.DESCRIPTION 
		Use Import-Cert to import certificate to specific certificate store.

	.PARAMETER Path 
		Path to cer or pfx file with certificate data.

	.PARAMETER secureString
		The password required to access the X.509 certificate data. Can be placed as SecureString or as plain Text.

	.PARAMETER storeName 
		One of the enumeration values that specifies the name of the X.509 certificate store. 

	.PARAMETER storeLocation
		One of the enumeration values that specifies the location of the X.509 certificate store.
		
	.EXAMPLE 
		PS P:\> Import-Cert -Path P:\cert.cer -storeName "Root" -storeLocation "LocalMachine" -Verbose

		VERBOSE: Performing operation "Import certificate P:\cert.cer" on Target "Root in location LocalMachine".
		VERBOSE: Trying open cert: P:\cert.cer
		VERBOSE: Trying open store Root in location LocalMachine
		VERBOSE: Trying add cert CN=mg to store Root in location LocalMachine

		    Directory: Microsoft.PowerShell.Security\Certificate::LocalMachine\Root


		Thumbprint                                Subject
		----------                                -------
		B40BEE7CDF39981C041B42FA3C8DC4C77F969192  CN=mg

	.NOTES 
		Author: Michal Gajda 
#>

	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low" 
	)]	
	param(
		[parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[String]$Path,
		$secureString,
		[parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[String]$storeName,
		[parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[String]$storeLocation
	)

	Begin{}

	Process
	{
		if ($pscmdlet.ShouldProcess("$storeName in location $storeLocation","Import certificate $Path"))
		{
			Try
			{
				Write-Verbose "Trying open cert: $Path"
				if($secureString -ne $null)
				{
					$certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($Path,$secureString)	
				}
				else
				{
					$certObj = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($Path)
				}
			}
			Catch
			{
				Write-Warning "Can't open cert: $Path"
			}
			
			Try
			{
				Write-Verbose "Trying open store $storeName in location $storeLocation"
				$storeObj = New-Object System.Security.Cryptography.X509Certificates.X509Store($storeName,$storeLocation)
				$storeObj.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
			}
			Catch
			{
				Write-Warning "Can't open store $storeName in location $storeLocation"
			}
			
			Try
			{
				Write-Verbose "Trying add cert $($certObj.Subject) to store $storeName in location $storeLocation"
				$storeObj.add($certObj) 
				$storeObj.close()	
				
				Return Get-ChildItem "cert:\$storeLocation\$storeName" | Where-Object {$_.Thumbprint -eq ($certObj.Thumbprint)}
			}
			Catch
			{
 				Write-Warning "Can't add cert $($certObj.Subject) to store $storeName in location $storeLocation"
			}
		}
	}
	
	End{}
}

Function Export-Cert
{
<# 
	.SYNOPSIS 
		Export certificate.
		
	.DESCRIPTION 
		Use Export-Cert to export specific certificate from certificate store.

	.PARAMETER Cert
		Path to certificate in certificate store.
		
	.PARAMETER Path 
		Path to cer or pfx file.
		
	.PARAMETER withPrivateKey 
		Exprto cert with PrivateKey.

	.PARAMETER secureString
		The password required to access the X.509 certificate data. Can be placed as SecureString or as plain Text.
		
	.EXAMPLE 
		PS P:\> $Cert = dir cert:\LocalMachine\Root | Where-Object {$_.Subject -eq "CN=mg"}
		PS P:\> Export-Cert -Cert $Cert -withPrivateKey -secureString "P@ssw0rd" -Path P:\MyCert.pfx
		
		PS P:\> Get-Cert P:\MyCert.pfx -secureString "P@ssw0rd" | Select-Object Thumbprint, Subject, HasPrivateKey

		Thumbprint                              Subject                                              HasPrivateKey
		----------                              -------                                              -------------
		B40BEE7CDF39981C041B42FA3C8DC4C77F96... CN=mg                                                         True
		
	.EXAMPLE 
		PS P:\> Get-ChildItem cert:\LocalMachine\Root | Where-Object {$_.Subject -eq "CN=mg"} | Export-Cert
		PS P:\> Get-Cert .\B40BEE7CDF39981C041B42FA3C8DC4C77F969192.cer

		Thumbprint                                Subject
		----------                                -------
		B40BEE7CDF39981C041B42FA3C8DC4C77F969192  CN=mg		
		
	.NOTES 
		Author: Michal Gajda 
#>

	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low" 
	)]	
	param(
		[parameter(ValueFromPipeline=$True,Mandatory=$true)]
		[System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert,
		[String]$Path = "",
		[Switch]$withPrivateKey = $false,
		$secureString
	)

	Begin{}

	Process
	{
		if ($pscmdlet.ShouldProcess("$storeName in location $storeLocation","Import certificate $Path"))
		{
			if($withPrivateKey -eq $true -and $Cert.hasPrivateKey -eq $true)
			{
				Write-Verbose "Creating cert type: pfx"
				$certType = [System.Security.Cryptography.X509Certificates.X509ContentType]::pfx
				$certExt = "pfx"
				
				if($secureString -eq $null)
				{
					Write-Verbose "Read for password"
					$secureString = Read-Host "Password" -AsSecureString
				}
				
				Write-Verbose "Export cert: $Cert.Subject"
				$certBytes = $Cert.Export($certType, $secureString)
			}
			else
			{
				Write-Verbose "Creating cert type: cer"
				$certType = [System.Security.Cryptography.X509Certificates.X509ContentType]::Cert
				$certExt = "cer"
				
				Write-Verbose "Export cert: $Cert.Subject"
				$certBytes = $Cert.Export($certType)
			}
			

			Try
			{
				if($Path -eq "")
				{
					Write-Verbose "Save in current path"
					$Path = Join-Path -Path (Get-Location).Path -ChildPath "$($Cert.Thumbprint).$certExt"
				}
				Write-Verbose "Saving cert to $Path"
				[system.IO.file]::WriteAllBytes($Path, $certBytes)
			}
			Catch
			{
				Write-Warning "Can't save cert: $Cert.Subject"	
			}
		}
	}
	
	End{}
}