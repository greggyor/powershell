﻿# Script: dailyscomreport.ps1
# Author: David Maldonado
# Date: 05/13/2011
# Examples:
# .\dailyscomreport.ps1
# .\dailyscomreport.ps1 * 3 open
# .\dailyscomreport.ps1 "Heartbeat failed" 7 closed secondary@contoso2.com scom@contoso2.com 
# smtp.contoso2.com

<#
.SYNOPSIS
A daily report of SCOM 2007 alerts. Scope can be configured to retrieve a specific alert name,
the number of days in which to retrieve the alert, and the resolution state of the alert. Sends
report via html email. Can be scheduled via Windows Task Scheduler.

.DESCRIPTION
Uses the command Get-Alert to retrieve alerts from SCOM 2007 RMS Server.

.PARAMETER RMSServer
Specifies the Name of the OPS 2007 RMS Server. Defaults to "RMS.contoso.com"

.PARAMETER alertName
Specifies the Name of the alert to target. Wildcards accepted. Defaults to "Web Application*".

.PARAMETER noDays
Specifies the number of days in which to target. Defaults to "1" day.

.PARAMETER alertState
Specifies the Resolution State of the alert to target. Case insensitive. Accepts "Open" or "Closed"
Defaults to all.

.PARAMETER toEmail
Specifies recipient's email address. Defaults to "primary@contoso.com".

.PARAMETER fromEmail
Specifies sender's email address. Defaults to "scom@contoso.com".

.PARAMETER smtpServer
Specifies SMTP Server to use. Defaults to "smtp.contoso.com".

.EXAMPLE
C:\PS> dailyscomreport.ps1

Description
-----------
Script produces a report consisting of all alerts matching name "Web Application*" raised over
the last 1 day, and for all resolution states. Sends email to account "primary@contoso.com",
from account "scom@contoso.com", using smtp server "smtp.contoso.com".

.EXAMPLE
C:\PS> dailyscomreport.ps1 * 3 open

Description
-----------
Script produces a report consisting of all alerts raised over the last 3 days, and with
resolution states that are open. Sends email to account "primary@contoso.com",
from account "scom@contoso.com", using smtp server "smtp.contoso.com".

.EXAMPLE
C:\PS> dailyscomreport.ps1 "Heartbeat failed" 7 closed secondary@contoso2.com scom@contoso2.com
smtp.contoso2.com

Description
-----------
Script produces a report consisting of all alerts matching name "Heartbeat failed" raised over
the last 7 days, and with resolution states that are closed. Sends email to account
"secondary@contoso2.com", from account "scom@contoso2.com", using smtp server "smtp.contoso2.com".
#>

param (
[string]$RMSServer = "RMS.contoso.com",
[string]$alertName = "Web Application*",
[int] $noDays = "1",
[string] $alertState,
[string]$toEmail = "primary@contoso.com",
[string]$fromEmail="scom@contoso.com",
[string]$smtpServer = "smtp.contoso.com"
) # end parameters

# load Operations Manager 2007 Shell
Add-PSSnapin Microsoft.EnterpriseManagement.OperationsManager.Client -ErrorAction SilentlyContinue `
-ErrorVariable Err
New-PSDrive Monitoring Microsoft.EnterpriseManagement.OperationsManager.Client\OperationsManagerMonitoring ""
New-ManagementGroupConnection $RMSServer
Set-Location 'C:\Program Files\System Center Operations Manager 2007'
./Microsoft.EnterpriseManagement.OperationsManager.ClientShell.NonInteractiveStartup.ps1

$style = '<style>
BODY{font-size:85%; font-family:arial; background-color:#D0D0D0}
TABLE{font-size:90%;border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse}
TH{font-size:100%; color:white; border-width: 1px;padding: 2px;border-style: solid;border-color:black;
background-color:#000066}
TD{font-size:85%;border-width: 1px;padding: 2px;border-style: solid;border-color:black;
background-color:white}
</style>'

function Send-EMail {
param(
[string]$Subject="SCOM Daily Report - $alertName",
[string]$Body="<font face=arial><font size=2><B><U>Here are the alerts opened for scope $alertName `
in the last $noDays day(s):</U></B></font><BR><BR>$newAlerts <BR><BR>"
) # end parameters
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = $fromEmail
$msg.To.Add($toEmail)
$msg.Subject = $Subject
$msg.IsBodyHtml = 1
$msg.Body = $Body
$msg.Priority = [System.Net.Mail.MailPriority]::High
$smtp.Send($msg)
} # end function Send-EMail

# begin

# gets current date and subtracts from number of days specified in scope
$Date = (Get-Date).adddays(-$noDays)

# supplies value to resolution state based on scope specified
switch ($alertState)
{
"Closed" {$State = "255"}
"Open" {$State = "0"}
default {$State = "*"}
}

# retrieves alerts based on scope specified
$newAlerts = Get-Alert |
Where-Object {($_.Name -like $alertName) -and ($_.TimeRaised -gt $Date) -and
($_.ResolutionState -like $State)} |
Select-Object TimeRaised, MonitoringObjectPath, Name, Description, ResolutionState,`
Priority, Severity |
Sort-Object TimeRaised -Descending | ConvertTo-Html -head $style -body $style

# sends report via html email
Send-EMail

# end