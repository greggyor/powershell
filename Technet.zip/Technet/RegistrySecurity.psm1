﻿#region Internals
#region Invoke-Ternary
function Invoke-Ternary ([scriptblock]$decider, [scriptblock]$ifTrue, [scriptblock]$ifFalse) 
{
	if (&$decider)
	{ 
		&$ifTrue
	}
	else
	{
		&$ifFalse
	}
}
Set-Alias ?? Invoke-Ternary -Option AllScope -Description "Ternary Operator like '?' in C#"
#endregion

#region Get-RegistryKey
function Get-RegistryKey
{
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath","FullName")]
		[string] $Path,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Rights = "FullControl"
	)
	
	begin { }
	
	process {
	
		if ($Path.StartsWith(".\"))
		{
			$Path = $Path.SubString(2)
		}
		if (!$Path.Contains("\"))
		{
			$Path = [System.IO.Path]::Combine($PWD.ProviderPath, $Path)
		}
			
		$tempPath = $Path
		if ($tempPath.Contains("::"))
		{
			$tempPath = $tempPath.SubString($tempPath.IndexOf("::") + 2)
		}
		
		$root = $tempPath.SubString(0, $tempPath.IndexOf("\"))
		$tempPath = $tempPath.SubString($tempPath.IndexOf("\") + 1)
		
		switch ($root)
		{
			"HKEY_CLASSES_ROOT" {
				return [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($tempPath,
					[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree,
					$Rights)
			}
			"HKEY_LOCAL_MACHINE" {
				return [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($tempPath,
					[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree,
					$Rights)
			}
			"HKEY_CURRENT_USER" {
				return [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($tempPath,
					[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree,
					$Rights)
			}
			"HKEY_USERS" {
				return [Microsoft.Win32.Registry]::Users.OpenSubKey($tempPath,
					[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree,
					$Rights)
			}
			default {
				throw New-Object System.Exception("Path was not in the correct format")
			}
		}
	}
	
	end { }
}
#endregion
#endregion

#region Add-Ace
function Add-Ace
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="SimpleInheritance")]
	
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath","FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("RegistryRights")]
		[System.Security.AccessControl.RegistryRights] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="SimpleInheritance")]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.InheritanceFlags] $InheritanceFlags,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.PropagationFlags] $PropagationFlags = [System.Security.AccessControl.PropagationFlags]::None,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | Select-Object -ExpandProperty Privilege
		if ($privileges -notcontains "TakeOwnership" -or $privileges -notcontains "Restore")
		{
			Write-Verbose "TakeOwnership and Restore preivilege not available. Permissions can only be shown if the required access to the key is granted or if the privileges are available."
		}
		else
		{
			[Void]$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership)
			[Void]$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Restore)
		}
	}
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ChangePermissions
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read security information" -Exception $_.Exception
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$ir = New-Object System.Security.Principal.SecurityIdentifier($Account.Sid)
			switch ($pscmdlet.ParameterSetName)
			{
				"SimpleInheritance"
				{
					$ace = New-Object Security.AccessControl.RegistryAccessRule($ir,
						$AccessRights,
						(?? {$NoInheritance} { [Security.AccessControl.InheritanceFlags]::None } {[Security.AccessControl.InheritanceFlags]::ContainerInherit }),
						[Security.AccessControl.PropagationFlags]::None,
						$AccessType)
				}
				"ComplexInheritance"
				{
					$ace = New-Object Security.AccessControl.RegistryAccessRule($ir,
						$AccessRights,
						$InheritanceFlags,
						$PropagationFlags,
						$AccessType)
				}
			}
			
			try
			{
				$sd.AddAccessRule($ace)
				$item.SetAccessControl($sd)
			}
			catch [Exception]
			{
				Write-Error -Message "Error adding ACE to item: $($_.Exception.Message)" -Exception $_.Exception
			}
			Write-Verbose "ACE for user $Account added to ACL of $($item.FullName)"
			
			if ($PassThru)
			{
				foreach ($ace in $sd.GetAccessRules($true, $false, [System.Security.Principal.NTAccount]))
				{
					$ace = [Security2.RegistryAccessRule2]$ace
					$ace.FullName = $item.FullName
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.RegistryAccessRule2]$ace
				}
			}
		}
	}
	
	end
	{
		if ($privileges -contains "TakeOwnership")
		{ [Void]$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership) }
		if ($privileges -contains "Restore")
		{ [Void]$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Restore) }
	}
}
#endregion

#region Remove-Ace
function Remove-Ace
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath","FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("RegistryRights")]
		[System.Security.AccessControl.RegistryRights] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin {}
	
	process
	{
		$acesToRemove = $null
		
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ChangePermissions
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read security information" -Exception $_.Exception
				continue
			}
		
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$acl = $sd.GetAccessRules($true, $false, [System.Security.Principal.NTAccount])
			
			$acesToRemove = @($acl | Where-Object { $_.IdentityReference -eq $Account })
			
			foreach ($ace in $acesToRemove)
			{
				try
				{
					if (($ace.RegistryRights -eq $AccessRights) -or (-not $AccessRights))
					{
						[Void]$sd.RemoveAccessRule($ace)
					}
					else
					{
						[Void]$sd.RemoveAccessRule($ace)
						$ace = New-Object System.Security.AccessControl.RegistryAccessRule($ace.IdentityReference,
							($ace.RegistryRights -bxor $AccessRights),
							$ace.InheritanceFlags,
							$ace.PropagationFlags,
							$ace.AccessControlType)
						$sd.AddAccessRule($ace)
					}
					$item.SetAccessControl($sd)
					Write-Verbose "$($acesToRemove.Count) ACE(s) removed from item $($item.Name)"
				}
				catch [Exception]
				{
					Write-Error -Message "Error removing ACE(s) from item: $($_.Exception.Message)" -Exception $_.Exception
				}
			}
			
			if ($PassThru)
			{
				$acl = $sd.GetAccessRules($true, $false, [System.Security.Principal.NTAccount])
			}
		}
	}
	
	end { }
}
#endregion RemoveAccess

#region Get-Ace
function Get-Ace
{
<#
	.SYNOPSIS
		Gets all Access Control Entries in the item's Discretionary Access Control List.
		
	.DESCRIPTION
		The function returns all ACEs defined on the item. You can filter the ACEs using the switches ExcludeExplicit and ExcludeInherited.
		
		Whether the item inherits the permissions from its parant is indicated in the output as well.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.FileSystemAccessRule2
    	Get-Ace returns objects that represent the item's Access Control Entries.

	.PARAMETER Path
		Specifies the path to a resource. Get-Owner gets the ownership of the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
		
	.PARAMETER ExcludeExplicit
		If set, only inherited ACEs are returned.
	
	.PARAMETER ExcludeInherited
		If set, only explicitly non-inherited ACEs are returned.
			
	.EXAMPLE
		PS C:\> Get-Item c:\ | Get-Ace

		    Path: C:\ (Inheritance disabled)

		Identity                       Rights         Inheritance    Type           IsInherited
		--------                       ------         -----------    ----           -----------
		NT AUTHORITY\Authenticated ... AppendData     None           Allow          False
		NT AUTHORITY\Authenticated ... -536805376     ContainerIn... Allow          False
		NT AUTHORITY\SYSTEM (S-1-5-18) FullControl    None           Allow          False
		NT AUTHORITY\SYSTEM (S-1-5-18) 268435456      ContainerIn... Allow          False
		BUILTIN\Administrators (S-1... 268435456      ContainerIn... Allow          False
		BUILTIN\Administrators (S-1... FullControl    None           Allow          False
		BUILTIN\Users (S-1-5-32-545)   ReadAndExec... ContainerIn... Allow          False

		Description
		-----------
		Get all ACEs defined on the root of drive C:
		
	.EXAMPLE
		PS C:\> dir | Where-Object { $_.PSIsContainer } | Get-Ace -ExcludeInherited

		Description
		-----------
		This command returns only explicitly set ACEs on all folders.
		
	.EXAMPLE
		PS C:\> dir | Get-Ace | Where-Object { $_.ID -eq "BUILTIN\Users" }

		Description
		-----------
		This command returns only explicitly set ACEs on all folders.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
	
	begin { }
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read security information" -Exception $_.Exception
				continue
			}
			
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
				{
					$ace = [Security2.RegistryAccessRule2]$ace
					$ace.FullName = $item.Name
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					Write-Output $ace
				}
		}
	}
	
	end { }
}
#endregion

#region Get-OrphanedAce
function Get-OrphanedAce
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
		
	begin { }
	
	process
	{
		[bool] $hasOrphanedSIDs = $false
		$orphanedSidCount = 0
		
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			
			$item = Get-Item -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
		
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
			{
				$ace = [Security2.RegistryAccessRule2]$ace
				
				if (-not $ace.IdentityReference.AccountName)
				{
					$ace.FullName = $item.Name
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.RegistryAccessRule2]$ace
					
					$hasOrphanedSIDs = $true
					$orphanedSidCount++
				}
			}
			
			if ($hasOrphanedSIDs)
			{
				Write-Verbose ("Item {0} knows about {1} orphaned SIDs in its ACL" -f $item.FullName, $orphanedSidCount)
			}
		}
	}
}
#endregion Get-OrphanedAce

#region Get-Owner
function Get-Owner
{
<#
	.SYNOPSIS
		Gets the owner for a file or folder.
		
	.DESCRIPTION
		The function gets the owner for a file or filder.
		
		All the function needs to know is the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.ItemOwner
    	Get-Owner returns an object that represents the item's ownership.

	.PARAMETER Path
		Specifies the path to a resource. Get-Owner gets the ownership of the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
			
	.EXAMPLE
		PS C:\Users> dir | Get-Owner

		Item                                                     Account
		----                                                     -------
		C:\Users\Public                                          BUILTIN\Administrators (S-1-5-32-544)
		C:\Users\raandree                                        NT AUTHORITY\SYSTEM (S-1-5-18)

		Description
		-----------
		This command gets the owner of all items in C:\Users
		
	.EXAMPLE
		PS F:\> dir | Get-Owner | Where-Object { "S-1-1-0" -eq $_.Account.SID }

		Item                                                     Account
		----                                                     -------
		F:\Tools                                                 Everyone (S-1-1-0)
		F:\lib1.ps1                                              Everyone (S-1-1-0)
		
		Description
		-----------
		This command returns all items whose owner is the Everyone group.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
				$owner = New-Object Security2.RegistryOwner
				$owner.Item = $item
				$owner.Account = $item.Owner
				Write-Output $owner
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read security information" -Exception $_.Exception
			}
		}
	}
	
	end { }
}
#endregion Get-Owner

#region Set-Owner
function Set-Owner
{
<#
	.SYNOPSIS
		Sets the owner for a certain account on a file or folder.
		
	.DESCRIPTION
		The function sets the given owner on a file or folder to. This task requires the Restore and TakeOwnership privilege. If you do not have these privileges the script will not start.
		
		All the function needs to know is the file or folder path and the account (Domain\Username) to set as the new owner. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
		
		As the Restore and TakeOwnership privilege is needed you may want to use the function in an elevated PowerShell.
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.ItemOwner
    	Set-Owner returns an object that represents the item's ownership only if the parameter PassThru is used. Without PassThrhu the function has no output

	.PARAMETER Path
		Specifies the path to a resource. Set-Owner sets the owner of the item indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER Account
		Takes the account that is will be the new owner. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'.
	
	.PARAMETER PassThru
		Returns a ItemOwner object for each item worked on. By default, this cmdlet does not generate any output.
		
	.EXAMPLE
		PS C:\> Get-Item F:\Tools | Set-Owner -Account 'NT Authority\Everyone' -PassThru

		Item                                                     Account
		----                                                     -------
		F:\Tools                                                 Everyone (S-1-1-0)

		Description
		-----------
		This command sets the owner of the tools folder to Everyone and shows the result.
		
	.EXAMPLE
		PS C:\Users> dir | Where-Object { $_.PSIsContainer } | ForEach-Object { Set-Owner -Path $_.FullName -Account "C1\$($_.Name)" -PassThru }

		Item                                         Account
		----                                         -------
		C:\Users\administrator                       C1\Administrator (S-1-5-21-3872441409-162...		
		C:\Users\dev                                 C1\Dev (S-1-5-21-3872441409-1623757310-16...
		C:\Users\devadmin                            C1\DevAdmin (S-1-5-21-3872441409-16237573...
		C:\Users\t1                                  C1\t1 (S-1-5-21-3872441409-1623757310-164...
		C:\Users\t11                                 C1\t11 (S-1-5-21-3872441409-1623757310-16...		
		
		Description
		-----------
		This command sets the owners for all items in the current directory. The directory name is taken as the respective account name. This can be useful to correct the ownership on terminal service profiles.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | Select-Object -ExpandProperty Privilege
		if ($privileges -notcontains "TakeOwnership" -or $privileges -notcontains "Restore")
		{
			throw New-Object System.Exception("The TakeOwnership or Restore privilege is not available. The ownership cannot be set without this privilege")
			return
		}
		else
		{
			[Void]$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership)
			[Void]$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Restore)
		}
		
		$registrySecurity = New-Object Security2.Win32RegistrySecurity
	}
	
	process
	{
		foreach ($p in $Path)
		{
			if ($Path.StartsWith(".\"))
			{
				$Path = $Path.SubString(2)
			}
			if (!$Path.Contains("\"))
			{
				$Path = [System.IO.Path]::Combine($PWD.ProviderPath, $Path)
			}
				
			$tempPath = $Path
			if ($tempPath.Contains("::"))
			{
				$tempPath = $tempPath.SubString($tempPath.IndexOf("::") + 2)
			}
			
			$root = $tempPath.SubString(0, $tempPath.IndexOf("\"))
			$tempPath = $tempPath.SubString($tempPath.IndexOf("\") + 1)

			$registrySecurity.SetRegistryOwner($root, $tempPath, [System.Security.Principal.SecurityIdentifier]$Account)
			
			if ($PassThru)
			{
				Get-Owner -Path $p
			}
		}
	}
	
	end
	{
		[Void]$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership)
		[Void]$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Restore)
	}
}
#endregion Set-Owner

#region Get-Inheritance
function Get-Inheritance
{
<#
	.SYNOPSIS
		Gets the inheritance information.
		
	.DESCRIPTION
		Gets the inheritance information and returns an object that contains just the file and a boolean value indicating whether the item inherits the permission from its parent.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.ItemInheritanceInfo
    	Get-Owner returns an object that represents the item's inheritance setting.

	.PARAMETER Path
		Specifies the path to a resource. Get-Owner gets the ownership of the items indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
			
	.EXAMPLE
		PS C:\> dir | Get-Inheritance
		WARNING: This module already adds the property 'IsInheritanceBlocked' to the file system items. This infomation is displayed by default in the column 'Inherits' and can be used for filtering or sorting.

		Name                InheritanceEnabled
		----                ------------------
		PerfLogs            True
		Program Files       False
		Program Files (x86) False
		Users               False
		Windows             False
		.rnd                True

		Description
		-----------
		This command gets the inheritance setting for all items in C:\.
		
		The same information get be get through the Get-ChildItem cmdlet. The module adds some properties to files and folders and also one that tells if the inheritance is enabled or blocked:
		
		PS C:\> dir

		    Directory: C:\

		Mode    Inherits             LastWriteTime    Size(M) Name
		----    --------             -------------    ------- ----
		d----       True      14.07.2009     05:20            PerfLogs
		d-r--      False      19.03.2011     01:18            Program Files
		d-r--      False      19.03.2011     13:59            Program Files (x86)
		d-r--      False      18.03.2011     23:40            Users
		d----      False      19.03.2011     11:23            Windows
		-a---       True      19.03.2011     01:26          0 .rnd
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path
	)
	
	begin
	{
		Write-Verbose "This module already adds the property 'IsInheritanceBlocked' to the file system items. This infomation is displayed by default in the column 'Inherits' and can be used for filtering or sorting."
	}
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
				$ii = New-Object Security2.RegistryInheritanceInfo
				$ii.Item = $item
				$ii.InheritanceEnabled = !$item.IsInheritanceBlocked
				Write-Output $ii
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read security information" -Exception $_.Exception
			}
		}
	}
	
	end { }
}
#endregion Get-Inheritance

#region Enable-Inheritance
function Enable-Inheritance
{
<#
	.SYNOPSIS
		Enables the security inheritance on the item.
		
	.DESCRIPTION
		The command enables the inheritance on the specified item.
		
		The function needs to know the file or folder path. The path can be an argument or be piped into the function as string or FileSystemInfo object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.ItemInheritanceInfo
    	Enable-Inheritance returns an object that represents the item's inheritance setting only if the parameter PassThru is used. Without PassThrhu the function has no output.

	.PARAMETER Path
		Specifies the path to a resource. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining this function with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER RemoveInheritedPermissions
		If defined the permissions that were inherited by the item previously are removed, otherwise the permissions are copied to the item. The same choice must be done when disabling inheritance using the UI.
		
	.EXAMPLE
		PS F:\Data> dir | Where-Object { $_.PSIsContainer } | Enable-Inheritance -PassThru

		Name       InheritanceEnabled
		----       ------------------
		Project_01 True
		Project_02 True
		Project_03 True
		Project_04 True
		Project_05 True

		Description
		-----------
		This command enables the inheritance on all folders in the current container. PassThru returns the inheritance info afterwards
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
				$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
				$sd.SetAccessRuleProtection($false, $false)
				$item.SetAccessControl($sd)
			}
			catch [Exception]
			{
				Write-Error -Message "Could not enable inheritance" -Exception $_.Exception
			}
			
			if ($PassThru)
			{
				if ($item) { $item | Get-Inheritance }
			}
		}
	}
	
	end
	{ }
}
#endregion Enable-Inheritance

#region Disable-Inheritance
function Disable-Inheritance
{
<#
	.SYNOPSIS
		Disabled the security inheritance on the item.
		
	.DESCRIPTION
		The command disables or blocks the inheritance on the specified item. The already inherited permissions can be copied or removed from the item using the parameter RemoveInheritedPermissions. 
		
		The function needs to know the registry key path. The path can be an argument or be piped into the function as string or RegistryKey object (result of Get-ChildItem or Get-Item).
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		None or Security2.RegistryInheritanceInfo
    	Disable-Inheritance returns an object that represents the item's inheritance setting only if the parameter PassThru is used. Without PassThrhu the function has no output.

	.PARAMETER Path
		Specifies the path to a resource. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining combining this function with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER RemoveInheritedPermissions
		If defined the permissions that are inherited by the item are removed, otherwise the permissions are copied to the item. The same choice must be done when disabling inheritance using the Explorer UI.
		
	.EXAMPLE
		PS HKCU:\Test> dir | Disable-Inheritance -PassThru

		Name       InheritanceEnabled
		----       ------------------
		Project_01 False
		Project_02 False
		Project_03 False
		Project_04 False
		Project_05 False

		Description
		-----------
		This command disables the inheritance on all folders in the current container. PassThru returns the inheritance info afterwards
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[switch] $RemoveInheritedPermissions,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	
	begin
	{ }
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
				$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
				$sd.SetAccessRuleProtection($true, !$RemoveInheritedPermissions)
				$item.SetAccessControl($sd)
			}
			catch [Exception]
			{
				Write-Error -Message "Could not enable inheritance" -Exception $_.Exception
			}
			
			if ($PassThru)
			{
				if ($item) { $item | Get-Inheritance }
			}
		}
	}
	
	end
	{ }
}
#endregion Disable-Inheritance

#region Get-EffectivePermissions
function Get-EffectivePermissions
{
<#
	.SYNOPSIS
		Gets the effective permissions for a certain account on a registry key.
		
	.DESCRIPTION
		The function uses the Win32 function GetEffectiveRightsFromAcl to get the effective rights for a certain account of a registry key. It requires a path and an account to read the effective rights. The path can be an argument or be piped into the function as string or RegistryKey object (result of Get-ChildItem or Get-Item).
		
		If you do not have access to the item, the security privilege is used to read the security descriptor. If the security priviledge is not held, a warning is displayed and also an error for each item that your do not have access to.
	
	.INPUTS
		System.String
    	You can pipe a string that contains a path.
	
	.OUTPUTS
		Security2.EffectivePermissionEntry
    	Get-EffectivePermissions returns an object that represents the effective permissions.

	.PARAMETER Path
		Specifies the path to a resource. Get-EffectivePermissions gets the effective permissions of the resource indicated by the path. Wildcards are not permitted. This paramter also accepts input from the pipleine so combining Get-EffectivePermissions with Get-ChilfItem  or Get-Item is the easiest way if you want to get the effective rights of multiple files and folders.
	
	.PARAMETER Account
		Takes the account to get the effective rights for. This can either be a SID (well known, domain or local) or a account name. The account name must be specified in the syntax 'Domain\UserName'. Well known accounts are not part of the domain or local machine. Use for example 'NT Authority\System' or 'Builtin\Administrators'. If not specified the effective permission the current account has are reported.

	.EXAMPLE
		PS C:\> dir | Get-EffectivePermissions

		Name                Access                 AccessMask Account
		----                ------                 ---------- -------
		PerfLogs            {FullControl}          2032127    Client1\Test
		Program Files       {Modify,  Synchronize} 1245631    Client1\Test
		Program Files (x86) {Modify,  Synchronize} 1245631    Client1\Test
		Users               {FullControl}          2032127    Client1\Test
		Windows             {Modify,  Synchronize} 1245631    Client1\Test
		.rnd                {FullControl}          2032127    Client1\Test
		
		Description
		-----------
		This command gets the effective rights of the account Client1\Test of all items in the C:\ directory.
		
	.EXAMPLE
		PS HKCU:\Test> dir | Get-EffectivePermissions | Where-Object { $_.AccessMask -lt [System.Security.AccessControl.RegistryRights]::FullControl }

		Name Access                                                    AccessMask Account
		---- ------                                                    ---------- -------
		K2   {QueryValues,  EnumerateSubKeys,  Notify,  CreateLink...} 852025     raandree3\ra...
		
		Description
		-----------
		Gets all items where the current account does not have FullControl to. As FullControl is the highest value in the enum we can simply check if the effective permission's access mask is less than the integer value for FullControl.
		
	.EXAMPLE
		PS HKCU:\Test> dir | Get-EffectivePermissions -Account raandree\test | Where-Object $_.AccessAsString -eq 'FullControl' }

		Name Access        AccessMask Account
		---- ------        ---------- -------
		K1   {FullControl} 983103     raandree\test
		K3   {FullControl} 983103     raandree\test

		Description
		-----------
		This command retreives all registry keys the user raandree\test has full control to.
#>
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Position=1)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account
	)
	
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | Select-Object -ExpandProperty Privilege
		if ($privileges -notcontains "Security")
		{
			Write-Warning "The Security privilege is not available. This privilege might be required to show effective permissions on certain items."
		}
		else
		{
			[Void]$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Security)
		}
	}
	
	process
	{
		foreach ($p in $Path)
		{
			try
			{
				$item = Get-RegistryKey -Path $p -Rights ReadPermissions
			}
			catch [Exception]
			{
				Write-Error -Message "Could not read registrz security" -Exception $_.Exception
				continue
			}
			
			if (!$Account)
			{	
				$Account = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
			}
			
			$accessMask = 0

			try
			{
				$accessMask = [Security2.EffectivePermissions]::GetEffectivePermissions($item.GetAccessControl(),
					$Account,
					$item.PSIsContainer)
				
				New-Object Security2.RegistryEffectivePermissionEntry($Account, $accessMask, $item.Name)
			}
			catch
			{
				Write-Error "Error reading effective permissions."
			}
		}
	}

	end
	{
		if ($privileges -contains "Security")
		{
			[Void]$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Security)
		}
	}
}
#endregion Get-EffectivePermissions