####################################################################################################
# 
# 	NAME: Set-FineGrainedPasswordPolicy
#
# 	AUTHOR: Anthony P. Guimelli 
#
# 	PURPOSE: Sets a fine grained password policy for users in a specific Active Directory org unit
#			 and writes the resulting policy and user it has been applied to to 
#			 to an HTML file for viewing and troubleshooting purposes.
#
# 	DATE: 7/9/2012
#
#   NOTES: Requires XML config file as specified in the $settingsFilePath variable with the 
# 		   following schema:
#   	   
#		   <Parameters>
#		 	  <ActiveDirectoryObjects TargetOuDn="OU=Users,DC=fabrikam,DC=com" 
#			   PasswordPolicyDn="CN=UserPso,CN=Password Settings Container,CN=System,DC=fabrikam,DC=com" />
# 			  <FilePaths Html="C:\Scripts\PSO\UserPso.html" Csv="C:\Scripts\PSO\UserPso.csv" />  
#			  <RunOptions WriteToConsole="FALSE" WhatIf="TRUE" />	
#		   </Parameters>
# 
####################################################################################################
Import-Module ActiveDirectory

# Path to config file
$settingsFilePath = "C:\Scripts$\PSO\Set-FineGrainedPasswordPolicy.xml"

# If config XML file is not found, terminate. 
if (!([System.IO.File]::Exists($settingsFilePath))) {
	Exit #terminates processing
}
else {
	# Get config settings
	[xml]$configXml = Get-Content $settingsFilePath
}

# Get config settings
[string]$targetOuDN = $configXml.Parameters.ActiveDirectoryObjects.TargetOuDN
[string]$passwordPolicyDN = $configXml.Parameters.ActiveDirectoryObjects.PasswordPolicyDN
[string]$htmlFilePath = $configXml.Parameters.FilePaths.Html
[string]$csvFilePath = $configXml.Parameters.FilePaths.Csv
[string]$writeToConsoleString = $configXml.Parameters.RunOptions.WriteToConsole.ToUpper()
[bool]$writeToConsole = $false
if ($writeToConsoleString -eq "TRUE"){ $writeToConsole = $true }
[string]$whatIfString = $configXml.Parameters.RunOptions.WhatIf.ToUpper()
[bool]$whatIf = $true
if ($whatIfString -eq "FALSE"){ $whatIf = $false }
  			
# Get users in target OU and add their DNs to a hash table. If the OU
# passed to this function doesn't exist, terminate processing.
$usersHashTable = @{}

# Try to get users. If that fails, halt execution.
try {
	$userCollection = Get-ADUser -SearchBase $targetOuDN -Filter *
}
catch {
	Exit
}
foreach ($user in $userCollection){ $usersHashTable.Add($user.distinguishedName, $null) }

# Get password policy object. If it doesn't exist, terminate processing. 
try {
	$passwordPolicyObject = Get-ADFineGrainedPasswordPolicy -Identity $passwordPolicyDN -Properties msDS-PSOAppliesTo, cn
}
catch {
	Exit
}
$passwordPolicyName = $passwordPolicyObject.cn

# Get users with policy currently applied and their DNs to a hash table
$usersWithPolicyCurrentlyAppliedHashTable = @{}
$usersWithPsoPreviouslyApplied = $passwordPolicyObject."msDS-PSOAppliesTo"
foreach ($userDN in $usersWithPsoPreviouslyApplied){ $usersWithPolicyCurrentlyAppliedHashTable.Add($userDN, $null) }

# Iterate through user collection to determine if user needs to have policy applied
foreach ($userDN in $usersHashTable.Keys){
	$addActivityString = "Adding '$userDN' to policy: '$passwordPolicyName'"
	if (!($usersWithPolicyCurrentlyAppliedHashTable.Contains($userDN))){
		if ($whatIf) {				
			Write-Host "What if: $addActivityString"						
		}
		else {
			if ($writeToConsole) { 
				Write-Host $addActivityString -ForegroundColor Green 						
			}
			Set-ADFineGrainedPasswordPolicy -Identity $passwordPolicyDN -Add @{'msDS-PSOAppliesTo'=$userDN}					
		}				
	}
}
# Iterate through user collection to determine if user needs to have policy removed
foreach ($userDN in $usersWithPolicyCurrentlyAppliedHashTable.Keys){	
	if (!($usersHashTable.Contains($userDN))){	
		$removeActivityString = "Removing '$userDN' from policy: '$passwordPolicyName'"
		if ($whatIf) {				
			Write-Host "What if: $removeActivityString"						
		}
		else {
			if ($writeToConsole) { 
				Write-Host $removeActivityString -ForegroundColor Red 						
			}
			Set-ADFineGrainedPasswordPolicy -Identity $passwordPolicyDN -Remove @{'msDS-PSOAppliesTo'=$userDN}					
		}	
	}
}

# Clear conent of old files if they exist
if ([System.IO.File]::Exists($csvFilePath)){ Clear-Content $csvFilePath -Force }	
if ([System.IO.File]::Exists($htmlFilePath)){ Clear-Content $htmlFilePath -Force }	

# Write the first line to the temp csv file
$csvLine = "USER NAME,LOGIN ID,ORGANIZATION,EMAIL ADDRESS,POLICY LAST APPLIED,POLICY NAME"
$csvLine | Out-File $csvFilePath -Append -Encoding "Default"

# Get the password policy sans changes (above) with attributes necessary for HTML report.
$currentPasswordPolicyObject = Get-ADFineGrainedPasswordPolicy -Identity $passwordPolicyDN -Properties *

# Get settings from password policy object and convert ticks to date/times where necessary
$passwordPolicyName = $currentPasswordPolicyObject.cn
$passwordHistory = $currentPasswordPolicyObject."msDS-PasswordHistoryLength"
$maximumPasswordAgeTicks = [Math]::Abs($currentPasswordPolicyObject."msDS-MaximumPasswordAge")
$maximumPasswordAge = [System.TimeSpan]::FromTicks($maximumPasswordAgeTicks).TotalDays
$minimumPasswordAgeTicks = [Math]::Abs($currentPasswordPolicyObject."msDS-MinimumPasswordAge")
$minimumPasswordAge = [System.TimeSpan]::FromTicks($minimumPasswordAgeTicks).TotalMinutes
$minimumPasswordLength = $currentPasswordPolicyObject."msDS-MinimumPasswordLength"
$complexityEnabled = $currentPasswordPolicyObject."msDS-PasswordComplexityEnabled"
$accountLockoutThreshold = $currentPasswordPolicyObject."msDS-LockoutThreshold"
$usersWithPsoCurrentlyApplied = $currentPasswordPolicyObject."msDS-PSOAppliesTo"
$passwordPolicyPrecedence = $currentPasswordPolicyObject."msDS-PasswordSettingsPrecedence"
$reversableEncryptionEnabled = $currentPasswordPolicyObject."msDS-PasswordReversibleEncryptionEnabled"
$lockoutObservationWindowTicks = [Math]::Abs($currentPasswordPolicyObject."msDS-LockoutObservationWindow")
$lockoutObservationWindow = [System.TimeSpan]::FromTicks($lockoutObservationWindowTicks).TotalMinutes
$lockoutDurationTicks = [Math]::Abs($currentPasswordPolicyObject."msDS-LockoutDuration")
$lockoutDuration = [System.TimeSpan]::FromTicks($lockoutDurationTicks).TotalMinutes

# Write html to memory to be written out later via ConvertTo-Html
$psoSettingsHtml += "<font face='verdana'>"
$psoSettingsHtml += "<B>ENFORCE PASSWORD HISTORY</B>: <font color='red'>$passwordHistory passwords remembered</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>MAXIMUM PASSWORD AGE</B>: <font color='red'>$maximumPasswordAge days</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>MINIMUM PASSWORD AGE</B>: <font color='red'>$minimumPasswordAge days</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>MINIMUM PASSWORD LENGTH</B>: <font color='red'>$minimumPasswordLength characters</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>ACCOUNT LOCKOUT THRESHOLD</B>: <font color='red'>$accountLockoutThreshold invalid logon attempts</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>PASSWORD POLICY PRECEDENCE</B>: <font color='red'>$passwordPolicyPrecedence</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>REVERSABLE ENCRYPTION ENABLED</B>: <font color='red'>$reversableEncryptionEnabled</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>LOCKOUT OBSERVATION WINDOW</B>: <font color='red'>$lockoutObservationWindow minutes</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "<B>LOCKOUT DURATION</B>: <font color='red'>$lockoutDuration minutes</font>"
$psoSettingsHtml += "<BR>"
$psoSettingsHtml += "</font>"

$htmlTitleRow = "<font face='verdana'>USER OBJECTS WITH <B>$passwordPolicyName</B> APPLIED:</font>"

# Iterate through msDS-PSOAppliesTo attribute to acquire users that the policy is applied to
foreach ($userDN in $usersWithPsoCurrentlyApplied){
	$userObject = Get-ADUser -Identity $userDN -Properties cn, givenName, sn, mail, company
	$userFullName = $userObject.givenName + " " + $userObject.sn
	$userOrg = $userObject.company
	$userLoginId = $userObject.cn
	$userEmail = $userObject.mail	
	$policyLastApplied = Get-Date -Format g
	$csvLine = "$userFullName,$userLoginId,$userOrg,$userEmail,$policyLastApplied,$passwordPolicyName"
	$csvLine | Out-File $csvFilePath -Append -Encoding "Default"
}

# Define HTML style
$htmlStyleParams += "<style>"
$htmlStyleParams += "BODY{background-color:#B9FFDA;}"
$htmlStyleParams += $htmlStyleParams + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$htmlStyleParams += $htmlStyleParams + "TH{border-width: 1px;padding: 5px;border-style: solid;border-color: black;background-color:thistle}"
$htmlStyleParams += $htmlStyleParams + "TD{border-width: 1px;padding: 5px;border-style: solid;border-color: black;background-color:PaleGoldenrod}"
$htmlStyleParams += $htmlStyleParams + "</style>"

# Import CSV file and convert to html 
$objCsv = Import-Csv -Path $csvFilePath
$objCsv | ConvertTo-Html "USER NAME","LOGIN ID",ORGANIZATION,"EMAIL ADDRESS","POLICY LAST APPLIED","POLICY NAME" -title $passwordPolicyName -head $htmlStyleParams -body "<H2><font face='verdana'>$passwordPolicyName</font></H2>$psoSettingsHtml<BR>$htmlTitleRow" | Set-Content $htmlFilePath

####################################################################################################
