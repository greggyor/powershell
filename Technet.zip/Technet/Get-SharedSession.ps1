﻿Function Get-SharedSession
{
    <#
	.SYNOPSIS
	    Gets current session to shared folder on file server.

	.DESCRIPTION
	    The Get-SharedSession cmdlet gets list of current session to shared folder on file server.
		
	.PARAMETER Server
	    Specifies a file server. 
		
	.EXAMPLE
		PS C:\> "MyFS"| Get-SharedSession | Format-Table * -AutoSize

		Server IdleTime ConnectTime Computer       User          OpenFiles
		------ -------- ----------- --------       ----          ---------
		MyFS   00:32:29 7.03:23:49  10.10.10.1     MG                    1
		
	.NOTES
		Author: Michal Gajda
		Blog  : http://commandlinegeeks.com/
	#>    	
	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low"
	)]
	Param
	(
	[parameter(ValueFromPipeline=$true,
		ValueFromPipelineByPropertyName=$true)]	
	[String[]]$Server = "."
	)
	
	Begin{}

	Process
	{
		Write-Verbose "Start SharedSession Scan..."
		Foreach($Srv in $Server)
		{ 
			Try
			{
				Write-Verbose "Connecting to $Srv..."
				$ADSI = [ADSI]"WinNT://$Srv/LanmanServer"
				$ConnectedStatus = $true
			} #End Try
			Catch
			{
				Write-Verbose "Can't connect to $Server. Machine is unavailable or access denied!"
				$ConnectedStatus = $false
			} #End Catch
			
			If($Srv -eq ".")
			{
				$Srv = "LocalHost"
			} #End If $Srv -eq "."
			
			If($ConnectedStatus)
			{
				Write-Verbose "Geting session list from $Srv"
				$Sessions = $ADSI.psbase.invoke("Sessions") 
				
				$NumberOfSession = 0
				$MaxNumberOfSession = ($Sessions|measure).count
				Foreach($Session in $Sessions)
				{
					Write-Progress -Activity "Geting session list from $Srv" -Status "Completed $NumberOfSession/$MaxNumberOfSession" -PercentComplete ([int]($NumberOfSession/$MaxNumberOfSession * 100))
					Try { $User = $Session.GetType().InvokeMember("User","GetProperty",$null,$Session,$null) } Catch {Write-Verbose $_}
					Try { $Computer = $Session.GetType().InvokeMember("Computer","GetProperty",$null,$Session,$null) } Catch {Write-Verbose $_}
					Try { $ConnectTime = (New-TimeSpan -Seconds ($Session.GetType().InvokeMember("ConnectTime","GetProperty",$null,$Session,$null))).ToString() } Catch {Write-Verbose $_}
					Try { $IdleTime = (New-TimeSpan -Seconds ($Session.GetType().InvokeMember("IdleTime","GetProperty",$null,$Session,$null))).ToString() } Catch {Write-Verbose $_}

					$OpenFiles = (Get-WmiObject win32_serverconnection -ComputerName $Srv -Filter "username='$User' and computername='$Computer'" | select NumberOfFiles|measure -sum NumberOfFiles).sum
					
					$ServerSessions = New-Object -TypeName PSobject -Property @{ 
						Server = $Srv
						User = $User
						OpenFiles = [int]$OpenFiles
						Computer = $Computer
						ConnectTime = $ConnectTime
						IdleTime = $IdleTime
					} #End New-Object PSobject

					$ServerSessions
					
					$NumberOfSession++
				} #End ForEach $Session in $Sessions
			} #End IF $ConnectedStatus
		} #End ForEach $Srv in $Server
	} #End Process
	
	End{}
} #In The End :)