#Windows PowerShell Code###########################################################################
#
# AUTHOR: John Grenfell
#
###########################################################################

<#
.SYNOPSIS
    This is a script will take the picture out of AD and update the Windows 7 User tile
.DESCRIPTION
    This is a script will take the picture out of AD and update the Windows 7 User tile
.EXAMPLE
    .\Set-UserTileFromAD.ps1
.NOTES
        VERSION HISTORY:
        1.1 12.10.2011
        
        2011/09/01 - Created Script
    
        Currently requires the Active Directory module and to have put the image in the 
        AD attribute thumbnailphoto    

#>

$code = @"
[DllImport("shell32.dll", EntryPoint = "#262", CharSet = CharSet.Unicode, PreserveSig = false)]
 public static extern void SetUserTile(string username, int whatever, string picpath);

public static void ChangeUserPicture(string username, string picpath) {
    SetUserTile(username, 0, picpath);
}
"@

#Grab the user that's currently logged in (I wan tthe domain as well)
$DomainAndUser = (Get-WmiObject Win32_ComputerSystem).UserName

#Now lets take just the user name
$JustUser = $DomainAndUser.Substring($DomainAndUser.IndexOf("\")+1)

#You can change $ImageFile if you're not going to use the AD attribute
$ImageFile = "$ENV:temp\ADuser.jpg"

##### Take out this section if you want to use a different source file - Start
Import-Module ActiveDirectory
$ADUser = Get-ADUser $JustUser -Properties thumbnailphoto
$ADUser.thumbnailphoto | Set-Content $ImageFile -Encoding byte
##### Take out this section if you want to use a different source file - End

Add-Type -MemberDefinition $code -NameSpace DMD -Name ChangeUserTile
[DMD.ChangeUserTile]::ChangeUserPicture($DomainAndUser,$ImageFile)

