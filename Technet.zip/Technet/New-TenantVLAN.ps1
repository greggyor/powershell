﻿#requires -Module "VirtualMachineManager"

# Common Input — Required
$ServerName          = "VMM.Corp.Contoso.Com"
$LNDName             = "Datacenter"

# Common Input — Optional
# This is required only if we are going to use VMM for IP Address assignment.
# Otherwise these properties do not really matter and can be set to anything.
# Though it is best to define them anyway for reporting and visibility purposes
$FabricDNSSuffix     = "Fabric.Nprod2.com"
$TenantBaseDNSSuffix = "Tenant.Nprod2.com"

# Custom Input: Network — Required
$VLANID              = 3000

# Custom Input: Network — Optional
# This is required only if we are going to use VMM for IP Address assignment.
# Otherwise these properties do not really matter and can be set to anything.
# Though it is best to define them anyway for reporting and visibility purposes
$SubnetAddress       = [System.Net.IPAddress]"192.168.0.0"
$SubnetPrefix        = 24

# Custom Input: Tenant — Optional
# This is required only if we are going to use VMM for IP Address assignment.
# Otherwise these properties do not really matter and can be set to anything.
# Though it is best to define them anyway for reporting and visibility purposes
$TenantName          = "MyTenant"


# Calculate subnet borders and reserved address
# Note: portions of this code are borrowed from
# http://www.itadmintools.com/2011/08/calculating-tcpip-subnets-with.html

Function ConvertTo-BinaryIP ($DottedDecimalIP)
{
    (
        $DottedDecimalIP.Split(".") | 
            ForEach-Object -Process {
                [Convert]::toString($PSItem,2).padLeft(8,"0")
            }
    ) -join ""
}

Function ConvertTo-DottedDecimalIP ($BinaryIP)
{
    $DottedDecimalArray = @()
    For ($i = 0; $i -le 24; $i+=8)
    {
        $DottedDecimalArray += [Convert]::toInt32($BinaryIP.Substring($i,8),2)
    }
    $DottedDecimalArray -join "."
}

$SubnetAddressBinary = ConvertTo-BinaryIP($SubnetAddress.ToString())

$AddressGateway      = 
    [System.Net.IPAddress](ConvertTo-DottedDecimalIP $(
        $SubnetAddressBinary.substring(0,$SubnetPrefix).padright(31, "0") + "1"
    ))

$AddressDNSServer1   = 
    [System.Net.IPAddress](ConvertTo-DottedDecimalIP $(
        $SubnetAddressBinary.substring(0,$SubnetPrefix).padright(30, "0") +"10"
    ))

$AddressLast         = 
    [System.Net.IPAddress](ConvertTo-DottedDecimalIP $(
        $SubnetAddressBinary.substring(0,$SubnetPrefix).padright(31, "1") + "0"
    ))

$AddressBroadCast    = 
    [System.Net.IPAddress](ConvertTo-DottedDecimalIP $(
        $SubnetAddressBinary.substring(0,$SubnetPrefix).padright(32, "1")
    ))

# (End of borrowed code).


$SubnetInfo = @"
IP Pool properties
Subnet:         $SubnetAddress
Gateway:        $AddressGateway
1st DNS Server: $AddressDNSServer1
Last Address:   $AddressLast
Broadcast:      $AddressBroadCast
"@

Write-Verbose -Message $SubnetInfo


# Define internal variables

$Server = Get-SCVMMServer -ComputerName $ServerName
                        
$GetSCLogicalNetworkDefinitionParam = @{
    VMMServer = $Server
    Name      = $LNDName
}
$LND = Get-SCLogicalNetworkDefinition @GetSCLogicalNetworkDefinitionParam

$LogicalNetwork = $LND.LogicalNetwork


# Create Subnet-VLAN definition

$SubnetID = "$SubnetAddress/$SubnetPrefix"
        
$NewSCSubnetVLanParam = @{
    VMMServer = $Server
    Subnet    = $SubnetID
    VLanID    = $VLANID
}
$SubnetVLAN = New-SCSubnetVLan @NewSCSubnetVLanParam


# Update Logical Network Definition (LND)
# [also known in the UI (VMM Console) as a “Network Site”]
# This can be done in advance
# when actual VLAN is provisioned to the physical network gear.

$AllSubnetVLAN = @($LND.SubnetVLans) + $SubnetVLAN

$SetSCLogicalNetworkDefinitionParam = @{
    LogicalNetworkDefinition = $LND
    SubnetVLan               = $AllSubnetVLAN
}
Set-SCLogicalNetworkDefinition @SetSCLogicalNetworkDefinitionParam | Out-Null


# Build properties for IP Subnet and VM Network

# If we are going to use VMM for IP Address assignment
# the following should take place immediately before we provision a Tenant
# because some of the properties are specific to the Tenant name
# (and maybe to the Tenant preferred settings like Domain name or DNS servers)

# Otherwise we can do it in advance, e.g. immediately after we add the Subnet.
# In this case no properties really matter.
# Though it is best to define them anyway for reporting and visibility purposes

$IPPoolName = "VLAN " + $VLANID + " — Tenant " + $TenantName

# Define Gateways
$NewSCDefaultGatewayParam = @{
    VMMServer = $Server
    IPAddress = $AddressGateway
    Automatic = $True
}
$Gateway = New-SCDefaultGateway @NewSCDefaultGatewayParam
$AllGateway = @($Gateway)

# Define DNS servers 
$AllDnsServer = @($AddressDNSServer1)

# Define the Tenant DNS Suffix
$DNSSuffix = $TenantName + "." + $TenantBaseDNSSuffix

# Define DNS Search List
$AllDnsSuffix = @($FabricDNSSuffix)

# Define WINS servers
$AllWinsServer = @()


# Create IP Pool
$NewSCStaticIPAddressPoolParam = @{
    VMMServer                = $Server
    Name                     = $IPPoolName
    LogicalNetworkDefinition = $LND
    Subnet                   = $SubnetID
    IPAddressRangeStart      = $AddressGateway
    IPAddressRangeEnd        = $AddressLast
    DefaultGateway           = $AllGateway
    DNSServer                = $AllDnsServer
    DNSSuffix                = $DNSSuffix
    DNSSearchSuffix          = $AllDnsSuffix
    WINSServer               = $AllWinsServer
    EnableNetBIOS            = $False
}
$IPPool = New-SCStaticIPAddressPool @NewSCStaticIPAddressPoolParam


# Create VM Network.
# This should be done immediately after we create the IP Pool. (See above).

# Otherwise, if there are multiple IP Pools provisioned in advance
# we cannot rely on “-AutoCreateSubnet”, and it would take additional work.

# The name is really important here.
# We will have to use it later to specify where VMs are connected to.

$VMNetworkName = "Tenant — " + $TenantName

$NewSCVMNetworkParam = @{
    VMMServer        = $Server
    Name             = $VMNetworkName
    LogicalNetwork   = $LogicalNetwork
    AutoCreateSubnet = $True
}
$VMNetwork = New-SCVMNetwork @NewSCVMNetworkParam