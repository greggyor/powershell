﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -version 2.0

<#
.SYNOPSIS 
    This Script can be used to list how many users are authenticated in a given Domain Controller.
.DESCRIPTION
	This Script can be used to list how many users are authenticated in a given Domain Controller.
.PARAMETER  <Day>
	Specifies the day you want to check, the default value is 1 if this parameter is not specified.
.EXAMPLE
    .\UsersAreAuthenticatedInDomainController.ps1
	
	User Name                Logon Times
	---------                -----------
	Contoso\Li                         1
	Contoso\CNV$                       1
	Contoso\LIAO$                      2

 	This command will list all of user account are authenticated in a given Domain Controller.
.EXAMPLE
    .\UsersAreAuthenticatedInDomainController.ps1 -Day 2
	
	User Name                Logon Times
	---------                -----------
	Contoso\Li                         1
	Contoso\CNV$                       1
	Contoso\LIAO$                      2
	Contoso\VIVI$                      3
	Contoso\JEF$                       3
	This command will list all of user account are authenticated in a given Domain Controller in two days.
.LINK
	http://technet.microsoft.com/library/hh849682.aspx
#>
Param
(
	[Parameter(Mandatory=$false)]
	[Alias('d')][Int32]$Day=1
)

$Date = [Math]::Abs($Day)
[String]$EventLogNames=@("Security")
[DateTime]$EventStartDate = (((Get-Date).addDays(-$Date).date))
[DateTime]$EventEndTime = (Get-Date)

$EventCritea = @{Id="4624"; Logname=$EventLogNames; StartTime=$EventStartDate; EndTime=$EventEndTime}

[regex]$RegexAccountName = "Account Name:\s+\w+.*"
[regex]$RegexDomainName = "Account Domain:\s+\w+.*"


$WinEvent = Get-WinEvent -ComputerName $Env:COMPUTERNAME -FilterHashTable $EventCritea

$WinEvent| Foreach-Object{
$DomainName = ($RegexDomainName.match($_.message).value).Split(":")[1].Trim()
$AccountName = ($RegexAccountName.match($_.message).value).Split(":")[1].Trim()
"$DomainName\$AccountName"
}|Group-Object -NoElement|Select-Object @{Expression={$_.Name};Name="User Name"},
@{Expression={$_.count};Name="Logon Times";}|Sort-Object -Property "Logon Times"|Format-Table -AutoSize