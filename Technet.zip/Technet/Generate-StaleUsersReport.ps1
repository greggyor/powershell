﻿<#
	.SYNOPSIS
	Create HTML e-mail report of stale users based on input parameters

	.DESCRIPTION
	Find all users in a given OU who have not authenticated to the domain in a given number of days or have never authenticated to domain. Script uses both the lastLogonTimestamp and pwdLastSet attributes of the user object to determine when the user last authenticated. E-mail settings are configurable within script.
	NOTE: This is not real-time data!

	.PARAMETER OU
	Active Directory Organizational Unit to restrict search. Needs to be in LDAP syntax, (ex. "OU=Department,DC=domain,DC=com"). Entire domain can be searched using "DC=domain,DC=com" syntax.

	.PARAMETER NumberOfDays
	Script will return users who have not authenticated since this date. DateTime object. Defaults to 90 days ago.
	
	.PARAMETER LogFilePath
	Path to directory where log file will be placed. Defaults to "C:\Scripts\Logs\StaleUsers"

	.EXAMPLE
	.\Generate-StaleUsersReport.ps1 -OU "DC=Domain,DC=COM"
	
	Searches entire domain for users who have not authenticated within the last 90 days
	
	.EXAMPLE
	.\Generate-StaleUsersReport.ps1 -OU "DC=Domain,DC=COM" -NumberOfDays (Get-Date).AddDays(-120) -LogfilePath "C:\temp"
	
	Searches entire domain for users who have not authenticated within the last 120 days. It saves the log file in C:\temp

	.NOTES
		NAME:  Generate-StaleUsersReport.ps1
		AUTHOR: Charles Downing
		LASTEDIT: 02/18/2013
		KEYWORDS:
	.LINK
	http://blogs.technet.com/b/askds/archive/2009/04/15/the-lastlogontimestamp-attribute-what-it-was-designed-for-and-how-it-works.aspx
#>

Param(
	[Parameter(position=1)][string]$OU = "DC=DOMAIN,DC=COM",
	[DateTime]$NumberOfDays = (Get-Date).AddDays(-90),
	[string]$LogfilePath = "C:\Scripts\Logs\StaleUsers"
)

$NumberOfDaysTS = $NumberOfDays.ToFileTime()
$Logfile = "{0}\{1}_StaleUsers.log" -f $LogfilePath, (Get-Date -Format yyyyMMdd_hhmmsstt)
$ScriptName = [system.io.path]::GetFilenameWithoutExtension($MyInvocation.MyCommand.Path)
$date = Get-Date -Format d
$MAIL_SERVER = "mail.domain.com"
$FROM_ADDR = "scripts@domain.com"
$TO_ADDR = "user1@domain.com"
$EMAIL_SUBJECT = "Stale users in AD - $date"
$STYLE = "
		<STYLE> 
			BODY { 
				font-family: Verdana, Arial, Helvetica, sans-serif;
				font-size: 12px;
			}
			TABLE { 
				border-width: 1px; 
				border-style: solid; 
				border-color: black; 
				border-collapse: collapse; 
			}
			TH { 
				border-width: 1px;
				padding: 5px;
				border-style: solid;
				border-color: black;
				background-color: #005DAB;
				color: #FFFFFF 
			}
			TD { 
				border-width: 1px;
				padding: 5px;
				border-style: solid;
				border-color: black;
				background-color: #D2E6F4 
			}
			.sizeRed { 
				background-color: Red 
			}
			.sizeYellow { 
				background-color: Yellow
			}
			.summaryHeading {
				font-style: italic;
				font-weight: bold;
				background-color: #A0A0A0;
			}
			.summaryLine {
				background-color: #A0A0A0;
				text-align: right;
			}
		</STYLE>"

# adapted from http://stackoverflow.com/questions/7834656/create-log-file-in-powershell
Function LogWrite
{
   	Param (
   		[Parameter(position=0)][string]$logstring,
		[Parameter(position=1)][int]$severity = 0
	)
	
	switch ($severity)
	{
		0
		{
			$severityStr = "INFO"
		}
		1
		{
			$severityStr = "WARNING"
		}
		2
		{
			$severityStr = "ERROR"
		}
		3
		{
			$severityStr = "CRITICAL"
		}
	}
	
	$logEntry = "{0} - {1}: {2}" -f (Get-Date -Format u), $severityStr, $logstring

	Add-content $Logfile -value $logEntry 
}

Function SendHTMLEmail
{
	Param(
		[array]$staleUsers
	)
	
	LogWrite "Creating e-mail" 0
	$staleUsers_html = $staleUsers | Sort-Object LastLogonTime | ConvertTo-Html -Fragment
		
	$htmlBody = "
	<HTML>
		<HEAD>
			$STYLE
		</HEAD>
		<BODY>
			The following users last authenticated to the domain on or before $(Get-Date -Date $NumberOfDays -Format d)`:<BR>
			<BR>
			$staleUsers_html<BR>"
	$htmlBody += "
			<BR><small><small>Report located on Server01: $ScriptName</small></small>
		</BODY>
	</HTML>
	"

	LogWrite "Sending e-mail to $TO_ADDR from $FROM_ADDR at $(Get-Date -format g)" 0
	try
	{
		Send-MailMessage -From $FROM_ADDR -To $TO_ADDR -Subject $EMAIL_SUBJECT -Body $htmlBody -SmtpServer $MAIL_SERVER -BodyAsHtml -ErrorAction SilentlyContinue
		if(!$?)
		{
			throw $error[0].Exception
		}
	}
	catch [System.Exception]
	{
		LogWrite "E-mail not sent successfully: $_" 3
		Write-Host "Exception thrown: $_" -ForegroundColor Red
	}
}

if(!(Test-Path -Path $LogfilePath -PathType Container))
{
	New-Item -ItemType Directory -Path $LogfilePath
}

LogWrite "----- Processing started by $env:username -----" 0

$LDAPOU = "LDAP://{0}" -f $OU
if([adsi]::Exists($LDAPOU))
{
	try
	{
		LogWrite "Generating list of enabled users where lastLogonTimestamp and pwdLastSet attributes are older than $NumberOfDays" 0
		$staleUsers = Get-ADUser `
			-SearchBase $OU `
			-filter {(lastLogonTimestamp -notlike "*" -OR lastLogonTimestamp -le $NumberOfDaysTS) -AND (pwdLastSet -le $NumberOfDaysTS) -AND (Enabled -eq $True)} `
			-Properties lastLogonTimestamp, pwdLastSet | 
			Select-Object `
				Name, `
				SamAccountName, `
				@{Expression={if($_.lastLogonTimestamp -ne $null) {[datetime]::FromFileTime($_.lastLogonTimestamp)}};Label="LastLogonTime"},`
				@{Expression={if(($_.pwdLastSet -ne $null) -and ($_.pwdLastSet -ne 0)) {[datetime]::FromFileTime($_.pwdLastSet)}};Label="PwdLastSetTime"}
		LogWrite "List generated" 0
	}
	catch [System.Exception]
	{
		LogWrite $_.Exception.Message 3
		Write-Host "Exception thrown: $_" -ForegroundColor Red
	}
}
else
{
	LogWrite "OU does not exist: $LDAPOU" 3
	Write-Host "OU does not exist: $LDAPOU" -ForegroundColor Red
}

if($staleUsers -ne $null)
{
	SendHTMLEmail $staleUsers
}
LogWrite "----- Processing complete -----" 0