<#
	.SYNOPSIS
		Get list of mailboxes for users in a given OU
	.DESCRIPTION
    	List display name, primary SMTP address, and list of alternate e-mail addresses for each user in an Active Directory Organizational Unit who also has an Exchange mailbox.
	.PARAMETER OrganizationalUnit
		LDAP query for OU to run script against. Exampl: "LDAP://OU=orgUnit,DC=domain,DC=com"
	.INPUTS
		Array of string objects representing LDAP queries of OUs to be processed
	.OUTPUTS
		Array of mailbox objects containing OrganizationalUnit, DisplayName, PrimarySmtpAddress, and list of alternate SMTP addresses
	.EXAMPLE
    	.\Get-MailboxesPerOU.ps1 -OrganizationalUnit "LDAP://OU=NETSRV,OU=BLUES,OU=Company,DC=domain,DC=COM"
		OrganizationalUnit            DisplayName       PrimarySmtpAddress          EmailAddresses
		------------------            -----------       ------------------          --------------
		domain.com/Company/BLUES/NE... Mailbox User 1	mailboxuser1@domain.com		mailboxuser1@domain.com
		domain.com/Company/BLUES/NE... Mailbox User 2   mailboxuser2@domain.com     mailboxuser2@domain.com
		domain.com/Company/BLUES/NE... Mailbox User 3   mailboxuser3@domain.com     {user3@domain.com, Mailbo...
		domain.com/Company/BLUES/NE... backup test      backuptest@domain.com       {backuptest@migrate.bcb...
		domain.com/Company/BLUES/NE... testmail01       testmail01@domain.com       {testmail01@migrate.domain...
		domain.com/Company/BLUES/NE... testmail03       testmail03@domain.com       {testmail03@migrate.domain...
		domain.com/Company/BLUES/NE... archiveview      archiveview@domain.com      {archiveview@migrate.domai...
	.EXAMPLE
		.\Get-MailboxesPerOU.ps1 -OrganizationalUnit "LDAP://OU=NETSRV,OU=BLUES,OU=Company,DC=domain,DC=COM" | fl

		OrganizationalUnit : domain.com/Company/BLUES/NETSRV
		DisplayName        : Mailbox User 1
		PrimarySmtpAddress : mailboxuser1@domain.com
		EmailAddresses     : mailboxuser1@domain.com

		OrganizationalUnit : domain.com/Company/BLUES/NETSRV
		DisplayName        : Mailbox User 2
		PrimarySmtpAddress : mailboxuser2@domain.com
		EmailAddresses     : mailboxuser2@domain.com

		OrganizationalUnit : domain.com/Company/BLUES/NETSRV
		DisplayName        : Mailbox User 3
		PrimarySmtpAddress : mailboxuser3@domain.com
		EmailAddresses     : {user3@domain.com, mailboxuser3@domain.com}
	.NOTES
		NAME:  Get-MailboxesPerOU.ps1
		AUTHOR: Charles Downing
		LASTEDIT: 06/18/2012
		KEYWORDS:
	.LINK
#>

Param
(
	[Parameter(ValueFromPipeline=$true,Position=0,Mandatory=$true)][string]$OrganizationalUnit = ""
)

BEGIN
{
	# Add Exchange Admin module
	If ((Get-PSSnapin | where {$_.Name -match "Exchange.Management"}) -eq $null)
	{
		Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin
	}

	function Get-OU
	{
		# Set filter to return results for OUs only
		$searcher = [adsisearcher]"(objectClass=organizationalUnit)"
		# Parent OU to search under
		$searcher.SearchRoot = [adsi]$OrganizationalUnit
		$ounames = $searcher.FindAll()

		return $ounames
	}
}

PROCESS
{
	$AllMailboxes = @()
	foreach ($ou in Get-OU)
	{
		# Run Get-Mailbox cmdlet for each OU in parent OU and return only those users in that OU with mailboxes
		$temp = Get-Mailbox -OrganizationalUnit $ou.Properties.distinguishedname[0] -ResultSize Unlimited |
			Select-Object OrganizationalUnit, DisplayName,PrimarySmtpAddress, @{Name=�EmailAddresses�;Expression={$_.EmailAddresses | 
				Where-Object {$_.PrefixString -eq �smtp�} | 
				ForEach-Object {$_.SmtpAddress}}}
		
		# Save mailboxes in OU to array
		$AllMailboxes += $temp
	}
	$AllMailboxes
}
