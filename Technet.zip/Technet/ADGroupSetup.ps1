﻿Param(
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVClusterName,
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVObjectADGroupSamName
)

# Add and import needed features
if ((Get-WindowsFeature | ? Name -Like "RSAT-AD-PowerShell") | ? InstallState -NotLike Installed)
{
    Install-WindowsFeature "RSAT-AD-PowerShell"
}
if ((Get-WindowsFeature | ? Name -Like "RSAT-Clustering-PowerShell") | ? InstallState -NotLike Installed)
{
    Install-WindowsFeature "RSAT-Clustering-PowerShell"
}
Import-Module -Name ActiveDirectory
Import-Module -Name FailoverClusters

# Check for group and create if necessary
$adGroup = @()
$adGroup = Get-ADGroup -Filter {samAccountName -eq $HyperVObjectADGroupSamName}
if ($adGroup.Count -ne 1)
{
    $adGroup = New-ADGroup -DisplayName $HyperVObjectADGroupSamName -Name $HyperVObjectADGroupSamName -SamAccountName $HyperVObjectADGroupSamName -GroupScope Global -GroupCategory Security -PassThru
}

# Build array of Hyper-V servers
$HyperVNodes = (Get-ClusterNode -Cluster $HyperVClusterName).Name | Get-ADComputer

# Add nodes to group if not already members
for ($i = 0; $i -lt $HyperVNodes.Count; $i++)
{
    if (!(Get-ADGroupMember $adGroup | ? Name -ieq $HyperVNodes[$i].Name))
    {
        Add-ADGroupMember $adGroup -Members $HyperVNodes[$i]
    }
}

# Add Hyper-V cluster object to group if not already present
if (!(Get-ADGroupMember $adGroup | ? Name -ieq $HyperVClusterName))
{
    Add-ADGroupMember $adGroup -Members (Get-ADComputer $HyperVClusterName)
}
