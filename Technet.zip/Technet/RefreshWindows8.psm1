﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 3.0

Function Set-OSCRefreshReImage
{
<#
 	.SYNOPSIS
        Set-OSCRefreshReImage is an advanced function which can be used to set the active recovery image.
    .DESCRIPTION
         Set-OSCRefreshReImage is an advanced function which can be used to set the active recovery image.
    .PARAMETER  Path
		Specifies the path to set image file. The parameter is required.
    .EXAMPLE
        C:\PS> Set-OSCRefreshReImage C:\RefreshImage

		This command set the active recovery image to the CustomRefresh.wim file in the location by the "C:\RefreshImage" Folder.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory,Position=0)]
        [String]$Path,
		[Parameter(Mandatory=$false,Position=1)]
		[String[]]$ComputerName = $Env:COMPUTERNAME
    )

	Foreach($CN in $ComputerName)
	{
		#Connecting test
		$PingResult = Test-Connection -ComputerName $CN -Count 1 -Quiet
		If($PingResult)
		{
			If (Test-Path -Path $Path)
		    {
				$FileExtension = Get-ChildItem -Path $Path | ForEach-Object{$_.Extension -eq ".wim"}
				If($FileExtension)
				{
					Write-Host "Setting the current custom recovery image..." -ForegroundColor Green
			        Invoke-Expression -Command "recimg /setcurrent $Path"
				}
				Else
				{
					Write-Warning "Can not find *.wim file in $Path."
				}
		    }
		    Else
		    {
		        Write-Warning "Cannot find path '$Path' because it does not exist."
		    }
		}
		Else
		{
			Write-Host "Failed to connect to $CN!, Please make sure your connectivity is unobstructed." -ForegroundColor Yellow
		}
	}
}