﻿#Add Exchange 2010 snapin and set the scope to see entire forest 
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue 
Set-ADServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue 

#Move required files on each Mailbox Server and create Schedule task for Alert
$MBServers = Get-MailboxServer | Select-Object Name | Format-Table -HideTableHeaders | Out-String -Stream | Where-Object {$_.Trim() -ne ""} | foreach {$_.TrimEnd()}

foreach ($MBServer in $MBServers)
{
    If (Test-Path "\\$MBServer\C$\ProgramData\DBMoveAlert") {Remove-Item -Path "\\$MBServer\C$\ProgramData\DBMoveAlert" -Recurse -Force}
    schtasks.exe /delete /S $MBServer /TN "Event Viewer Tasks\Application_MSExchangeRepl_3169_byScript" /F
}
Write-Host " "
Write-Host "Press any key to Exit..." -ForegroundColor Yellow
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
