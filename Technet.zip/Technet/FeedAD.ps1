################################################################################################
##           Author: Vikas Sukhija                   
##           Date: 07-10-2012                                                                                                                    
##           Description:- This script is used for feeding data to AD attributes                                                              
#################################################################################################

# Import CSV file that is populated with user id & email address

$now=Get-Date -format �dd-MMM-yyyy HH:mm�

# replace : by -

$now = $now.ToString().Replace(�:�, �-�)

$data = import-csv $args[0]

# Loop thru the data from CSV

foreach ($i in $data)

{

$userobject = get-qaduser $i.userid -IncludedProperties �Co�,�C� 

$Address = $userobject.StreetAddress
$City = $userobject.City
$Country = $userobject.co
$Zip = $userobject.PostalCode
$State = $userobject.StateOrProvince
$Phone = $userobject.telephoneNumber

if ($Address -like $null)
{

# adding log to check current  address is blank

Write-host $userobject has blank Physical address

$Log1 = �C:\scripts\MergerScript\BlankAddress� + $now + �.log�

Add-content  $Log1 �$userobject has blank Physical address�

# If address is Blank then populate the address from the csv file

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{StreetAddress = $i.PhysicalAddress.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Address = $userobject.StreetAddress

Write-host $userobject has $Address as Physical address

$Log3 = �C:\scripts\MergerScript\SetAddress� + $now + �.log�

Add-content  $Log3 �For $userobject $Address as address has been set�

} 

else

{

# adding log to check current address is not blank , then address will not be updated.

$Log2 = �C:\scripts\MergerScript\Currentaddress� + $now + �.log�
Write-host $userobject has $Address as Current Physical address

Add-content  $Log2 �$userobject already has $Address as address�

}

# As done above same needs to be done with other parameters

if ($City -like $null)
{
Write-host $userobject has blank City

$Log1 = �C:\scripts\MergerScript\BlankCity� + $now + �.log�

Add-content  $Log1 �$userobject has blank City�
Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{l = $i.City.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$City = $userobject.City

Write-host $userobject has $City as City

$Log3 = �C:\scripts\MergerScript\SetCity� + $now + �.log�

Add-content  $Log3 �For $userobject $City as city has been set�

} 

else

{

$Log2 = �C:\scripts\MergerScript\CurrentCity� + $now + �.log�
Write-host $userobject has $City as Current City

Add-content  $Log2 �$userobject already has $City as City�

}
if ($Country -like $null)
{
Write-host $userobject has blank Country

$Log1 = �C:\scripts\MergerScript\BlankCountry� + $now + �.log�

Add-content  $Log1 �$userobject has blank Country�
Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{co = $i.Country.Trim()}

Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{C = $i.CountryCode.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Country = $userobject.CO

Write-host $userobject has $Country as Country

$Log3 = �C:\scripts\MergerScript\SetCountry� + $now + �.log�

Add-content  $Log3 �For $userobject $Country as Country has been set�

} 

else

{

$Log2 = �C:\scripts\MergerScript\CurrentCountry� + $now + �.log�

Write-host $userobject already has $Country as Country

Add-content  $Log2 �$userobject already has $Country as Country�

}
if ($Zip -like $null)
{
Write-host $userobject has blank Zip

$Log1 = �C:\scripts\MergerScript\BlankZip� + $now + �.log�

Add-content  $Log1 �$userobject has blank Zip�
Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{PostalCode = $i.Zip.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Zip = $userobject.PostalCode

Write-host $userobject has $Zip as Zip

$Log3 = �C:\scripts\MergerScript\SetZip� + $now + �.log�

Add-content  $Log3 �For $userobject $Zip as Zip has been set�

} 

else

{

$Log2 = �C:\scripts\MergerScript\CurrentZip� + $now + �.log�

Write-host $userobject already has $Zip as Zip

Add-content  $Log2 �$userobject already has $Zip as Zip�

}
if ($State -like $null)
{
Write-host $userobject has blank State

$Log1 = �C:\scripts\MergerScript\BlankState� + $now + �.log�

Add-content  $Log1 �$userobject has blank State�
Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{st = $i.State.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$State = $userobject.st

Write-host $userobject has $State as State

$Log3 = �C:\scripts\MergerScript\SetState� + $now + �.log�

Add-content  $Log3 �For $userobject $State as State has been set�

} 

else

{

$Log2 = �C:\scripts\MergerScript\CurrentState� + $now + �.log�

Write-host $userobject already has $State as State

Add-content  $Log2 �$userobject already has $State as State�

}
if ($Phone -like $null)
{
Write-host $userobject has blank Phone

$Log1 = �C:\scripts\MergerScript\BlankPhone� + $now + �.log�

Add-content  $Log1 �$userobject has blank Phone�
Get-QADUser $i.userid | Set-QADUser -ObjectAttributes @{telephoneNumber = $i.OfficeTelephone.Trim()}

$userobject = get-qaduser $i.userid -IncludedProperties �CO�

$Phone = $userobject.telephoneNumber

Write-host $userobject has $Phone as Phone

$Log3 = �C:\scripts\MergerScript\SetPhone� + $now + �.log�

Add-content  $Log3 �For $userobject $Phone as Phone has been set�

} 

else

{

$Log2 = �C:\scripts\MergerScript\CurrentPhone� + $now + �.log�

Write-host $userobject already has $Phone as Phone

Add-content  $Log2 �$userobject already has $Phone as Phone�

}
}
######################################################################################################

