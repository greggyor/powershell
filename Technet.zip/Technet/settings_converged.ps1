##############################################################
#
# Copyright (c) Microsoft. All rights reserved.
# This code is licensed under the Microsoft Public License.
# THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
# ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
# IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
# PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
###############################################################

###############################################################
#
# Settings_converged.ps1
# -------------------------------------------------------------
#
# Defines a dictionary of configurable settings used throughout
# the Cloud Technologies Sample.
# Depends on the cloud.psm1 module
# 
###############################################################

<#
 .SYNOPSIS
 Defines a dictionary of configurable settings used throughout
 the Cloud Technologies Sample.
 
 .PARAMETER DCB
 Enables DCB settings for the sample. Default is software QOS. 
 
 .PARAMETER Spaces
 Enables Storage Spaces to manage storage server storage. 
 Default is non-Spaces configuration
 
 .OUTPUTS
 [hashtable] of settings for the Cloud Technologies sample 
 deployment scripts
#>

param([switch]$DCB, [switch]$spaces )

Set-StrictMode -Version 2.0

import-module .\Helper\Cloud.psm1 -Force -ErrorAction stop 
 
## Master Settings
$Domain       = 'HCP'  # just the domain name, not the FQDN
$DNSDomain    = 'hcp.com'
$Gateway      = '192.168.0.1'
$DNSServer    = '192.168.0.1'
$PrefixLength = 16
$DNSSuffix    = $DNSDomain

# Account whose credentials will be used to connect via CredSSP. 
# Gets full cluster access to both clusters. 
# Must be an administrator on all servers
$AdminAccount = "$Domain\Administrator" 

## Cluster settings
# Grants administrator rights to accounts that will use the clusters
$ClusterFullAccessList = (,$AdminAccount)

## HyperV cluster
$HyperVClusterName       = 'Converged'
$HyperVClusterAddress    = '192.168.2.117/16' # Virtual IP Static address of the cluster. 
                                            # CIDR prefix required. Passed to New-Cluster
$HVClusterIgnoreNetwork  = $Null # passed to New-Cluster

# Nodes of the Hyper-V compute cluster  
$HVNode = @{
    Node1 = @{
        Name = "HC2N1"
        Address = "192.168.2.111"
    }
    Node2 = @{
        Name = "HC2N2"
        Address = "192.168.2.112"       
        
    }
    Node3 = @{
        Name = "HC2N3"
        Address = "192.168.2.113"
    }
    Node4 = @{
        Name = "HC2N4"
        Address = "192.168.2.114"
    }
}

## Storage Cluster 
$StorageClusterName           = 'Storage-Cluster' 
$StorageClusterAddress        = '192.168.2.119/16'  # Virtual IP Static address of the cluster. 
                                                    # CIDR prefix required. Passed to New-Cluster
$StorageClusterIgnoreNetwork  = $Null # passed to New-Cluster

# The name of the scaleout file server role to be added to the storage cluster.
$FileServerName = 'ScaleoutFS' 

# Nodes of the file share storage cluster
$StorageNode = @{
    Node1 = @{
        Name    = "HC2N5"
        Address = "192.168.2.115"
        # non spaces config values
        QuorumDiskNumber  = '0' # Number string. Disk numbers may differ across machines. 
                                # (If using spaces, this will be used to set the quorum if $PreparedQuorumDiskEnabled = $True)
        VMShareDiskNumber    = '2' # if $SpacesSettingsEnabled = $false these will be used to create the fileshares on storage node 1
        VHDLibraryDiskNumber = '3' # These disks must be NTFS Formatted to be CSV
    }
    Node2 = @{
        Name    = "HC2N6"
        Address = "192.168.2.116"
        # non spaces config values
        QuorumDiskNumber = '0' # Number string. Disk numbers may differ across machines.  
                               # (If using spaces, this will be used to set the quorum if $PreparedQuorumDiskEnabled = $True)
    }
}

# Fileshares
# Define share that will hold VMS and VHDs
$VMShareDir = 'VMShare'
$VMShareName = $VMShareDir 

# A place for your base VHDs will be created on the fileserver with this SMB share name
$VHDlibraryShareDir   = 'VHDLibrary'
$VHDlibraryShareName  = $VHDlibraryShareDir  


## Storage Spaces settings
# Enable Storage Spaces to manage storage on the storage cluster. Edit or use the -spaces switch.
$SpacesSettingsEnabled = $Spaces 
               
# Storage Cluster Quorum settings
# Because the samples build the cluster one node at a time we must set the quorum.  
# A formatted disk that will be used for quorum on the storage cluster. 
# Overrides spaces quorum settings.
$PreparedQuorumDiskEnabled   = $false # Set $true if using a prepared nonspaces quorum disk with spaces config.
    
    # Spaces quorum settings:
    $ReserveQuorumEnabled    = $false # if $true and spaces are enabled one physical disk will not be added to the Storage Spaces storage pool.
                                      # it will be formatted and used as quorum for the storage cluster
    
    $SpacesQuorumDiskEnabled = $True # Create and use a spaces disk for Storage Cluster quorum    
    $QuorumVirtualDiskName   = 'QuorumDisk' # Specifies which Storage Spaces Virtual Disk will become quorum.  

# Storage Spaces pool
$SpacesBusType = 'SAS'
$ClusterStoragePoolName = 'ClusterStoragePool'

# Storage Spaces Virtual disks: name, size
$VMShareVDisk        = 'VMShareDisk',      (200 * 1GB)
$VMLibraryVDisk      = 'VMLibraryDisk',    (200 * 1GB)
$QuorumVDisk         = 'QuorumDisk',       (1 * 1gb)


## Networking
# Names of the Nic teams that will be created
$HosterNetNICTeamName = 'HosterNet'
$TenantNetNICTeamName = 'TenantNet'

# These must match the names on the actual network adapters on all nodes
$HosterNetTeamMembers = 'HosterNet 1', 'HosterNet 2'
$TenantNetTeamMembers = 'TenantNet 1', 'TenantNet 2'

# Virtual Switch
$TenantNetVirtualSwitchName = 'TenantSwitch' 

## flow control settings for DCB and QOS (These are only example values, not recommended settings)
$DCBEnabled = $DCB # Edit or use -DCB switch
$QOSEnabled = $True

$ClusterSubnetMatch = "192.168.2.0/16"

## DCB
$DCBFlowcontrol = 3

# Traffic classes
# SMB
$SMB_TC_BandwidthPercent = 40                                       
$SMB_TC_Priority = 3

# LiveMigration
$LiveMigration_TC_BandwidthPercent = 30
$LiveMigration_TC_Priority = 5

# Cluster
$Cluster_TC_BandwidthPercent = 20
$Cluster_TC_Priority = 4  

# DCB QOS Policy
$SMB_DCBQOSPolicy_Priority = 3
$LiveMigration_DCBQOSPolicy_Priority = 5
$Cluster_DCBQOSPolicy_Priority = 5

## QOS
# Software QOS settings if DCB is not supported
$Default_QOSPolicy_MinBandwidth = 50
$SMB_QOSPolicy_Priority = 3
$SMB_QOSPolicy_MinBandwidth = 100

$LiveMigration_QOSPolicy_Priority = 5
$LiveMigration_QOSPolicy_MinBandwidth = 50 
                        
$Cluster_QOSPolicy_Priority = 5  
$Cluster_QOSPolicy_MinBandwidth = 100  

# End customizable settings. 
# To customize node names, IPs etc just edit the top section. 
# To change the number of nodes/clusters to a different configuration you will need to edit the bottom.
#######################################################################################################################################

$HVMachineAccessList          = $HVnode[ $HVNode.keys ] | % { '{0}\{1}$' -f $Domain, $_.Name }
$ClusterMachineAccountString  = '{0}\{1}$' -f $Domain, $HyperVClusterName

# Per-cluster settings
$Cluster = @{ 
    HyperV = @{
        Name = $HyperVClusterName
        StaticAddress = $HyperVClusterAddress
        ClusterAccess = @(ClusterAccess -User @($ClusterFullAccessList) -Full)
        
        QuorumDiskNumber = $HVNode[ $HVNode.keys ] | 
            foreach -begin { $QuorumDiskNumber = @{} } -process { 
                $QuorumDiskNumber[$_['name']] = $_['QuorumDiskNumber'] 
                }   -end { $QuorumDiskNumber }
                
        SpaceSettings = $Null
        
    } # End of Hyperv

    Storage = @{
        Name = $StorageClusterName
        StaticAddress = $StorageClusterAddress       
        FileServerName = $FileServerName
        ClusterAccess = @(ClusterAccess -User @($ClusterFullAccessList) -Full)
        
        QuorumDiskNumber = $StorageNode[ $StorageNode.keys ] | 
            foreach -begin { $QuorumDiskNumber = @{} } -process { 
                $QuorumDiskNumber[$_['name']] = $_['QuorumDiskNumber'] 
                } -end { $QuorumDiskNumber }
                
        PreparedQuorumDiskEnabled = $PreparedQuorumDiskEnabled
        SpacesSetting = if( $SpacesSettingsEnabled )
            { 
                SpacesSetting -Friendlyname $ClusterStoragePoolName `
                -Bustype $SpacesBusType `
                -ReserveQuorum $ReserveQuorumEnabled `
                -QuorumVirtualDisk $QuorumVirtualDiskName `
                -VirtualDisk @( 
                    VirtualDisk @VMShareVDisk  
                    VirtualDisk @VMLibraryVDisk    
                    if( (-not $PreparedQuorumDiskEnabled ) -and (-not $ReserveQuorumEnabled) -and $SpacesQuorumDiskEnabled )
                    { 
                        VirtualDisk @QuorumVDisk 
                    }
                )   
             } 
             else 
             { 
                $null 
             }
                        
        FileShare =  @(
            if( $SpacesSettingsEnabled )
            {
                # Define the vmshare. Continuously available storage for clustered VMs for Hyper-V over SMB2
                Fileshare -name $VMShareName -VDiskFriendlyName $VMShareVDisk[0] -SubPath $VMShareDir `
                    -fullaccess (@($HvMachineAccessList) + $AdminAccount, 'Administrators', $ClusterMachineAccountString, "System") 
                
                # Define the library disk share
                Fileshare -name $VHDLibraryShareName -VDiskFriendlyName $VMLibraryVDisk[0] -SubPath $VHDlibraryShareDir `
                    -fullaccess (@($HvMachineAccessList) + $AdminAccount, 'Administrators', $ClusterMachineAccountString, "System")
                    
            }
            else
            {
                # define the vmshare
                Fileshare -name $VMShareName -DiskNumber $StorageNode.Node1.VMShareDiskNumber -SubPath $VMShareDir `
                    -fullaccess (@($HvMachineAccessList)  + $AdminAccount, 'Administrators',$ClusterMachineAccountString, "System") 
                      
                # define the library disk share
                Fileshare -name $VHDLibraryShareName -DiskNumber $StorageNode.Node1.VHDLibraryDiskNumber -SubPath $VHDlibraryShareDir `
                    -fullaccess (@($HvMachineAccessList) + $AdminAccount, 'Administrators', $ClusterMachineAccountString, "System") 
            }
            
        )# End of FileShare
    } # End of Storage
} # End of Cluster
  
  # Common Throughput Settings
$ThroughputSetting = @{ 
    DCBEnabled = $DCBEnabled  
    QOSEnabled = $QOSEnabled
    DCB = ThroughputSetting -DCB `
            -NetQOSFlowControlPriority $DCBFlowcontrol `
            -NetQOSTrafficClass @(

                                NetQOSTrafficClass -Name SMB `
                                    -Algorithm ETS `
                                    -BandwidthPercentage $SMB_TC_BandwidthPercent `
                                    -Priority $SMB_TC_Priority 
                                NetQOSTrafficClass -Name LiveMigration `
                                    -Algorithm ETS `
                                    -BandwidthPercentage $LiveMigration_TC_BandwidthPercent `
                                    -Priority $LiveMigration_TC_Priority
                                NetQOSTrafficClass -Name Cluster `
                                    -Algorithm ETS `
                                    -BandwidthPercentage $Cluster_TC_BandwidthPercent `
                                    -Priority $Cluster_TC_Priority

                                  ) `
            -NetQOSPolicy @(
                                NetQOSPolicy -Name SMB `
                                    -SMB `
                                    -PriorityValue8021Action $SMB_DCBQOSPolicy_Priority
                                NetQOSPolicy -Name LiveMigration `
                                    -LiveMigration `
                                    -PriorityValue8021Action $LiveMigration_DCBQOSPolicy_Priority
                                NetQOSPolicy -Name Cluster `
                                    -IPDstPrefixMatchCondition $ClusterSubnetMatch `
                                    -PriorityValue8021Action $Cluster_DCBQOSPolicy_Priority 

                            )
                             
    QOS = ThroughputSetting -QOS `
            -NetQOSPolicy @(
                                NetQOSPolicy -Name Default `
                                    -Default `
                                    -MinBandwidthWeightAction $Default_QOSPolicy_MinBandwidth
                                NetQOSPolicy -Name SMB `
                                    -SMB `
                                    -PriorityValue8021Action $SMB_QOSPolicy_Priority `
                                    -MinBandwidthWeightAction $SMB_QOSPolicy_MinBandwidth
                                NetQOSPolicy -Name LiveMigration `
                                    -LiveMigration `
                                    -PriorityValue8021Action $LiveMigration_QOSPolicy_Priority `
                                    -MinBandwidthWeightAction $LiveMigration_QOSPolicy_MinBandwidth
                                NetQOSPolicy -Name Cluster `
                                    -PriorityValue8021Action $Cluster_QOSPolicy_Priority `
                                    -IPDstPrefixMatchCondition $ClusterSubnetMatch `
                                    -MinBandwidthWeightAction $Cluster_QOSPolicy_MinBandwidth
                            )
        }

# Hyper-V settings that must be set per node
$HyperVSetting = @{
    DefaultVHDPath = "\\$($Cluster.Storage.FileServerName)\$VMShareName"
    DefaultVMPath  = "\\$($Cluster.Storage.FileServerName)\$VMShareName"
   
    VirtualSwitch = @( VMSwitch  -Name $TenantNetVirtualSwitchName -NetAdapterName $TenantNetNICTeamName -AllowManagementOS $false )
}    
            
# Define nodes
$Node = @(      
        Node -name $HVnode.Node1.Name -type HyperV -cluster $Cluster.HyperV -HyperVsetting $HyperVSetting -FileServerName $FileServerName `
             -NetworkSetting (
                    NodeNetworksetting `
                        -configurationipaddress $HVnode.Node1.Address `
                        -ThroughputSetting $ThroughputSetting `
                        -NicTeam @(
                                        Nicteam -Name $HosterNetNICTeamName `
                                            -TeamMembers $HosterNetTeamMembers `
                                            -IPAddress $HVnode.Node1.Address `
                                            -PrefixLength $PrefixLength `
                                            -Gateway   $Gateway `
                                            -DNSServer $DNSServer `
                                            -DNSSuffix $DNSSuffix
 
                                        Nicteam -name $TenantNetNICTeamName `
                                            -TeamMembers  $TenantNetTeamMembers `
                                            -Unbind $true
                                   ) 
                                ) 
                            
        Node -Name $HVnode.Node2.Name -type HyperV -Cluster $Cluster.HyperV -HyperVsetting $HyperVSetting -FileServerName $FileServerName `
             -NetworkSetting (
                    NodeNetworksetting `
                        -configurationipaddress $HVnode.Node2.Address `
                        -ThroughputSetting $ThroughputSetting `
                        -NicTeam @(
                                        Nicteam -Name $HosterNetNICTeamName `
                                            -TeamMembers $HosterNetTeamMembers `
                                            -IPAddress $HVnode.Node2.Address `
                                            -PrefixLength $PrefixLength `
                                            -Gateway   $Gateway `
                                            -DNSServer $DNSServer `
                                            -DNSSuffix $DNSSuffix
                                            
                                        Nicteam -name $TenantNetNICTeamName `
                                            -TeamMembers $TenantNetTeamMembers `
                                            -Unbind $true
                                   ) 
                                ) 
                           
        Node -Name $HVnode.Node3.Name -type HyperV -cluster $Cluster.HyperV -HyperVsetting $HyperVSetting -FileServerName $FileServerName `
              -NetworkSetting (
                    NodeNetworksetting `
                        -configurationipaddress $HVnode.Node3.Address `
                        -ThroughputSetting $ThroughputSetting `
                        -NicTeam @(
                                        Nicteam -Name $HosterNetNICTeamName `
                                            -TeamMembers $HosterNetTeamMembers `
                                            -IPAddress $HVnode.Node3.Address `
                                            -PrefixLength $PrefixLength `
                                            -Gateway   $Gateway `
                                            -DNSServer $DNSServer `
                                            -DNSSuffix $DNSSuffix
                                            
                                        Nicteam -name $TenantNetNICTeamName `
                                            -TeamMembers $TenantNetTeamMembers `
                                            -Unbind $true
                                   ) 
                                )
                             
        Node -Name $HVnode.Node4.Name -Type HyperV -Cluster $Cluster.HyperV -HyperVsetting $HyperVSetting -FileServerName $FileServerName `
             -NetworkSetting (
                NodeNetworksetting `
                        -configurationipaddress $HVnode.Node4.Address `
                        -ThroughputSetting $ThroughputSetting `
                        -NicTeam @(
                                    Nicteam -Name $HosterNetNICTeamName `
                                        -TeamMembers $HosterNetTeamMembers `
                                        -IPAddress $HVnode.Node4.Address `
                                        -PrefixLength $PrefixLength `
                                        -Gateway   $Gateway `
                                        -DNSServer $DNSServer `
                                        -DNSSuffix $DNSSuffix
                                                           
                                   Nicteam -name $TenantNetNICTeamName `
                                        -TeamMembers $TenantNetTeamMembers `
                                        -Unbind $true
                                   ) 
                                ) 
                               
        Node -name $StorageNode.Node1.Name -type Storage -cluster $Cluster.Storage  -FileServerName $FileServerName `
            -NetworkSetting ( 
                NodeNetworksetting `
                    -configurationipaddress $StorageNode.Node1.Address `
                    -ThroughputSetting $ThroughputSetting `
                    -NicTeam @(
                                Nicteam -Name $HosterNetNICTeamName `
                                -TeamMembers $HosterNetTeamMembers `
                                        -ipaddress $StorageNode.Node1.Address `
                                        -PrefixLength $PrefixLength `
                                        -Gateway   $Gateway `
                                        -DNSServer $DNSServer `
                                        -DNSSuffix $DNSSuffix
                    )
            )
                                
        Node -name $StorageNode.Node2.Name -type Storage -cluster $Cluster.Storage  -FileServerName $FileServerName `
            -NetworkSetting ( 
                NodeNetworksetting -configurationipaddress $StorageNode.Node2.Address `
                    -ThroughputSetting $ThroughputSetting `
                    -NicTeam @(
                                Nicteam -Name $HosterNetNICTeamName `
                                -TeamMembers $HosterNetTeamMembers `
                                -ipaddress $StorageNode.Node2.Address `
                                -PrefixLength $PrefixLength `
                                -Gateway   $Gateway `
                                -DNSServer $DNSServer `
                                -DNSSuffix $DNSSuffix
                    )
            )                             
    )
   
# Dictionary of all settings
$Setting = @{ 

  # An account with admin permissions on all servers.
  AdminAccount = $AdminAccount
  
  # Cluster subdictionary    
  Cluster = $Cluster
  
  # Per node settings 
  Node = $node
}

return $Setting