#  Copyright (c) Microsoft Corporation.  All rights reserved.
#  
# THIS SAMPLE CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
# IF THIS CODE AND INFORMATION IS MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN
# CONNECTION WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER. 

Param
( 
    [parameter(Mandatory=$false, Position=1, HelpMessage="The name of a Remote Access server to read the configuration from.")][String] $ComputerName="localhost"
)

#
# Returns true if the local computer is Windows Server.
#
Function IsWindowsServer
{
    $windowsInfo = Get-WmiObject -Query "SELECT * FROM Win32_OperatingSystem WHERE ProductType=3"
    return [bool]$windowsInfo;
}

# Import the required PowerShell modules

Import-Module GroupPolicy -ErrorAction SilentlyContinue
Import-Module RemoteAccess -ErrorAction SilentlyContinue

if (-not (Get-Module RemoteAccess))
{
    if (IsWindowsServer)
    {
        throw 'The Windows Feature "RemoteAccess Management Tools" is not installed. (Run "Install-WindowsFeature -Name RSAT-RemoteAccess")'
    }
    else
    {
        throw 'The Windows Feature "RemoteAccess Management Tools" is not installed. (Install Remote Server Administration Tools and run "Enable-WindowsOptionalFeature -FeatureName RemoteServerAdministrationTools-Roles-RemoteAccess -Online")'
    }
}

#
# Prints an informational line to the console 
#
Function OutputLine([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message"
    
}

#
# Prints a success line to the console 
#
Function OutputSuccess([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message" -ForegroundColor Green

}

#
# Prints a warning line to the console 
#
Function OutputWarning([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message" -ForegroundColor Yellow
}

#
# Invokes the specified cmdlet while including the script's ComputerName parameter
#
Function InvokeCmdletWithComputerName($cmdlet)
{
    if ($ComputerName -ine "localhost")
    {
        # A remote computer name is specified, append the ComputerName parameter to the invoked expression using the ComputerName parameter provided for the script
        $cmdlet = $cmdlet + " -ComputerName $ComputerName"
    }
   
    return Invoke-Expression $cmdlet -ErrorAction SilentlyContinue
}

#
# Finds the closest writeable domain controller to a specified server
#
Function GetClosestWritableDc($server)
{
    # Run the method DomainController:FindOne on the remote server in order to retrieve the DC closest to the remote server.
    $dc = Invoke-Command -ComputerName $server -ScriptBlock {
        $context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain")
        [System.DirectoryServices.ActiveDirectory.DomainController]::FindOne($context, [System.DirectoryServices.ActiveDirectory.LocatorOptions]::WriteableRequired) 
    }
    
    return $dc.Name
}

#
# Checks if the address is a subset of the prefix given
#
Function IsSubset($Prefix, $Address)
{
    $PrefixAddr = $Prefix.Split('/')[0] + '1'
    $PrefixAddrBytes = [System.Net.IPAddress]::Parse($PrefixAddr).GetAddressBytes()
    $AddrBytes = [System.Net.IPAddress]::Parse($Address).GetAddressBytes()
    for ($i=0; $i -lt 8; $i++)
    {
        if($PrefixAddrBytes[$i] -ne $AddrBytes[$i])
        {
            return $false;
        }
    }
    return $true;
}
############################################################
#################### Script Begins Here ####################
############################################################
try
{
    OutputLine("Retrieving Remote Access deployment data from server `"$ComputerName`"...")
    $RAConfig = InvokeCmdletWithComputerName("Get-RemoteAccess")
    # Check if DirectAccess is installed on the server. 
    if (!$RAConfig -or $RAConfig.DAStatus -ine "Installed")
    {
        throw "DirectAccess is not configured on the server `"$ComputerName`". For the ComputerName parameter, specify the name or IP address of a server on which DirectAccess is configured." 
    }

    # Check if force tunnel is enabled on the server. 
    if($RAConfig.ForceTunnel -ine "Enabled")
    {
        throw "Force tunneling for DirectAccess is not enabled on the server `"$ComputerName`". This script is valid only for DirectAccess deployments with force tunneling enabled"
    }
    
    #Check if multi site is enabled
    try
    {
        $multisitedata = InvokeCmdletWithComputerName("Get-DAMultiSite")
    }
    catch
    {
        # Multisite is not deployed
        $multisitedata = $null
    }

    if($multisitedata)
    {
        throw "Multi Site is enabled on the server `"$ComputerName`". This script is valid only for single site DirectAccess deployments with force tunneling enabled"
    }

    #Check if load balancing is configured
    if($RAConfig.LoadBalancing -ine "NotConfigured")
    {
        throw "Load balancing is already configured on the server `"$ComputerName`". This script needs to be run before enabling load balancing"
    }

    OutputSuccess("Retrieved Remote Access deployment data from server `"$ComputerName`"")

    #Get closest DC
    OutputLine("Retrieving closest DC for server `"$ComputerName`"...")
    $closestDCName = GetClosestWritableDc($ComputerName)
    if (!$closestDCName)
    {
        throw "Failed to retrieve closest DC for server `"$ComputerName`""
    }
    OutputSuccess("Retrieved closest DC for server `"$ComputerName`" : `"$closestDCName`"")
    
    $ServerGPOName = $RAConfig.ServerGpoName.Split('\')[1]
    #Check if DTE1 belongs to iphttps prefix
    try
    {
        $DTE1 = Get-GPRegistryValue -Name $ServerGpoName -Key HKLM\software\policies\microsoft\windows\remoteaccess\config -ValueName DTE1 -Server $closestDCName
    }
    catch
    { 
        throw "Failed to read registry from `"$ServerGpoName`" GPO" 
    }

    if(IsSubset $RAConfig.ClientIPv6Prefix $DTE1.Value)
    {
        throw "This script is valid only for DirectAccess deployments with force tunneling enabled and the server is deployed with two network adapters and the Internet facing adapter has no public address"
    }

    #Set the DTE1 registry key
    OutputLine("Modifying the registry value on server `"$ComputerName`"...")
    $ipHttpsAddr = $RAConfig.ClientIPv6Prefix.Split('/')[0] + '1'
    $result = Set-GPRegistryValue -Name $ServerGPOName  -Key HKLM\Software\Policies\Microsoft\Windows\Remoteaccess\Config -ValueName DTE1 -Value $ipHttpsAddr -Type String -Server $closestDCName
    if(!$result)
    {
        throw "An error occurred while setting the GPO registry key"
    }
    OutputSuccess("The DTE1 registry value on the server GPO `"$ServerGPOName`" is set to $ipHttpsAddr")
    
    #Disable the Remote Access Configuration Task
    $result = Invoke-Expression "schtasks /change /tn \Microsoft\Windows\RemoteAccess\RaConfigTask /DISABLE /s $ComputerName"
    if($LASTEXITCODE -eq 0)
    {
        OutputSuccess("Disabled RemoteAccess configuration task on server `"$ComputerName`"")
    }
    else
    {
        OutputWarning("An error occured while disabling RemoteAccess configuration task on server `"$ComputerName`". Disable the scheduled task 'RaConfigTask' manually. To disable the task, open Task Scheduler, navigate to  Microsoft\Windows\RemoteAccess , select RaConfigTask and click Disable.")
    }
}
finally
{}
