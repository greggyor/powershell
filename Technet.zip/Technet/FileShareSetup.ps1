﻿Param(
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVClusterName,
    [Parameter(Mandatory=$true)]
    [string]
    $ScaleOutFSName,
    [Parameter(Mandatory=$true)]
    [string]
    $ShareName,
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVObjectADGroupSamName,
    [int]
    $CSVVolumeNumber = 1,
    [string]
    $VHDFolderName = "VHDs",
    [string]
    $VMFolderName = "VMs"
)

# Create the share folder
New-Item -ItemType Directory -Path C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName

# Create folders in share
New-Item -ItemType Directory -Path "C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName\$VHDFolderName"
New-Item -ItemType Directory -Path "C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName\$VMFolderName"

# Get the domain name
$DomainName = Get-Content env:userdnsdomain

# Grant the Hyper-V group permission
$cmdString = "ICACLS.EXE C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName  --% /Grant $DomainName\$HyperVObjectADGroupSamName"
$cmdString += ':(CI)(OI)F'
Invoke-Expression -Command $cmdString

# Grant domain admins permission
$DomainAdmins = "Domain Admins"
$cmdString = "ICACLS.EXE C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName"
$cmdString += '  --% /Grant "'
$cmdString += "$DomainName\$DomainAdmins"
$cmdString += ':(CI)(OI)F"'
Invoke-Expression -Command $cmdString

# Remove inheritance (optional)
ICACLS.EXE C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName  /Inheritance:R

# Create new share and set matching Share permissions
$FullAccess = ("$DomainName\$HyperVObjectADGroupSamName","$DomainName\Domain Admins")
New-SmbShare -Name $ShareName -Path C:\ClusterStorage\Volume$CSVVolumeNumber\$ShareName  -FullAccess $FullAccess