Function oldcomp
{

   BEGIN
   {

   }

    PROCESS
    {
   
       $Dname=$_.DistinguishedName
       $noofdays=[datetime]::now - [datetime]::fromfiletime($_.lastlogontimestamp)
       $cname=$_.name
       $totdays=$noofdays.days

         If($totdays -gt 180)
         {

               write-output "$cname,$Dname,$totdays"
          }

       }

       END     
       {
       
       }
}

get-adcomputer -filter * | get-adobject -properties lastlogontimestamp | oldcomp | out-file "c:\oldcomputers.csv"

