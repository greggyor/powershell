﻿#############################################################################################################################
##                                                                                                                         ##
##  Author: Geoffrey Stenta                                                                                                ##
##                                                                                                                         ##
##  Version:  1.0                                                                                                          ##
##                                                                                                                         ##
##  Date:  03/29/2012                                                                                                      ##
##                                                                                                                         ##
##  Purpose: Revised combination of the 3 individual scripts to locate and remove inactive accounts from AD.               ## 
##                                                                                                                         ##
#############################################################################################################################
add-pssnapin quest*  -EA SilentlyContinue                                                                                                    

new-item C:\Scripts\Exports -type directory  -EA SilentlyContinue

Function Show-Menu {

Param(
[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter your menu text")]
[ValidateNotNullOrEmpty()]
[string]$Menu,
[Parameter(Position=1)]
[ValidateNotNullOrEmpty()]
[string]$Title="Menu",
[switch]$ClearScreen
)

if ($ClearScreen) {Clear-Host}

#build the menu prompt
$menuPrompt=$title
#add a return
$menuprompt+="`n"
#add an underline
$menuprompt+="-"*$title.Length
$menuprompt+="`n"
#add the menu
$menuPrompt+=$menu

Read-Host -Prompt $menuprompt

} #end function

#define a menu here string
$menu=@"
1. Gather List of Inactive Accounts.

2. Disable Inactive Accounts.

3. Delete Disabled Accounts.

Q  Quit

Select a task by number or Q to quit
"@

#Keep looping and running the menu until the user selects Q (or q).
Do {
    #use a Switch construct to take action depending on what menu choice
    #is selected.
                Switch (Show-Menu $menu "Options to locate and remove inactive accounts" -clear) {
     "1" {Write-Host "Locating Inactive Accounts.  Please wait..." -ForegroundColor Yellow
            get-qaduser -inactive -DontUseDefaultIncludedProperties -include samaccountname -serializevalues -NotLoggedOnFor 60 -sizelimit 0 | 
            Export-csv C:\Scripts\Exports\inactive_users.csv
                } 
     
     "2" {Write-Host "Disabling Inactive Accounts.  Please wait..." -ForegroundColor Yellow
            import-csv C:\Scripts\Exports\inactive_users.csv | foreach{Get-QADUser $_.samaccountname | Disable-QADUser | Set-QADUser -UserPrincipalName "zzz$($_.userprincipalname)"}
                }
     
     "3" {Write-Host "Deleting Disabled Accounts.  Please wait..." -ForegroundColor Yellow
            import-csv C:\Scripts\Exports\inactive_users.csv | foreach{Get-QADUser $_.samaccountname | remove-QADObject -UserPrincipalName "zzz$($_.userprincipalname)"}
                }
     
     "Q" {Write-Host "Script Terminated" -ForegroundColor Yellow
         Return
         }
     
     Default {Write-Warning "Invalid Choice. Try again."
              sleep -milliseconds 750}
    } #switch
} While ($True)