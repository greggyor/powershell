#Global variables
$taskname = 'WakeTimer-Task'
$pgmpath = "SCHTASKS.exe"
$templatepath = "WakeTimer-Task.xml"
$criticallevel = 10

Function Create-Task 
{
    &$pgmpath /CREATE /TN "$taskname" /XML "$templatepath" /RU "NT Authority\System" /F
    $startdate = Get-Date -format "dd/MM/yyyy"
    $starttime = Get-Date -format "HH:mm"
    &$pgmpath /CHANGE /TN "$taskname" /SD "$startdate" /ST "$starttime" 
    Write-Host "Created Task ($taskname) successfully"
}

Function Delete-Task 
{
    Set-Variable -Name taskenabled -Value $false -Scope 1
    &$pgmpath /DELETE /TN "$taskname" /F
    Write-Host "Deleted task ($taskname) successfully"
}

Function Invoke-Standby 
{
    Write-Host "Invoke-Standby" (Get-Date)
    powercfg -h off
    &"$env:SystemRoot\System32\rundll32.exe" powrprof.dll,SetSuspendState hybrid sleep
}

Function Invoke-Hibernate 
{
    Write-Host "Invoke-Hibernate" (Get-Date)
    powercfg -h on
    &"$env:SystemRoot\System32\rundll32.exe" powrprof.dll,SetSuspendState Hibernate
}

Function Check-BatteryCharge 
{
    param($computername=$env:computername)
    return (Get-WmiObject -Class Win32_Battery -ea 0).EstimatedChargeRemaining
}

Function Check-BatteryState 
{
    param($computername=$env:computername)
    $status = (Get-WmiObject -Class Win32_Battery -ea 0).BatteryStatus
    if($status) 
    {
        switch ($status)
        {
            1 { "Discharging" }
            2 { "NotDischarging" }
            3 { "FullyCharged" }
            4 { "Low" }
            5 { "Critical" }
            6 { "Charging" }
            7 { "ChargingAndHigh" }
            8 { "ChargingAndLow" }
            9 { "ChargingAndCritical" }
            10 { "UnknownState" }
            11 { "PartiallyCharged" }
        }
    }
}

Function Get-AdminStatus
{ 
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") 
}

#Main

if(!(Get-AdminStatus))
{
    throw "Need administrative priviledge to run this script properly"
}

$refreshinterval = 15
$taskenabled = $false
[console]::TreatControlCAsInput = $true

while($true) 
{
    $Bstate = Check-BatteryState
    $Bcharge = 0 + (Check-BatteryCharge)
    Write-Host "Polling... Time:" (Get-Date) "; Battery:$Bcharge%,$Bstate"

    if($Bstate -eq "NotDischarging" -or 
        $Bstate -eq "Low" -or 
        $Bstate -eq "Critical" -or 
        $Bstate -eq "Charging" -or 
        $Bstate -eq "ChargingAndHigh" -or 
        $Bstate -eq "ChargingAndLow" -or 
        $Bstate -eq "ChargingAndCritical")
    {
        if($taskenabled -eq $true) 
        {
            Delete-Task
            $taskenabled =  $false
        }
    }
    elseif($Bstate -eq "Discharging" -or 
        $Bstate -eq "FullyCharged")
    {
        if($taskenabled -eq $false) 
        {
            Create-Task
            $taskenabled =  $true
        }

        if($Bcharge -le $criticallevel) 
        {
            Invoke-Standby
            Start-Sleep -s 60
        }
    }
    
    Start-Sleep -s $refreshinterval

    if ($Host.UI.RawUI.KeyAvailable -and (3 -eq [int]$Host.UI.RawUI.ReadKey("AllowCtrlC,IncludeKeyUp,NoEcho").Character)) 
    {
        Delete-Task
        break;
    }
}

Write-Host "Exiting"