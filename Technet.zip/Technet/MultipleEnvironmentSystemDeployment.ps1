﻿Add-PSSnapin Microsoft.SharePoint.Powershell -ErrorAction "SilentlyContinue"

# use the following the determine location of this script file
$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Path
$deploymentXml = $scriptPath + "\Xml\Deploy.xml"

# now load the deployment configuration data
[xml]$Data = get-content $deploymentXml
$iisRootPath = $Data.Deploy.Settings.IISRootPath
$Url = $Data.Deploy.Settings.Url
$Port = $Data.Deploy.Settings.Port
$AppPoolAccount = $Data.Deploy.Settings.AppPoolAccount
$Owner = $Data.Deploy.Settings.Owner
$WebAppName = $Data.Deploy.Settings.WebAppName
$SiteName = $Data.Deploy.Settings.SiteName
$SiteTemplate = $Data.Deploy.Settings.SiteTemplate


# Below is an example of Creating a Site Collection

if ($Port -ne "80")
{
	$Url = $Url + ":" + $port
}

Write-Host "`n Create Site Collection" -ForegroundColor Blue

New-SPSite $url -Template $SiteTemplate  -Name  $SiteName -OwnerAlias $Owner -Confirm:$false 


# Here is the sample xml file:

#<?xml version="1.0"?>
#<Deploy>
#  <Settings>
#    <IISRootPath>C:\inetpub\wwwroot\wss\VirtualDirectories\</IISRootPath>
#    <Url>http://siteurl</Url>
#    <Port>80</Port>
#    <AppPoolAccount>AD\SVCACCOUNT</AppPoolAccount>
#    <Owner>AD\SITEOWNER</Owner>
#    <SiteName>Site Name</SiteName>
#    <SiteTemplate>BICENTERSITE#0</SiteTemplate>
#  </Settings>
#</Deploy>