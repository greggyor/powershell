$cat1 = get-mailbox -ResultSize unlimited | where{$_.ProhibitSendQuota -eq 200000KB}
$cat2 = get-mailbox -ResultSize unlimited | where{$_.ProhibitSendQuota -eq 300000KB}
$cat3 = get-mailbox -ResultSize unlimited | where{$_.ProhibitSendQuota -eq 350000KB}
$cat4 = get-mailbox -ResultSize unlimited | where{$_.ProhibitSendQuota -eq 400000KB}
$cat5 = get-mailbox -ResultSize unlimited | where{$_.ProhibitSendQuota -eq 450000KB}
$int1 = 0
$int2 = 0
$int3 = 0
$int4 = 0
$int5 = 0
foreach ($item in $cat1)
{$int1++}
foreach ($item in $cat2)
{$int2++}
foreach ($item in $cat3)
{$int3++}
foreach ($item in $cat4)
{$int4++}
foreach ($item in $cat5)
{$int5++}
Write-host Cat1 Count : $int1
Write-host Cat2 Count : $int2
Write-host Cat3 Count : $int3
Write-host Cat4 Count : $int4
Write-host Cat5 Count : $int5