# ------------------------------------------------------------------------
# NAME: DotSourceScripts.ps1
# AUTHOR: ed wilson, Microsoft
# DATE: 2/8/2009
#
# KEYWORDS: dot-source, dot source
#
# COMMENTS: This script uses a function from another
# 
#
#
#
# ------------------------------------------------------------------------
. C:\BestPracticesBook\GetIPDemoSingleFunction.ps1
. C:\BestPracticesBook\Get-FreeDiskSpace.ps1
. C:\BestPracticesBook\Get-OperatingSystemVersion.ps1