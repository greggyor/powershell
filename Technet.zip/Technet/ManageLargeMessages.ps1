﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
		#This function is used to create a PowerShell ErrorRecord
		[CmdletBinding()]
		Param
		(
			[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
			[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
			[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
			[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
		)
		Process
		{
			$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
			$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
			return $customError
		}
}

Function Suspend-OSCEXMessage
{
	<#
		.SYNOPSIS
		Suspend-OSCEXMessage is an advanced function which can be used to suspend messages which meet specified condition.
		.DESCRIPTION
		Suspend-OSCEXMessage is an advanced function which can be used to suspend messages which meet specified condition.
		Messages will be suspended after you enable the notification.
		.PARAMETER TransportServer
		Indicates the name of the server which contains the queues that hold the messages.
		.PARAMETER MessageFilter
		Indicates the filter which will be used by Get-Message. For example, '(Size -gt $(10MB)) -and (Status -ne "Suspended")'.
		.PARAMETER MessageProperty
		Indicates the property names which returned by Get-Message, for exmple, "Identity","FromAddress","Size","Subject".
		These property names will be used in the notification mail.
		.PARAMETER SuspendMailDelivery
		Indicates this function will suspend these messages which meet the filter. The default value is $true.
		You can use $false, if you want to receive the notification mail for administrators only.
		.PARAMETER NotificationMailFrom
		Indicates the e-mail address which the mail is sent.
		.PARAMETER NotificationMailCC
		Indicates the e-mail addresses to which a carbon copy (CC) of the e-mail message is sent.
		.PARAMETER NotificationMailSmtpServer
		Indicates the name of the SMTP server that sends the e-mail message.		
		.EXAMPLE
		#Use Suspend-OSCEXMessage for monitoring large size messages and displays the results in the console.
		$messageSize = "10MB"
		1..20 | %{
			Suspend-OSCEXMessage -TransportServer "transportserver01","transportserver02" -MessageFilter '(Size -gt $messageSize) -and (Status -ne "Suspended")' -MessageProperty "Identity","FromAddress","Size","Subject" -Verbose
			Start-Sleep -Seconds 1
		}
		.EXAMPLE
		#Use Suspend-OSCEXMessage for monitoring large size messages and send emails to administrators only.Messages will not be suspended.
		$messageSize = "10MB"
		1..20 | %{
			Suspend-OSCEXMessage -TransportServer "transportserver01","transportserver02" -MessageProperty "Identity","FromAddress","Size","Subject" `
			-MessageFilter '(Size -gt $messageSize) -and (Status -ne "Suspended")' -SuspendMailDelivery:$false -NotificationMailSmtpServer transportserver01 `
			-NotificationMailFrom "itadmin@corp.contoso.com" -NotificationMailCC "itadmin@corp.contoso.com" -Verbose
			Start-Sleep -Seconds 1
		}
		.EXAMPLE
		#Use Suspend-OSCEXMessage for monitoring large size messages and send emails to administrators and end users.
		$messageSize = "10MB"
		1..20 | %{
			Suspend-OSCEXMessage -TransportServer "transportserver01","transportserver02" -MessageProperty "Identity","FromAddress","Size","Subject" `
			-MessageFilter '(Size -gt $messageSize) -and (Status -ne "Suspended")' -SuspendMailDelivery -NotificationMailSmtpServer transportserver01 `
			-NotificationMailFrom "itadmin@corp.contoso.com" -NotificationMailCC "itadmin@corp.contoso.com" -Verbose
			Start-Sleep -Seconds 1
		}
		.EXAMPLE
		#Use Suspend-OSCEXMessage for monitoring messages with specific subject and send emails to administrators and end users.
		$messageSubject = "Newsletter*"
		1..20 | %{
			Suspend-OSCEXMessage -TransportServer "transportserver01","transportserver02" -MessageProperty "Identity","FromAddress","Size","Subject" `
			-MessageFilter '(Subject -like $messageSubject) -and (Status -ne "Suspended")' -SuspendMailDelivery -NotificationMailSmtpServer transportserver01 `
			-NotificationMailFrom "itadmin@corp.contoso.com" -NotificationMailCC "itadmin@corp.contoso.com" -Verbose
			Start-Sleep -Seconds 1
		}
		.EXAMPLE
		#Use Suspend-OSCEXMessage for monitoring messages with specific subject and send emails to administrators and end users.
		$messageSubject = "Newsletter*"
		1..20 | %{
			Suspend-OSCEXMessage -TransportServer "transportserver01","transportserver02" `
			-MessageFilter '(Subject -like $messageSubject) -and (Status -ne "Suspended")' -SuspendMailDelivery -NotificationMailSmtpServer CNSHE14SVR03 `
			-NotificationMailFrom "itadmin@corp.contoso.com" -NotificationMailCC "itadmin@corp.contoso.com" -Verbose
			Start-Sleep -Seconds 1
		}		
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Get-Message
		http://technet.microsoft.com/en-us/library/bb124738.aspx
		.LINK
		Suspend-Message
		http://technet.microsoft.com/en-us/library/aa997457.aspx		
	#>
	
	[CmdletBinding(DefaultParameterSetName="__AllParameterSets")]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string[]]$TransportServer,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$MessageFilter,
		[Parameter(Mandatory=$false,Position=3)]
		[string[]]$MessageProperty="*",		
		[Parameter(Mandatory=$true,Position=4,ParameterSetName="DoSuspend")]
		[switch]$SuspendMailDelivery,
		[Parameter(Mandatory=$true,Position=5,ParameterSetName="DoSuspend")]
		[string]$NotificationMailFrom,		
		[Parameter(Mandatory=$true,Position=6,ParameterSetName="DoSuspend")]
		[string[]]$NotificationMailCC,
		[Parameter(Mandatory=$true,Position=7,ParameterSetName="DoSuspend")]
		[string]$NotificationMailSmtpServer				
	)
	Process
	{
		$mailMsgs = @()
		#Retrieve messages from multiple transport servers
		foreach ($transServer in $TransportServer) {
			Try
			{
				$mailMsg = Get-Message -Server $transServer -Filter $MessageFilter -Verbose:$false
			}
			Catch
			{
				$pscmdlet.WriteError($Error[0])
			}
			if ($mailMsg -eq $null) {
				$verboseMsg = $Messages.CannotFindMessages
				$verboseMsg = $verboseMsg -replace "Placeholder01",$transServer
				$pscmdlet.WriteVerbose($verboseMsg)
			} else {
				$mailMsgs += $mailMsg
			}
		}
		#Processing the mails
		if ($mailMsgs -ne $null) {
			Switch ($pscmdlet.ParameterSetName) {
				"__AllParameterSets" {
					#Display the messages which meet the filter.
					$mailMsgs | Select-Object -Property $MessageProperty
				}
				"DoSuspend" {
					if ($SuspendMailDelivery) {
						$SuspendMessageDeliverySubject = $Messages.SuspendMessageDeliverySubject
						$SuspendMessageDeliveryBody = $Messages.SuspendMessageDeliveryBody
						#Try to suspend messages and send notifications
						foreach ($mailMsg in $mailMsgs) {
							Try
							{
								if ($mailMsg.Queue -notmatch "Submission|Poison") {
									Suspend-Message -Identity $($mailMsg.Identity) -Confirm:$false -Verbose:$false -ErrorAction:Stop
								} else {
									$verboseMsg = $Messages.CannotSuspendAMessageinSubmissionPoisonQueue
									$verboseMsg = $verboseMsg -replace "Placeholder01",$($mailMsg.Identity)
									$pscmdlet.WriteVerbose($verboseMsg)
								}
							}
							Catch
							{
								$pscmdlet.WriteWarning($Error[0])
							}
							$suspendStatus = (Get-Message -Identity $($mailMsg.Identity)).Status
							if ($suspendStatus -eq "Suspended") {
								$isSuspended = $true
							} elseif ($suspendStatus -eq "PendingSuspend") {
								$isSuspended = $false
								$warningMsg = $Messages.PendingSuspend
								$warningMsg = $warningMsg -replace "Placeholder01",$($mailMsg.Identity)
								$pscmdlet.WriteWarning($warningMsg)
							}							
							if ($isSuspended) {
								$verboseMsg = $Messages.SendingMessage
								$verboseMsg = $verboseMsg -replace "Placeholder01","$($mailMsg.FromAddress)"
								$pscmdlet.WriteVerbose($verboseMsg)
								$SuspendMessageDeliveryBody = $SuspendMessageDeliveryBody -replace "Placeholder01","$($mailMsg.Subject)"
								$SuspendMessageDeliveryBody = $SuspendMessageDeliveryBody -replace "Placeholder02","$($mailMsg.Identity)"
								Send-MailMessage -SmtpServer $NotificationMailSmtpServer `
								-From $NotificationMailFrom -To $($mailMsg.FromAddress) -Cc $NotificationMailCC `
								-Subject $SuspendMessageDeliverySubject -Body $SuspendMessageDeliveryBody
							}
						}
					} else {
						#Send notification mail to mail system administrators.
						$verboseMsg = $Messages.SendingMessage
						$verboseMsg = $verboseMsg -replace "Placeholder01",$NotificationMailCC
						$pscmdlet.WriteVerbose($verboseMsg)
						$NotificationMailSubjectForMultipleMails = $Messages.NotificationMailSubjectForMultipleMails
						$NotificationMailSubjectForMultipleMails = $NotificationMailSubjectForMultipleMails -replace "Placeholder01",$($mailMsgs.Count)
						$notificationMailBody = $mailMsgs | Select-Object -Property $MessageProperty | ConvertTo-Html -Fragment
						Send-MailMessage -SmtpServer $NotificationMailSmtpServer `
						-From $NotificationMailFrom -To $NotificationMailCC `
						-Subject $NotificationMailSubjectForMultipleMails -Body "$notificationMailBody" -BodyAsHtml
					}
				}
			}
		}
	}
}

Function Resume-OSCEXSuspendedMessage
{
	<#
		.SYNOPSIS
		Resume-OSCEXSuspendedMessage is an advanced function which can be used to resume suspended messages which meet specified condition.
		.DESCRIPTION
		Resume-OSCEXSuspendedMessage is an advanced function which can be used to resume suspended messages which meet specified condition.
		.PARAMETER TransportServer
		Indicates the name of the server which contains the queues that hold the messages.
		.PARAMETER MessageFilter
		Indicates the filter which will be used by Get-Message. For example, '(Size -gt $(10MB)) -and (Status -ne "Suspended")'.
		.PARAMETER MessageProperty
		Indicates the property names which returned by Get-Message, for exmple, "Identity","FromAddress","Size","Subject".
		These property names will be used in the notification mail.	
		.EXAMPLE
		#Confirm the messages taht will be resumed.
		Resume-OSCEXSuspendedMessage -TransportServer "transportserver01","transportserver01" -MessageFilter 'Status -eq "Suspended"' -Verbose -Whatif
		.EXAMPLE
		#Resume the suspened messages by using specific filter.
		Resume-OSCEXSuspendedMessage -TransportServer "transportserver01","transportserver01" -MessageFilter 'Status -eq "Suspended"' -Verbose
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Get-Message
		http://technet.microsoft.com/en-us/library/bb124738.aspx
		.LINK
		Resume-Message
		http://technet.microsoft.com/en-us/library/aa997457.aspx		
	#>
	
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string[]]$TransportServer,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$MessageFilter		
	)
	Process
	{
		$mailMsgs = @()
		#Retrieve messages from multiple transport servers
		foreach ($transServer in $TransportServer) {
			$mailMsg = Get-Message -Server $transServer -Filter $MessageFilter -Verbose:$false
			if ($mailMsg -eq $null) {
				$verboseMsg = $Messages.CannotFindMessages
				$verboseMsg = $verboseMsg -replace "Placeholder01",$transServer
				$pscmdlet.WriteVerbose($verboseMsg)
			} else {
				$mailMsgs += $mailMsg
			}
		}
		#Processing the mails
		if ($mailMsgs -ne $null) {
			$verboseMsg = $Messages.MessagesWillBeResumed
			$verboseMsg = $verboseMsg -replace "Placeholder01",$mailMsgs.Count
			$pscmdlet.WriteVerbose($verboseMsg)
			foreach ($mailMsg in $mailMsgs) {
				Try
				{
					if ($pscmdlet.ShouldProcess($($mailMsg.Identity))) {
						Resume-Message -Identity $($mailMsg.Identity) -Confirm:$false -Verbose:$false -ErrorAction:Stop
					}
				}
				Catch
				{
					$pscmdlet.WriteError($Error[0])
				}
			}
		} else {
			$infoMsg = $Messages.CannotFindSuspendedMessage
			$pscmdlet.WriteObject($infoMsg)
		}
	}
}

