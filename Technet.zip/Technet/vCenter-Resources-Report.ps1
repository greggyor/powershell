add-pssnapin VMware.VimAutomation.Core
$smtpServer = "SMTP Server"
$MailFrom = "From EMail ID" 
$mailto = Get-Content  -Path C:\report\email_id.txt # mention email ID in "email_id.txt" to whom you want to send email.
$input1=Get-Content  -Path C:\report\vc_list.txt # mention vcenter name where you want to check resources.

foreach($vc in $input1)
{
$file="C:\report\$($vc).html" # output of the report which will be send by email.
if ( [System.IO.File]::Exists($file) )
{
 remove-item -force $file
}

Connect-VIServer $VC

$a = "<style>"
$a = $a + "BODY{background-color:#FFFFFF;font-size: 15px;}"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:#BBBBBB}"
$a = $a + "TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:#EEEEEE}"
$a = $a + "</style>"

ConvertTo-HTML -body "<font size=3 color=green>$($vc)</font><font size=3 color=red>:</font><font size=3 color=green>Resource Pool Available Reservation.</font>"|out-file C:\pscripts\Gautham -Test\respool\$($vc).html -append

foreach($clus in Get-Cluster){
Get-ResourcePool -Location $clus| Where-Object {$_.Name -eq "Serverprovisioning"} |    Select @{N="Cluster";E={$clus.Name}},Name,
            @{N="Available Reservation MB";E={$_.Extensiondata.Runtime.Memory.UnreservedForPool/1MB}}|ConvertTo-HTML -head $a|out-file C:\pscripts\Gautham -Test\respool\$($vc).html -append
}


ConvertTo-HTML -body "<font size=3 color=green>$($vc)</font><font size=3 color=red>:</font><font size=3 color=green>Over Provisioned DataStores.</font>"|out-file C:\pscripts\Gautham -Test\respool\$($vc).html -append
 Get-View -ViewType Datastore | Where-Object {$_.Name -notmatch "pag"} | `
Select-Object -Property Name,
  @{N="FreeSpaceGB";E={[Math]::Round($_.Summary.FreeSpace/1GB,0)}},
  @{N="CapacityGB"; E={[Math]::Round($_.Summary.Capacity/1GB,0)}},
  @{N="ProvisionedSpaceGB";E={[Math]::Round(($_.Summary.Capacity - $_.Summary.FreeSpace + $_.Summary.Uncommitted)/1GB,0)}},
  @{N="OverProvisionedDS";E={([Math]::Round($_.Summary.Capacity/1GB,0)) - ([Math]::Round(($_.Summary.Capacity - $_.Summary.FreeSpace + $_.Summary.Uncommitted)/1GB,0))}}| `
Sort-Object -Property OverProvisionedDS |  where {$_.OverProvisionedDS -match "-"} |   Select-Object Name,FreeSpaceGB,CapacityGB,ProvisionedSpaceGB |  ConvertTo-HTML -head $a |`
out-file C:\report\$($vc).html -append



ConvertTo-HTML -body "<font size=3 color=green>$($vc)</font><font size=3 color=red>:</font><font size=3 color=green>Datastores < 1000 GB Free.</font>"|out-file C:\pscripts\Gautham -Test\respool\$($vc).html -append
 Get-View -ViewType Datastore | Where-Object {$_.Name -notmatch "pag"} | `
Select-Object -Property Name,
  @{N="FreeSpaceGB";E={[Math]::Round($_.Summary.FreeSpace/1GB,0)}}|`
Sort-Object -Property FreeSpaceGB|  where {$_.FreeSpaceGB -le 1000} |   Select-Object Name,FreeSpaceGB |  ConvertTo-HTML -head $a |`
out-file C:\report\$($vc).html  -append 

#$hr1="<hr align=left width=50>"
#ConvertTo-HTML -body $hr1 |out-file C:\report\$($vc).html -append
ConvertTo-HTML -body "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" |out-file C:\report\$($vc).html  -append


Disconnect-VIServer $VC -confirm:$false

}

#Send mail->
    $msg = new-object Net.Mail.MailMessage 
    $smtp = new-object Net.Mail.SmtpClient($smtpServer) 
    $msg.From = $MailFrom
    $msg.IsBodyHTML = $true
    $msg.To.Add($Mailto) 

    $msg.Subject = "Resource Pool & Datastores Usage Report."

 foreach($vc in $input1)
     {
     $MailTextT =  Get-Content  -Path C:\report\$($vc).html
     $MailText= $MailText + $MailTextT
    }

   $msg.Body = $MailText 
   $smtp.Send($msg) 