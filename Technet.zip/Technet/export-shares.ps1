# THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS"  
# WITHOUT WARRANTY OF ANY KIND. 
# 
# Name: export-shares.ps1  
# Author: Frank Czepat 
# Date: 28.01.2012
# v1.0
#
# Export Shares where Type is Disk Drive and Path is like D: 
#
$type = 0
$path = "D:*"
gwmi win32_share -filter "type = $type" | sort name | % {if ($_.path -like $path) {$_.name + "#" + $_.description + "#" + $_.path}} | out-file .\shares.log -append