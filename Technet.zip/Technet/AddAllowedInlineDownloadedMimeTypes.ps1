<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Load Microsoft SharePoint Snapin
if ((Get-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null) {Add-PSSnapin Microsoft.SharePoint.PowerShell}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Get-OSCSPWebAppMimeTypes
{
	<#
		.SYNOPSIS
		Get-OSCSPWebAppMimeTypes is an advanced function which can be used to retrive allowed inline downloaded MIME types list from one web application.
		.DESCRIPTION
		Get-OSCSPWebAppMimeTypes is an advanced function which can be used to retrive allowed inline downloaded MIME types list from one web application.
		.PARAMETER Identity
		Indicates the name, URL, or GUID of one Web application.
		.EXAMPLE
		#Retrieve allowed inline downloaded MIME types from one web application.
		Get-OSCSPWebAppMimeTypes -Identity "http://sitename:8082"
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Microsoft.SharePoint.Administration.SPWebApplication Class
		http://msdn.microsoft.com/en-us/library/ms463140.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Identity
	)
	Process
	{
		Try
		{
			$spWebApplication = Get-SPWebApplication -Identity $Identity
		}
		Catch
		{
			$pscmdlet.WriteError($Error[0])
		}
		$infoMsg = $Messages.ExistedMIMETypes
		$infoMsg = $infoMsg -replace "Placeholder01",$($spWebApplication.Name)
		$pscmdlet.WriteObject($infoMsg)
		$spAllowedInlineDownloadedMimeTypes = $spWebApplication.AllowedInlineDownloadedMimeTypes
		return $spAllowedInlineDownloadedMimeTypes
	}
}

Function Add-OSCSPWebAppMimeTypes
{
	<#
		.SYNOPSIS
		Add-OSCSPWebAppMimeTypes is an advanced function which can be used to add additional MIME types to allowed inline downloaded MIME types list from one web application.
		.DESCRIPTION
		Add-OSCSPWebAppMimeTypes is an advanced function which can be used to add additional MIME types to allowed inline downloaded MIME types list from one web application.
		.PARAMETER Identity
		Indicates the name, URL, or GUID of one Web application.
		.PARAMETER MIMEType
		Indicates the name of MIME type which will be added to allowed inline downloaded MIME types list.
		.EXAMPLE
		#Add MIME type application/pdf and application/msonenote to allowed inline downloaded MIME types for one web application.
		Add-OSCSPWebAppMimeTypes -Identity "http://sitename:8082" -MIMEType "application/pdf","text/csv" -Verbose
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Microsoft.SharePoint.Administration.SPWebApplication Class
		http://msdn.microsoft.com/en-us/library/ms463140.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Identity,
		[Parameter(Mandatory=$true,Position=2)]
		[string[]]$MIMEType	
	)
	Process
	{
		#Display Information Message
		$title = $Messages.SecurityWarningTitle
		$message = $Messages.SecurityWarning
		$message = $message -replace "Placeholder01",$MIMEType
		$yes = New-Object System.Management.Automation.Host.ChoiceDescription $($Messages.ChoiceYes),$($Messages.ChoiceYesMsg01)
		$no = New-Object System.Management.Automation.Host.ChoiceDescription $($Messages.ChoiceNo),$($Messages.ChoiceNoMsg01)
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
		$result = $host.ui.PromptForChoice($title, $message, $options, 1)
		switch ($result)
		{
			0 {$userConfirmed = $true}
			1 {$userConfirmed = $false}
		}		
		if ($userConfirmed) {
			Try
			{
				$spWebApplication = Get-SPWebApplication -Identity $Identity -Verbose:$false
			}
			Catch
			{
				$pscmdlet.WriteError($Error[0])
			}
			foreach ($mimeTypeItem in $MIMEType) {
				if ($spWebApplication.AllowedInlineDownloadedMimeTypes -notcontains $mimeTypeItem) {
					$verboseMsg = $Messages.AddMIMEType
					$verboseMsg = $verboseMsg -replace "Placeholder01",$mimeTypeItem
					$pscmdlet.WriteVerbose($verboseMsg)
					$spWebApplication.AllowedInlineDownloadedMimeTypes.Add($mimeTypeItem)
					$spWebApplication.Update()
				} else {
					$warningMsg = $Messages.ExistedType
					$warningMsg = $warningMsg -replace "Placeholder01",$mimeTypeItem
					$pscmdlet.WriteWarning($warningMsg)
				}
			}
		} else {
			return $null
		}
	}
}

