$filename = "C:\BigMailbox$(Get-Date -f 'yyyyMMdd').csv"

Get-Mailbox -ResultSize Unlimited | Get-MailboxStatistics | Where {$_.TotalItemSize -gt 500MB} `
| Select-Object DisplayName, ItemCount, {$_.TotalItemSize.Value.ToMB()}, {$_.TotalDeletedItemSize.Value.ToMB()}, StorageLimitStatus `
| Export-Csv "$filename" -NoType


                $smtp = "mail.contoso.com"
                $SendTo = "messaging@contoso.com"
                $From = "Reports@contoso.com"
                $subject = "Big Mailbox Report for $(Get-Date -f 'yyyy/MM/dd')"
                $body = " The file $filename has been attached to this email "
                $file = "$filename"


            #Create SMTP Client object        
            $mail = New-Object system.net.mail.smtpclient($smtp)
            
            
            if ($username -and $password) {
                $mailcred=New-Object system.net.NetworkCredential ($username,$password)
                $mail.credentials=$mailcred
            }
            
            $msg = New-Object system.Net.Mail.MailMessage ($From,$SendTo,$subject,$body)
            
            #if file attachment specified, add it to the message
            if ($file) {
                $attach=New-Object system.Net.Mail.Attachment $file
                $msg.Attachments.add($attach)
            }
            
            #send message
            $mail.send($msg)

Remove-Item $filename