﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 3.0

Function Export-OSCVM
{
<#
 	.SYNOPSIS
        Export-OSCVM is an advanced function which can be used to batch export virtual machines.
    .DESCRIPTION
        Export-OSCVM is an advanced function which can be used to batch export virtual machines.
    .PARAMETER  IDScope
		Specifies the ID scope you want to export.
	.PARAMETER  ExcludeIDScope
		Omits the specified items.
	.PARAMETER  Path
		Specifies the path to the folder into which the virtual machine is to be exported.
    .EXAMPLE
        C:\PS> Show-OSCVirtualMachineInfo
        ID     VirtualMachineName                                 
        --     ------------------                                 
         1     WIN7Client1                                        
         2     WIN7Client2                                        
         3     WIN8Client1                                        
         4     WINServer2012-DHCP                                 
         5     WINServer2012-DNS                                  
         6     WINServer2012-DNS02  

        C:\PS> Export-OSCVM -IDScope 1..5 -ExcludeIDScope 3 -Path D:\
	
		This command shows how to batch export virtual machines to the root of the D drive.
	.EXAMPLE
        C:\PS> Show-OSCVirtualMachineInfo
        ID     VirtualMachineName                                 
        --     ------------------                                 
         1     WIN7Client1                                        
         2     WIN7Client2                                        
         3     WIN8Client1                                        
         4     WINServer2012-DHCP                                 
         5     WINServer2012-DNS                                  
         6     WINServer2012-DNS02  

        C:\PS> Export-OSCVM -IDScope 1,2,3 -Path D:\
	
		This command shows how to batch export virtual machines to the root of the D drive.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory,Position=0)]
        [Alias('id')]
        [String[]]$IDScope,

        [Parameter(Mandatory=$false,Position=1)]
        [Alias('exid')]
        [String[]]$ExcludeIDScope,
    
        [Parameter(Mandatory,Position=2)]
        [Alias('p')]
        [String]$Path
    )

    If ($ExcludeIDScope)
    {
        $ExportVMs = FindVirtualMachine -ExcludeIDScope $ExcludeIDScope
        ExportVirtualMachine -ExportVMs $ExportVMs
    }
    Else
    {
        $ExportVMs = GetVirtualMachine -IDScope $IDScope
        ExportVirtualMachine -ExportVMs $ExportVMs
    }
}

Function Show-OSCVirtualMachineInfo
{
    #Define an initial ID number.
    $IDNumber = 1 
    #Define an empty array.
    $Objs=@()

    Foreach($VM in $(Get-VM))
    {
        $Obj = New-Object -TypeName PSObject
        $Obj | Add-Member -MemberType NoteProperty -Name "ID" -Value $IDNumber
        $Obj | Add-Member -MemberType NoteProperty -Name "VirtualMachineName" -Value $VM.Name
        
        $IDNumber++
        $Objs+=$Obj
    }
	$Objs
}

Function GetVirtualMachine($IDScope)
{
    #Filter virtual machines that we want to rename
    If($IDScope -match "..")
    {
        Foreach($ID in Invoke-Expression([String]$IDScope))
        {
            Show-OSCVirtualMachineInfo | Where-Object ID -EQ $ID
        }
    }
    Else
    {
         Foreach($ID in $IDScope)
        {
            Show-OSCVirtualMachineInfo | Where-Object ID -EQ $ID
        }
    }
}

Function FindVirtualMachine($ExcludeIDScope)
{
    $ModifyVirtualMachines = GetVirtualMachine -IDScope $IDScope

    If($ExcludeID -match "..")
    {
        Foreach($ExcludeID in Invoke-Expression([String]$ExcludeIDScope))
        {
            #Perform the recursion by calling itself.
            $ModifyVirtualMachines = $ModifyVirtualMachines | Where-Object ID -NE $ExcludeID
        }
    }
    Else
    {
        Foreach($ExcludeID in $ExcludeIDScope)
        {
            #Perform the recursion by calling itself.
            $ModifyVirtualMachines = $ModifyVirtualMachines | Where-Object ID -NE $ExcludeID
        }
    }
    $ModifyVirtualMachines
}

Function ExportVirtualMachine($ExportVMs)
{
        Foreach($ExportVM in $ExportVMs)
        {
            Try
            {
                $ExportVMName = $ExportVM.VirtualMachineName
                
                $VMState = (Get-VM -Name $ExportVMName).State
                If ($VMState -eq "Running")
                {
                    Write-Warning "The operation cannot be performed while the virtual machine ""$ExportVMName"" is in ""Running"" state. "
                }
                Else
                {
                    Write-Host "Exporting the virtual machine ""$ExportVMName""... " -NoNewline
                    Export-VM -Name $ExportVMName -Path $Path -ErrorAction Stop
                    Write-Host "Successfully" -ForegroundColor Green
                }
            }
            Catch
            {
                Write-Host "Failed" -ForegroundColor Red
            }
        }
}