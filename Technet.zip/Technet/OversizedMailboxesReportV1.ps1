﻿# script will generate HTML report for mailboxes over specified size
# ($mailboxLimit) variable will define the specified size limit for report
# if you were to display mailbox size results in KB or MB change the line 72, 92, 105 and 106 accordingly

#Variables to configure 
$smtpServer = "exchange2010.mydomain.com"
$ReportSender = "sender@mydomain.com" 
$users = "DistributionList@mydomain.com", "user1@mydomain.com", "user2@mydomain.com";
$MailSubject = ("Mailbox Size Report" + " - " + ( get-date ).ToString('yyyy/MM/dd')) 
$mailboxLimit = '1gb' 
 
Write-Host "Initializing..."

#Add Exchange 2010 snapin and run OUTPUT command
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue
Set-ADServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue

#Run OUTPUT command
$exdata = Get-Mailbox -ResultSize Unlimited | Get-MailboxStatistics -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Where-Object {$_.totalItemSize -gt $mailboxLimit} | Sort-Object TotalItemSize -descending | Select-Object DisplayName, ItemCount, TotalItemSize, Database, LastLogonTime
 
$fileName = "OversizedMailboxReport.html" 
New-Item -ItemType file $fileName -Force
 
$reportTime = Get-Date

# HTML start 
Add-Content $fileName "<html>" 
 
# HEAD start 
Add-Content $fileName "<head>" 
 
add-content $fileName '<STYLE TYPE="text/css">' 
add-content $fileName  "<!--" 
add-content $fileName  "td {" 
add-content $fileName  "font-family: Tahoma;" 
add-content $fileName  "font-size: 11px;" 
add-content $fileName  "border-top: 1px solid #999999;" 
add-content $fileName  "border-right: 1px solid #999999;" 
add-content $fileName  "border-bottom: 1px solid #999999;" 
add-content $fileName  "border-left: 1px solid #999999;" 
add-content $fileName  "padding-top: 0px;" 
add-content $fileName  "padding-right: 0px;" 
add-content $fileName  "padding-bottom: 0px;" 
add-content $fileName  "padding-left: 0px;" 
add-content $fileName  "}" 
add-content $fileName  "body {" 
add-content $fileName  "margin-left: 5px;" 
add-content $fileName  "margin-top: 5px;" 
add-content $fileName  "margin-right: 0px;" 
add-content $fileName  "margin-bottom: 10px;" 
add-content $fileName  "}" 
add-content $fileName  "table {" 
add-content $fileName  "border: thin solid #000000;" 
add-content $fileName  "}" 
add-content $fileName  "-->" 
add-content $fileName  "</style>" 
 
# HEAD end 
Add-Content $fileName "</head>" 
 
# BODY start 
Add-Content $fileName "<body>" 
Add-Content $fileName ("<h3 align='center'><font face='Arial'>List of Mailboxes over " + ($mailboxLimit) + " in size</font></h3>")
Add-Content $fileName ("<h5 align='center'><font face='Arial'>Generated: " + ($reportTime) + "</font></h5>")
# TABLE start 
Add-Content $fileName "<table width='100%'>" 
 
# TABLE Header 
Add-Content $fileName "<tr bgcolor='#990000'>" 
Add-Content $fileName "<td><b><font color='#FFFFFF'>Display Name</font></b></td>" 
Add-Content $fileName "<td><b><font color='#FFFFFF'>Email Count</font></b></td>" 
Add-Content $fileName "<td><b><font color='#FFFFFF'>Mailbox Size (GB)</font></b></td>" 
Add-Content $fileName "<td><b><font color='#FFFFFF'>Database</font></b></td>" 
Add-Content $fileName "<td><b><font color='#FFFFFF'>Last Logon Time</font></b></td>"
Add-Content $fileName "</tr>" 
 
$alternateTableRowBackground = 0 
 
# TABLE Content 
while($alternateTableRowBackground -lt $exdata.length) 
{ 
if(($alternateTableRowBackground % 2) -eq 0) 
{ 
Add-Content $fileName "<tr bgcolor='#CCCCCC'>" 
} 
else 
{ 
Add-Content $fileName "<tr bgcolor='#FCFCFC'>" 
}
Add-Content $fileName ("<td>" + $exdata[$alternateTableRowBackground].DisplayName + "</td>")  
Add-Content $fileName ("<td>" + $exdata[$alternateTableRowBackground].ItemCount + "</td>") 
Add-Content $fileName ("<td>" + $exdata[$alternateTableRowBackground].TotalItemSize.Value.ToGB() + "</td>") 
Add-Content $fileName ("<td>" + $exdata[$alternateTableRowBackground].Database + "</td>") 
Add-Content $fileName ("<td>" + $exdata[$alternateTableRowBackground].LastLogonTime + "</td>") 
Add-Content $fileName "</tr>" 

$alternateTableRowBackground = $alternateTableRowBackground + 1
}
# Summe Mailboxsize 
Add-Content $fileName "<tr bgcolor='#990000'>" 
$tempdata = $exdata.count
Add-Content $fileName ("<td><b><font color='#FFFFFF'>Mailbox Count: " + ($tempdata) + "</font></b></td>")  
$tempdata = $exdata | %{$_.ItemCount} | Measure-Object -Sum 
Add-Content $fileName ("<td><b><font color='#FFFFFF'>" + ($tempdata | Select-Object -expand Sum) + "</font></b></td>") 
$tempdata = $exdata | %{$_.TotalItemSize.Value.ToGB()} | Measure-Object -Sum 
Add-Content $fileName ("<td><b><font color='#FFFFFF'>" + ($tempdata | Select-Object -expand Sum) + " GB</font></b></td>") 
Add-Content $fileName ("<td></td>")
Add-Content $fileName ("<td></td>")
 
#TABLE end 
Add-Content $fileName "</table>" 
 
# HEAD end 
Add-Content $fileName "</body>" 
 
# HTML end 
Add-Content $fileName "</html>" 
 
#SendEmailFunction 
foreach ($user in $users) 
{ 
Write-Host "Sending Email notification to $user"

$smtp= New-Object System.Net.Mail.SmtpClient($smtpServer) 
$msg = New-Object System.Net.Mail.MailMessage  
$msg.To.Add($user)
$msg.From = $ReportSender
$msg.Subject = $MailSubject
$msg.Body = (Get-Content $fileName)
$msg.isBodyhtml = $true 
$smtp.send($msg) 
}
