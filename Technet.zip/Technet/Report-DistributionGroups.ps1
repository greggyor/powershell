<#
    .SYNOPSIS
    Creates a HTML Report showing Distribution and Dynamic Distribution Group Summary and Members 
   
   	Serkan Varoglu
	
	http:\\Mshowto.org
	http:\\Get-Mailbox.org
	
	THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE 
	RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
	
	Version 1.6, 22 March 2012
	Fixed ResultSize.
	Version 1.5, 14 March 2012
	
    .DESCRIPTION
	
    This script creates a HTML report showing the following information:
	
	* Distribution Groups Summary:
		o Distribution Group Count
		o Hidden From Address List
		o Moderation Status
		o Sender Authentication Required
		o Join
			* Open to Join
			* Approval to Join
			* Closed to Join
		o Depart
			* Open to Depart
			* Closed to Depart
		o Is Valid False
		o No Manager
		o Empty Groups
	* Dynamic Distribution Groups Summary:
        o Dynamic Distribution Group Count
		o Hidden From Address List
		o Sender Authentication Required
		o Is Valid False
		o No Manager
		o Empty Groups
    
	Then per Distribution Group and Dynamic Distribution Group
	* Distribution Group Name
		o If Group is hidden from Address Lists this cell will have a DASHED BLACK BORDER
	* Alias
	* Group Type
	* Primary SMTP Address
		o If Sender Authentication Required this cell will have a SOLID RED BORDER
	* Recipient Type Details
	* Is Valid?
		o If the group is not valid this cell will be highligted with color YELLOW
	* Managed by
	* Member Count
		o If Distribution Group has another group as member this will be listed as "X members including Y groups".
			X representing Total Number of Members, Y representing Number of Groups as Member
		o If Group is Open to join this cell will be highlighted with color GREEN
		o If Group is ApprovalRequired to join this cell will be highlighted with color ORANGE
		o If Group is Open to depart this cell will have a DOTTED RED BORDER
		
	ShowMembers switch will determine the output. If you use ShowMembers switch, Members column hyperlinks will take you to the group members list if clicked.

	Also please be aware that if you do not have any Distribution Groups or Dynamic Distribution Groups you might receive errors on powershell screen but this will not affect the output.

	If you migrated from a previous version of Exchange Server some groups might have invalid alias. These will be listed during the process as warning and also in the report you can find these groups as �Is valid false� highlighted with yellow background.

	If RecipientFilter is not configured correctly on Dynamic Distribution Groups you might get errors on the screen but report will still get published without reporting members of this group.
		
	.PARAMETER HTMLReport
    Filename to write HTML Report to
	
	.SWITCH ShowMembers
	If ShowMembers is added as switch the Members of each group (if not empty) will be listed in a table
	    
	.EXAMPLE
    Generate the HTML report 
    .\Report-DistributionGroups.ps1 -ShowMembers -HTMLReport "C:\Users\SVaroglu\Desktop\DistributionGroupReport.HTML"
	
    #>
param ( [Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$false,HelpMessage='Filename to write HTML report to. For Example: c:\DistGroupReport.html')][string]$HTMLReport,
		[Parameter(Position=1,Mandatory=$false,ValueFromPipeline=$false,HelpMessage='This switch will list members in your report')][switch]$ShowMembers)
$Watch = [System.Diagnostics.Stopwatch]::StartNew()
$WarningPreference="SilentlyContinue"
$ErrorPreference="SilentlyContinue"
$ShowMembers=$ShowMembers.IsPresent
$Output="<html><style type=""text/css"">a:visited, a:link{color:#000066;text-decoration:none;font-weight:bold;}a:hover{background-color:#CC3300;color:#FFFFFF;text-decoration:none;font-weight:bold;}</style>
<body>
<font size=""1"" face=""Arial,sans-serif"">
<h3 align=""center"">Distribution Group Report</h3>
<h4 align=""center"">Generated $((Get-Date).ToString())</h4>
<h5 align=""center"">Distribution Groups Summary</h5>
<center>"
function _Progress
{
    param($PercentComplete,$Status)
    Write-Progress -id 1 -activity "Distribution Group Report" -status $Status -percentComplete ($PercentComplete)
}
if ($ShowMembers -like "True"){$stat=1}else{$stat=1}
_Progress $stat "Getting Distribution Group List"
$groups=Get-DistributionGroup -resultsize Unlimited | Sort-Object name
if ($ShowMembers -like "True"){$stat=8}else{$stat=10}
_Progress $stat "Getting Dynamic Distribution Group List"
$dygroups=Get-DynamicDistributionGroup -resultsize Unlimited | Sort-Object name
$gcount=($groups | Measure-Object).count
$dygcount=($dygroups | Measure-Object).count
if ($ShowMembers -like "True"){$stat=13}else{$stat=25}
_Progress $stat "Collecting Distribution Group Information"
if ($gcount -eq 0){Write-Host -ForegroundColor Cyan "No Distribution Groups Found." }
else{
	$hiddengroups=($groups | ?{$_.HiddenFromAddressListsEnabled -like "True"} | measure-object).count
	$moderatedgroups=($groups | ?{$_.ModerationEnabled -like "True"} | measure-object).count
	$authgroups=($groups | ?{$_.RequireSenderAuthenticationEnabled -like "True"} | measure-object).count
	$invalidgroups=($groups | ?{$_.isvalid -like "False"} | measure-object).count
	$opengroups=($groups | ?{$_.MemberJoinRestriction -like "Open"} | measure-object).count
	$approvalgroups=($groups | ?{$_.MemberJoinRestriction -like "Approval*"} | measure-object).count
	$closedgroups=($groups | ?{$_.MemberJoinRestriction -like "Closed"} | measure-object).count
	$departopengroups=($groups | ?{$_.MemberDepartRestriction -like "Open"} | measure-object).count
	$departclosedgroups=($groups | ?{$_.MemberDepartRestriction -like "Closed"} | measure-object).count
	$groupswithoutManager=($groups | ?{!$_.managedby} | measure-object).count
	}
if ($dygcount -eq 0){Write-Host -ForegroundColor Cyan "No Dynamic Distribution Groups Found." }
else{
	$dyhiddengroups=($dygroups | ?{$_.HiddenFromAddressListsEnabled -like "True"} | measure-object).count
	$dyauthgroups=($dygroups | ?{$_.RequireSenderAuthenticationEnabled -like "True"} | measure-object).count
	$dyinvalidgroups=($dygroups | ?{$_.isvalid -like "False"} | measure-object).count
	$dygroupswithoutManager=($dygroups | ?{!$_.managedby} | measure-object).count
	}
if (($gcount -eq 0) -and ($dygcount -eq 0)){exit}
if ($ShowMembers -like "True"){$stat=20}else{$stat=45}
_Progress $stat "Getting Distribution and Dynamic Distribution Group Member Counts (Please be Patient)"
if ($gcount -ne 0){$emptygroups=($groups | ?{!(Get-DistributionGroupMember �identity $_.DistinguishedName)} | measure-object ).count}
if ($dygcount -ne 0){$dyemptygroups=($dygroups | ?{!(Get-Recipient -RecipientPreviewFilter $_.RecipientFilter)} | measure-object).count}
$Output+="<table border=""0"" cellpadding=""3"" style=""font-size:8pt;font-family:Arial,sans-serif"" width=""50%"">
<tr bgcolor=""#736AFF"" align=""""center"""">
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Distribution Group Count</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Hidden From Address List</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Moderated</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Sender Authentication Required</th>
<th nowrap=""nowrap"" colspan=""3""><font color=""#FFFFFF"">Join</th>
<th nowrap=""nowrap"" colspan=""2""><font color=""#FFFFFF"">Depart</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Is Valid False</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">No Manager</th>
<th nowrap=""nowrap"" rowspan=""2""><font color=""#FFFFFF"">Empty Groups</th>
</tr>
<tr bgcolor=""#736AFF"" align=""""center"""">
<th nowrap=""nowrap""><font color=""#FFFFFF"">Open to Join</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Approval to Join</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Closed to Join</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Open to Depart</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Closed to Depart</th>
</tr>
<tr>
<td align=""center"">$gcount</td>
<td style=""border: 2px dashed black"" align=""center"">$hiddengroups</td>
<td bgcolor=""#FFF200"" align=""center"">$moderatedgroups</td>
<td style=""border: 1px solid red"" align=""center"">$authgroups</td>
<td bgcolor=""#A4FFA4"" align=""center"">$opengroups</td>
<td bgcolor=""#FFB366"" align=""center"">$approvalgroups</td>
<td align=""center"">$closedgroups</td>
<td style=""border: 2px dotted red"" align=""center"">$departopengroups</td>
<td align=""center"">$departclosedgroups</td>
<td bgcolor=""#FFFFB3"" align=""center"">$invalidgroups</td>
<td align=""center"">$groupswithoutManager</td>
<td align=""center"">$emptygroups</td>
</tr></table>
<h5 align=""center"">Dynamic Distribution Groups Summary</h5>
<table border=""0"" cellpadding=""3"" style=""font-size:8pt;font-family:Arial,sans-serif"" width=""50%"">
<tr bgcolor=""#736AFF"" align=""""center"""">
<th nowrap=""nowrap""><font color=""#FFFFFF"">Dynamic Distribution Group Count</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Hidden From Address List</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Sender Authentication Required</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Is Valid False</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">No Manager</th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Empty Groups</th>
</tr>
<tr>
<td align=""center"">$dygcount</td>
<td style=""border: 2px dashed black"" align=""center"">$dyhiddengroups</td>
<td style=""border: 1px solid red"" align=""center"">$dyauthgroups</td>
<td bgcolor=""#FFFFB3"" align=""center"">$dyinvalidgroups</td>
<td align=""center"">$dygroupswithoutManager</td>
<td align=""center"">$dyemptygroups</td>
</tr>
</table>"
if ($gcount -ne 0){
$Output+="<h5 align=""center"">Distribution & Dynamic Distribution Group List</h5>
<table border=""0"" cellpadding=""3"" style=""font-size:8pt;font-family:Arial,sans-serif"" width=""50%"">
<tr bgcolor=""#736AFF"" align=""center"">
<th nowrap=""nowrap""><font color=""#FFFFFF"">Distribution Group</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Alias</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Group Type</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Primary SMTP Address</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Recipient Type Details</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Is Valid?</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Managed By</font></th>
<th nowrap=""nowrap""><font color=""#FFFFFF"">Members</font></th>
</tr>"}
if ($ShowMembers -like "True"){$stat=30}else{$stat=59}
_Progress $stat "Writing Summary for $($gcount) Distribution Groups and $($dygcount) Dynamic Distribution Groups"
$i=0

if ($gcount -ne 0)
{
foreach ($group in $groups)
		{
_Progress ($stat+((($i+1)*20)/$gcount)) "Writing Summary for Distribution Group $($i+1) of $($gcount)"			
			$members=Get-DistributionGroupMember $group -resultsize unlimited | sort-object name
			$memberscount=($members | measure-object).count
			if (0,2,4,6,8 -contains "$i"[-1]-48) {
					if ($group.HiddenFromAddressListsEnabled -like "True")
					{[string]$border="style=""border: 2px dashed black"""}
					else
					{[string]$border=""}
					$Output+="<tr bgcolor=""#E8E8E8""><th nowrap=""nowrap"" $($border)><a name=""#$($group.Name)_s"">$($group.Name)</a></th>"
					$Output+="<td>$($group.Alias)</td>"
					$Output+="<td>$($group.GroupType)</td>"
					if ($group.ModerationEnabled -like "True")
					{[string]$bgcolor="bgcolor=""#FFF200"""}
					else
					{[string]$bgcolor=""}
					if ($group.RequireSenderAuthenticationEnabled -like "True")
					{[string]$border="style=""border: 1px solid red"""}
					else
					{[string]$border=""}
					$Output+="<td $($bgcolor) $($border)>$($group.PrimarySmtpAddress)</td>"
					$Output+="<td>$($group.RecipientTypeDetails)</td>"
					if ($group.isvalid -notlike "True")
						{
						$Output+="<td bgcolor=""#FFFFB3"">$($group.isvalid)</td>"
						}
					else
						{
						$Output+="<td>$($group.isvalid)</td>"
						}
					$Managers=$group | select-object -Expand Managedby
					if (!$Managers){$Output+="<td>No Manager</td>"}
					else 
					{
					$Output+="<td>"
					foreach ($Manager in $Managers)
						{
						$Output+="$($Manager.name); "
						}
					$Output+="</td>"
					}
					if ($group.MemberJoinRestriction -like "Open")
					{[string]$bgcolor="bgcolor=""#A4FFA4"""}
					elseif ($group.MemberJoinRestriction -like "Approval*")
					{[string]$bgcolor="bgcolor=""#FFB366"""}
					else
					{[string]$bgcolor=""}
					if ($group.MemberDepartRestriction -like "Open")
					{[string]$border="style=""border: 2px dotted red"""}
					else
					{[string]$border=""}
					$grouphasgroup=$members | ?{$_.RecipientType -like "*group*"}
					$grouphasgroupcount=($grouphasgroup|measure-object).count
					if(!$grouphasgroup){$MemberNote="Members"} else {$MemberNote="Members including $($grouphasgroupcount) Groups"}
						if(!$members)
							{
							$Output+="<td $($bgcolor) $($border)>Empty</td>"
							}
						else
							{
							$Output+="<td $($bgcolor) $($border)><a href=""#$($group.Name)"">$($memberscount) $($MemberNote)</a></td>"
							}			
					$Output+="</tr>"
					$i++
  			} else {
					if ($group.HiddenFromAddressListsEnabled -like "True")
					{[string]$border="style=""border: 2px dashed black"""}
					else
					{[string]$border=""}
					$Output+="<tr bgcolor=""#C8C8C8""><th nowrap=""nowrap"" $($border)><a name=""#$($group.Name)_s"">$($group.Name)</a></th>"
					$Output+="<td>$($group.Alias)</td>"
					$Output+="<td>$($group.GroupType)</td>"
					if ($group.ModerationEnabled -like "True")
					{[string]$bgcolor="bgcolor=""#FFF200"""}
					else
					{[string]$bgcolor=""}
					if ($group.RequireSenderAuthenticationEnabled -like "True")
					{[string]$border="style=""border: 1px solid red"""}
					else
					{[string]$border=""}
					$Output+="<td $($bgcolor) $($border)>$($group.PrimarySmtpAddress)</td>"
					$Output+="<td>$($group.RecipientTypeDetails)</td>"
					if ($group.isvalid -notlike "True")
						{
						$Output+="<td bgcolor=""#FFFFB3"">$($group.isvalid)</td>"
						}
					else
						{
						$Output+="<td>$($group.isvalid)</td>"
						}
					$Managers=$group | select-object -Expand Managedby
					if (!$Managers){$Output+="<td>No Manager</td>"}
					else 
					{
					$Output+="<td>"
					foreach ($Manager in $Managers)
						{
						$Output+="$($Manager.name); "
						}
					$Output+="</td>"
					}
					if ($group.MemberJoinRestriction -like "Open")
					{[string]$bgcolor="bgcolor=""#A4FFA4"""}
					elseif ($group.MemberJoinRestriction -like "Approval*")
					{[string]$bgcolor="bgcolor=""#FFB366"""}
					else
					{[string]$bgcolor=""}
					if ($group.MemberDepartRestriction -like "Open")
					{[string]$border="style=""border: 2px dotted red"""}
					else
					{[string]$border=""}
					$grouphasgroup=$members | ?{$_.RecipientType -like "*group*"}
					$grouphasgroupcount=($grouphasgroup|measure-object).count
					if(!$grouphasgroup){$MemberNote="Members"} else {$MemberNote="Members including $($grouphasgroupcount) Groups"}
					if(!$members)
						{
						$Output+="<td $($bgcolor) $($border)>Empty</td>"
						}
					else
						{
						$Output+="<td $($bgcolor) $($border)><a href=""#$($group.Name)"">$($memberscount) $MemberNote</a></td>"
						}			
					$Output+="</tr>"
					$i++
  			}                                                                                                                
		}
$i=0
}
if ($dygcount -ne 0)
{
foreach($dygroup in $dygroups)
		{
if ($ShowMembers -like "True"){$stat=50}else{$stat=79}
_Progress ($stat+((($i+1)*20)/$dygcount)) "Writing Summary for Dynamic Distribution Group $($i+1) of $($dygcount)"	
			$dymembers = Get-Recipient -ResultSize Unlimited -RecipientPreviewFilter $dygroup.RecipientFilter | Sort-Object name
			$dymemberscount=($dymembers | measure-object).count
			if (0,2,4,6,8 -contains "$i"[-1]-48) {
			if ($dygroup.HiddenFromAddressListsEnabled -like "True")
			{[string]$border="style=""border: 2px dashed black"""}
			else
			{[string]$border=""}
			$Output+="<tr bgcolor=""#E8E8E8""><th nowrap=""nowrap"" $($border)><a name=""#$($dygroup.Name)_s"">$($dygroup.Name)</a></th>"
			$Output+="<td>$($dygroup.Alias)</td>"
			$Output+="<td>Dynamic Distribution</td>"
			if ($dygroup.ModerationEnabled -like "True")
			{[string]$bgcolor="bgcolor=""#FFF200"""}
			else
			{[string]$bgcolor=""}
			if ($dygroup.RequireSenderAuthenticationEnabled -like "True")
			{[string]$border="style=""border: 1px solid red"""}
			else
			{[string]$border=""}
			$Output+="<td $($bgcolor) $($border)>$($dygroup.PrimarySmtpAddress)</td>"
			$Output+="<td>$($dygroup.RecipientTypeDetails)</td>"
			if ($dygroup.isvalid -notlike "True")
				{
				$Output+="<td bgcolor=""#FFFFB3"">$($dygroup.isvalid)</td>"
				}
			else
				{
				$Output+="<td>$($dygroup.isvalid)</td>"
				}
			$Manager=$dygroup.managedby
			if (!$Manager){$Output+="<td>No Manager</td>"}
			else 
			{
			$Output+="<td>$($Manager.name)</td>"
			}
			$dygrouphasgroup=$dymembers | ?{$_.RecipientType -like "*group*"}
			$dygrouphasgroupcount=($dygrouphasgroup|Measure-Object).count
			if(!$dygrouphasgroup){$dyMemberNote="Members"} else {$dyMemberNote="Members including $($dygrouphasgroupcount) Groups"}
			if(!$dymembers)
				{
				$Output+="<td>Empty</td>"
				}
			else
				{
				$Output+="<td><a href=""#$($dygroup.Name)"">$($dymembers.count) $($dyMemberNote)</a></td>"
				}			
			$Output+="</tr>"
			$i++
			} else {
			if ($dygroup.HiddenFromAddressListsEnabled -like "True")
			{[string]$border="style=""border: 2px dashed black"""}
			else
			{[string]$border=""}
			$Output+="<tr bgcolor=""#C8C8C8""><th nowrap=""nowrap""  $($border)><a name=""#$($dygroup.Name)_s"">$($dygroup.Name)</a></th>"
			$Output+="<td>$($dygroup.Alias)</td>"
			$Output+="<td>Dynamic Distribution</td>"
			if ($dygroup.ModerationEnabled -like "True")
			{[string]$bgcolor="bgcolor=""#FFF200"""}
			else
			{[string]$bgcolor=""}
			if ($dygroup.RequireSenderAuthenticationEnabled -like "True")
			{[string]$border="style=""border: 1px solid red"""}
			else
			{[string]$border=""}
			$Output+="<td $($bgcolor) $($border)>$($dygroup.PrimarySmtpAddress)</td>"
			$Output+="<td>$($dygroup.RecipientTypeDetails)</td>"
			if ($dygroup.isvalid -notlike "True")
				{
				$Output+="<td bgcolor=""#FFFFB3"">$($dygroup.isvalid)</td>"
				}
				else
				{
				$Output+="<td>$($dygroup.isvalid)</td>"
				}
			$Manager=$dygroup.managedby
			if (!$Manager){$Output+="<td>No Manager</td>"}
			else 
			{
			$Output+="<td>$($Manager.name)</td>"
			}
			$dygrouphasgroup=$dymembers | ?{$_.RecipientType -like "*group*"}
			$dygrouphasgroupcount=($dygrouphasgroup|Measure-Object).count
			if(!$dygrouphasgroup){$dyMemberNote="Members"} else {$dyMemberNote="Members including $($dygrouphasgroupcount) Groups"}
			if(!$dymembers)
				{
				$Output+="<td>Empty</td>"
				}
			else
				{
				$Output+="<td><a href=""#$($dygroup.Name)"">$($dymemberscount) $($dyMemberNote)</a></td>"
				}			
			$Output+="</tr>"
			$i++
			}
		}
}		
$Output+="</table>"
if ($ShowMembers -like "True")
{
	$Output+="<h5 align=""center"">Members</h5>"
	$Output+="<table border=""0"" cellpadding=""3"" style=""font-size:8pt;font-family:Arial,sans-serif"">
	<tr bgcolor=""#736AFF"" align=""center"">
	<th nowrap=""nowrap""><font color=""#FFFFFF"">Distribution Group</font></th>
	<th nowrap=""nowrap""><font color=""#FFFFFF"">Member</font></th>
	<th nowrap=""nowrap""><font color=""#FFFFFF"">Primary SMTP Address</font></th>
	<th nowrap=""nowrap""><font color=""#FFFFFF"">RecipientTypeDetails</font></th>
	</tr>
	"
	$i=0
	foreach ($group in $groups)
		{
_Progress (70+((($i+1)*15)/$gcount)) "Adding Members List for Distribution Group $($i+1) of $($gcount) to the Report"	
			$members=Get-DistributionGroupMember $group -resultsize Unlimited | sort-object name
			if(!$members){}
			else
			{
				if (0,2,4,6,8 -contains "$i"[-1]-48) 
					{
						$rowspan=($members | measure-object).count+1
						$Output+="<tr><td><a href=""#$($group.Name)_s"">&#9650;</a><hr /></td></tr><tr bgcolor=""#C8C8C8""><th rowspan=$($rowspan) nowrap=""nowrap"" valign=""baseline""><a name=""#$($group.Name)"">$($group.Name)</a></th></tr>"
						foreach ($member in $members)
						{
								if($member.RecipientTypeDetails -like "*Room*")
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#454545"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*User*")
								{
								if ($member.IsValidSecurityPrincipal -like "False")
								{$color="red"}else{$color="'#000066'"}
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=$color>$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*Contact*")
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#336633"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*Group*")
								{
								$Output+="<tr bgcolor=""#B0B0B0"">"
								$Output+="<td><font color=""#333333""><a href=""#$($member.Name)"">$($member.Name)</a></font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								else
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#000000"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
						}
					$i++	
					}
				else
					{
						$rowspan=($members | measure-object).count+1
						$Output+="<tr><td><a href=""#$($group.Name)_s"">&#9650;</a><hr /></td></tr><tr bgcolor=""#E8E8E8""><th rowspan=$($rowspan) nowrap=""nowrap""  valign=""baseline""><a name=""#$($group.Name)"">$($group.Name)</a></th></tr>"
						foreach ($member in $members)
						{
								if($member.RecipientTypeDetails -like "*Room*")
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#454545"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*User*")
								{
								if ($member.IsValidSecurityPrincipal -like "False")
								{$color="red"}else{$color="'#000066'"}
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=$color>$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*Contact*")
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#336633"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($member.RecipientTypeDetails -like "*Group*")
								{
								$Output+="<tr bgcolor=""#B0B0B0"">"
								$Output+="<td><font color=""#333333""><a href=""#$($member.Name)"">$($member.Name)</a></font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								else
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#000000"">$($member.Name)</font></td>"
								$Output+="<td>$($member.PrimarySmtpAddress)</td>"
								$Output+="<td>$($member.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
						}
					$i++
					}
			}
		}
		$i=0
	foreach ($dygroup in $dygroups)
		{
_Progress (85+((($i+1)*14)/$dygcount)) "Adding Members List for Dynamic Distribution Group $($i+1) of $($dygcount) to the Report"				
			$dymembers = Get-Recipient -Resultsize Unlimited -RecipientPreviewFilter $dygroup.RecipientFilter | Sort-Object name
			if(!$dymembers){}
			else
			{
				if (0,2,4,6,8 -contains "$i"[-1]-48) 
					{
						$rowspan=($dymembers | measure-object).count+1
						$Output+="<tr><td><a href=""#$($dygroup.Name)_s"">&#9650;</a><hr /></td></tr><tr bgcolor=""#E8E8E8""><th rowspan=$($rowspan) nowrap=""nowrap"" valign=""baseline""><a name=""#$($dygroup.Name)"">$($dygroup.Name)</a></th></tr>"
						foreach ($dymember in $dymembers)
						{
								if($dymember.RecipientTypeDetails -like "*Room*")
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#454545"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*User*")
								{
								if ($dymember.IsValidSecurityPrincipal -like "False")
								{$color="red"}else{$color="'#000066'"}
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=$color>$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*Contact*")
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#336633"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*Group*")
								{
								$Output+="<tr bgcolor=""#B0B0B0"">"
								$Output+="<td><font color=""#333333""><a href=""#$($dymember.Name)"">$($dymember.Name)</a></font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								else
								{
								$Output+="<tr bgcolor=""#E8E8E8"">"
								$Output+="<td><font color=""#000000"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
						}
					$i++
					}
				else
					{
						$rowspan=($dymembers | measure-object).count+1
						$Output+="<tr><td><a href=""#$($dygroup.Name)_s"">&#9650;</a><hr /></td></tr><tr bgcolor=""#C8C8C8""><th rowspan=$($rowspan) nowrap=""nowrap"" valign=""baseline""><a name=""#$($dygroup.Name)"">$($dygroup.Name)</a></th></tr>"
						foreach ($dymember in $dymembers)
						{
								if($dymember.RecipientTypeDetails -like "*Room*")
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#454545"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*User*")
								{
								if ($dymember.IsValidSecurityPrincipal -like "False")
								{$color="red"}else{$color="'#000066'"}
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=$color>$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*Contact*")
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#336633"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								elseif ($dymember.RecipientTypeDetails -like "*Group*")
								{
								$Output+="<tr bgcolor=""#B0B0B0"">"
								$Output+="<td><font color=""#333333""><a href=""#$($dymember.Name)"">$($dymember.Name)</a></font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
								else
								{
								$Output+="<tr bgcolor=""#C8C8C8"">"
								$Output+="<td><font color=""#000000"">$($dymember.Name)</font></td>"
								$Output+="<td>$($dymember.PrimarySmtpAddress)</td>"
								$Output+="<td>$($dymember.RecipientTypeDetails)</td>"
								$Output+="</tr>"
								}
						}
					$i++
					}
			}
		}
}
$Output+="</table></center>"
$Output+="<br><br>"
$Output+="<font size=""1"" face=""Arial,sans-serif"">Scripted by <a href=""http://www.get-mailbox.org"">Serkan Varoglu</a>.  
	Elapsed Time To Complete This Report: $($Watch.Elapsed.Minutes.ToString()):$($Watch.Elapsed.Seconds.ToString())</font></body></html>"
$Output | Out-File $HTMLReport
