#NAME: service_check.ps1 
#AUTHOR: Kevin Olson
#DATE: 4/29/2011

#Machine to be monitored
$Computer = "host1"

#Create an array of all services running
$GetService = get-service -ComputerName $Computer

#Create a subset of the previous array for services you want to monitor
$ServiceArray = "Service1","Service2","Service3";

#Find any iWFM service that is stopped
foreach ($Service in $GetService)
{
	foreach ($srv in $ServiceArray)
	{
		if ($Service.name -eq $srv)
		{
            #check if a service is hung ( I haven't test this, uncomment at your own risk)
			if ($Service.status -eq "StopPending")
            {
            #email to notify if a service is down
            Send-Mailmessage -to admin@domain.com -Subject "$srv is hung on $Computer" -from admin@domain.com -Body "The $srv service was found hung" -SmtpServer smtp.domain.com
            $servicePID = (gwmi win32_Service | where { $_.Name -eq $srv}).ProcessID
            Stop-Process $ServicePID
            Start-Service -InputObject (get-Service -ComputerName $Computer -Name $srv)
            }
            # check if a service is stopped
            elseif ($Service.status -eq "Stopped")
			{
		    #email to notify if a service is down
            Send-Mailmessage -to admin@domain.com -Subject "$srv is stopped on $Computer" -from admin@domain.com -Body "The $srv service was found stopped" -SmtpServer smtp.domain.com
			#automatically restart the service.
			Start-Service -InputObject (get-Service -ComputerName $Computer -Name $srv)
			}
		}
	}
}
