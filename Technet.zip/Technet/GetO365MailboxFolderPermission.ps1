﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function Get-OSCMsolMailboxFolderPermission
{
	<#
		.SYNOPSIS
		Get-OSCMsolMailboxFolderPermission is an advanced function which can be used to get mailbox folder permissions from Office 365 mailboxes.
		.DESCRIPTION
		Get-OSCMsolMailboxFolderPermission is an advanced function which can be used to get mailbox folder permissions from Office 365 mailboxes.
		It leverages the capability of Get-MailboxFolderPermission. Also, you can use filter to find specific mailboxes.
		.PARAMETER Credential
		Indicates the credential to use for connecting to Office 365.
		.PARAMETER MailboxFilter
		Indicates the OPath filter used to find mailboxes.
		.PARAMETER FolderName
		Indicates the name of mailbox folder.
		.PARAMETER DisconnectSession
		Indicates the session to Office 365 will be disconnected after this function is executed.
		.EXAMPLE
		#Returns the list of user permissions for John Doe's Calendar mailbox folder. (Windows PowerShell has already connected to Office 365.) 
		Get-OSCMsolMailboxFolderPermission -MailboxFilter 'DisplayName -eq "John Doe"' -FolderName "Calendar" -Verbose
		.EXAMPLE
		#Returns the list of user permissions for John Doe's Calendar mailbox folder. If Windows PowerShell has not connected to Office 365, you should use Get-Credential to get a credential object.
		This function will use the credential for establishing the connection.
		$cred = Get-Credential "admin@example01.onmicrosoft.com"
		Get-OSCMsolMailboxFolderPermission -Credential $cred -MailboxFilter 'DisplayName -eq "John Doe"' -FolderName "Calendar" -Verbose	
		.EXAMPLE
		#Returns the list of user permissions of Calendar folder for specific mailboxes which alias starts with "J".
		Get-OSCMsolMailboxFolderPermission -MailboxFilter 'Alias -like "J*"' -FolderName "Calendar" -Verbose
		.EXAMPLE
		#Returns the list of user permissions of SpecialEvents folder under Calendar folder for specific mailboxes which alias starts with "J". If the folder does not exist in some mailboxes, error messages will be displayed and "N/A" will appear in the final report.
		Get-OSCMsolMailboxFolderPermission -MailboxFilter 'Alias -like "J*"' -FolderName "Calendar\SpecialEvents" -Verbose
		.EXAMPLE
		#Returns the list of user permissions of Calendar folder for specific mailboxes which alias starts with "J". Then use Export-Csv to save the reports in a .csv file. After that, Windows PowerShell will be disconnected from Office 365.
		Get-OSCMsolMailboxFolderPermission -MailboxFilter 'DisplayName -like "j*"' -FolderName "Calendar" -DisconnectSession -Verbose | Export-Csv -Path "C:\Scripts\reports.csv" -NoTypeInformation
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Use Windows PowerShell in Exchange Online
		http://help.outlook.com/en-us/140/cc546278.aspx
		.LINK
		Reference to Available PowerShell Cmdlets in Exchange Online
		http://help.outlook.com/en-us/140/dd575549.aspx
		.LINK
		Get-MailboxFolderPermission
		http://technet.microsoft.com/en-us/library/dd335061.aspx
		.LINK
		Filterable Properties for the -Filter Parameter
		http://technet.microsoft.com/en-us/library/bb738155.aspx		
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[System.Management.Automation.PSCredential]$Credential,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$MailboxFilter,
		[Parameter(Mandatory=$true,Position=3)]
		[string]$FolderName,
		[Parameter(Mandatory=$false,Position=4)]
		[switch]$DisconnectSession
	)
	Process
	{
		$reports = @()
		#Connect Windows PowerShell to Office 365
		Try
		{
			#If session does not exist, create a new session.
			$existingSession = Get-PSSession -Verbose:$false | Where-Object {$_.ConfigurationName -eq "Microsoft.Exchange"}
			if ($existingSession -eq $null) {
				$verboseMsg = $Messages.CreatingSession
				$pscmdlet.WriteVerbose($verboseMsg)
				$O365Session = New-PSSession -ConfigurationName Microsoft.Exchange `
				-ConnectionUri "https://ps.outlook.com/powershell" -Credential $Credential `
				-Authentication Basic -AllowRedirection
				#If session is newly created, import the session.
				Import-PSSession -Session $O365Session -Verbose:$false | Out-Null
				$existingSession = $O365Session
			} else {
				$verboseMsg = $Messages.FoundExistingSession
				$pscmdlet.WriteVerbose($verboseMsg)
			}
		}
		Catch
		{
			$pscmdlet.WriteError($Error[0])
		}
		if ($existingSession -ne $null) {
			#Get mailboxes
			$mailboxes = Get-Mailbox -Filter $MailboxFilter -ResultSize unlimited
			#If mailboxes exists, use Get-MailboxFolderPermission to retrieve permissions. 
			if ($mailboxes -ne $null) {
				foreach ($mailbox in $mailboxes) {
					$mailboxAlias = $mailbox.Alias
					$mailboxDisplayName = $mailbox.DisplayName
					$permissions = Get-MailboxFolderPermission -Identity "$mailboxAlias`:\$FolderName"
					if ($permissions -ne $null) {
						foreach ($permission in $permissions) {
							$report = New-Object PSObject
							$report | Add-Member -MemberType NoteProperty -Name "MailboxAlias" -Value $mailboxAlias
							$report | Add-Member -MemberType NoteProperty -Name "MailboxDisplayName" -Value $mailboxDisplayName
							$report | Add-Member -MemberType NoteProperty -Name "FolderName" -Value $permission.FolderName
							$report | Add-Member -MemberType NoteProperty -Name "User" -Value $permission.User
							$report | Add-Member -MemberType NoteProperty -Name "AccessRights" -Value $permission.AccessRights
							$reports += $report
						}
					} else {
						$report = New-Object PSObject
						$report | Add-Member -MemberType NoteProperty -Name "MailboxAlias" -Value $mailboxAlias
						$report | Add-Member -MemberType NoteProperty -Name "MailboxDisplayName" -Value $mailboxDisplayName
						$report | Add-Member -MemberType NoteProperty -Name "FolderName" -Value "N/A"
						$report | Add-Member -MemberType NoteProperty -Name "User" -Value "N/A"
						$report | Add-Member -MemberType NoteProperty -Name "AccessRights" -Value "N/A"
						$reports += $report
					}

				}
			} else {
				$warningMsg = $Messages.CannotFindMBXWithSpecifiedFilter
				$warningMsg = $warningMsg -replace "Placeholder01",$MailboxFilter
				$pscmdlet.WriteWarning($warningMsg)
			}
			#Disconnect Windows PowerShell from Office 365
			if ($DisconnectSession) {
				Remove-PSSession -Session $existingSession -Verbose:$false
			}
			#Return the result
			return $reports
		}
	}
}

