<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Load Microsoft SharePoint Snapin
if ((Get-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null) {Add-PSSnapin Microsoft.SharePoint.PowerShell}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Add-OSCSPListItemAttachment
{
	<#
		.SYNOPSIS
		Add-OSCSPListItemAttachment is an advanced function which can be used to add attachments for a specific list item.
		.DESCRIPTION
		Add-OSCSPListItemAttachment is an advanced function which can be used to add attachments for a specific list item.
		.PARAMETER SiteURL
		Indicates the URL of a SharePoint site, in the form http://server_name/sites/sitename.
		.PARAMETER ListName
		Indicates the Name of a SharePoint site list, for example, "Shared Documents", "Calendar", "Tasks".
		.PARAMETER ItemID
		Indicates Add-OSCSPListItemAttachment will add attachments for a list item with specific ID.
		.PARAMETER Attachment
		Indicates the path of attachments which will be added.
		.EXAMPLE
		#Add an attachment for a specific list item.
		Add-OSCSPListItemAttachment -SiteURL "http://server_name/sites/sitename" -ListName "ListName" -ItemID 1 -Attachment "c:\scripts\testfile.txt" -Verbose
		.EXAMPLE
		#Add multiple attachments for a specific list item. (Method 01)
		Add-OSCSPListItemAttachment -SiteURL "http://server_name/sites/sitename" -ListName "ListName" -ItemID 1 -Attachment "c:\scripts\test02.txt","c:\scripts\test03.txt" -Verbose
		.EXAMPLE
		#Add multiple attachments for a specific list item. (Method 02)
		$files = Get-ChildItem c:\Scripts -Filter "Test1*.txt"
		$files | %{Add-OSCSPListItemAttachment -SiteURL "http://server_name/sites/sitename" -ListName "ListName" -ItemID 1 -Attachment $_.FullName -Verbose}		
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Microsoft.SharePoint.SPSite Class
		http://msdn.microsoft.com/en-us/library/microsoft.sharepoint.spsite.aspx
		.LINK
		Microsoft.SharePoint.SPList Class
		http://msdn.microsoft.com/en-us/library/microsoft.sharepoint.splist.aspx
		.LINK
		Microsoft.SharePoint.SPAttachmentCollection Class
		http://msdn.microsoft.com/en-us/library/ms472013.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$ListName,
		[Parameter(Mandatory=$true,Position=3)]
		[int]$ItemID,		
		[Parameter(Mandatory=$true,Position=4,ValueFromPipeline=$true)]
		[string[]]$Attachment
	)
	Process
	{
		Try
		{
			#Use Get-SPWeb to get a SPWeb object
			$spWeb = Get-SPWeb -Identity $SiteURL -ErrorAction Stop -Verbose:$false
		}
		Catch 
		{
			$pscmdlet.WriteError($Error[0])			
		}
		if ($spWeb -ne $null) {
			#Try to get a list, if list name is wrong, this function will be terminated.
			$spList = $spWeb.Lists.TryGetList($ListName)
			if ($spList -eq $null) {
				$errorMsg = $Messages.CannotFindSpecifiedList
				$errorMsg = $errorMsg -replace "Placeholder01",$ListName
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory ResourceUnavailable -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				$spWeb.Dispose()
				return $null
			}
			#Check attachments setting, if this feature is disabled,
			#exits this fuction immediately.
			if (-not $spList.EnableAttachments) {
				$errorMsg = $Messages.AttachmentFeatureDisabled
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory Notspecific -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				$spWeb.Dispose()
				return $null			
			}
			#Try to get a list item by ID.
			Try
			{
				$spListItem = $spList.GetItemByID($ItemID)
			}
			Catch
			{
				$errorMsg = $Messages.CannotFindSpecifiedItem
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory ObjectNotFound -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)		
			}
			if ($spListItem -ne $null) {
				foreach ($attachmentPath in $Attachment) {
					#Verify attachment path
					$isExist = Test-Path -Path $attachmentPath -PathType Leaf
					if ($isExist) {
						$fileBits = [System.IO.File]::ReadAllBytes($attachmentPath)
						#Exclude empty files
						if ($fileBits.Length -ne 0) {
							Try
							{
								$verboseMsg = $Messages.AddAttacment
								$verboseMsg = $verboseMsg -replace "Placeholder01",$attachmentPath
								$pscmdlet.WriteVerbose($verboseMsg)
								$spListItem.Attachments.AddNow($attachmentPath,$fileBits) | Out-Null
							}
							Catch
							{
								$pscmdlet.WriteError($Error[0])
							}
						} else {
							$warningMsg = $Messages.CannotAddEmptyFile
							$warningMsg = $warningMsg -replace "Placeholder01",$attachmentPath
							$pscmdlet.WriteWarning($warningMsg)
						}
					} else {
						$warningMsg = $Messages.CannotFindSpecifiedAttachment
						$warningMsg = $warningMsg -replace "Placeholder01",$attachmentPath
						$pscmdlet.WriteWarning($warningMsg)
					}
				}
			}
			$spWeb.Dispose()
			return $null
		}
	}
}

Function Remove-OSCSPListItemAttachment
{
	<#
		.SYNOPSIS
		Remove-OSCSPListItemAttachment is an advanced function which can be used to remove attachments for a specific list item.
		.DESCRIPTION
		Remove-OSCSPListItemAttachment is an advanced function which can be used to remove attachments for a specific list item.
		.PARAMETER SiteURL
		Indicates the URL of a SharePoint site, in the form http://server_name/sites/sitename.
		.PARAMETER ListName
		Indicates the Name of a SharePoint site list, for example, "Shared Documents", "Calendar", "Tasks".
		.PARAMETER ItemID
		Indicates Remove-OSCSPListItemAttachment will remove attachments for a list item with specific ID.
		.PARAMETER AttachmentName
		Indicates the name of attachments which will be removed. You can use regular expression for deleting multiple attachments.
		.PARAMETER MoveToRecycleBin
		Indicates the attachments should be recycled or deleted directly.
		.EXAMPLE
		#Recycle attachments which name matches Test1[0|2|4|6|8], like test10.txt,test12.txt,test14.txt,test16.txt,test18.txt
		Remove-OSCSPListItemAttachment -SiteURL "http://server_name/sites/sitename" -ListName "ListName" -ItemID 2 -AttachmentName "Test1[0|2|4|6|8]" -MoveToRecycleBin -Verbose		
		.EXAMPLE
		#Remove attachments which name matches Test1[0|2|4|6|8] directly, like test10.txt,test12.txt,test14.txt,test16.txt,test18.txt
		Remove-OSCSPListItemAttachment -SiteURL "http://server_name/sites/sitename" -ListName "ListName" -ItemID 2 -AttachmentName "Test1[0|2|4|6|8]" -MoveToRecycleBin:$false -Verbose		
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Microsoft.SharePoint.SPSite Class
		http://msdn.microsoft.com/en-us/library/microsoft.sharepoint.spsite.aspx
		.LINK
		Microsoft.SharePoint.SPList Class
		http://msdn.microsoft.com/en-us/library/microsoft.sharepoint.splist.aspx
		.LINK
		Microsoft.SharePoint.SPAttachmentCollection Class
		http://msdn.microsoft.com/en-us/library/ms472013.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$ListName,
		[Parameter(Mandatory=$true,Position=3)]
		[int]$ItemID,		
		[Parameter(Mandatory=$true,Position=4)]
		[string]$AttachmentName,
		[Parameter(Mandatory=$true,Position=5)]
		[switch]$MoveToRecycleBin
	)
	Process
	{
		Try
		{
			#Use Get-SPWeb to get a SPWeb object
			$spWeb = Get-SPWeb -Identity $SiteURL -ErrorAction Stop -Verbose:$false
		}
		Catch 
		{
			$pscmdlet.WriteError($Error[0])
		}
		if ($spWeb -ne $null) {
			#Try to get a list, if list name is wrong, this function will be terminated.
			$spList = $spWeb.Lists.TryGetList($ListName)
			if ($spList -eq $null) {
				$errorMsg = $Messages.CannotFindSpecifiedList
				$errorMsg = $errorMsg -replace "Placeholder01",$ListName
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory ResourceUnavailable -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				$spWeb.Dispose()
				return $null
			}
			#Check attachments setting, if this feature is disabled,
			#exits this fuction immediately.
			if (-not $spList.EnableAttachments) {
				$errorMsg = $Messages.AttachmentFeatureDisabled
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory Notspecific -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
				$spWeb.Dispose()
				return $null
			}
			#Try to get a list item by ID.
			Try
			{
				$spListItem = $spList.GetItemByID($ItemID)
			}
			Catch
			{
				$errorMsg = $Messages.CannotFindSpecifiedItem
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory ObjectNotFound -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)		
			}
			if ($spListItem -ne $null) {
				if ($spListItem.Attachments.Count -gt 0) {
					#Get SPAttachmentCollection
					$spAttachments = $spListItem.Attachments
					#Create an array for storing the attachment names which will be deleted later.
					$spAttachmentNames = @()
					#Loop each existed attachment name and use regular expression for comparison.
					for ($i = 0;$i -le $spListItem.Attachments.Count;$i++) {
						if ($spAttachments[$i] -match $AttachmentName) {
							$spAttachmentNames += $spAttachments[$i]
						}
					}
					#If find a match, begin to remove the specific attachments
					if ($spAttachmentNames -ne $null) {
						foreach ($spAttachmentName in $spAttachmentNames) {
							#You have two options, move the attachments to the Recycle Bin,
							#or delete it directly.
							if ($MoveToRecycleBin) {
								$verboseMsg = $Messages.RecycleItem
								$verboseMsg = $verboseMsg -replace "Placeholder01",$spAttachmentName
								$pscmdlet.WriteVerbose($verboseMsg)
								$spAttachments.RecycleNow($spAttachmentName)
							} else {
								$verboseMsg = $Messages.RemoveItem
								$verboseMsg = $verboseMsg -replace "Placeholder01",$spAttachmentName
								$pscmdlet.WriteVerbose($verboseMsg)							
								$spAttachments.DeleteNow($spAttachmentName)
							}
							$spAttachments = $spListItem.Attachments
						}
					} else {
						$warningMsg = $Messages.CannotFindspecificAttachments
						$warningMsg = $warningMsg -replace "Placeholder01",$AttachmentName
						$pscmdlet.WriteWarning($warningMsg)
					}
				} else {
					$errorMsg = $Messages.CannotFindAttachments
					$customError = New-OSCPSCustomErrorRecord `
					-ExceptionString $errorMsg `
					-ErrorCategory ObjectNotFound -ErrorID 1 -TargetObject $pscmdlet
					$pscmdlet.WriteError($customError)					
				}
			}
			$spWeb.Dispose()
			return $null
		}
	}
}

