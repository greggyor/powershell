###############################################################
# ADPassword_reset_v1.0.ps1
# Version 1.0
# MALEK Ahmed - 04 / 03 / 2013
###################

##################
#--------Config
##################
$adPath="LDAP://DC=contoso,DC=msft"
$domaindnsname = "contoso.msft"
$domainnetbiosname = "CONTOSO"
$smtpserver = "mail.contoso.msft"
$noreplymail = "no-reply@contoso.msft"  

##################
#--------Function 
##################
Function Set-AdUserPwd 
{ 
Param( 
[string]$user, 
[string]$pwd 
) #end param 
$oUser = [adsi]"LDAP://$user" 
$ouser.psbase.invoke("SetPassword",$pwd) 
$ouser.psbase.CommitChanges() 
} # end function Set-AdUserPwd
    
##################
#--------Main  
##################
cls
#Prompting the user to enter the variables
#Determine if the user is external or not
$usernameAD = ([Environment]::UserDomainName).ToString() + "\" + ([Environment]::UserName).ToString()
#Reads the User samaccountname
$samaccountname = Read-Host 'What is the user samaccountname?'
#Define the User Password
$password = .\Get-RandomString.ps1 -Length 8 -LowerCase:$FALSE -Numbers:$TRUE -UpperCase:$TRUE
#Doing the password reset
import-module activedirectory
#Identify the creator e-mail address
$User = get-aduser ([Environment]::UserName).ToString() -Properties Mail
$accountcreator = $User.mail
#LDAP connection
$objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
#Doing an LDAP search
$ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
$ObjSearch.PageSize = 60000
#Filtering user accounts based on their samaccountname
$ObjSearch.Filter = "(&(objectCategory=person)(objectClass=user)(samaccountname="+$samaccountname+"))"
$allSearchResult = $ObjSearch.FindAll()
if ($allSearchResult.Count -eq 0)
{
    $errormessagesamaccountname = "The is no such login in " + $domaindnsname + " domain, please try another one!"
    $samaccountname = Read-Host $errormessagesamaccountname
    $ObjSearch.Filter = "(&(objectCategory=person)(objectClass=user)(samaccountname="+$samaccountname+"))"
    $allSearchResult = $ObjSearch.FindAll()
    while ($allSearchResult.Count -eq 0)
    {
        $samaccountname = Read-Host $errormessagesamaccountname
        $ObjSearch.Filter = "(&(objectCategory=person)(objectClass=user)(samaccountname="+$samaccountname+"))"
        $allSearchResult = $ObjSearch.FindAll()
    }
    foreach ($objSearchResult in $allSearchResult)
    {
        $objUser=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $test1 = $Error.Count
        Set-AdUserPwd -user $objUser.distinguishedname -pwd $password
        $test2 = $Error.Count
        if($test1 -eq $test2)
        {
            $passwordreset = $true
        }
        else
        {
            $passwordreset = $false
        }
    }
}
else
{
    foreach ($objSearchResult in $allSearchResult)
    {
        $objUser=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $test1 = $Error.Count
        Set-AdUserPwd -user $objUser.distinguishedname -pwd $password
        $test2 = $Error.Count
        if($test1 -eq $test2)
        {
            $passwordreset = $true
        }
        else
        {
            $passwordreset = $false
        }
    }  
}

#Notification
$wshShell =  new-object �comobject �wscript.shell�
if ($passwordreset)
{
    $wshShell.Popup("The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was done successfully. The new password is " + $password + "", 0, "[SUCCESS] The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was done successfully", 48);
    $mailbody = "AD Login = " + $domainnetbiosname + "\" + $samaccountname + "`r`n`r`n"
    $mailbody += "Password = " + $password + "`r`n`r`n"
    $mailbody += "The password reset was done by " + $usernameAD
    #Notification about the script execution
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    $msg.From = $noreplymail
    $msg.To.Add($accountcreator)
    $msg.Subject = "[SUCCESS] The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was done successfully"
    $msg.Body = $mailbody
    $smtp.Send($msg)    
}
else
{
    $wshShell.Popup("The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was not done successfully", 0, "[ERROR] The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was not done successfully", 48);
    $mailbody = "AD Login = " + $domainnetbiosname + "\" + $samaccountname + "`r`n`r`n"
    $mailbody += "`r`n`r`n"
    $mailbody += "The error occured when doing the password reset will be checked by the Centralized Infrastructure Team!`r`n`r`n"
    $mailbody += "Debugging [Centralized Infra]: samaccountname: "+ $samaccountname + "`r`n`r`n"
    $mailbody += "The password reset was done by " + $usernameAD
    #Notification about the script execution
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    $msg.From = $noreplymail
    $msg.To.Add($accountcreator)
    $msg.Subject =  "[ERROR] The password reset for " + $domainnetbiosname + "\" + $samaccountname + " was not done successfully"
    $msg.Body = $mailbody
    $smtp.Send($msg)
}