﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Search-OSCCsUser
{
	#.EXTERNALHELP Search-OSCCSUser-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[ValidateSet("Voice","Conferencing","Pin","ExternalAccess","Location","Client","ClientVersion","Presence","Mobility","Archiving")]
		[string]$PolicyType,
		[Parameter(Mandatory=$true,Position=2)]
		[hashtable]$Feature
	)
	Process
	{
		$userFilters = @()
		$policyFeatures = @{}
		#Prepare feature list for each policy, it will be used for validation
		$nonFeatures = "Anchor","Description","Identity","Name","Priority","RuleId","ScopeClass","PolicyEntry"
		Switch -regex ($PolicyType) {		
			"ClientVersion" {
				$csSites = Get-CsSite -Verbose:$false
				$sitesCount = ($csSites | Measure-Object).Count
				if ($sitesCount -eq 1) {
					$siteID = $csSites.Identity
				} else {
					$siteID = $csSites[0].Identity
				}
				$tempGUID = [System.Guid]::NewGuid()
				$ruleTemplate = New-CsClientVersionPolicyRule -Parent "Site:$siteID" -RuleId $tempGUID -InMemory
				$ruleTemplate | Get-Member -MemberType Property | %{$policyFeatures.Add($_.Name,$_.Definition)}
				break
			}			
			"Voice|Conferencing|Pin|ExternalAccess|Location|Client|Presence|Mobility|Archiving" {
				$command = "New-Cs$($PolicyType)Policy -Identity `"Template`" -InMemory -Verbose:`$false"
				$policyTemplate = Invoke-Expression -Command $command
				$policyTemplate | Get-Member -MemberType Property | %{$policyFeatures.Add($_.Name,$_.Definition)}
				break
			}
		}
		#Remove any unnecessary properties
		$nonFeatures | %{$policyFeatures.Remove($_)}		
		#Build filter for finding policies
		$userSpecifiedFeatures = @()
		foreach ($featureKey in $Feature.Keys.GetEnumerator()) {
			if ($policyFeatures.ContainsKey($featureKey)) {
				$policyFeatureDefinition = $policyFeatures[$featureKey]
				Switch -regex ($policyFeatureDefinition) {
					"System.Boolean*" {
						$featureValue = "`$$($Feature[$featureKey])"
						$userSpecifiedFeatures += "`$_.$featureKey -eq $featureValue"
						break
					}
					"System.Collections.Generic.IList`1*" {
						$featureValue = $Feature[$featureKey]
						$userSpecifiedFeatures += "(`$_.$featureKey -join `",`") -eq `"$featureValue`""
						break
					}
					Default {
						$featureValue = "$($Feature[$featureKey])"
						$userSpecifiedFeatures += "`$_.$featureKey -eq `"$featureValue`""
					}
				}
			} else {
				$warningMsg = $Messages.InvalidFeature
				$warningMsg = $warningMsg -f $featureKey
				$pscmdlet.WriteWarning($warningMsg)
			}
		}
		if ($userSpecifiedFeatures.Count -eq 1) {
			$featureFilter = $userSpecifiedFeatures -join ""
		} elseif ($userSpecifiedFeatures.Count -gt 1) {
			$featureFilter = "(" + $($userSpecifiedFeatures -join ") -and (") + ")"		
		} else {
			$featureFilter = $null
		}
		#Get specific policies
		if ($featureFilter -ne $null) {
			$verboseMsg = $Messages.FeatureFilter
			$verboseMsg = $verboseMsg -f $PolicyType,$($featureFilter.Replace("`$_.",""))
			$pscmdlet.WriteVerbose($verboseMsg)
			Switch -regex ($PolicyType) {
				"ClientVersion" {
					$command = "Get-CsClientVersionPolicyRule -Filter tag* -Verbose:`$false | Where-Object {$featureFilter}"
					break
				}
				"Voice|Conferencing|Pin|ExternalAccess|Location|Client|Presence|Mobility|Archiving" {
					$command = "Get-Cs$($PolicyType)Policy -Filter tag* -Verbose:`$false | Where-Object {$featureFilter}"
					break
				}
			}
			Try
			{
				$policies = Invoke-Expression -Command $command
			}
			Catch
			{
				#Suppress any errors.
			}
		}
		#Generate user filter for finding users
		if ($Policies -ne $null) {
			$policyCount = ($Policies | Measure-Object).Count
			$verboseMsg = $Messages.FoundPolicy
			$verboseMsg = $verboseMsg -f $policyCount
			$pscmdlet.WriteVerbose($verboseMsg)
			Switch -regex ($PolicyType) {
				"ClientVersion" {
					$tempPolicies = @{}
					foreach ($rule in $Policies) {
						$policyID = ($rule.Identity.Split("/"))[0]
						$policyID = $policyID.Replace("Tag:","")
						if (-not $tempPolicies.ContainsKey($policyID)) {
							$tempPolicies.Add($policyID,"")
						}
					}
					foreach ($rule in $tempPolicies.Keys.GetEnumerator()) {
						$userFilters += "ClientVersionPolicy -eq '$rule'"
					}
					break
				}
				"Voice|Conferencing|Pin|ExternalAccess|Location|Client|Presence|Mobility|Archiving" {
					foreach ($policy in $policies) {
						$policyId = $policy.Identity.Split(":")[1]
						$userFilters += "$($PolicyType)Policy -eq '$policyId'"
					}
					break
				}
			}
		} else {
			$warningMsg = $Messages.CannotFindPolicy
			$warningMsg = $warningMsg -f $PolicyType
			$pscmdlet.WriteWarning($warningMsg)
		}
		if ($userFilters.Count -eq 1) {
			$userFilter = $userFilters -join ""
		} elseif ($userFilters.Count -gt 1) {
			$userFilter = "(" + $($userFilters -join ") -or (") + ")"
		} else {
			$errorMsg = $Messages.CannotGenerateUserFilter
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		$verboseMsg = $Messages.UserFilter
		$verboseMsg = $verboseMsg -f $($userFilter.Replace("`$_.","")),$PolicyType
		$pscmdlet.WriteVerbose($verboseMsg)
		#Find users by using Get-CsUser cmdlet
		$csUsers = Get-CsUser -Filter $userFilter
		if ($csUsers -ne $null) {
			$usersCount = ($csUsers | Measure-Object).Count
			$verboseMsg = $Messages.FoundUser
			$verboseMsg = $verboseMsg -f $usersCount
			$pscmdlet.WriteVerbose($verboseMsg)			
			return $csUsers
		} else {
			$verboseMsg = $Messages.CannotFindUser
			$pscmdlet.WriteVerbose($verboseMsg)
			return $null
		}		
	}
}

