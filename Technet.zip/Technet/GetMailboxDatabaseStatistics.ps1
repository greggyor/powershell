﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
	   [Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
	   [Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
	   [Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
	   [Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
	   $exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
	   $customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
	   return $customError
	}
}

Function Get-OSCEXMailboxDatabaseStatistics
{
	<#
		.SYNOPSIS
		Get-OSCEXMailboxDatabaseStatistics is an advanced function which can be used to collect the properties of mailbox and mailbox database.
		.DESCRIPTION
		Get-OSCEXMailboxDatabaseStatistics is an advanced function which can be used to collect the properties of mailbox and mailbox database.
		.PARAMETER MailboxProperty
		Indicates the name of mailbox properties which will be retrieved, in the form "Name","Alias".
		Please do not use wildcard character(*) in the property name or as the value of this parameter.
		The property names should not be conflicted with the names of mailbox database property.
		.PARAMETER MailboxDatabaseProperty
		Indicates the name of mailbox database properties which will be retrieved, in the form "LastFullBackup","DatabaseSize".
		Please do not use wildcard character(*) in the property name or as the value of this parameter.
		The property names should not be conflicted with the names of mailbox property.
		.PARAMETER MailboxFilter
		Indicates the OPath filter used to find mailboxes.
		.EXAMPLE
		#Retrieve specified property values for all mailboxes
		Get-OSCEXMailboxDatabaseStatistics -MailboxProperty "Name","Alias" -MailboxDatabaseProperty "LastFullBackup","DatabaseSize" | Format-Table -Autosize
		.EXAMPLE
		#Retrieve specified property values for these mailboxes which alias starts with "TestUser0"
		Get-OSCEXMailboxDatabaseStatistics -MailboxProperty "Name","Alias" -MailboxDatabaseProperty "LastFullBackup","DatabaseSize" -MailboxFilter 'Alias -like "TestUser0*"' | Format-Table -Autosize
		.EXAMPLE
		#Retrieve specified property values for these mailboxes which alias starts with "TestUser0" and exports the results to a comma-separated values (CSV) file.
		Get-OSCEXMailboxDatabaseStatistics -MailboxProperty "Name","Alias" -MailboxDatabaseProperty "LastFullBackup","DatabaseSize" -MailboxFilter 'Alias -like "TestUser*"' | Export-Csv -Path c:\Scripts\mailbox-statistics.csv -NoTypeInformation
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Get-Mailbox
		http://technet.microsoft.com/en-us/library/bb123685.aspx
		.LINK
		Get-MailboxDatabase
		http://technet.microsoft.com/en-us/library/bb124924.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string[]]$MailboxProperty,
		[Parameter(Mandatory=$true,Position=2)]
		[string[]]$MailboxDatabaseProperty,
		[Parameter(Mandatory=$false,Position=3)]
		[string]$MailboxFilter
	)
	Process
	{
		#Define two variables for storing the information.
		$results = @()
		$mbxDBStatistics = @{}
		#Define a ProgressRecord
		$activityName = $Messages.ActivityName
		$progressRecord = New-Object System.Management.Automation.ProgressRecord(1,$activityName,"Processing")
		#Try to get mailbox servers
		if (-not ([System.String]::IsNullOrEmpty($MailboxFilter))) {
			$mailboxes = Get-Mailbox -Filter $MailboxFilter -ResultSize unlimited -Verbose:$false
		} else {
			$mailboxes = Get-Mailbox -ResultSize unlimited -Verbose:$false
		}
		if ($mailboxes -ne $null) {
			foreach ($mailbox in $mailboxes) {
				$counter++
				if ($mailboxes -is [array]) {
					$progressPercent = [int]($counter / ($mailboxes.Count) * 100)
				}
				#Define a variable for storing the information.
				$result = New-Object PSObject
				#Display progress
				$verboseMsg = $Messages.ProcessingMailbox
				$verboseMsg = $verboseMsg -replace "Placeholder01", $($mailbox.Alias)
				$pscmdlet.WriteVerbose($verboseMsg)
				$progressRecord.CurrentOperation = $verboseMsg
				$progressRecord.PercentComplete = $progressPercent
				$pscmdlet.WriteProgress($progressRecord)
				#Begin to process
				$mbxServerName = $mailbox.ServerName
				$mbxDBName = $mailbox.Database
				$result | Add-Member -MemberType NoteProperty -Name "ServerName" -Value $mbxServerName
				$result | Add-Member -MemberType NoteProperty -Name "Database" -Value $mbxDBName
				if (-not ($mbxDBStatistics.ContainsKey($mbxDBName))) {
					$mbxDB = Get-MailboxDatabase -Identity $mbxDBName -Status -Verbose:$false
					$mbxDBStatistics.Add($mbxDBName,$mbxDB)
				}
				foreach ($mbxDBProperty in $MailboxDatabaseProperty) {
					$mbxDBPropertyValue = $mbxDBStatistics[$mbxDBName].$mbxDBProperty
					$result | Add-Member -MemberType NoteProperty -Name "$mbxDBProperty" -Value $mbxDBPropertyValue
				}
				foreach ($mbxProperty in $MailboxProperty) {
					$result | Add-Member -MemberType NoteProperty -Name "$mbxProperty" -Value $($mailbox.$mbxProperty)
				}
				$results += $result
			}
		} else {
			#Cannot find mailboxes with specified filter
			$errorMsg = $Messages.CannotFindMBXWithSpecifiedFilter
			$errorMsg = $errorMsg -replace "Placeholder01",$MailboxFilter
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null		
		}
		#Return the results
		return $results
	}
}

