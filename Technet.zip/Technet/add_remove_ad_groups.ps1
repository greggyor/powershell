########################################################### 
# AUTHOR  : Marius / Hican - http://www.hican.nl - @hicannl  
# DATE    : 05-07-2012  
# COMMENT : Script to add/remove AD Groups to one another.
###########################################################

#ERROR REPORTING ALL
Set-StrictMode -Version latest

#IMPORT the ActiveDirectory Module
Import-Module ActiveDirectory

$path         = Split-Path -parent $MyInvocation.MyCommand.Definition
$inputGroups  = $path + "\input.csv"
$exist_parent = ""
$exist_child  = ""

Function AddRemoveADGroups
{
  Import-CSV $inputGroups | ForEach-Object {
  #Check all Parent + Child groups if they are existent
  Try
  {
    $exist_parent = Get-ADGroup $_.ParentGroup -ErrorAction Stop
    $exist_child  = Get-ADGroup $_.ChildGroup -ErrorAction Stop
  }
  Catch
  {
    Write-Host "$($_.Exception.Message)"
  }
  If ($exist_parent -ne "" -And $exist_parent -ne $Null -And $exist_child -ne "" -And $exist_child -ne $Null)
  {
    $pg = $_.ParentGroup
    $cg = $_.ChildGroup
    If ($_.Action -eq "ADD")
    {
      Try
      {
        $member_add = Add-ADGroupMember $_.ParentGroup $_.ChildGroup
        Write-Host "Added  ($cg)  to  ($pg)"
      }
      Catch
      {
        Write-Host "$($_.Exception.Message)"
      }
    }

    If ($_.Action -eq "REMOVE")
    {
      Try
      {
        $member_remove = Remove-ADGroupMember $_.ParentGroup $_.ChildGroup -Confirm:$False
        Write-Host "Removed  ($cg)  from  ($pg)"
      }
      Catch
      {
        Write-Host "$($_.Exception.Message)"
      }
    }
  }
}

AddRemoveADGroups