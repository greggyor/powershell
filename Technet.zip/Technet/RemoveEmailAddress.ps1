﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Remove-OSCEXEmailAddress
{
	<#
		.SYNOPSIS
		Remove-OSCEXEmailAddress is an advanced function which can be used to remove e-mail addressed with specified domain name from mailbox, distribution group and dynamic distribution group.
		.DESCRIPTION
		Remove-OSCEXEmailAddress is an advanced function which can be used to remove e-mail addressed with specified domain name from mailbox, distribution group and dynamic distribution group.
		.PARAMETER Filter
		Indicates the OPath filter used to filter recipients.
		.PARAMETER DomainName
		Indicates the domain name part of an e-mail address.You can specify multiple domain names in the form "example01.com","example02.com".
		.EXAMPLE
		#Confirm the operations which will be executed by using -Whatif parameter.
		Remove-OSCEXEmailAddress -Filter 'Alias -like "New*"' -DomainName "example01.com" -Whatif
		.EXAMPLE
		#Remove email address which contains specific domain name from mailbox.
		Remove-OSCEXEmailAddress -Filter '(Alias -like "New*") -and (RecipientType -eq "UserMailbox")' -DomainName "example02.com" -Verbose
		.EXAMPLE
		#Remove email address which contains specific domain name from distribution group.
		Remove-OSCEXEmailAddress -Filter '(Alias -like "New*") -and (RecipientType -eq "MailUniversalDistributionGroup")' -DomainName "example02.com" -Verbose
		.EXAMPLE
		#Remove email address which contains specific domain name from dynamic distribution group.
		Remove-OSCEXEmailAddress -Filter '(Alias -like "New*") -and (RecipientType -eq "DynamicDistributionGroup")' -DomainName "example02.com" -Verbose		
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Filterable Properties for the -Filter Parameter
		http://technet.microsoft.com/en-us/library/bb738155.aspx		
	#>
	
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Filter,
		[Parameter(Mandatory=$true,Position=2)]
		[string[]]$DomainName
	)
	Process
	{
		#Get mailboxes or distribution groups
		$recipients = Get-Recipient -Filter $Filter -ResultSize unlimited -Verbose:$false
		if ($recipients -ne $null) {
			foreach ($recipient in $recipients) {		
				if ($recipient.RecipientType -notmatch "UserMailbox|DistributionGroup") {
					$warningMsg = $Messages.RecipientTypeIsNotSupported
					$warningMsg = $warningMsg -replace "Placeholder01",$($recipient.RecipientType)
					$pscmdlet.WriteWarning($warningMsg)				
				} else {
					for ($i=0;$i -lt $recipient.EmailAddresses.Count;$i++) {
						#Begin to remove invalid email address one by one.
						$addressDomain = $recipient.EmailAddresses[$i].AddressString.Split("@")[1]
						if ($DomainName -contains $addressDomain) {
							$primarySmtpAddress = $recipient.PrimarySmtpAddress.ToString()
							$invalidEmailAddress = $($recipient.EmailAddresses[$i])
							#Use ShouldProcess method for supporting -Whatif parameter
							if ($pscmdlet.ShouldProcess($($recipient.Alias))) {
								if ($invalidEmailAddress -ne $primarySmtpAddress) {
									$verboseMsg = $Messages.RemoveAddress
									$verboseMsg = $verboseMsg -replace "Placeholder01",$($recipient.EmailAddresses[$i])
									$pscmdlet.WriteVerbose($verboseMsg)
									Switch ($recipient.RecipientType) {
										"UserMailbox" {
											$mailbox = Get-Mailbox -Identity $($recipient.Alias) -Verbose:$false
											$returnValue = $mailbox.EmailAddresses.Remove($invalidEmailAddress)
											if ($returnValue) {
												Set-Mailbox -Identity $mailbox -EmailAddresses $mailbox.EmailAddresses -Verbose:$false
											}
										}
										"MailUniversalDistributionGroup" {
											$distributionGroup = Get-DistributionGroup -Identity $($recipient.Alias) -Verbose:$false
											$returnValue = $distributionGroup.EmailAddresses.Remove($invalidEmailAddress)
											if ($returnValue) { 
												Set-DistributionGroup -Identity $distributionGroup -EmailAddresses $distributionGroup.EmailAddresses -Verbose:$false									
											}
										}
										"DynamicDistributionGroup" {
											$dynamicDistributionGroup = Get-DynamicDistributionGroup -Identity $($recipient.Alias) -Verbose:$false
											$returnValue = $dynamicDistributionGroup.EmailAddresses.Remove($invalidEmailAddress)
											if ($returnValue) {
												Set-DynamicDistributionGroup -Identity $dynamicDistributionGroup -EmailAddresses $dynamicDistributionGroup.EmailAddresses -Verbose:$false									
											}
										}
									}
								} else {
									#Remove primary SMTP address is not supported by this function.
								}
							}
						}
					}
				}
			}
		} else {
			$errorMsg = $Messages.CannotFindRecipient
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.WriteError($customError)
			return $null
		}
	}
}

