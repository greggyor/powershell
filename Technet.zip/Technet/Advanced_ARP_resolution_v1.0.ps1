﻿<#  
 Author:   Andreas Werner 
 Create:   04.02.2013 
 Modiy:    04.02.2013 
 Version:  1.0
 From:     Germany 
 Email:    ps@werner-it.net 
 Website:  www.werner-it.net 
 
 Description 
 Advanced ARP resolution
#>


#------------------
#---> Function <---
#------------------

function GetManufacturer(){
param([string]$MAC)

$MAC -match "([0-9a-z]{2})-([0-9a-z]{2})-([0-9a-z]{2})-(.*)" | Out-Null

$OUI_Entry=$Matches[1]+$Matches[2]+$Matches[3]
$Manufacturer= $OUI_List[$OUI_Entry]

return $Manufacturer
}

#---------------------
#--->  S T A R T  <---
#---------------------
Clear-Host
[string]$Patter="(.*)([0-9a-z]{2}-[0-9a-z]{2}-[0-9a-z]{2}-[0-9a-z]{2}-[0-9a-z]{2}-[0-9a-z]{2})(.*)"

$ARPcache=arp -a


$ARPdyn_List=@() #;$ARPdyn_List=$null
$ARPsta_List=@() #;$ARPsta_List=$null
$OUI_List=@{};$Path=(Get-Location).Path + "\oui.txt"
$Path
Import-Csv -Path $Path | foreach {$OUI_List[$_.OUI]= $_.Manufacturer}

ForEach ($ARPentry in $ARPcache) {
    $ARPentry -match $Patter | Out-Null
        #$ARP_Entry = $null
        $ARP_Entry = New-Object system.object
        $ARP_Entry | Add-Member -Type NoteProperty -Name 'IPv4-Address' -Value $matches[1].Trim() -Force
        $ARP_Entry | Add-Member -Type NoteProperty -Name 'MAC-Address' -Value $matches[2].Trim() -Force        
        
      $cache=$matches[3].Trim()
        if ($cache -like "dyn*") {
        
            $Manufacturer= GetManufacturer $matches[2]
            $ARP_Entry | Add-Member -Type NoteProperty -Name 'Manufacturer' -Value $Manufacturer -Force
            
           try{ $DNSHost=[System.Net.Dns]::GetHostByAddress($matches[1].Trim()) }
           catch {$ARP_Entry | Add-Member -Type NoteProperty -Name 'DNS Hostname' -Value "not resolve" -Force}
           Finally {$ARP_Entry | Add-Member -Type NoteProperty -Name 'DNS Hostname' -Value $DNSHost.HostName -Force}  
            
            $ARPdyn_List+=$ARP_Entry}
        else {$ARPsta_List+=$ARP_Entry}        
}

Write-Host " -----<<< dynamic ARP entrys >>>----- " -ForegroundColor Black -BackgroundColor Yellow
$ARPdyn_List | Sort-Object Manufacturer | Format-Table -AutoSize

Write-Host ""
Write-Host " -----<<< static ARP entrys >>>----- " -ForegroundColor Black -BackgroundColor Yellow
$ARPsta_List | Sort-Object Manufacturer | Format-Table -AutoSize

Write-Host "----------------------------------------------"
Write-Host "Local dynamic ARP entrys: " $ARPdyn_List.count -ForegroundColor Black -BackgroundColor Green
Write-Host "Local static ARP entrys:  " $ARPsta_List.count -ForegroundColor Black -BackgroundColor Green