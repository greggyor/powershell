﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function Get-OSCEXMailboxDBReport
{
	<#
		.SYNOPSIS
		Get-OSCEXMailboxDBReport is an advanced function which can be used to get mailbox database statistics and mailbox statistics.
		.DESCRIPTION
		Get-OSCEXMailboxDBReport is an advanced function which can be used to get mailbox database statistics and mailbox statistics.
		This function leverage the capability of Measure-Object cmdlet, for example, you can calculate average mialbox size for each database. 
		.PARAMETER Database
		Indicates the name of mailbox database.
		.PARAMETER DataBaseProperty
		Indicates the properties of mailbox database. By default, this function will display "ServerName","DatabaseName","DatabaseSize" and "AvailableNewMailboxSpace".
		You can add addtional properties in the form "IssueWarningQuota","ProhibitSendQuota". Wildcard character is not supported.
		.PARAMETER MailboxStatisticsProperty
		Indicates the properties of mailbox stattistics. You can specify any property which can be measured.
		These properties should be supplied in the following form "Property(MeasureMethod)". For example, "TotalItemSize(Average)","ItemCount(Sum)"
		Valid measure methods are Average, Sum, Maximum, Minimum.
		.PARAMETER IncludeDisconnectedMailbox
		Indicates the statistics contains the value from disconnected mailbox.
		.EXAMPLE
		#Calculate average value and sum value of TotalItemSize property for specific mailbox database.
		Get-OSCEXMailboxDBReport -Database "MailboxDB" -MailboxStatisticsProperty "TotalItemSize(Average)","TotalItemSize(Sum)"
		#Calculate average value and sum value of TotalItemSize property for specific mailbox database. (Includes disconnected mailbox)
		Get-OSCEXMailboxDBReport -Database "MailboxDB" -MailboxStatisticsProperty "TotalItemSize(Average)","TotalItemSize(Sum)"	-IncludeDisconnectedMailbox	
		.EXAMPLE
		#Calculate average value and sum value of TotalItemSize property for specific mailbox database.
		#And use "Calculated Property" to convert TotalItemSize from bytes to megabytes.
		Get-OSCEXMailboxDBReport -Database "MailboxDB" -MailboxStatisticsProperty "ItemCount(Average)","TotalItemSize(Sum)" `
		| Select *,@{Name="TotalItemSizeInMB(Sum)";Expression={$_."TotalItemSize(Sum)" / 1MB}} -ExcludeProperty "TotalItemSize(Sum)"
		.EXAMPLE
		#Calculate average value of ItemCount property and sum value of TotalItemSize property for specific mailbox database.
		#IssueWarningQuota and ProhibitSendQuota which are the properties of mailbox database will be included in the report.
		Get-OSCEXMailboxDBReport -Database "MailboxDB" -DataBaseProperty "IssueWarningQuota","ProhibitSendQuota" -MailboxStatisticsProperty "ItemCount(Average)","TotalItemSize(Sum)"
		.EXAMPLE
		#Calculate average value of ItemCount property and sum value of TotalItemSize property for all mailbox databases.
		#Then use "Calculated Property" to convert TotalItemSize from bytes to megabytes.
		$dbs = Get-MailboxDatabase
		$dbs | %{Get-OSCEXMailboxDBReport -Database $_.Name -MailboxStatisticsProperty "TotalItemSize(Sum)","ItemCount(Average)" -Verbose `
		| Select *,@{Name="TotalItemSizeInMB(Sum)";Expression={$_."TotalItemSize(Sum)" / 1MB}} -ExcludeProperty "TotalItemSize(Sum)"}
		.LINK
		Windows PowerShell Advanced Function
		http://technet.microsoft.com/en-us/library/dd315326.aspx
		.LINK
		Get-MailboxDatabase
		http://technet.microsoft.com/en-us/library/bb124924.aspx
		.LINK
		Get-MailboxStatistics
		http://technet.microsoft.com/en-us/library/bb124612.aspx
		.LINK
		Windows PowerShell Tip: Using Calculated Properties
		http://technet.microsoft.com/en-us/library/ff730948.aspx
	#>
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[string]$Database,
		[Parameter(Mandatory=$false,Position=2)]
		[string[]]$DataBaseProperty,
		[Parameter(Mandatory=$true,Position=3)]
		[string[]]$MailboxStatisticsProperty,
		[Parameter(Mandatory=$false,Position=4)]
		[switch]$IncludeDisconnectedMailbox	
	)
	Process
	{
		$reports = @()
		$mailboxDBProperties = @{}
		#Get Mailbox Database
		$mailboxDB = Get-MailboxDatabase -Identity $Database -Status -Verbose:$false
		#If specific database could be found, keep on processing
		if ($mailboxDB -ne $null) {
			#Save the property names to a variable, it will be used to validate the property names which are provided by administrators
			$mailboxDB | Get-Member -MemberType Property | %{$mailboxDBProperties.Add($_.Name,"")}
			#Prepare the report
			$report = New-Object PSObject
			$report | Add-Member -MemberType NoteProperty -Name "ServerName" -Value $($mailboxDB.ServerName)
			$report | Add-Member -MemberType NoteProperty -Name "DatabaseName" -Value $($mailboxDB.Name)
			$report | Add-Member -MemberType NoteProperty -Name "DatabaseSize" -Value $($mailboxDB.DatabaseSize)
			$report | Add-Member -MemberType NoteProperty -Name "AvailableNewMailboxSpace" -Value $($mailboxDB.AvailableNewMailboxSpace)
			#Handle additional properties
			if ($DataBaseProperty -ne $null) {
				foreach ($dbProperty in $DataBaseProperty) {
					if ($mailboxDBProperties.ContainsKey($dbProperty)) {
						$report | Add-Member -MemberType NoteProperty -Name $dbProperty -Value $($mailboxDB.$dbProperty)
					} else {
						$warningMsg = $Messages.PropertyNameIsNotValid
						$warningMsg = $warningMsg -replace "Placeholder01",$dbProperty
						$pscmdlet.WriteWarning($warningMsg)
					}
				}
			}
			#Get mailbox statistics
			$mailboxDBStatProperties = @{}
			if ($IncludeDisconnectedMailbox) {
				$mailboxStat = Get-MailboxStatistics -Database $Database -Verbose:$false
			} else {
				$mailboxStat = Get-MailboxStatistics -Database $Database -Verbose:$false | Where-Object {$_.DisconnectDate -ne $null}
			}
			if ($mailboxStat -is [array]) {
				$mailboxStat | Get-Member -MemberType Property | %{$mailboxDBStatProperties.Add($_.Name,"")}
				$report | Add-Member -MemberType NoteProperty -Name "Mailbox(Count)" -Value $($mailboxStat.Count)
				foreach ($mbxStatProperty in $MailboxStatisticsProperty) {
					#Use regular expression to capture measure method
					$measureMethod = [regex]::Match($mbxStatProperty,"(?<=\()\w+")
					$measuredProperty = [regex]::Replace($mbxStatProperty,"\($measureMethod\)","")
					if (($mailboxDBStatProperties.ContainsKey($measuredProperty)) -and ($measuredProperty -match "Count|Size") -and ($measuredProperty -notmatch "LastLoggedOnUserAccount")) {
						Switch ($measureMethod) {
							"Average" {
								if ($measuredProperty -match "Size") {
									$measuredValue = $mailboxStat | Select *,@{Name="$measuredProperty";Expression={$_.$measuredProperty.Value.ToBytes()}} -ExcludeProperty $measuredProperty | Measure-Object -Property $measuredProperty -Average
								} else {
									$measuredValue = $mailboxStat | Measure-Object -Property $measuredProperty -Average
								}
								$report | Add-Member -MemberType NoteProperty -Name "$measuredProperty(Average)" -Value $measuredValue.Average
							}
							"Sum" {
								if ($measuredProperty -match "Size") {
									$measuredValue = $mailboxStat | Select *,@{Name="$measuredProperty";Expression={$_.$measuredProperty.Value.ToBytes()}} -ExcludeProperty $measuredProperty | Measure-Object -Property $measuredProperty -Sum
								} else {
									$measuredValue = $mailboxStat | Measure-Object -Property $measuredProperty -Sum
								}
								$report | Add-Member -MemberType NoteProperty -Name "$measuredProperty(Sum)" -Value $measuredValue.Sum
							}
							"Maximum" {
								if ($measuredProperty -match "Size") {
									$measuredValue = $mailboxStat | Select *,@{Name="$measuredProperty";Expression={$_.$measuredProperty.Value.ToBytes()}} -ExcludeProperty $measuredProperty | Measure-Object -Property $measuredProperty -Maximum
								} else {
									$measuredValue = $mailboxStat | Measure-Object -Property $measuredProperty -Maximum
								}
								$report | Add-Member -MemberType NoteProperty -Name "$measuredProperty(Maximum)" -Value $measuredValue.Maximum
							}
							"Minimum" {
								if ($measuredProperty -match "Size") {
									$measuredValue = $mailboxStat | Select *,@{Name="$measuredProperty";Expression={$_.$measuredProperty.Value.ToBytes()}} -ExcludeProperty $measuredProperty | Measure-Object -Property $measuredProperty -Minimum
								} else {
									$measuredValue = $mailboxStat | Measure-Object -Property $measuredProperty -Minimum
								}
								$report | Add-Member -MemberType NoteProperty -Name "$measuredProperty(Minimum)" -Value $measuredValue.Minimum
							}
							Default {
								$warningMsg = $Messages.MeasureMethodIsNotValid
								$warningMsg = $warningMsg -replace "Placeholder01",$measureMethod
								$pscmdlet.WriteWarning($warningMsg)									
							}
						}
					} else {
						$warningMsg = $Messages.PropertyNameIsNotValidForMeasuring
						$warningMsg = $warningMsg -replace "Placeholder01",$measuredProperty
						$pscmdlet.WriteWarning($warningMsg)
					}
					$measuredValue = $null
				}
			} else {
				#If the mailbox database does not contain any user mailboxes,SystemMailbox will be excluded from the result.
				$warningMsg = $Messages.CannotFindAnyMailboxStat
				$warningMsg = $warningMsg -replace "Placeholder01",$Database
				$pscmdlet.WriteWarning($warningMsg)
			}
		}
		return $report
	}
}

