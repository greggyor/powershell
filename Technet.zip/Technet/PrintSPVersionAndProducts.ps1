﻿###############################################################################
# Get cleartext release and license of your SharePoint 2010/2013 farm
# Url              : http://gallery.technet.microsoft.com/Get-cleartext-and-license-008ee875
# Creator          : Matthias Einig, www.matthiaseinig.de
###############################################################################

# load the SharePoint PowerShell snapin (only available in SharePoint 2010 or above)
Add-PSSnapin "Microsoft.SharePoint.PowerShell" -EA 0; cls

# get the current folder
$0 = $myInvocation.MyCommand.Definition
$scriptDir = [System.IO.Path]::GetDirectoryName($0)
 
# load the version and licenses lookup data
[xml]$xml = Get-Content $scriptDir"\SharePointVersions.xml"
 
$farm = Get-SPFarm
$InstalledVersion = $farm.BuildVersion
# get the matching version from the lookup data
$SPVersionName = ($xml.SPSD.SharePoint.Versions.Version | Where-Object {$_.Number -eq $InstalledVersion}).Name 
$InstalledVersionName =  $SPVersionName +" ("+ $InstalledVersion +")"
Write-Host -ForegroundColor White "Installed SP version: $InstalledVersionName"
 
$installedProducts =  $farm | select Products
# get the matching licenses from the lookup data
$installedLicences = $xml.SPSD.SharePoint.Licenses.License | Where-Object { $installedProducts.Products -icontains $_.Guid}
$installedLicences | ForEach-Object {Write-Host -ForegroundColor White "Installed SP license:"$_.Name}