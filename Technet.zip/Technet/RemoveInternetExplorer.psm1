﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -version 2.0

Function Remove-OSCInternetExplorer
{
<#
 	.SYNOPSIS
        Remove-OSCInternetExplorer is an advanced function which can be used to remove Internet Explorer in Windows 7.
    .DESCRIPTION
        Remove-OSCInternetExplorer is an advanced function which can be used to remove Internet Explorer in Windows 7.
	.PARAMETER  Enable
		Enable Internet Explorer feature.
    .EXAMPLE
        C:\PS> Remove-OSCInternetExplorer

		Disabling Internet Explorer feature...

		Deployment Image Servicing and Management tool
		Version: 6.1.7600.16385

		Image Version: 6.1.7600.16385

		Disabling feature(s)
		[==========================100.0%==========================]
		The operation completed successfully.
		Restart Windows to complete this operation.
		
		This command shows how to disable Internet Explorer Feature.
    .EXAMPLE
        C:\PS> Remove-OSCInternetExplorer -Enable

		Enabling Internet Explorer feature...

		Deployment Image Servicing and Management tool
		Version: 6.1.7600.16385

		Image Version: 6.1.7600.16385

		Disabling feature(s)
		[==========================100.0%==========================]
		The operation completed successfully.
		Restart Windows to complete this operation.
		
		This command shows how to enable Internet Explorer Feature.
#>

	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
    (
		[Parameter(Mandatory=$false)]
		[Alias("en")][Switch]$Enable
    )
	
	$SearchFeatureInfo = Dism /online /Get-FeatureInfo /FeatureName:Internet-Explorer-Optional-amd64
	$FeatureState = $SearchFeatureInfo | Select-String "State"
	
		If($Enable)
		{
			If($PSCmdlet.ShouldProcess("Enabling Internet Explorer feature"))
			{
				If($FeatureState -match "Disabled")
				{
					Write-Host "Enabling Internet Explorer feature..."
					Dism /online /Enable-Feature /FeatureName:Internet-Explorer-Optional-amd64
				}
				Else
				{
					Write-Warning "Internet Explorer is already enabled." 
				}
			}
		}
		Else
		{	
			If($PSCmdlet.ShouldProcess("Disabling Internet Explorer feature"))
			{
				If($FeatureState -match "Enabled")
				{
					Write-Host "Disabling Internet Explorer feature..."
					Dism /online /Disable-Feature /FeatureName:Internet-Explorer-Optional-amd64
				}
				Else
				{
					Write-Warning "Internet Explorer is already disabled." 
				}
			}
		}
	}