#This script was written a while back using quest's AD commandlets
#those can be downloaded from here: 
#http://www.quest.com/powershell/activeroles-server.aspx
#This script will find any AD account in an OU  with less than 15 days
#on its password and send an email to the user

$tod = get-date
$cutoff = 15 #number of days out to start sending emails
#Remove the -ou parameter from the command below to get all users in AD
Get-QADUser -ou 'OU=<OU>,DC=<company>,DC=<>' -enabled -size 0 | where {($_.PasswordNeverExpires -eq $False)} | Foreach-Object {
	$timeleft = ($_.passwordexpires - $tod).Days 
    $Firstname=$_.givenname
	if ($timeleft -lt $cutoff) {
        if ($timeleft -lt 1) {$timeleft=0}		
		$body = @"
Hello $firstname,
		
Your password is set to expire in $timeleft days.  Please consider changing it before this date.
If you have any questions about how to change your password, please contact the helpdesk at <it@company.com>.

Thank you,
Corporate IT
<cotendo> Corporation
helpdesk@<cotendo>.com
http:\\helpdesk.<cotendo>.com
"@
		$User=$_.SamAccountName	
		$emailFrom = "<helpdesk>@<cotendo>.com"
	   	$emailTo = "$_.PrimarySMTPAddress"
	   	$subject="Your Password will expire in $timeleft days"
	   	$smtpserver="<relay>.<server>.com"
	   	$smtp=new-object Net.Mail.SmtpClient($smtpServer)
	   	$smtp.Send($emailFrom, $emailTo, $subject, $body)
	}
}
