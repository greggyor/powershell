# ##############################################
# Description: Use this to pull Nested members from Distribution groups and exports it to CSV files
# Security: You may need to run [ Set-ExecutionPolicy Unrestricted ] prior to running this script
# Applies To: Exchange 2007,2010
# ##############################################



#check Arguments
$Error.Clear()
$GroupCount = 0
foreach ($arg in $args)
{
  $GroupCount = $args.Count
  Write-Host "Getting nested members for Distributions Group: $($arg)" -f Green
  $Table = @()

Function FCMDLembers ($Group)
{
    $members = Get-DistributionGroupMember $Group

    If ($Error.Count -gt 0)
    {
    $Error.Clear()
    exit
    }
    Else
    {
    ForEach ($obj in $members)
        {        
            IF ($obj.RecipientType -ne 'userMailbox' -and $obj.RecipientType -ne 'MailContact')
                {
                FCMDLembers($obj.Name)
                }
            Else 
                {
                $obj
                }
            }
         }
    }
$Table  = FCMDLembers($arg)
$File = ($arg -as [string]) + $((get-date).tostring("ddMMyyyyHHmmss")) + ".csv"
Write-Host "Exporting group to $($file)" -f yellow
$Table | Export-csv $file

}
IF ($GroupCount -eq 0)
{
 Write-Host ""
 Write-Host "Usage for NestedGroup.ps1 " -f green
 Write-Host ""

 Write-Host "Example 1: .\NestedGroup.ps1 'GroupName'"
 Write-Host "Example 2: .\NestedGroup.ps1 'Group1' 'Group2' 'Group ABC'"
 Write-Host ""
 Write-Host "Note: Each group will be automatically exported to a csv file in the current working directory" -f yellow
 Write-Host "" 
}

