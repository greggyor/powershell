$path = "c:\program files (x86)\Microsoft\Powershell PSI Cmdlets for Project Server 2010\ProjectPSICmdlets.dll"
$assem = [System.Reflection.Assembly]::LoadFile($path)
import-module -assembly $assem


$projectDs = New-Object SvcProject.ProjectDataSet
# URL of PWA 
$url = "http://Amit-Test-VM/pwa";

# List of Mandatory custom fields.Get the MD_PROP_UID of Custom field from database or PWA>server settings> Enterprise Custom fields & Lookup table>
# Click on Custom field & get the system data. In this sample CF1 & CF2 having the lookup value which can be found using the Published database table MSP_LOOKUP_TABLE_VALUES
# Get the LT_STRUCT_UID as code value & Set the Code value as LT_STRUCT_UID & create a row for the project custom fields tavle in project dataset

$CF1ID = "8a4c9ae1-2237-4a7d-98b3-af334314a3b2";
$CF2ID = "6c203bd2-eec2-449d-9117-c4087f0cae56";
$projID = [System.Guid]::NewGuid();

# Create Project Row with Minimum data like New PROJ_UID, Name & type (default value as 0 for project)
$nr = $projectDs.Project.NewProjectRow()
$nr.PROJ_TYPE = 0;    
$nr.PROJ_UID = $projID;
$nr.PROJ_NAME = "Powershell_Project_Test2";
$projectDs.Project.AddProjectRow($nr);
     
# Create CF Row for CF1
$cfRow = $projectDs.ProjectCustomFields.NewProjectCustomFieldsRow();
$cfRow.PROJ_UID = $projID;
$cfRow.CUSTOM_FIELD_UID = [System.Guid]::NewGuid();
$cfRow.MD_PROP_UID = $CF1ID;      
$cfRow.CODE_VALUE = "18894D5D-146B-4B4C-ABF4-09250F2BF233";

# Create CF Row for CF2
$cfRowCOE = $projectDs.ProjectCustomFields.NewProjectCustomFieldsRow();
$cfRowCOE.PROJ_UID = $projID;
$cfRowCOE.CUSTOM_FIELD_UID = [System.Guid]::NewGuid();
$cfRowCOE.MD_PROP_UID = $CF2ID;      
$cfRowCOE.CODE_VALUE = "7321D7DD-51CA-4FBC-9CCD-22D1A967A21E";

$projectDs.ProjectCustomFields.AddProjectCustomFieldsRow($cfRow);
$projectDs.ProjectCustomFields.AddProjectCustomFieldsRow($cfRowCOE);

# Saving         
$jobUid = [System.Guid]::NewGuid();       
psi-QueueCreateProject  $url $jobUid $projectDs $false
