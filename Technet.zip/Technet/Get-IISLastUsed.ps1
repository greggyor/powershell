﻿function Get-IISLastUsed{
[cmdletBinding()]
param(
[parameter(Mandatory=$true,ValueFromPipeline=$true)]
[string[]] $ComputerName)
begin{
$results = @()
}
process{
foreach($server in $computername)
{
    $iis = [adsi]"IIS://$server/w3SVC"
    $sites = $iis.Children | ?{$_.keytype -eq "IIsWebServer"}
    foreach($site in $sites)
    {
        $logdir = $site.LogFileDirectory
        $logdir = $logdir -replace ':\\', '$\'
        $logdir = "\\$server\$logdir\w3svc$($site.name)"
        if(Test-Path $logdir)
        {
            $lwt = gci $logdir | sort lastwritetime -Descending | select -first 1 -ExpandProperty lastwritetime
            $daysago = (New-TimeSpan -Start $lwt -End ([datetime]::Now)).days
            $obj = New-Object psobject -Property @{
                Server=$server
                Site = $($Site.name)
                Comment = $($site.ServerComment)
                LastUsed = $lwt
                DaysAgo = $daysago
                }
            $results += $obj
        }
    }
}
}
end{
$results
}
}