﻿################################################## 
#
# ScopeLevelMacFiltering.ps1 
# Scope-level Link layer filtering using DHCP policies in Windows Server 2012.
# This script enables creation of an allow list or a deny list (from an input file) of MAC addresses for a specified DHCP scope.
# 
################################################## 

param( 
    [parameter(Mandatory=$true)] 
    [ipaddress]
    $ScopeId, 
     
    [parameter(Mandatory=$true)] 
    [string]  
    $InputFileName, 
     
    #Default is true. Creates an allow-list by default
    [parameter(Mandatory=$false)] 
    [bool]  
    $IsAllow = $true 
)


$filename = $InputFileName
$allow = $IsAllow

# Attempt to read the contents of the input file. Spew out any failure here.
try
{
    $filecontent = Get-Content $filename -ErrorAction Stop
}
catch
{
    throw
}

$operator = ""
$condition = ""
$policyname = "MAC-based policy: "
$description = ""
$descr1 = "The MAC addresses in this policy will" 
$descr2 = "be leased IP addresses"
$maclist = @()

# Populate the policy name, description, condition for the policy.
if($allow -eq $true)
{
    $operator = "EQ"
    $condition = "OR"
    $policyname = $policyname + "Allow list"
    $description = $descr1 + " " + $descr2
}
elseif ($allow -eq $false)
{
    $operator = "NE"
    $condition = "AND"
    $policyname = $policyname + "Deny list"
    $description = $descr1 + " not " + $descr2
}

# Attempt to read the entire list of MAC-addresses into an array.
# Finally, The array $maclist would look like the following for an allow list -
# @("EQ", "mac-address1", "EQ", "mac-address2", "EQ", "mac-address3" ..)
foreach ($mac in $filecontent)
{
    $maclist += $operator
    if($mac -ne "")
    {
        $maclist += $mac
     }
}

try
{
    Add-DhcpServerv4Policy -Name $policyname -Description $description -ScopeId $ScopeId -Condition $condition -MacAddress $maclist -ErrorAction Stop
}
catch
{
    # Creation of a policy could fail due to a number of reasons -
    # 1. The target DHCP server is not running.
    # 2. The specified scope id doesn't exist.
    # 3. Another policy with the same name exists on the specified scope.
    # 4. The input file was not formatted correctly with MAC addresses.
    # Spew the output on the screen, and don't continue further.

    throw
}
 
try
{
    # Fetch the start and end address of this scope to set that to the start and end range for this policy.
    # The intent being to create a policy with range as the entire address range of the scope.

    $scope = Get-DhcpServerv4Scope $ScopeId -ErrorAction Stop
    $start = [ipaddress]$scope.StartRange
    $end = [ipaddress]$scope.EndRange

    Add-DhcpServerv4PolicyIPRange -Name $policyname -ScopeId $ScopeId -StartRange $start -EndRange $end -ErrorAction Stop
}
catch
{
    # If the creation of policy succeeded but the addition of range failed, it is most likely due to existence of another 
    # range-based policy in the same scope. Whatever the reason, attempt to rollback by deleting the created policy.

    Remove-DhcpServerv4Policy -Name $policyname -ScopeId $ScopeId
    throw
}

Write-Host "The script executed successfully and the required policy was created on scope" $ScopeId.ToString()
Write-Host ""

Exit
