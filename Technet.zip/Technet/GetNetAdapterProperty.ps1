﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 3

Function Get-OSCNetAdapterProperty
{
    #.EXTERNALHELP Get-OSCNetAdapterProperty-Help.xml

    [cmdletbinding()]
    [OutputType([System.Management.Automation.PSCustomObject])]
    Param
    (
        #Define parameters
        [Parameter(Mandatory=$false,Position=1)]
        [string[]]$Name,
        [Parameter(Mandatory=$false,Position=2)]
        [string[]]$Property,
        [Parameter(Mandatory=$false)]
        [switch]$IncludeHidden,
        [Parameter(Mandatory=$false)]
        [switch]$Physical,
        [Parameter(Mandatory=$false)]
        [switch]$AllProperties
    )
    Process
    {
        $results = @()
        $netAdapterPropertyNames = @{}
        $netAdapterAdvPropertyNames = @{}
        $netAdapterAdvPropertyKVP = @{}
        #Get Network Adapters and Advanced Properties
        if ($Name -ne $null) {
            $netAdapters = Get-NetAdapter -Name $Name -IncludeHidden:$IncludeHidden -Physical:$Physical -ErrorAction:Stop
            $netAdapterAdvProperties = Get-NetAdapterAdvancedProperty -Name $Name -IncludeHidden:$IncludeHidden -AllProperties:$AllProperties
        } else {
            $netAdapters = Get-NetAdapter -IncludeHidden:$IncludeHidden -Physical:$Physical -ErrorAction:Stop
            $netAdapterAdvProperties = Get-NetAdapterAdvancedProperty -IncludeHidden:$IncludeHidden -AllProperties:$AllProperties
        }
        if ($netAdapters -ne $null) {
            #Populate nested hash table: $netAdapterAdvPropertyKVP
            foreach ($netAdapterAdvProperty in $netAdapterAdvProperties) {
                $netAdapterName = $netAdapterAdvProperty.Name
                $netAdapterAdvPropertyDisplayName = $netAdapterAdvProperty.DisplayName
                $netAdapterAdvPropertyDisplayValue = $netAdapterAdvProperty.DisplayValue
                if (-not $AllProperties) {
                    if (-not $netAdapterAdvPropertyKVP.ContainsKey($netAdapterName)) {
                        $netAdapterAdvPropertyKVP.Add($netAdapterAdvProperty.Name,@{$netAdapterAdvPropertyDisplayName=$netAdapterAdvPropertyDisplayValue})
                    } else {
                        $netAdapterAdvPropertyKVP[$netAdapterName].Add($netAdapterAdvPropertyDisplayName,$netAdapterAdvPropertyDisplayValue)
                    }
                } else {
                    $netAdapterAdvPropertyRegistryKeyword = $netAdapterAdvProperty.RegistryKeyword
                    $netAdapterAdvPropertyRegistryValue = $netAdapterAdvProperty.RegistryValue
                    if (-not $netAdapterAdvPropertyKVP.ContainsKey($netAdapterName)) {
                        if ($netAdapterAdvPropertyDisplayName -ne $null) {
                            $netAdapterAdvPropertyKVP.Add($netAdapterAdvProperty.Name,@{$netAdapterAdvPropertyDisplayName=$netAdapterAdvPropertyDisplayValue})
                        } else {
                            $netAdapterAdvPropertyKVP.Add($netAdapterAdvProperty.Name,@{$netAdapterAdvPropertyRegistryKeyword=$netAdapterAdvPropertyRegistryValue})
                        }
                    } else {
                        if ($netAdapterAdvPropertyDisplayName -ne $null) {
                            $netAdapterAdvPropertyKVP[$netAdapterName].Add($netAdapterAdvPropertyDisplayName,$netAdapterAdvPropertyDisplayValue)
                            if (-not $netAdapterAdvPropertyKVP[$netAdapterName].ContainsKey($netAdapterAdvPropertyDisplayName)) {
                                $netAdapterAdvPropertyKVP[$netAdapterName].Add($netAdapterAdvPropertyRegistryKeyword,$netAdapterAdvPropertyRegistryValue)
                            }
                        } else {
                            $netAdapterAdvPropertyKVP[$netAdapterName].Add($netAdapterAdvPropertyRegistryKeyword,$netAdapterAdvPropertyRegistryValue)
                        }
                    }
                }
            }
            #Preapare hash tables for property name verification
            $netAdapters | Get-Member -MemberType Property | %{$netAdapterPropertyNames.Add($_.Name,"")}
            $netAdapters | Get-Member -MemberType ScriptProperty | %{$netAdapterPropertyNames.Add($_.Name,"")}
            $netAdapters | Get-Member -MemberType AliasProperty | %{$netAdapterPropertyNames.Add($_.Name,"")}
            #If AllProperties parameter is specified, RegistryKeyword can be used as the property name.
            #This is because some advanced properties do not have display name.
            if (-not $AllProperties) {
                $netAdapterAdvProperties.DisplayName | Select-Object -Unique | %{$netAdapterAdvPropertyNames.Add($_,"")}
            } else {
                $netAdapterAdvProperties.DisplayName | Select-Object -Unique | %{$netAdapterAdvPropertyNames.Add($_,"")}
                $netAdapterAdvProperties.RegistryKeyword | Select-Object -Unique | %{
                    if (-not $netAdapterAdvPropertyNames.ContainsKey($_)) {
                        $netAdapterAdvPropertyNames.Add($_,"")
                    }
                }
            }
            #Parameter value verification for $Property
            if (-not [system.string]::IsNullOrEmpty($Property)) {
                foreach ($userSpecifiedProperty in $Property) {
                    if (-not $netAdapterPropertyNames.ContainsKey($userSpecifiedProperty)) {
                        if (-not $netAdapterAdvPropertyNames.ContainsKey($userSpecifiedProperty)) {
                            $warningMsg = "$userSpecifiedProperty is not a valid property name."
                            $pscmdlet.WriteWarning($warningMsg)
                        }
                    }
                }
            }
            #Get properties and generate the result
            foreach ($netAdapter in $netAdapters) {
                $netAdapterName = $netAdapter.Name
                $result = New-Object System.Management.Automation.PSObject
                #Get all properties unless specific properties are specified
                if (-not [system.string]::IsNullOrEmpty($Property)) {
                    foreach ($userSpecifiedProperty in $Property) {
                        $propertyValue = $netAdapterAdvPropertyKVP[$netAdapterName].$userSpecifiedProperty
                        if ($netAdapterPropertyNames.ContainsKey($userSpecifiedProperty)) {
                            $result | Add-Member -NotePropertyName $userSpecifiedProperty -NotePropertyValue $($netAdapter.$userSpecifiedProperty) -Force
                        } elseif ($netAdapterAdvPropertyNames.ContainsKey($userSpecifiedProperty)) {
                            $result | Add-Member -NotePropertyName "$userSpecifiedProperty" -NotePropertyValue $propertyValue -Force
                        }
                    }
                } else {
                    foreach ($netAdapterProperty in $netAdapterPropertyNames.Keys.GetEnumerator()) {
                        $result | Add-Member -NotePropertyName $netAdapterProperty -NotePropertyValue $($netAdapter.$netAdapterProperty) -Force
                    }
                    foreach ($netAdapterAdvPropertyName in $netAdapterAdvPropertyNames.Keys.GetEnumerator()) {
                        $propertyValue = $netAdapterAdvPropertyKVP[$netAdapterName].$netAdapterAdvPropertyName
                        $result | Add-Member -NotePropertyName $netAdapterAdvPropertyName -NotePropertyValue $propertyValue -Force
                    }
                }
                $results += $result
            }
        }
        return $results
    }
}

