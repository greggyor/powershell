#####################################################################################################
##
## Update_Extracted_RDLs reads a tokens.txt file to search .rss files to allow yout to easily
## modify the scripts to reduce the time it takes to make changes to migrate between environments.
##
## Author : Warwick Rudd Jnr IT Options
## Revision : 1.0 Initial Creation
##
#####################################################################################################

# Determine the current location that the script will run from
$Invocation = (Get-Variable MyInvocation -scope 0).Value
$ParentDir = Split-Path $Invocation.MyCommand.Path

# Set the TokenFile so we know what to read to check what to change
$TokenFile = "Tokens.txt"
$TokenFile = Join-Path $ParentDir $TokenFile

# Read the Tokens file to determine what we want changed
# Initialise the $ReplaceTokens
$ReplaceTokens = @()

ForEach ($Token in Get-Content $TokenFile)
{
    If (($Token -notlike "Rem --*") -and ($Token -notlike ""))## Comment Rows or blank rows
    {
        $ReplaceTokens = $ReplaceTokens + $Token
    }
}


# Work through the Directories under the current folder
Foreach ($file in Get-ChildItem $ParentDir -Recurse -Include *.rss)
{
    # Work through each of the tokens we are looking to replace 
    ForEach ($ReplaceToken In $ReplaceTokens)
    {
        $Find,$Replace = [regex]::split($ReplaceToken,"::=") ## Split the Token value into the Find and Replace variables
        # if we are replacing the Datasource we need to get the exact match of what is currently set
        # so that we can find and replace the entire data source string
        If ($Find -like "*Data Sources*")
        {
            $TempFind = "*" + $Find + "*"
            ForEach ($Results in Get-Content $File)
            {
                #Find the matching data source search string to set the new appropriate $Find parameter
                If (($Results -like $TempFind) -and ($Results -notlike ""))
                {
                    $Find = $Results.trim()
                }
            }
        }
        # Replace all the tokens
        (Get-Content $File) | Foreach-Object {$_ -cReplace $Find,$Replace} |  Set-Content $File
    }
}

