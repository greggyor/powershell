﻿# Script:	DeleteFoldersBottomUp.ps1
# Purpose:	This scripts deletes every folder and subfolders for a specific top-folder starting from the last one
# Author:	Nuno Mota
# Date:		Feb 2012

[String] $mbxName = "user@domain.com"
[String] $topFolderName = "Name of Top Folder"
[Int] $intCount = 0

[String] $dllPath = "E:\Program Files\Microsoft\Exchange\Web Services\1.1\Microsoft.Exchange.WebServices.dll"
[Void] [Reflection.Assembly]::LoadFile($dllPath)

$Service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP1)
$Service.AutodiscoverUrl($mbxName, {$True})

# This is the root folder from where we want to start searching for the folder we want to delete.
# Once we find it, then we will go recursively down that folder.
# Other option would be to get the FolderID and start the search straight from there
$RootFolderID = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox, $mbxName)
#$RootFolderID = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Root, $mbxName)
$RootFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($Service, $RootFolderID)

$FolderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView(1000)
$FolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep
$Response = $RootFolder.FindFolders($FolderView)

# Go through all folders under the Inbox folder looking for the folder we want to delete
ForEach ($folder in $Response.Folders)
{
	# Check if the current folder is the folder we want to delete
	If ($folder.DisplayName -eq $topFolderName)
	{
		# Found the folder, so start a new Deep search across all its sub-folders
		$FolderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView(3000)
		$FolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep
		$Response = $folder.FindFolders($FolderView)
		$RootFolder = $folder
		
		# Loop to go through all sub-folders while there are any
		While ($($Response.Folders).Count -gt 0)
		{
			# Get the last folder so we can then delete it (not very efficient...)
			ForEach ($folder in $Response.Folders)
			{
				#$folder.DisplayName
				$lastFolder = $folder
			}

			Write-Host "Deleting", $lastFolder.DisplayName
			$lastFolder.Delete([Microsoft.Exchange.WebServices.Data.DeleteMode]::HardDelete)
			$intCount++
			Write-Progress -Activity "Deleting Folders" -Status "Folders Deleted: $intCount"

			$Response = $RootFolder.FindFolders($FolderView)
		}

		# Delete the top folder and exit the first ForEach
		#Write-Host "Deleting Top ""$($RootFolder.DisplayName)"""
		$RootFolder.Delete([Microsoft.Exchange.WebServices.Data.DeleteMode]::HardDelete)
		Break
	}
}