###############################################################
# Populate_Test_Domains_v1.0.ps1
# Version 1.0
# MALEK Ahmed - 07 / 01 / 2013
###################

##################
#--------Config
##################
$source = "DC=contoso,DC=prod"
$destination = "DC=contoso,DC=test"
$adPath="LDAP://DCprod.contoso.prod/"+$source 
$adPathnewdomain="LDAP://DCtest.contoso.test/" + $destination
$maximumADObjects = 60000
        
        
##################
#--------Main  
##################
import-module activedirectory
#Create OUs
$objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPathnewdomain)
$ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
$ObjSearch.PageSize = $maximumADObjects
[array] $OUs = @()
$OUs = dsquery ou $source -limit 0
$OUsorted = $OUs | sort-object { $_.Length}
for ($k=0; $k -le $OUsorted.Count -1; $k++)
{
    $OUtoCreate = ($OUsorted[$k] -replace $source,$destination).ToString()
    $OUSearch = ($OUtoCreate -replace '"',"").ToString()
    $ObjSearch.Filter = "(&(objectCategory=organizationalUnit)(distinguishedName="+ $OUSearch + "))"
    $allSearchResult = $ObjSearch.FindAll()
    if ($allSearchResult.Count -eq 1)
    {
        "[OU]-No changes were done on = " + $OUtoCreate
    }
    else
    {
        dsadd ou $OUtoCreate
        "[OU]-OU Creation = " + $OUtoCreate
    }
}



#Create Groups
$Groups = dsquery group $source -limit 0
    $objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
    $ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
    $ObjSearch.PageSize = $maximumADObjects

for ($k=0; $k -le $Groups.Count -1; $k++)
{
    $ObjSearch.Filter = "(&(objectCategory=Group)(distinguishedName="+ ($Groups[$k] -replace '"',"").ToString() + "))"
    $allSearchResult = $ObjSearch.FindAll()
    foreach ($objSearchResult in $allSearchResult)
    {
        $objGroup=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $objNewDomain=New-Object System.DirectoryServices.DirectoryEntry($adPathnewdomain)
        $ObjNewSearch=New-Object System.DirectoryServices.DirectorySearcher($objNewDomain)
        $ObjNewSearch.PageSize = $maximumADObjects 
        $ObjNewSearch.Filter = "(&(objectCategory=Group)(name="+ $objGroup.name + "))"
        $allNewSearchResult = $ObjNewSearch.FindAll()
        if ($allNewSearchResult.Count -eq 0)
        {
            #Creating a new group if the group does not existing
            $GrouptoCreate = ($Groups[$k] -replace $source,$destination).ToString()
            dsadd group $GrouptoCreate
            "[Group]-Group Creation = " + $GrouptoCreate
        }
        else
        {
           foreach ($objNewSearchResult in $allNewSearchResult)
           {
                #Moving back the groups that were moved
                $objNewGroup=New-Object System.DirectoryServices.DirectoryEntry($objNewSearchResult.Path)
                if ('"'+$objNewGroup.distinguishedname+'"' -ne ($Groups[$k] -replace $source,$destination).ToString())
                {
		            $Groupcn = "CN="+$objNewGroup.cn.ToString() + ","
                    $newOUDest = (($Groups[$k] -replace $Groupcn,"") -replace $source,$destination).ToString()
                    $newOUDest = ($newOUDest -replace '"',"")
	                Move-ADObject -Identity $objNewGroup.distinguishedname.ToString() -TargetPath $newOUDest
		            "[Group]-Group account was moved = " + ($Groups[$k] -replace $source,$destination)
                }
                else
                {
                    "[Group]-No changes were done on = " + ($Groups[$k] -replace $source,$destination).ToString()
                }
           }
        } 
        "-----------------------------------------------------------------------------------"           
    }
    
}

#Create Users
$Users = dsquery user $source -limit 0

    $objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
    $ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
    $ObjSearch.PageSize = $maximumADObjects

for ($k=0; $k -le $Users.Count -1; $k++)
{
    $ObjSearch.Filter = "(&(objectCategory=person)(distinguishedName="+ ($Users[$k] -replace '"',"").ToString() + "))"
    $allSearchResult = $ObjSearch.FindAll()
    foreach ($objSearchResult in $allSearchResult)
    {
        $objUser=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $objNewDomain=New-Object System.DirectoryServices.DirectoryEntry($adPathnewdomain)
        $ObjNewSearch=New-Object System.DirectoryServices.DirectorySearcher($objNewDomain)
        $ObjNewSearch.PageSize = $maximumADObjects 
        $ObjNewSearch.Filter = "(&(objectCategory=person)(name="+ $objUser.name + "))"
        $allNewSearchResult = $ObjNewSearch.FindAll()
        if ($allNewSearchResult.Count -eq 0)
        {
            #Creating a new use if the user does not existing
            $UsertoCreate = ($Users[$k] -replace $source,$destination).ToString()
            dsadd user $UsertoCreate -disabled no -pwd temppwd
        }
        else
        {
           foreach ($objNewSearchResult in $allNewSearchResult)
           {
                #Moving back the users that were moved
                $objNewUser=New-Object System.DirectoryServices.DirectoryEntry($objNewSearchResult.Path)
                if ('"'+$objNewUser.distinguishedname+'"' -ne ($Users[$k] -replace $source,$destination).ToString())
                {
		           $Usercn = "CN="+$objNewUser.cn.ToString() + ","
                   $newOUDest = (($Users[$k] -replace $Usercn,"") -replace $source,$destination).ToString()
                   $newOUDest = ($newOUDest -replace '"',"")
	               Move-ADObject -Identity $objNewUser.distinguishedname.ToString() -TargetPath $newOUDest
		           "[User]-User account was moved = " + ($Users[$k] -replace $source,$destination)
                }
                else
                {
                   "[User]-No changes were done on = " + ($Users[$k] -replace $source,$destination).ToString()
                }
           }
        } 
        "-----------------------------------------------------------------------------------"           
    }
    
}

#Populate User attributes
$Users = dsquery user $source -limit 0

    $objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
    $ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
    $ObjSearch.PageSize = $maximumADObjects

for ($k=0; $k -le $Users.Count -1; $k++)
{
    $ObjSearch.Filter = "(&(objectCategory=person)(distinguishedName="+ ($Users[$k] -replace '"',"").ToString() + "))"
    $allSearchResult = $ObjSearch.FindAll()
    foreach ($objSearchResultCheck in $allSearchResult)
    {
    foreach ($objSearchResult in $allSearchResult)
    {
        $objUser=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $objNewDomain=New-Object System.DirectoryServices.DirectoryEntry($adPathnewdomain)
        $ObjNewSearch=New-Object System.DirectoryServices.DirectorySearcher($objNewDomain)
        $ObjNewSearch.PageSize = $maximumADObjects 
        $ObjNewSearch.Filter = "(&(objectCategory=person)(name="+ $objUser.name + "))"
        $allNewSearchResult = $ObjNewSearch.FindAll()
        foreach ($objSearchResult in $allNewSearchResult)
            {
                $objUser=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
                $objUserCheck=New-Object System.DirectoryServices.DirectoryEntry($objSearchResultCheck.Path)
	            $objUser.Description = $objUserCheck.Description  
                $objUser.givenName = $objUserCheck.givenName
                $objUser.mail = $objUserCheck.mail
                $objUser.sAMAccountName = $objUserCheck.sAMAccountName
                $objUser.userPrincipalName = ($objUserCheck.userPrincipalName.ToString() -replace ".org",".test").ToString()
                $objUser.sn = $objUserCheck.sn
                $objUser.displayname = $objUserCheck.displayname 
                $user1DN = "LDAP://"+($Users[$k] -replace '"',"").ToString()
                $user1 = [ADSI]$user1DN
                $user2DN = "LDAP://"+(($Users[$k] -replace '"',"").ToString() -replace "DC=ORG","DC=TEST").ToString()
                $user2 = [ADSI]$user2DN

                foreach ($group in $user1.memberof)
                {
	               $groupDN = "LDAP://" + ($group -replace "DC=ORG","DC=TEST").ToString()
	               $group = [ADSI]$groupDN
     	           $DN = "LDAP://"+$user2.distinguishedName
	               $group.Add($DN)
                }
                $objUser.CommitChanges()
                "[User]-Attribues updated for " + $objUser.distinguishedname
            }
            
    }
    }
 }
 
#Populate Group attributes
$Groups = dsquery group $source -limit 0

    $objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
    $ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
    $ObjSearch.PageSize = $maximumADObjects

for ($k=0; $k -le $Groups.Count -1; $k++)
{
    $ObjSearch.Filter = "(&(objectCategory=group)(distinguishedName="+ ($Groups[$k] -replace '"',"").ToString() + "))"
    $allSearchResult = $ObjSearch.FindAll()
    foreach ($objSearchResultCheck in $allSearchResult)
    {
    foreach ($objSearchResult in $allSearchResult)
    {
        $objGroup=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
        $objNewDomain=New-Object System.DirectoryServices.DirectoryEntry($adPathnewdomain)
        $ObjNewSearch=New-Object System.DirectoryServices.DirectorySearcher($objNewDomain)
        $ObjNewSearch.PageSize = $maximumADObjects 
        $ObjNewSearch.Filter = "(&(objectCategory=group)(name="+ $objGroup.name + "))"
        $allNewSearchResult = $ObjNewSearch.FindAll()
        foreach ($objSearchResult in $allNewSearchResult)
            {
                $objGroup=New-Object System.DirectoryServices.DirectoryEntry($objSearchResult.Path)
                $objGroupCheck=New-Object System.DirectoryServices.DirectoryEntry($objSearchResultCheck.Path)
	            $objGroup.Description = $objGroupCheck.Description  
                $objGroup.mail = $objGroupCheck.mail
                $Group1DN = "LDAP://"+($Groups[$k] -replace '"',"").ToString()
                $Group1 = [ADSI]$Group1DN
                $Group2DN = "LDAP://"+(($Groups[$k] -replace '"',"").ToString() -replace "DC=ORG","DC=TEST").ToString()
                $Group2 = [ADSI]$Group2DN

                foreach ($group in $Group1.memberof)
                {
	               $groupDN = "LDAP://" + ($group -replace "DC=ORG","DC=TEST").ToString()
	               $group = [ADSI]$groupDN
     	           $DN = "LDAP://"+$Group2.distinguishedName
	               $group.Add($DN)
                }
                $objGroup.CommitChanges()
                "[Group]-Attribues updated for " + $objGroup.distinguishedname
            }
            
    }
    }
 }