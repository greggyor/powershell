#E-mail Configuration
$SMTPServer = "smtp.company.com"
$FromAddress = "messaging@company.com"
$Recipients = "ExchangeAdmins@company.com"
$MessageSubject = "Exchange 2007 Transaction Logs Check."
$MessageBody = ""

#Add Snapin for Exchange Cmdlets
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin

$Hours = 24

#HTML variables referenced during the script for output formatting
$sHTMLCellStyle = "`r`n<td style=`"font-family: Verdana, sans-serif; font-size: 10px; color: navy`">"
$sHTMLHeadingStyle = "`r`n<th style=`"font-family: Verdana, sans-serif; font-size: 11px; color: navy`">"
$sHtmlTableStyle = "`r`n<table border=`"1`", cellpadding=`"10`", cellspacing=`"0`", TABLE BORDER WIDTH=`"75%`">"
$sHTMLParagraphStyle = "`r`n<p style=`"font-family: Verdana, sans-serif; font-size: 12px; color: navy`">"

$sHtmlTableHeading = "$sHtmlTableStyle <tr>$sHTMLHeadingStyle Storage Group</th>" + `
"$sHTMLHeadingStyle SG Log Path</th>$sHTMLHeadingStyle Lingering Log Files</th>$sHTMLHeadingStyle Database</th>" + `
"$sHTMLHeadingStyle Last Full Database Backup</th></tr>"

$hostname = $env:computername.ToLower()

Get-StorageGroup -Server $hostname | Sort Name |
%{
    Write-Host $_.Identity
	$DBCount = 0
	$MbxDBs = Get-MailboxDatabase -StorageGroup $_.Identity -status
	$PfDBs = Get-PublicFolderDatabase -StorageGroup $_.Identity -status
	If ($MbxDBs -ne $null) {If ($MbxDBs.GetType().Name -ne "MailboxDatabase"){$DBCount = ($MbxDBs).Count} Else {$DBCount = 1}}
	If ($PfDBs -ne $null) {$DBCount += 1}

	$temp = $sHTMLCellStyle -Replace(">", "rowspan=$DBCount>")
	$MessageBody += "<tr>$temp" + $_.Name + "</td>$temp" + $_.LogFolderPath + "</td>$temp"
	$temp = ""
	$TransactionLogs = Get-ChildItem -Path $_.LogFolderPath -Filter "*.log" | ?{ ((Get-Date).AddHours(-$Hours) - $_.LastWriteTime) -gt 1 } 
	If ($TransactionLogs -ne $null){
        $TransactionLogs.GetType()
        Write-Host "Log File count: " + $TransactionLogs.length-1
		If ($TransactionLogs.GetType().Name -ne "FileInfo" -AND $TransactionLogs.length-1 -gt 11){
			$TransactionLogs[0..4] | %{$MessageBody += $_.Name + " last written to on " + ($_.LastWriteTime).ToString().Substring(0,10) + " at " + ($_.LastWriteTime).ToString().Substring(11,8) + "<br>"}
			$MessageBody += "...<br>"
			$TransactionLogs[-1..-5] | %{$MessageBody += $_.Name + " last written to on " + ($_.LastWriteTime).ToString().Substring(0,10) + " at " + ($_.LastWriteTime).ToString().Substring(11,8) + "<br>"}}
		Else {$TransactionLogs | %{$MessageBody += $_.Name + " last written to on " + ($_.LastWriteTime).ToString().Substring(0,10) + " at " + ($_.LastWriteTime).ToString().Substring(11,8) + "<br>"}}}
	Else {
		$MessageBody += "No logs older than $Hours hours found.<br>"
		$TransactionLogs = Get-ChildItem -Path $_.LogFolderPath -Filter "*.log" | sort lastwritetime | select -first 1
		If ($TransactionLogs -ne $null) {$TransactionLogs | %{$MessageBody += "Oldest log file: " + $_.Name + " last written to on " + ($_.LastWriteTime).ToString().Substring(0,10) + " at " + ($_.LastWriteTime).ToString().Substring(11,8) + "<br>"}}}
	$MessageBody += "</td>"
	If ($MbxDBs -ne $null){
		If ($MbxDBs.GetType().Name -ne "MailboxDatabase")
		{For ($i=0; $i -le $MbxDBs.Length-1; $i++)
			{If ($i -eq 0)
			{$MessageBody += "$sHTMLCellStyle" + $MbxDBs[$i].Name + "</td>$sHTMLCellStyle" + $MbxDBs[$i].LastFullBackup + "</td></tr>"}
			Else
			{$MessageBody += "<tr>$sHTMLCellStyle" + $MbxDBs[$i].Name + "</td>$sHTMLCellStyle" + $MbxDBs[$i].LastFullBackup + "</td></tr>"}
		}
	}
	Else {$MbxDBs | %{$MessageBody += "$sHTMLCellStyle" + $_.Name + "</td>$sHTMLCellStyle" + $_.LastFullBackup + "</td></tr>"}}}
	If ($PfDBs -ne $null)
	{If ($DBCount -gt 1)
		{$PfDBs | %{$MessageBody += "<tr>$sHTMLCellStyle" + $_.Name + "</td>$sHTMLCellStyle" + $_.LastFullBackup + "</td></tr>"}}
		Else
		{$PfDBs | %{$MessageBody += "$sHTMLCellStyle" + $_.Name + "</td>$sHTMLCellStyle" + $_.LastFullBackup + "</td></tr>"}}
	}
}
$MessageBody = $sHtmlTableHeading + $MessageBody + "</table>"
$MessageBody | out-file "c:\Exchange 2007 Transaction Logs Check.htm"

#Send the e-mail
$SMTPMessage = New-Object System.Net.Mail.MailMessage $FromAddress, $Recipients, $MessageSubject, $MessageBody
$SMTPMessage.IsBodyHTML = $true
$SMTPClient = New-Object System.Net.Mail.SMTPClient $SMTPServer
$SMTPClient.Send($SMTPMessage)
$SMTPMessage.Dispose()
$MessageBody = ""
