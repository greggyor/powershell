#===================================================================
# Web Config Modifications Script
#===================================================================

Add-PSSnapin Microsoft.SharePoint.Powershell -ErrorAction "SilentlyContinue"

#connect to the function library for this script
$functionLocation = "C:\PowerShell\WebConfigModifications"
. $functionLocation\Web_Config_Modifications_Functions.ps1

#define the SPWebConfigModification constants
$modificationOwner = "SomeUniqueIdentifier"
$EnsureChildNode = 0
$EnsureAttribute = 1

#get the web configuration modifications xml file
$webconfigLocation = "C:\PowerShell\WebConfigModifications"
$webconfigData = $webconfigLocation + "\Web_Config_Modifications.xml"

# get the Web Application for the given Url
$url = "http://YOUR-WEB-APP-URL"
$webapp = Get-SPWebApplication $url
$webapp
#===============================================================================================================

#Write-Host "`nCleaning up existing Nodes"

#use this statement below to correct for any errors 
#when initially adding new sections / nodes / attributes 
#etc that may cause exceptions
#$webapp.WebConfigModifications.Clear()

DeleteSections $webapp $modificationOwner $false

#===============================================================================================================
Write-Host "`nAdding Web Config Nodes"

#load the xml data
[xml]$Data = get-content $webconfigData

foreach ($Section in $Data.Sections.Section)
{ 
    #Ignore sections marked to be skipped
    if ($Section.Skip -eq "false")
	{
	    $path = $Section.Path
		foreach ($modification in $Section.modifications.ChildNodes)
		{
			if ($modification.type -eq "EnsureAttribute")
			{
				$type = $EnsureAttribute
				$name = $modification.name
		  		$value =  $modification.value 
				
				Write-Host "`nChanging $path -> $name to $value"
			}			
		    else
			{
				$type = $EnsureChildNode
				$name = $modification.name
				$value = "<" + $modification.value + "/>"
				
				Write-Host "`nAdding Modifications -> $path : $name, $value"
			}		
			
			CreateConfigChildNode $modificationOwner $type $path $name $value
		}
	}
}

#===============================================================================================================
Write-Host "`nApplying Modifications to the Web.Config"		
$webapp.Update()
$webapp.Parent.ApplyWebConfigModifications()
Write-Host "`nCompleted Web.Config Modifications"

#----- END OF FILE  -----#

#----- START of FUNCTION FILE ----#

#===================================================================
# Web Config Modifications Script Functions
#===================================================================

#===================================================================
# function to Create Web Config nodes and or change attributes
#===================================================================
function CreateConfigChildNode($Owner, $Type, $Path, $Name, $Value)
{
    $childNode = New-Object Microsoft.SharePoint.Administration.SPWebConfigModification 
	$childNode.Owner = $Owner
	$childNode.Path = $Path
	$childNode.Name = $Name
	$childNode.Value = $Value
	$childNode.Type = $Type

	$webapp.WebConfigModifications.Add($childNode)
}

#===================================================================
# function to remove all existing node and changes to attributes matching the Owner name
#===================================================================
function DeleteSections($webapp, $Owner, $removeOnly)
{
    $count =  $webapp.WebConfigModifications.Count
	$foundNodes = $false
	for ($i=$count ;$i -gt -1; $i--)
	{
	    if ($webapp.WebConfigModifications[$i].Owner -eq $Owner)
		{
			$foundNodes = $true
			Write-Host "`n$i"
			$webapp.WebConfigModifications.Remove($webapp.WebConfigModifications[$i])
		}
	}

	if ($foundNodes -and $removeOnly)
	{
		$webapp.Parent.ApplyWebConfigModifications()
		$webapp.Update()
	}
}

#----- END OF FILE  -----#
