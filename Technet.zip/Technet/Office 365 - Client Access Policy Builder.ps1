﻿#------------------------------------------------------------------------------
#
# Copyright © 2012 Microsoft Corporation.  All rights reserved.
#
# THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED “AS IS” WITHOUT
# WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
# FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR 
# RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
#
#------------------------------------------------------------------------------
#
# PowerShell Source Code
#
# NAME:
#    Office 365 - Client Access Policy Builder.ps1
#
# VERSION:
#    1.0
#
#------------------------------------------------------------------------------

#----------------------------------------------
#region Import Assemblies
#----------------------------------------------
[void][Reflection.Assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
[void][Reflection.Assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
[void][Reflection.Assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
[void][Reflection.Assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
[void][Reflection.Assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
[void][Reflection.Assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
[void][Reflection.Assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
#endregion Import Assemblies

#Define a Param block to use custom parameters in the project
#Param ($CustomParameter)

function Main {
	Param ([String]$Commandline)
	#Note: This function starts the application
	#Note: $Commandline contains the complete argument string passed to the packager
	#Note: $Args contains the parsed arguments passed to the packager (Type: System.Array) 
	#Note: To get the script directory in the Packager use: Split-Path $hostinvocation.MyCommand.path
	#Note: To get the console output in the Packager (Windows Mode) use: $ConsoleOutput (Type: System.Collections.ArrayList)
	#TODO: Initialize and add Function calls to forms
	
	if((Call-MainForm_pff) -eq "OK")
	{
		
	}
	
	$global:ExitCode = 0 #Set the exit code for the Packager
}








#region Call-MainForm_pff
function Call-MainForm_pff
{
	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$MainForm = New-Object System.Windows.Forms.Form
	$buttonBuild = New-Object System.Windows.Forms.Button
	$buttonHelp = New-Object System.Windows.Forms.Button
	$labelNotify = New-Object System.Windows.Forms.Label
	$groupboxStep2 = New-Object System.Windows.Forms.GroupBox
	$labelGroups = New-Object System.Windows.Forms.Label
	$textboxGroups = New-Object System.Windows.Forms.TextBox
	$groupboxIPSelection = New-Object System.Windows.Forms.GroupBox
	$labelIPExplanation = New-Object System.Windows.Forms.Label
	$labelRangeEndNotify = New-Object System.Windows.Forms.Label
	$labelRangeBeginNotify = New-Object System.Windows.Forms.Label
	$labelIPNotify = New-Object System.Windows.Forms.Label
	$labelRangeHyphen = New-Object System.Windows.Forms.Label
	$label9 = New-Object System.Windows.Forms.Label
	$label8 = New-Object System.Windows.Forms.Label
	$label7 = New-Object System.Windows.Forms.Label
	$label6 = New-Object System.Windows.Forms.Label
	$label5 = New-Object System.Windows.Forms.Label
	$label4 = New-Object System.Windows.Forms.Label
	$label3 = New-Object System.Windows.Forms.Label
	$label2 = New-Object System.Windows.Forms.Label
	$label1 = New-Object System.Windows.Forms.Label
	$RangeOct8 = New-Object System.Windows.Forms.TextBox
	$RangeOct7 = New-Object System.Windows.Forms.TextBox
	$RangeOct6 = New-Object System.Windows.Forms.TextBox
	$RangeOct5 = New-Object System.Windows.Forms.TextBox
	$RangeOct4 = New-Object System.Windows.Forms.TextBox
	$RangeOct3 = New-Object System.Windows.Forms.TextBox
	$RangeOct2 = New-Object System.Windows.Forms.TextBox
	$RangeOct1 = New-Object System.Windows.Forms.TextBox
	$IPOct4 = New-Object System.Windows.Forms.TextBox
	$IPOct3 = New-Object System.Windows.Forms.TextBox
	$IPOct2 = New-Object System.Windows.Forms.TextBox
	$IPOct1 = New-Object System.Windows.Forms.TextBox
	$radiobuttonIPRange = New-Object System.Windows.Forms.RadioButton
	$radiobuttonSingleIP = New-Object System.Windows.Forms.RadioButton
	$radiobuttonBlockOnlyOutlook = New-Object System.Windows.Forms.RadioButton
	$labelChooseOneOfTheExampl = New-Object System.Windows.Forms.Label
	$radiobuttonBlockExceptEAS = New-Object System.Windows.Forms.RadioButton
	$radiobuttonBlockExceptBrowser = New-Object System.Windows.Forms.RadioButton
	$radiobuttonBlockAll = New-Object System.Windows.Forms.RadioButton
	$radiobuttonBlockGroups = New-Object System.Windows.Forms.RadioButton
	$groupboxStep1 = New-Object System.Windows.Forms.GroupBox
	$labelClaimTypesNotify = New-Object System.Windows.Forms.Label
	$labelAfterTheUpdateRollup = New-Object System.Windows.Forms.Label
	$buttonCreateClaimTypeRules = New-Object System.Windows.Forms.Button
	$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	$OnLoadFormEvent={
		#Set vars
		$Global:ErrorActionPreference = "SilentlyContinue"
		$Global:IPisValid = $false
		$Global:RangeBeginIsValid = $false
		$Global:RangeEndIsValid = $false
		$Global:IP = "1000.1000.1000.1000"
		$Global:RangeBeginIP = "1000.1000.1000.1000"
		$Global:RangeEndIP = "1000.1000.1000.1000"
		$StopHere = $false
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block all external access to Office 365"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"customer-provided public ip address regex"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@
		
		#Initialize UI
		$radiobuttonBlockAll.Checked = $true
		$radiobuttonSingleIP.Checked = $true
		$RangeOct1.Enabled = $false
		$RangeOct2.Enabled = $false
		$RangeOct3.Enabled = $false
		$RangeOct4.Enabled = $false
		$RangeOct5.Enabled = $false
		$RangeOct6.Enabled = $false
		$RangeOct7.Enabled = $false
		$RangeOct8.Enabled = $false
		$IPOct1.Enabled = $true
		$IPOct2.Enabled = $true
		$IPOct3.Enabled = $true
		$IPOct4.Enabled = $true
		$groupboxStep2.Enabled = $false
		$labelNotify.Visible = $false
		$labelGroups.Visible = $false
		$textboxGroups.Visible = $false
		$buttonBuild.Enabled = $false
		
		#Check to make sure this is an AD FS 2.0 server
		$IsADFS = Get-Service ADFSSRV
		If (!$IsADFS)
		{
			$StopHere = $true
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " The AD FS 2.0 Windows service was not found on this machine. "
			$groupboxStep1.Enabled = $false
			$groupboxStep2.Enabled = $false
			$buttonBuild.Enabled = $false
		}
		
		#Check to make sure the AD FS 2.0 Windows service is running
		If (($IsADFS.Status -ne "Running") -and (!$StopHere))
		{
			$StopHere = $true
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " AD FS 2.0 is not running. "
			$groupboxStep1.Enabled = $false
			$groupboxStep2.Enabled = $false
			$buttonBuild.Enabled = $false
		}
		
		#Check if the AD FS 2.0 MMC is open
		$ADFSMMC = Get-Process | Where {(($_.MainWindowTitle -eq "AD FS 2.0") -and ($_.Name -eq "mmc"))}
		
		If (($ADFSMMC.GetType().Name -eq "Process") -and (!$StopHere))
		{
			$StopHere = $true
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Please close the AD FS 2.0 MMC console. "
			$groupboxStep1.Enabled = $false
			$groupboxStep2.Enabled = $false
			$buttonBuild.Enabled = $false
		}
		
		#Add the AD FS 2.0 PSH snap-in
		If (!((Get-PSSnapin Microsoft.Adfs.Powershell).Name))
		{
			Add-PSSnapin Microsoft.Adfs.Powershell
			
			If ((!((Get-PSSnapin Microsoft.Adfs.Powershell).Name)) -and (!$StopHere))
				{
					$StopHere = $true
					$labelNotify.Visible = $true
					$labelNotify.ForeColor = "Red"
					$labelNotify.Text = " AD FS 2.0 PowerShell failed to load. "
					$groupboxStep1.Enabled = $false
					$groupboxStep2.Enabled = $false
					$buttonBuild.Enabled = $false
				}
	}
	}
	
	function Validate-IsIP ([string] $IP)
	{
		$IsIP = $IP -match "\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b"
		
		If (!$IsIP)
		{
			$buttonBuild.Enabled = $false
		}
		
		Return $IsIP
	}
	
	function IPTextChanged ()
	{
		#Combine texboxes into single string IP
		$Global:IP = $IPOct1.Text+"."+$IPOct2.Text+"."+$IPOct3.Text+"."+$IPOct4.Text
		#Call function to validate if this is a valid IP address
		$Global:IPIsValid = Validate-IsIP($Global:IP)
		
		#Change UI if this IP is valid or invalid
		If ($Global:IPIsValid)
		{
			$labelIPNotify.Visible = $false
			$buttonBuild.Enabled = $true
			$labelNotify.Visible = $false
		}
		Else
		{
			$labelIPNotify.Visible = $true
			$labelIPNotify.ForeColor = "Red"
			$labelIPNotify.Text = " Invalid "
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Please enter a valid IP address "
		}
	}
	
	function RangeBeginTextChanged ()
	{
		#Combine texboxes into single string IP
		$Global:RangeBeginIP = $RangeOct1.Text+"."+$RangeOct2.Text+"."+$RangeOct3.Text+"."+$RangeOct4.Text
		#Call function to validate if this is a valid IP address
		$Global:RangeBeginIsValid = Validate-IsIP($Global:RangeBeginIP)
		
		#Change UI if this IP is valid or invalid
		If ($Global:RangeBeginIsValid)
		{
			$labelRangeBeginNotify.Visible = $false
		}
		Else
		{
			$labelRangeBeginNotify.Visible = $true
			$labelRangeBeginNotify.ForeColor = "Red"
			$labelRangeBeginNotify.Text = " Invalid "
		}
		
		#Change UI if the beginning and the end of the range are both valid
		If (($Global:RangeBeginIsValid) -and ($Global:RangeEndIsValid))
		{
			$buttonBuild.Enabled = $true
			$labelNotify.Visible = $false
		}
		Else
		{
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Please enter a valid IP address "
		}
	}
	
	function RangeEndTextChanged ()
	{
		#Combine texboxes into single string IP
		$Global:RangeEndIP = $RangeOct5.Text+"."+$RangeOct6.Text+"."+$RangeOct7.Text+"."+$RangeOct8.Text
		#Call function to validate if this is a valid IP address
		$Global:RangeEndIsValid = Validate-IsIP($Global:RangeEndIP)
		
		#Change UI if this IP is valid or invalid
		If ($Global:RangeEndIsValid)
		{
			$labelRangeEndNotify.Visible = $false
		}
		Else
		{
			$labelRangeEndNotify.Visible = $true
			$labelRangeEndNotify.ForeColor = "Red"
			$labelRangeEndNotify.Text = " Invalid "
		}
		
		#Change UI if the beginning and the end of the range are both valid
		If (($Global:RangeBeginIsValid) -and ($Global:RangeEndIsValid))
		{
			$buttonBuild.Enabled = $true
			$labelNotify.Visible = $false
		}
		Else
		{
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Please enter a valid IP address "
		}	
	}
	
	function BuildIPRegEx ([string] $IPType, [string] $IP, [string] $EndRangeIP)
	{
		If ($IPType -eq "Single")
		{
			$IPArray = $IP.Split(".")
			$RegEx = "\b"+$IPArray[0]+"\."+$IPArray[1]+"\."+$IPArray[2]+"\."+$IPArray[3]+"\b"
		}
		ElseIf ($IPType -eq "Range")
		{
			$RangeIPBeginArray = $IP.Split(".")
			$RangeIPEndArray = $EndRangeIP.Split(".")
			$RegEx = "\b"+$RangeIPBeginArray[0]+"\."+$RangeIPBeginArray[1]+"\."+$RangeIPBeginArray[2]+"\."+$RangeIPBeginArray[3]+"\b"
			$Iterations = ([int]$RangeIPEndArray[3] - [int]$RangeIPBeginArray[3])
			
			For ($i=1; $i -le $Iterations; $i++)
			{
				$NewEnding = ([int]$RangeIPBeginArray[3] + $i)
				$RegEx = $RegEx + "|\b"+$RangeIPEndArray[0]+"\."+$RangeIPEndArray[1]+"\."+$RangeIPEndArray[2]+"\."+$NewEnding+"\b"
			}
		}
		Else
		{
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Invalid IP type selected. "
		}
		
		Return $RegEx
	}
	
	function ConvertGroupsToSIDs ([string] $GroupString)
	{
		If ($GroupString -match ",")
		{
			$GroupArray = $GroupString.Split(",")
			$Iterations = ($GroupArray.Count -1)
			$FirstGroup = (New-Object system.security.principal.NtAccount($GroupArray[0].Trim())).translate([system.security.principal.securityidentifier])
			
			If (!$?)
			{
				$FirstGroup = "FAIL"
			}
			
			$ConvertedGroups = "\b"+$FirstGroup+"\b"
			
			For ($i=1; $i -le $Iterations; $i++)
			{
				$CurrentGroup = (New-Object system.security.principal.NtAccount($GroupArray[$i].Trim())).translate([system.security.principal.securityidentifier])
				
				If (!$?)
				{
					$CurrentGroup = "FAIL"
				}
				
				$ConvertedGroups = $ConvertedGroups+"|\b"+$CurrentGroup+"\b"
			}
		}
		Else
		{
			$GroupString = $GroupString.Trim()
			$ConvertedGroups = (New-Object system.security.principal.NtAccount($GroupString)).translate([system.security.principal.securityidentifier])
			
			If (!$?)
			{
				$ConvertedGroups = "FAIL"
			}
			
			$ConvertedGroups = "\b"+$ConvertedGroups+"\b"
		}
		
		Return $ConvertedGroups
	}
	
	#region Control Helper Functions
	function Load-ListBox 
	{
	<#
		.SYNOPSIS
			This functions helps you load items into a ListBox.
	
		.DESCRIPTION
			Use this function to dynamically load items into the ListBox control.
	
		.PARAMETER  ListBox
			The ListBox control you want to add items to.
	
		.PARAMETER  Items
			The object or objects you wish to load into the ListBox's Items collection.
	
		.PARAMETER  DisplayMember
			Indicates the property to display for the items in this control.
		
		.PARAMETER  Append
			Adds the item(s) to the ListBox without clearing the Items collection.
		
		.EXAMPLE
			Load-ListBox $ListBox1 "Red", "White", "Blue"
		
		.EXAMPLE
			Load-ListBox $listBox1 "Red" -Append
			Load-ListBox $listBox1 "White" -Append
			Load-ListBox $listBox1 "Blue" -Append
		
		.EXAMPLE
			Load-ListBox $listBox1 (Get-Process) "ProcessName"
	#>
		Param (
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.ListBox]$listBox,
			[Parameter(Mandatory=$true)]
			$Items,
		    [Parameter(Mandatory=$false)]
			[string]$DisplayMember,
			[switch]$Append
		)
		
		if(-not $Append)
		{
			$listBox.Items.Clear()	
		}
		
		if($Items -is [Array])
		{
			$listBox.Items.AddRange($Items)
		}
		else
		{
			$listBox.Items.Add($Items)	
		}
	
		$listBox.DisplayMember = $DisplayMember	
	}#endregion
	
	$buttonCreateClaimTypeRules_Click={
		$buttonCreateClaimTypeRules.Enabled = $false
		
		#Get the original set of AD CP trust rules to file
		$RulesFile = "$env:TEMP\ADCP_Rules.txt"
		(Get-ADFSClaimsProviderTrust -Name "Active Directory").AcceptanceTransformRules | Out-File $RulesFile
		
		#Pull the rules into an array
		$OriginalADCPTrustRules = Get-Content $RulesFile
		
		#Loop through the array looking for any matches for existing Client Access Policy claim types
		foreach ($Line in $OriginalADCPTrustRules)
		{
			If (($Line -match "x-ms-forwarded-client-ip") -or ($Line -match "x-ms-client-application") -or ($Line -match "x-ms-client-user-agent") -or ($Line -match "x-ms-proxy") -or ($Line -match "x-ms-endpoint-absolute-path"))
			{
				$RulesAlreadyExist = $true	
			}
		}
		
		#If the rules do not exist, create them. Else, do nothing.
		If (!($RulesAlreadyExist))
		{
	$ClaimRuleLanguage = @"
@RuleName = "Pass through: x-ms-forwarded-client-ip"
c:[type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip"]    => issue(claim = c);
"@
	$ClaimRuleLanguage | Out-File $RulesFile -Append		
			
	$ClaimRuleLanguage = @"
@RuleName = "Pass through: x-ms-client-application"
c:[type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application"]    => issue(claim = c);
"@
	$ClaimRuleLanguage | Out-File $RulesFile -Append
			
	$ClaimRuleLanguage = @"
@RuleName = "Pass through: x-ms-client-user-agent"
c:[type == "p://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-user-agent"]    => issue(claim = c);
"@
	$ClaimRuleLanguage | Out-File $RulesFile -Append
	
	$ClaimRuleLanguage = @"
@RuleName = "Pass through: x-ms-proxy"
c:[type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]    => issue(claim = c);
"@
	$ClaimRuleLanguage | Out-File $RulesFile -Append
			
	$ClaimRuleLanguage = @"
@RuleName = "Pass through: x-ms-endpoint-absolute-path"
c:[type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path"]    => issue(claim = c);
"@
	$ClaimRuleLanguage | Out-File $RulesFile -Append
			
			#Set the AD CP Trust with the new rule set
			Set-ADFSClaimsProviderTrust -TargetName "Active Directory" -AcceptanceTransformRulesFile $RulesFile
			
			If (!$?)
			{
				$labelClaimTypesNotify.Visible = $true
				$labelClaimTypesNotify.ForeColor = "Red"
				$labelClaimTypesNotify.Text = " Could not write to 'Active Directory' CP Trust. "
			}
			
			Remove-Item $RulesFile	
		}
		Else
		{
			$labelClaimTypesNotify.Visible = $true
			$labelClaimTypesNotify.ForeColor = "Red"
			$labelClaimTypesNotify.Text = " Existing rules detected. No action taken. "
		}
		
		$groupboxStep1.Enabled = $false
		$groupboxStep2.Enabled = $true
		$labelNotify.Visible = $true
		$labelNotify.Text = " Please enter a valid IP address "
		$labelNotify.ForeColor = "Red"
	}
	
	$radiobuttonBlockAll_CheckedChanged={
		If ($radiobuttonBlockAll.Checked)
		{	
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block all external access to Office 365"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@
		}
	}
	
	$radiobuttonBlockExceptEAS_CheckedChanged={
		If ($radiobuttonBlockExceptEAS.Checked)
		{
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block all external access to Office 365 except Exchange ActiveSync"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application",
Value=="Microsoft.Exchange.ActiveSync"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@	
		}
		
	}
	
	$radiobuttonBlockExceptBrowser_CheckedChanged={
		If ($radiobuttonBlockExceptBrowser.Checked)
		{
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block all external access to Office 365 except browser-based applications"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path", Value == "/adfs/ls/"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@
		}
		
	}
	
	$radiobuttonBlockGroups_CheckedChanged={
		If ($radiobuttonBlockGroups.Checked)
		{
			$labelGroups.Visible = $true
			$textboxGroups.Visible = $true
			$GroupString = $textboxGroups.Text
			
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block all external access to Office 365 for designated Active Directory groups"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
exists([Type == "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid", Value =~ "GroupPlaceholder"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@	
		}
		Else
		{
			$labelGroups.Visible = $false
			$textboxGroups.Visible = $false
		}
		
	}
	
	$radiobuttonBlockOnlyOutlook_CheckedChanged={
		If ($radiobuttonBlockOnlyOutlook.Checked)
		{
	$Global:ClaimRuleLanguage = @"
@RuleName = "Permit Access to All Users"
 => issue(Type = "http://schemas.microsoft.com/authorization/claims/permit", Value = "true");
@RuleName = "Block only external Outlook Clients - Exchange AutoDiscover"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application",
Value=="Microsoft.Exchange.Autodiscover"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path", Value == "/adfs/services/trust/2005/usernamemixed"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
@RuleName = "Block only external Outlook Clients - Exchange OAB"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application",
Value=="Microsoft.Exchange.OfflineAddressBook"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path", Value == "/adfs/services/trust/2005/usernamemixed"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
@RuleName = "Block only external Outlook Clients - Exchange RPC"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application",
Value=="Microsoft.Exchange.RPC"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path", Value == "/adfs/services/trust/2005/usernamemixed"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
@RuleName = "Block only external Outlook Clients - Exchange Web Services"
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-proxy"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-application",
Value=="Microsoft.Exchange.WebServices"]) &&
NOT exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-forwarded-client-ip",
Value=~"IPPlaceholder"]) &&
exists([Type == "http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path", Value == "/adfs/services/trust/2005/usernamemixed"])
=> issue(Type = "http://schemas.microsoft.com/authorization/claims/deny", Value = "true");
"@
		}
		
	}
	
	$radiobuttonSingleIP_CheckedChanged={
		If ($radiobuttonSingleIP.Checked)
		{
			#Enable/Disable textboxes for IP entry
			$RangeOct1.Enabled = $false
			$RangeOct2.Enabled = $false
			$RangeOct3.Enabled = $false
			$RangeOct4.Enabled = $false
			$RangeOct5.Enabled = $false
			$RangeOct6.Enabled = $false
			$RangeOct7.Enabled = $false
			$RangeOct8.Enabled = $false
			$IPOct1.Enabled = $true
			$IPOct2.Enabled = $true
			$IPOct3.Enabled = $true
			$IPOct4.Enabled = $true
			
			#Clear error notifications
			$labelNotify.Visible = $false
			$labelRangeBeginNotify.Visible = $false
			$labelRangeEndNotify.Visible = $false
			$labelIPNotify.Visible = $false
			
			IPTextChanged
		}
		
	}
	
	$radiobuttonIPRange_CheckedChanged={
		If ($radiobuttonIPRange.Checked)
		{
			#Enable/Disable texboxes for IP entry
			$IPOct1.Enabled = $false
			$IPOct2.Enabled = $false
			$IPOct3.Enabled = $false
			$IPOct4.Enabled = $false
			$RangeOct1.Enabled = $true
			$RangeOct2.Enabled = $true
			$RangeOct3.Enabled = $true
			$RangeOct4.Enabled = $true
			$RangeOct5.Enabled = $false
			$RangeOct6.Enabled = $false
			$RangeOct7.Enabled = $false
			$RangeOct8.Enabled = $true
			
			#Clear error notifications
			$labelNotify.Visible = $false
			$labelRangeBeginNotify.Visible = $false
			$labelRangeEndNotify.Visible = $false
			$labelIPNotify.Visible = $false
			
			RangeBeginTextChanged
			RangeEndTextChanged
		}
	}
	
	$buttonHelp_Click={
		$buttonHelp.Enabled = $false
		Start-Process -FilePath "$Env:ProgramFiles\Internet Explorer\iexplore.exe" -ArgumentList "http://technet.microsoft.com/en-us/library/hh526961(v=ws.10).aspx"
		$buttonHelp.Enabled = $true
		If (!$?)
		{
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Internet Explorer failed to load Help "
		}
	}
	
	$buttonBuild_Click={
		$buttonBuild.Text = "Working..."
		$buttonBuild.Enabled = $false
		$StopHere = $false
		
		If ($radiobuttonBlockGroups.Checked)
		{
			$labelGroups.Visible = $true
			$textboxGroups.Visible = $true
			$GroupString = $textboxGroups.Text
			
			$ConvertedGroups = ConvertGroupsToSIDs $GroupString
			
			If ($ConvertedGroups -match "FAIL")
			{
				$StopHere = $true
				$labelNotify.Visible = $true
				$labelNotify.ForeColor = "Red"
				$labelNotify.Text = " Group to SID translation failed. Check group names. "
			}
		}
		
		If (!$StopHere)
		{
			If ($radiobuttonSingleIP.Checked)
			{
				$RegEx = BuildIPRegEx "Single" $Global:IP "foo"
			}
			ElseIf ($radiobuttonIPRange.Checked)
			{
				$RegEx = BuildIPRegEx "Range" $Global:RangeBeginIP $Global:RangeEndIP
			}
			Else
			{
				$labelNotify.Visible = $true
				$labelNotify.ForeColor = "Red"
				$labelNotify.Text = " Invalid IP button selection. "
			}
		
			$RuleToWrite = $Global:ClaimRuleLanguage.Replace("IPPlaceholder", $RegEx)
			$RuleToWrite = $RuleToWrite.Replace("GroupPlaceholder",$ConvertedGroups)
		
			Set-AdfsRelyingPartyTrust -TargetName "Microsoft Office 365 Identity Platform" -IssuanceAuthorizationRules $RuleToWrite
		
			If (!$?)
			{
				$labelNotify.Visible = $true
				$labelNotify.ForeColor = "Red"
				$labelNotify.Text = " Could not write to 'Microsoft Office 365 Identity Platform' RP Trust. "
			}
			Else
			{
				$labelNotify.Visible = $true
				$labelNotify.ForeColor = "Green"
				$labelNotify.Text = " Success! Please verify the rule(s). Click Help for more information. "
			}
		}
		
		$buttonBuild.Text = "Build"
		$buttonBuild.Enabled = $true
		
	}
	
	$IPOct1_TextChanged={
		IPTextChanged
	}
	
	$IPOct2_TextChanged={
		IPTextChanged
	}
	
	$IPOct3_TextChanged={
		IPTextChanged
	}
	
	$IPOct4_TextChanged={
		IPTextChanged
	}
	
	$RangeOct1_TextChanged={
		RangeBeginTextChanged
		$RangeOct5.Text = $RangeOct1.Text
	}
	
	$RangeOct2_TextChanged={
		RangeBeginTextChanged
		$RangeOct6.Text = $RangeOct2.Text
	}
	
	$RangeOct3_TextChanged={
		RangeBeginTextChanged
		$RangeOct7.Text = $RangeOct3.Text
	}
	
	$RangeOct4_TextChanged={
		RangeBeginTextChanged
	}
	
	$RangeOct5_TextChanged={
		RangeEndTextChanged
	}
	
	$RangeOct6_TextChanged={
		RangeEndTextChanged
	}
	
	$RangeOct7_TextChanged={
		RangeEndTextChanged
	}
	
	$RangeOct8_TextChanged={
		#Combine texboxes into single string IP
		$Global:RangeEndIP = $RangeOct5.Text+"."+$RangeOct6.Text+"."+$RangeOct7.Text+"."+$RangeOct8.Text
		#Call function to validate if this is a valid IP address
		$Global:RangeEndIsValid = Validate-IsIP($Global:RangeEndIP)
		
		#Change UI if this IP is valid or invalid
		If (($Global:RangeEndIsValid) -and ([int]$RangeOct8.Text -gt [int]$RangeOct4.Text))
		{
			$labelRangeEndNotify.Visible = $false
		}
		Else
		{
			$labelRangeEndNotify.Visible = $true
			$labelRangeEndNotify.ForeColor = "Red"
			$labelRangeEndNotify.Text = " Invalid "
		}
	
		#Change UI if the beginning and the end of the range are both valid
		If (($Global:RangeBeginIsValid) -and ($Global:RangeEndIsValid) -and ([int]$RangeOct8.Text -gt [int]$RangeOct4.Text))
		{
			$buttonBuild.Enabled = $true
			$labelNotify.Visible = $false
		}
		Else
		{
			$labelNotify.Visible = $true
			$labelNotify.ForeColor = "Red"
			$labelNotify.Text = " Please enter a valid IP address "
		}
	}
	
	
	
	$textboxGroups_TextChanged={
		$GroupString = $textboxGroups.Text
		
	}
		# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$MainForm.WindowState = $InitialFormWindowState
	}
	
	$Form_StoreValues_Closing=
	{
		#Store the control values
		$script:MainForm_textboxGroups = $textboxGroups.Text
		$script:MainForm_RangeOct8 = $RangeOct8.Text
		$script:MainForm_RangeOct7 = $RangeOct7.Text
		$script:MainForm_RangeOct6 = $RangeOct6.Text
		$script:MainForm_RangeOct5 = $RangeOct5.Text
		$script:MainForm_RangeOct4 = $RangeOct4.Text
		$script:MainForm_RangeOct3 = $RangeOct3.Text
		$script:MainForm_RangeOct2 = $RangeOct2.Text
		$script:MainForm_RangeOct1 = $RangeOct1.Text
		$script:MainForm_IPOct4 = $IPOct4.Text
		$script:MainForm_IPOct3 = $IPOct3.Text
		$script:MainForm_IPOct2 = $IPOct2.Text
		$script:MainForm_IPOct1 = $IPOct1.Text
		$script:MainForm_radiobuttonIPRange = $radiobuttonIPRange.Checked
		$script:MainForm_radiobuttonSingleIP = $radiobuttonSingleIP.Checked
		$script:MainForm_radiobuttonBlockOnlyOutlook = $radiobuttonBlockOnlyOutlook.Checked
		$script:MainForm_radiobuttonBlockExceptEAS = $radiobuttonBlockExceptEAS.Checked
		$script:MainForm_radiobuttonBlockExceptBrowser = $radiobuttonBlockExceptBrowser.Checked
		$script:MainForm_radiobuttonBlockAll = $radiobuttonBlockAll.Checked
		$script:MainForm_radiobuttonBlockGroups = $radiobuttonBlockGroups.Checked
	}

	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonBuild.remove_Click($buttonBuild_Click)
			$buttonHelp.remove_Click($buttonHelp_Click)
			$textboxGroups.remove_TextChanged($textboxGroups_TextChanged)
			$RangeOct8.remove_TextChanged($RangeOct8_TextChanged)
			$RangeOct7.remove_TextChanged($RangeOct7_TextChanged)
			$RangeOct6.remove_TextChanged($RangeOct6_TextChanged)
			$RangeOct5.remove_TextChanged($RangeOct5_TextChanged)
			$RangeOct4.remove_TextChanged($RangeOct4_TextChanged)
			$RangeOct3.remove_TextChanged($RangeOct3_TextChanged)
			$RangeOct2.remove_TextChanged($RangeOct2_TextChanged)
			$RangeOct1.remove_TextChanged($RangeOct1_TextChanged)
			$IPOct4.remove_TextChanged($IPOct4_TextChanged)
			$IPOct3.remove_TextChanged($IPOct3_TextChanged)
			$IPOct2.remove_TextChanged($IPOct2_TextChanged)
			$IPOct1.remove_TextChanged($IPOct1_TextChanged)
			$radiobuttonIPRange.remove_CheckedChanged($radiobuttonIPRange_CheckedChanged)
			$radiobuttonSingleIP.remove_CheckedChanged($radiobuttonSingleIP_CheckedChanged)
			$radiobuttonBlockOnlyOutlook.remove_CheckedChanged($radiobuttonBlockOnlyOutlook_CheckedChanged)
			$radiobuttonBlockExceptEAS.remove_CheckedChanged($radiobuttonBlockExceptEAS_CheckedChanged)
			$radiobuttonBlockExceptBrowser.remove_CheckedChanged($radiobuttonBlockExceptBrowser_CheckedChanged)
			$radiobuttonBlockAll.remove_CheckedChanged($radiobuttonBlockAll_CheckedChanged)
			$radiobuttonBlockGroups.remove_CheckedChanged($radiobuttonBlockGroups_CheckedChanged)
			$buttonCreateClaimTypeRules.remove_Click($buttonCreateClaimTypeRules_Click)
			$MainForm.remove_Load($OnLoadFormEvent)
			$MainForm.remove_Load($Form_StateCorrection_Load)
			$MainForm.remove_Closing($Form_StoreValues_Closing)
			$MainForm.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	#
	# MainForm
	#
	$MainForm.Controls.Add($buttonBuild)
	$MainForm.Controls.Add($buttonHelp)
	$MainForm.Controls.Add($labelNotify)
	$MainForm.Controls.Add($groupboxStep2)
	$MainForm.Controls.Add($groupboxStep1)
	$MainForm.ClientSize = '536, 604'
	$MainForm.FormBorderStyle = 'Fixed3D'
	#region Binary Data
	$MainForm.Icon = [System.Convert]::FromBase64String('AAABAAEAHh4AAAEAGABoCwAAFgAAACgAAAAeAAAAPAAAAAEAGAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAD//////////v7+///+/v7+/v79/fz+/f3+/v7+/v3+/v3+/v7+/v79/f3+/v7+/v7////+
/v7////////////////////////////////////////+/v7///8AAP////////////3+/vn7+uvt
7uLj5eLj5eLj5OLi5eLh5OLg5uHg5ePg5O7r5/b29f7+/v//////////////////////////////
//////////////////7+/gAA///////////////+ttH3Qoj0Q4juQ4ntQ4rsRYvrRojrSIbqSILp
S4Dogp7a2dja+Pj4/////v77/Pr1+Pbx+Pbx+PXx+PXx+Pbx+PXx9/Xx+fn5////////AAD/////
/////v7///+VvfcAX/4AZ/8AZv8AZ/4Aaf8Aaf4AY/4AXv4AW/0WYPSjtNby8vH+/v3W2+2UpOKQ
od2RpN6PqduOrd2NrdyOr9yYrdve3d7Y2Njk5OQAAP////////7//////5i+9gBh/yV08Wyc7Hur
9nys+Hys93ys+Hyo9wdi+gdh+JKt2PHy79Tc+AI++gBF/wBH/gBK/gBN/QBQ/ABT/ABW/B178MzH
y4eHh8HBwQAA////////////////l772AGf/Sonn397g///7///+///+///+///9I3b7BGj5k67X
9/Tufpv4AD3+F1T2M2X4N2r8OGn8Omv8KF/7Ak39HnLv0c3Qt7e22NjYAAD////////+//////+X
v/UAbv9IjOna3OP8/Pz//////v////////4hePsDbfqTsNj29O99ofkAPf9rht/t6eT///r///z/
//u3xPYGTP0eb+7Z1Nj///7///8AAP///////////////5nC9AB3/0qP6tvd5Pz8/P//////////
/////iJ3+wJr+pGw2Pbz74Gp+QBF/22K3+vp5/7+/v///////7bE+QZL/h5p79nV1/v6+v///wAA
///////////+////nMX1AH7/SpPq3d7l/Pz8////////////////I3b7AWf7ka7Z9vTvhbD5AE7/
bo3g6+ro/v7+////////tcP5BUr+G2Pw2tbX+vr6////AAD//////////v////6eyvQAhv9Ll+ra
3OH49/X7+vj6+fj6+fj//vtIi/kBYfqUsN338++HtvkAVPuGouj08/P+/fz8/Pv///qzwfUFSv0b
W/HZ19b6+vr///8AAP///////////////6HM8wCP/zaS752236zC5qzC5qnB5cPO3+jm5OHo9EmK
96C76/z59Ym7+FmT9OXp8f779szU7MDI4sXK34WZ6ARL/BpS9NrY2Pr6+f///wAA////////////
///+rdL1AJf8BJD7E435FIr5E4b4EYL5IoXyrsHW6ebi3ej14ev4/f780+b56vH5///4jK/zImz4
H2X0IF/0FFH2AEj8HVDz7Onj/f38////AAD////////////////2+v1SrfYOmvgQl/kKkfsGifsA
gvsAevwKe/fB0+n7+vf+/v7+/v7+/v7///2cw/gVbvsDYvwAWfwATvwAQ/sFQPmptvD9/Pb/////
//8AAP////7+/v////7+/v///v//+/X1+fHz+fPz+fLz+fLy+fHy+PHy+e7z+f39/P7+/v////7/
//v9/fH2+u/z9/Dy9u/y9u/x9+/x9/379v7/+/3+/f////7+/gAA///+/////v7////88PH05ebv
5ebt5Obt5Obu5ebt5eXs4+Tr4ePq4OXt9/f3/v7+///////++f397PH34eTq293k2tzj29zj3d3j
6+nk9fX2/v7+////////AAD+//////7///2p0vZFqvc8p/Y8p/U8p/U8pfU9pvQ+pvQ/qPIzpfKe
y+r8+Pb+/v7+/v7+//73+/yIufc7hvI5ge86fe87eO47cu17l9vi4Nz7+/v////+/v4AAP//////
/unx+iSo+gGi/QCn/wCq/wCq/gCl/gCh/gCa/wCS/Wm99PDy9Pz6+Pb08/n5+f37+/j39ebv+TSK
+gBl/QBb/wBT/wBM/Q1U+NjWz/j4+P///////wAA///+////2Or6Frj+Abv9O731b873b9H7b9H6
b876bMr6kdP59/r4+fv5qtXzq83m+vf0i8r4stLm7uzq7fT6w9r5xNn3lbj1E2X8BVr82NXP+Pj3
////////AAD+///////Y7PsWy/0Fz/yg1uv//Pb///////7///////7///7//v2r3PcQmfiZw+P7
9vN6yvoQovW0zd/49vT///7///7N4PscdvwEZf3Y0874+Pf///////8AAP///////9ju+hrZ/g3c
/prX6v/5+P////////////////7////+/Qqw+gOa+p3E5Pv283vO+gCj/nm76Pbz8f///////8nh
/BqB/QRv/dnTz/j49////////wAA////////2PD7JeD9GOH+mtjq/vn4////////////////////
///+ALn9Baf7nsfl/Pf0gtX6AKz/fL7o8+/s+vn3/fr3xt73Goz8Anj92NTO+Pj3////////AAD/
///////Z7/st5P4j5/2c2ev++Pj//////////////////////v4AxvwFs/yey+X89/aJ2foAtP5b
seewxN6wxuGvyOCJuuQTk/oBgv7Y1M74+Pf///////8AAP///////9fx+kDq/Sns/Z7a6/759///
///////////////////+/QDO/QW9+5/O5/v39Zfg+QC//AC5/wCw/wCr/wCk/wCe/wCa/wCN/t7Z
1Pn5+P///////wAA////////1/H7U+79J+/+ndrq/fj2/v7+/v7+/v7+/v7+/v7+//z8AdL9BcX7
n8/m+PX14PT7bdf5V9H6Vc37Ucr6TcX6TMH7TLz6S7X79PHu/Pz8/////v7+AAD////////W8Pth
8fwn8f6g1OT66OX67ev67ez57Ov57Ov67ev66+oC1f4Fyvue0ef29fX////1+/3v+fzw+P3v+P3u
+P3v+P3u+P3v+P3+/v7+/v7///////8AAP///////9bw+2ry/STz/i7h+Dnh+Trk+Tjj+Tjj+Tbh
+DXe+CrY+Q3d/wbL/KDU6vn39////////v///v////////////////////////////////7+/v//
/wAA////////1fD6dPD8M/L+NfX9Nvb9M/X+LPX9J/L9Je39I+n9F+P9Dtv+Js/6xOPx/fz8////
////////////////////////////////////////////////AAD///////7l9vu67vq37/y28Pux
8Pup7/ud7/uP7fyG6/yF6fuA5vt94vm86fj9+/v+/v7+/v7/////////////////////////////
//////////////////8AAP/+//7+/v///v///v///v///v///v///v///v///v///v///v///v//
/f///v7+/v7+/v///////////////////////////////////////////////////wAA/v/+//7/
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=')
	#endregion
	$MainForm.Name = "MainForm"
	$MainForm.StartPosition = 'CenterScreen'
	$MainForm.Text = "Office 365 - Client Access Policy Builder"
	$MainForm.add_Load($OnLoadFormEvent)
	#
	# buttonBuild
	#
	$buttonBuild.Location = '476, 572'
	$buttonBuild.Name = "buttonBuild"
	$buttonBuild.Size = '50, 23'
	$buttonBuild.TabIndex = 23
	$buttonBuild.Text = "Build"
	$buttonBuild.UseVisualStyleBackColor = $True
	$buttonBuild.add_Click($buttonBuild_Click)
	#
	# buttonHelp
	#
	$buttonHelp.Location = '420, 572'
	$buttonHelp.Name = "buttonHelp"
	$buttonHelp.Size = '50, 23'
	$buttonHelp.TabIndex = 24
	$buttonHelp.Text = "Help"
	$buttonHelp.UseVisualStyleBackColor = $True
	$buttonHelp.add_Click($buttonHelp_Click)
	#
	# labelNotify
	#
	$labelNotify.Location = '13, 572'
	$labelNotify.Name = "labelNotify"
	$labelNotify.Size = '372, 23'
	$labelNotify.TabIndex = 25
	#
	# groupboxStep2
	#
	$groupboxStep2.Controls.Add($labelGroups)
	$groupboxStep2.Controls.Add($textboxGroups)
	$groupboxStep2.Controls.Add($groupboxIPSelection)
	$groupboxStep2.Controls.Add($radiobuttonBlockOnlyOutlook)
	$groupboxStep2.Controls.Add($labelChooseOneOfTheExampl)
	$groupboxStep2.Controls.Add($radiobuttonBlockExceptEAS)
	$groupboxStep2.Controls.Add($radiobuttonBlockExceptBrowser)
	$groupboxStep2.Controls.Add($radiobuttonBlockAll)
	$groupboxStep2.Controls.Add($radiobuttonBlockGroups)
	$groupboxStep2.Location = '13, 133'
	$groupboxStep2.Name = "groupboxStep2"
	$groupboxStep2.Size = '513, 431'
	$groupboxStep2.TabIndex = 9
	$groupboxStep2.TabStop = $False
	$groupboxStep2.Text = "Step 2"
	#
	# labelGroups
	#
	$labelGroups.Location = '37, 187'
	$labelGroups.Name = "labelGroups"
	$labelGroups.Size = '161, 23'
	$labelGroups.TabIndex = 12
	$labelGroups.Text = "Separate groups with commas:"
	#
	# textboxGroups
	#
	$textboxGroups.Location = '220, 184'
	$textboxGroups.Name = "textboxGroups"
	$textboxGroups.Size = '159, 20'
	$textboxGroups.TabIndex = 11
	$textboxGroups.Text = "domain\group1, domain\group2"
	$textboxGroups.add_TextChanged($textboxGroups_TextChanged)
	#
	# groupboxIPSelection
	#
	$groupboxIPSelection.Controls.Add($labelIPExplanation)
	$groupboxIPSelection.Controls.Add($labelRangeEndNotify)
	$groupboxIPSelection.Controls.Add($labelRangeBeginNotify)
	$groupboxIPSelection.Controls.Add($labelIPNotify)
	$groupboxIPSelection.Controls.Add($labelRangeHyphen)
	$groupboxIPSelection.Controls.Add($label9)
	$groupboxIPSelection.Controls.Add($label8)
	$groupboxIPSelection.Controls.Add($label7)
	$groupboxIPSelection.Controls.Add($label6)
	$groupboxIPSelection.Controls.Add($label5)
	$groupboxIPSelection.Controls.Add($label4)
	$groupboxIPSelection.Controls.Add($label3)
	$groupboxIPSelection.Controls.Add($label2)
	$groupboxIPSelection.Controls.Add($label1)
	$groupboxIPSelection.Controls.Add($RangeOct8)
	$groupboxIPSelection.Controls.Add($RangeOct7)
	$groupboxIPSelection.Controls.Add($RangeOct6)
	$groupboxIPSelection.Controls.Add($RangeOct5)
	$groupboxIPSelection.Controls.Add($RangeOct4)
	$groupboxIPSelection.Controls.Add($RangeOct3)
	$groupboxIPSelection.Controls.Add($RangeOct2)
	$groupboxIPSelection.Controls.Add($RangeOct1)
	$groupboxIPSelection.Controls.Add($IPOct4)
	$groupboxIPSelection.Controls.Add($IPOct3)
	$groupboxIPSelection.Controls.Add($IPOct2)
	$groupboxIPSelection.Controls.Add($IPOct1)
	$groupboxIPSelection.Controls.Add($radiobuttonIPRange)
	$groupboxIPSelection.Controls.Add($radiobuttonSingleIP)
	$groupboxIPSelection.Location = '7, 241'
	$groupboxIPSelection.Name = "groupboxIPSelection"
	$groupboxIPSelection.Size = '496, 183'
	$groupboxIPSelection.TabIndex = 10
	$groupboxIPSelection.TabStop = $False
	$groupboxIPSelection.Text = "IP Selection"
	#
	# labelIPExplanation
	#
	$labelIPExplanation.Location = '7, 115'
	$labelIPExplanation.Name = "labelIPExplanation"
	$labelIPExplanation.Size = '483, 65'
	$labelIPExplanation.TabIndex = 27
	$labelIPExplanation.Text = "The x-ms-forwarded-client-ip claim is populated from an HTTP header that is currently set only by Exchange Online, which populates the header when passing the authentication request to AD FS. The value of the claim may be a single IPV4 address or a IPV4 address range. Currently, this tool allows only a range in the last octet of the IPV4 address. For more information, click Help."
	#
	# labelRangeEndNotify
	#
	$labelRangeEndNotify.Location = '379, 83'
	$labelRangeEndNotify.Name = "labelRangeEndNotify"
	$labelRangeEndNotify.Size = '111, 23'
	$labelRangeEndNotify.TabIndex = 26
	#
	# labelRangeBeginNotify
	#
	$labelRangeBeginNotify.Location = '391, 58'
	$labelRangeBeginNotify.Name = "labelRangeBeginNotify"
	$labelRangeBeginNotify.Size = '99, 23'
	$labelRangeBeginNotify.TabIndex = 25
	#
	# labelIPNotify
	#
	$labelIPNotify.Location = '378, 25'
	$labelIPNotify.Name = "labelIPNotify"
	$labelIPNotify.Size = '111, 23'
	$labelIPNotify.TabIndex = 24
	#
	# labelRangeHyphen
	#
	$labelRangeHyphen.Font = "Microsoft Sans Serif, 14pt"
	$labelRangeHyphen.Location = '378, 50'
	$labelRangeHyphen.Name = "labelRangeHyphen"
	$labelRangeHyphen.Size = '47, 23'
	$labelRangeHyphen.TabIndex = 23
	$labelRangeHyphen.Text = "-"
	#
	# label9
	#
	$label9.Location = '323, 80'
	$label9.Name = "label9"
	$label9.Size = '10, 23'
	$label9.TabIndex = 22
	$label9.Text = "."
	#
	# label8
	#
	$label8.Location = '213, 80'
	$label8.Name = "label8"
	$label8.Size = '10, 23'
	$label8.TabIndex = 21
	$label8.Text = "."
	#
	# label7
	#
	$label7.Location = '324, 55'
	$label7.Name = "label7"
	$label7.Size = '10, 23'
	$label7.TabIndex = 20
	$label7.Text = "."
	#
	# label6
	#
	$label6.Location = '269, 55'
	$label6.Name = "label6"
	$label6.Size = '10, 23'
	$label6.TabIndex = 19
	$label6.Text = "."
	#
	# label5
	#
	$label5.Location = '268, 80'
	$label5.Name = "label5"
	$label5.Size = '10, 23'
	$label5.TabIndex = 18
	$label5.Text = "."
	#
	# label4
	#
	$label4.Location = '214, 55'
	$label4.Name = "label4"
	$label4.Size = '10, 23'
	$label4.TabIndex = 17
	$label4.Text = "."
	#
	# label3
	#
	$label3.Location = '323, 22'
	$label3.Name = "label3"
	$label3.Size = '10, 23'
	$label3.TabIndex = 16
	$label3.Text = "."
	#
	# label2
	#
	$label2.Location = '268, 22'
	$label2.Name = "label2"
	$label2.Size = '10, 23'
	$label2.TabIndex = 15
	$label2.Text = "."
	#
	# label1
	#
	$label1.Location = '214, 22'
	$label1.Name = "label1"
	$label1.Size = '10, 23'
	$label1.TabIndex = 14
	$label1.Text = "."
	#
	# RangeOct8
	#
	$RangeOct8.Location = '339, 80'
	$RangeOct8.Name = "RangeOct8"
	$RangeOct8.Size = '33, 20'
	$RangeOct8.TabIndex = 13
	$RangeOct8.add_TextChanged($RangeOct8_TextChanged)
	#
	# RangeOct7
	#
	$RangeOct7.Location = '284, 80'
	$RangeOct7.Name = "RangeOct7"
	$RangeOct7.Size = '33, 20'
	$RangeOct7.TabIndex = 12
	$RangeOct7.add_TextChanged($RangeOct7_TextChanged)
	#
	# RangeOct6
	#
	$RangeOct6.Location = '229, 80'
	$RangeOct6.Name = "RangeOct6"
	$RangeOct6.Size = '33, 20'
	$RangeOct6.TabIndex = 11
	$RangeOct6.add_TextChanged($RangeOct6_TextChanged)
	#
	# RangeOct5
	#
	$RangeOct5.Location = '175, 80'
	$RangeOct5.Name = "RangeOct5"
	$RangeOct5.Size = '33, 20'
	$RangeOct5.TabIndex = 10
	$RangeOct5.add_TextChanged($RangeOct5_TextChanged)
	#
	# RangeOct4
	#
	$RangeOct4.Location = '339, 54'
	$RangeOct4.Name = "RangeOct4"
	$RangeOct4.Size = '33, 20'
	$RangeOct4.TabIndex = 9
	$RangeOct4.add_TextChanged($RangeOct4_TextChanged)
	#
	# RangeOct3
	#
	$RangeOct3.Location = '284, 55'
	$RangeOct3.Name = "RangeOct3"
	$RangeOct3.Size = '33, 20'
	$RangeOct3.TabIndex = 8
	$RangeOct3.add_TextChanged($RangeOct3_TextChanged)
	#
	# RangeOct2
	#
	$RangeOct2.Location = '229, 55'
	$RangeOct2.Name = "RangeOct2"
	$RangeOct2.Size = '33, 20'
	$RangeOct2.TabIndex = 7
	$RangeOct2.add_TextChanged($RangeOct2_TextChanged)
	#
	# RangeOct1
	#
	$RangeOct1.Location = '175, 55'
	$RangeOct1.Name = "RangeOct1"
	$RangeOct1.Size = '33, 20'
	$RangeOct1.TabIndex = 6
	$RangeOct1.add_TextChanged($RangeOct1_TextChanged)
	#
	# IPOct4
	#
	$IPOct4.Location = '339, 23'
	$IPOct4.Name = "IPOct4"
	$IPOct4.Size = '33, 20'
	$IPOct4.TabIndex = 5
	$IPOct4.add_TextChanged($IPOct4_TextChanged)
	#
	# IPOct3
	#
	$IPOct3.Location = '284, 22'
	$IPOct3.Name = "IPOct3"
	$IPOct3.Size = '33, 20'
	$IPOct3.TabIndex = 4
	$IPOct3.add_TextChanged($IPOct3_TextChanged)
	#
	# IPOct2
	#
	$IPOct2.Location = '229, 22'
	$IPOct2.Name = "IPOct2"
	$IPOct2.Size = '33, 20'
	$IPOct2.TabIndex = 3
	$IPOct2.add_TextChanged($IPOct2_TextChanged)
	#
	# IPOct1
	#
	$IPOct1.Location = '175, 22'
	$IPOct1.Name = "IPOct1"
	$IPOct1.Size = '33, 20'
	$IPOct1.TabIndex = 2
	$IPOct1.add_TextChanged($IPOct1_TextChanged)
	#
	# radiobuttonIPRange
	#
	$radiobuttonIPRange.Location = '7, 51'
	$radiobuttonIPRange.Name = "radiobuttonIPRange"
	$radiobuttonIPRange.Size = '160, 24'
	$radiobuttonIPRange.TabIndex = 1
	$radiobuttonIPRange.TabStop = $True
	$radiobuttonIPRange.Text = "External IP address range"
	$radiobuttonIPRange.UseVisualStyleBackColor = $True
	$radiobuttonIPRange.add_CheckedChanged($radiobuttonIPRange_CheckedChanged)
	#
	# radiobuttonSingleIP
	#
	$radiobuttonSingleIP.Location = '7, 20'
	$radiobuttonSingleIP.Name = "radiobuttonSingleIP"
	$radiobuttonSingleIP.Size = '160, 24'
	$radiobuttonSingleIP.TabIndex = 0
	$radiobuttonSingleIP.TabStop = $True
	$radiobuttonSingleIP.Text = "Single external IP address"
	$radiobuttonSingleIP.UseVisualStyleBackColor = $True
	$radiobuttonSingleIP.add_CheckedChanged($radiobuttonSingleIP_CheckedChanged)
	#
	# radiobuttonBlockOnlyOutlook
	#
	$radiobuttonBlockOnlyOutlook.Location = '7, 210'
	$radiobuttonBlockOnlyOutlook.Name = "radiobuttonBlockOnlyOutlook"
	$radiobuttonBlockOnlyOutlook.Size = '489, 24'
	$radiobuttonBlockOnlyOutlook.TabIndex = 9
	$radiobuttonBlockOnlyOutlook.TabStop = $True
	$radiobuttonBlockOnlyOutlook.Text = "Block only external Outlook clients"
	$radiobuttonBlockOnlyOutlook.UseVisualStyleBackColor = $True
	$radiobuttonBlockOnlyOutlook.add_CheckedChanged($radiobuttonBlockOnlyOutlook_CheckedChanged)
	#
	# labelChooseOneOfTheExampl
	#
	$labelChooseOneOfTheExampl.Location = '7, 20'
	$labelChooseOneOfTheExampl.Name = "labelChooseOneOfTheExampl"
	$labelChooseOneOfTheExampl.Size = '497, 44'
	$labelChooseOneOfTheExampl.TabIndex = 8
	$labelChooseOneOfTheExampl.Text = "Choose one of the example scenarios below to configure the claim rules on the Microsoft Office 365 Identity Platform relying party trust that best meets the needs of your organization, enter an external IP address or external IP address range, and click the Build button."
	#
	# radiobuttonBlockExceptEAS
	#
	$radiobuttonBlockExceptEAS.Location = '7, 97'
	$radiobuttonBlockExceptEAS.Name = "radiobuttonBlockExceptEAS"
	$radiobuttonBlockExceptEAS.Size = '489, 33'
	$radiobuttonBlockExceptEAS.TabIndex = 5
	$radiobuttonBlockExceptEAS.TabStop = $True
	$radiobuttonBlockExceptEAS.Text = "Block all external access to Office 365, except Exchange ActiveSync"
	$radiobuttonBlockExceptEAS.UseVisualStyleBackColor = $True
	$radiobuttonBlockExceptEAS.add_CheckedChanged($radiobuttonBlockExceptEAS_CheckedChanged)
	#
	# radiobuttonBlockExceptBrowser
	#
	$radiobuttonBlockExceptBrowser.Location = '7, 127'
	$radiobuttonBlockExceptBrowser.Name = "radiobuttonBlockExceptBrowser"
	$radiobuttonBlockExceptBrowser.Size = '489, 35'
	$radiobuttonBlockExceptBrowser.TabIndex = 6
	$radiobuttonBlockExceptBrowser.TabStop = $True
	$radiobuttonBlockExceptBrowser.Text = "Block all external access to Office 365, except for browser-based applications such as Outlook Web Access or SharePoint Online"
	$radiobuttonBlockExceptBrowser.UseVisualStyleBackColor = $True
	$radiobuttonBlockExceptBrowser.add_CheckedChanged($radiobuttonBlockExceptBrowser_CheckedChanged)
	#
	# radiobuttonBlockAll
	#
	$radiobuttonBlockAll.Location = '7, 67'
	$radiobuttonBlockAll.Name = "radiobuttonBlockAll"
	$radiobuttonBlockAll.Size = '489, 24'
	$radiobuttonBlockAll.TabIndex = 4
	$radiobuttonBlockAll.TabStop = $True
	$radiobuttonBlockAll.Text = "Block all external access to Office 365"
	$radiobuttonBlockAll.UseVisualStyleBackColor = $True
	$radiobuttonBlockAll.add_CheckedChanged($radiobuttonBlockAll_CheckedChanged)
	#
	# radiobuttonBlockGroups
	#
	$radiobuttonBlockGroups.Location = '7, 158'
	$radiobuttonBlockGroups.Name = "radiobuttonBlockGroups"
	$radiobuttonBlockGroups.Size = '489, 35'
	$radiobuttonBlockGroups.TabIndex = 7
	$radiobuttonBlockGroups.TabStop = $True
	$radiobuttonBlockGroups.Text = "Block all external access to Office 365 for members of designated Active Directory groups"
	$radiobuttonBlockGroups.UseVisualStyleBackColor = $True
	$radiobuttonBlockGroups.add_CheckedChanged($radiobuttonBlockGroups_CheckedChanged)
	#
	# groupboxStep1
	#
	$groupboxStep1.Controls.Add($labelClaimTypesNotify)
	$groupboxStep1.Controls.Add($labelAfterTheUpdateRollup)
	$groupboxStep1.Controls.Add($buttonCreateClaimTypeRules)
	$groupboxStep1.Location = '13, 13'
	$groupboxStep1.Name = "groupboxStep1"
	$groupboxStep1.Size = '510, 114'
	$groupboxStep1.TabIndex = 8
	$groupboxStep1.TabStop = $False
	$groupboxStep1.Text = "Step 1"
	#
	# labelClaimTypesNotify
	#
	$labelClaimTypesNotify.Location = '181, 81'
	$labelClaimTypesNotify.Name = "labelClaimTypesNotify"
	$labelClaimTypesNotify.Size = '315, 23'
	$labelClaimTypesNotify.TabIndex = 2
	#
	# labelAfterTheUpdateRollup
	#
	$labelAfterTheUpdateRollup.Location = '6, 16'
	$labelAfterTheUpdateRollup.Name = "labelAfterTheUpdateRollup"
	$labelAfterTheUpdateRollup.Size = '497, 58'
	$labelAfterTheUpdateRollup.TabIndex = 1
	$labelAfterTheUpdateRollup.Text = "After the Update Rollup 1 for Active Directory Federation Services (AD FS) 2.0 package has been installed on all federation servers and federation server proxies, and the AD FS Windows service has been restarted, use the following button to add a set of claim rules that make the new claim types available to the policy engine."
	#
	# buttonCreateClaimTypeRules
	#
	$buttonCreateClaimTypeRules.Location = '6, 81'
	$buttonCreateClaimTypeRules.Name = "buttonCreateClaimTypeRules"
	$buttonCreateClaimTypeRules.Size = '168, 23'
	$buttonCreateClaimTypeRules.TabIndex = 0
	$buttonCreateClaimTypeRules.Text = "Create Rules for Claim Types"
	$buttonCreateClaimTypeRules.UseVisualStyleBackColor = $True
	$buttonCreateClaimTypeRules.add_Click($buttonCreateClaimTypeRules_Click)
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $MainForm.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$MainForm.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$MainForm.add_FormClosed($Form_Cleanup_FormClosed)
	#Store the control values when form is closing
	$MainForm.add_Closing($Form_StoreValues_Closing)
	#Show the Form
	return $MainForm.ShowDialog()

}
#endregion

#region Call-Global_ps1
	#--------------------------------------------
	# Declare Global Variables and Functions here
	#--------------------------------------------
	
	
	#Sample function that provides the location of the script
	function Get-ScriptDirectory
	{ 
		if($hostinvocation -ne $null)
		{
			Split-Path $hostinvocation.MyCommand.path
		}
		else
		{
			Split-Path $script:MyInvocation.MyCommand.Path
		}
	}
	
	#Sample variable that provides the location of the script
	[string]$ScriptDirectory = Get-ScriptDirectory
	
	
	
#endregion

#Start the application
Main ($CommandLine)
