﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

Function Remove-OSCSPSiteUser
{
<#
 	.SYNOPSIS
        Remove-OSCSPSiteUser is an advanced function which can be used to remove users from a Site that have a specific permission level.
    .DESCRIPTION
        Remove-OSCSPSiteUser is an advanced function which can be used to remove users from a Site that have a specific permission level.
    .PARAMETER  SiteUrl
		The specified site URL.
    .PARAMETER  Permission 
		The specific permission level.
    .EXAMPLE
        C:\PS> Remove-OSCSPSiteUser -SiteURL "http://win-lfseeatt8jr/sites/mysite" -Permission "Design"
		
		This command shows how to remove users from "http://win-lfseeatt8jr/sites/mysite" that have a "Design" permission level.
#>
	[CmdletBinding()]
	Param
	(
	    [Parameter(Mandatory = $True,Position=0)]
		[String]$SiteURL,
		[Parameter(Mandatory = $True,Position=1)]
		[ValidateSet("Design","Contribute","Full Control","Read")]
		[String]$Permission 
	)
	[System.Reflection.Assembly]::Load("Microsoft.SharePoint, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")   | Out-Null	
	[System.Reflection.Assembly]::Load("Microsoft.SharePoint.Portal, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")   | Out-Null	
	[System.Reflection.Assembly]::Load("Microsoft.SharePoint.Publishing, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")   | Out-Null	
	[System.Reflection.Assembly]::Load("System.Web, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")   | Out-Null
	if ((Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'})-eq $null) 
	{
		Add-PSSnapin "Microsoft.SharePoint.Powershell"
	}
		
	$Caption = "Confirm Remove Permission"
	$Message = "This action will remove all users with the specified permission,do you want to continue?"
	$Choices = [System.Management.Automation.Host.ChoiceDescription[]]@("&Yes","&No")
	[Int]$DefaultChoice = 0
	$ChoiceRTN = $Host.UI.PromptForChoice($Caption, $Message, $Choices, $DefaultChoice) 
	If($ChoiceRTN -eq 0)
	{
		Removeuser $SiteURL $Permission
	}
	Else
	{
		Break
	}
}


Function Removeuser([String]$SiteURL,[String]$Permission)
{
	Try
	{
		#Get SharePoint site
		$Flag = $False
		#Get spsite
		$Site = New-Object Microsoft.SharePoint.SPSite($SiteURL)
		$Web = $site.OpenWeb()
		#Get all users in the site
		$SiteUsers = $web.SiteUsers
		#Loop the users with the specified permission
		Foreach($SiteUser in $SiteUsers)
		{	
			#Ignore the local system users
		    If(($SiteUser.IsSiteAdmin -eq $false) -and ($SiteUser.UserLogin -notmatch "AUTHORITY")  -and ($SiteUser.UserLogin -notmatch "System"))
		    {
				#Check if the user is granted directly, or in a member group 
		        If($SiteUser.Roles -ne $null )
		        {
                    If(($SiteUser.Roles | select name).count -lt 1)
                    {
		              $UserPermission = ($SiteUser.Roles  | select Name).Name
                    }
                	Else
                    {
						#If the user has several level permissions,the highest one works
                        $UserPermission = ($SiteUser.Roles  | select Name)[0].Name
                    }
		        }
		        Else
		        {
					#If the user is in a member group, get the permission of the group
					If($SiteUser.Groups -ne $null)
					{
						$GroupRoles = ($SiteUser.Groups | Select Roles).Roles
						$UserPermission = ($GroupRoles |select Name).Name       
					}   
		        }
		        If($UserPermission -match $Permission)
		        {
					#Delete the user 
					$Flag = $true
		            $UserName = $SiteUser.Name
					$web.SiteUsers.Remove($SiteUser)
		            write-Host "Removing Permission from User '$UserName' successfully" -ForegroundColor Green
		        }
		    		 
		    }
			If($Flag)
			{
                Break;   
			}
		}
		If($Flag)
		{
			Removeuser $SiteURL $Permission
		}
		$Web.close()
		$Site.dispose()
		
	}
	Catch
	{
		Write-Error $_
	}
}

