#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 2.0

Function Set-OSCWindowsSearchFeature
{
<#
 	.SYNOPSIS
        Set-OSCWindowsSearchFeature is an advanced function which can be used to disable or enable Windows Search Feature.
    .DESCRIPTION
        Set-OSCWindowsSearchFeature is an advanced function which can be used to disable or enable Windows Search Feature.
    .PARAMETER  <enable>
		Disable Windows Search Feature.
	.PARAMETER  <diable>
		Enable Windows Search Feature.
    .EXAMPLE
        C:\PS> Set-OSCWindowsSearchFeature -Disable

		Disabling Search Feature...

		Deployment Image Servicing and Management tool
		Version: 6.1.7600.16385

		Image Version: 6.1.7600.16385

		Disabling feature(s)
		[==========================100.0%==========================]
		The operation completed successfully.
		Restart Windows to complete this operation.
		
		This command shows how to disable Windows Search Feature.
    .EXAMPLE
        C:\PS> Set-OSCWindowsSearchFeature -Enable

		Enabling Search Feature...

		Deployment Image Servicing and Management tool
		Version: 6.1.7600.16385

		Image Version: 6.1.7600.16385

		Disabling feature(s)
		[==========================100.0%==========================]
		The operation completed successfully.
		Restart Windows to complete this operation.
		
		This command shows how to enable Windows Search Feature.
#>
	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
    (
        [Parameter(Mandatory=$true,Position=0,ParameterSetName='Disable')]
		[Alias("dis")][Switch]$Disable,
		[Parameter(Mandatory=$true,Position=0,ParameterSetName='Enable')]
		[Alias("en")][Switch]$Enable
    )
	
	$SearchFeatureInfo = Dism /online /Get-FeatureInfo /FeatureName:SearchEngine-Client-Package
	$FeatureState = $SearchFeatureInfo | Select-String "State"
	
	If($Disable)
	{
		If($PSCmdlet.ShouldProcess("Disabling Search Feature"))
		{
			If($FeatureState -match "Enable")
			{
				Write-Host "Disabling Search Feature..."
				Dism /online /Disable-Feature /FeatureName:SearchEngine-Client-Package
			}
			If($FeatureState -match "Disable")
			{
				Write-Warning "Search Feature is already disabled." 
			}
		}
	}
	
	If($Enable)
	{
		If($PSCmdlet.ShouldProcess("Enabling Search Feature"))
		{
			If($FeatureState -match "Disable")
			{
				Write-Host "Enabling Search Feature..."
				Dism /online /Enable-Feature /FeatureName:SearchEngine-Client-Package
			}
			If($FeatureState -match "Enable")
			{
				Write-Warning "Search Feature is already Enabled." 
			}
		}
	}
}