﻿##########################################################################################
# Heartbeat Monitor for Service Manager - Configure this for your environment
##########################################################################################
# Configuration  Edit below values for your environment      #
$SQLProduction = 'myservicemanagerdb'                        # Service Manager Primary server (not DW)
$SQLReporting  = 'mysqlserver'                               # SQL Server for SM Tracking
$SQLDBName     = 'SMHEALTH'                                  # Database Name - default 'SMHEALTH'
$AlertEmailTo  = 'user@domain.com'                           # Primary email for daily recap
$AlertEmailAdd = 'MyDL@domain.com'                           # Additional email or DL fordaily recap
$ExchangeURL   = “https://mail.domain.com/ews/exchange.asmx” # URL for Exchange Web Services, generally mail.domain.com/ews/exchange.asmx
# Configuration End  
######################################################
# Set connection to Production DB for latest numbers #
######################################################
$connstr = ("Data Source=$SQLProduction;Initial Catalog=ServiceManager;Integrated Security=SSPI;") 
$conn = New-object system.data.sqlclient.sqlconnection($connstr)
$conn.open()
# Start text for email body $stats
$Stats="<BR>"
######################################################
# Gather trend datapoints
######################################################
#Number of new IR's 24 Hours
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT Count (*)   FROM [ServiceManager].[dbo].[MTV_System"+'$WorkItem$Incident]' + "where CreatedDate_6258638D_B885_AB3C_E316_D00782B8F688 > (select dateadd(day,-1,getutcdate())) "
$IRsLast24Hours=$cmd.executescalar()
write-host "There were "  $IRsLast24Hours  "  new IR's created in the last 24 Hours"
$Stats=$Stats + "There were " + $IRsLast24Hours + "  new IR's created in the last 24 Hours<BR>"
#Number of IR's open and older than 30 days - Our system closes IR's that reach 30 days 
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT Count (*)   FROM [ServiceManager].[dbo].[MTV_System"+'$WorkItem$Incident]' + "where CreatedDate_6258638D_B885_AB3C_E316_D00782B8F688 < (select dateadd(Day,-30,getUTCdate())) and ClosedDate_C529833E_0926_F082_C185_294CBC8BB9FD is null"
$IRSOlderthan30days=$cmd.executescalar()
write-host "There were "  $IRSOlderthan30days  " active IR's older than 30 days"
$Stats=$Stats + "There were " + $IRSOlderthan30days + " active IR's older than 30 days<BR>"
#Number of new SR's last 24 Hours
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT Count (*)    FROM [ServiceManager].[dbo].[MTV_System" + '$WorkItem$ServiceRequest]' + "where [CreatedDate_6258638D_B885_AB3C_E316_D00782B8F688]  > (select dateadd(day,-1,getutcdate()))"
$SRsLast24Hours=$cmd.executescalar()
write-host "There were "  $SRsLast24Hours  " new SR's created in the last 24 Hours"
$Stats=$Stats + "There were "+  $SRsLast24Hours + " new SR's created in the last 24 Hours<BR>"
#Total Number of IR's
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT COUNT ([Id_9A505725_E2F2_447F_271B_9B9F4F0D190C]) FROM [ServiceManager].[dbo].[MTV_System" + '$WorkItem$Incident]' + " "
$IRsTotalCount=$cmd.executescalar()
write-host "There are a total of "$IRsTotalCount "IR's in the system"
$Stats=$Stats + "There are a total of "+$IRsTotalCount+ " IR's in the system<BR>"
#Total number of open IR's in system 
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT     COUNT(Id_9A505725_E2F2_447F_271B_9B9F4F0D190C) AS Expr1 FROM MTV_System"+'$WorkItem$Incident'+" GROUP BY ClosedDate_C529833E_0926_F082_C185_294CBC8BB9FD HAVING (ClosedDate_C529833E_0926_F082_C185_294CBC8BB9FD IS NULL)"
$IRsTotalOPenCount=$cmd.executescalar()
write-host "There are a total of "$IRsTotalOpenCount " Open IR's in the system"
$Stats=$Stats + "There are a total of "+$IRsTotalOpenCount+ " Open IR's in the system<BR>"
#SR Total
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT COUNT ([Id_9A505725_E2F2_447F_271B_9B9F4F0D190C]) FROM [ServiceManager].[dbo].[MTV_System" + '$WorkItem$ServiceRequest]' + " "
$SRsTotalCount=$cmd.executescalar()
write-host "There are a total of "$SRsTotalCount "SR's in the system"
$Stats=$Stats + "There are a total of "+$SRsTotalCount+ " SR's in the system<BR>"
#SR Open 
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT     COUNT(Id_9A505725_E2F2_447F_271B_9B9F4F0D190C) AS Expr1 FROM MTV_System"+'$WorkItem$ServiceRequest'+" "
$cmd.commandtext = $cmd.commandtext + "GROUP BY ClosedDate_97E7869A_FEFA_D7D2_BDFC_ECAD440E080E HAVING (ClosedDate_97E7869A_FEFA_D7D2_BDFC_ECAD440E080E IS NULL) "
$SRsTotalOpenCount=$cmd.executescalar()
write-host "There are a total of "$SRsTotalOpenCount " Open SR's in the system"
$Stats=$Stats + "There are a total of "+$SRsTotalOpenCount+ " Open SR's in the system<BR>"
#Count BMEs to Purge
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT COUNT(1) BMEsToPurge FROM dbo.[BaseManagedEntity] WHERE [IsDeleted] = 1 AND [LastModified] > (select dateadd(day,-1,getutcdate()))"
$BMEtoPurge=$cmd.executescalar()
write-host "There were a total of "$BMEtopurge " BMEs purged this morning"
$Stats=$Stats + "There were a total of "+ $BMEtopurge + " BMEs scheduled to be purged<BR>"
#Count TMEsToPurge to Purge
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT COUNT(1) TMEsToPurge FROM dbo.[TypedManagedEntity] WHERE [IsDeleted] = 1 AND [LastModified] > (select dateadd(day,-1,getutcdate()))"
$TMEsToPurge=$cmd.executescalar()
write-host "There were a total of "$TMEsToPurge " TMEs purged this morning"
$Stats=$Stats +  "There were a total of "+ $TMEsToPurge +" TMEs scheduled to be purged<BR>"
#Count RelationShips to Purge
$cmd=$conn.createcommand()
$cmd.commandtext = "SELECT COUNT(1) RelationshipsToPurge FROM dbo.[Relationship] WHERE [IsDeleted] = 1 AND [LastModified] > (select dateadd(day,-1,getutcdate()))"
$RelationShips=$cmd.executescalar()
write-host "There were a total of "$RelationShips " relationships purged this morning"
$Stats=$Stats + "There were a total of "+ $RelationShips +" relationships scheduled to be purged<BR>"
#Count minutes for last grooming event
$cmd=$conn.createcommand()
#$cmd.commandtext = "select top 1 DATEDIFF(minute,timestarted,timefinished) from InternalJobHistory where command like 'exec dbo.p_datapurging' order by InternalJobHistoryid desc"
$cmd.commandtext = "SELECT     SUM(DATEDIFF(minute, TimeStarted, TimeFinished)) AS Minutes FROM InternalJobHistory "
$cmd.commandtext=$cmd.commandtext + "WHERE     (Command LIKE 'exec dbo.p_datapurging') AND (TimeStarted > (SELECT     DATEADD(day, - 1, GETUTCDATE()) AS Expr1))"
$PreviousGroom=$cmd.executescalar()
write-host "Our last groom event took "$PreviousGroom " minutes to complete"
$Stats=$Stats + "Our last groom event took "+ $PreviousGroom +" minutes to complete<BR>"
#Count changelogentity rows
$cmd=$conn.createcommand()
$cmd.commandtext = "select COUNT(*) from entitychangelog"
$EntityChangeLogRows=$cmd.executescalar()
write-host "The current row count of EntityChangeLog is "$EntityChangeLogRows " rows"
$Stats=$Stats + "The current row count of EntityChangeLog is "+ $EntityChangeLogRows +" rows<BR>"
#Count relatedentitychangelogentity rows
$cmd=$conn.createcommand()
$cmd.commandtext = "select COUNT(*) from relatedentitychangelog"
$RelatedEntityChangeLogRows=$cmd.executescalar()
write-host "The current row count of RelatedEntityChangeLog is "$RelatedEntityChangeLogRows " rows"
$Stats=$Stats + "The current row count of RelatedEntityChangeLog is "+ $RelatedEntityChangeLogRows +" rows<BR>"
## New Last 24 hour table
$cn = new-object system.data.sqlclient.sqlconnection("Data Source=$SQLReporting;integrated security=sspi;initial catalog=$SQLDBName");
$ds = new-object "System.Data.DataSet" "dsInventoryData"
$Q = "SELECT     TOP (1000) AVG(IRNewCount) AS IRNewCount, AVG(IROpenOver30) AS IROpenOver30, AVG(SRNewCount) AS SRNewCount, AVG(IRTotalCount) AS IRTotalCount, AVG(IRTotalActive) AS IRTotalActive, AVG(SRTotalCount) AS SRTotalCount, AVG(SRTotalOpen) AS SRTotalOpen, AVG(BMEsToPurge) AS BMEsToPurge, AVG(GroomTime) AS GroomTime FROM SM_Daily_trending_30Day "
$da = New-object "System.Data.SqlClient.SqlDataAdapter" ($q, $cn)
$da.Fill($ds)
$dtInventory = new-object "System.Data.DataTable" "dsInventoryData"
$dtInventory = $ds.Tables[0]

$AvgIRnewCount= $dtInventory | ForEach-Object {[string]$_.IrNewCount}
$AvgSRNewCount= $dtInventory | ForEach-Object {[string]$_.SRNewCount}
$AvgIrOpenOver30 = $dtInventory | ForEach-Object {[string]$_.IrOpenOver30}
$AvgIRTotalCount = $dtInventory | ForEach-Object {[string]$_.IRTotalCount}
$avgIRTotalActive = $dtInventory | ForEach-Object {[string]$_.IRTotalActive}
$AvgSRTotalCount = $dtInventory | ForEach-Object {[string]$_.SRTotalCount}
$AvgSRTotalOpen = $dtInventory | ForEach-Object {[string]$_.SRTotalOpen}
$AvgBMEsToPurge = $dtInventory | ForEach-Object {[string]$_.BMEsToPurge}
$AvgGroomTime = $dtInventory | ForEach-Object {[string]$_.GroomTime}
$NewLastDayTable="<table border=1>"
$NewLastDayTable=$NewLastDayTable + "<TR><TH>Area</TH><TH>Last 24 Hour</TH><TH>Average 30day</TH></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>New IR's</FONT></td><td><FONT size=2>" + $IRsLast24Hours + "</FONT></td><td><FONT size=2>" +  $avgIRNewCount + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>New SR's</FONT></td><td><FONT size=2>" + $SRsLast24Hours + "</FONT></td><td><FONT size=2>" + $avgSRNewCount + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>IR TTL</FONT></td><td><FONT size=2>" + $IRsTotalCount + "</FONT></td><td><FONT size=2>" + $avgIRTotalCount + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>IR Active</FONT></td><td><FONT size=2>" + $IRsTotalOpenCount + "</FONT></td><td><FONT size=2>" + $avgIRTotalActive + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>SR TTL</FONT></td><td><FONT size=2>" + $SRsTotalCount + "</FONT></td><td><FONT size=2>" + $avgSRTotalCount + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>SR Open</FONT></td><td><FONT size=2>" + $SRsTotalOpenCount + "</FONT></td><td><FONT size=2>" + $avgSRTotalOpen + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>IR's 30+ Day</FONT></td><td><FONT size=2>" + $IRSOlderthan30days + "</FONT></td><td><FONT size=2>" + $avgIROpenOver30 + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>BME</FONT></td><td><FONT size=2>" + $BMEtopurge + "</FONT></td><td><FONT size=2>" + $avgBMEsToPurge + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "<TD><FONT size=2>Groom</FONT></td><td><FONT size=2>" + $PreviousGroom + "</FONT></td><td><FONT size=2>" + $avgGroomTime + "</FONT></td></TR>"
$NewLastDayTable=$NewLastDayTable + "</table><br>"
$Stats=$Stats + "<HR>New Last 24 hour Report<BR>"
$Stats=$Stats + $NewLastDayTable

## Create top 25 issue chart for last 24 hours


$connstr3 = ("Data Source=$SQLProduction;Initial Catalog=ServiceManager;Integrated Security=SSPI;") 
$conn3 = New-object system.data.sqlclient.sqlconnection($connstr3)
$conn3.open()
$cmd=$conn3.createcommand()

$cmd.commandtext ="SELECT     TOP (25) dbo.MT_System" +'$WorkItem$Incident'+".Title_9691DD10_7211_C835_E3E7_6B38AF8B8104 AS AlertType, COUNT(*) AS Count, dbo.DisplayStringView.DisplayName as displayname "
$cmd.commandtext = $cmd.commandtext + "FROM         dbo.MT_System"+'$WorkItem$Incident'+" INNER JOIN dbo.DisplayStringView ON dbo.MT_System"+'$WorkItem$Incident'+".TierQueue_1E9615C2_3386_2452_BA83_05B2169DF38C = dbo.DisplayStringView.LTStringId "
$cmd.commandtext = $cmd.commandtext + "WHERE     (dbo.MT_System"+'$WorkItem$Incident'+".CreatedDate_6258638D_B885_AB3C_E316_D00782B8F688 > (SELECT   DATEADD(D, - 1, GETUTCDATE()) AS Expr1)) "
$cmd.commandtext = $cmd.commandtext + "GROUP BY dbo.MT_System"+'$WorkItem$Incident'+".Title_9691DD10_7211_C835_E3E7_6B38AF8B8104, dbo.DisplayStringView.DisplayName, DisplayStringView.LanguageCode HAVING (DisplayStringView.LanguageCode = N'enu')  ORDER BY COUNT DESC "

$GetLast24hrIRresult=$cmd.executescalar()
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $cmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$GetLast24hrIRresult=$DataSet.Tables[0] 
$dataset.tables[0].rows.count

$HighIRTable="<BR>Top 25 Alerts's for last 24 Hours<BR>"
$HighIRTable=$HighIRTable + "<table border=1>"
$highirtable=$highirtable + "<TR><TH>Count</TH><TH>Alert</TH><Th>Support Queue</TH></TR>"
foreach ($a in $GetLast24hrIRresult)
{
$HighIRTable=$HighIRTable + "<TD><FONT size=2>" + [string]$a.count + "</FONT></td><td><FONT size=2>" + [string]$a.AlertType + "</FONT></td><TD><FONT size=2>" + [string]$a.displayname + "</FONT></td></TR>"
}
$HighIRTable=$HighIRTable + "</table><br>"
$stats=$stats + "<BR>"
$Stats=$stats + $HighIRTable
# Start IR Count by Queue
$connstr3 = ("Data Source=$SQLProduction;Initial Catalog=ServiceManager;Integrated Security=SSPI;") 
$conn3 = New-object system.data.sqlclient.sqlconnection($connstr3)
$conn3.open()
$cmd=$conn3.createcommand()


$cmd.commandtext = "SELECT DISTINCT top 10 COUNT(*) AS Count, DisplayStringView.DisplayName AS Queue FROM MTV_System"+'$WorkItem$'+"Incident INNER JOIN DisplayStringView ON MTV_System"+'$WorkItem$'+"Incident.TierQueue_1E9615C2_3386_2452_BA83_05B2169DF38C = DisplayStringView.LTStringId "
$cmd.commandtext = $cmd.commandtext + "WHERE (MTV_System"+'$WorkItem$'+"Incident.CreatedDate_6258638D_B885_AB3C_E316_D00782B8F688 > DATEADD(day, - 1, getutcdate())) GROUP BY DisplayStringView.DisplayName, DisplayStringView.LanguageCode "
$cmd.commandtext = $cmd.commandtext + "HAVING      (DisplayStringView.LanguageCode = N'enu') ORDER BY Count DESC"

$GetIRsByQueue=$cmd.executescalar()
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $cmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$GetIRsByQueue=$DataSet.Tables[0] 
$dataset.tables[0].rows.count

$QueueCountTable="<BR>Top 10 IR load by queue<BR>"
$QueueCountTable=$QueueCountTable + "<table border=1>"
$QueueCountTable=$QueueCountTable + "<TR><TH>Count</TH><Th>Support Queue</TH></TR>"
foreach ($a in $GetIRsByQueue)
{
$QueueCountTable=$QueueCountTable + "<TD><FONT size=2>" + [string]$a.count + "</FONT></td><td><FONT size=2>" + [string]$a.queue + "</FONT></td></TR>"
}
$QueueCountTable=$QueueCountTable + "</table><br>"
$stats=$stats + "<BR>"
$Stats=$stats + $QueueCountTable

# End IR Count by Queue
## End top 25 issue chart for last 24 hours

$conn.Close()

#########################################
# SQL Insert action
#########################################

$connstr2 = ("Data Source=$SQLReporting;Initial Catalog=$SQLDBName;Integrated Security=SSPI;") 
$conn2 = New-object system.data.sqlclient.SqlConnection($connstr2)
$conn2.Open()
$cmd=$conn2.CreateCommand()
$CMD.CommandText = "INSERT INTO SM_Daily_trending (IRTotalCount,IRNewCount,SRTotalCount,SRNewCount,GroomTime,BMEsToPurge,IRTotalActive,SRTotalOpen,IROpenOver30,EntityChangeLog) Values "
$cmd.commandtext = $cmd.commandtext + "('$IRsTotalCount','$IRsLast24Hours','$SRsTotalCount','$SRsLast24Hours','$PreviousGroom','$BMEtoPurge','$IRsTotalOpenCount','$SRsTotalOpenCount','$IRSOlderthan30days','$EntityChangeLogRows')"
$cmdresult=$CMD.ExecuteNonQuery()

#########################################
# Send daily status
#########################################
#Setup email 
write-host "Sending email"
$dllpath = "C:\Program Files\Microsoft\Exchange\Web Services\1.1\Microsoft.Exchange.WebServices.dll"
[void][Reflection.Assembly]::LoadFile($dllpath)
$service2 = new-object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2007_SP1)
    $uri2=[system.URI] $ExchangeURL
    $service2.Url = $uri2
    $message = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage($service2)
$message.subject = "Service Manager Daily Report"
$message.ToRecipients.Add($AlertEmailTo)
$message.ToRecipients.Add($AlertEmailAdd)
# If you need additional TO: lines, create a new line per address below
# $message.ToRecipients.Add('email@domain.com')
# $message.ToRecipients.Add('group@domain.com')
$body = "<B><u>Service Manager Daily Report </b></u><BR>"
$body = $body + "<BR>"
$body = $body + "This report covers the last 24 hours<BR>"
$body = $body + $Stats
$body = $body + "<BR>"
$body = $body + "<BR>"
$body = $body + "SQL Data:<BR>"
$body = $body + "<ul>Server = $SQLReporting<BR>"
$body = $body + "Catalog/DB = $SQLDBName<BR>"
$body = $body + "<B>Table = SM_Daily_Trending</b><BR>"
$message.body = $body
$message.send.Invoke()


