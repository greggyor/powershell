############################################################
#
# Copyright (c) Microsoft. All rights reserved.
# This code is licensed under the Microsoft Public License.
# THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
# ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
# IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
# PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#
############################################################

##############################################################
#
# ConfigureCloud_NonConverged.ps1
# ------------------------
#
# This sample demonstrates the setup and configuration
# of a clustered HyperV environment as part of the Cloud 
# Technologies sample.
##############################################################

<#
.SYNOPSIS
demonstrates the setup and configuration Of a clustered HyperV environment 

.PARAMETER settingsFile
Specifies an alternate settings file
default is ".\Settings_Nonconverged.ps1"

.PARAMETER Credential 
PSCredential object. Must be administrator all machines, will get full cluster access.

#>

Param(
    [ValidateScript({ Test-path -Path $_ })]
    [string]
    $settingsFile = "..\Settings_Nonconverged.ps1",
    [System.Management.Automation.PSCredential]
    $Credential = $null
)
Set-strictMode -version 2

$setting =  & $settingsFile

if( -not $setting ){ Throw 'Settings not found' }

if ( -not $Credential )
{
    $Credential = Get-Credential -Credential $Setting.AdminAccount -ErrorAction stop
}

$Progress = @{
    Activity         = 'Configuring Cloud' 
    Status           = 'Stage 1 Networking' 
    CurrentOperation = "Credssp" 
    PercentComplete  = ( 0 )
    ParentID         = 1
} 

function UpdateProgress {
    Param(
    [string] 
    $Activity, 
    [string] 
    $Status, 
    [string]
    $CurrentOperation, 
    [uint32]$PercentComplete
    )
    $PsboundParameters.GetEnumerator() | % { $Script:Progress[$_.key]= $_.value }
    write-progress @Progress
}

#
# Pre-requisites and assumptions
#  - Appropriate hardware is correctly configured, including server machines and connected shared storage. 
#  - Windows Server OS is installed, with properly configured NICs, and domain-joined on all participating nodes.
#  - Powershell remoting, execution polices, and Cred-SSP are enabled on all nodes.
#  - HyperV role is installed and machine rebooted if necessary on all HyperV nodes.
#  - MPIO installed and configured on file server nodes.
#  - storage is properly formatted


# Enable credssp for 'double hop' authentication. Cluster cmdlets, for instance, must pass credentials to other machines.
UpdateProgress

$setting.node | % {
        invoke-command -computername $_.name -ScriptBlock {
            Enable-WSManCredSSP -Role Server -force  | out-null
            Enable-WSManCredSSP -Role Client -DelegateComputer *.hcp.com -force  | out-null
            Enable-WSManCredSSP -Role Client -DelegateComputer * -force  | out-null
            } 
        } 

UpdateProgress -PercentComplete 10

#
# Step 1: Configure networks on each node for resiliency and throughput
#

$Jobs = @()
$setting.Node | % { $count = 0 } {
    $address =  $_.NetworkSetting.ConfigurationIPAddress
    UpdateProgress -CurrentOperation "Configuring network on node $($_.Name)... " 

    $Job = Invoke-Command -ComputerName $_.Name -FilePath .\Helper\ConfigureNetworking.ps1 -AsJob -ArgumentList @(
        $_.NetworkSetting['AdapterSetting'],
        $_.NetworkSetting['NicTeam'],
        $_.NetworkSetting['ThroughputSetting'],
        $_.NetworkSetting['InterfaceMetric']
    ) 
    
    UpdateProgress -CurrentOperation "Waiting for node $($_.Name)."  
    start-sleep -seconds 2

    do { ipconfig /flushdns | out-null } while ( -not (Test-Connection -Quiet -ComputerName  $Address -Delay 1) ) 
    
    $Count++
    $job|receive-job
    $Jobs += $job
    
    UpdateProgress -CurrentOperationNode "$($_.Name) back online." -PercentComplete ( ( ++$count/$setting.Node.count ) * 100 )
}

$SessionTable = New-PSSession  -Authentication 'CredSSP' -Credential $Credential -ComputerName ( 
        $Setting.Node | % { $_.name } ) | 
            group -AsHashTable -Property computername 

#
# Step 2: Configure HyperV Cluster
#

UpdateProgress -Status 'Stage 2 Hyper-V Cluster' -CurrentOperation ' ' -PercentComplete 0
$setting.Node | ? { $SessionTable[$_.Name] } | % { $Count = 0 } {
    
    UpdateProgress -CurrentOperation "Configuring Node: $($_.name)"   
    $cluster = Invoke-Command -Session $SessionTable[ $_.Name ] -FilePath .\Helper\ConfigureHyperVCluster.ps1 -ArgumentList @(
        $_.Cluster.Name, 
        $_.Cluster.StaticAddress, 
        $_.Cluster['IgnoreNetwork'],
        $_.Cluster['ClusterAccess'],
        $Null, 
        $_.Cluster['NetworkRoleSetting'] 
    )
          
    $Count++
    UpdateProgress -PercentComplete ( ( ++$count / $SessionTable.count ) * 100 )
}
 
#
# Step 3: Configure HyperV settings
#

UpdateProgress -Status 'Stage 3 HyperV settings' -PercentComplete 0 
$setting.Node | ? { $SessionTable[$_.Name] } | % { $Count = 0 } {
    $Update = @{
        Status           = 'Stage 3 HyperV settings'
        CurrentOperation = "Settings for node $($_.Name)" 
        PercentComplete  = 0 
        }
         
    UpdateProgress -CurrentOperation "Settings for node $($_.Name)"
    Invoke-Command  -Session $SessionTable[$_.Name] -FilePath .\Helper\ConfigureHyperVSettings.ps1 -ArgumentList @(
            $_.HyperVSetting['VirtualSwitch'],
            $_.HyperVSetting['DefaultVHDPath'],
            $_.HyperVSetting['DefaultVHDAccessPathParameter'],
            $_.HyperVSetting['DefaultVMPath'],
            $_.HyperVSetting['DefaultVMAccessPathParameter'] 
    )
    
         
        UpdateProgress -PercentComplete( ( ++$count/$SessionTable.count ) * 100 )
}
 
UpdateProgress -Activity 'Cloud Configured' -Status 'Complete' -CurrentOperation 'Done' -PercentComplete 100

$SessionTable  | %{ $_.values | Remove-PSSession }
$jobs | Remove-Job
 