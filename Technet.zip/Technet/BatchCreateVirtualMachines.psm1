﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -version 3

Import-Module Hyper-V

Function New-OSCVirtualMachine
{
<#
 	.SYNOPSIS
        New-OSCVirtualMachine is an advanced function which can be used to batch create virtual machines.
    .DESCRIPTION
        New-OSCVirtualMachine is an advanced function which can be used to batch create virtual machines.
    .PARAMETER  <CsvFilePath>
		Specifies the path you want to import VM configuration files.
    .EXAMPLE
        C:\PS> New-OSCVirtualMachine -CsvFilePath D:\VMConfigurations.csv
		
		This command will create one or more new virtual machines with configuration files.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true,Position=0)]
        [Alias("path")][String]$CsvFilePath
    )
	
	if(Test-Path -Path $CsvFilePath)
	{
	    $vmInfo = Import-Csv $CsvFilePath
	    foreach($vm in $vmInfo)
	    {
	        $VHDFolder = $vm.VHDFolder
	        $VHDName = $vm.VHDName
	        $VHDParentPath = $vm.VHDParentPath
	        $VMFolder = $vm.VMFolder
	        $VMName = $vm.VMName    
			$VMSwitchName = $vm.VMSwitchName
	        $MemoryStartupBytes = $vm.MemoryStartupBytes   
			
	        $VHDPath = Join-Path -Path $VHDFolder -ChildPath $VHDName
	        $VMPath = Join-Path -Path $VMFolder -ChildPath $VMName
			
			if(Test-Path -Path $VHDPath)
			{
	        	Write-Warning "$VHDPath already exists."
			}
			elseif(Test-Path -Path $VMPath)
			{
				Write-Warning "$VMPath already exists."
			}
			elseif(Test-Path -Path $VHDParentPath)
			{
				if($VMSwitchName -ne "")
				{                 
					$isExisted = Get-VMSwitch -Name $VMSwitchName -ErrorAction SilentlyContinue
					
					# if the value of $isExisted is $null, it means the virtual switch does not exist. 
					if($isExisted -eq $null) 
					{
						Write-Warning "Can not find virtual switch : $VMSwitchName, because the virtual switch does not exist."
					}
					else
					{
						#creates a virtual hard disk 
	        			New-VHD -Path $VHDPath -ParentPath $VHDParentPath -Differencing|Out-Null
	       
						#creates a virtual machine.
	        			New-VM -Path $VMFolder -Name $VMName -VHDPath $VHDPath -MemoryStartupBytes $(Invoke-Expression -Command $MemoryStartupBytes)|Out-Null
						
						#connects a virtual network adapter to a virtual switch
						Connect-VMNetworkAdapter -VMName $VMName -SwitchName $VMSwitchName
					}
				}
				else
				{
					#if the value of $VMSwitchName is $null, it means user do not want to configure the virtual switch.
					#creates a virtual hard disk 
	    			New-VHD -Path $VHDPath -ParentPath $VHDParentPath -Differencing|Out-Null
	   
					#creates a virtual machine.
	    			New-VM -Path $VMFolder -Name $VMName -VHDPath $VHDPath -MemoryStartupBytes $(Invoke-Expression -Command $MemoryStartupBytes)|Out-Null
				}
				
				#gets the reporting results
				Get-VM -Name $VMName -ErrorAction "SilentlyContinue"|Select-Object Name,State,Status, `
				@{Label="Creation State";Expression={if(Get-VM -Name $VMName)
														{"Create Successful"}
														else
														{"Create Failed"}}}
			}
			else
			{
				Write-Warning "Cannot find path '$VHDParentPath' because it does not exist, plese input the correct path."
			}
	    }
	}
	else
	{
		Write-Warning "Cannot find path '$CsvFilePath' because it does not exist, plese input the correct path."
	}
}
