﻿<####################################################################
# 																	
# Author       : Bhavik Solanki										
# Date         : 10th March 2012									
# Version      : 1.0												
# Desctiption  : This utility will help to monitor web applications.
#																	
#####################################################################>

#Update following variables before you run this script.
$EmailFrom = "emailfrom@example.com"
$EmailTo = "emailto@example.com"
$SMTPServer = "SMTPServer"
$EmailSubject = "URL Monitoring Result" 
$URLListFile = "D:\URLList.txt" 

#Takes URL list as input from text file
$URLList = Get-Content $URLListFile -ErrorAction SilentlyContinue

if($URLList -ne $null)
{
    $Result = @()
    Foreach($Url in $URLList)
    {
        #Create web request
		$Request = [System.Net.WebRequest]::Create($Url); 
        $Request.UseDefaultCredentials = $true
        $Request.Proxy.Credentials = $Request.Credentials        
		#Uncommnet following line and provide appropriave value (in milisecond) if require
		#$Request.TimeOut = 60000
		$Response = $Request.GetResponse();

        #Based on Response prepare Result set
		if($Response -eq $null)
        {
            $Result += New-Object PSObject -Property @{
                URL = $Url
                Status = 'Failed'
            }
        }
        else
        {
            $Result += New-Object PSObject -Property @{
                URL = $Url
                Status = $Response.StatusCode
            }
        }
		$Response = $null
    }
}
else
{
    Write-Host "File Not Found."
}

#Prepare email body in HTML format
if($Result -ne $null)
{
    $EmailBody = "<HTML><BODY><Table border=1 cellpadding=0 cellspacing=0><TR bgcolor=gray align=center><TD><B>URL</B></TD><TD><B>Status</B></TD></TR>"
    Foreach($Entry in $Result)
    {
        if($Entry.Status -ne "OK")
        {
            $EmailBody += "<TR bgcolor=red>"
        }
        else
        {
            $EmailBody += "<TR>"
        }
        $EmailBody += "<TD>$($Entry.URL)</TD><TD align=center>$($Entry.Status)</TD></TR>"
    }
    $EmailBody += "</Table></BODY></HTML>"
}

#Send mail with output
$mailmessage = New-Object system.net.mail.mailmessage 
$mailmessage.from = ($EmailFrom) 
$mailmessage.To.add($EmailTo)
$mailmessage.Subject = $EmailSubject
$mailmessage.Body = $EmailBody
$mailmessage.IsBodyHTML = $true
$SMTPClient = New-Object Net.Mail.SmtpClient($SmtpServer)  
$SMTPClient.Send($mailmessage)
