﻿Function my-function
{
 Param(
  [int]$a,
  [int]$b)
  "$a plus $b equals four"
}