﻿<#

Requires Active Directory Module from Microsoft
Author: http://twitter.com/alexanderangel

#>
$SearchOU = "OU=Scripting,OU=Groups,DC=lab,DC=lan"
$DestinationOU = "OU=Empty,OU=Groups,DC=lab,DC=lan"
$EmptyGroups = Get-ADGroup -filter * -Properties members,memberof -searchbase $SearchOU | where {!$_.members} | where {!$_.membersof}
foreach ($EmptyGroup in $EmptyGroups)
{
$DN = $EmptyGroup.DistinguishedName
Move-ADObject -Identity $DN -TargetPath $DestinationOU
}
