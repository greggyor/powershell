<# 

.SYNOPSIS 
----------------------------------------------------------------------------------
Set-SPDocumentLibraryFileBrowserHandling.ps1
Version: 1.0
Revision Date: September 19, 2011
--------------------------------------------------------------------------------- 
   
 Changes the SPDocumentLibrary.BrowserFileHandling property for all or specified 
 Document Libraries in a SPWeb, or if specified, recursively to all child SPWeb 
 objects under the specified SPWeb. Automatically produces a CSV report of changes
 made to SPDocumentLibrary objects in the excuting directory of the script.
  
.DESCRIPTION 
 Changes the SPDocumentLibrary.BrowserFileHandling property for all or specified 
 Document Libraries in a SPWeb, or if specified, recursively to all child SPWeb 
 objects under the specified SPWeb. Automatically produces a CSV report of changes
 made to SPDocumentLibrary objects in the excuting directory of the script. 
 
 In addition, using the -WhatIf script parameter, one can produce a report of 
 SPDocumentLibrary objects within a specified SPWeb (and recursively for child SPWeb 
 objects if specified) that have a specific SPDocumentLibrary.BrowserFileHandling property.
 
 The script can be configured to process all SPDocumentLibrary objects within an SPWeb,
 or one can explicitly specifiy the document library titles to target. If a specified
 document library title does not exist in the specified SPWeb, the script will ignore
 the document library title (this also works when used recursively)



.PARAMETER Url
     Indicates the URL of a SharePoint Web (SPWeb). THIS PARAMETER IS REQUIRED. 
     
     Example: -Url "http://mySharePointWebUrl"
    
 .PARAMETER BrowserFileHandlingTypeToChange 
     The text string representing the SPDocumentLibrary.BrowserFileHandling type you wish 
     to change within specified Document Libraries. THIS PARAMETER IS REQUIRED. 
     Valid values are "Permissive" and "Strict" only. Cannot be the same value as 
     the $browserFileHandlingTypeNewValue parameter.
     
     Example: -BrowserFileHandlingTypeToChange "Permissive"
     
 .Parameter BrowserFileHandlingTypeNewValue
     The text string representing the SPDocumentLibrary.BrowserFileHandling type you wish 
     to set for specified Document Libraries. THIS PARAMETER IS REQUIRED. 
     Valid values are "Permissive" and "Strict" only. Cannot be the same value as 
     the $browserFileHandlingTypeToChange parameter.
     
     Example: -BrowserFileHandlingTypeNewValue "Strict"
      
 .PARAMETER DocumentLibraryTitlesToTarget
     An array of specific Document Library Titles to target within the script.
     THIS PARAMETER IS OPTIONAL. If this parameter is not specified, all 
     non-hidden Document Libraries within a targeted SPWeb will be processed. 
     Even if this parameter is specified, Hidden Document Libraries will not be 
     targeted within this script.  
     
     Example: See full examples for an example.
     
 .PARAMETER Recursive 
     If this parameter is included, the script will recursively traverse all 
     child SPWeb objects of the specified SPWeb in the $url parameter. If this 
     parameter is omitted, the script will target only the SPWeb specified in the 
     $url parameter. THIS SWITCH PARAMETER IS OPTIONAL. THE DEFAULT IS NOT RECURSIVE.
     
     Example: -Recursive 
     
 .PARAMETER WhatIf 
     Describes what would happen if you executed the command to modify the 
     BrowserFileHandling of specified document libraries without actually executing 
     the Update() command against any document libraries. A WhatIf CSV report will be 
     generated if the for you to review to analyze what would happen if the script
     fully executed.
     
     Example: -WhatIf



.Notes
This script assumes that you use the SharePoint 2010 Management Shell to execute the script 
and is not intended to be executed as a Windows Scheduled Task.

It can be executed against the following SharePoint versions: 
  - Microsoft SharePoint Foundation 2010 
  - Microsoft SharePoint Server 2010 - for all SKUs 
      
Windows SharePoint Services 3.0 and Microsoft SharePoint 
Server 2007 are not supported as they do not utilize the property 
(SPDocuentLibrary.BrowserFileHandling) that is targeted in this script.
       
 REQUIRED: the account executing this script must have the following permissions: 
      - Must have the SHAREPOINT_SHELL_ACCESS role via the Add-SPShellAdmin CMDLET 
        for the content database within which the targeted SPWeb (script $url parameter) 
        resides
      - Full Control of the directory where the script is stored on the server 

        
.EXAMPLE  
.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive"

This command will change the SPDocumentLibrary.BrowserFileHandling property 
from "Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url.

A CSV report with file name ChangeReport.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of all
changes made by the script.


.EXAMPLE
.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -Recursive

This command will change the SPDocumentLibrary.BrowserFileHandling property 
from "Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url and for all non-hidden Document Libraries in
all child SPWeb objects specified by -Url.

A CSV report with file name ChangeReport.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of all
changes made by the script.

.EXAMPLE  
.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -WhatIf

This command describes what would happen to the 
SPDocumentLibrary.BrowserFileHandling property if it were changed from 
"Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url. 

A CSV report with file name WhatIf.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of what
would happen if the script was executed without the -WhatIf parameter.

.EXAMPLE  
.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -Recursive 
    -WhatIf

This command describes what would happen to the 
SPDocumentLibrary.BrowserFileHandling property if it were changed from 
"Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url and for all non-hidden Document Libraries in
all child SPWeb objects specified by -Url.

A CSV report with file name WhatIf.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of what
would happen if the script was executed without the -WhatIf parameter.

.EXAMPLE  
[string[]]$documentLibraryTitlesToTarget = "Documents", "MyCustomTitle"

.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -DocumentLibraryTitlesToTarget $documentLibraryTitlesToTarget
     
This command will change the SPDocumentLibrary.BrowserFileHandling property 
from "Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url that are titled "Documents" and "MyCustomTitle" 
(if they exist.)

A CSV report with file name ChangeReport.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of all
changes made by the script.

.EXAMPLE   
[string[]]$documentLibraryTitlesToTarget = "Documents", "MyCustomTitle"

.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -DocumentLibraryTitlesToTarget $documentLibraryTitlesToTarget
    -Recursive
     
This command will change the SPDocumentLibrary.BrowserFileHandling property 
from "Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url that are titled "Documents" and
"MyCustomTitle" (if they exist), and for all non-hidden Document Libraries in
all child SPWeb objects specified by -Url that are titled "Documents" and
"MyCustomTitle" (if they exist).

A CSV report with file name ChangeReport.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of all
changes made by the script.

.EXAMPLE  
[string[]]$documentLibraryTitlesToTarget = "Documents", "MyCustomTitle"

.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -DocumentLibraryTitlesToTarget $documentLibraryTitlesToTarget
    -WhatIf
     
This command describes what would happen to the 
SPDocumentLibrary.BrowserFileHandling property if it were changed from 
"Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url that are titled "Documents" and "MyCustomTitle" 
(if they exist).

A CSV report with file name WhatIf.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of what
would happen if the script was executed without the -WhatIf parameter.

.EXAMPLE  
[string[]]$documentLibraryTitlesToTarget = "Documents", "MyCustomTitle"

.\Set-SPDocumentLibraryBrowserFileHandling.ps1 
    -Url "http://mySharePointWebUrl"
    -BrowserFileHandlingTypeToChange "Strict" 
    -BrowserFileHandlingTypeNewValue "Permissive" 
    -DocumentLibraryTitlesToTarget $documentLibraryTitlesToTarget
    -Recursive
    -WhatIf
     
This command describes what would happen to the 
SPDocumentLibrary.BrowserFileHandling property if it were changed from 
"Strict" to "Permissive" for all non-hidden Document Libraries within
the SPWeb specified by -Url that are titled "Documents" and "MyCustomTitle" 
(if they exist),  and for all non-hidden Document Libraries in
all child SPWeb objects specified by -Url that are titled "Documents" and
"MyCustomTitle" (if they exist).

A CSV report with file name WhatIf.csv will automatically be generated
in the same folder where the ModifiyDocLibBrowserFileHandling.ps1 script
is stored on the SharePoint Server. This report is a complete record of what
would happen if the script was executed without the -WhatIf parameter.


.LINK
Blog: http://craiglussier.com 
Facebook: http://craiglussier.me        
Twitter: http://craiglussier.info
MSDN Profile: http://social.msdn.microsoft.com/profile/craig%20lussier/

#> 


#===================
#   Parameters
#===================
param(

 [parameter(Mandatory=$true, HelpMessage="The url parameter is required. Please enter the url for a SharePoint 2010 Site Collection or Web.")]
 [string]
 $Url 
 , 
 
 [ValidateSet("Permissive","Strict")]
 [parameter(Mandatory=$true, HelpMessage="The handlingTypeToChange parameter is required. Please specify either 'Permissive' or 'Strict' as your parameter.")]
 [string]
 $BrowserFileHandlingTypeToChange = $(Throw "the handlingTypeToChange parameter is required.")
 ,  
 
 [ValidateSet("Permissive","Strict")]
 [parameter(Mandatory=$true, HelpMessage="The handlingTypeNewValue parameter is required. Please specify either 'Permissive' or 'Strict' as your parameter.")]
 [string]
 $BrowserFileHandlingTypeNewValue = $(Throw "the handlingTypeNewValue parameter is required.")
 , 
 
 [string[]]
 $DocumentLibraryTitlesToTarget=$null
 , 
 
 [switch]
 $Recursive
 ,
 
 [switch]
 $Whatif
) 
# END Parameters 
 
 
#=================================================================
# Initial Parameter checks 
#
# Ensure conditions regarding parameters and create some new ones
#=================================================================
 
# Determine if the SPWeb url exists in SharePoint - if not exit script processing
$urlExists = Get-SPWeb $url -ErrorAction SilentlyContinue | Select Exists -ErrorAction SilentlyContinue
if(!$urlExists.exists) {
 ""
 "The SharePoint SPWeb Url provided does not exist."
 "This script will now stop executing."
 ""
 exit
}


# Ensure that $handlingTypeToChange is not equal to $handlingTypeNewValue - if it is, stop the script
if($browserFileHandlingTypeToChange -eq $browserFileHandlingTypeNewValue) {
 ""
 "The 'handlingTypeToChange' and 'handlingTypeNewValue' parameters must be different."
 "This script will now stop executing."
 ""
 exit
}


# Determine if this script should process SubWebs recursively - create new script scoped variable to store bool value
$script:recursiveSubWebs = $false
if($Recursive.IsPresent) {
 $script:recursivesubwebs = $true
}

# Determine if this sscript should be run in WhatIf mode - create new script scoped variable to store the bool value
$script:reportOnly=$false
if($Whatif.IsPresent) {
 $script:reportOnly = $true
}


# Create a script scoped array variable. This will hold a collection of custom PSObject objects that are produced while 
# the script executes against targeted document libraries. This array is used to create a CSV report at the end of the script.
$script:reportObjectCollection = @()
 
 
  
# Create a script scoped variable to store the DocumentLibrary type
$script:documentLibraryType = [Microsoft.SharePoint.SPBaseType]::DocumentLibrary


# Create two script scoped variables to hold the types of BrowserFileHandling as specified in the scrit parameters 
$script:targetBrowserFileHandlingToChange = Invoke-Expression '[Microsoft.SharePoint.SPBrowserFileHandling]::$BrowserFileHandlingTypeToChange'
$script:targetBrowserFileHandlingChangeTo = Invoke-Expression '[Microsoft.SharePoint.SPBrowserFileHandling]::$BrowserFileHandlingTypeNewValue'
 
 
# END INITIAL PARAMETER CHECKS 
 
 
 
 
 
# The Process-BrowserFileHandling function makes changes to the SPDocumentLibrary.BrowserFileHandling property
# for specific document libraries in specified SPWeb objects as per script scoped parameters
function Process-BrowserFileHandling($web) {
 
    # Output Message: the current web being processed
    ""
    "====================================================================="
    "Processing Web:" + $web.Title 
    $web.url
    "====================================================================="
  
    # Output Message
    "Determining Document Library Collection to process..." 
    
    # Get only SPWeb Document Libraries that are not Hidden.
    # Note: This will be equal to the listing of Document Libraries when you look at the 'All Site Content' of an SPWeb
    $documentLibrariesInitialFilter = $web.Lists | where { $_.BaseType -eq $script:documentLibraryType -and $_.Hidden -eq $false }


    #Create Array collection variable to hold document libraries to process within this SPWeb
    $documentLibraries = @()
 
    # If target document library titles were specified in the [string[]]$documentLibraryTitlesToTarget script parameter, 
    # create where a clause to filter the $documentLibrariesInitialFilter array and set the local function variable $documentLibraries 
    # to contain the specified target document libraries
    # Note: regardless of the Document Library titles in the [string[]]$documentLibraryTitlesToTarget script parameter, the resultent $documentLibraries 
    # array of SPDocumentLibrary objects will only contain Document Libraries that exist in the current SPWeb.
    if($script:DocumentLibraryTitlesToTarget -ne $null) {

        # Create WhereClause variable
        $whereClause = "";
        
        # Loop through each of the $documentLibraryTitlesToTarget and dynamically create a Where clause
        # filter Document Libraries within the current SPWeb. Depending on what input was sent to the script
        # the final collection could contain no Document Libraries if they do not exist in the SPWeb
        $count=$script:documentLibraryTitlesToTarget.count;
        $counter=1;
        foreach ($lib in $script:documentLibraryTitlesToTarget) {
           if($counter -ne $count) {
               $whereClause += '$_.Title -eq "' + $lib + '" -or '
           }
           else {
               $whereClause += '$_.Title -eq "' + $lib + '"'
           } 
          
           $counter++
        }
     
        # Create actual where filter command that will be executed against the $documentLibrariesInitialFilter
        # to futher refine the Document Libraries to be targeted
        $command = '$documentLibrariesInitialFilter | where {' + $whereClause + '}'
     
        # The final array of SPDocumentLibrary objects against which to process 
        $documentLibraries = Invoke-Expression $command
        
        # Output Message
        "-Specified Document Libraries, if they exist, within this Web will be processed..."
        ""

    }    
    # If the the [string[]]$documentLibraryTitlesToTarget script parameter was omitted,  
    # Set the $documentLibraries array to equal $documentLibraryTitlesToTarget, in other words
    # process all document libraries in the SPWeb that are not hidden libraries.
    else { 
     $documentLibraries = $documentLibrariesInitialFilter
     
     # Output Message
     "-All Document Libraries within this Web will be processed..."
     ""
    } # END OF $DOCUMENTLIBRARYTITLESTOTARGET IF CHECK
 
 
    # Create local function scoped array to store $reportObject objects
    # The reportObject is a custom PSObject (see below) that stores information
    # regarding the current document library being processed
    $localReportObjectCollection = @()
    
    # If the filtered $documentLibraries array contains one or more SPDocumentLibrary
    if($documentLibraries -ne $null) {
    
        # Output Message
        ""
        "Processing the following Document Libraries:"
        "--------------------------------------------"
    
        # Loop through each Document Library in the filtered array $documentLibraries 
        foreach($documentLibrary in $documentLibraries) {
         
             # If the Document library BrowserFileHandling currently is specified to change you want to change 
             # Note: if the document library BrowserFileHandling is the opposite, it will not process as it does not need to.
             if($documentLibrary.BrowserFileHandling -eq $targetBrowserFileHandlingToChange) {
             
                # Create custom PSObject to store Document Library report data
                $reportObject = New-Object PSObject -Property @{
                    webUrl = ""
                    webTitle = ""
                    listTitle = ""
                    listUrl = ""
                    browserFileHandlingCurrent = ""
                    browserFileHandlingChangedTo = ""
                }

                 # Output Message
                 "-" + $documentLibrary.Title
                 
                 # Populate the reportObject for this Document Library
                 $reportObject = $reportObject
                 $reportObject.webUrl = $documentLibrary.ParentWeb.Url
                 $reportObject.webTitle = $documentLibrary.ParentWeb.Title
                 $reportObject.listTitle = $documentLibrary.Title
                 $reportObject.listUrl = $documentLibrary.ParentWeb.Url + "/" + $documentLibrary.RootFolder.Url
                 $reportObject.browserFileHandlingCurrent = $documentLibrary.BrowserFileHandling
                 
                 # Note: this will only take place when the WhatIf parameter is omitted from callng the script
                 $reportObject.browserFileHandlingChangedTo = $targetBrowserFileHandlingChangeTo
          
          
          
                 # This gets fired when the script WhatIf parameter is omitted
                 # This will commit the actual change to the Document Library BrowserFileHandling property
                 if(!$reportOnly) {
                       $documentLibrary.BrowserFileHandling = $targetBrowserFileHandlingChangeTo
                       $documentLibrary.Update()

                 }
                  
                 # Add the current Document Library $reportObject to the function scoped $localReportObjectCollection array 
                 $localReportObjectCollection += $reportObject
          
          
            } # END OF IF $DOCUMENTLIBRARY.BROWSERFILEHANDLING -EQ $TARGETBROWSERFILEHANDLINGTOCHANGE
            
        } # END FOREACH $DOCUMENTLIBRARY IN $DOCUMENTLIBRARIES

    } # END OF IF $DOCUMENTLIBRARIES -NE $NULL

    # Output Message
    ""
    "Number of processed Libraries: " + $localReportObjectCollection.count
    
    # Add the $localReportObjectCollection to the script scoped array $script:reportObjectCollection
    $script:reportObjectCollection += $localReportObjectCollection
 
} # END PROCESS-BROWSERFILEHANDLING FUNCTION
 
 
# The Process-ScriptBlockWrapper function is available to wrap a script block and ensures that 
# disposable objects are disposed at runtime. Please note that all objects are automatically
# disposed after the SharePoint 2010 Management Shell is closed.
function Process-ScriptBlockWrapper([ScriptBlock]$block) {
    
    # Create SPAssignnment
    $webdisposal = Start-SPAssignment
    
    # Execute the specified ScriptBlock
    $webdisposal | & $block
    
    # Stop the SPAssignment (i.e. dispose)
    $webdisposal | Stop-SPAssignment
    
} # END PROCESS-SCRIPTBLOCKWRAPPER FUNCTION



# The Process-SPWeb function is a wrapper function around calling the Process-BrowserFileHandling function.
# It provides functionalty for recursive child web calls provides for automatic disposal of child SPWeb calls.
function Process-SPWeb([Microsoft.SharePoint.SPWeb]$myWeb) {

    # Utilize a ScriptBlock Wrapper function to ensure SPWeb object are disposed of during runtime
    Process-ScriptBlockWrapper {
        
        # Call the ProcessHandling function for the specified web in the script scoped $url parameter
        Process-BrowserFileHandling($myweb)
        
        # If the -recursive script scoped parameter was specified, recursively traverse all sub-webs 
        # of all webs and subwebs below the SPWeb specified in the script scoped $url parameter 
        if($recursiveSubWebs) {
        
            # Loop through all SPWebs in the SPWeb.Webs property for the SPWeb specified in the script scoped $url parameter
            foreach($web in $myWeb.Webs) {  
                
                # Make the recursive function call to ProcessSPWeb  
                Process-SPWeb($web)
                
            } # END FOREACH WEB IN $MYWEB.WEBS
            
        } # END IF RECURSIVE 
        
    } # END SCRIPTBLOCK WRAPPER
    
} # END PROCESS-SPWEB FUNCTION
 
 
 
 
 
 
 
#==================================================
#          Main Procedural Script
#==================================================
$initialwebscope = Start-SPAssignment
$web = $initialwebscope | get-spweb $Url 
Process-SPWeb($web)
$initialwebscope | Stop-SPAssignment

# Output Message 
""
"--------------------------------------------------------------------------"

# Get the local directory within which this script is running
$Invocation = (Get-Variable MyInvocation -Scope 0).Value 
$dir = Split-Path $Invocation.MyCommand.Path 

# If the WhatIf script scoped parameter was used
if($reportOnly) {

    # Determine file path for WhatIf.csv report
    $reportFile = $dir + "\" + "WhatIf.csv"
    
    # Create WhatIfReport csv
    $script:reportObjectCollection | select webUrl, webTitle, listTitle, listUrl, browserFileHandlingCurrent, browserFileHandlingChangeTo | export-csv $reportFile -notypeinformation
    
    # Output Message
    "WhatIf.csv has been written to " + $dir + " for you to examine what changes would be made should you choose to run this and apply the BrowserFileHandling changes."
}
# If the WhatIf script scoped parameter was not used - live changes were made
else {

    # Determine file path for ChangeReport.csv report
    $reportFile = $dir + "\" + "ChangeReport.csv"
    
    # Create ChangeReport csv
    $script:reportObjectCollection | select webUrl, webTitle, listTitle, listUrl, browserFileHandlingCurrent, browserFileHandlingChangeTo | export-csv $reportFile -notypeinformation
    
    # Output Message
    "ChangeReport.csv has been written to " + $dir + " for your records."
}

# Output Message
"--------------------------------------------------------------------------"
""
 
 

