#
# Get-OABSizes.ps1
# Fetches the total file size of each copy of each offline address book
#
# Steve Goodman
#

# Retrieve all OABs
$OABs = Get-OfflineAddressBook 
 # Cycle through each OAB
foreach ($OAB in $OABs)
{
    # Cycle through each OAB Virtual Directory for the current OAB
    foreach ($OABVirtualDirectory in $OAB.VirtualDirectories)
    {
        # Get the actual OAB Virtual Directory properties
        $OABVirtualDirectory = Get-OabVirtualDirectory -Identity $OABVirtualDirectory;
        # Retrieve the folder local to the CAS that hosts the OAB, and append the Guid of this OAB
        $LocalOABPath = "$($OABVirtualDirectory.Path)\$($OAB.Guid)";
        # Get the UNC path used to get to the hidden C$ share on the CAS
        $BaseUNCPath = "\\$($OABVirtualDirectory.Server)\C$";
        # Replace the local path with the UNC path to the CAS server
        $UNCOABPath = $LocalOABPath.Replace("C:",$BaseUNCPath);
        # Get the directory listing of the folder hosting the OAB
        $OABItems = Get-ChildItem -Path $UNCOABPath
        # Calculate the total size of the folder hosting the OAB, in bytes
        [int]$TotalBytes = ($OABItems | Measure-Object -Property Length -Sum).Sum;
        # Convert the total size in bytes to kilobytes
        [int]$TotalKBytes = $TotalBytes/1024;
        # Build the output object for this copy of the OAB and output it
        $Output = New-Object Object
        $Output | Add-Member NoteProperty Server $OABVirtualDirectory.Server;
        $Output | Add-Member NoteProperty Name $OABVirtualDirectory.Name;
        $Output | Add-Member NoteProperty OABName $OAB.Name;
        $Output | Add-Member NoteProperty OABSizeKB $TotalKBytes;
        $Output
    }
}