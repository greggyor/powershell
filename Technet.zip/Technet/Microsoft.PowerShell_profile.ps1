$speak = new-object -com 'sapi.spvoice'
Import-Module jh-weather

Function get-christmas {
$time=([datetime]'12/25/2011'-(get-date)).ToString().Substring(0,11)
$text="[**Christmas in $($time)**]"
$text.tocharArray() |foreach {
if ((Get-Random -min 1 -max 10) -gt 5) {
 $color="RED"
 }
else {
 $color="GREEN"
}
write-host $_ -nonewline -foregroundcolor $color
}
} #end function

Function get-chanukah {
$time=([datetime]'12/20/2011 18:00'-(get-date)).ToString().Substring(0,11)
$text="[**Chanukah in $($time)**]"
$text.tocharArray() |foreach {
if ((Get-Random -min 1 -max 10) -gt 5) {
$color="Yellow"
}
else {
$color="GREEN"
}
write-host $_ -nonewline -foregroundcolor $color
}
} #end function


Function god-mode {
$computername = $env:computername.tolower()
$a = (get-host).UI.RawUI
$a.WindowTitle = "Admin Mode: Active! Welcome to Powershell God Mode."
$a.BackgroundColor = "Black"
$a.ForegroundColor = "White"
cls
hello
write-host "Your Qoute of the day"
$q = get-qotd
write-host "$q`n" -foregroundcolor DarkGreen
$speak.speak($q)
gw 12773399 -extended
} #end function

function get-pro { notepad $profile }
write-host "$q`n" -foregroundcolor Yellow
function hello {
$talk = new-object -com 'sapi.spvoice'
$text = "Hello $env:username, My name is $computername"
$talk.speak($text)
$text
write-host ""
}

Function Get-QOTD {

   [cmdletBinding()]

   Param()

   Write-Verbose "Starting Get-QOTD"
   #create the webclient object
   $webclient = New-Object System.Net.WebClient

   #define the url to connect to
   $url="http://feeds.feedburner.com/brainyquote/QUOTEBR"

   Write-Verbose "Connecting to $url"
   Try
   {
       #retrieve the url and save results to an XML document
       [xml]$data =$webclient.downloadstring($url)
       #parse out the XML document to get the first item which
       #will be the most recent quote
       $quote=$data.rss.channel.item[0]
   }
   Catch
   {
       $msg="There was an error connecting to $url"
       $msg+=$_.Exception.Message
       Write-Warning $msg
   }

   if ($quote)
   {
       Write-Verbose $quote.OrigLink
       "{0} - {1}" -f $quote.Description,$quote.Title 
   }
   else
   {
       Write-Warning "Failed to get data from $url"
   }

   Write-Verbose "Ending Get-QOTD"
   write-host ""

} #end function

god-mode