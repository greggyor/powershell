[void][System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic')
[void][microsoft.visualbasic.interaction]::MsgBox(�In AD 2101�)
[void][microsoft.visualbasic.interaction]::MsgBox(�War Was Beginning�)
[void][microsoft.visualbasic.interaction]::MsgBox(�What Happen ?�)
[void][microsoft.visualbasic.interaction]::MsgBox(�Somebody set up us the bomb.�)
[void][microsoft.visualbasic.interaction]::MsgBox(�We get Signal�)
[void][microsoft.visualbasic.interaction]::MsgBox(�What!�)
[void][microsoft.visualbasic.interaction]::MsgBox(�Main Screen Turn On�)
[void][microsoft.visualbasic.interaction]::MsgBox(�It's You!!�)
[void][microsoft.visualbasic.interaction]::MsgBox(�How are you Gentlemen!!�)
[void][microsoft.visualbasic.interaction]::MsgBox(�All Your Base Are Belong To Us.�)
[void][microsoft.visualbasic.interaction]::MsgBox(�You are on the way to destruction�)
[void][microsoft.visualbasic.interaction]::MsgBox(�What you say!!�)
[void][microsoft.visualbasic.interaction]::MsgBox(�You have no Chance to Survive make your time.�)
[void][microsoft.visualbasic.interaction]::MsgBox(�HA HA HA HA !!!! �)
[void][microsoft.visualbasic.interaction]::MsgBox(�All Your Base Are Belong To Us.�)



$i = 1
do{
$i++
$result = [Microsoft.VisualBasic.Interaction]::MsgBox("All your base are belong to us! You are on the way to destruction. You have no chance to survive make your time",'YesNoCancel,Question',"how are you gentleman")

switch ($result) {
  'Yes'		{ "Somebody set up us the bomb." }
  'No'		{ "Main screen turn on." }
  'Cancel'	{ "For great justice." }
}
}
until ($i -gt 3)

do{(new-object -com wscript.shell).run("http://chroniclesofgeorge.nanc.com/base.swf",4);$i++}
until ($i -gt 4)