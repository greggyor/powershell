﻿
	<#
	 				"SatNaam WaheGuru"
						
					Author  :  Aman Dhally
					E-Mail  :  amandhally@gmail.com
					website :  www.amandhally.net
					twitter : https://twitter.com/#!/AmanDhally
					facebook: http://www.facebook.com/groups/254997707860848/
					Linkedin: http://www.linkedin.com/profile/view?id=23651495
	
					More Info: 
	#>
	
	"`n"
	Write-Host " While you are alive, conquer death, and you shall have no regrets in the end. - Sri Guru Granth Sahib Ji " -ForegroundColor 'Yellow'
	"`n"


#----------------------------------------------
#region Application Functions
#----------------------------------------------

function OnApplicationLoad {
	#Note: This function is not called in Projects
	#Note: This function runs before the form is created
	#Note: To get the script directory in the Packager use: Split-Path $hostinvocation.MyCommand.path
	#Note: To get the console output in the Packager (Windows Mode) use: $ConsoleOutput (Type: System.Collections.ArrayList)
	#Important: Form controls cannot be accessed in this function
	#TODO: Add snapins and custom code to validate the application load
	
	return $true #return true for success or false for failure
}

function OnApplicationExit {
	#Note: This function is not called in Projects
	#Note: This function runs after the form is closed
	#TODO: Add custom code to clean up and unload snapins when the application exits
	
	$script:ExitCode = 0 #Set the exit code for the Packager
	
}

#endregion Application Functions

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Call-PIng_Network_Community_v2_pff {

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formPowershellNetworkPin = New-Object 'System.Windows.Forms.Form'
	$labelOutput = New-Object 'System.Windows.Forms.Label'
	$labelCreatedByAmanDhallyW = New-Object 'System.Windows.Forms.Label'
	$labelSubject = New-Object 'System.Windows.Forms.Label'
	$labelFrom = New-Object 'System.Windows.Forms.Label'
	$label1 = New-Object 'System.Windows.Forms.Label'
	$labelSMTPServer = New-Object 'System.Windows.Forms.Label'
	$textbox9 = New-Object 'System.Windows.Forms.TextBox'
	$textbox8 = New-Object 'System.Windows.Forms.TextBox'
	$textbox7 = New-Object 'System.Windows.Forms.TextBox'
	$textbox6 = New-Object 'System.Windows.Forms.TextBox'
	$buttonEMailOutput = New-Object 'System.Windows.Forms.Button'
	$richtextbox1 = New-Object 'System.Windows.Forms.RichTextBox'
	$buttonRun = New-Object 'System.Windows.Forms.Button'
	$textbox5 = New-Object 'System.Windows.Forms.TextBox'
	$labelTo = New-Object 'System.Windows.Forms.Label'
	$textbox4 = New-Object 'System.Windows.Forms.TextBox'
	$textbox3 = New-Object 'System.Windows.Forms.TextBox'
	$textbox2 = New-Object 'System.Windows.Forms.TextBox'
	$textbox1 = New-Object 'System.Windows.Forms.TextBox'
	$labelIPAddressRange = New-Object 'System.Windows.Forms.Label'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------

	
	
	
	
	
	
	$formPowershellNetworkPin_Load={
		#TODO: Initialize Form Controls here
		
	}
	
	$textbox1.MaxLength=3
	$textbox2.MaxLength=3
	$textbox3.MaxLength=3
	$textbox4.MaxLength=3
	$textbox5.MaxLength=3
	
	
	$buttonRun_Click={
		
		#TODO: Place custom script here
		$richtextbox1.Clear()
		$result = @()
		$startip = $textbox1.Text + "." + $textbox2.Text +  "." + $textbox3.Text + "." + $textbox4.Text
		$ip = $textbox5.Text 
		
		foreach ($i in $startip) { 
		$last = $i.Split(".")
		[int]$lastip = $last[3]
		while ( $lastip -le $ip ) { 
		$result +=  $textbox1.Text + "." + $textbox2.Text +  "." + $textbox3.Text + "." +  $lastip++ } }	
		
		foreach ( $computer in $result ) {
		if (test-Connection -ComputerName $computer -Count 1 -Quiet ) {
			$richtextbox1.Text += " $computer is alive and Pinging." 
			$richtextbox1.Text += "`n"
			$formPowershellNetworkPin.Refresh()				
			} else 	{ 
			
			$richtextbox1.Text +=  " $computer seems dead and not Pinging." 
			$richtextbox1.Text += "`n"		
			$formPowershellNetworkPin.Refresh()	
			
			}
		
	 }
	}
	
	
	$buttonClear_Click={
		#TODO: Place custom script here
		
	}
	
	$buttonEMailOutput_Click={
		#TODO: Place custom script here
		$smtp = $textbox6.Text
		$to =   $textbox7.Text
		$from = $textbox8.Text
		$sub =  $textbox9.Text
		$body = $richtextbox1.Text
		Send-MailMessage -SmtpServer $smtp -From $from -To $to -Subject $sub -Body $body
	}
	
	$labelSMTPServer_Click={
		#TODO: Place custom script here
		
	}
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formPowershellNetworkPin.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$labelSMTPServer.remove_Click($labelSMTPServer_Click)
			$buttonEMailOutput.remove_Click($buttonEMailOutput_Click)
			$buttonRun.remove_Click($buttonRun_Click)
			$formPowershellNetworkPin.remove_Load($formPowershellNetworkPin_Load)
			$formPowershellNetworkPin.remove_Load($Form_StateCorrection_Load)
			$formPowershellNetworkPin.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	#
	# formPowershellNetworkPin
	#
	$formPowershellNetworkPin.Controls.Add($labelOutput)
	$formPowershellNetworkPin.Controls.Add($labelCreatedByAmanDhallyW)
	$formPowershellNetworkPin.Controls.Add($labelSubject)
	$formPowershellNetworkPin.Controls.Add($labelFrom)
	$formPowershellNetworkPin.Controls.Add($label1)
	$formPowershellNetworkPin.Controls.Add($labelSMTPServer)
	$formPowershellNetworkPin.Controls.Add($textbox9)
	$formPowershellNetworkPin.Controls.Add($textbox8)
	$formPowershellNetworkPin.Controls.Add($textbox7)
	$formPowershellNetworkPin.Controls.Add($textbox6)
	$formPowershellNetworkPin.Controls.Add($buttonEMailOutput)
	$formPowershellNetworkPin.Controls.Add($richtextbox1)
	$formPowershellNetworkPin.Controls.Add($buttonRun)
	$formPowershellNetworkPin.Controls.Add($textbox5)
	$formPowershellNetworkPin.Controls.Add($labelTo)
	$formPowershellNetworkPin.Controls.Add($textbox4)
	$formPowershellNetworkPin.Controls.Add($textbox3)
	$formPowershellNetworkPin.Controls.Add($textbox2)
	$formPowershellNetworkPin.Controls.Add($textbox1)
	$formPowershellNetworkPin.Controls.Add($labelIPAddressRange)
	$formPowershellNetworkPin.ClientSize = '363, 326'
	$formPowershellNetworkPin.FormBorderStyle = 'Fixed3D'
	$formPowershellNetworkPin.Name = "formPowershellNetworkPin"
	$formPowershellNetworkPin.Opacity = 0.95
	$formPowershellNetworkPin.StartPosition = 'CenterScreen'
	$formPowershellNetworkPin.Text = "Powershell - Network Pinger - Ajit V.1"
	$formPowershellNetworkPin.add_Load($formPowershellNetworkPin_Load)
	#
	# labelOutput
	#
	$labelOutput.Location = '12, 44'
	$labelOutput.Name = "labelOutput"
	$labelOutput.Size = '65, 16'
	$labelOutput.TabIndex = 21
	$labelOutput.Text = "Output |"
	#
	# labelCreatedByAmanDhallyW
	#
	$labelCreatedByAmanDhallyW.Location = '217, 294'
	$labelCreatedByAmanDhallyW.Name = "labelCreatedByAmanDhallyW"
	$labelCreatedByAmanDhallyW.Size = '146, 33'
	$labelCreatedByAmanDhallyW.TabIndex = 20
	$labelCreatedByAmanDhallyW.Text = "Created by: Aman Dhally
      www.amandhally.net
"
	#
	# labelSubject
	#
	$labelSubject.Location = '123, 237'
	$labelSubject.Name = "labelSubject"
	$labelSubject.Size = '100, 20'
	$labelSubject.TabIndex = 18
	$labelSubject.Text = "Subject"
	#
	# labelFrom
	#
	$labelFrom.Location = '17, 238'
	$labelFrom.Name = "labelFrom"
	$labelFrom.Size = '100, 19'
	$labelFrom.TabIndex = 17
	$labelFrom.Text = "From"
	#
	# label1
	#
	$label1.Location = '123, 188'
	$label1.Name = "label1"
	$label1.Size = '92, 23'
	$label1.TabIndex = 16
	$label1.Text = "To"
	#
	# labelSMTPServer
	#
	$labelSMTPServer.Location = '17, 188'
	$labelSMTPServer.Name = "labelSMTPServer"
	$labelSMTPServer.Size = '76, 23'
	$labelSMTPServer.TabIndex = 15
	$labelSMTPServer.Text = "SMTP Server"
	$labelSMTPServer.add_Click($labelSMTPServer_Click)
	#
	# textbox9
	#
	$textbox9.Location = '123, 260'
	$textbox9.Name = "textbox9"
	$textbox9.Size = '100, 20'
	$textbox9.TabIndex = 14
	#
	# textbox8
	#
	$textbox8.Location = '12, 260'
	$textbox8.Name = "textbox8"
	$textbox8.Size = '103, 20'
	$textbox8.TabIndex = 13
	#
	# textbox7
	#
	$textbox7.Location = '123, 214'
	$textbox7.Name = "textbox7"
	$textbox7.Size = '100, 20'
	$textbox7.TabIndex = 12
	#
	# textbox6
	#
	$textbox6.Location = '12, 214'
	$textbox6.Name = "textbox6"
	$textbox6.Size = '103, 20'
	$textbox6.TabIndex = 11
	#
	# buttonEMailOutput
	#
	$buttonEMailOutput.Location = '237, 232'
	$buttonEMailOutput.Name = "buttonEMailOutput"
	$buttonEMailOutput.Size = '102, 23'
	$buttonEMailOutput.TabIndex = 10
	$buttonEMailOutput.Text = "E-Mail Output"
	$buttonEMailOutput.UseVisualStyleBackColor = $True
	$buttonEMailOutput.add_Click($buttonEMailOutput_Click)
	#
	# richtextbox1
	#
	$richtextbox1.Location = '12, 63'
	$richtextbox1.Name = "richtextbox1"
	$richtextbox1.Size = '327, 101'
	$richtextbox1.TabIndex = 8
	$richtextbox1.Text = ""
	#
	# buttonRun
	#
	$buttonRun.Location = '284, 170'
	$buttonRun.Name = "buttonRun"
	$buttonRun.Size = '55, 23'
	$buttonRun.TabIndex = 7
	$buttonRun.Text = "Run"
	$buttonRun.UseVisualStyleBackColor = $True
	$buttonRun.add_Click($buttonRun_Click)
	#
	# textbox5
	#
	$textbox5.Location = '303, 21'
	$textbox5.Name = "textbox5"
	$textbox5.Size = '28, 20'
	$textbox5.TabIndex = 6
	#
	# labelTo
	#
	$labelTo.Location = '263, 23'
	$labelTo.Name = "labelTo"
	$labelTo.Size = '100, 23'
	$labelTo.TabIndex = 5
	$labelTo.Text = "-- to --"
	#
	# textbox4
	#
	$textbox4.Location = '228, 21'
	$textbox4.Name = "textbox4"
	$textbox4.Size = '27, 20'
	$textbox4.TabIndex = 4
	#
	# textbox3
	#
	$textbox3.Location = '192, 21'
	$textbox3.Name = "textbox3"
	$textbox3.Size = '27, 20'
	$textbox3.TabIndex = 3
	#
	# textbox2
	#
	$textbox2.Location = '157, 21'
	$textbox2.Name = "textbox2"
	$textbox2.Size = '27, 20'
	$textbox2.TabIndex = 2
	#
	# textbox1
	#
	$textbox1.Location = '123, 21'
	$textbox1.Name = "textbox1"
	$textbox1.Size = '27, 20'
	$textbox1.TabIndex = 1
	#
	# labelIPAddressRange
	#
	$labelIPAddressRange.Location = '15, 21'
	$labelIPAddressRange.Name = "labelIPAddressRange"
	$labelIPAddressRange.Size = '112, 23'
	$labelIPAddressRange.TabIndex = 0
	$labelIPAddressRange.Text = "IP-Address Range :"
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formPowershellNetworkPin.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formPowershellNetworkPin.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formPowershellNetworkPin.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formPowershellNetworkPin.ShowDialog()

} #End Function

#Call OnApplicationLoad to initialize
if((OnApplicationLoad) -eq $true)
{
	#Call the form
	Call-PIng_Network_Community_v2_pff | Out-Null
	#Perform cleanup
	OnApplicationExit
}
