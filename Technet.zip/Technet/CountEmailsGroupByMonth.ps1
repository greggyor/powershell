﻿#$MailboxName = "nuno.mota@letsexchange.com" 
$hashTableNumber = @{} 
$hashTableSize = @{} 
 
$dllpath = "C:\Program Files\Microsoft\Exchange\Web Services\1.0\Microsoft.Exchange.WebServices.dll" 
[void][Reflection.Assembly]::LoadFile($dllpath) 
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2007_SP1) 
 
$windowsIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent() 
$sidbind = "LDAP://<SID=" + $windowsIdentity.user.Value.ToString() + ">" 
$aceuser = [ADSI] $sidbind 
 
$service.AutodiscoverUrl($aceuser.mail.ToString()) 
 
$Sfir = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::IsRead, $True) 
$Sflt = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::IsRead, $False) 
$sfCollection = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+SearchFilterCollection([Microsoft.Exchange.WebServices.Data.LogicalOperator]::Or); 
$sfCollection.add($Sfir) 
$sfCollection.add($Sflt) 
 
 
[Int] $intCount = (Get-Mailbox -ResultSize Unlimited -Filter {CustomAttribute1 -eq "STAFF"}).Count 
#[Int] $intCount = (Get-Content C:\users1GB.csv | Get-Mailbox).Count 
[Int] $intSucceeded = 0 
 
# We can check only mailboxes in a CSV for example 
#Get-Content C:\users1GB.csv | Get-Mailbox | ForEach { 
Get-Mailbox -ResultSize Unlimited -Filter {CustomAttribute1 -eq "STAFF"} | Select PrimarySmtpAddress | ForEach { 
    # Create a progress bar so we know how we are doing 
    Write-Progress -Activity "Checking $intCount Mailboxes" -Status "Mailboxes Successfully Processed: $intSucceeded" 
     
    $MailboxName = ($_.PrimarySmtpAddress).ToString() 
 
    $rfRootFolderID = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::MsgFolderRoot,$MailboxName) 
    $rfRootFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$rfRootFolderID) 
    $fvFolderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView(100000); 
    $fvFolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep 
    $fvFolderView.PropertySet = $Propset 
    $ffResponse = $rfRootFolder.FindFolders($fvFolderView); 
 
    ForEach ($folder in $ffResponse.Folders) 
    { 
        #Write-Host $folder.Displayname  -ForegroundColor Green 
        If ($folder.DisplayName -notmatch "Calendar" -and $folder.DisplayName -notmatch "Notes" -and $folder.DisplayName -notmatch "Tasks" -and $folder.DisplayName -notmatch "Deleted Items") 
        { 
            $folderid = new-object  Microsoft.Exchange.WebServices.Data.FolderId($folder.ID) 
            $InboxFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$folderid) 
            $view = new-object Microsoft.Exchange.WebServices.Data.ItemView(500000) 
 
            $frFolderResult = $InboxFolder.FindItems($sfCollection,$view) 
            ForEach ($miMailItems in $frFolderResult.Items) 
            { 
                [String] $strDate = ($miMailItems.DateTimeCreated).ToShortDateString() 
                # To group only by month we remove the day. To group by year remove the month as well 
                $strDate = $strDate.Substring(3) 
                         
                $hashTableNumber.Set_Item($strDate, $hashTableNumber.Get_Item($strDate) + 1) 
                $hashTableSize.Set_Item($strDate, $hashTableSize.Get_Item($strDate) + [Int] $miMailItems.Size) 
            } 
        } 
    } 
     
    #$MailboxName >> C:\EmailDates_MbxProc_Big1GB.txt 
    $intSucceeded++ 
} 
 
 
$hashTableNumber.GetEnumerator() | Sort-Object Name | Export-CSV C:\EmailDates_Total.csv -NoTypeInformation 
$hashTableSize.GetEnumerator() | Sort-Object Name | Export-CSV C:\EmailDates_Total_Size.csv -NoTypeInformation