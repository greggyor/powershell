﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -version 3.0

Function Remove-OSCReadOnlyAttribute
{
<#
 	.SYNOPSIS
        Remove-OSCReadOnlyAttribute is an advanced function which can be used to remove read-only attribute of file.
    .DESCRIPTION
        Remove-OSCReadOnlyAttribute is an advanced function which can be used to remove read-only attribute of file.
    .PARAMETER  Path
		Specifies the path to a folder.
    .EXAMPLE
        C:\PS> Remove-OSCReadOnlyAttribute -Path C:\File\

		File Name                                Action(Remove Read-Only Attribute)
		---------                                ----------------------------------
		C:\File\Microsoft.psm1                   Success
		C:\File\Microsoft.vbs                    Success
		C:\File\New Text Document.txt            Success
		C:\File\Untitled.vbs                     Success
#>
	[Cmdletbinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=0)]
		[Alias('p')][String]$Path
	)
	
	$PathInfo = Get-ChildItem -Path $Path -File
	
	Foreach($File in $PathInfo)
	{
		$FileFullName = $File.FullName
		$Numbers++
		$Properties = @{'File Name' = $FileFullName
						'Action(Remove Read-Only Attribute)' = Try {Set-ItemProperty -Path $FileFullName -Name IsReadOnly -Value $false
																	"Success"}
															   Catch
															   		{"Failure"}
						}
		$Obj = New-Object -TypeName PSObject -Property $Properties
		$Obj
	}
}