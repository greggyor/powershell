if ( (Get-PSSnapin -Name Microsoft.Adfs.Powershell -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin Microsoft.Adfs.Powershell
}
Set-ADFSRelyingPartyTrust -TargetName "<myRelyingPartyName>" -TokenLifeTime <myTokenLifeTime>
Read-Host "Token Lifetime has been set. Press enter to exit."