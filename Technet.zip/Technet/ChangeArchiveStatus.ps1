if ($args[0] -eq $null -or $args[1] -eq $null -or $args[1].GetType().Name -ne "Boolean")
{
    echo ""
    echo "Usage: ChangeArchiveStatus.ps1 <Mailbox user account> <`$true|`$false>"
    echo "Specify `$true to set the ArchiveStatus, `$false otherwise"
    echo ""
    echo "Example: ChangeArchiveStatus.ps1 Mailbox1 `$true"
    echo ""
    exit
}

$userName = $args[0]
$setArchiveStatus = $args[1]
 
# setup the connection (first part is server and port, then Base DN of the search)
$objOU = New-Object System.DirectoryServices.DirectoryEntry("")

 
# filter should give you one user
$strFilter = "(&(objectCategory=User)(samaccountname=$userName))"
 
# setup the query
$objSearcher = New-Object System.DirectoryServices.DirectorySearcher
$objSearcher.SearchRoot = $objOU 
$objSearcher.PageSize = 1000
$objSearcher.Filter = $strFilter
$objSearcher.SearchScope = "Subtree"
 
 
# get the one result and show properties
$foundUser = $objSearcher.FindOne()

if ($foundUser -eq $null)
{
    echo "User $userName cannot be found"
    exit
}

echo "Found user $userName"
 
# get the result as User object and change something
$archiveStatus = $null
$archiveGuid = $null
$updateUser = $foundUser.getDirectoryEntry()

[int]$archiveStatus = &{
    return $updateUser.Get("msExchArchiveStatus")
    trap [Exception]
    {
        continue
    }
}

$archiveGuid = &{
    return $updateUser.Get("msExchArchiveGuid")
    trap [Exception]
    {
        continue
    }
}


if ($setArchiveStatus -and $archiveGuid -eq $null)
{
    echo ("The user does not have an archive")
    return
}

if ($archiveStatus -ne $null)
{
    echo ("Current value of ArchiveStatus is " + $archiveStatus)
}

if ($setArchiveStatus)
{
    # set the last bit to 1 
    $archiveStatus = $archiveStatus -bor 1
}
else
{
    # clear the last bit 
    $archiveStatus = $archiveStatus -band (0xffffffff - 1)
}

echo ("Setting value of ArchiveStatus to " + $ArchiveStatus)

$updateUser.Put("msExchArchiveStatus", $ArchiveStatus)

# save 
$updateUser.SetInfo()

echo ("ArchiveStatus has been updated successfully")
