Import-Module FailoverClusters

foreach ($diskrsrc in Get-ClusterResource | where-object {$_.ResourceType -ilike "Physical Disk"}) {
	get-clusterresource $diskrsrc.Name | get-clusterparameter | ?{$_.Name -eq "DiskSignature"} | %{$diski += @{[Convert]::ToUInt32($_.Value, 16) = $diskrsrc.Name}}
}

foreach ($rec in $diski.GetEnumerator()) {
	$WMIdisk = gwmi -Namespace root/MSCluster -Query "Select * From MSCluster_Disk Where ID=$($rec.Name)"
	gwmi -Namespace root/MSCluster -Query "ASSOCIATORS OF {$WMIdisk} Where ResultClass=MSCluster_DiskPartition" | %{$Label = $_.VolumeLabel; Get-ClusterResource $($rec.Value) | %{$_.Name = $Label}}
}