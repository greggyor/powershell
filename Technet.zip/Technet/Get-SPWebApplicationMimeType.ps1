﻿Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue

function Get-SPWebApplicationMimeType {
<#
.Synopsis
 This function gets the allowed inline downloaded MIME Types for a SharePoint Web Application. It can also report whether a specific MIME Type exists in the collection of allowed inline downloaded MIME Types.

.Description
 This function gets the allowed inline downloaded MIME Types for a SharePoint Web Application. It can also report whether a specific MIME Type exists in the collection of allowed inline downloaded MIME Types.
 This is the list of MIME types that can be directly Opened from SharePoint without being prompted to Save to file.
 This function has been verified to work with:
 ---All SharePoint 2010 and 2013 versions
 ---Will execute on Windows Server 2008, 2008 R2 and 2012

.Example
 Get-SPWebApplicationMimeType -WebApplication http://yourwebapplication

 This example gets the AllowedInlineDownloadedMimeTypes collection for the SharePoint Web Application http://yourwebapplication

.Example
 Get-SPWebApplicationMimeType -WebApplication http://yourwebapplication -Verbose

 This example gets the AllowedInlineDownloadedMimeTypes collection for the SharePoint Web Application http://yourwebapplication
 Verbose notes will be displayed.

.Example
 Get-SPWebApplicationMimeType -WebApplication http://yourwebapplication -ContainsMIMEType "application/pdf"

 This example will inform you whether or not the "application/pdf" MIME Type is included in the AllowedInlineDownloadedMimeTypes collection for the Web Application http://yourwebapplication
 
 Instead of the AllowedInlineDownloadedMimeType collection, the output will be a custom PSObject containing:
 -[string]WebApplicationName - the Web Application Name, 
 -[string]MIMEType a string indicating the specified by the $MIMEType input parameter in this case "application/pdf"
 -[bool]MIMETypeAllowed - indicates whether or not the specified MIME Type is in the AllowedInlineDownloadedMimeTypes collection for the specified Web Application http://yourwebapplication

.Example
 Get-SPWebApplication | ForEach-Object {Get-SPWebApplicationMimeType -WebApplication $_ -ContainsMIMEType "application/pdf"}

 This example will inform you whether or not the "application/pdf" MIME Type is included in the AllowedInlineDownloadedMimeTypes collection for all SharePoint Web Applications (excluding Central Administration)
 
 Instead of the AllowedInlineDownloadedMimeTypes collection, the output will be a custom PSObject collection containing:
 -[string]WebApplicationName - the Web Application Name, 
 -[string]MIMEType a string indicating the specified by the $MIMEType input parameter in this case "application/pdf"
 -[bool]MIMETypeAllowed - indicates whether or not the specified MIME Type is in the AllowedInlineDownloadedMimeTypes collection for the specified Web Application http://yourwebapplication

.PARAMETER WebApplication
 Required. SPWebApplicationPipeBind. Specifies a single SharePoint Web Application.

.PARAMETER MIMEType
 Optional. String. Specify the MIME Type to determine if it exists within the specified WebApplication AllowedInlineDownloadedMimeTypes collection. If specified, the function will return a collection of custom PSObjects reporting if the MIME Type exists in the WebApplication AllowedInlineDownloadedMimeTypes collection. See examples for more details. This parameter is forced to lower case within the script.

.Notes
 Name: Get-SPWebApplicationMimeType
 Author: Craig Lussier
 Last Edit: 2/17/2013

.Link
http://www.craiglussier.com
http://twitter.com/craiglussier
http://social.technet.microsoft.com/profile/craig%20lussier/

# Requires PowerShell Version 2.0 or Version 3.0
#>
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true, ValueFromPipeline=$true, Position=0)]
[Microsoft.SharePoint.PowerShell.SPWebApplicationPipeBind]$WebApplication,

[Parameter(Mandatory=$false, ValueFromPipeline=$true, Position=1)]
[string]$ContainsMIMEType
)

    Process {
        Write-Verbose "Entering Process Block - Get-SPWebApplicationMimeType"


        try {
           Write-Verbose "Get Web Application"
           $WebApp = Get-SPWebApplication $WebApplication

           

           if($ContainsMIMEType) {
                Write-Verbose "--Create custom PSObject for Web Application"
                $object = New-Object PSObject -Property @{                           
                    WebApplicationName = $WebApp.DisplayName              
                    MIMETypeAllowed = $null
                    MIMEType = $null                                               
                } 
                $containsType = $WebApp.AllowedInlineDownloadedMimeTypes -contains $ContainsMIMEType.ToLower().ToString()
                $object.MIMEType = $ContainsMIMEType.ToLower().ToString()
                $object.MIMETypeAllowed = $containsType

                Write-Output $object | select WebApplicationName, MIMEType, MIMETypeAllowed

           }
           Else {
                Write-Verbose "Output AllowedInlineDownloadedMimeTypes to the pipeline"
                Write-Output $WebApp.AllowedInlineDownloadedMimeTypes
            }

        }
        catch {
           Write-Error "There has been an issue getting the AllowedInlineDownloadedMimeTypes."
           Write-Error $_
        }
        Write-Verbose "Leaving Process Block - Get-SPWebApplicationMimeType"
    }

}