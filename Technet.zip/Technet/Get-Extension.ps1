
<#
   .Synopsis
    See if a phone extension is in use.
   
   .Description
    Search via PowerShell for the specified extension against Servers running Lync 2010, Exchange 2010 and Active Directory 2008 R2.
    Since I am using the -Filter option you do not nave to worry about the -resultsize unlimited setting with Get-UMMailbox.
	
	You MUST run these two functions bsp-exc & bsp-Lync that should be in your PowerShell profile PRIOR to running this script or it will fail.

	# Load Lync
	function bsp-lync 
	{ 
	write-host -ForegroundColor green -BackgroundColor black "Loading Lync Server 2010 RM" 
	$newlyncsession = New-PSSession -ConnectionUri https://lyncweb.BigDog.com/ocspowershell -credential "BigDog\TimBolton" 
	import-pssession -session $newlyncsession 
	} 
	
	# Load Exchange
	function bsp-exc 
	{ 
	write-host -ForegroundColor green -BackgroundColor black "Loading Exchange Server 2010 RM" 
	$newexcsession = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://Exchange01.BigDog.ad/PowerShell/ -Authentication Kerberos -Credential "BigDog\TimBolton" 
	
	import-pssession -session $newexcsession 
	}

    .Parameter Name
    The phone extension you want to find which will be passed as a string to $Extension.
    .Example
    PS C:\> Get-Extension 7530
    $GetUser=Get-user -Filter "Phone -like '*$Extension'"
	
	NOTE- You may see mixed results per server meanning it may exist in one area, but but not another.
	.Example
	PS C:\> Get-Extension 7530

	CS Display Name    : Bolton,Tim
	Line URI           : tel:+19226667530
	AD Phone           : 922-666-7530
	Other Fax          : Extension Not Found
	Exchange SIP       : TBOLTON@BigDog.com
	Exchange Extension : {7530 (DirectFromAudiocodes-Temp.BigDog.com), 7530 (BigDog-OCS-DP.BigDog.com), TBOLTON@BigDog.com}
	
	.Example
	PS C:\> Get-Extension 3721
		
	CS Display Name    : Extension Not Found
	Line URI           : Extension Not Found
	AD Phone           : Extension Not Found
	Other Fax          : {Doe,John H., Smith,Mark R.} - This indicates there is a duplicate entry which can also cause issues.
	Exchange SIP       : Extension Not Found
	Exchange Extension : Extension Not Found
	
   .Notes
    NAME: Get-Extension
    VERSION: 3.0
    AUTHOR: Tim Bolton / Brian Peacock
    LASTEDIT: 12/19/2012
#>

# Example Get-Extension 7530
Function Get-Extension {
	param(
	[parameter(Mandatory = $true)]
	[String] $Extension)

# The extension you entered is now passed as a string value and searched agianst the various servers.  If not found that will be the value posted.
	$CSUser=Get-csuser -Filter "LineURI -like '*$Extension'" # Lync
	$GetUser=Get-User -Filter "Phone -like '*$Extension'"	 # Active Directoy
	$GetOther=Get-User -Filter "OtherFax -Like '*$Extension*'"
	$GetUM=Get-UMMailbox -Filter "EmailAddresses -Like '*$Extension*'" # Exchange
	$NotFound = "Extension Not Found"

# Creating new Objects
	$obj = New-Object -TypeName PSObject

# If statments - If found will show information, if not will show Extension Not Found.  You may see mixed results per server maening it may exist in EUM but not AD or Lync or vice versa.
	If ($CSUser -ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "CS Display Name" -Value ($CSUser.DisplayName)
	} 	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "CS Display Name" -Value ($NotFound)
		}
		
	If ($CSUser	-ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "Line URI" -Value ($CSUser.LineURI)
	}	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "Line URI" -Value ($NotFound)
		}
		
	If 	($GetUser -ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "AD Phone" -Value ($GetUser.Phone)
	} 	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "AD Phone" -Value ($NotFound)
		}
		
	If 	($GetOther -ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "Other Fax" -Value ($GetOther.DisplayName)
	} 	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "Other Fax" -Value ($NotFound)
		}	
		
	If 	($GetUM -ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "Exchange SIP" -Value ($GetUM.SIPResourceIdentifier)
	} 	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "Exchange SIP" -Value ($NotFound)
		}
	
		If 	($GetUM -ne $null)
	{
	$obj | Add-Member -MemberType NoteProperty -Name "Exchange Extension" -Value ($GetUM.Extensions)
	} 	Else {
		$obj | Add-Member -MemberType NoteProperty -Name "Exchange Extension" -Value ($NotFound)
		}

# Write the output to the screen.
	Write-Output $obj
}