﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

#Add System.DirectoryServices.Protocols Assembly
Add-Type -AssemblyName System.DirectoryServices.Protocols

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Export-OSCADGroupDisplayName
{
	#.EXTERNALHELP Export-OSCADGroupDisplayName-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Path,
		[Parameter(Mandatory=$false,Position=2)]
		[string]$SearchBase,
		[Parameter(Mandatory=$false,Position=3)]
		[System.DirectoryServices.Protocols.SearchScope]$SearchScope="SubTree",
		[Parameter(Mandatory=$false,Position=4)]
		[System.Management.Automation.PSCredential]$Credential
	)
	Begin
	{
		$results = @()

		#Try to establish connection to target domain
		Try
		{
			if ([System.String]::IsNullOrEmpty($SearchBase)) {
                $currentDomain = New-Object System.DirectoryServices.DirectoryEntry
                $currentDomainDN = $currentDomain.distinguishedName.ToString().ToLower()
				$targetDomainFqdn = $currentDomainDN.Replace(",dc=",".").Replace("dc=","").TrimStart(".")
			} else {
				if (-not $SearchBase.ToLower().StartsWith("dc=")) {
					$firstDcIndex = $SearchBase.ToLower().IndexOf(",dc=")
					$domainDN = $SearchBase.ToLower().Substring($firstDcIndex)
				} else {
					$domainDN = $SearchBase.ToLower()
				}
				$targetDomainFqdn = $domainDN.Replace(",dc=",".").Replace("dc=","").TrimStart(".")
			}
			
			$verboseMsg = $Messages.EstablishDomainConnection
			$verboseMsg = $verboseMsg -f $targetDomainFqdn
			$pscmdlet.WriteVerbose($verboseMsg)
			
			if ($Credential -ne $null) {
				$networkCred = $Credential.GetNetworkCredential()
				$ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn, 3268)
				$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier,$networkCred)
			} else {
				$ldapDirectoryIdentifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($targetDomainFqdn, 3268)
				$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection($ldapDirectoryIdentifier)
			}
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
        
		if ([System.String]::IsNullOrEmpty($SearchBase)) {
			$SearchBase = ""
		}
	}
	Process
	{
		#Define return attributes
		$retrunAttributes = [string[]]("distinguishedName","displayName","mail","objectGUID")

		#Define LDAP search filter
		$ldapSearchFiler = "(&(objectCategory=group)(|(mail=*)(proxyAddresses=*))(!(displayName=*)))"

		#Enable Paged Search
		$pagedSearch = New-Object System.DirectoryServices.Protocols.PageResultRequestControl(1000)

		#Prepare a new search request
		$ldapConnection.SessionOptions.ReferralChasing = [System.DirectoryServices.Protocols.ReferralChasingOptions]::All
		$searchRequest = New-Object System.DirectoryServices.Protocols.SearchRequest(`
						 $SearchBase,$ldapSearchFiler,$SearchScope,$retrunAttributes)
		$searchRequest.Controls.Add($pagedSearch) | Out-Null

		#Send search request
		$verboseMsg = $Messages.SendSearchRequest
		$pscmdlet.WriteVerbose($verboseMsg)
		
        Try
        {
		    $searchResponse = [System.DirectoryServices.Protocols.SearchResponse]$ldapConnection.SendRequest($searchRequest)
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }

		#Iterate each search response entry
		$verboseMsg = $Messages.HandleSearchResponse
		$pscmdlet.WriteVerbose($verboseMsg)
		
		if ($searchResponse.Entries.Count -ne 0) {
			foreach ($searchResponseEntry in $searchResponse.Entries) {
				$objectGuid = $searchResponseEntry.Attributes.objectguid.GetValues("byte[]")
				$objectGuidBase64String = [System.Convert]::ToBase64String($objectGuid[0])
				$distinguishedName = [string]($searchResponseEntry.Attributes.distinguishedname.GetValues("string"))
				$mail = [string]($searchResponseEntry.Attributes.mail.GetValues("string"))
				if ($searchResponseEntry.Attributes.Contains("displayname")) {
					$displayName = [string]($searchResponseEntry.Attributes.displayname.GetValues("string"))
				} else {
					$displayName = [System.String]::Empty
				}
				$result = New-Object System.Management.Automation.PSObject
				$result | Add-Member -MemberType NoteProperty -Name DistinguishedName -Value $distinguishedName
				$result | Add-Member -MemberType NoteProperty -Name Displayname -Value $displayName
				$result | Add-Member -MemberType NoteProperty -Name Mail -Value $mail
				$result | Add-Member -MemberType NoteProperty -Name ObjectGUID -Value $objectGuidBase64String
				$results += $result
			}
		} else {
            $warningMsg = $Messages.CannotFindGroupWithEmptyDisplayName
            $PSCmdlet.WriteWarning($warningMsg)
		}
	}
	End
	{
		#Export the result
		$infoMsg = $Messages.ExportResult
		$infoMsg = $infoMsg -f ($results | Measure-Object).Count
		$pscmdlet.WriteObject($infoMsg)

		Try
		{
			$results | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -NoClobber
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
	}
}

Function Import-OSCADGroupDisplayName
{
	#.EXTERNALHELP Import-OSCADGroupDisplayName-Help.xml

	[cmdletbinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Path,
		[Parameter(Mandatory=$false,Position=2)]
		[System.Management.Automation.PSCredential]$Credential
	)
	Begin
	{
		$validGroups = @{}
		$invalidGroupCount = 0
		$pattern = "\?|@|\+"

		#Import files
		Try
		{
			$rawGroups = Import-Csv -Path $Path
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}

		#Verify the input file
		foreach ($rawGroup in $rawGroups) {
			if ([System.String]::IsNullOrEmpty($rawGroup.DistinguishedName)) {continue}
		
			$isValid = $true
			
			#Verify the length of DisplayName
			if (($rawGroup.DisplayName.Length -gt 256) -or ($rawGroup.DisplayName.Length -eq 0)) {
				$warningMsg = $Messages.InvalidLength
				$warningMsg = $warningMsg -f $rawGroup.DistinguishedName
				$PSCmdlet.WriteWarning($warningMsg)
				$isValid = $false
			}

			#Verify invalid characters
			if ([regex]::IsMatch($rawGroup.DisplayName,$pattern)) {
				$warningMsg = $Messages.InvalidChars
				$warningMsg = $warningMsg -f $rawGroup.DistinguishedName
				$PSCmdlet.WriteWarning($warningMsg)
				$isValid = $false
			}
			
			if (-not $isValid) {
				$invalidGroupCount++
			} else {
				$validGroups.Add($rawGroup.DistinguishedName,$rawGroup.DisplayName)			
			}
		}

		#Input file should meet the requirement of displayName
		if ($invalidGroupCount -gt 0) {
			$warningMsg = $Messages.InvalidGroupName
			$warningMsg = $warningMsg -f $invalidGroupCount
			$pscmdlet.WriteWarning($warningMsg)
		}
	}
	Process
	{
		#Iterate each valid group to set displayName
		foreach ($validGroup in $validGroups.GetEnumerator()) {
			$groupDN = $validGroup.Name
			$groupDisplayname = $validGroup.Value
			
			#Get domain FQDN from distinguishedName
			$firstDcIndex = $groupDN.ToLower().IndexOf(",dc=")
			$domainDN = $groupDN.Substring($firstDcIndex)
			$targetDomainFQDN = $domainDN.ToLower().Replace(",dc=",".").TrimStart(".")

			#Try to establish connection to target domain if necessary
			if ($ldapConnection -ne $null) {
				$ldapConnDirSvr = [string]($ldapConnection.Directory.Servers)
			}

			if (($ldapConnection -eq $null) -or ($ldapConnDirSvr -ne $targetDomainFQDN)) {
				Try
				{
					if ($Credential -ne $null) {
						$networkCred = $Credential.GetNetworkCredential()
						$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection("$targetDomainFqdn",$networkCred)
					} else {
						$ldapConnection = New-Object System.DirectoryServices.Protocols.LdapConnection("$targetDomainFqdn")
					}
				}
				Catch
				{
					$PSCmdlet.ThrowTerminatingError($_)
				}
			}
			
			#Send modify request to modify displayName
			if ($PSCmdlet.ShouldProcess($groupDN)) {
				Try
				{
					$modifyRequest = New-Object System.DirectoryServices.Protocols.ModifyRequest(`
									 $groupDN,[System.DirectoryServices.Protocols.DirectoryAttributeOperation]::Replace,`
									 "displayName",$groupDisplayname)
					$requestResponse = $ldapConnection.SendRequest($modifyRequest)
				}
				Catch
				{
					$PSCmdlet.WriteError($_)
				}
			}
		}
	}
	End	{}
}

Export-ModuleMember -Function "Export-OSCADGroupDisplayName","Import-OSCADGroupDisplayName"