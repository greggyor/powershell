﻿function solve([int] $count, [char] $source)
{
	for($i = 1; $i -lt ([Math]::Pow(2, $count)); $i++)
	{
		$global:c++
		$s = [char]([int]$source + ($i -band $i - 1) % 3)
		$d = [char]([int]$source + (($i -bor $i - 1) + 1) % 3)
		Write-Host "Move top disk from pole $s to pole $d"
	}
}

$num = Read-Host "Number of disks"
$global:c = 0
solve $num 'A'
Write-Host "Iterations: $global:c"