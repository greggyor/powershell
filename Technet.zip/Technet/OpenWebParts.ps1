$webUrl = "http://<yourweb>"  #the url of the web
$library = "Pages"      #the name of the pages library
$page = "default.aspx"      #the file name of the page in the pages Library
$comment = "Restored WebParts"  #the comment used for checking in and publishing the page
 
$web = Get-SPWeb $webUrl
try{
    $list = $web.Lists.TryGetList($library)
    if($list){
        $item = $list.Items | ? {$_.Name -eq $page }
        $pubWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($web)
        $pubPage = [Microsoft.SharePoint.Publishing.PublishingPage]::GetPublishingPage($item)
        $pubPage.CheckOut()
        if([System.Web.HttpContext]::Current -eq $null){
            $sw = New-Object System.IO.StringWriter  
            $response = New-Object System.Web.HttpResponse $sw 
            $request = New-Object System.Web.HttpRequest "", $web.Url, "" 
            $context = New-Object System.Web.HttpContext $request, $response 
            $context.Items["HttpHandlerSPWeb"] = $web  -as [Microsoft.SharePoint.SPweb]  
            [System.Web.HttpContext]::Current = $context
        }
 
        $wpm = $web.GetLimitedWebPartManager($pubPage.Url, [System.Web.UI.WebControls.WebParts.PersonalizationScope]::Shared)
 
        # to show the closed status of all webparts on the page, uncomment the next line
        # $wpm.WebParts | select Title,  ZoneId, isClosed | ft
 
        $wpm.WebParts | % {
                $wpm.OpenWebPart($_)      
                $wpm.SaveChanges($_)
        }
 
        $pubPage.CheckIn($comment)
        $pubPage.ListItem.File.Publish($comment)
        $pubPage.ListItem.File.Approve($comment)
    }
}
finally{
    $web.Dispose()
    #remove context to avoid conflicts when running the script on multiple webs
    [System.Web.HttpContext]::Current = $null
}