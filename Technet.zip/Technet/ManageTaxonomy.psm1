﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Get-OSCSPTaxonomyTerm
{
	#.EXTERNALHELP Get-OSCSPTaxonomyTerm-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$TermStoreName,
		[Parameter(Mandatory=$true,Position=3)]
		[string[]]$Name,
		[Parameter(Mandatory=$false,Position=4)]
		[Microsoft.SharePoint.Taxonomy.StringMatchOption]$MatchOption="ExactMatch",			
		[Parameter(Mandatory=$false,Position=5)]
		[int]$ResultCollectionSize=1000,
		[Parameter(Mandatory=$false)]
		[switch]$TrimUnavailable,
		[Parameter(Mandatory=$false)]
		[switch]$DefaultLabelOnly
	)
	Begin
	{
		if ($TrimUnavailable) {$TrimUnavailable = $true} else {$TrimUnavailable = $false}
		if ($DefaultLabelOnly) {$DefaultLabelOnly = $true} else {$DefaultLabelOnly = $false}
	}
	Process
	{
		#Get Taxonomy Session
		Try
		{
			$spTaxonomySession = Get-SPTaxonomySession -Site $SiteURL -Verbose:$false
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
		#Get Term Store
		Try
		{
			$spTermStore = $spTaxonomySession.TermStores.Item($TermStoreName)
		}
		Catch
		{
			$errorMsg = $Messages.InvalidTermStoreName
			$errorMsg = $errorMsg -f $TermStoreName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		foreach ($termName in $Name) {
			$spTerms = $spTermStore.GetTerms($termName,$DefaultLabelOnly,$MatchOption,$ResultCollectionSize,$TrimUnavailable)
			if ($spTerms -ne $null) {
				foreach ($spTerm in $spTerms) {
					$PSCmdlet.WriteObject($spTerm)
				}
			} else {
				$errorMsg = $Messages.CannotFindSpecificTerm
				$errorMsg = $errorMsg -f $termName
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.WriteError($customError)
			}
		}
	}
}

Function Add-OSCSPTaxonomyTerm
{
	#.EXTERNALHELP Add-OSCSPTaxonomyTerm-Help.xml

	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$TermStoreName,
		[Parameter(Mandatory=$true,Position=3)]
		[string]$TermSetName,
		[Parameter(Mandatory=$true,Position=4)]
		[string[]]$Name
	)
	Process
	{
		#Get Taxonomy Session
		Try
		{
			$spTaxonomySession = Get-SPTaxonomySession -Site $SiteURL -Verbose:$false
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
		#Get Term Store
		Try
		{
			$spTermStore = $spTaxonomySession.TermStores.Item($TermStoreName)
		}
		Catch
		{
			$errorMsg = $Messages.InvalidTermStoreName
			$errorMsg = $errorMsg -f $TermStoreName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		#Get Term Set
		$spTermSets = $spTermStore.GetTermSets($TermSetName,[System.Globalization.CultureInfo]::CurrentCulture.LCID)
		if ($spTermSets.Count -eq 0) {
			$errorMsg = $Messages.InvalidTermSetName
			$errorMsg = $errorMsg -f $TermSetName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		} else {
			$termSetID = $spTermSets.Item(0).ID
			$spTermSet = $spTermStore.GetTermSet($termSetID)
		}
		foreach ($termName in $Name) {
			Try
			{
				$verboseMsg = $Messages.CreatingTerm
				$verboseMsg = $verboseMsg -f $termName
				$pscmdlet.WriteVerbose($verboseMsg)
				$spTerms = $spTermStore.GetTerms($termName,$false,[Microsoft.SharePoint.Taxonomy.StringMatchOption]::ExactMatch,1,$false)
				if ($spTerms.Count -eq 0) {
					$spTerm = $spTermSet.CreateTerm($termName,[System.Globalization.CultureInfo]::CurrentCulture.LCID)			
				} else {
					$warningMsg = $Messages.TermExists
					$warningMsg = $warningMsg -f $termName
					$pscmdlet.WriteWarning($warningMsg)				
				}
			}
			Catch
			{
				$pscmdlet.WriteError($_)
			}
		}
		$spTermStore.CommitAll()
	}
}

Function Remove-OSCSPTaxonomyTerm
{
	#.EXTERNALHELP Remove-OSCSPTaxonomyTerm-Help.xml

	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$SiteURL,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$TermStoreName,
		[Parameter(Mandatory=$true,Position=5)]
		[string[]]$Name
	)
	Process
	{
		#Get Taxonomy Session
		Try
		{
			$spTaxonomySession = Get-SPTaxonomySession -Site $SiteURL -Verbose:$false
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
		#Get Term Store
		Try
		{
			$spTermStore = $spTaxonomySession.TermStores.Item($TermStoreName)
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
		Try
		{
			foreach ($termName in $Name) {
				$spTerms = $spTermStore.GetTerms($termName,$false)
				if ($spTerms.Count -ne 0) {
					foreach ($spTerm in $spTerms) {
						$verboseMsg = $Messages.RemovingTerm
						$verboseMsg = $verboseMsg -f $termName
						$pscmdlet.WriteVerbose($verboseMsg)
						if ($PSCmdlet.ShouldProcess($spTerm.Name)) {
							$spTerm.Delete()
						}
					}
				} else {
					$warningMsg = $Messages.CannotFindSpecificTerm
					$warningMsg = $warningMsg -f $termName
					$pscmdlet.WriteWarning($warningMsg)
				}
			}
			$spTermStore.CommitAll()
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($_)
		}
	}
}

Export-ModuleMember -Function "Get-OSCSPTaxonomyTerm","Add-OSCSPTaxonomyTerm","Remove-OSCSPTaxonomyTerm"