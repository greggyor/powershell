param
(
[Parameter(Mandatory=$true)][ValidateScript({Test-Path $_ -Include "*.csv"})]
[String]$CSVPath
)

#This script will remove users specified in the CSV. 

$CSVFile = Import-CSV $CSVPath
Add-PSSnapin Microsoft.SharePoint.PowerShell -EA SilentlyContinue

#Get all site collections
$Sites = Get-SPSite -Limit All
$AllSites = @()
foreach($Line in $CSVFile)
{
	foreach($Site in $Sites)
	{
		#Get the rootweb for the site collection
		$RootWeb = $Site.RootWeb
		If([bool](Get-SPUser $Line.Username -Web $RootWeb -EA SilentlyContinue) -eq $True)
		{
		#Remove the user from the User Information List
		Remove-SPUser -Identity $Line.username -Web $RootWeb -Confirm:$False
		$AllSites += $RootWeb.Url
		}
	}
	if(!($AllSites).count -eq 0)
	{
	#Give feedback on deleted users
	Write-Host "Removed user $($Line.username) from:" -Fore "Magenta"
	foreach($S in $AllSites){Write-Host "- $S"}
	Write-Host ""
	$AllSites = @()
	}
}
