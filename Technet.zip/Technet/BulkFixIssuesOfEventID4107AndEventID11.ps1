﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#Requires -Version 2.0

#Import Localized Data
Import-LocalizedData -BindingVariable Message

$scriptblock = {
    # This function is used to remove all the temped files in the specific path.
    Function Remove-OSCCryptnetUrlCacheFiles{   

        Param
        (   
            [Parameter(Mandatory = $true,ParameterSetName='Path')]
            [String]$Path
        )
        
        # Remove all the files in the specified path.
        If(-not [String]::IsNullOrEmpty($Path)){
            If(Test-Path -Path $Path){
                Try{
                    $Items = Get-ChildItem -Path $Path -Force | ForEach-Object{
                        $_.Delete()
                    }
                }
                Catch{
                    Write-Error $($_.Exception.Message)
                }
            }   
        }
    }
    
    # This function is used to fix the Event4107 and Event11 error.
    Function Repair-OSCCTLCertificateExpiredIssue{
        Try{    
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\ServiceProfiles\LocalService\AppData\LocalLow\Microsoft\CryptnetUrlCache\Content")
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\ServiceProfiles\LocalService\AppData\LocalLow\Microsoft\CryptnetUrlCache\MetaData")
                
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\ServiceProfiles\NetworkService\AppData\LocalLow\Microsoft\CryptnetUrlCache\Content")
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\ServiceProfiles\NetworkService\AppData\LocalLow\Microsoft\CryptnetUrlCache\MetaData")
                
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\System32\config\systemprofile\AppData\LocalLow\Microsoft\CryptnetUrlCache\Content")
            Remove-OSCCryptnetUrlCacheFiles -Path (Join-Path $Env:windir "\System32\config\systemprofile\AppData\LocalLow\Microsoft\CryptnetUrlCache\MetaData")
        }
        Catch{
            Write-Error $($_.Exception.Message)
            return $null
        }
    }
    certutil –urlcache * delete | Out-Null
    Repair-OSCCTLCertificateExpiredIssue
}

$ListInvalidCertBlock = {	
	# This function is used to get the expired certificates in this computer.
    Function Get-OSCExpiredCertificate{

        [OutputType('System.Security.Cryptography.X509Certificates.X509Certificate2[]')]
        Param
        (
            [Parameter(Mandatory = $true)]
            [Security.Cryptography.X509Certificates.StoreName]$StoreName,
        
            [Parameter(Mandatory = $true)]
            [Security.Cryptography.X509Certificates.StoreLocation]$StoreLocation
        )
        
		If([String]::IsNullOrEmpty($StoreName) -or [String]::IsNullOrEmpty($StoreLocation)){
        	return $null
    	}
		
		$ChildPath = [String]::Format("{0}\{1}",$StoreLocation,$StoreName)
		
        $OSCExpiredCerts = @()
        
        # Get the certificates from the specific store 
		
        $OSCCertificates = Get-ChildItem -Path (Join-Path "cert:\" $ChildPath)
        $OSCCurrentDateTime = Get-Date
                
        $OSCCertificates | Foreach-Object {
            If($_.NotAfter -lt $OSCCurrentDateTime){
                $OSCExpiredCerts += $_
            }
        }
				                
        return $OSCExpiredCerts
    }
	
    Get-OSCExpiredCertificate -StoreLocation LocalMachine -StoreName Root | Format-List
}

Function Repair-OSCCTLCertificateExpiredIssueBulk{
<#
    .SYNOPSIS
        Repair-OSCCTLCertificateExpiredIssueBulk is a function can be used to bulk fix the computers errors Event4107 and Event11 caused by the expired certificate.
    .DESCRIPTION
        Repair-OSCCTLCertificateExpiredIssueBulk is an advanced function which can be bulk fix the computers errors Event4107 and Event11 
        caused by the expired certificate.
        
    .PARAMETER  <Path>
        The specific path of the .csv file log the Server names need to be fixed .
        
    .PARAMETER  <UserId>
        The UserId to login the Server.
                        
    .EXAMPLE
        Repair-OSCCTLCertificateExpiredIssueBulk -Path "TestPath" -UserId "TestUserId"
        
        Bulk fix the issues of EventID4107AndEventID11 on the computers list on the .csv file in the specific path.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true,ParameterSetName='Path')]
        [String]$Path,
        
        [Parameter(Mandatory=$true)]
        [String]$UserId
    )
    
    If([String]::IsNullOrEmpty($Path) -or [String]::IsNullOrEmpty($UserId))
	{
        Write-Error $Message.InvalidParameters
        return $null
    }
    
    If(-not(Test-Path -Path $Path))
    {
        Write-Error $Message.InvalidPath
        return $null
    }
    
    If([System.IO.Path]::GetExtension($Path) -ne ".csv")
    {
        Write-Error $Message.InvalidFileType
        return $null
    }
    
    Try{
        $Credential = Get-Credential -Credential $UserId
        $LocalMachineName = $Env:COMPUTERNAME
            
        #Bulk fix the issue
        Import-Csv -Path $Path | ForEach-Object{
            If($LocalMachineName -eq $_.ComputerName){
                $ExecutionContext.InvokeCommand.InvokeScript($scriptblock)
                Write-Host ($_.ComputerName + " has been fixed! ")
            }Else{
                Invoke-Command -ComputerName $_.ComputerName -Credential $Credential -ScriptBlock $scriptblock 
                Write-Host ($_.ComputerName + " has been fixed! ")
            }
        }
    }Catch{
        Write-Error $($_.Exception.Message)
    }
}

Function Repair-OSCCTLCertificateExpiredIssue{
<#
    .SYNOPSIS
        Repair-OSCCTLCertificateExpiredIssue is a function can be used to fix the computers errors Event4107 and Event11 caused by the expired certificate.
    .DESCRIPTION
        Repair-OSCCTLCertificateExpiredIssue is an advanced function which can be fix the computers errors Event4107 and Event11 
        caused by the expired certificate.
        
    .PARAMETER  <ComputerName>
        The specific name of the computer need to be fixed .
        
    .PARAMETER  <UserId>
        The UserId to login the Server.
                        
    .EXAMPLE
        Repair-OSCCTLCertificateExpiredIssue -Path "ComputerName" -UserId "TestUserId"
        
        Fix the issues of EventID4107AndEventID11 on the specific computer.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true)]
        [String]$ComputerName,
        
        [Parameter(Mandatory=$true)]
        [String]$UserId
    )
	
	If([String]::IsNullOrEmpty($ComputerName) -or [String]::IsNullOrEmpty($UserId)){
        Write-Error $Message.InvalidParameters
        return $null
    }
	
	Try{
        $Credential = Get-Credential -Credential $UserId
        $LocalMachineName = $Env:COMPUTERNAME
            
        #Fix the issue
        If($LocalMachineName -eq $ComputerName){
            $ExecutionContext.InvokeCommand.InvokeScript($scriptblock)
            Write-Host ($ComputerName + " has been fixed! ")
        }Else{
            Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock $scriptblock 
            Write-Host ($ComputerName + " has been fixed! ")
        }
    }Catch{
        Write-Error $($_.Exception.Message)
    }
}

Function Get-OSCExpiredCertificates{
<#
    .SYNOPSIS
        Get-OSCExpiredCertificates is a function can be used to list all the expired certificates in the specific computer.
    .DESCRIPTION
        Get-OSCExpiredCertificates is an advanced function which can be used to list all the expired certificates in the specific computer.
        
    .PARAMETER  <ComputerName>
        The specific name of the computer need to be list the expired certificates.
        
    .PARAMETER  <UserId>
        The UserId to login the Server.
                        
    .EXAMPLE
        Get-OSCExpiredCertificates -Path "ComputerName" -UserId "TestUserId"
        
        List all the expired certificates in the specific computer.
#>

    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true)]
        [String]$ComputerName,
        
        [Parameter(Mandatory=$true)]
        [String]$UserId
    )
	
	If([String]::IsNullOrEmpty($ComputerName) -or [String]::IsNullOrEmpty($UserId)){
        Write-Error $Message.InvalidParameters
        return $null
    }
	
	Try{
        $Credential = Get-Credential -Credential $UserId
        $LocalMachineName = $Env:COMPUTERNAME
            
        If($LocalMachineName -eq $ComputerName){
            $ExecutionContext.InvokeCommand.InvokeScript($ListInvalidCertBlock)
            Write-Host ($ComputerName)
        }Else{
            Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock $ListInvalidCertBlock
            Write-Host ($ComputerName)
        }
    }Catch{
        Write-Error $($_.Exception.Message)
    }
}

Function Get-OSCExpiredCertificatesBulk{
<#
    .SYNOPSIS
        Get-OSCExpiredCertificatesBulk is a function can be used to list all the expired certificates in the specific computers list on the .csv file in the specific path.
    .DESCRIPTION
        Get-OSCExpiredCertificatesBulk is an advanced function which can be used to list all the expired certificates in the specific computers list on the .csv file in the specific path.
        
    .PARAMETER  <Path>
        The specific path of the .csv file list all the computers need to show their expired certificates.
        
    .PARAMETER  <UserId>
        The UserId to login the Server.
                        
    .EXAMPLE
        Get-OSCExpiredCertificatesBulk -Path "TestPath" -UserId "TestUserId"
        
        List all the expired certificates in the specific computers list on the .csv file in the specific path.
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true,ParameterSetName='Path')]
        [String]$Path,
        
        [Parameter(Mandatory=$true)]
        [String]$UserId
    )
    
    If([String]::IsNullOrEmpty($Path) -or [String]::IsNullOrEmpty($UserId)){
        Write-Error $Message.InvalidParameters
        return $null
    }
    
    If(-not(Test-Path -Path $Path))
    {
        Write-Error $Message.InvalidPath
        return $null
    }
    
    If([System.IO.Path]::GetExtension($Path) -ne ".csv")
    {
        Write-Error $Message.InvalidFileType
        return $null
    }
    
    Try{
        $Credential = Get-Credential -Credential $UserId
        $LocalMachineName = $Env:COMPUTERNAME
            
        #Bulk fix the issue
        Import-Csv -Path $Path | ForEach-Object{
            If($LocalMachineName -eq $_.ComputerName){
                $ExecutionContext.InvokeCommand.InvokeScript($ListInvalidCertBlock)
                Write-Host ($_.ComputerName)
            }Else{
                Invoke-Command -ComputerName $_.ComputerName -Credential $Credential -ScriptBlock $ListInvalidCertBlock
                Write-Host ($_.ComputerName)
            }
        }
    }Catch{
        Write-Error $($_.Exception.Message)
    }
}