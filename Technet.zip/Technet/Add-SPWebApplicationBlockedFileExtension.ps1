﻿Add-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue

function Add-SPWebApplicationBlockedFileExtension {
<#
.Synopsis
 This function adds a file extension to a SharePoint Web Application's BlockedFileExtensions collection.

.Description
 This function adds a file extension to a SharePoint Web Application's BlockedFileExtensions collection.
 This ensures that files with the specified extension cannot be saved within the Web Application.
 When the add operation is complete, the Get-SPWebApplicationBlockedFileExtension function is called to report the status of the file extension.
 This function has been verified to work with:
 ---All SharePoint 2010 and 2013 versions
 ---Will execute on Windows Server 2008, 2008 R2 and 2012

.Example
 Add-SPWebApplicationBlockedFileExtension -WebApplication http://yourwebapplication -Extension "html"

 This example adds the "html" file extension to the BlockedFileExtensions collection for the SharePoint Web Application http://yourwebapplication

.Example
 Get-SPWebApplication | ForEach-Object {Add-SPWebApplicationBlockedFileExtension -WebApplication $_ -Extension "html"}

 This example adds the "html" extension to the BlockedFileExtensions for all SharePoint Web Applications (excluding Central Administration)
 
.PARAMETER WebApplication
 Required. SPWebApplicationPipeBind. Specifies a single SharePoint Web Application.

.PARAMETER Extension
 Required. String. Specify the file extension to add to the specified WebApplication BlockedFileExtensions collection. This parameter is forced to lower case within the script.


.Notes
 Name: Add-SPWebApplicationBlockedFileExtension
 Author: Craig Lussier
 Last Edit: 3/3/2013

.Link
 Get-SPWebApplicationBlockedFileExtension
 http://www.craiglussier.com
 http://twitter.com/craiglussier
 http://social.technet.microsoft.com/profile/craig%20lussier/
 # Requires PowerShell Version 2.0 or Version 3.0
#>
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true, ValueFromPipeline=$true, Position=0)]
[Microsoft.SharePoint.PowerShell.SPWebApplicationPipeBind]$WebApplication,
[Parameter(Mandatory=$true, ValueFromPipeline=$true, Position=1)]
[string]$Extension
)

    Process {

        Write-Verbose "Entering Process Block - Add-SPWebApplicationBlockedFileExtension"
        try {
            Write-Verbose "Get Web Application"
            $WebApp = Get-SPWebApplication $WebApplication
            $WebAppDisplayName = $WebApp.DisplayName

            $ExtensionLowerCase = $Extension.ToLower().ToString()

            Write-Verbose "Get Web Application BlockedFileExtensions"
            $Extensions = $WebApp.BlockedFileExtensions

            Write-Verbose "Attempt to add the $Extension extension if it does not exist in the BlockedFileExtensions collection"
            if($Extensions -notcontains $ExtensionLowerCase) {
                $Extensions.Add($Extension) | Out-Null
                $WebApp.Update()
                Write-Verbose "Added the $ExtensionLowerCase extension to the BlockedFileExtensions collection"
            }
            else {
                Write-Warning "The Extension '$ExtensionLowerCase' is already a blocked file type in the '$WebAppDisplayName' Web Application. No Add action taken."
            }

        }
        catch {
            Write-Error "There has been an error while attempting to add the specified extension to the BlockedFileExtensions collection of the specified Web Application."
            Write-Error "Try running PowerShell as Administrator and make sure you have proper PSShellAdmin permissions to the underlying SPContentDatabase for the specified Web Application"
            Write-Error $_
        }

        try {
            Write-Verbose "Prepare to call the Get-SPWebApplicationBlockedFileExtension function to verify that the '$Extension' extension exists in the BlockedFileExtensions collection of the specified Web Application"
            
            Write-Verbose "Determine the executing folder"
            $scriptPath = & { Split-Path $myInvocation.ScriptName } 

            Write-Verbose "Dot source the Get-SPWebApplicationBlockedFileExtension.ps1 file to load the function"
            . "$scriptPath\Get-SPWebApplicationBlockedFileExtension.ps1"

            Write-Verbose "Calling the the Get-SPWebApplicationBlockedFileExtension function"
            Get-SPWebApplicationBlockedFileExtension -WebApplication $WebApplication -Extension $ExtensionLowerCase
        }
        catch {
            Write-Error "There has been an error while attempting to verify that the specified Extension has been added to the BlockedFileExtensions collection of the specified Web Application."
            Write-Error "Make sure the Get-SPWebApplicationBlockedFileExtension.ps1 file is in the same folder as the Add-SPWebApplicationBlockedFileExtension.ps1 file."
            Write-Error $_
        }
        Write-Verbose "Leaving Process Block - Add-SPWebApplicationBlockedFileExtension"
    }

}