﻿[CmdletBinding(SupportsShouldProcess=$true)]
param (
    [Parameter(Mandatory=$false)]
    [string]
    $ConnectionBroker,

    [Parameter(Mandatory=$false)]
    [switch]
    $Force
)

import-module ServerManager
import-module RemoteDesktop

# Fetch all RDSH servers in the deployment
$sessionHosts = Get-RDServer -Role RDS-RD-SERVER -ConnectionBroker $ConnectionBroker -ErrorAction Stop
if(-not $sessionHosts)
{
    Write-Error "No RD Session Host servers found in the deployment"
    return
}

$sessionHostsString = $sessionHosts.Server -Join ", "
Write-Verbose "Discovered session hosts: $sessionHostsString"

# Determine which ones don't have desktop experience installed
$toInstall = New-Object System.Collections.ArrayList
foreach($rdsh in $sessionHosts.Server)
{
    try
    {
        $desktopExp = Get-WindowsFeature -Name Desktop-Experience -ComputerName $rdsh -ErrorAction Stop

        if($desktopExp.Installed)
        {
            Write-Host "The Desktop Experience feature is already installed on $rdsh"
        }
        elseif($desktopExp.InstallState -ne [Microsoft.Windows.ServerManager.Commands.InstallState]::Available)
        {
            Write-Warning "Cannot install the Desktop Experience feature on $($rdsh): the feature does not appear to be available for installation, the InstallState is listed as '$($desktopExp.InstallState)' instead of 'Available'"
        }
        else
        {
            $toInstall.Add($rdsh.ToLower()) | Out-Null
        }
    }
    catch
    {
        Write-Warning "Cannot install the Desktop Experience feature on $($rdsh): error querying Desktop Experience feature: $_"
    }
}

if($toInstall.Count -eq 0)
{
    Write-Error "Cannot install the Desktop Experience feature: all RD Session Host servers either already have the feature installed or cannot install the feature."
    return
}

# If this server is an RD Session Host in the list, ensure it is at the end so that when we get rebooted we don't mess anything up.
if($toInstall.Count -gt 1)
{
    $localhost = [System.Net.Dns]::GetHostEntry([System.Net.Dns]::GetHostName()).HostName.ToLower()
    if($toInstall.Contains($localhost))
    {
        $toInstall.Remove($localhost)
        $toInstall.Add($localhost) | Out-Null
    }
}

# Prompt the user to ensure they want to install the feature on all of the detected RD Session Host servers
$toInstallString = $toInstall -Join ", "

$whatif = "The Desktop Experience feature will be installed on the following RD Session Host servers. Reboots will be performed if required. If this server is one of the RD Session Host servers, it will be the last server to be rebooted. RD Session Host servers: $toInstallString"
           
$message = "Are you sure you want to install the Desktop Experience feature on the following RD Session Host servers? Reboots will be performed if required. If this server is one of the RD Session Host servers, it will be the last server to be rebooted. RD Session Host servers: $toInstallString"

if(-not $PSCmdlet.ShouldProcess($whatif, $message, ""))
{
    return
}

if((-not $Force) -and (-not $PSCmdlet.ShouldContinue($message, "")))
{
    return
}

# Install the feature
foreach($rdsh in $toInstall)
{
    Write-Verbose "Installing Desktop-Experience on machine $rdsh"
    Install-WindowsFeature -Name Desktop-Experience -Restart -IncludeAllSubFeature -IncludeManagementTools -ComputerName $rdsh
}