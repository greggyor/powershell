﻿Function Convert-ImgageType
{
    <#
	.SYNOPSIS
	    Convert image file.

	.DESCRIPTION
	    The Convert-ImgageType cmdlet to convert image file to specific image format type.
		
	.PARAMETER Image
	    Specifies an image file. 

	.PARAMETER Destination
	    Specifies a destination of converted file. Default is current location (Get-Location).
	
	.PARAMETER Type
	    Specifies an image format type. Allowet are "jpg", "bmp", "emf", "gif", "ico", "png", "tif", "wmf". Default is jpg. 
		
	.PARAMETER Overwrite
	    Specifies a destination exist then overwrite it without prompt. 
		
	.PARAMETER RemoveSource
	    Remove source file after conversion. 
		
	.EXAMPLE
		PS C:\> Get-ChildItem P:\test\*.bmp | Convert-ImgageType -Destination p:\test -Verbose
		VERBOSE: Image 'P:\test\Img1.bmp' was converted to jpg and save in 'p:\test\Img1.jpg'
		VERBOSE: Image 'P:\test\Img2.bmp' was converted to jpg and save in 'p:\test\Img2.jpg'
		VERBOSE: Image 'P:\test\Img3.bmp' was converted to jpg and save in 'p:\test\Img3.jpg'
		VERBOSE: Image 'P:\test\Img4.bmp' was converted to jpg and save in 'p:\test\Img4.jpg'
		
	.NOTES
		Author: Michal Gajda
		Blog  : http://commandlinegeeks.com/
	#>
	[CmdletBinding(
    	SupportsShouldProcess=$True,
        ConfirmImpact="Low"
    )]	
	Param
	(
		[parameter(Mandatory=$true,
			ValueFromPipeline=$true,
			ValueFromPipelineByPropertyName=$true)]
		[Alias("Image")]	
		[String[]]$FullName,
		[String]$Destination = $(Get-Location),
		[ValidateSet("jpg", "bmp", "emf", "gif", "ico", "png", "tif", "wmf")]
		[String]$Type = "jpg",
		[Switch]$Overwrite,
		[Switch]$RemoveSource
	)
	
	Begin
	{
		[void][reflection.assembly]::LoadWithPartialName("System.Windows.Forms")
	} #End Begin
	
	Process
	{
		Foreach($Image in $FullName)
		{
			If(Test-Path $Image)
			{
				$img = new-object system.drawing.bitmap $Image
				$imgProperty = Get-ItemProperty $Image
				
				Switch($Type)
				{
					{$_ -eq "jpg"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Jpeg; Break}
					{$_ -eq "bmp"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Bmp; Break}
					{$_ -eq "emf"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Emf; Break}
					{$_ -eq "gif"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Gif; Break}
					{$_ -eq "ico"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Icon; Break}
					{$_ -eq "png"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Png; Break}
					{$_ -eq "tif"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Tiff; Break}
					{$_ -eq "wmf"} {$ImageFormat = [System.Drawing.Imaging.ImageFormat]::Wmf; Break}
				} #End Switch $Type
				
				$SaveLocation = Join-Path -Path $Destination -ChildPath ("$($imgProperty.BaseName).$Type")
				
				If(!$Overwrite)
				{
					If(Test-Path $SaveLocation)
					{
						$Title = "A file already exists: $SaveLocation"
							
						$ChoiceOverwrite = New-Object System.Management.Automation.Host.ChoiceDescription "&Overwrite"
						$ChoiceCancel = New-Object System.Management.Automation.Host.ChoiceDescription "&Cancel"
						$Options = [System.Management.Automation.Host.ChoiceDescription[]]($ChoiceCancel, $ChoiceOverwrite)		
						If(($host.ui.PromptForChoice($Title, $null, $Options, 1)) -eq 0)
						{
							Write-Verbose "Image '$Image' exist in destination location - skiped"
							Continue
						} #End If ($host.ui.PromptForChoice($Title, $null, $Options, 1)) -eq 0
					} #End If Test-Path $SaveLocation
				} #End If !$Overwrite	
				
			    $img.save($SaveLocation,$ImageFormat)
				$img.Dispose()
				Write-Verbose "Image '$Image' was converted to $Type and save in '$SaveLocation'"
				
				If($RemoveSource)
				{
					Remove-Item $Image -Force
					Write-Verbose "Image source '$Image' was removed"
				} #End If $RemoveSource
			} #End If Test-Path $Image
		} #End ForEach $Image in $FullName
	} #End Process
	
	End{}
} #In The End :)