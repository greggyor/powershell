#SCRIPT TITLE 	Netlogon archival
#AUTHOR 		Joji Oshima - Microsoft Corporation
#VERSION 		1.0

# Configuration Section
$loglocation 	= "c:\windows\debug\netlogon.bak" 	#location of the netlogon.bak file
$ziplocation	= "c:\temp\"						#location you want the zip files
$interval		= 15								#seconds between checks

#functions
function New-Zip
{
	param([string]$zipfilename)
	set-content $zipfilename ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
	(dir $zipfilename).IsReadOnly = $false
}

function Add-Zip
{
	param([string]$zipfilename)

	if(-not (test-path($zipfilename)))
	{
		set-content $zipfilename ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
		(dir $zipfilename).IsReadOnly = $false	
	}
	
	$shellApplication = new-object -com shell.application
	$zipPackage = $shellApplication.NameSpace($zipfilename)
	
	foreach($file in $input) 
	{ 
		$zipPackage.CopyHere($file.FullName)
		Start-sleep -milliseconds 500
	}
}

# Program Start
$last 			= (get-item $loglocation).lastwritetime
$computer		= gc env:computername

# Loop until you cancel
do 
{
	$latest 	= (get-item $loglocation).lastwritetime
	$now		= get-date
	cls
	Write-Host "`n"
	Write-Host " WARNING: This script sample is provided AS-IS with no warranties and confers no rights." -ForegroundColor Yellow 
	Write-Host "          This script sample is NOT intended for production use." -ForegroundColor Yellow 
	Write-Host "          There is NO error handling and is not ready for mission-critical work." -ForegroundColor Yellow 
	Write-Host "`n This script sample will attempt to archive the netlogon debug logs`n" 
	Write-Host "`n Press CTRL-C to stop the script.`n" -ForegroundColor Yellow 
	Write-Host " Last Checked: $now" -ForegroundColor Green 
	$now = $now.AddSeconds($interval)
	Write-Host " Next Check:   $now" -ForegroundColor Green
	
	Write-Host " ---------------------------------" -ForegroundColor Green
	if ($last -eq $latest) 
	{
		Write-Host " No change`n" -ForegroundColor Green
		$latest
		$last
	}
	else 
	{
		Write-Host " Change detected! Archiving $loglocation`n" -ForegroundColor Yellow
		$latest
		$last
		$last 	= $latest
		$year 	= $latest.Year
		$month 	= $latest.Month
		$day 	= $latest.Day
		$hour 	= $latest.Hour
		$minute = $latest.Minute
		$second = $latest.Second
		
		new-zip $ziplocation"$computer netlogon $year-$month-$day H$hour M$minute S$second.zip"
		dir $loglocation | add-zip $ziplocation"$computer netlogon $year-$month-$day H$hour M$minute S$second.zip"
	}
	
	Start-Sleep -s $interval
} until ($last -eq 0)

