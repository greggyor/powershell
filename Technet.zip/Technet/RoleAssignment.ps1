﻿#    '===================================================================
#    ' DISCLAIMER:
#    '-------------------------------------------------------------------
#    '
#    ' This sample is provided as is and is not meant for use on a 
#    ' production environment. It is provided only for illustrative 
#    ' purposes. The end user must test and modify the sample to suit 
#    ' their target environment.
#    ' 
#    ' Microsoft can make no representation concerning the content of 
#    ' this sample. Microsoft is providing this information only as a 
#    ' convenience to you. This is to inform you that Microsoft has not 
#    ' tested the sample and therefore cannot make any representations 
#    ' regarding the quality, safety, or suitability of any code or 
#    ' information found here.
#    ' 
#    '===================================================================

$AppPrefix = "Apps"


$TSEnv = New-Object -ComObject "Microsoft.SMS.TSEnvironment"
$RoleMap = Import-Csv "RoleAssignment.csv"
$Role = $TSEnv.Value("Department")

[Int32] $iCount = 1

ForEach($Assignment in $RoleMap)
{
    if($Assignment.Department -eq $Role)
    {
        $Package = $Assignment.Package
        $Program = $Assignment.Program

        if($iCount -lt 10)
        {
            $TSEnv.Value("$AppPrefix" + "00" + "$iCount") = "$Package" + ":" + "$Program"
        }
        elseif($iCount -lt 100)
        {
            $TSEnv.Value("$AppPrefix" + "0" + "$iCount") = "$Package" + ":" + "$Program"
        }
        elseif($iCount -lt 1000)
        {
            $TSEnv.Value("$AppPrefix" + "$iCount") = "$Package" + ":" + "$Program"
        }
    }
}