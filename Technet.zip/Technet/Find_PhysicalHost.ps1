#Identifies the Physical Host information of a Virtual Server
#If a physical hostname is given, provides System information of that server
#By Sravan kumar S 

function Pause ($Message="Press any key to continue..."){ 
    "" 
    Write-Host $Message 
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 
}

function GetCompName{ 
  Do { $Env = Read-host "`nEnter a computer name" } while ($Env -eq "")
        checkhost
     } 
 
function CheckHost{ 
    $ping = gwmi Win32_PingStatus -filter "Address='$Env'" 
    if($ping.StatusCode -eq 0)
    {
      $pcip=$ping.ProtocolAddress; 
      Getdata
     } 
    else{Pause "'$Env' is not reachable...Press any key to continue"; reattempt} 
} 
     
 function Getdata {

         $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$Env)  
         $regKey= $reg.OpenSubKey('SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters')
         if(!$regkey)
         {
          write-host " `n$Env is Not a virtual Machine"
          sysinfo
         }
         else
         { 
            $PFQDN= $regkey.GetValue('PhysicalHostNameFullyQualified')
						Write-host "Physical hostname is $PFQDN";
          }      	
		
      }  
  function sysinfo {
         gwmi -computer $Env Win32_ComputerSystem | Format-List Name,Domain,Manufacturer,Model,SystemType 
            Pause 
                      
          }         
 function reattempt {
      $MenuSelection = Read-Host "`nTo try again press 1, to Exit press 2"
      switch ($MenuSelection){ 
        1 { GetCompName }
        2 { exit } } }
       
$Env = $args[0] 
if($Env){CheckHost} 
else{GetCompName}  	 
      

