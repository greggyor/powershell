﻿param (
    [Parameter(Mandatory=$TRUE, HelpMessage="FQDN of RD Web Access\RD Connection Broker and RD Virtualization host roles")]
    [String]
    $serverName,

    [Parameter(Mandatory=$TRUE, HelpMessage="Domain name to be used for new desktops created")]
    [String]
    $domain
)

# Import the RemoteDesktop module
Import-Module RemoteDesktop

# Create a new RDS deployment
New-RDVirtualDesktopDeployment -ConnectionBroker $serverName `
   -WebAccessServer $serverName `
   -VirtualizationHost $serverName
Write-Verbose "Created new RDS deployment on: $serverName"

Grant-RDOUAccess -Domain $domain  -OU "Computers" -ConnectionBroker $serverName

# Create a new pooled managed desktop collection
New-RDVirtualDesktopCollection -CollectionName demoPool -PooledManaged `
   -VirtualDesktopTemplateName Win7Gold `
   -VirtualDesktopTemplateHostServer $serverName `
   -VirtualDesktopAllocation @{$serverName = 1} `
   -StorageType LocalStorage `
   -ConnectionBroker $serverName `
   -VirtualDesktopNamePrefix msVDI
  

   