﻿# extract logs for Project Server log level manager from ULS logs for the specified day

$Date = get-date -format "yyyyMMdd" 

$files = Get-ChildItem "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\15\LOGS" | where-object {$_ -like "*$Date*"}
foreach ($file in $files)
{
    get-content -path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\15\LOGS\$file" | where-object { $_ -match 'LogLevelManager!'} | Out-File C:\PSLog$Date.txt -append
} 