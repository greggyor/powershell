Function Get-UninstallString
{
<#
.SYNOPSYS
Get-Uninstall string provides the DisplayName, Publisher and UninstallString for all software listed in the registry

.DESCRIPTION
Get-Uninstall will query the x64 and x86 registry nodes in order to list out all installed software and there associated uninstall stings.  By default information is displayed as a table in a custom PSObject.

.PARAMETER ComputerName

.EXAMPLE
Get-UninstallString

Product   : VMware Tools
Company   : VMware, Inc.
Computer  : LABTOOLS
Uninstall : MsiExec.exe /X{44D55920-B223-4702-81D9-4C07108A3C27}
Version   : 9.2.2.18018

Product   : Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.6161
Company   : Microsoft Corporation
Computer  : LABTOOLS
Uninstall : MsiExec.exe /X{5FCE6D76-F5DC-37AB-B2B8-22AB8CEDB1D4}
Version   : 9.0.30729.6161

Product   : Microsoft Visual C++ 2008 Redistributable - x86 9.0.30729.4148
Company   : Microsoft Corporation
Computer  : LABTOOLS
Uninstall : MsiExec.exe /X{1F1C2DFC-2D24-3E06-BCB8-725134ADF989}
Version   : 9.0.30729.4148

.EXAMPLE
Get-UninstallString | Format-Table

Product                      Company                      Computer                    Uninstall                   Version                    
-------                      -------                      --------                    ---------                   -------                    
VMware Tools                 VMware, Inc.                 LABTOOLS                    MsiExec.exe /X{44D55920-... 9.2.2.18018                
Microsoft Visual C++ 2008... Microsoft Corporation        LABTOOLS                    MsiExec.exe /X{5FCE6D76-... 9.0.30729.6161             
Microsoft Visual C++ 2008... Microsoft Corporation        LABTOOLS                    MsiExec.exe /X{1F1C2DFC-... 9.0.30729.4148

.EXAMPLE
Get-content c:\servers.txt | Get-UninstallString

Gets the uninstallstring information for a list of computers specified in the file servers.txt

#>
[CmdletBinding()]
Param
    (
    [parameter(
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True
    )][String[]]$ComputerName = $env:COMPUTERNAME
    )
Begin 
    {
    $param = @{ScriptBlock = {`
        if ((Get-WmiObject win32_operatingsystem -ComputerName $ComputerName).OSArchitecture -notlike '64-bit') {$keys= (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*')}
        else {$keys = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')} 
        $Keys |
        Where-Object {$_.Publisher -or $_.UninstallString -or $_.displayversion -or $_.DisplayName} |
        ForEach-Object {
            New-Object -TypeName PSObject -Property @{
                Computer = $env:COMPUTERNAME
                Company = $_.Publisher
                Uninstall = $_.UninstallString
                Version = $_.displayversion
                Product = $_.DisplayName
                }
            }
        }
        }
    }
Process
    {
    If (Test-Connection $ComputerName -Quiet -Count 2) {
        If ($ComputerName -ne $env:COMPUTERNAME) {$param.Add("ComputerName",$ComputerName)}            
        Invoke-Command @param
        }
    Else { "The Computer, $ComputerName, is not online" }
    }
End {}
}