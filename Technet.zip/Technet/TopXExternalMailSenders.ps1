﻿# Load .Net Chart Control Assemblies 
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")

# create chart object 
$Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
$Chart.Width = 800 
$Chart.Height = 700 
$Chart.Left = 40 
$Chart.Top = 30

# create a chartarea to draw on and add to chart 
$ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea 
$Chart.ChartAreas.Add($ChartArea)

# number of senders to include in the chart
$topXsenders = 10

# set number of days to report on - Note: must have this many days of message tracking logs available on your hub transport server(s)
$days = 7

# set start date
$start = (Get-Date -Hour 00 -Minute 00 -Second 00).AddDays(-$days)

# set end date
$end = (Get-Date -Hour 23 -Minute 59 -Second 59).AddDays(-1)

# add title and axes labels
[void]$Chart.Titles.Add("Top " + $topXsenders +  " External Mail Senders - Previous " + $days + " Days" + "`n" + (Get-Date($start) -Format F) + " to " + (Get-Date($end) -Format F)) 
$ChartArea.AxisX.Title = "Users"
$ChartArea.AxisX.Interval = 1
$ChartArea.AxisX.LabelStyle.Angle = -30
$ChartArea.AxisY.Title = "Messages Sent"

$script:WarningPreference = "SilentlyContinue"

$senders = @{}
Get-TransportServer | Get-MessageTrackingLog -EventID Send -Start $Start -End $End -resultsize unlimited | ForEach-Object {
	if ($senders.ContainsKey($_.Sender)){
		$senders.Set_Item($_.Sender,$senders.Get_Item($_.Sender)+1)
	} else {
		$senders.Add($_.Sender,1)
	}
}

# sort the senders list in descending order and select the top number of senders to include in the chart
$topSenders = $senders.GetEnumerator() | Sort-Object Value -descending | Select-Object -First $topXsenders

# set x and y axis arrays
$senders = @(foreach($sender in $topSenders){$sender.Name})
$messageCount = @(foreach($sender in $topSenders){$sender.Value})

[void]$Chart.Series.Add("Data")
$Chart.Series["Data"].Points.DataBindXY($senders, $messageCount)

# make bars into 3d cylinders 
$Chart.Series["Data"]["DrawingStyle"] = "Cylinder"

# display the chart on a form in a popup window
$Chart.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor 
                [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left 
$Form = New-Object Windows.Forms.Form 
$Form.Text = "PowerShell Chart" 
$Form.Width = 900 
$Form.Height = 800 
$Form.controls.add($Chart)

# save chart to file
$path = Split-Path -parent $MyInvocation.MyCommand.Definition
$Chart.SaveImage($path + "\TopXExternalSenders.png", "PNG")

$Form.Add_Shown({$Form.Activate()}) 
$Form.ShowDialog()
