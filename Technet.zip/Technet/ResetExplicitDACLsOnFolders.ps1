﻿#Set generic objects
$colRights = [System.Security.AccessControl.FileSystemRights]"ReadAndExecute"
$objType =[System.Security.AccessControl.AccessControlType]::Allow 

New-PSDrive -Name Z -PSProvider Filesystem -Root "\\SERVERNAME\DRIVELETTER$\ROOTPATH\"
Set-Location "z:\"
$folderlist = Get-ChildItem "z:\"
foreach ($folder in $folderlist) {
	$ACLlist = Get-Acl $folder
	foreach ($acl in $ACLlist.access) {
		$InheritanceFlag = $acl.InheritanceFlags
		$PropagationFlag = $acl.PropagationFlags
		$objuser = $acl.IdentityReference
		
		$objACE = New-Object System.Security.AccessControl.FileSystemAccessRule `
    	($objUser, $colRights, $InheritanceFlag, $PropagationFlag, $objType)
		$ACLlist.SetAccessRule($objACE)
		$folder.SetAccessControl($ACLlist)
		
		}
	$folder.GetAccessControl() | fl
	}