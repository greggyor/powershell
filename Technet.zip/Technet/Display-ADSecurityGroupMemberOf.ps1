<# 
================================================================================
PURPOSE:	Display Nested AD Security Groups

AUTHORS:	Axel Limousin
VERSION:	1.1 
DATE:		04/20/2013 

SYNTAX:		Get-ADGroup <GroupDN>
			| Display-ADSecurityGroupMemberOf [-RL <integer>] `
			[-PI {<Absolut> | <Relative> | <Domain>}] `
			[-LC <string>] [-DC <string>] [-UC <string>] 

EXAMPLE:	Get-ADGroup "CN=MyGroup,OU=MyOU,DC=MyDom,DC=MyRoot"
			| Display-ADSecurityGroupMemberOf

THANKS:		Thomas Corbiere
================================================================================
#>

function Display-ADSecurityGroupMemberOf {
	
	param (
	
		[Parameter(ValueFromPipeline = $true, Mandatory = $true)]
		[Microsoft.ActiveDirectory.Management.ADGroup] $ADSGroup,
		
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[Alias("RL")]
		[Byte] $MaximumRecursionLevel = 5,
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[Alias("CL")]
		[Byte] $CurrentRecursionLevel = 0,
		
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[Alias("PI")]
		[ValidateSet("Absolut", "Relative", "Domain")]
		[String] $PathInfo = "Relative",
		
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[Alias("LC")]
		[ConsoleColor] $DomainLocalColor = "Red",
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]	
		[Alias("GC")]
		[ConsoleColor] $GlobalColor = "Green",
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]	
		[Alias("UC")]
		[ConsoleColor] $UniversalColor = "Cyan"
	)
	
	begin {
	
		$GroupColor = {
			
			param (
				
				[Microsoft.ActiveDirectory.Management.ADGroupScope] $GroupScope
			)

			switch ($GroupScope) {
			
				"DomainLocal" { return $DomainLocalColor }
				"Global"      { return $GlobalColor }
				"Universal"   { return $UniversalColor }
			}
		}
	}

	process { 
	
		if ($CurrentRecursionLevel -ge $MaximumRecursionLevel) {
        	
			return
    	}
		
		if ($ADSGroup.GroupCategory -eq "Security") {

    		$paddingText = "  " * $CurrentRecursionLevel

    		"{0}|_ {1}" -f $paddingText, $ADSGroup.Name | Write-Host `
			-ForegroundColor (&$GroupColor $ADSGroup.GroupScope)
		
			$CName = "CN="+$ADSGroup.Name
			$Absolut = $ADSGroup.DistinguishedName.Remove(0,$CName.Length+1)
			$Relative = $Absolut.Remove($Absolut.IndexOf(",DC="))
			$Domain =  $Absolut.Remove(0,$Relative.Length+1)
		
			switch ($PathInfo) {
				
				"Absolut"{
					"{0}   {1}" -f $paddingText, $Absolut | Write-Host
				}
				"Relative" {
					"{0}   {1}" -f $paddingText, $Relative | Write-Host
				}
				"Domain"{
					"{0}   {1}" -f $paddingText, $Domain | Write-Host
				}
			}
    	
			(Get-ADGroup -Properties MemberOf `
			$ADSGroup.DistinguishedName).MemberOf `
			| ForEach-Object -Process {
				Get-ADGroup $_ `
				| Display-ADSecurityGroupMemberOf -RL $MaximumRecursionLevel `
				-CL ($CurrentRecursionLevel+1) -PI $PathInfo `
				-LC $DomainLocalColor -GC $GlobalColor -UC $UniversalColor 
			}
		}
		
		elseif ($CurrentRecursionLevel -eq 0) { 
			
			Write-Warning -Message "Please select only Security Group"
		} 
	}
}