﻿<#
	Script to find out Registry information for Disk Timeouts
	Writen by G Taylor
	Version 1.0
#>

<#	Get list of computers to check #>
$serverlist = Get-Content -Path 'C:\scripts\SAN_server_list.txt'

<#	For each server, connect and get timeout information #>
foreach ($server in $serverlist)
{
	#Write-Host "Getting Reg info for $server"
	$serverpath = "\\" + $server + "\c$"
	if (Test-Path -Path $serverpath)
	{
		$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('localmachine',$server)
		$regkey = $reg.opensubkey("system\currentcontrolset\services\disk\")
		$Disktimeout = $regkey.getvalue("timeoutvalue")
		#$sanresults = $server $Disktimeout
		Write-Host $server $Disktimeout
		#add-Content -Path 'c:\scripts\SAN_server_results.txt' $server $disktimeout #$sanresults
	}
	else
	{
		if (Test-Connection -ComputerName $server -Count 1 -Quiet)
		{
			write-host "+++ $Server is not acessable/non-windows server"
		}
		else
		{
			Write-Host "+++ $server is not on network/behind firewall"
		}
	}
}