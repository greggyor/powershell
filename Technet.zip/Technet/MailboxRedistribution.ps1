<#
.NOTES
    Name: MailboxRedistribution
    Author: Daniel Sheehan
    Requires: PowerShell V2, Exchange 2007 PSSnapin.
    Version History:
    1.0 - 6/1/2011 - Initial Release.
.SYNOPSIS
    Migrates Exchange 2007 mailboxes in multiple simultaneous jobs.
.DESCRIPTION
    This script will maximize mailbox moves in Exchange 2007 by grouping
    mailbox moves by target database to utilize the MaxThreads option, but
    also allows splitting the multiple move mailbox sessions into separate
    processes to increase the throughput as well.
    For the mailbox move reporting aspect of this script, reference the
    following URL:
    http://www.mikepfeiffer.net/2010/04/how-to-audit-exchange-2007-mailbox-moves-using-powershell/
.EXAMPLE  
    [PS] C:\>.\MailboxRedistribution.ps1 <no parameters>
#>

# Add the Exchange Management Shell snap-in, and if it is already loaded then don't display an error message.
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin -ErrorAction "SilentlyContinue"

# --Set some variables to be used later in the script--
# Set the log path to the local Exchange migration logs folder (cannot use $exinstall in a scheduled task).
$LogPath = "C:\Program Files\Microsoft\Exchange Server\Logging\MigrationLogs�
# Select a group of users to re-distribute to the target databases.
$MovingMailboxes = Get-DistributionGroupMember GroupOfUsersBeingMO
# Specify the number of jobs to split the target database moves into.
$JobSplit = 4
# Specify the Source and Target mailbox servers.
$MailboxServers = @("EXCHMBX1","EXHCMBX2","EXHCMBX3","EXHCMBX4","EXHCMBX5")
# Determine the target databases by querying just the mailbox databases with "MBX*" in the name, which avoids 
#   other servers with a mailbox database, and skips recovery databases, databases not mounted, and MBX5 databases.
$TarDatabases = Get-MailboxDatabase -status | Where {($_.Name -like "MBX*") -and ($_.Recovery -eq $False) `
	-and ($_.Mounted -eq "True") -and ($_.Name -notlike "MBX5*")} | Sort-Object Name

# Check to see if the Old folder exists in the migration logs folder, and if not create it.
If (!(Test-Path -Path $LogPath\Old)) {New-Item $LogPath\Old -Type directory | Out-Null}

# If there are any existing log or CSV files from previous migrations, and move them to a sub folder named "OLD".
Get-ChildItem $LogPath -Filter *.log | Move-Item -Destination $LogPath\Old
Get-ChildItem $LogPath -Filter *.xml | Move-Item -Destination $LogPath\Old
Get-ChildItem $LogPath -Filter *.CSV | Move-Item -Destination $LogPath\Old

# Run the following remote Powershell script on the SCOM management server to deactive Forefront Realtime Scan 
#   monitoring in SCOM.
Invoke-Command -ComputerName EXHCSCOM2 -filepath \\EXHCSCOM2\C$\SCRIPTS\DisableSCOMFFRTS.ps1

# Run the following remote Powershell commands on the mailbox servers to deactive Forefront Realtime Scanning so
#   that mailboxes being moved aren't re-scanned by antivirus on the new server which would slow down the process
#   and potentially apply new content filters to very old data that has been in the mailbox for a long time. 
Foreach ($MailboxServer in $MailboxServers) {
    Invoke-Command -ComputerName $MailboxServer -ScriptBlock {
        Add-PSSnapin fssp*
        Set-FSERealtimeScan -Bypass $True
    }
}

# Create a DataTable to host the mailbox data, and create columns by defining their name and attribute type.
$MBXDBTable = New-Object System.Data.DataTable �MBXDatabaseTable�
# Create a column named DataBase to hold the name of the database and make it a primary and unique key.
$MBXDBTable.Columns.Add("DataBase") | Out-Null
$MBXDBTable.Columns["DataBase"].Unique = $true
$MBXDBTable.PrimaryKey = $MBXDBTable.Columns["DataBase"]
# Create a column named ActiveSTDMBs to keep a count of all standard size mailboxes in the DB.
$MBXDBTable.Columns.Add("ActiveSTDMBs",[Int]) | Out-Null
# Create a column named ActiveLRGMBs to keep a count of all large size mailboxes in the DB.
$MBXDBTable.Columns.Add("ActiveLRGMBs",[Int]) | Out-Null
# Create a column named ActiveALLMBs to keep a count of all mailboxes in the DB.
$MBXDBTable.Columns.Add("ActiveALLMBs",[Int]) | Out-Null
# Create a column named MailboxMoves to a list of all mailboxes to be moved to the database.
$MBXDBTable.Columns.Add("MailboxMoves",[Array]) | Out-Null

# Set the loop count to 0 to be used with a progress bar.
$LoopCount=0
# Loop through each database in the TarDatabases query defined at the start of the script.
Foreach ($TarDatabase in $TarDatabases) {
    # Show a status bar for progress while data is collected.
    $PercentComplete = [Math]::Round(($LoopCount++ / $TarDatabases.Count * 100),1)
    $CurrentDB = $TarDatabase.Name
    Write-Progress -Activity "Mailbox Database Query in Progress" -PercentComplete $PercentComplete `
        -Status "$PercentComplete% Complete" -CurrentOperation "Current Database: $CurrentDB"
    # Define the query which which finds every mailbox in the database.
    $TarDBInfo = Get-Mailbox -Database $TarDatabase 
    # Set the initial values to 0 for each database being processed.
    $TotalActiveSTDMBs = 0
    $TotalActiveLRGMBs = 0
    # Loop through each mailbox in the database checking to see if it is a large mailbox or not.
    Foreach ($MBXInfo in $TarDBINfo) {
		If ($MBXInfo.UseDatabaseQuotaDefaults -eq $true) {
			# It's a standard mailbox size so increment that number.
			$TotalActiveSTDMBs++
		} Else {
			# It's a large mailbox size so increment that number.
			$TotalActiveLRGMBs++
		}
	}
    # Add the gathered information to a new row in the table.
    $NewDTRow = $MBXDBTable.NewRow()
	$NewDTRow.DataBase = $TarDatabase
    $NewDTRow.ActiveSTDMBs = $TotalActiveSTDMBs
    $NewDTRow.ActiveLRGMBs = $TotalActiveLRGMBs
    # Add both values together to create the total mailbox count.
	$NewDTRow.ActiveALLMBs = ($TotalActiveSTDMBs + $TotalActiveLRGMBs)
	$NewDTRow.MailboxMoves = @()
 	$MBXDBTable.Rows.Add($NewDTRow)
}
# Close out the progress bar cleanly.
Write-Progress -Activity "Mailbox Database Query in Progress" -Completed -Status "Completed"

# Select a group of users to re-distribute and then launch into the ForEach Loop.
$MovingMailboxes | ForEach {
	$MovingMailbox = Get-Mailbox $_.Identity
	# Choose the optimal database by sorting the mailbox databases depending on the mailbox being the default size or not.
	If ($MovingMailbox.UseDatabaseQuotaDefaults -eq $True) {
		# If the Mailbox is the default size, sort the databases by the total number of mailboxes, and if there are several
		#   at the same count then pick the one with the least large mailboxes. Also avoid putting any users with a 
        #   BlackBerry PIN (CustomAttribute 7 variable of 8 characters) on MBX1 since it has a disperportional amount of
        #   BlackBerry users.
		If ($MovingMailbox.CustomAttribute7.Length -ne 8) {
            $OptimalDB = ($MBXDBTable | Sort-Object ActiveALLMBs,ActiveLRGMBs | Select -First 1)
        } Else {
            $OptimalDB = ($MBXDBTable | Where {$_.Database -notlike "EXHCMBX1*"} | Sort-Object ActiveALLMBs,ActiveLRGMBs | Select -First 1)
        }
	} Else {
		# If the Mailbox is large size, sort the databases by the number of large mailboxes, and if there are several
		#   at the same count then pick the one with the least total mailboxes.  Also avoid putting any users with a 
        #   BlackBerry PIN (CustomAttribute 7 variable of 8 characters) on MBX1 since it has a disperportional amount of
        #   BlackBerry users.
		If ($MovingMailbox.CustomAttribute7.Length -ne 8) {
            $OptimalDB = ($MBXDBTable | Sort-Object ActiveLRGMBs,ActiveALLMBs | Select -First 1)
        } Else {
            $OptimalDB = ($MBXDBTable | Where {$_.Database -notlike "EXHCMBX1*"} |  Sort-Object ActiveLRGMBs,ActiveALLMBs | Select -First 1)
        }
	}
	$MBXDBTable.Rows.Find($OptimalDB.Database).ActiveALLMBs++
	$MBXDBTable.Rows.Find($OptimalDB.Database).MailboxMoves += $MovingMailbox.PrimarySmtpAddress.ToString()
	If ($MovingMailbox.UseDatabaseQuotaDefaults -eq $true) {
		$MBXDBTable.Rows.Find($OptimalDB.Database).ActiveSTDMBs++
	} Else {
		$MBXDBTable.Rows.Find($OptimalDB.Database).ActiveLRGMBs++
	}
}

# Create an Array of the mailbox databases that have mailboxes assigned to be moved to them.
$MBXMoveArray = $MBXDBTable | Where-Object {$_.MailboxMoves -ne $Null} | Select Database,MailboxMoves
# Calculate the number of databases with users assigned to be moved to them, and then device the number by the JobSplit 
#   number defined above. This new number represents the number of sequential target database moves in each JobSplit.
$MovesPerJob = [Math]::Round($MBXMoveArray.Count / $JobSplit)
# Set the first database grouping to start at the array entry 0 since that is the first entry in an array.
$MBXMoveArrayStart = 0
# Set the first database grouping to end at the number of MovesPerArray -1 because an array starts on line 0 and not 1.
$MBXMoveArrayEnd = ($MovesPerJob -1)
# Set the JobCount to 1 so the script can keep track of how many jobs it has kicked off.
$JobCount = 1
While ($JobCount -le $JobSplit) {
    $JobName = "MoveJob" + $JobCount
    Write-Host -ForegroundColor Yellow "Working on job $JobCount with the array start of $MBXMoveArrayStart and the array end of $MBXMoveArrayEnd."
    Start-Job -Name $JobName `
    -InitializationScript {Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin -ErrorAction "SilentlyContinue"} `
    -ScriptBlock {
        # Grab the parameters passed into the script block from down below.
        Param($MBXMoveArray,$MBXMoveArrayStart,$MBMXMoveArrayEnd)
        # Move the users to their destined database in a large group of up to 10 simultaneously per target database.
        $MBXMoveArray[$MBXMoveArrayStart..$MBMXMoveArrayEnd] |  ForEach {
    	    $TargetDB = $_.Database
            $_.MailboxMoves | Move-Mailbox -TargetDatabase $TargetDB -BadItemLimit 50 -PreserveMailboxSizeLimit:$True -MaxThreads:10 -Confirm:$False
        }
    # Pass the parameters from the script into the script block.
    } -ArgumentList ($MBXMoveArray,$MBXMoveArrayStart,$MBXMoveArrayEnd)
    # Increment the job count by 1 for the calculations below.
    $JobCount++
    # Set the starting point in the Array for the next job to the line after the last run.
    $MBXMoveArrayStart = ($MBXMoveArrayEnd + 1)
    # If the next job will be the final run in the JobSplit, then just set the end point to the final line in the Array.
    If ($JobCount -eq $JobSplit) {
        $MBXMoveArrayEnd = $MBXMoveArray.Count
    # Otherwise set the Array end point to the MovesPerArray increment -1 (since the Array starts on line 0).
    } Else { 
        $MBXMoveArrayEnd = ($MBXMoveArrayStart + ($MovesPerJob - 1))
    }
} 

# Loop in the script until all of the spawned jobs have reached the status of Completed.
While ((Get-Job -Name MoveJob* | Where {$_.State -eq "Completed"}).Count -lt $JobSplit) {
    Write-Host -ForegroundColor Blue "Waiting on all jobs to reach a Completed status. Sleeping for 60 seconds."
    Start-Sleep -Seconds 60
}

# All jobs have reported as Completed, so remove them and proceed with the rest of the script.
Write-Host -ForegroundColor Green "All jobs have reported a Completed status!"
Get-Job -Name MoveArray* | Remove-Job

# Sleep for 1 minute to give time AD time to replicate the changes before attempting to generate the report since
#   we need to pull some mailbox statistics for the report.
Start-Sleep -Seconds 60

# Build an array of all the resultant migration XML files in the migraiton logs folder.
$XMLReports = @()
ForEach ($XMLFile in Get-ChildItem $LogPath -Filter move*.xml ) {
    $XMLReports += [xml](Get-Content $XMLFile.fullname)
} 

# Build a datatable to hold the results of the migration logs.
$MoveResults = New-Object system.Data.DataTable �MoveResults�
$MoveResults.Columns.Add("Mailbox",[String]) | Out-Null
$MoveResults.Columns.Add("PrimarySMTPAddress",[String]) | Out-Null
$MoveResults.Columns.Add("TargetDatabase",[String]) | Out-Null
$MoveResults.Columns.Add("ErrorCode",[String]) | Out-Null
$MoveResults.Columns.Add("MailboxSizeMB",[String]) | Out-Null
$MoveResults.Columns.Add("ItemCount",[String]) | Out-Null
$MoveResults.Columns.Add("StartTime",[String]) | Out-Null
$MoveResults.Columns.Add("EndTime",[String]) | Out-Null
$MoveResults.Columns.Add("Duration",[String]) | Out-Null
$MoveResults.Columns.Add("DurationInSec",[String]) | Out-Null
$MoveResults.Columns.Add("SpeedInKBps",[Int]) | Out-Null
$MoveResults.Columns.Add("IsWarning",[String]) | Out-Null
$MoveResults.Columns.Add("MovedBy",[String]) | Out-Null            

# Parse thorugh each XML file in the array, and record the information for each mailbox moved therein.
$XMLReports | %{
    $TargetDB = (Get-MailboxDatabase $_."move-Mailbox".TaskHeader.Options.TargetDatabase).Name
    $MovedBy = $_."move-Mailbox".TaskHeader.RunningAs
    $StartTime = $_."move-Mailbox".TaskHeader.StartTime
    $EndTime = $_."move-Mailbox".TaskFooter.EndTime
    $Result = $_."move-Mailbox".taskdetails.item | %{
    $TempMBSize = $_.MailboxSize
        # Normalize the mailbox size depending on how it was stored in the XML file so that all of the mailbox sizes
        #   are reported the same way.
        If ($TempMBSize.EndsWith("KB")) {
            [Int]$MailboxSize = $TempMBSize.Substring(0,($TempMBSize.Length - 2))
            $MailboxSize = $MailboxSize * 1024
        } Elseif ($TempMBSize.EndsWith("MB")) {
            [Int]$MailboxSize = $TempMBSize.Substring(0,($TempMBSize.Length - 2))
            $MailboxSize = $MailboxSize * 1024 * 1024
        } Elseif ($TempMBSize.EndsWith("GB")) {
            [Int]$MailboxSize = $TempMBSize.Substring(0,($TempMBSize.Length - 2))
            $MailboxSize = $MailboxSize * 1024 * 1024 * 1024
        } Else {
            $MailboxSize = $TempMBSize
        }
        # Calculate the speed of the mailbox move.
        # Set the Speed to Null in case the XML file doesn't have the duration set.
        $TimeSpan = $Null
        # Set the Speed to Null in case the XML file doesn't have the duration set.
        $Speed = $Null 
        # If the duration is set in the XML file, then calculate the speed of the mailbox transfer.
        If ($_.Duration) {
            # Split the duration up using the . and : characters as a delimiter.
            $Time = $_.Duration.Split(�.:�)
            If ($Time.Count -eq 4) {$TimeSpan = New-Timespan -Days $Time[0] -Hours $Time[1] -Minutes $Time[2] `
              -Seconds $Time[3]}
            If ($Time.Count -eq 3) {$TimeSpan = New-Timespan -Hours $Time[0] -Minutes $Time[1] -Seconds $Time[2]}
            $Speed = $MailboxSize / $TimeSpan.TotalSeconds
        } 
        # Add the gathered information to a new row in the table.
        $NewDTRow = $MoveResults.NewRow()
        $NewDTRow.Mailbox = $_.MailboxName
        $NewDTRow.PrimarySMTPAddress = $_.Source.PrimarySmtpAddress
        $NewDTRow.TargetDatabase = $TargetDB
        $NewDTRow.ErrorCode = $_.Result.ErrorCode
        # Take the total mailbox size in bytes, and devide it by 1024 twice to get a size in MB, and then round 
        #   off the nubmer.
        $NewDTRow.MailboxSizeMB = [Math]::Round($MailboxSize / 1024 / 1024)
        # Since the migration logs don't record the number of items in the mailbox, query the mailbox itself.
        $NewDTRow.ItemCount = (Get-MailboxStatistics $_.Source.PrimarySmtpAddress).ItemCount
        $NewDTRow.StartTime = $StartTime
        $NewDTRow.EndTime = $EndTime
        $NewDTRow.Duration =  $_.Duration
        $NewDTRow.DurationInSec = $TimeSpan.TotalSeconds
        # Take the Speed and devide by 1024 to get the speed in KB.
        $NewDTRow.SpeedInKBps = ($Speed/1024)
        $NewDTRow.IsWarning = $_.Result.IsWarning
        $NewDTRow.MovedBy = $MovedBy
        $MoveResults.Rows.Add($NewDTRow)    
    }
}
# Create a CSV file name with the current date in the file name.
$CSVReport = $LogPath + "\MailboxMove" + (Get-Date -Format "MM-dd-yyyy") + ".CSV"
# Export the mailbox move results to the CSV.
$MoveResults | Export-Csv -NoTypeInformation $CSVReport

# Run the following remote Powershell commands on the various mailbox servers to activate Forefront Realtime Scanning.
Foreach ($MailboxServer in $MailboxServers) {
    Invoke-Command -ComputerName $MailboxServer -ScriptBlock {
        Add-PSSnapin fssp*
        Set-FSERealtimeScan -Bypass $False
    }
}

# Run the following remote Powershell script on the SCOM management server to enable Forefront Realtime Scan monitoring in SCOM.
Start-Sleep -Seconds 15
Invoke-Command -ComputerName EXHCSCOM2 -filepath \\EXHCSCOM2\C$\SCRIPTS\EnableSCOMFFRTS.ps1

# Check to see if any of the mailboxes were set to use individual storage limits of 0 even though they were set to use the
#   default database storage limits and set those sub-values back to Unlimited. This seems to happen on disabled mailboxes 
#   and messes up the billing report which expects to see Unlimited on mailboxes using the database default limits.
$MovingMailboxes | Get-Mailbox | Where {($_.UseDatabaseQuotaDefaults -eq $True) -and ($_.IssueWarningQuota -like 0)} | `
Set-Mailbox -IssueWarningQuota Unlimited -ProhibitSendQuota Unlimited -ProhibitSendReceiveQuota Unlimited

# Capture the date and time in a variable using the "Nov 11/01/2010 6:00 AM" format.
$DateTime = Get-Date -Format "ddd MM/dd/yyyy h:mm tt"

# Construct an HTML based email message summarizing all the work the script has performed. Begin by formatting the email 
#   subject line to include the $DateTime variable.
$EmailSubject = "Mailbox migration completed at $DateTime."
# Check to see if there were any errors in the migration, and if there were change the ErrorState variable from False 
#   to True.
$ErrorState = "False"
$MoveResults | ForEach {
    If ($_.ErrorCode -ne "0") {
        $ErrorState = "True" 
    }
}
# Set the message body contents according to if there were any errors in the migration or not.
If ($ErrorState -eq "True") {
    $EmailBody = "There was one or more errors in the migration, please check the attached CSV."
} Else {
    $EmailBody = "There were no errors in the migration."
}
# Prep the body of the email message with table styles to control the formatting of any tables present it it.
Send-MailMessage -Subject $EmailSubject -From "Postmaster@company.com" -To "Postmaster@company.com" -Body $EmailBody `
    -Attachments $CSVReport -SmtpServer "smtprelay.company.com"