﻿# To Get the VM data with Snapshot, Datastore, Total Disk Size, Cluster Name, OS Name
Set-ExecutionPolicy Remotesigned -force
if (-not (Get-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue)) {
Add-PSSnapin VMware.VimAutomation.Core}
$VC1 = read-host "Type the VC name"
$date = Get-Date -DisplayHint DateTime -Format "yyyy-M-d"
Connect-VIServer -Server $VC1 -WarningAction SilentlyContinue
Get-VM | Select Name,PowerState, @{N="SnapName";E={
($_ | Get-Snapshot).Name}},@{N="Datastore";E={
($_ | Get-Datastore).Name}},@{ N="TotalDisk"; E={ 
($_ | Get-harddisk | measure-object -property CapacityKB -sum).Sum}},@{N="GuestOS";E={
($_ | Get-VMGuest).OSFullName}},@{N="Cluster";E={
($_ | Get-Cluster).Name}}| Export-Csv -NoTypeInformation -Path \\xyz\Reports\Report-$VC1-$Date.csv
Disconnect-VIServer -server $VC1 -Force -Confirm:$false