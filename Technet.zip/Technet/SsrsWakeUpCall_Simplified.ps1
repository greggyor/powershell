﻿# Root url of SSRS Report Manager
# Example:
#   http://localhost/Reports               for a local default SSRS instance
#   http://servername/Reports_SQLEXPRESS   for a remote named SSRS instance "SQLEXPRESS"
[string] $url = "http://msql_ch/Reports_TFS/Pages/Folder.aspx";

[System.Net.WebClient] $wc = New-Object System.Net.WebClient;
$wc.UseDefaultCredentials = $true;
$result = $wc.DownloadString($url);
$wc.Dispose();