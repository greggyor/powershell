﻿<#
			"SatNaam WaheGuru"

Date: 06:03:2012, 20:20PM
Author: Aman Dhally
Email:  amandhally@gmail.com
web:	www.amandhally.net/blog
blog:	http://newdelhipowershellusergroup.blogspot.com/
More Info : 

Version : 1

	/^(o.o)^\ 


#>


$compname = "LocalHost","R92DA6V" # cange this with your Computers Name 

foreach ($comp in $compname) {

write-Host -ForegroundColor Green "=========$comp==============="
Get-WmiObject win32_Service -ComputerName $comp| where {$_.StartMode -eq "Auto" -and $_.State -eq "stopped"} |  Select SystemName,Name,StartMode,State | ft -AutoSize


}
