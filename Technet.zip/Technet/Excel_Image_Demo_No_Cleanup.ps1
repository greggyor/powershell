#Region External functions
# determine the script's location
$scriptPath = Split-Path $MyInvocation.MyCommand.Path

# get path to external function script
$GetRamData = Join-Path $scriptPath Get-InUseMemory.ps1

# dot source external function
if (Test-Path $GetRamData -PathType Leaf) {. $GetRamData} else {
	Write-Error "Cannot find '$GetRamData'. Make sure it is in the '$scriptPath' directory."
 exit
}
#EndRegion

#Region New workbook and image files' path
# paths to the new workbook and the image file
$workbookPath = Join-Path $scriptPath ExcelAndImagesDemo.xlsx
$imgPath = Join-Path $scriptPath Ensign.jpg

# check image file existence
if (-not (Test-Path $imgPath -PathType Leaf)) {
	Write-Error "Cannot find '$imgPath'. Make sure it is in the '$scriptPath' directory."
 exit
}
#EndRegion

#Region RAM and Process monitor - Before executing Excel_Image_Demo_No_Cleanup.ps1
Write-Host Excel processes running before executing Excel_Image_Demo_No_Cleanup.ps1 -ForegroundColor Blue -BackgroundColor White
Get-Process Excel -ErrorAction SilentlyContinue

Write-Host RAM usage before executing Excel_Image_Demo_No_Cleanup.ps1 -ForegroundColor Blue -BackgroundColor White
$before = Get-InUseMemory -ForegroundColor Blue
#EndRegion

#Region Constants
# Excel Constants
# Microsoft.Office.Interop.Excel.XlRgbColor
Set-Variable rgbWhite 16777215 -Option Constant -ErrorAction SilentlyContinue

# MsoTriState
Set-Variable msoFalse 0 -Option Constant -ErrorAction SilentlyContinue
Set-Variable msoTrue 1 -Option Constant -ErrorAction SilentlyContinue

# MsoScaleFrom
Set-Variable msoScaleFromTopLeft 0 -Option Constant -ErrorAction SilentlyContinue
Set-Variable msoScaleFromMiddle 1 -Option Constant -ErrorAction SilentlyContinue
Set-Variable msoScaleFromBottomRight 2 -Option Constant -ErrorAction SilentlyContinue

# MsoFlipCmd
Set-Variable msoFlipHorizontal 0 -Option Constant -ErrorAction SilentlyContinue
Set-Variable msoFlipVertical 1 -Option Constant -ErrorAction SilentlyContinue

# MsoAutoShapeType
Set-Variable msoShapeDoubleWave 104 -Option Constant -ErrorAction SilentlyContinue

# Own Constants
# cell width and height in points
Set-Variable cellWidth 48 -Option Constant -ErrorAction SilentlyContinue
Set-Variable cellHeight 15 -Option Constant -ErrorAction SilentlyContinue
#EndRegion

#Region Excel API, Workbook and Sheet
$xl = New-Object -ComObject Excel.Application -Property @{Visible = $true; DisplayAlerts = $false}
$wb = $xl.WorkBooks.Add()
$sh = $wb.Sheets.Item('Sheet1')
$sh.Name = 'Excel and images demo'

# handle irregular Speech.Speak exception
trap {continue}
#EndRegion

#Region Image 1
# arguments to insert the image through the Shapes.AddPicture Method; all are required
$LinkToFile = $msoFalse
$SaveWithDocument = $msoTrue
$Left = $cellWidth * 2
$Top = $cellHeight * 4
$Width = $cellWidth * 2
$Height = $cellHeight * 4

# add image to the Sheet
$xl.Speech.Speak('add an image to the Sheet through the Add Picture Method')
$img1 = $sh.Shapes.AddPicture($imgPath, $LinkToFile, $SaveWithDocument, $Left, $Top, $Width, $Height)

# lock aspect ratio before scaling down the image
$xl.Speech.Speak('lock aspect ratio before scaling down the image')
$img1.LockAspectRatio = $true

# arguments to scale image
$Factor = .5
$RelativeToOriginalSize = $msoFalse
$Scale = $msoScaleFromTopLeft

# scale down image to 50% of its current size
$xl.Speech.Speak('scale down image to 50% of its current size')
$img1.ScaleHeight($Factor, $RelativeToOriginalSize, $Scale)
Start-Sleep -Milliseconds 300
#EndRegion

#Region Image 2
# get a copy of the image
$xl.Speech.Speak('get a copy of the image')
$img2 = $img1.Duplicate()

# change its position through its Left and Top properties
# move the image four cells over to the right from Sheet's left side
$xl.Speech.Speak("change the image's position through its Left and Top properties")
$xl.Speech.Speak("move the image four cells over to the right from Sheet's left side")
$img2.Left = $cellWidth * 4
# move the image four cells down from Sheet's top
$xl.Speech.Speak("move the image four cells down from Sheet's top")
$img2.Top = $cellHeight * 4

# lock aspect ratio before scaling up the image
$xl.Speech.Speak('lock aspect ratio before scaling up the image')
$img2.LockAspectRatio = $true

# scale up the image to thrice its current size
$xl.Speech.Speak('scale up the image to thrice its current size')
$img2.DrawingObject.Width *= 3
# $img2.DrawingObject.Height = $cellHeight * 6

# an image can be rotated clockwise in positive increments through the IncrementRotation Method...
$xl.Speech.Speak('an image can be rotated clockwise in positive increments')
$xl.Speech.Speak('through the Increment Rotation Method')
for ($i = 0; $i -lt 60; $i++) {
 $img2.IncrementRotation(6)
 Start-Sleep -Milliseconds 30
}

# ...or by setting an absolute degree value through the Rotation property
$xl.Speech.Speak('or by setting an absolute degree value through the Rotation property')
$img2.Rotation = 45
$xl.Speech.Speak('45 degrees')
$img2.Rotation = -45
$xl.Speech.Speak('negative 45 degrees')
$img2.Rotation = 0
$xl.Speech.Speak('0 degrees')

# also, an image can be flipped horizontaly and verticaly
$xl.Speech.Speak('also, an image can be flipped horizontaly, and verticaly.')
$img2.Flip($msoFlipHorizontal)
Start-Sleep -Milliseconds 350
$img2.Flip($msoFlipVertical)
Start-Sleep -Milliseconds 350
#EndRegion

#Region Image 3
# get another copy of the image
$xl.Speech.Speak('get another copy of the image')
$img3 = $img1.Duplicate()

# adjust the position by removing the 12 points automatically when duplication took place
# to align it horizontaly with the previous copy of the image and with the cell grid
$xl.Speech.Speak('adjust the position of the new image by removing the 12 points automatically added when duplication took place')
$xl.Speech.Speak('to align it horizontaly with the previous copy of the image and with the cell grid')
$img3.Left -= 12
$img3.Top -= 12
Start-Sleep -Milliseconds 300

# change position through the IncrementLeft or IncrementTop methods
$xl.Speech.Speak('change position through the Increment Left Method six cells to the right')
$img3.IncrementLeft($cellWidth * 6)

# change size through the DrawingObject.Width and/or DrawingObject.Height properties
$xl.Speech.Speak('change size through the Drawing Object Width and or Drawing Object Height properties')
$xl.Speech.Speak('three cells wide and six cells tall')
$img3.DrawingObject.Width = $cellWidth * 3
$img3.DrawingObject.Height = $cellHeight * 6

# transform the image into a double wave shape through the AutoShapeType property
$xl.Speech.Speak('transform the image into a double wave shape through the Auto Shape Type property')
$img3.AutoShapeType = $msoShapeDoubleWave

# add reflection to the image through the Reflection.Type property
$xl.Speech.Speak('add reflection to the image through the Reflection Type property')
$img3.Reflection.Type = 1

# increment the refletction's size
$xl.Speech.Speak("increment the refletction's size to 50")
$img3.Reflection.Size = 50

# an image can also be rotated counterclockwise in negative increments through the IncrementRotation Method...
$xl.Speech.Speak('an image can also be rotated counterclockwise in negative increments through the Increment Rotation Method')
for ($i = 0; $i -lt 60; $i++) {
 $img3.IncrementRotation(-6)
 Start-Sleep -Milliseconds 30
}
#EndRegion

#Region Image 4
# get the last copy of the image
$xl.Speech.Speak('get the last copy of the image')
$img4 = $img1.Duplicate()

# transform the image into a double wave shape through the AutoShapeType property
$xl.Speech.Speak('transform the image into a double wave shape through the Auto Shape Type property')
$img4.AutoShapeType = $msoShapeDoubleWave

# add a -relatively- medium white glow to the image
$xl.Speech.Speak('add a relatively medium white glow to the image')
$img4.Glow.Color = $rgbWhite
$img4.Glow.Radius = 5
$img4.Glow.Transparency = .3

# change its position through its Left and/or Top properties; the prefered method
# move it 4 cells down from Sheet's top
$xl.Speech.Speak('change its position through its Left and or Top properties; the prefered method')
$xl.Speech.Speak("move it 4 cells down from Sheet's top")
$img4.Top = $cellHeight * 4

# move image 10 cells over to the right from Sheet's left side
# show transition
$xl.Speech.Speak("move image 10 cells over to the right from Sheet's left side")
$xl.Speech.Speak('show the transition by sliding the image to its new position')
do {
 $img4.Left += $cellWidth / 12
} until ($img4.Left -eq ($cellWidth * 10))
#EndRegion

#Region Save and exit
$xl.Speech.Speak('save the workbook and exit')
$wb.SaveAs($workbookPath)
Start-Sleep -Seconds 2
$wb.Close()
$xl.Quit()
#EndRegion

#Region RAM and Process monitor - After executing Excel_Image_Demo_No_Cleanup.ps1
Write-Host RAM usage after executing Excel_Image_Demo_No_Cleanup.ps1 -ForegroundColor Red -BackgroundColor White
$after = Get-InUseMemory -ForegroundColor Red
$diff = $after - $before
Write-Host Difference in RAM usage after executing Excel_Image_Demo_No_Cleanup.ps1: ${diff}MB -ForegroundColor Black -BackgroundColor Yellow

Write-Host Excel processes running after executing Excel_Image_Demo_No_Cleanup.ps1 -ForegroundColor Red -BackgroundColor White
Get-Process Excel -ErrorAction SilentlyContinue
#EndRegion