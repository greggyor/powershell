﻿###################################Abhishek Borole#####################################
$ErrorActionPreference = "SilentlyContinue"
$Succeeded = "S:\temp\Succeeded_$(get-date -format 'ddMMyy_HH-mm-ss').txt"
$Failed = "S:\temp\Failed_$(get-date -format 'ddMMyy_HH-mm-ss').txt"
function write-log{ 
param( 
[string]$mytex, 
[string]$bg 
) 
if(!$bgc){$bgc="White"} 
write-host $mytex -BackgroundColor $bg
$mytex | out-file $Failed -append 
} 
function write-logs{ 
param( 
[string]$mytext, 
[string]$bgc 
) 
if(!$bgc){$bgc="White"} 
write-host $mytext -BackgroundColor $bgc 
$mytext | out-file $Succeeded -append 
} 
$Servers = gc "d:\Test\servers.txt" # This is the file where all server name or IP address has to be added.
$Source = "s:\temp\MRInit.conf" # This is the old value which need to replace with new value.
$Service = "W32Time","Dhcp" # Service Name which you want to restart after txt file update
$Process = "c:\Program Files (x86)\Sophos\Remote Management System\ClientMRInit.exe"

###################################Abhishek Borole#####################################

foreach ($server in $servers){
$ping = Test-Connection -ComputerName $server -Quiet -Count 1
If ($ping -eq "True") {
	If ($(Test-Path "\\$server\c$") -eq "True"){
	$OSD = Test-Path "\\$server\c$\Program Files (x86)\Sophos\Remote Management System\"
		If ( $OSD -eq 'True') {$Destination = "\\$server\c$\Program Files (x86)\Sophos\Remote Management System\"}
		else  { $Destination = "\\$server\c$\Program Files\Sophos\Remote Management System\"}
			If ($(Test-Path $Destination) -eq "True"){
			$Error.Clear()
			Copy-Item -path $Source -Destination $Destination -Force -ErrorAction SilentlyContinue
				If ($? -eq "True") {
					Invoke-wmimethod -path win32_process -name create -argumentlist $process -ComputerName $Server -ErrorAction SilentlyContinue | Out-Null
					If ($? -eq "True"){
							Restart-Service -InputObject $(Get-Service -Computer $Server -Name $Service) -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
						If ($? -eq "True") {
							write-logs "$server - File has been replaced and restarted service" Green}
						Else {write-log "$server - $error"}
									  }
					Else {write-log "$server - $error"}
								   }	
				Else {write-log "$server - $error"}
													 }
			Else {write-log "$server - Path not accessiable" Magenta}
 												}
    Else {write-log "$server - C$ not accessiable" Magenta}
					 }
Else {write-log "$server - Server is offline or not reachable" Red}
								}
$ErrorActionPreference = "Continue"
###################################Abhishek Borole#####################################