# ==============================================================================================
# 
# NAME: Get-GroupPoliciesByGroup.ps1
# 
# AUTHOR: Ben Baird
# DATE  : 8/30/2011
# 
# DESCRIPTION:
#
# Supply this function with an Active Directory group name it will
# return a list of GPOs that affect the specified group.
#
# Assumes the presence of Microsoft's GroupPolicy PowerShell module.
# ==============================================================================================

function Get-GroupPoliciesByGroup {

	param(
		[Parameter(Mandatory=$true)]
		[Alias("Name")]
		[string]$GroupName,
		[string]$Domain
	)

	if ((Get-Command Get-GPO -ErrorAction SilentlyContinue) -eq $null)
	{
		Import-Module GroupPolicy
	}

	if ($Domain -eq $null -or $Domain -eq '')
	{
		$Domain = ([System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain().Name)
	}

	$gpos = Get-GPO -All -Domain $Domain

	foreach ($gpo in $gpos)
	{
		$secinfo = $gpo.GetSecurityInfo() | where { $_.Permission -eq "GpoApply" }
		foreach ($sec in $secinfo)
		{
			if ($sec.Trustee.Name -eq $GroupName)
			{
				Out-Default -InputObject $gpo
			}
		}
	}
}
