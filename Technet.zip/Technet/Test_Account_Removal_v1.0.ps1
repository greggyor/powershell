###############################################################
# Test_Account_Removal_v1.0.ps1
# Version 1.0
# MALEK Ahmed - 30 / 03 / 2013
###################

##################
#--------Config
##################
$adPath="LDAP://DC=contoso,DC=msft"
$domainnetbiosname = "CONTOSO"
$noreplymail = "no-reply@contoso.msft"
$globalADadminmail = "administrator@contoso.msft"
$smtpServer = "mail.contoso.msft"
$Server = "DCProd.contoso.msft"
        
##################
#--------Main  
##################
#Identify Stamp
$Stamp = (get-date).ToFileTime()
#LDAP connection
$objDomain=New-Object System.DirectoryServices.DirectoryEntry($adPath)
#Doing an LDAP search
$ObjSearch=New-Object System.DirectoryServices.DirectorySearcher($ObjDomain)
$ObjSearch.PageSize = 60000    
#Filtering user accounts based on their mail
$ObjSearch.Filter = "(&(objectCategory=person)(objectClass=user)(info=User-TestAccount*)(accountexpires<="+$Stamp+"))"
$allSearchResult = $ObjSearch.FindAll()
foreach ($SearchResult in $allSearchResult)
{
    $testaccount=New-Object System.DirectoryServices.DirectoryEntry($SearchResult.Path)
    $errorcount1 = $Error.Count
    dsrm $testaccount.distinguishedname -noprompt -c -s $Server
    $errorcount2 = $Error.Count
    $msg = new-object Net.Mail.MailMessage
    $smtp = new-object Net.Mail.SmtpClient($smtpServer)
    $msg.From = $noreplymail
    #Notification about the test account removal
    if ($errorcount1 -eq $errorcount1)
    {
        $mailbody = "The test account " + $domainnetbiosname + "\" + $testaccount.samaccountname + " was removed from Active Directory. "+ "`r`n`r`n"
        $testaccountownermail = ($testaccount.info -replace "User-TestAccount Owner: ","")
        $Receiver=$testaccountownermail
        $msg.cc.Add($globalADadminmail)
        $msg.Subject = "[IMPORTANT] The account " + $domainnetbiosname + "\" + $testaccount.samaccountname + " was removed from Active Directory."
    }
    else
    {
        $mailbody = "The test account " + $domainnetbiosname + "\" + $testaccount.samaccountname + " was not removed from Active Directory. "+ "`r`n`r`n"
        $testaccountownermail = ($testaccount.info -replace "User-TestAccount Owner: ","")
        $Receiver=$globalADadminmail
        $msg.Subject = "[ERROR] The account " + $domainnetbiosname + "\" + $testaccount.samaccountname + " was notremoved from Active Directory."
    }
    $msg.To.Add($Receiver)
    $msg.Body = $mailbody
    $msg.Priority = [System.Net.Mail.MailPriority]::High
    $smtp.Send($msg)
}