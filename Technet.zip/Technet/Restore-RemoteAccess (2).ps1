#  Copyright (c) Microsoft Corporation.  All rights reserved.
#  
# THIS SAMPLE CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
# IF THIS CODE AND INFORMATION IS MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN
# CONNECTION WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER. 

<#
.SYNOPSIS
    Restores Remote Access configuration from a backup file.
.DESCRIPTION
    The script restores, from a backup file, Remote Access (DirectAccess and VPN) configuration to their state when taking the backup, including all Group Policy Objects and links.
.PARAMETER Path
    Target path to load the backup from.
    If the Path parameter is not specified, the current directory is used with a default file named RemoteAccessBackup.zip
.PARAMETER Force
    Restores the configuration without prompting for confirmation.
.NOTES
    Requires Windows 8 or Windows Server 2012.
    Requires the PowerShell modules: GroupPolicy, ActiveDirectory.
    Server-specific settings such as certificates and IP addresses will not be restored. 
    Ensure all Remote Access servers that were backed up are still part of the Remote Access deployment.
.EXAMPLE
    C:\PS>.\Restore-RemoteAccess.ps1 -Path C:\Backups\MyBackup.zip
    
    Description
    -----------
    Restores the Remote Access configuration from C:\Backups\MyBackup.zip.
.EXAMPLE
    C:\PS>.\Restore-RemoteAccess.ps1 -Path MyBackup.zip
    
    Description
    -----------
    Restores the Remote Access configuration from MyBackup.zip in the current directory.
.EXAMPLE
    C:\PS>.\Restore-RemoteAccess.ps1 -Path C:\Backups
    
    Description
    -----------
    Restores the Remote Access configuration from RemoteAccessBackup.zip in the directory C:\Backups.
.EXAMPLE
    C:\PS>.\Restore-RemoteAccess.ps1
    
    Description
    -----------
    Restores the Remote Access configuration from RemoteAccessBackup.zip in the current directory.
#>
Param
( 
    [parameter(Mandatory=$false, ValueFromPipeline=$true, Position=0, HelpMessage="Target path to load the backup from.")][Alias("PSPath")][String] $Path,
    [parameter(Mandatory=$false, HelpMessage="Restores the configuration without prompting for confirmation.")][switch] $Force
)

#
# Returns true if the local computer is Windows Server.
#
Function IsWindowsServer
{
    $windowsInfo = Get-WmiObject -Query "SELECT * FROM Win32_OperatingSystem WHERE ProductType=3"
    return [bool]$windowsInfo;
}

# Import the required PowerShell modules

Import-Module GroupPolicy -ErrorAction SilentlyContinue

if (-not (Get-Module GroupPolicy))
{
    if (IsWindowsServer)
    {
        throw 'The Windows Feature "Group Policy Management" is not installed. (Run "Install-WindowsFeature -Name GPMC")'
    }
    else
    {
        throw 'The Windows Feature "Group Policy Management Tools" is not installed. (Install Remote Server Administration Tools and run "Enable-WindowsOptionalFeature -FeatureName RemoteServerAdministrationTools-Features-GP -Online")'
    }
}

Add-Type -AssemblyName "WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
Add-Type -AssemblyName "System.IO.Compression.FileSystem, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"

# Global variable declaration

$script:IsADReplicationRequired = $Force
$script:IsADReplicationUserQueryRequired = -not $Force
$script:IsADModuleLoaded = $false
$script:GposToRestore = $null

Add-Type @"
public struct RemoteAccessGpo {
   public string Name;
   public string GpoId;
   public string BackupId;
   public string Domain;
   public string DC;
   public string Links;
   public string WmiFilter;
   public string DAServers;
}
"@

# Function Declerations

#
# Prints a standard line to the console 
#
Function OutputLine([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message"
    
}

#
# Prints a success line to the console 
#
Function OutputSuccess([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message" -ForegroundColor Green

}

#
# Prints an error line to the console 
#
Function OutputError([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message" -ForegroundColor Red
}

#
# Prints an indented informational line to the console 
#
Function OutputData([String] $message)
{
    $spacer = New-Object String -ArgumentList @(' ',21)
    Write-Host "$spacer $message"`
}

#
# Prints GPO information to the console 
#
Function OutputGpo($gpo)
{
    OutputData("Domain : " + $gpo.Domain)
    OutputData("Name   : " + $gpo.Name)
    OutputData("DC     : " + $gpo.DC)
    OutputData("Links  : " + [System.Uri]::UnescapeDataString($gpo.Links))
    
    if ($gpo.DAServers)
    {
        OutputData("Servers: " + ($gpo.DAServers.Split('|', [StringSplitOptions]::RemoveEmptyEntries) -join ", "))
    }
}

#
# Extracts files from a compressed archive file in the specified path to the specified folder path
#
Function UnzipFolder ([string] $zipFilePath, [string] $folderPath)
{
    try
    {
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zipFilePath, $folderPath)
    }
    catch 
    {
        throw "An error occurred while extracting files from `"$zipFilePath`". " + $error[0]
    }
}

#
# Creates a path of $env:TEMP\RemoteAccessBackups\[GUID] to store temporary backup files
#
Function CreateTempBackupDirectory
{
    $tempDir = $null
    try
    {
        $tempDir = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "RemoteAccessBackups")
        $guid = [System.Guid]::NewGuid().ToString()
        $tempDir =  [System.IO.Path]::Combine($tempDir, $guid) + "\"

        [System.IO.Directory]::CreateDirectory($tempDir) | Out-Null
    }
    catch
    {
        throw "Could not create a temporary backup directory in `"$tempDir`"." + $error[0]
    }
    return $tempDir
}

#
# Calculates the file path of the (compressed) backup file according to the script input parameters
#
Function ConstructBackupFilePath
{
    $providerPath = $null
    $driveInfo = $null

    if (-not $ExecutionContext.SessionState.Path.IsPSAbsolute($Path, [ref]$driveInfo) -and -not $Path.StartsWith('\\'))
    {
        # User provided a relative path. Combine it with the current file system path.
        $providerPath = $ExecutionContext.SessionState.Path.Combine(((Get-Location -PSProvider FileSystem).ProviderPath), $Path)
    }
    else
    {
        $providerPath = $Path
    }

    $providerInfo = $null
    $driveInfo = $null
    # Resolve the path (possibly from wildcards), and check if the provider is FileSystem
    try
    {
        $providerPath = $ExecutionContext.SessionState.Path.GetResolvedProviderPathFromPSPath($providerPath, [ref]$providerInfo)[0]
    }
    catch
    {
        $providerPath = $null
    }

    if (-not $providerPath)
    {
        throw "The provided path `"$Path`" doesn't exist. Specify a different value for the Path parameter."
    }

    if ($providerInfo.Name -ne "FileSystem")
    {
        throw "The provided path `"$Path`" is not a FileSystem path."
    }

    # Check if given path is a directory, and if so append the default file name
    if (Test-Path -Path $providerPath -PathType Container)
    {
        $defaultFileName = "RemoteAccessBackup.zip"
        $providerPath = $ExecutionContext.SessionState.Path.Combine($providerPath, $defaultFileName)
    }
    # If it's not a directory, check if it's a file with a zip extension
    elseif ([System.IO.Path]::GetExtension($providerPath) -ine ".zip")
    {
        # The specified path is not a zip file
        throw "The value specified for the Path parameter must have a .zip extension."
    }
    
    # Validate that the backup file exists
    if (-not (Test-Path -Path $providerPath -PathType Leaf))
    {
        throw "The provided path `"$providerPath`" doesn't exist. Specify a different value for the Path parameter."
    }

    return $providerPath
}

#
# Gets an ActiveDirectory Domain object for the specified domain
#
Function GetDomainByName([string] $domainName)
{
    $domainContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain", $domainName)
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($domainContext)
    
    return $domainObj
}

#
# Gets a GPDomain object for the specified domain
#
Function GetGPDomainByName([string] $domainName)
{
    $domainObj = GetDomainByName($domainName)
    $gpDomain = New-Object Microsoft.GroupPolicy.GPDomain $domainObj.Name
    return $gpDomain
}

#
# Restores a GPO from the backup
#
Function RestoreGpo($gpoToRestore, $tempBackupDir)
{
    $result = $null

    # If GPO backup was taken from a specific DC, make sure the DC is still valid
    if ($gpoToRestore.DC -ine "PDC")
    {
        try
        {
            # Check if the DC indicated for this GPO exists and is reachable
            $dcContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("DirectoryServer", $gpoToRestore.DC)
            [System.DirectoryServices.ActiveDirectory.DomainController]::GetDomainController($dcContext) | Out-Null
        }
        catch
        {
            # The specified DC isn't reachable. Ask the user whether he wants to use the DC running as the PDC emulator instead.
            $restoreToPdcInstead = $true
            if (-not $Force)
            {
                $PSCmdlet.WriteWarning("The domain controller `"" + $gpoToRestore.DC  +  "`" cannot be contacted.")
                $restoreToPdcInstead = $PSCmdlet.ShouldContinue("Would you like to attempt to restore the GPO to the domain controller with the PDC emulator role?", "Confirm")
            }
            else
            {
                $PSCmdlet.WriteWarning("The domain controller `"" + $gpoToRestore.DC  +  "`" cannot be contacted. Attempting to restore the GPO to the domain controller with the PDC emulator role.")
            }

            if ($restoreToPdcInstead)
            {
                # User wants to restore the GPO to the PDC emulator instead of the original DC
                $gpoToRestore.DC = "PDC"
            }
            else
            {
                # User did not want to restore to the PDC emulator. Stopping restore operation.
                $gpName = $gpoToRestore.Domain + "\" + $gpoToRestore.Name
                throw "The GPO `"$gpName`" cannot be restored to the domain controller `"" + $gpoToRestore.DC + "`". " + $error[0]
            }
        }
    }

    # Restore the GPO
    if ($gpoToRestore.DC -eq "PDC")
    {
        # If "PDC" is specified as the DC to restore to, do not pass the Server parameter. The GPO will be restored to the DC running as the PDC emulator.
        $result = Restore-GPO -BackupId $gpoToRestore.BackupId -Domain $gpoToRestore.Domain -Path $tempBackupDir -ErrorAction Stop
    }
    else
    {
        # If a specific DC is specified as the DC to restore to, pass the Server parameter. The GPO will be restored to that DC.
        $result = Restore-GPO -BackupId $gpoToRestore.BackupId -Domain $gpoToRestore.Domain -Path $tempBackupDir -ErrorAction Stop -Server $gpoToRestore.DC
    }

    # Check if the GPO had a WMI Filter when it was backed up, and if so, check if this WMI Filter still exists in the domain.
    if ($gpoToRestore.WmiFilter -and -not $result.WmiFilter)
    {
        # A WMI Filter existed when we backed-up the GPO, but doesn't exist in the restored GPO. Show a warning.
        $PSCmdlet.WriteWarning("The WMI filter `"" + $gpoToRestore.WmiFilter + "`" cannot be found. The restore operation will continue without linking the GPO to the WMI filter.")
    }

    return $result
}

#
# Creates links to the restored GPO.
#
Function RestoreGpoLinks ($missingLinks, $restoredGpo, $dcName)
{
    try
    {
        if ($missingLinks.Count -eq 0)
        {
            # No missing links to restore.
            return
        }

        # Since GPO Links can only be restored on the PDC and the GPO might have been restored to a different DC, 
        # we must replicate the GPO container to the PDC before creating the links.
        $isPdc = $false
        $sourceDc = $null
        $pdcName = $null
        
        if ($dcName -eq "PDC") 
        {
            # The GPO was restored directly to the DC running as the PDC emulator. Replication will not be required.
            $isPdc = $true 
        }
        else
        {
            $dcContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("DirectoryServer", $dcName)
            $sourceDc = [System.DirectoryServices.ActiveDirectory.DomainController]::GetDomainController($dcContext)
            if ($sourceDc.Roles.Contains("PdcRole"))
            {
                # The GPO was restored directly to the PDC. Replication will not be required.
                $isPdc = $true
            }
        }
        
        if (!$isPdc -and $script:IsADReplicationUserQueryRequired)
        {
            # Request user for permission to replicate objects   
            $script:IsADReplicationRequired = $PSCmdlet.ShouldContinue("Restoring the GPO links requires synchronizing some Active Directory objects between domain controllers. Ensure that `"Active Directory module for Windows PowerShell`" is installed. Do you want to continue?", "Confirm")
            $script:IsADReplicationUserQueryRequired = $false
        }

        if (!$isPdc -and !$script:IsADReplicationRequired)
        {
            # User did not agree to allow replication
            throw "Active Directory replication is required."
        }
        elseif (!$isPdc) # User agreed to replicate
        {
            if (!$script:IsADModuleLoaded)
            {
                # Try loading the Active Directory module for PowerShell
                Import-Module ActiveDirectory -ErrorAction SilentlyContinue
                
                if (-not (Get-Module ActiveDirectory))
                {
                    # Active Directory module is not installed. Do not try replicating again.
                    $script:IsADReplicationRequired = $false

                    if (IsWindowsServer)
                    {
                        throw 'The Windows Feature "Active Directory module for Windows PowerShell" is not installed. (Run "Install-WindowsFeature -Name RSAT-AD-PowerShell")'
                    }
                    else
                    {
                        throw 'The Windows Feature "Active Directory Module for Windows PowerShell" is not installed. (Install Remote Server Administration Tools and run "Enable-WindowsOptionalFeature -FeatureName RemoteServerAdministrationTools-Roles-AD-Powershell -Online")'
                    }
                }
                else
                {
                    # Active Directory module was successfully loaded to the PowerShell runspace. No need to load it again in the future.
                    $script:IsADModuleLoaded = $true
                }
            }

            # Find the PDC and force replication from the source DC to the PDC
            $domainContext = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain", $restoredGpo.DomainName)
            $domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetDomain($domainContext)
            $pdcName = $domain.PdcRoleOwner.Name
                        
            # Replicate the GPO container to the PDC which is required in order to link the GPO on the PDC.
            # This operation may fail for Windows Server 2008 R2 domain controllers if SP1 is not installed.
            try 
            { 
                Sync-ADObject -Object $restoredGpo.Path -Source $sourceDc.Name -Destination $pdcName 
            }
            catch [System.ArgumentException] 
            {
                throw $error[0].Exception.Message + " Ensure domain controllers are updated with the latest Windows service pack."
            }
        }

        # Iterate on all of the target containers that are missing the GPO link
        foreach($missingLinkTarget in $backedUpLinks)
        {
            # Create a link to the GPO in the iterated target
            OutputData("Creating link to target `"$missingLinkTarget`"")
            New-GPLink -Guid $restoredGpo.Id -Target $missingLinkTarget -Domain $restoredGpo.DomainName | Out-Null

            if (!$isPdc)
            {
                # Replicate the link target back to the source DC
                # This will replicate the links we created on the PDC back to the DC closest to the Remote Access server
                try 
                {
                    Sync-ADObject -Object $missingLinkTarget -Source $pdcName -Destination $sourceDc.Name 
                }
                catch [System.ArgumentException] 
                {
                    throw $error[0].Exception.Message + " Ensure domain controllers are updated with the latest Windows service pack."
                }
            }
        }        
    }
    catch
    {
        $gpName = $restoredGpo.DomainName + "\" + $restoredGpo.DisplayName
        $lastError = $Error[0]
        OutputError "Cannot automatically restore the links to GPO `"$gpName`" due to the following error: '$lastError'; You may restore the links manually using Group Policy Management Console."
    }
}

#
# Checks if the GPO links that existed during back up already exist in the domain after restoring the GPO.
# If the GPO did not exist prior to the restore operation, we need to re-create all of the links to this GPO as specified in the Backup Index file.
# This function restores only the links that are currently missing.
#
Function RestoreMissingGpoLinks($gpoLinks, $restoredGpo, $dcName)
{
    # Parse the pipe-delimited (|) string containing the list of link targets for the GPO
    $backedUpLinks = New-Object System.Collections.ArrayList($null)
    $gpoLinks.Split('|', [StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object { $backedUpLinks.Add([System.Uri]::UnescapeDataString($_)) } | Out-Null
    
    $gpoDomainName = $restoredGpo.DomainName
    $gpoDomain = $null
    try 
    {
        $gpoDomain = GetGPDomainByName($gpoDomainName) 
    }
    catch 
    {
        OutputError "Couldn't find domain `"$gpoDomainName`""
        return
    }

    $soms = $null
    # Retrieve a scope of management (SOM) for each container (in the domain) that the restored GPO is linked to.
    try 
    {
        $soms = $gpoDomain.SearchSoms($restoredGpo) 
    }
    catch 
    {
        $errorMsg = $error[0]
        OutputError "Couldn't retrieve the group policy scope of management collection. $errorMsg"
        return
    }
    
    foreach($som in $soms)
    {
        foreach($link in $som.GpoLinks)
        {
            if ($link.GpoId -eq $restoredGpo.Id) 
            {
                # Link already exists in the domain, remove it from the backed-up links list as we don't need to re-create it.
                $backedUpLinks.Remove($link.Target)
            }
        }
    }

    # Restore the missing GPO Links
    RestoreGpoLinks $backedUpLinks $restoredGpo $dcName
}

#
# Invokes a group policy update on all Remote Access server which are part of the restored configuration
#
Function SyncDAServers($daServers)
{
    try
    {
        if ($daServers.Length -eq 0)
        {
            # No servers in the list
            return
        }

        OutputLine("Applying GPOs on the Remote Access servers...")

        $sortedServersList = @()
        # If the server executing the script is a Remote Access server then we need to invoke it last and move it to the end of the array.
        # otherwise, it might lose connectivity due to GPO configuration changes and will not be able to sync the rest of the Remote Access servers
        $localHostName = [System.Net.Dns]::GetHostEntry("localhost").HostName
        if ($daServers -contains $localHostName -and $daServers.Length -gt 1)
        {
            # localhost is one of the Remote Access servers. Remove it from the array, and push it back again to the end of the array.
            $sortedServersList += $daServers | Where-Object {$_ -ine $localHostName}
            $sortedServersList += $localHostName
        }
        else
        {
            # localhost is not one of the Remote Access servers, or is the only Remote Access server. Keep array as is.
            $sortedServersList += $daServers
        }

        # Iterate on all Remote Access servers
        foreach ($server in $sortedServersList)
        {
            try
            {
                # Call the WMI method "Sync" on the iterated Remote Access server in order to invoke a group policy update
                $syncOption = 1 # SYNC_DELAYED - will invoke a gpupdate on the server after 30 seconds
                $wmiResult = $null
                $wmiResult = Invoke-WmiMethod -Name "Sync" -ArgumentList @($syncOption) -Class "PS_RemoteAccessLocal" -Namespace "ROOT\Microsoft\Windows\RemoteAccess\Server" -ComputerName $server -ErrorAction SilentlyContinue

                if (!$wmiResult)
                {
                    # Invoke-WmiMethod failed
                    throw
                }

            }
            catch
            {
                # An error occurred while trying to synchronize the server. Show a warning and continue trying to synchronize the remaining servers.
                $PSCmdlet.WriteWarning("GPO updates cannot be applied on `"$server`". Changes will not take effect until the next policy refresh.")
            }
        }
    }
    catch
    {
        $PSCmdlet.WriteWarning("GPO updates cannot be applied. Changes will not take effect until the next policy refresh.")
    }   
}

#
# Extracts the backup files to the temporary directory from the compressed zip and loads the Backup Index file
#
#
Function ReadBackupFile ($backupFile, $tempBackupDir)
{
    UnzipFolder $backupFile $tempBackupDir

    # Check whether the Backup Index file exists in the backup directory
    $SummaryFile = [IO.Path]::Combine($tempBackupDir, "BackupIndex.csv")
    if (!(Test-Path $SummaryFile))
    {
        throw "The backup in `"$backupFile`" doesn't contain the BackupIndex.csv index file."
    }

    # Ask for user confirmation for restoring configuration
    if (!$Force)
    {
        if (!$PSCmdlet.ShouldContinue("Configuration will be restored from `"$backupFile`". Do you want to continue?", "Confirm"))
        {
            exit
        }
    }
    
    # Deserialize the Backup Index file
    $script:GposToRestore = $null
    $script:GposToRestore = Import-Csv $SummaryFile
    if (!$script:GposToRestore)
    {
        throw "The backup index file is empty. Cannot restore configuration."
    }
}

############################################################
#################### Script Begins Here ####################
############################################################

$backupFile = $null
$tempBackupDir = $null

try
{
    OutputLine("Preparing and retrieving data for restore.")

    # Check for input path and file name validitiy
    $backupFile = ConstructBackupFilePath
    # Create a temporary directory for backup files
    $tempBackupDir = CreateTempBackupDirectory

    # Extract the zip file and read the Backup Index file into $script:GposToRestore
    ReadBackupFile $backupFile $tempBackupDir 

    $daServers = @()

    # Iterate on all GPOs to restore
    foreach($gpoToRestore in $script:GposToRestore)
    {
        # Print GPO information to the console
        OutputLine("Restoring GPO:")
        OutputGpo $gpoToRestore
    
        # Restore the GPO from the backup to the domain
        $restoredGpo = RestoreGpo $gpoToRestore $tempBackupDir

        # Search and create any missing links for the GPO
        RestoreMissingGpoLinks $gpoToRestore.Links $restoredGpo $gpoToRestore.DC

        # Add the Remote Access servers associated with the restored GPO to a list
        $daServers += $gpoToRestore.DAServers.Split('|', [StringSplitOptions]::RemoveEmptyEntries)

        OutputSuccess("Successfully restored GPO.")
    }

    # Invoking group policy update on all Remote Access servers
    SyncDAServers $daServers

    OutputSuccess("Done. Successfully restored configuration from `"$backupFile`"")
}
finally
{
    # Delete the temporary backup directory
    if ($tempBackupDir)
    {
        Remove-Item -Recurse -Force $tempBackupDir
    }
}