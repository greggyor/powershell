﻿#Requires -Version 2.0
#Made by: Alfred Erian
#######################
#Credit goes to my lovely wife
#This script was made keeping in mind lazy admins and people who don't #like to edit in scripts.
#Some code blocks here where taking from other scripts made for the same reason.
#No one were harmed in the making of this script.
#######################

#Script Parameters
[cmdletBinding(SupportsShouldProcess = $true)]
param(
	[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true, Mandatory = $false)] 
	[switch]$Demo,
	[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true, Mandatory = $false)] 
	[string]$Preview,
	[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true, Mandatory = $false)] 
	[switch]$LogError,
	[parameter(ValueFromPipeline = $false, ValueFromPipelineByPropertyName = $true, Mandatory = $false)] 
	[switch]$LogAll
)

#Clear screen and set current location to script location
cls
$ScriptPath = Split-Path $MyInvocation.MyCommand.Path
Set-Location -Path $ScriptPath

#Clear any variable from previous run
clv [a..z]* -Scope local

# Files to be used.
$configFile    = 'settings.txt'
$errorLog      = 'error.log'
$proccessLog   = 'proccess.log'
$emailFile     = 'mail.html'

# Get current year, month and day for later use.
$date = Get-Date -uformat %Y-%m-%d

# Utility function that turns unquoted, space-separated strings into an array.
# It means you can write "ql foo bar baz" rather than "@('foo', 'bar', 'baz')".
function ql { $args }

# Function to parse the configuration file.
function Parse-Config {
    
	$config = $null
    $config = @{}
    
    if (-not (Test-Path -PathType Leaf $configFile)) {
        
        Write-Host "${date}: Fatal error: File $configFile not found. Processing aborted."
        "${date}: Fatal error: File $configFile not found. Processing aborted." | Out-File -Append $errorLog
        exit 1
        
    }
    
    Get-Content $configFile | Where-Object { $_ -match '\S' } | # Skip blank (whitespace only) lines.
    Foreach-Object {
		switch -regex ($_) {
    		"^\s*([^#].+?)\s*=\s*(.*)" {
      		$key,$value = $matches[1..2]
      		$config.$key = $value
    		}
  		}
	}
	
    $requiredValues = ql smtp smtpPort from firstWarningDays lastWarningDays useDefaultCredentials enableSSL
    
    # Initialize this to false and exit after the loop if a required value is missing.
    [bool] $missingRequiredValue = $false
    
    foreach ($requiredValue in $requiredValues) {
       
        if ((-not $config.ContainsKey($requiredValue)) -or (-not($config.$requiredValue))) {
            
            Write-Host "${date}: Error: Missing '$requiredValue'. Processing will be aborted."
            "${date}: Error: Missing '$requiredValue'. Processing will be aborted." | Out-File -Append $errorLog
            $missingRequiredValue = $true
        }
        
    }
    
    # Exit the program if a required value is missing in the configuration file.
    if ($missingRequiredValue) { exit 2 }
    
    $config 
}

# Check needed module
function Set-ModuleStatus { 
	[cmdletBinding(SupportsShouldProcess = $true)]
	param	(
		[parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true, Mandatory = $true, HelpMessage = "No module name specified!")] 
		[string]$name
	)
	if(!(Get-Module -name "$name")) { 
		if(Get-Module -ListAvailable | ? {$_.name -eq "$name"}) { 
			Import-Module -Name "$name" 
			# module was imported
			return $true
		} else {
			# module was not available (Windows feature isn't installed)
			return $false
		}
	}else {
		# module was already imported
		return $true
	}
}

#Function to set current checked user max time span
function Get-maxPasswordAgeTimeSpan {
	# see if we're at Windows2008 domain functional level, which supports granular password policies
	if ($global:dfl -ge 4) { # 2008 Domain functional level
      $userFGPP = Get-ADUserResultantPasswordPolicy $user
	  if ($userFGPP -ne $null) {
		return $userFGPP.MaxPasswordAge
	  } else {
		return (Get-ADDefaultDomainPasswordPolicy).MaxPasswordAge
	  }
	} else { # 2003 or ealier Domain Functional Level
	  return (Get-ADDefaultDomainPasswordPolicy).MaxPasswordAge
	}
}

# Function to actually send the mail
function Send-Warn-Mail {
    
    param(
          [string] $private:userEmail
          )
		  
	if (-not (Test-Path -PathType Leaf $emailFile)) {
        
        Write-Host "${date}: Fatal error: File $emailFile not found. Processing aborted."
        "${date}: Fatal error: File $emailFile not found. Processing aborted." | Out-File -Append $errorLog
        exit 1	
    }
	
	#Get e-mail body template
	$private:messagebody = Get-Content $emailFile
	$private:messagebody = $ExecutionContext.InvokeCommand.ExpandString($private:messagebody )
	
	#Read e-mail subject from settings file
    $private:subject = $config.emailSubject
	$private:subject = $ExecutionContext.InvokeCommand.ExpandString($private:subject )
    
	$private:msg = New-Object System.Net.Mail.MailMessage $config.from, $private:userEmail , $private:subject, $private:messagebody 
	$private:msg.IsBodyHTML = $true
	
    $private:SmtpClient = New-Object System.Net.Mail.SmtpClient($config.smtp, $config.smtpPort)
    
    # If useDefaultCredentials is set to true, change the property on the SMTP client object.
    # It is false by default.
    if ($config.useDefaultCredentials -imatch 'true') {
        $private:SmtpClient.UseDefaultCredentials = $true
	else{}
		if (-not($config.smtpUser)) {
		$private:SmtpClient.Credentials = New-Object System.Net.NetworkCredential( $config.smtpUser , $config.smtpPass );
		}  
    }
    
    # If enableSSL is set to "true" in the config file, enable SSL.
    if ($config.enableSSL -imatch 'true') {
        $private:SmtpClient.enableSSL = $true
    }
    
    # Send the mail
    $private:SmtpClient.Send($private:msg)
    
    if ( $? ) {
        
        "${date}: Sent user $MyUserName warning mail at $private:userEmail"
        
    }
    
    else {
        
        "${date}: Error sending user $MyUserName warning mail at $private:userEmail : " + $error[0].ToString() | Out-File -Append $errorLog
        
    }
    
    # "Clear" the object/variable. Seems necessary.
    $private:SmtpClient = $null
    
}

# Check configuration file for values.
$config = Parse-Config $configFile

# Checking for ActiveDirectory module install if needed
if ((Set-ModuleStatus ActiveDirectory) -eq $false){
	$error.clear()
	Write-Host "Installing the Active Directory module..." -ForegroundColor yellow
	Set-ModuleStatus ServerManager
	Add-WindowsFeature RSAT-AD-PowerShell
	if ($error){
		Write-Host "${date}: Fatal error: Active Directory module could not be installed. Processing aborted."
		"${date}: Fatal error: Active Directory module could not be installed. Processing aborted." | Out-File -Append $errorLog
		exit 1
	}
}
	
# Set the default e-mail address LDAP attribute/field unless specified (default: 'Email')
    if ((-not $config.ContainsKey('emailADAttribute')) -or (-not($config.emailADAttribute))){
        $config.emailADAttribute = 'EmailAddress' 
    }
	
# Set the default user name attribute/field unless specified (default: 'DisplayName')
    if ((-not $config.ContainsKey('userNameAttribute')) -or (-not($config.userNameAttribute))){    
        $config.userNameAttribute = 'DisplayName'   
    }
	
# Set the default date format unless specified (default: 'yyyy-MM-dd')
    if ((-not $config.ContainsKey('DateFormat')) -or (-not($config.DateFormat))){    
        $config.DateFormat = "yyyy-MM-dd"
    }	

#Write header on screen if demo parameter passed
if ($Demo){
	Write-Host "`n"
	Write-Host ("{0,-25}{1,-35}{2,-8}{3,-12}{4,-12}" -f "User", "E-Mail","Expires","Expiry Date", "Policy") -ForegroundColor cyan -backgroundcolor black
	Write-Host ("{0,-25}{1,-35}{2,-8}{3,-12}{4,-12}" -f "========================", "==================================","=======","==========", "===========") -ForegroundColor cyan -backgroundcolor black
}


#Set what AD attributes to get
$srchAttributes = "PasswordExpired", "PasswordNeverExpires", "PasswordLastSet", $config.emailADAttribute, $config.userNameAttribute

#if no OU is set search all directory else search selected OU
if (-not ($config.searchOU)){
	$users = Get-ADUser -filter * -properties (foreach{$srchAttributes}) 
	}
else {
	$users = Get-ADUser -filter * -properties (foreach{$srchAttributes}) -SearchBase $config.searchOU 
	}

#Do the search in active directory and make actions as per passed parameter
foreach ($user in $users) {
	#Get User name as set if null expetion returned set to empty
	try {
		$MyUserName = $user | select -ExpandProperty $config.userNameAttribute
	}
	catch {
		$MyUserName = ''
		$error.clear()
	}
	
	#Get User name as set if null expetion returned set to empty
	try {
		$MyUserEMail = $user | select -ExpandProperty $config.emailADAttribute
	}
	catch {
		$MyUserEMail = ''
	}
	
	#Calculate Password Expiry
	
	#Check that password not already expired or set to never expires
	if (((!($user.PasswordExpired)) -and (!($user.PasswordNeverExpires)))) {
		$maxPasswordAgeTimeSpan = Get-maxPasswordAgeTimeSpan
		#Calculate days to expire and policy
		if ($maxPasswordAgeTimeSpan -eq $null -or $maxPasswordAgeTimeSpan.TotalMilliseconds -ne 0) {
			$DaysTillExpire = [math]::round(((New-TimeSpan -Start (Get-Date) -End ($user.PasswordLastSet + $maxPasswordAgeTimeSpan)).TotalDays),0) 
			$ExpiryDate = Get-date ([datetime]$date).Adddays($DaysTillExpire) -format $config.DateFormat
		} else {
			#Equal to set it to zero
			$DaysTillExpire = 0
			$ExpiryDate = "N\A"
		}
	} else {
		if ($user.PasswordExpired) {
			$DaysTillExpire = 'Expired'
			$maxPasswordAgeTimeSpan = Get-maxPasswordAgeTimeSpan
		} else { #So it's a user with never expire password
			$DaysTillExpire = 0
			$maxPasswordAgeTimeSpan = 0
		}
		$ExpiryDate = "N\A"
	}
	#Round and format the value to display only days
	$maxPasswordAgeTimeSpan = [math]::round((($maxPasswordAgeTimeSpan).TotalDays),0)
	
	if($Demo){
		Write-Host ("{0,-25}{1,-35}{2,-8}{3,-12}{4,-12}" -f $MyUserName, $MyUserEMail, $DaysTillExpire, $ExpiryDate, $maxPasswordAgeTimeSpan) -ForegroundColor cyan -backgroundcolor black
	} else {
		if (($DaysTillExpire -le $config.firstWarningDays) -and ($DaysTillExpire -ge $config.lastWarningDays)) {
			if ($MyUserEMail -eq $null) {
				Write-Host "${date}: Proccess error: User $MyUserName has no e-mail recorded."
				if ($LogError -or $LogAll) {
        			"${date}: Proccess error: User $MyUserName has no e-mail recorded." | Out-File -Append $proccessLog
					}
			} else {
				if (($Preview -ne $null) -and ($Preview)) {
					Send-Warn-Mail $Preview
				} else {
					Send-Warn-Mail $MyUserEMail
					if ($LogAll) {"${date}: Proccess: User $MyUserName warning e-mail has been sent to $MyUserEMail" | Out-File -Append $proccessLog}
				}
			}
		}
	}
}