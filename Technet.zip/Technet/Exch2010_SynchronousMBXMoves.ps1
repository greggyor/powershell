# Exchange 2010 Synchronous Mailbox Moves
# Purpose:  Move a single Exchange 2010 mailbox at a time within a maintenance window.  Best when scheduled
#			as a task for a consistent start time, however manual execution from the CLI will provide host
#			feedback for monitoring.  For a reference on running a Powershell script as a scheduled task
#			visit http://www.mikepfeiffer.net/2010/02/creating-scheduled-tasks-for-exchange-2010-powershell-scripts/.

# =================================================
# ==========  CHOOSE CUSTOM SETTINGS  =============	
# =================================================

## Timing Settings ##
# Length of time the script is allowed to run before suspending an active move (in minutes).
$TimeThresholdMins = 540
# Source csv file with header "name,database".  Name should be a unique name value for the account.  Preferrably
# alias.  Database is the name of the target database for the move.
$SourceFile = "D:\Scripts\MBXMoves.csv"
# If set to $True the $TimeThresholdMins setting is ignored on Saturdays and Sundays allowing the script to run until 
# 12am Monday.  See $MondayTimeThresholdMins.
$RunWeekends = $false
# Number of minutes from 12am Monday that the script should run (in minutes).  Only takes effect if $RunWeekends is set to $True.
$MondayTimeThresholdMins = 300

## Label Settings ##
# Set the batch name to tag move requests managed by the script.  This tag will show in the move request properties and
# is used to resume moves the script has previously suspended.
$BatchName = "Moved by Synchronous Move Script"
# Set the suspend comment for a suspended move request.  This tag will show in the move request properties for informational purposes. 
$SuspendComment = "Suspended by Synchronous Move Script"

## Email Settings ##
# Email recipients for alerts.  Use @("user1@domain.com","user2@domain.com") for multiple entries.  
# Comment out $Recipients to turn off alerts.
$Recipients = "user1@domain.com"
$From = "MBXMoves<NoReply@domain.com>"
$Subject = "Automated Message:  MBX Move Status $((get-date).ToShortDateString())"
$SMTPServer = "mailserver.domain.com"
# The body of your email.  An extra line will be appended to this text containg the end status of the script.
$Body = "Automated query executed from the 'Exchange 2010 - MBXMoves' scheduled task on server.domain.local."

# =================================================
# ==========  End CUSTOM SETTINGS  ================	
# =================================================

# Setup a timer to keep track of a duration of time.
$Timer = New-Object Timers.Timer
# Interval is in milliseconds.  $TimeThresholdMins relies on a 60 second interval, or 60000ms.
$Timer.Interval = 60000
$Timer.Enabled = $True
$Global:Counter = 0
Register-ObjectEvent -InputObject $Timer -EventName Elapsed -Action {$Global:Counter++}

# Function to monitor the percent complete of a move request.  No other moves will occur until after this gets to 100%.
Function MoveStatusCheck {
		Do {
		Start-Sleep -Seconds 10
		$StatCheck = Get-MoveRequestStatistics -Identity $Mailbox
		$PercentComplete = $Statcheck.PercentComplete
		# Since we've queried the moverequeststatistics pull the status for use in the SuspendCheck function
		$Status = $Statcheck.Status
		Write-Host $PercentComplete -foreground yellow
		# While monitoring the percent of completion we check to see if it's time for the script to stop.
		SuspendCheck
		}
	Until ($PercentComplete -ge 100)
}

# Function to determine if the timer threshold has been surpassed
Function SuspendCheck {
	# Grab the day of the week number (Monday = 1)
	$Day = Get-Date -UFormat %u
	# Check to see if we're allowed to run all weekend and that it's actually a weekend day.
	If ($RunWeekends -eq $true -and $Day -ge "6") {
		# RunWeekends is true so we reset our time threshold to the Monday time threshold.
		$TimeThresholdMins = $MondayTimeThresholdMins
		# We reset the counter so when $Day becomes 1 it will start a fresh count from zero.
		$Global:Counter = 0
		return
	}
	
	# Check the global counter to see if it has surpassed our timer threshold.
	If ($Global:Counter -ge $TimeThresholdMins) {
		$Timer.Stop()
		# Check the status of the current move.  Moves with a status of CompletionInProgress cannot be suspended.
		# If the status matches we leave it to finish and head to the SendMail function to exit the script.
		If ($Status -eq "CompletionInProgress") {
			$Body = "$Body  The script is shutting down and allowing mailbox $Mailbox to complete its move."
			SendMail
		}
		# If the timer threshold has been surpassed, and the current move has not reached the status of CompletionInProgress
		# then we suspend the current move and head to the SendMail function to exit the script.
		Suspend-MoveRequest -Identity $Mailbox -Confirm:$false -SuspendComment $SuspendComment
		$Body = "$Body  The script is shutting down after suspending mailbox $Mailbox."
		SendMail
	}
}

# Function to notify recipients of the script's ending, stop the timer, and exit the script.
Function SendMail {
	# Check to see if $Recipients was set in the custom settings.  The email notification only works if there is a value.
	If ($Recipients) {
	Send-MailMessage -To $Recipients -From $From -Subject $Subject -Body $Body -SmtpServer $SMTPServer
	}
	$Timer.Stop()

	# Exit the script.
	Exit
}

# Query current move requests for moves previously suspended by this script.
$SuspendedMoves = Get-MoveRequest -BatchName $BatchName -Suspend $true

# If previous moves exist we resume the move and begin monitoring for its completion.
Foreach ($Mailbox in $SuspendedMoves) {
	If (!$Mailbox) {continue}
	Write-Host "Found suspended MBX:  " $Mailbox
	Resume-MoveRequest -Identity $Mailbox
	MoveStatusCheck
}

# Previous moves are complete.  Import a list of new move requests.
$file = Import-CSV $SourceFile

# Begin processing new move requests.
Foreach ($line in $file) {
	# Grab account info from the name in the file.  
	$MBX = Get-Mailbox $line.name
		
	# Make sure the Get-Mailbox query didn't result in multiple values.  If so we move to the next line in the file.
	If ($MBX.GetType().IsArray -or $MBX.Database -eq $line.database) {
		Write-Host "Search is an array or the mailbox already exists on that database" -foreground red
		continue
	}
	
	# Grab the mailbox alias to insure we use a valid property on the rest of our queries.
	$Mailbox = $MBX.Alias

	# Perform a Try/Catch on our move request in case of errors starting a move request.  If an error is caught we move
	# to the next line in the file.  You may only catch terminating errors so we use -ErrorAction Stop on our cmdlet.
	Try {
		# Launch our move request.  Assigning a batch name allows the script to mark its work.
		New-MoveRequest -Identity $Mailbox -BatchName $BatchName -TargetDatabase $line.database �ErrorAction Stop
		}
	Catch {
		Write-host "The New-MoveRequest cmdlet encountered an error for $Mailbox.  Moving to the next mailbox." -foreground red
		continue
	}

	# Monitor the move.
	MoveStatusCheck 

	# When the move is complete we check copyqueuelength to make sure all target DBs are keeping up.  This was developed
	# due to low bandwidth issues after all.
	Do {
		# A little nap so we don't query the servers *too* many times while it catches up.
		Start-Sleep -Seconds 10
		# Get the database copy status of the database we just copied to.
		$DBCopyStatus = Get-MailboxDatabaseCopyStatus -Identity $line.database
		# Create an array where we'll store the copyqueuelength values for sorting.
		$SplitArray = @()
		# Run through the database copy status and put the value of copyqueuelength into an array.
		ForEach ($DB in $DBCopyStatus) {
			$CQLArray += $DB.CopyQueueLength
		}
		# Sort the array as intengers to grab the last value. The last value will be the highest valued copyqueuelength.
		$HighestCQL = $CQLArray | Sort-Object {[int] $_} | Select-Object -Last 1
		# If there is any data waiting in queue we jump out and check again to avoid further traffic to our bottleneck.
		If ($HighestCQL -ge 1) {
		$Status = 1
		# Use continue to reenter our "Do" loop and check for updates on the copyqueuelength.
		continue
		}
		
		# If all is well we get out of our "Do"
		$Status = 0
	}
	Until ($Status -eq 0)
}
# Head to the SendMail function to exit the script.
$Body = "$Body  The script has reached the end of the move list."
SendMail