﻿<#  
 Author:   Andreas Werner 
 Create:   09.01.2013 
 Modiy:    09.01.2013 
 Version:  1.0
 From:     Germany 
 Email:    ps@werner-it.net 
 Website:  www.werner-it.net 
 
 Description 
 Finds the AD Computer ip address on the mac address 
#> 

function Get-IPbyMAC () {
param([string]$Computer,[string]$MAC)
[wmi]$NetworkAdapters = Get-WmiObject Win32_NetworkAdapter -ComputerName $Computer -Filter "NetEnabled='True'"

  foreach ($NetworkAdapter in $NetworkAdapters){
    if($MAC -eq $NetworkAdapter.MACAddress){
        $Adapters=@()
        $Adapter_Entry = New-Object system.object
        $Adapter_Entry | Add-Member -Type NoteProperty -Name 'Computer' -Value $Computer -Force
        $Adapter_Entry | Add-Member -Type NoteProperty -Name 'Adapter' -Value $NetworkAdapter.NetConnectionID -Force
        $Adapter_Entry | Add-Member -Type NoteProperty -Name 'MAC' -Value $MAC -Force
        $IP=[System.Net.Dns]::GetHostAddresses($Computer) | % {$_.IPAddressToString}
        $Adapter_Entry | Add-Member -Type NoteProperty -Name 'IP-Address' -Value $IP -Force
        $Adapters+=$Adapter_Entry
        return $Adapters
    } else {$null}
  }
}


function FastPing (){
param ([string]$Computer, [int]$Timeout=500)
    $Ping=New-Object System.Net.NetworkInformation.Ping
    $Status=$Ping.Send($Computer,$Timeout).Status
    if ($Status -eq "Success") {return $true} else {return $false}
}

#----- S T A R T ----
Import-Module ActiveDirectory

Clear-Host

#-- Input
$MAC= Read-Host -Prompt "Enter MAC-Address... (e.g. 00:11:22:33:44:55) "
$MACpatter="\b([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2})\b"

if ( $MAC -match $MACpatter) {
write-host " >> started seek << " -ForegroundColor white -BackgroundColor Green
    $ADComputers=Get-ADComputer -Filter * -Properties * | Foreach {$_.DNSHostName}
    foreach ($ADComputer in $ADComputers){

    [boolean]$Aktive=FastPing -Computer $ADComputer

        if($Aktive) {
            $Wert=Get-IPbyMAC -Computer $ADComputer -MAC $MAC
            if(!($Wert -eq $null)) {$Wert | Format-List ;break}
        }

    }
} else {write-host "MAC-Address incorrect" -ForegroundColor Yellow -BackgroundColor Red}

write-host " >> ended seek << " -ForegroundColor white -BackgroundColor Green
