if ($ver.Version.Major -gt 1)  {$Host.Runspace.ThreadOptions = "ReuseThread"}
 Add-PsSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

#This PowerShell Script Reports On All Web Application Policies In The Environment And Accepts No Parameters

#Set Script Parameters
$LoggingDirectory = �c:\ExportPolicies�


#Begin Script
######LOAD FUNCTIONS######
Function ExportPolicies ($FileName)
{
$WebApplications = Get-SPWebApplication

#Record general document header information to the output file
"Policy Reporting Process Beginning at :" | Out-File $Filename
 $StartTime | Out-File $Filename -Append
 "" | Out-File $Filename -Append
 "" | Out-File $Filename -Append
 "Current Web Application Policies" | Out-File $Filename -Append

 #Record web application specific information to the output file
 Foreach($WebApplication in $WebApplications)
 {
 #Get an individual web application
 $WorkingWebApp = get-spwebapplication $WebApplication

 #Get the Web application policies for the individual web application
 $WebAppPolicies = $WorkingWebApp.Policies
 "" | Out-File $Filename -Append
 "Web Application:" | Out-File $Filename -Append

 #Record the Web Application Details
 $WebApplication | Out-File $Filename -Append

 #Record the Web Application Policy Details
 $WebAppPolicies | Out-File $Filename -Append
 }
}

function EnsureLoggingDirectory
{
If ($LoggingDirectory.Endswith("\"))
    {
    }
else
    {
    Set-Variable -Name LoggingDirectory -Value "$LoggingDirectory\" -Scope 1
    }
}
######END LOAD FUNCTIONS######

EnsureLoggingDirectory

#Record the Start Time of the Policy Report (This is used to generate a dynamic Filename)
$StartTime = (get-date -uFormat "%Y-%m-%d_%I-%M-%S %p" ).tostring()

#Set the Output Filename dynamically
$Filename = "$LoggingDirectory" + "PolicyReport_" +$StartTime +".txt"

if(Test-Path c:\temp)
{
 ExportPolicies $FileName
}
else
{
Write-Host " "
Write-Host "Directory $LoggingDirectory Does Not Exist, Creating Directory"
New-Item $LoggingDirectory -type directory
Write-Host " "
Write-Host "Directory $LoggingDirectory Created Successfully"
Write-Host " "
ExportPolicies $FileName
}
if (Test-Path $FileName)
{
Write-Host "Policies Exported Successfully To $FileName"
}
else
{
Write-Host "$FileName Could Not Be Created"
Write-Host "Please Try Again"
}