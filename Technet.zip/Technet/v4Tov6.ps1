#  Copyright (c) Microsoft Corporation.  All rights reserved.
#  
# THIS SAMPLE CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
# IF THIS CODE AND INFORMATION IS MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN
# CONNECTION WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER. 

Param
( 
    [parameter(Mandatory=$false, Position=1, HelpMessage="The name of a Remote Access server to read the configuration from.")][String] $ComputerName="localhost"
)

#
# Returns true if the local computer is Windows Server.
#
Function IsWindowsServer
{
    $windowsInfo = Get-WmiObject -Query "SELECT * FROM Win32_OperatingSystem WHERE ProductType=3"
    return [bool]$windowsInfo;
}

# Import the required PowerShell modules

Import-Module GroupPolicy -ErrorAction SilentlyContinue
Import-Module RemoteAccess -ErrorAction SilentlyContinue

if (-not (Get-Module RemoteAccess))
{
    if (IsWindowsServer)
    {
        throw 'The Windows Feature "RemoteAccess Management Tools" is not installed. (Run "Install-WindowsFeature -Name RSAT-RemoteAccess")'
    }
    else
    {
        throw 'The Windows Feature "RemoteAccess Management Tools" is not installed. (Install Remote Server Administration Tools and run "Enable-WindowsOptionalFeature -FeatureName RemoteServerAdministrationTools-Roles-RemoteAccess -Online")'
    }
}

#
# Prints an informational line to the console 
#
Function OutputLine([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message"
    
}

#
# Prints a success line to the console 
#
Function OutputSuccess([String] $message)
{
    $time = [DateTime]::Now
    Write-Host "[$time] $message" -ForegroundColor Green

}

#
# Invokes the specified cmdlet while including the script's ComputerName parameter
#
Function InvokeCmdletWithComputerName($cmdlet)
{
    if ($ComputerName -ine "localhost")
    {
        # A remote computer name is specified, append the ComputerName parameter to the invoked expression using the ComputerName parameter provided for the script
        $cmdlet = $cmdlet + " -ComputerName $ComputerName"
    }
   
    return Invoke-Expression $cmdlet -ErrorAction SilentlyContinue
}

#
# Finds the closest writeable domain controller to a specified server
#
Function GetClosestWritableDc($server)
{
    # Run the method DomainController:FindOne on the remote server in order to retrieve the DC closest to the remote server.
    $dc = Invoke-Command -ComputerName $server -ScriptBlock {
        $context = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext("Domain")
        [System.DirectoryServices.ActiveDirectory.DomainController]::FindOne($context, [System.DirectoryServices.ActiveDirectory.LocatorOptions]::WriteableRequired) 
    }
    
    return $dc.Name
}
############################################################
#################### Script Begins Here ####################
############################################################
try
{
    OutputLine("Retrieving Remote Access deployment data from server `"$ComputerName`"...")
    $RAConfig = InvokeCmdletWithComputerName("Get-RemoteAccess")
    # Check if DirectAccess is installed on the server. 
    if (!$RAConfig -or $RAConfig.DAStatus -ine "Installed")
    {
        throw "DirectAccess is not configured on the server `"$ComputerName`". Specify the name or IP address of the Remote Access server for the ComputerName parameter on which DirectAccess is configured."
    }

    OutputSuccess("Retrieved Remote Access deployment data from server `"$ComputerName`"")

    $result = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\ramgmtsvc\Config -Name DcName -ErrorAction SilentlyContinue
    if(!$result)
    {
        #Get closest DC
        OutputLine("Retrieving closest DC for server `"$ComputerName`"...")
        $closestDCName = GetClosestWritableDc($ComputerName)
        if (!$closestDCName)
        {
            throw "Failed to retrieve closest DC for server `"$ComputerName`""
        }
    }
    else
    {
        $closestDCName = $result.DcName
    }
    OutputSuccess("Retrieved closest DC for server `"$ComputerName`" : `"$closestDcName`"")
    
    $ServerGPOName = $RAConfig.ServerGpoName.Split('\')[1]

    #Check if the deployement is v4 only    
    $result = Get-GPRegistryValue -Name $ServerGPOName -Key HKLM\software\policies\microsoft\windows\remoteaccess\config\isatap -ValueName IsatapPrefix -Server $closestDCName -ErrorAction SilentlyContinue
    if(!$result)
    {
        throw "This script is valid for deployments with only IPv4 enabled in the internal network"
    }

    #Set the v6 registry key
    $result = Set-GPRegistryValue -Name $ServerGPOName -Key HKLM\software\policies\microsoft\windows\remoteaccess\config -ValueName CorpPrefix -Value $RAConfig.InternalIPv6Prefix -Type MultiString -Server $closestDCName -ErrorAction SilentlyContinue
    if(!$result)
    {
        throw "An error occurred while setting the GPO registry key"
    }
    $InternalIPv6Prefix = $RAConfig.InternalIPv6Prefix
    OutputSuccess("The CorpPrefix registry value on the server GPO `"$ServerGPOName`" is set to `"$InternalIPv6Prefix`"")

    #Remove the v4 registry key
    $result = Remove-GPRegistryValue -Name $ServerGPOName -Key HKLM\software\policies\microsoft\windows\remoteaccess\config\isatap -ValueName IsatapPrefix -Server $closestDCName -ErrorAction SilentlyContinue
    if(!$result)
    {
        throw "An error occurred while removing the GPO registry key"
    }
    OutputSuccess("The IsatapPrefix registry value on the server GPO `"$ServerGPOName`" is removed")
}
finally
{}