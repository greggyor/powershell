﻿#Add Exchange 2010 snapin and set the scope to see entire forest 
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue 
Set-ADServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue 

#Move required files on each Mailbox Server and create Schedule task for Alert
$MBServers = Get-MailboxServer | Select-Object Name | Format-Table -HideTableHeaders | Out-String -Stream | Where-Object {$_.Trim() -ne ""} | foreach {$_.TrimEnd()}

foreach ($MBServer in $MBServers)
{
    If (Test-Path "\\$MBServer\C$\ProgramData\DBMoveAlert") {Remove-Item -Path "\\$MBServer\C$\ProgramData\DBMoveAlert" -Recurse -Force}
    New-Item -ItemType directory -Path "\\$MBServer\C$\ProgramData" -Name DBMoveAlert -Force -ErrorAction silentlycontinue -WarningAction silentlycontinue
    Copy-Item .\3169.xml -Destination "\\$MBServer\C$\ProgramData\DBMoveAlert\3169.xml" -Force -ErrorAction silentlycontinue -WarningAction silentlycontinue
    Copy-Item .\3169.ps1 -Destination "\\$MBServer\C$\ProgramData\DBMoveAlert\3169.ps1" -Force -ErrorAction silentlycontinue -WarningAction silentlycontinue
    Copy-Item .\3169.cmd -Destination "\\$MBServer\C$\ProgramData\DBMoveAlert\3169.cmd" -Force -ErrorAction silentlycontinue -WarningAction silentlycontinue
    Copy-Item .\Create-3169.cmd -Destination "\\$MBServer\C$\ProgramData\DBMoveAlert\Create-3169.cmd" -Force -ErrorAction silentlycontinue -WarningAction silentlycontinue
    schtasks.exe /delete /S $MBServer /TN "Event Viewer Tasks\Application_MSExchangeRepl_3169_byScript" /F
    schtasks.exe /create /S $MBServer /TN "Event Viewer Tasks\Application_MSExchangeRepl_3169_byScript" /XML 3169.xml
}
Write-Host " "
Write-Host "Press any key to Exit..." -ForegroundColor Yellow
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
