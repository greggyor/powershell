# Initialization of helper variables
# BizTalk version numbers
$versionBTS2004 = "3.0.4902.0"
$versionBTS2004SP1 = "3.0.6070.0"
$versionBTS2004SP2 = "3.0.7405.0"
$versionBTS2006 = "3.5.1602.0"
$versionBTS2006R2 = "3.6.1404.0"
$versionBTS2009 = "3.8.368.0"
$versionBTS2010 = "3.9.469.0"

# BizTalk edition values
$branch = "Branch"
$developer = "Developer"
$standard = "Standard"
$enterprise = "Enterprise"

# BizTalk version description
$descriptionBTS2004 = "BizTalk Server 2004"
$descriptionBTS2004SP1 = "BizTalk Server 2004 with service pack 1"
$descriptionBTS2004SP2 = "BizTalk Server 2004 with service pack 2"
$descriptionBTS2006 = "BizTalk Server 2006"
$descriptionBTS2006R2 = "BizTalk Server 2006 R2"
$descriptionBTS2006R2SP1 = "BizTalk Server 2006 R2 with service pack 1"
$descriptionBTS2009 = "BizTalk Server 2009"
$descriptionBTS2010 = "BizTalk Server 2010"

# BizTalk edition description
$descriptionBranch = "Branch Edition"
$descriptionDeveloper = "Developer Edition"
$descriptionStandard = "Standard Edition"
$descriptionEnterprise = "Enterprise Edition"

# Registry paths
$bizTalkRegistryPath = "HKLM:\SOFTWARE\Microsoft\BizTalk Server"
$biztalk2006SP1UninstallRegistryPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Biztalk Server 2006 R2 Service Pack 1 `[KB 974563`]'

$installedVersion = $null
$installedEdition = $null

# Check if BizTalk is installed:
if ((Test-Path $bizTalkRegistryPath) -eq $true)
{

# Set location to BizTalk registry key
Set-Location $bizTalkRegistryPath
$key = Get-ChildItem

# Get version number
$productVersion = $key.GetValue("ProductVersion")

switch ($productVersion)
{

$versionBTS2004 { $installedVersion = $descriptionBTS2004 }
$versionBTS2004SP1 { $installedVersion = $descriptionBTS2004SP1 }
$versionBTS2004SP2 { $installedVersion = $descriptionBTS2004SP2 }
$versionBTS2006 { $installedVersion = $versionBTS2006 }
$versionBTS2006R2
{
if ((Test-Path $biztalk2006SP1UninstallRegistryPath) -eq $false)
{
$installedVersion = $descriptionBTS2006R2
}
else
{
$installedVersion = $descriptionBTS2006R2SP1
}
}
$versionBTS2009 { $installedVersion = $descriptionBTS2009 }
$versionBTS2010 { $installedVersion = $descriptionBTS2010 }
}
}

if ($installedVersion -eq $null)
{
Write-Host "BizTalk Server is not installed on this machine."
Exit
}

# Get product edition
$productEdition= $key.GetValue("ProductEdition")
switch ($productEdition)
{
$branch {$installedEdition = $descriptionBranch}
$developer {$installedEdition = $descriptionDeveloper}
$standard {$installedEdition = $descriptionStandard}
$enterprise {$installedEdition = $descriptionEnterprise}
}


Write-Host "BizTalk Server installation found on this machine."
Write-Host "Product version number: $productVersion"
Write-Host "Installed version: $installedVersion"
Write-Host "Installed edition: $installedEdition"