﻿<#
.SYNOPSIS 
Script to delete old and/or obsolete files

.DESCRIPTION
The script Remove-Files is used to remove old and/or obsolete files from the 
target directory. It can delete files that are older than a specified amount of 
time or older than a specified date or it can delete the oldest files in the 
directory keeping any number of recent files.
A filter for specific files can be applied, so it is possible to delete only a
certain type of files.

.PARAMETER  KeepFiles
Sets the number of files to keep. In combination with KeepDays or Date it
preserves at least the number of files set.

.PARAMETER  Path
Directory path where the files should be deleted. If the path contains blanks it
needs to be enclosed in double quotation marks

.PARAMETER  Date
Removes the files created before the specified date

.PARAMETER  KeepDays
Removes the files older than specified days before actual date

.PARAMETER  Recurse
Removes the files in the specified location and in all subdirectories

.PARAMETER  Extension
Removes only files that have the specified extension, for instance *.log

.Example
.\Remove-Files.ps1 -Path .\Testing -KeepFiles 3 -Recurse

Description
-----------
Removes all but the newest 3 files from the directory .\Testing and all subdirectories

.Example
.\Remove-Files.ps1 -Path .\Testing -KeepDays 7

Description
-----------
Removes all files older 7 days from the directory testing

.Example
$date = (get-Date).AddMonth(-1)
.\Remove-Files.ps1 -Path .\Testing -Date $date -Extension *.txt

Description
-----------
Removes all textfiles older than one month from directory .\Testing
#>

#region Parameter
[cmdletBinding(SupportsShouldProcess=$true)]
param(
	[Parameter(Position = 0, Mandatory = $true)]
	[ValidateScript({
		$vr = Test-Path $_
		if(!$vr){Write-Host "The provided path $_ is invalid!"}
		$vr
	})][String]$Path,
	[String][ValidatePattern("\.[a-z]{2,5}")]$Extension,	
	[Int]$KeepFiles,
	[ValidateScript({
		if($Date){$vr = $false; write-host "Parameter error see get-help .\Remove-Files.ps1"}
		else{$vr = $true}
		$vr
	})][Int]$KeepDays,
	[ValidateScript({
		if($KeepDays){$vr = $false; write-host "Parameter error see get-help .\Remove-Files.ps1"}
		else{$vr = $true}
		$vr
	})][DateTime]$Date,
	[int]$FileSize=0,
	[Switch]$Recurse
)
#endregion

#region Functions
function Remove-BeforeDate
{
	param(
		[Parameter(Mandatory = $true)][DateTime]$TargetDate,
		[Parameter(Mandatory = $true)][Int]$Keep,
		[Parameter(Mandatory = $true)][Object[]]$Files
	)
	$Files = $Files | sort-object -Property PSParentPath,LastWriteTime -Descending | Group-Object -Property PSParentPath
	$FileList = @()
	foreach ($Group in $Files){
		$i=1
		Foreach ($item in $Group.Group){
			if($Item.LastWriteTime -lt $TargetDate -and $i -gt $Keep){
				$FileList += $Item
			}
			$i++
		}
	}
	return $FileList
}
function Remove-Oldest
{
	param(
		[Parameter(Mandatory = $true)][Int]$Keep,
		[Parameter(Mandatory = $true)][Object[]]$Files
	)
	#Select all files except the most recent specified number of files
	$Files = $Files | sort-object -Property PSParentPath,LastWriteTime -Descending | Group-Object -Property PSParentPath | Where-Object {$_.count -gt $KeepFiles}
	$FileList = @()
	foreach ($Group in $Files){
		$i=1	
		foreach ($Item in $Group.Group){
			if ($i -gt $Keep){
				$FileList += $Item
			}
			$i++
		}
	}
	return $FileList
}
function Remove-Files 
{
	foreach ($File in $Files2Delete){
		if($pscmdlet.ShouldProcess($File.FullName, "Delete File")){
			Remove-Item -LiteralPath $File.FullName
		}
	}
}
#endregion

#region Main
#Get the files
if ($Recurse){$RecOption = "-Recurse"}
if ($Extension){$ExtOption = "-Filter *$Extension"}
$strGetChild = "Get-ChildItem -Path `"$Path`" $RecOption $ExtOption | Where-Object {`$_ -is [System.IO.FileInfo]}"
$cbGetChild = [scriptblock]::Create($strGetChild)

$Files = @(Invoke-Command -ScriptBlock $cbGetChild)
$Files = $Files | Where-Object {$_.Length -ge $FileSize}

if($KeepDays){
	#Select the files before the specified date
	$Files2Delete = @(Remove-BeforeDate -TargetDate ((Get-Date).AddDays(-$KeepDays)) -Files $Files -Keep $KeepFiles)
}
elseif($Date){
	#Select the files before the specified date
	$Files2Delete = Remove-BeforeDate -TargetDate $Date -Files $Files -Keep $KeepFiles
}
else{
	$Files2Delete = Remove-Oldest -Keep $KeepFiles -Files $Files
}
if ($Files2Delete -eq $null){
	Write-Host "Nothing to delete!"
}
else {
	Remove-Files $Files2Delete
}
#$Files2Delete
#endregion