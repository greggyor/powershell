# ==========================================================
#Create result directory and create GP result file
# ==========================================================
new-item c:\Z_GPRes -itemtype directory
Set-Location C:\Z_GPRes
GPRESULT /H Result.htm