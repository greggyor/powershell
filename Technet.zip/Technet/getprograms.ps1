#GetPrograms powershell script by Oliver Ford. Queries remote registries for their program list and excludes common ones
param($computername, $outputdir="C:\compprogs", $compsfile=".\complist.txt", $excludefile=".\excludelist.txt")
$writeArray =@()
$compList =@()
$excludeArray=@()

#List of programs to exclude
if ((test-path $excludefile) -eq $true) {
$excludeArray = get-content $excludefile
} else {
$excludeArray = ("Security Update for Windows",
"Update for Windows",
"Update for Microsoft .NET",
"Security Update for Microsoft",
"Hotfix for Windows",
"Hotfix for Microsoft .NET Framework")
}


# Branch of the Registry  
$Branch="LocalMachine"
 
# Main Sub Branch you need to open  
$SubBranch="SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall"  

#Function to query the remote computer
Function queryComputer($computer) {
$restartReg = $false

ping -n 1 $computer | out-null

if ($? -eq $false) {
return
}

#Check if the remote registry service is stopped. If so, start it
$regserv = Get-WmiObject -ComputerName $computer -Class Win32_Service -Filter "Name='RemoteRegistry'"
if ($regserv.State -eq "Stopped") {
$regserv.StartService() | out-null
$restartReg = $true
}
 
 #Attempt to open the HKLM branch. Return from the current query if this fails
 try {
$registry=[microsoft.win32.registrykey]::OpenRemoteBaseKey($Branch,$computer)
} catch {
return
}

#Get the names of each of the installed programs
$registrykey=$registry.OpenSubKey($Subbranch)  
$SubKeys=$registrykey.GetSubKeyNames()  

#Get the Display Name values of each of the installed programs
Foreach ($key in $subkeys)  
{  
	$donotwrite = $false
    $exactkey=$key  
    $NewSubKey=$SubBranch+"\\"+$exactkey  
    $ReadUninstall=$registry.OpenSubKey($NewSubKey)  
    $Value=$ReadUninstall.GetValue("DisplayName")  

	#For each value which is not blank, exclude it if it is in the exclude list. If not, add it to the array of programs to be written
    if (($Value -ne "") -and ($Value -ne $null)) {

	Foreach ($exclude in $excludeArray) {
	if ($Value.StartsWith($exclude) -eq $true) {
	$donotwrite = $true
		break
		}
	}

	if ($donotwrite -eq $false) {
$writeArray += $Value
	}
	}
}  

#If the Remote Registry service was started above, stop it again
if ($restartReg -eq $true) {
$regserv.StopService() | out-null
}

#Write the results to a text file
$writeArray = $writeArray | sort-object
$outputfile = "$outputdir" + '\' + "$computer" + '.txt'

if ((test-path $outputfile) -eq $true) {
Remove-Item $outputfile
}

echo $writeArray >> $outputfile
}

#If no argument passed, read from file $compsfile
if ($computername.Length -lt 1) {

if ((test-path $compsfile) -eq $false) {
echo "Computer list not found and no computer specified. Exiting"
exit
}

$compList = get-content $compsfile

#If a list of computers is specified, query for each item in the list. If not, query only the command-line argument
Foreach ($comp in $compList) {
queryComputer $comp
}

} else {
queryComputer $computername
}
