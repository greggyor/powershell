﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 3.0

Function New-OSCWindowsHibernationTile
{
    $Shell = New-Object -ComObject Shell.Application
	$Desktop = $Shell.NameSpace(0X0)
    $WshShell = New-Object -comObject WScript.Shell

     #create a new shortcut of Hibernation
    $HibernationShortcutPath = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Hibernation.lnk"
    $HibernationShortcut = $WshShell.CreateShortcut($HibernationShortcutPath)
    $HibernationShortcut.TargetPath = "$env:SystemRoot\System32\rundll32.exe"
    $HibernationShortcut.Arguments = "powrprof.dll,SetSuspendState"
    $HibernationShortcut.Save()

    #change the default icon of Hibernation shortcut
    $HibernationLnk = $Desktop.ParseName($HibernationShortcutPath)
    $HibernationLnkPath = $HibernationLnk.GetLink
    $HibernationLnkPath.SetIconLocation("$env:SystemRoot\System32\SHELL32.dll",297)
    $HibernationLnkPath.Save()
	
    #pin application to windows Start menu
    $HibernationVerbs = $HibernationLnk.Verbs()
    Foreach($HibernationVerb in $HibernationVerbs)
    {
        If($HibernationVerb.Name.Replace("&","") -match "Pin to Start")
        {
            $HibernationVerb.DoIt()
        }
    }

     If(Test-Path -Path $HibernationShortcutPath)
    {
	    Write-Host "Create Windows Hibernation Tile successfully." -ForegroundColor Green
    }
    Else
    {
        Write-Host "Failed to create Windows Hibernation Tile." -ForegroundColor Red
    }
}

New-OSCWindowsHibernationTile