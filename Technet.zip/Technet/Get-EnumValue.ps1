﻿function Get-EnumValue{ 
param (
       [type]$type,
       [switch]$object,
       [switch]$list
      )

if ($Object)
    {
        [enum]::getNames($type) | 
            select @{name="Name";expression={$_}},
                    @{name="Value";expression={$type::$_.value__}}
    }
elseif ($list)
    {
        [enum]::getNames($type)
    }
else
    {
        [enum]::getNames($type) |             
            select @{name="Name";expression={$_}},
                    @{name="Value";expression={$type::$_.value__}} | 
                        Format-Table -AutoSize
    }

}




