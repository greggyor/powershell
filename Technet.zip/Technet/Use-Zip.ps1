﻿Function Use-Zip
{
	<#
	.SYNOPSIS
		Basic zip file manager.

	.DESCRIPTION
		The Use-Zip cmdlet allows to extract zip file to specific destination or compress specific files to zip.
		
	.PARAMETER ZipFile
		Indicates path to zip file.
			
	.PARAMETER Path
		Indicates path to destination folder in extract mode or source location in compress mode.
		
	.PARAMETER Compress
		Switch between Extract and Compress mode.
		
	.EXAMPLE
		PS P:\> Use-Zip -ZipFile P:\ZipFile.zip -Path P:\ExtractDirectory

		Description 
		----------- 
		Extract zip file P:\ZipFile.zip to location P:\ExtractDirectory


	.EXAMPLE
		PS P:\> Use-Zip -ZipFile P:\ZipFile.zip -Path P:\ExtractDirectory -Compress

		Description 
		----------- 
		Compress content of location P:\ExtractDirectory to zip file P:\ZipFile.zip
		
	.NOTES
		Author: Michal Gajda
		Blog  : http://commandlinegeeks.com/
	#>	

	Param
	(
		[parameter(Mandatory=$true)]
		[String]$ZipFile,
		[parameter(Mandatory=$true)]
		[String]$Path,
		[Switch]$Compress = $false
	)

	[Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null
	if($Compress)
	{
		$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
		$includebasedir = $false
		[System.IO.Compression.ZipFile]::CreateFromDirectory($Path,$ZipFile,$compressionLevel,$includebasedir)
	}
	else
	{
		[System.IO.Compression.ZipFile]::ExtractToDirectory($ZipFile,$Path)	
	}
}