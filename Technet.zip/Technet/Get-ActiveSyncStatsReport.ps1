﻿If ((Get-PSSnapin | where {$_.Name -match "Exchange.Management"}) -eq $null)
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin
}

Get-CASMailbox -Filter {hasactivesyncdevicepartnership -eq $true -and -not displayname -like "CAS_{*"} | Get-Mailbox | 
ForEach-Object {
	Get-ActiveSyncDeviceStatistics -Mailbox $_ | Select-Object Identity,LastSuccessSync,DeviceID,DeviceType | 
	Where-Object { $_.LastSuccessSync -gt $((Get-Date).AddDays(-60)) }
}