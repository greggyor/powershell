param([string]$siteUrl, [string]$listName, [string]$keyColumnName, [string]$valueColumnName, [bool]$valueFlag, [string]$output)

Add-PsSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue 

function createCPEDictionaryFromSPList ($url, $listName, $keyFieldName, $valueFieldName, $valueFlag, $output){
    # Get list from specified Sharepoint web
    $SPWeb = get-spweb $url

    $uniqueKeyValue = new-object System.Collections.Specialized.NameValueCollection
    
    if($listName -is [array]) {
        foreach($name in $listName)
        {
            $reflist = $SPWeb.Lists.TryGetList($name)
            $keyFName = $keyFieldName[$name]
            $valueFName = $valueFieldName[$name]
            
            foreach ($listItem in $reflist.Items) {
                $keyFieldValue = $listItem[$keyFName]
                $valueFieldValue = $listItem[$valueFName]

                if($keyFieldValue) {
                    if($valueFlag -and $valueFieldValue) {
                      $uniqueKeyValue.add($keyFieldValue, $valueFieldValue)
                    } else {
                      $uniqueKeyValue.add($keyFieldValue, $keyFieldValue)
                    }
                }
            }
        }
    } else {
        $reflist = $SPWeb.Lists.TryGetList($listName)
        
        foreach ($listItem in $reflist.Items) {
            $keyFieldValue = $listItem[$keyFieldName]
            $valueFieldValue = $listItem[$valueFieldName]
            
            if($keyFieldValue) {
                if($valueFlag -and $valueFieldValue) {
                  $uniqueKeyValue.add($keyFieldValue, $valueFieldValue)
                } else {
                  $uniqueKeyValue.add($keyFieldValue, $keyFieldValue)
                }
            }
        }
    }
    
    # Create XML with the root element
    [XML]$outputXml = "<dictionary></dictionary>"
    $root = $outputXml.get_DocumentElement()
    
    # Add entry elements
    foreach ($key in ($uniqueKeyValue.AllKeys | sort))
    {
        $element = $outputXml.CreateElement("entry")
        $element.SetAttribute("key", $key)
        $element.SetAttribute("value", $uniqueKeyValue.GetValues($key))
        [void]$root.AppendChild($element)
    }
    
    $SPWeb.Dispose()
    
    # Save the output XML file
    $XmlWriter = New-Object System.Xml.XmlTextWriter($output, [System.Text.Encoding]::UTF8)
    $xmlWriter.Formatting = [System.Xml.Formatting]::Indented
    $outputXml.Save($XmlWriter)
    $xmlWriter.Close()
    
    return
}

createCPEDictionaryFromSPList $siteUrl $listName $keyColumnName $valueColumnName $valueFlag $output