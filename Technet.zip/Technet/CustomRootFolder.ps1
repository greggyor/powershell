[string]$info = "White"                # Color for informational messages
[string]$warning = "Yellow"            # Color for warning messages
[string]$error = "Red"                 # Color for error messages
[string]$LogFile = "C:\Temp\Log.txt"   # Path of the Log File 

function CreateFolder($MailboxName)
{
    Write-host "Creating Folder for Mailbox Name:" $MailboxName -foregroundcolor  $info
    Add-Content $LogFile ("Creating Folder for Mailbox Name:" + $MailboxName) 

    #Change the user to Impersonate
    $service.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$MailboxName); 

    #Create the folder object 

 $oFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($service)
    $oFolder.DisplayName = $FolderName 

    #Call Save to actually create the folder
    $oFolder.Save([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::msgfolderroot) 

    Write-host "Folder Created for " $MailboxName -foregroundcolor  $warning
    Add-Content $LogFile ("Folder Created for " + $MailboxName) 

    $service.ImpersonatedUserId = $null
} 

#Change the name of the folder
$FolderName = "Customer Folder Name"
Import-Module -Name "C:\Program Files\Microsoft\Exchange\Web Services\1.1\Microsoft.Exchange.WebServices.dll" 

$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP1) 

# Set the Credentials
$service.Credentials = new-object Microsoft.Exchange.WebServices.Data.WebCredentials("Administrator","Type your Password Here","careexchange.in") 

# Change the URL to point to your cas server
$service.Url= new-object Uri("https://localhost/EWS/Exchange.asmx")

# Set $UseAutoDiscover to $true if you want to use AutoDiscover else it will use the URL set above
$UseAutoDiscover = $false
$a = get-mailbox 

$a | foreach-object {
    $WindowsEmailAddress = $_.WindowsEmailAddress.ToString() 

    #if ($UseAutoDiscover -eq $true) {
       # Write-host "Autodiscovering.." -foregroundcolor $info
        #$UseAutoDiscover = $false
        $service.AutodiscoverUrl($WindowsEmailAddress)
        #Write-host "Autodiscovering Done!" -foregroundcolor $info
       # Write-host "EWS URL set to :" $service.Url -foregroundcolor $info 

   # }
    #To catch the Exceptions generated
   # trap [System.Exception] 
   # {
    #    Write-host ("Error: " + $_.Exception.Message) -foregroundcolor $error;
   #     Add-Content $LogFile ("Error: " + $_.Exception.Message);
   #     continue;
   # }
    CreateFolder($WindowsEmailAddress)
}
