# Enable Lync User
# ** Need to update Lync-FE.MyDomain.com to your Full DNS name of your Lync Front End Server **

Write-Host
Write-Host "This enables a DIFZ User Account to be able to use Lync"
Write-Host
$User = Read-Host "Enter User Account Name (Ex: John.Doe): "

# Get User Information
$UserInfo = Get-CSADuser $User
$Name = $UserInfo.Displayname
$SipAddr = "sip:"+$UserInfo.WindowsEmailAddress

# Enable User for Lync
Enable-CSuser -identity $Name -RegistrarPool Lync-FE.MyDomain.com -SipAddress $SipAddr

# Final Words
Write-Host
Write-Host $Name " can now use Lync."
Write-Host


