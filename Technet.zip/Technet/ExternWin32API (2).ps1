$code = @"
    // http://pinvoke.net/default.aspx/kernel32/GetStdHandle.html
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr GetStdHandle(
        int nStdHandle
        );

    // http://pinvoke.net/default.aspx/kernel32/FillConsoleOutputAttribute.html
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool FillConsoleOutputAttribute(
        IntPtr hConsoleOutput,
        ushort wAttribute, 
        uint nLength, 
        COORD dwWriteCoord, 
        out uint lpNumberOfAttrsWritten
        );

    [StructLayout(LayoutKind.Sequential)]
    public struct COORD
    {
       public short X;
       public short Y;
    }
"@

Add-Type -MemberDefinition $code -Name kernel32 -Namespace Win32
