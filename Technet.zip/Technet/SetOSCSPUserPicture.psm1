<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Set-OSCSPUserPicture
{
	#.EXTERNALHELP Set-OSCSPUserPicture-Help.xml

	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$MySiteHostLocation,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$UserProfileServiceApplicationName,		
		[Parameter(Mandatory=$true,Position=3)]
		[string]$UserPictureLibrary,
		[Parameter(Mandatory=$false,Position=4)]
		[ValidateSet("SamAccountName","DisplayName")]
		[string]$PictureNameFormat="DisplayName",		
		[Parameter(Mandatory=$false,Position=5)]
		[switch]$UseDefaultPicture
	)
	Process
	{
		#Try to get site, web, library objects and user profile service application
		Try
		{
			$spSite = Get-SPSite -Identity $MySiteHostLocation -Verbose:$false -ErrorAction:Stop
			$spCurrentUserLogin = $spSite.RootWeb.CurrentUser.LoginName
			$spPicSite = New-Object Microsoft.SharePoint.SPSite -ArgumentList $UserPictureLibrary
			$spPicWeb = $spPicSite.OpenWeb()
			$spPicLib = $spPicWeb.GetList($UserPictureLibrary)
			$spUPSA = Get-SPServiceApplication -Name $UserProfileServiceApplicationName -Verbose:$false -ErrorAction:Stop		
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($Error[0])
		}
		if ($spPicLib.BaseTemplate -ne "PictureLibrary") {
			$errorMsg = $Messages.WrongLib
			$errorMsg = $errorMsg -f $UserPictureLibrary
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)			
		}
		#Verify current user's permissions for managing profiles.
		$spAppSecAdmins = Get-SPServiceApplicationSecurity -Identity $spUPSA -Admin -Verbose:$false
		$currentUserAcl = $spAppSecAdmins.ToAcl() | ?{$_.PrincipalName -eq $spCurrentUserLogin}
		if ($currentUserAcl -ne $null) {
			$manageProfilesMask = 72057594037927937
			$rightsMask = $currentUserAcl.GrantRightsMask
			if ($rightsMask -eq "FullControl") {
				$hasManageProfilesPermission = $true
			} else {
				if (($rightsMask -band $manageProfilesMask) -eq $manageProfilesMask) {
					$hasManageProfilesPermission = $true
				} else {
					$hasManageProfilesPermission = $false
				}
			}
		} else {
			$hasManageProfilesPermission = $false
		}
		$spAppSec = Get-SPServiceApplicationSecurity -Identity $spUPSA -Verbose:$false
		$spAppSecAccessRules = $spAppSec.GetAccessRules()
		$currentUserAccessRule = $spAppSecAccessRules | ?{$_.Name -like "*$spCurrentUserLogin"}
		if ($currentUserAccessRule -ne $null) {
			$hasConnectionPermission = $true
		} else {
			$hasConnectionPermission = $false
		}
		#If current user has enough permission,begin to change user picture
		if ($hasManageProfilesPermission -and $hasConnectionPermission) {
			#Try to get all user profiles
			$spSvcContext = Get-SPServiceContext -Site $spSite -Verbose:$false
			$profileMgr = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($spSvcContext)
			$userProfiles = $profileMgr.GetEnumerator()
			#Iterate each user profile
			foreach ($userProfile in $userProfiles) {
				#Use CAML query to find user pictures in specified library
				$spQuery = New-Object Microsoft.SharePoint.SPQuery
				$userDisplayName = $userProfile.DisplayName
				if ($PictureNameFormat -eq "DisplayName") {
					$camlQuery = "<Where><BeginsWith><FieldRef Name='NameOrTitle' /><Value Type='Computed'>$userDisplayName</Value></BeginsWith></Where>"
				} else {
					$accountName = $userProfile["AccountName"].Value.Split("\")[1]
					$camlQuery = "<Where><BeginsWith><FieldRef Name='NameOrTitle' /><Value Type='Computed'>$accountName</Value></BeginsWith></Where>"
				}
				$spQuery.Query = $camlQuery
				$spQuery.ViewAttributes = 'Scope="Recursive"'
				$spPicItem = $spPicLib.GetItems($spQuery)
				if ($pscmdlet.ShouldProcess($userDisplayName)) {
					if ($spPicItem.Count -eq 1) {	
						$absoluteUrl = [System.String]::Concat($spPicLib.ParentWeb.Url,"/",$spPicItem[0].Url)
						$absoluteUrl = [Microsoft.SharePoint.Utilities.SPEncode]::UrlEncodeAsUrl($absoluteUrl)
						$userProfile["PictureUrl"].Value = $absoluteUrl
						$userProfile.Commit()
					} else {
						$warningMsg = $Messages.CannotFindPic
						$warningMsg = $warningMsg -f $userDisplayName
						$pscmdlet.WriteWarning($warningMsg)
						if ($UseDefaultPicture) {
							$warningMsg = $Messages.UseDefaultPicture
							$warningMsg = $warningMsg -f $userDisplayName
							$pscmdlet.WriteWarning($warningMsg)						
							$userProfile["PictureUrl"].Value = $null
							$userProfile.Commit()
						}
					}
				}
			}
		} else {
			$errorMsg = $Messages.LackOfPermission
			$errorMsg = $errorMsg -f $spCurrentUserLogin
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)			
		}
		$spPicWeb.Dispose()
		$spPicSite.Dispose()
		$spSite.Dispose()
	}
}

Export-ModuleMember -Function "Set-OSCSPUserPicture"