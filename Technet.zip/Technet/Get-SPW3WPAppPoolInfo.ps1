﻿Function Get-SPW3WPAppPoolInfo
{
  <#
  .SYNOPSIS
  This PowerShell function fully automates the task of identifying which w3wp.exe processes 
  are running which IIS Application Pools for SharePoint 2010 and SharePoint 2013. 
  .DESCRIPTION
  This PowerShell function fully automates the task of identifying which w3wp.exe processes 
  are running which IIS Application Pools for SharePoint 2010 and SharePoint 2013.
  This function has been verified to work with:
  ---SharePoint 2013 on Windows Server 2012 (IIS 8)
  ---SharePoint 2010 on Windows Server 2008 R2 (IIS 7.5) 
  .EXAMPLE
  Get-SPW3WPAppPoolInfo
  .EXAMPLE
  Get-SPW3WPAppPoolInfo -Verbose
  .EXAMPLE
  Get-SPW3WPAppPoolInfo -W3WPID 1234
  .EXAMPLE
  1234 | Get-SPW3WPAppPoolInfo
  .EXAMPLE
  Get-SPW3WPAppPoolInfo | where {$_.W3WPID -eq 1234}
  .PARAMETER W3WPID
  The W3WP.exe ID that you wish to filter 
  .Notes
  Name: Get-SPW3WPAppPoolInfo
  Author: Craig Lussier
  Last Edit: February 8th, 2013
  .Link
  http://www.craiglussier.com
  http://twitter.com/craiglussier
  http://social.technet.microsoft.com/profile/craig%20lussier/
  # Requires PowerShell Version 2.0 or Version 3.0
  # Requires to be executed as an Administrator
  # Requires to be executed on a Windows Server 2012 Server running SharePoint 2013 and PowerShell 3.0 
  # Requires to be executed on a Windows Server 2008 R2 Server running SharePoint 2010 and PowerShell 2.0
  #>
  [CmdletBinding()]

      Param(
      [Parameter(Position=0, Mandatory=$false, ValueFromPipeline=$true, ValueFromPipelinebyPropertyName=$true)]
      [int]$W3WPID 
      )
 
      Begin {
        Write-Verbose "Entering Begin Block"

        If (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
        {
           Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
           Exit
        }

        try {
            $isSPPowerShellLoadedOnStart = $null
            $SPSnapin = "Microsoft.SharePoint.PowerShell"
            if (Get-PSSnapin $SPSnapin -ErrorAction SilentlyContinue) {
            $isSPPowerShellLoadedOnStart = $true
                Write-Verbose "Microsoft.SharePoint.PowerShell Snappin already registered and loaded"
            }
            elseif (Get-PSSnapin $SPSnapin -Registered -ErrorAction SilentlyContinue) {
            $isSPPowerShellLoadedOnStart = $false
                Add-PSSnapin $SPSnapin 
                Write-Verbose "Microsoft.SharePoint.PowerShell Snappin is registered and has been loaded for script operation"
            }
            else {
                Write-Error "Microsoft.SharePoint.PowerShell Snappin not found. Exit function."
                Exit
            }

        }
        catch [System.Exception] {

            Write-Error "There was an issue loading the Microsoft.SharePoint.PowerShell Snappin. Exit function."
            Exit

        }

        Write-Verbose "Leaving Begin Block"
      } # End of Begin
 
      Process {
        Write-Verbose "Entering Process Block"
 
        Write-Verbose "Creating an ArrayList to store custom PSObjects"
        $processCollection = New-Object System.Collections.ArrayList

        Write-Verbose "Determine whether W3WPID Parameter has been provided by user"

        $W3WPProcessSupplied = $false
        if($W3WPID) {
            $W3WPProcessSupplied = $true
        }

 
        Write-Verbose "Fetch running w3wp.exe processes using WMI" 
        $w3wpProcesses = $null
        if($W3WPProcessSupplied) {
            $w3wpProcesses = Get-WmiObject Win32_Process | where {$_.Name -eq "w3wp.exe" -and $_.ProcessId -eq $W3WPID}
        }
        else {
            $w3wpProcesses = Get-WmiObject Win32_Process | where {$_.Name -eq "w3wp.exe"}
        }
 
        Write-Verbose "Fetch Worker Processes from IIS using WMI"
        $iisWorkerProcesses = $null
        if($W3WPProcessSupplied) {
            $iisWorkerProcesses = Get-WmiObject -Class 'WorkerProcess' -NameSpace 'root\WebAdministration' | where {$_.ProcessId -eq $W3WPID}
        }
        else {
            $iisWorkerProcesses = Get-WmiObject -Class 'WorkerProcess' -NameSpace 'root\WebAdministration'
        } 
 
        Write-Verbose "Entering foreach loop - process each w3wp.exe process" 
        foreach($w3wpProcess in $w3wpProcesses) {
 
            $processID = $w3wpProcess.ProcessId
            Write-Verbose "-W3WP.exe Process: $ProcessId" 

            Write-Verbose "--Fetch Domain\Username information"
            $processAccount = $w3wpProcess.GetOwner().User
            $processDomain = $w3wpProcess.GetOwner().Domain

            Write-Verbose "--Fetch w3wp.exe process using Get-Process cmdlet (System.Diagnostics.Process)"
            $w3wpGetProcess = Get-Process w3wp | where {$_.Id -eq $w3wpProcess.ProcessId}

            Write-Verbose "--Fetch the IIS Worker Process associated with instance of w3wp.exe"
            $iisWorkerProcess = $iisWorkerProcesses | where {$_.ProcessId -eq $w3wpProcess.ProcessId}

            Write-Verbose "--Fetch the Application Pool Name from the IIS Worker Process"
            $iisAppPoolName = $iisWorkerProcesses | where {$_.ProcessId -eq $w3wpProcess.ProcessId} | select -expand AppPoolName #$appPoolName #$iisWorkerProcess | where {$_.ProcessId -eq $w3wpProcess.ProcessId} | select AppPoolName

            Write-Verbose "--Fetch the w3wp.exe process Command Line Arguments"
            $w3wpCommandLine = $w3wpProcess.CommandLine
 
            Write-Verbose "--Creating new PSObject"
                $object = New-Object PSObject -Property @{        
                    W3WPID                = $w3wpProcess.ProcessId
                    W3WPProcessWMI        = $w3wpProcess
                    W3WPProcess           = $w3wpGetProcess
                    WorkerProcessWMI      = $iisWorkerProcess
                    W3WPCommandLine       = $w3wpCommandLine
                    isSharePoint          = $false                              
                    IISAppPoolName        = $iisAppPoolName
                    SPAppPoolFriendlyName = ""
                    ProcessDomain         = $processDomain
                    ProcessAccount        = $processAccount
                    ProcessAccountName    = $processDomain + "\" + $processAccount                
       
                 }
   
            Write-Verbose "--Add new PSObject into the ArrayList"
            $processCollection.Add($object) | Out-Null
 
        }
        Write-Verbose "Leaving foreach loop - done processing each w3wp.exe process"
 
 
 
        Write-Verbose "Fetch SharePoint Web Applications"
        $webapplications = Get-SPWebApplication -includecentraladministration
 

        Write-Verbose "Entering foreach loop - process each SharePoint Web Application" 
        Write-Verbose "All must be inspected as we don't know at any given moment which Web Applications will have a live Application Pool"
        foreach($webapplication in $webapplications) {
           
            $webAppDisplayName = $webapplication.DisplayName
            Write-Verbose "-SharePoint Web Application: $webAppDisplayName" 

            Write-Verbose "--Fetch SharePoint Web Application Application Pool Name"
            $appPoolName = [string]($webapplication.ApplicationPool.Name)
 
            Write-Verbose "--Fetch the associated win_32 w3wp.exe process from the WMI collection"
            $w3wpProcess = $processCollection | where {$_.IISAppPoolName -eq $appPoolName}
 
            Write-Verbose "--Fetch the associated win_32 w3wp.exe process ID from the WMI collection"
            $w3wpProcessID = $w3wpProcess.W3WPID
 
            Write-Verbose "--Determine the ArrayList object index number for the w3wp.exe process associated with the Application Pool for this Web Application, if it exists"
            $indexCounter=0
            $indexSelected = -1
            $processCollection | foreach-object {if($_.W3WPID -eq $w3wpProcessID) { $indexSelected = $indexCounter;} $indexCounter++}
 
            Write-Verbose "--If there is an live Application Pool for this Web App, ensure the 'SPAppPoolFriendlyName' and 'isSharePoint' PSObject properties are populated."
            if($indexSelected -ne -1) {         
            $curValue = $processCollection[[int]$indexSelected].SPAppPoolFriendlyName
                if($curValue -eq "") {
                    $processCollection[[int]$indexSelected].SPAppPoolFriendlyName = $appPoolName
                    $processCollection[[int]$indexSelected].isSharePoint = $true
                }
 
            }
 
        }
        Write-Verbose "Leaving foreach loop - done processing SharePoint Web Applications"
 
  
        Write-Verbose "Fetch SharePoint Service Applications which utilize an Application Pool in IIS"
        $serviceapplications = Get-SPServiceApplication | where {$_.ApplicationPool -ne $null}
 

        Write-Verbose "Entering foreach loop - process each SharePoint Service Application" 
        Write-Verbose "All must be inspected as we don't know at any given moment which Service Applications will have a live Application Pool"
        foreach($serviceapplication in $serviceapplications) {
 
            $serviceAppDisplayName = $serviceapplication.DisplayName
            Write-Verbose "-SharePoint Service Application: $serviceAppDisplayName" 


            Write-Verbose "--Fetch Service Application Pool name. Some app pools use the friendly name as the app pool name in IIS"             
            $appPoolFriendlyName = [string]($serviceapplication.ApplicationPool.Name)

 
            Write-Verbose "--Fetch Service Application Pool Guid. Some app pools use the guid as the app pool name in IIS (with dashes stripped)"
            $appPoolGuidName = ([string]$serviceapplication.ApplicationPool.Id).Replace("-","")
  
            Write-Verbose "--Check Friendly and Guid names against IIS Application Pools to make an association"
            $checkFriendlyName = $iisWorkerProcess | where {$_.AppPoolName -eq $appPoolFriendlyName}
            $checkGuidName     = $iisWorkerProcess | where {$_.AppPoolName -eq $appPoolGuidName}
 
            Write-Verbose "--Determine Service Application Pool w3wp.exe process"
            $w3wpProcessID = $null
            if($checkFriendlyName -ne "") {
                $w3wpProcessID = $checkFriendlyName.ProcessID
            }
            elseif($checkGuidName -ne "") {
                $w3wpProcessID = $checkGuidName.ProcessID
            }
           
            Write-Verbose "--Determine the ArrayList object index number for the w3wp.exe process associated with the App Pool for this Service App, if it exists"
            $indexCounter=0
            $indexSelected = $null
            $processCollection | foreach-object {if($_.W3WPID -eq $w3wpProcessID) { $indexSelected = $indexCounter;} $indexCounter++}
 
            Write-Verbose "--If there is an live App Pool for this Service App, ensure the 'SPAppPoolFriendlyName' and 'isSharePoint' PSObject properties are populated."
            $curValue = $processCollection[[int]$indexSelected].SPAppPoolFriendlyName
            if($curValue -eq "") { 
                $processCollection[[int]$indexSelected].SPAppPoolFriendlyName = $appPoolFriendlyName
                $processCollection[[int]$indexSelected].isSharePoint = $true
            }
  
        }
        Write-Verbose "Leaving foreach loop - done processing SharePoint Service Applications"


        Write-Verbose "Create the pipeline output - select and filter the ArrayList objects"
        $pipelineOutput = $null
        $pipelineOutput = $processCollection |  select W3WPID, w3wpProcess, w3wpProcessWMI, WorkerProcessWMI, W3WPCommandLine, isSharePoint, IISAppPoolName, SPAppPoolFriendlyName, ProcessDomain, ProcessAccount, ProcessAccountName | sort w3wpid

 
        Write-Verbose "Send the pipeline output to the pipeline"
        Write-Output $pipelineOutput 
 
        Write-Verbose "Leaving Process Block"

    } 

} # End Function