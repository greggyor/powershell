# Get-DNSandWINS.ps1
# Written by Bill Stewart (bstewart@iname.com)

#requires -version 2

<#
.SYNOPSIS
Outputs the computer name, IP address(es), DNS server(s), and WINS server addresses for one or more computers.

.DESCRIPTION
Outputs the computer name, IP address(es), DNS server(s), and WINS server addresses for one or more computers.

.PARAMETER ComputerName
One or more computer names. This parameter accepts pipeline input.

.EXAMPLE
PS C:\> Get-DNSAndWINS server1
Outputs information for server1.

.EXAMPLE
PS C:\> Get-DNSAndWINS server1,server2
Outputs information for server1 and server2.

.EXAMPLE
PS C:\> Get-DNSAndWINS (Get-Content ComputerList.txt)
Outputs information for the computers listed in ComputerList.txt.

.EXAMPLE
PS C:\> Get-Content ComputerList.txt | Get-DNSAndWINS
Same as previous example (Outputs information for the computers listed in ComputerList.txt).
#>

param(
  [parameter(ValueFromPipeline=$TRUE)]
    [String[]] $ComputerName=$ENV:COMPUTERNAME
)

begin {
  $PIPELINEINPUT = (-not $PSBOUNDPARAMETERS.ContainsKey("ComputerName")) -and (-not $ComputerName)

  # Outputs the specified array as a comma-delimited string.
  function get-stringfromarray([String[]] $array) {
    $output = ""
    $array | foreach-object {
      if ($output -eq "") { $output += $_ } else { $output += ",$_" }
    }
    $output
  }

  # Outputs the computer name, IP address, and DNS and WINS settings
  # for every IP-enabled adapter on the specified computer.
  function get-info($computerName) {
    get-wmiobject Win32_NetworkAdapterConfiguration -computername $computerName -filter "IPEnabled=True" | foreach-object {
      $netConfig = $_
      $output = new-object PSObject
      $output | add-member NoteProperty "ComputerName" $computerName
      foreach ($ipAddress in $netConfig.IPAddress) {
        $output | add-member NoteProperty "IPAddress" $ipAddress
        $output | add-member NoteProperty "DNSServerSearchOrder" (get-stringfromarray $netConfig.DNSServerSearchOrder)
        $output | add-member NoteProperty "WINSPrimaryServer" $netConfig.WINSPrimaryServer
        $output | add-member NoteProperty "WINSSecondaryServer" $netConfig.WINSSecondaryServer
        $output
      }
    }
  }
}

process {
  if ($PIPELINEINPUT) {
    get-info $_
  }
  else {
    $ComputerName | foreach-object {
      get-info $_
    }
  }
}
