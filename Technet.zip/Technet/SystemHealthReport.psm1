﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -version 2.0

Function Get-OSCSystemHealthReport
{
<#
 	.SYNOPSIS
        Get-OSCSystemHealthReport is an advanced function which can be used to get a system health report.
    .DESCRIPTION
        Get-OSCSystemHealthReport is an advanced function which can be used to get a system health report.
    .PARAMETER  SaveToPath
		Specifies the path to an item. 
	.PARAMETER	ComputerName
		Specifies the computers on which the command runs. The default is the local computer. 
    .EXAMPLE
        C:\PS> Get-OSCSystemHealthReport -SaveToPath C:\HealthReport
		
		This command shows generate a system health report to C:\HealthReport.
    .EXAMPLE
    	C:\PS> Get-OSCSystemHealthReport -SaveToPath C:\HealthReport -ComputerName Client8
		
		This command shows generate a system health report to C:\HealthReport on the computer "Client8".
#>
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=0)]
		[String]$SaveToPath,
		[Parameter(Mandatory=$false,ValueFromPipeline=$true)]
		[Alias('CN','Computer')][String[]]$ComputerName=$Env:COMPUTERNAME
	)

	
	Foreach($CN in $ComputerName)
	{
		#test server connectivity
		$PingResult = Test-Connection -ComputerName $ComputerName -Count 1 -Quiet
		If($PingResult)
		{			
			If(Test-Path -Path $SaveToPath)
			{
				Write-Host "Generating system health report..."
				Start-Process -FilePath "$env:SystemRoot\System32\perfmon" -ArgumentList "/report" -WindowStyle Hidden
				
				#waiting for a report to be generated
				Start-Sleep -Seconds 100
				$DiagnosticsFullName = Get-ChildItem -Path "$env:SystemDrive\PerfLogs\System\Diagnostics" |`
				Sort-Object LastWriteTime -Descending | Select-Object -First 1 | ForEach-Object{$_.FullName}
				
				$ReportFile = "$DiagnosticsFullName\report.html"
				
				#check whether the report is generated, if the report exists, then close the process.
				If(Test-Path -Path $ReportFile)
				{
					Stop-Process -Name "perfmon"
				}
				
				#initial a variable
				$ComputerName = $Env:COMPUTERNAME
				$key = $(Get-Date -format "MMddhhmm")
				$FileName = $ComputerName+"_"+$key
				
				#move the report to specified path
				Copy-Item -Path "$DiagnosticsFullName\report.html" -Destination $SaveToPath -Force
				Rename-Item -Path "$SaveToPath\report.html" -NewName "$FileName.html"
				Write-Host "Generate system health report successfully."
			}
			Else
			{
				Write-Warning "Cannot find path '$SaveToPath'. If you want to save the report file to $SaveToPath, please input a correct path."
			}
		}
		Else
		{
			Write-Host "Cannot ping to $CN, please check the network connection."
		}
	}
}
