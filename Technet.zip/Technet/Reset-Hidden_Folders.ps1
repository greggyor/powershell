﻿<#
 author: Aman Dhally
 date: 25-Jan-2012
 version: 1
 Purpose: change the Attributes of "Hidden" folder to "Normal"
 mail: amandhally@gmail.com
 website: http://www.amandhally.net/blog
 
 blog: http://newdelhipowershellusergroup.blogspot.com/

			/^(o.o)^\ 

more info: http://newdelhipowershellusergroup.blogspot.com/2012/01/script-to-reset-hidden-files-and.html 

#>

## Change "D:\P-temp" with your folder path 

$Filepath = Get-ChildItem -Recurse -path "D:\P-Temp\" -Force  

$HSfiles = $Filepath | where { $_.Attributes -match "Hidden"}

$HSfiles

foreach ( $Object in $HSfiles ) {
	
	
	$Object.Attributes = "Archive" 
	
	
	}

### End of script #####
