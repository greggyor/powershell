﻿<# 
 Author:   Andreas Werner
 Create:   12.12.2012
 Change :    
 Version:  1.0
 From:     Germany
 Email:    ps@werner-it.net
 Website:  www.werner-it.net

 Description
 Compilation of all important data Forest
#>

function Get-ForestInfo(){

$ForestMode=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().ForestMode
$RootDomain=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().RootDomain

Write-host "Forest Mode: $ForestMode" -ForegroundColor DarkRed -BackgroundColor yellow
Write-Host "Root Domain: $RootDomain" -ForegroundColor DarkRed -BackgroundColor yellow
}


function Get-DomainInfo(){

$Domains=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Domains
$Domains | foreach {
    $Domain_Entry = New-Object system.object
    $Domain_Entry | Add-Member -Type NoteProperty -Name 'Domain' -Value $_.name -Force
    $Domain_Entry | Add-Member -Type NoteProperty -Name 'Domain Mode' -Value $_.DomainMode -Force
    return $Domain_Entry
    }

}

function Get-DCInfo(){

$Forest=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
$Domains=$Forest.Domains

$Domains | foreach {
   
   $contex=New-Object system.directoryservices.activedirectory.DirectoryContext("Domain",$_.name)
   $DClist=[system.directoryservices.activedirectory.domaincontroller]::FindAll($contex)
   $DClist | ForEach-Object {
        $DC_Entry = New-Object system.object
        $DC_Entry | Add-Member -Type NoteProperty -Name 'Domaincontroller' -Value $_.name -Force
        $IPv4=[System.Net.Dns]::GetHostAddresses($_.name).IPAddressToString
        $DC_Entry | Add-Member -Type NoteProperty -Name 'IP-Adress' -Value $IPv4 -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'IP-Adress' -Value $IPv4 -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'Site' -Value $_.SiteName -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name ' GC ' -Value $_.IsGlobalCatalog() -Force   
        
        $SchemaMaster="";$DomainMaster="";$PDCEmulator="";$RIDMaster="";$InfraMaster=""

        if ($_.Roles -eq "SchemaRole") {$SchemaMaster="  x"}
        if ($_.Roles -eq "NamingRole") {$DomainMaster="  x"}
        if ($_.Roles -eq "PdcRole") {$PDCEmulator=" x"}
        if ($_.Roles -eq "RidRole") {$RIDMaster=" x"}
        if ($_.Roles -eq "InfrastructureRole") {$InfraMaster="      x"}
        $DC_Entry | Add-Member -Type NoteProperty -Name 'Schema' -Value $SchemaMaster -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'Domain' -Value $DomainMaster -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'PDC' -Value $PDCEmulator -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'RID' -Value $RIDMaster -Force
        $DC_Entry | Add-Member -Type NoteProperty -Name 'Infrastructure' -Value $InfraMaster -Force

               
        return $DC_Entry     
                }
   
}
    
}

function Get-SitesInfo(){
$Sites=[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Sites

$Sites | ForEach-Object {
        Write-host "Site-Name:         "$_.name -BackgroundColor Yellow -ForegroundColor DarkRed
        Write-host "Subnets:           "$_.Subnets
        Write-host "Servers in Sites:  "$_.Servers
        Write-host "BridgeheadServers: "$_.BridgeheadServers
        Write-host "Site Links:        "$_.SiteLinks
        Write-host "ISTG:              "$_.InterSiteTopologyGenerator
        Write-host ""
        }

}
#------> START <-----
Clear-Host

Get-ForestInfo

$Domain_Table=@()
$Domain_Table += Get-DomainInfo
$Domain_Table | Format-Table -AutoSize

$DC_Table=@()
$DC_Table += Get-DCInfo
$DC_Table | Format-Table -AutoSize

SitesInfo