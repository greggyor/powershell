﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Import Active Directory Module
if ((Get-Module -Name ActiveDirectory -ListAvailable) -ne $null) {
	if ((Get-Module -Name ActiveDirectory) -eq $null) {
		Import-Module ActiveDirectory
	}
} else {
	$errorMsg = $Messages.InstallADModule
	throw $errorMsg
}
#Add Assembly
Add-Type -AssemblyName System.Drawing
#Use nested hash table to cache all policies
#Nested hash table structure: $cachedPolicies=@{"PolicyType"=@{"PolicyIdentity"=PolicyObject}}
$cachedPolicies = @{}
#Cache site objects
$cachedCsSites = Get-CsSite

Function Test-OSCCsUserPhoto
{
	#.EXTERNALHELP Test-OSCCsUserPhoto-Help.xml

	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Path
	)
	Process
	{
		#Try to get photo file
		Try
		{
			$file = Get-ChildItem -Path $Path
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($Error[0])
		}
		#Check photo size
		#The recommended thumbnail photo size in pixels is 96x96 pixels.
		#The size of thumbnail photo should be less than 100KB.
		$image = [System.Drawing.Image]::FromFile($file.FullName)
		$fileSize = $file.Length
		if (($fileSize -gt 100KB) -or ($image.Width -ne 96) -or ($image.Height -ne 96)) {
			return $false
		} else {
			return $true
		}
		$image.Dispose()
	}
}

Function Get-OSCCsUserEffectiveClientPolicy
{
	#.EXTERNALHELP Get-OSCCsUserEffectiveClientPolicy-Help.xml

	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[string]$Identity
	)
	Process
	{
		#Get user object, registrar pool, site
		Try
		{
			$csUser = Get-CsUser -Identity $Identity -Verbose:$false
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($Error[0])
		}
		if ($csUser -ne $null) {
			$csUserRegistrarPool = $csUser.RegistrarPool.FriendlyName
			$csUserSite = ($cachedCsSites | Where-Object {$_.Pools -contains $csUserRegistrarPool}).Identity	
			#Cache all client policies
			if ($cachedPolicies.Count -eq 0) {
				$policies = Get-CsClientPolicy -Verbose:$false
				foreach ($policy in $policies) {
					$policyID = $policy.Identity
					if (-not $cachedPolicies.ContainsKey("ClientPolicy")) {
						$cachedPolicies.Add("ClientPolicy",@{$policyID=$policy})
					} else {
						$cachedPolicies["ClientPolicy"].Add($policyID,$policy)
					}
				}
			}
			#Get effective policy name
			if ($csUser.ClientPolicy -ne $null) {
				$policyName = "Tag:" + $csUser.ClientPolicy.FriendlyName
			} else {
				if ($cachedPolicies["ClientPolicy"].ContainsKey($csUserSite)) {
					$policyName = $csUserSite
				} else {
					$policyName = "Global"
				}
			}
			#Return effective policy object
			$policy = $cachedPolicies["ClientPolicy"].$policyName
			return $policy
		}
	}
}

Function Set-OSCCsUserPhoto
{
	#.EXTERNALHELP Set-OSCCsUserPhoto-Help.xml

	[CmdletBinding(SupportsShouldProcess=$true)]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[string[]]$Identity,
		[Parameter(Mandatory=$true,Position=2)]
		[string]$PhotoFolder
	)
	Process
	{
		foreach ($userID in $Identity) {
			Try
			{
				$csUser = Get-CsUser -Identity $userID
			}
			Catch
			{
				$pscmdlet.WriteError($Error[0])
			}
			if ($csUser -ne $null) {
				#Check Client Polciy
				$samAccountName = $csUser.SamAccountName
				$clientPolicy = Get-OSCCsUserEffectiveClientPolicy -Identity $samAccountName
				if ($clientPolicy.DisplayPhoto -eq "NoPhoto") {
					$warningMsg = $Messages.NoPhotoWarning
					$warningMsg = $warningMsg -replace "Placeholder01",$samAccountName
					$pscmdlet.WriteWarning($warningMsg)
					break
				}
				#Try to get user photo by using SAM Account Name
				Try
				{
					$photoFile = Get-ChildItem -Path "$PhotoFolder\$samAccountName.jpg"	
				}
				Catch
				{
					$pscmdlet.WriteError($Error[0])
				}
				if ($photoFile -ne $null) {
					#Test photo size.
					#If photo meets the requirement of thumbnail photo, convert the content to System.Byte[]
					#Otherwise, displays a warning message.
					if (Test-OSCCsUserPhoto -Path $photoFile.FullName) {
						$photo = [byte[]](Get-Content $photoFile.FullName -Encoding byte)
					} else {
						$warningMsg = $Messages.UseRecommendedSize
						$warningMsg = $warningMsg -replace "Placeholder01",$samAccountName
						$pscmdlet.WriteWarning($warningMsg)
					}
					#Try to populate thumbnailPhoto attribute in Active Directory
					if ($photo -ne $null) {
						if ($pscmdlet.ShouldProcess($samAccountName)) {
							$verboseMsg = $Messages.SettingPhoto
							$verboseMsg = $verboseMsg -replace "Placeholder01",$samAccountName
							$pscmdlet.WriteVerbose($verboseMsg)
							Set-ADUser -Identity $samAccountName -Replace @{thumbnailPhoto=$photo}
						}
					}
				}
			}
		}
	}
}

