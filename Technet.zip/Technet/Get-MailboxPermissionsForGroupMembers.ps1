param($Group)
# Get mailboxes that one or more members of the specified access have full access permission to

# Helper function to get group members recursively
function Get-GroupMembersRecursive 
{
    param($Group)
    [array]$Members = @()
    $Group = Get-Group $Group -ErrorAction SilentlyContinue
    if (!$Group)
    {
        throw "Group not found"
        
    }
    foreach ($Member in $Group.Members)
    {
        if (Get-Group $Member -ErrorAction SilentlyContinue)
        {
            $Members += Get-GroupMembersRecursive -Group $Member
        } else {
            $Members += ((get-user $Member.Name).SamAccountName)
        }
    }
    $Members = $Members | Select -Unique
    return $Members
}

[array]$Members = @();
$Group = Get-Group $Group -ErrorAction SilentlyContinue;
if (!$Group)
{
    throw "Group not found"
}
[array]$Members = Get-GroupMembersRecursive -Group $Group

$Mailboxes = Get-Mailbox -ResultSize Unlimited
foreach ($Mailbox in $Mailboxes)
{

    $Result = Get-MailboxPermission $Mailbox | where { ($_.AccessRights -like "*FullAccess*") -and ($_.IsInherited -eq $false) -and -not ($_.User -like "NT AUTHORITY\SELF") }| Select User
    [array]$AccessUsers=@()

    foreach ($DomUser in $Result) 
    { 
        
        $Found = $false
        $DomUser  = [String] $DomUser.User
        $UserArray = $DomUser.Split("\")
        $User = $UserArray[1]
        $Domain = $UserArray[0]
        
        foreach ($Member in $Members)
        {
            if ($Member -eq $User)
            {
                $AccessUsers += $User
                $Found = $true
            }
        }
        
        if ($Found -eq $false)
        {
            # Check if the user exists, if not look for a group.
            if ($DomUser -ne "")
            {
                if (!(Get-User $DomUser -ErrorAction SilentlyContinue))
                {
                    $subGroup = Get-Group $DomUser -ErrorAction SilentlyContinue
                    if ($subGroup)
                    {
                        $subMembers = Get-GroupMembersRecursive -Group $subGroup
                        foreach ($subMember in $subMembers)
                        {
                            foreach ($Member in $Members)
                            {
                                if ($Member -eq $subMember)
                                {
                                    $AccessUsers += $Member
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    $AccessUsers = $AccessUsers | Select -uniq
    if ($AccessUsers.Count)
    {
        $Output = "These members of ""$($Group.Name)"" have Full Access permissions to Mailbox ""$($Mailbox)"""
        Write-Output $Output
        $Dashes=$null;
        for ($i=0;$i -lt $Output.Length;$i++)
        {
            $Dashes = $Dashes + "-"
        }
        Write-Output $Dashes
        $AccessUsers
    }
}