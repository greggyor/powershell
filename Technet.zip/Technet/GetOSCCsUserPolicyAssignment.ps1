<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Define variables in script scope
$knownPolicyTypes = "Voice","DialPlan","Conferencing","Pin","ExternalAccess",`
"Location","Client","ClientVersion","Presence","Mobility","Archiving"
#Use nested hash table to cache all policies
#Nested hash table structure: $cachedPolicies=@{"PolicyType"=@{"PolicyIdentity"=PolicyObject}}
$cachedPolicies = @{}
foreach ($wellknownPolicyType in $knownPolicyTypes) {
	if ($wellknownPolicyType -ne "DialPlan") {
		$command = "Get-Cs$($wellknownPolicyType)Policy -Verbose:`$false"
	} else {
		$command = "Get-Cs$($wellknownPolicyType) -Verbose:`$false"
	}
	$policies = Invoke-Expression -Command $command
	foreach ($policy in $policies) {
		$policyID = $policy.Identity
		if (-not $cachedPolicies.ContainsKey($wellknownPolicyType)) {
			$cachedPolicies.Add($wellknownPolicyType,@{$policyID=$policy})
		} else {
			$cachedPolicies[$wellknownPolicyType].Add($policyID,$policy)
		}
	}
}
#Cache site objects
$cachedCsSites = Get-CsSite

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Get-OSCCsUserEffectivePolicy
{
	#.EXTERNALHELP Get-OSCCsUserEffectivePolicy-Help.xml

	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[string]$Identity,		
		[Parameter(Mandatory=$true,Position=2)]
		[string]$PolicyType
	)
	Process
	{
		#Policy type validation
		if ($knownPolicyTypes -notcontains $PolicyType) {
			$errorMsg = $Messages.InvalidPolicyType
			$errorMsg = $errorMsg -replace "Placeholder01",$PolicyType
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}	
		#Get user object, registrar pool, site
		Try
		{
			$csUser = Get-CsUser -Identity $Identity -Verbose:$false
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($Error[0])
		}
		if ($csUser -ne $null) {
			$csUserRegistrarPool = $csUser.RegistrarPool.FriendlyName
			$csUserSite = ($cachedCsSites | Where-Object {$_.Pools -contains $csUserRegistrarPool}).Identity	
			if ($PolicyType -ne "DialPlan") {
				$policyTypeName = "$($PolicyType)Policy"	
			} else {
				$policyTypeName = $PolicyType
			}
			#Get effective policy name
			if ($csUser.$policyTypeName -ne $null) {
				$policyName = "Tag:" + $csUser.$policyTypeName.FriendlyName
			} else {
				Switch -regex ($PolicyType) {
					"DialPlan|ClientVersion" {
						if ($cachedPolicies[$PolicyType].ContainsKey("Service:Registrar:" + $csUserRegistrarPool)) {
							$policyName = "Service:Registrar:" + $csUserRegistrarPool
							break
						} elseif ($cachedPolicies[$PolicyType].ContainsKey($csUserSite)) {
							$policyName = $csUserSite
							break
						} else {
							$policyName = "Global"
						}
					}
					Default {
						if ($cachedPolicies[$PolicyType].ContainsKey($csUserSite)) {
							$policyName = $csUserSite
							break
						} else {
							$policyName = "Global"
						}		
					}
				}
			}
			#Return effective policy object
			$policy = $cachedPolicies[$PolicyType].$policyName
			return $policy
		}
	}
}

Function Get-OSCCsUserPolicyAssignment 
{
	#.EXTERNALHELP Get-OSCCsUserPolicyAssignment-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeLine=$true)]
		[string[]]$Identity,		
		[Parameter(Mandatory=$true,Position=2)]
		[hashtable]$Feature
	)
	Begin
	{
		$policyFeatures = @{}
		$verifiedPolicy = @{}
		$verifiedPolicyTypes = @()
		$verifiedPolicyFeatures = @{}
		#Prepare feature list for each policy, it will be used for validation
		$nonFeatures = "Anchor","Description","Identity","Name","Priority","RuleId","ScopeClass","PolicyEntry"
		#Generate a list of features
		foreach ($wellknownPolicyType in $knownPolicyTypes) {
			$policyFeatureNames = @()
			if ($wellknownPolicyType -ne "DialPlan") {
				$command = "New-Cs$($wellknownPolicyType)Policy -Identity `"Template`" -InMemory -Verbose:`$false"
			} else {
				$command = "New-Cs$($wellknownPolicyType) -Identity `"Template`" -InMemory -Verbose:`$false"
			}
			$policyTemplate = Invoke-Expression -Command $command
			$policyTemplate | Get-Member -MemberType Property | %{
				#Remove any non-features
				if ($nonFeatures -notcontains $_.Name) {
					$policyFeatureNames += $_.Name
				}
			}
			$policyFeatures.Add($wellknownPolicyType,$policyFeatureNames)		
		}
		#Policy and feature validation
		foreach ($userSpecifiedPolicy in $Feature.Keys.GetEnumerator()) {
			$verifiedFeatureNames = @()
			if ($knownPolicyTypes -notcontains $userSpecifiedPolicy) {
				$warningMsg = $Messages.InvalidPolicyType
				$warningMsg = $warningMsg -replace "Placeholder01",$userSpecifiedPolicy
				$pscmdlet.WriteWarning($warningMsg)
			} else {
				$verifiedPolicyTypes += $userSpecifiedPolicy
				$userSpecifiedFeatureNames = $Feature[$userSpecifiedPolicy].Split(",")
				foreach ($userSpecifiedFeatureName in $userSpecifiedFeatureNames) {
					if ($policyFeatures[$userSpecifiedPolicy] -notcontains ($userSpecifiedFeatureName)) {
						$warningMsg = $Messages.InvalidPolicyFeature
						$warningMsg = $warningMsg -replace "Placeholder01",$userSpecifiedFeatureName
						$pscmdlet.WriteWarning($warningMsg)
					} else {
						$verifiedFeatureNames += $userSpecifiedFeatureName
					}
				}
			}
			$verifiedFeatureNames = $verifiedFeatureNames -join ","
			$verifiedPolicyFeatures.Add($userSpecifiedPolicy,$verifiedFeatureNames)
		}	
	}
	Process
	{
		#Iterate each user's identity
		foreach ($csUserID in $Identity) {
			$output = New-Object System.Management.Automation.PSObject
			Try
			{
				$csUser = Get-CsUser -Identity $csUserID
			}
			Catch
			{
				$pscmdlet.WriteError($Error[0])
			}
			if ($csUser -ne $null) {
				$output | Add-Member -MemberType NoteProperty -Name DisplayName -Value $csUser.DisplayName
				$output | Add-Member -MemberType NoteProperty -Name RegistrarPool -Value $csUser.RegistrarPool
				$output | Add-Member -MemberType NoteProperty -Name SipAddress -Value $csUser.SipAddress			
				foreach ($verifiedPolicyType in $verifiedPolicyTypes) {
					$effectivePolicy = Get-OSCCsUserEffectivePolicy -Identity $csUser -PolicyType $verifiedPolicyType
					$effectivePolicyId = $effectivePolicy.Identity
					$effectivePolicyName = "Effective$($verifiedPolicyType)Policy"				
					$output | Add-Member -MemberType NoteProperty -Name $effectivePolicyName -Value $effectivePolicyId
					$verfiedFeatureNames = $verifiedPolicyFeatures[$verifiedPolicyType].Split(",")
					if ($verfiedFeatureNames -ne $null) {
						foreach ($verfiedFeatureName in $verfiedFeatureNames) {
							$output | Add-Member -MemberType NoteProperty -Name $verfiedFeatureName -Value $effectivePolicy.$verfiedFeatureName
						}
					}
				}
			} else {
				break
			}
			$pscmdlet.WriteObject($output)
		}
	}
	End {}
}

