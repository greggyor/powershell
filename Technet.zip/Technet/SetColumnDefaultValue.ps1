﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Load Microsoft SharePoint Snapin
if ((Get-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null) {Add-PSSnapin Microsoft.SharePoint.PowerShell}

Function Set-OSCColumnValue()
{
<#
	.SYNOPSIS
	Function Set-OSCColumnValue is an advanced function which can set the specified column default value on SharePoint website.
	.DESCRIPTION
	Function Set-OSCColumnValue is an advanced function which can set the specified column default value on SharePoint website.
	.PARAMETER SPSite
	Indicates the specified SharePoint Website.
	.PARAMETER ListName
	Indicates the specified list name.
	.PARAMETER ColumnName
	Indicates the specified column name.
	.PARAMETER DefaultValue
	Indicates the value to be set as default.
	.EXAMPLE
	Set-OSCColumnValue -SPSite "http://sp-server:32938/sites/test2" -listName "Test" -ColumnName "Title" -DefaultValue "Title"
	
	Set "Title" as default value of the column "Title" in list "Test" on site "http://sp-server:32938/sites/test2".

#>

	#Define parameters
	[CmdletBinding(SupportsShouldProcess=$true)]
	param
	(
	[Parameter(Mandatory=$True,Position=0)]
	[String]$SPSite,
	[Parameter(Mandatory=$True,Position=1)]
	[String]$ListName,
	[Parameter(Mandatory=$True,Position=2)]
	[String]$ColumnName,
	[Parameter(Mandatory=$True,Position=3)]
	[String]$DefaultValue
	)
	Trap{ Continue }
	#Get the specified SharePoint website
  	$web = Get-SPWeb $SPSite  -ErrorAction SilentlyContinue
	If($web -ne $null)
	{	
		#Get the specified list 
		$list= $web.Lists[$ListName] 
		If($list -ne $null)
		{
			#Get the specified column
			$column = $list.Fields[$ColumnName]
			If($column -ne $null)
			{
				Try
				{
					#Set default value 
					$column.DefaultValue = $DefaultValue
					#Update the site
					$column.Update()
					$list.Update()
					Write-Host "Action done!Please check it!"
				}
				Catch
				{
					Write-Error $Error
				}
			}
			Else
			{
				Write-Error "The column $columnname does not exist."
			}
		}
		Else
		{
			Write-Error "The list $listName does not exist."
		}
	}
	Else
	{
		Write-Error "The SPSite $SPSite does not exist,or access deny"
	}
	
}




