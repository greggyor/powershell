<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

$webSvcInstallDirRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Exchange\Web Services\2.0" -PSProperty "Install Directory" -ErrorAction:SilentlyContinue
if ($webSvcInstallDirRegKey -ne $null) {
	$moduleFilePath = $webSvcInstallDirRegKey.'Install Directory' + 'Microsoft.Exchange.WebServices.dll'
	Import-Module $moduleFilePath
} else {
	$errorMsg = $Messages.InstallexServiceModule
	throw $errorMsg
}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Connect-OSCEXWebService
{
	#.EXTERNALHELP Connect-OSCEXWebService-Help.xml

    [cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[System.Management.Automation.PSCredential]$Credential,
		[Parameter(Mandatory=$false,Position=2)]
		[Microsoft.Exchange.WebServices.Data.ExchangeVersion]$ExchangeVersion="Exchange2010_SP2",
		[Parameter(Mandatory=$false,Position=3)]
		[string]$TimeZoneStandardName,
		[Parameter(Mandatory=$false)]
		[switch]$Force
	)
	Process
	{
        #Get specific time zone info
        if (-not [System.String]::IsNullOrEmpty($TimeZoneStandardName)) {
            Try
            {
                $tzInfo = [System.TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneStandardName)
            }
            Catch
            {
                $PSCmdlet.ThrowTerminatingError($_)
            }
        } else {
            $tzInfo = $null
        }

        #Try to get email address of current user
		Try
		{
			$directoryEntry = New-Object System.DirectoryServices.DirectoryEntry
			$currentDomain = New-Object System.DirectoryServices.DirectoryEntry("LDAP://" + $directoryEntry.distinguishedName)
			$currentUserName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name.Split("\")[1]
			$driectorySearcher = New-Object System.DirectoryServices.DirectorySearcher(`
									$currentDomain,"sAMAccountName=$currentUserName")
			$driectorySearcher.PropertiesToLoad.Add("mail") | Out-Null
			$currentUserMailAddress = $driectorySearcher.FindOne().GetDirectoryEntry().Properties["mail"].ToString()
			if (-not [System.String]::IsNullOrEmpty($currentUserMailAddress)) {
				$userName = $currentUserMailAddress
			} else {
				$errorMsg = $Messages.RequiresUserMailAddress
				$errorMsg = $errorMsg -f $currentUserName
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
				$PSCmdlet.ThrowTerminatingError($customError)					
			}			
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
	
		#Try to get exchange service object from global scope
		$existingExSvcVar = (Get-Variable -Name exService -Scope Global -ErrorAction:SilentlyContinue) -ne $null
		
		#Establish the connection to Exchange Web Service
		if ((-not $existingExSvcVar) -or $Force) {
			$verboseMsg = $Messages.EstablishConnection
			$PSCmdlet.WriteVerbose($verboseMsg)
            if ($tzInfo -ne $null) {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion,$tzInfo)			
            } else {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion)
            }
			
			#Set network credential
			if ($Credential -ne $null) {
				$userName = $Credential.UserName
				$exService.Credentials = $Credential.GetNetworkCredential()
			} else {
				$exService.UseDefaultCredentials = $true
			}
			Try
			{
				#Set the URL by using Autodiscover
				$exService.AutodiscoverUrl($userName,$validateRedirectionUrlCallback)
				$verboseMsg = $Messages.SaveExWebSvcVariable
				$PSCmdlet.WriteVerbose($verboseMsg)
				Set-Variable -Name exService -Value $exService -Scope Global -Force
			}
			Catch [Microsoft.Exchange.WebServices.Autodiscover.AutodiscoverRemoteException]
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
			Catch
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
		} else {
			$verboseMsg = $Messages.FindExWebSvcVariable
            if ($Credential -ne $null) {
                $verboseMsg = $verboseMsg -f $exService.Credentials.Credentials.UserName
            } else {
                $verboseMsg = $verboseMsg -f $userName
            }
			$PSCmdlet.WriteVerbose($verboseMsg)            
		}
	}
}

Function Get-OSCEXPublicFolder
{
	#.EXTERNALHELP Get-OSCEXPublicFolder-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[string]$Identity="\",
		[Parameter(Mandatory=$false,Position=2)]
		[int]$PageSize=100
	)
	Begin
	{
        #Verify the existence of exchange service object
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
		
		#Verify public folder path
		$pfPath = $Identity.TrimStart("\").TrimEnd("\")
		if ($Identity -ne "\") {
			$pfPaths = $pfPath.Split("\")
			for ($i=0; $i -lt $pfPaths.Count; $i++) {
				if ([System.String]::IsNullOrEmpty($pfPaths[$i])) {
					$errorMsg = $Messages.InvalidFolderPath
					$errorMsg = $errorMsg -f $Identity
					$customError = New-OSCPSCustomErrorRecord `
					-ExceptionString $errorMsg `
					-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
					$PSCmdlet.ThrowTerminatingError($customError)
				}
			}
		}
	}
	Process
	{
		#Create progress record object, because this function may search a lot of public folders
		$progressRecord = New-Object System.Management.Automation.ProgressRecord(1,"{0}","{0}")
		
		#Bind Root Public Folder
		$currentPublicFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($exService,`
							   [Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::PublicFoldersRoot)
		
		#Return Root Public Folder
		if ($Identity -eq "\") { return $currentPublicFolder }
		
        #Prepare folder view
        $folderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView($PageSize)
		
        #Begin to search each public folder
		foreach ($currentFolderName in $pfPaths) {
			$prStatDesc = $Messages.GPFProgressRecordStatusDescription
			$prStatDesc = $prStatDesc -f $currentFolderName,$currentPublicFolder.DisplayName,$currentPublicFolder.ChildFolderCount
			$progressRecord.Activity = $Messages.GPFProgressRecordActivity
			$progressRecord.StatusDescription = $prStatDesc
			$PSCmdlet.WriteProgress($progressRecord)
        	do
        	{
	        	$searchFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo(`
	                        	[Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName,$currentFolderName)
	            $findResults = $currentPublicFolder.FindFolders($searchFilter,$folderView)
				if ($findResults.TotalCount -eq 1) {
					#If any sub folder is found, replace parent folder object with the sub folder object
					#and keep on searching.
					$currentPublicFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind(`
				               			   $exService,$findResults.Folders[0].Id)
					$folderView.Offset = 0
				} else {
					$folderView.Offset += $PageSize
				}
        	} while ($findResults.MoreAvailable)
			
			#If public folder path is wrong, this function cannot find any public folder.
			#Then, exit this function immediately.
			if ($findResults.TotalCount -eq 0) {
				$errorMsg = $Messages.InvalidFolderPath
				$errorMsg = $errorMsg -f $Identity
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
				$PSCmdlet.ThrowTerminatingError($customError)
			}
		}
		return $currentPublicFolder
	}
	End {}
}

Function New-OSCEXContactImportFile
{
	#.EXTERNALHELP New-OSCEXContactImportFile-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$Path,
		[Parameter(Mandatory=$false)]
		[switch]$IncludeAdditionalProperty
	)
	Begin
	{
        #Verify the existence of exchange web service
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
	}
	Process
	{
		#Define return object for this function
		$output = New-Object System.Management.Automation.PSObject
		#Sort return object before exporting all properties to csv.
		$sortedList = New-Object System.Collections.SortedList
		#Define default properties
		$defaultPropertis = @("GivenName","Surname","CompanyName","Department",`
							"JobTitle","EmailAddress1","DisplayName","BusinessHomePage",`
							"ImAddress1","BusinessPhone","BusinessFax","HomePhone",`
							"MobilePhone","BusinessAddressPostalCode","BusinessAddressState",`
							"BusinessAddressCity","BusinessAddressStreet","BusinessAddressCountryOrRegion")
		
		#Return default properties by default. Otherwise, generate property list
		if (-not $IncludeAdditionalProperty) {
			$defaultPropertis | %{$output | Add-Member -MemberType NoteProperty -Name $_ -Value $null}
		} else {
			$contactSchemas = @{}
			$contactReadOnlyProperties = @{}
			$contactProperties = @{}
			$reservedProperties = @("Initials","Subject","Body","ItemClass","Children","PolicyTag",`
									"ArchiveTag","MimeContent","InReplyTo","FileAs","FileAsMapping",`
									"Flag","Culture","Generation","IsReminderSet","ReminderDueBy",`
                                    "ReminderMinutesBeforeStart")
			
			#Get properties from ContactSchem Class
			[Microsoft.Exchange.WebServices.Data.ContactSchema] | Get-Member -Static -MemberType Property | %{$contactSchemas.Add($_.Name,"")}
			
			#Get read only properties from Contact object
			$newContact = New-Object Microsoft.Exchange.WebServices.Data.Contact($exService)
			$newContact.GetType().GetProperties() | ?{($_.CanRead) -and ($_.CanWrite -eq $false)} | %{$contactReadOnlyProperties.Add($_.Name,"")}
			
			#Remove read-only properties
			foreach ($contactReadOnlyProperty in $contactReadOnlyProperties.GetEnumerator()) {
				if ($contactSchemas.ContainsKey($contactReadOnlyProperty.Name)) {
					$contactSchemas.Remove($contactReadOnlyProperty.Name)
				}
			}
			
			#Remove reserved properties
			foreach ($reservedProperty in $reservedProperties) {
				if ($contactSchemas.ContainsKey($reservedProperty)) {
					$contactSchemas.Remove($reservedProperty)
				}
			}			
			
			#Populate return object
			foreach ($contactSchema in $contactSchemas.GetEnumerator()) {
				$sortedList.Add($contactSchema.Name,$null) | Out-Null
			}
			foreach ($key in $sortedList.GetKeyList()) {
				$output | Add-Member -MemberType NoteProperty -Name $key -Value $null
			}
		}
		
		#Export the property list to a .CSV file.
		$output | Export-Csv -Path $Path -NoTypeInformation
	}
	End {}
}

Function Import-OSCEXContact
{
	#.EXTERNALHELP Import-OSCEXContact-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[Microsoft.Exchange.WebServices.Data.Folder]$ParentFolder,		
		[Parameter(Mandatory=$true,Position=2)]
		[string]$CsvFile,
		[Parameter(Mandatory=$false,Position=3)]
		[Microsoft.Exchange.WebServices.Data.FileAsMapping]$FileAsMapping="GivenNameSpaceSurname"
	)
	Begin
	{
        #Verify the existence of exchange web service
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
		
		#Verify parent folder can contain contact object
		if ($ParentFolder.FolderClass -ne "IPF.Contact") {
			$errorMsg = $Messages.RequiresContactFolder
			$errorMsg = $errorMsg -f $ContactFolder.DisplayName
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)		
		}
		
		#Verify the path of the .CSV file	
		if (-not (Test-Path -Path $CsvFile -PathType Leaf -Include "*.csv")) {
			$errorMsg = $Messages.CannotOpenCsvFile
			$errorMsg = $errorMsg -f $CsvFile
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)		
		}
	}
	Process
	{
		#Get contact property names from .CSV file
		$contactPropertyNames = @()
		$contacts = Import-Csv $CsvFile
		$contacts | Get-Member -MemberType NoteProperty | %{$contactPropertyNames += $_.Name}

		#Create progress record object, because this function may search a lot of public folders
		$progressRecord = New-Object System.Management.Automation.ProgressRecord(1,"{0}","{0}")		
		
		#Iterate each contact and create it
		foreach ($contact in $contacts) {
			#Show progress bar
			$counter++
			$prStatDesc = $Messages.CNCProgressRecordStatusDescription
			$prStatDesc = $prStatDesc -f $($contact.DisplayName)
			$progressRecord.Activity = $Messages.CNCProgressRecordActivity
			$progressRecord.StatusDescription = $prStatDesc
			$progressRecord.PercentComplete = $counter / $contacts.Count * 100
			$PSCmdlet.WriteProgress($progressRecord)
			#Initialize new contact instance
			$newContact = New-Object Microsoft.Exchange.WebServices.Data.Contact($exService)
			foreach ($contactPropertyName in $contactPropertyNames) {
				if (-not [System.String]::IsNullOrEmpty($contact.$contactPropertyName)) {
					Switch -regex ($contactPropertyName) {
						"Birthday" {
							#Set birthday property
							$newContact.$contactPropertyName = [System.DateTime]::Parse($contact.$contactPropertyName)
						}
						"Companies|Categories" {
							#Set companies and categories property
							$strings = $contact.$contactPropertyName.Split(";")
							$stringList = New-Object Microsoft.Exchange.WebServices.Data.StringList
							foreach ($string in $strings) {
								$stringList.Add($string)
							}
							$newContact.$contactPropertyName = $stringList
						}
						"EmailAddress" {
							#Set EmailAddress 1, EmailAddress 2 and EmailAddress 3
							$newContact.EmailAddresses.Item(`
							[Microsoft.Exchange.WebServices.Data.EmailAddressKey]::$contactPropertyName`
							) = $contact.$contactPropertyName
						}
						"IMAddress" {
							#Set IMAddress 1, IMAddress 2 and IMAddress 3
							$newContact.ImAddresses.Item(`
							[Microsoft.Exchange.WebServices.Data.ImAddressKey]::$contactPropertyName`
							) = $contact.$contactPropertyName					
						}					
						"(Business|Home|Other)Address" {
							#Set Bussiness Address, Home Address and OtherAddress
							$contactPropertyShortName = $contactPropertyName -replace "(Business|Home|Other)Address",""
							$physicalAddressType = $contactPropertyName -replace $contactPropertyShortName,""
							$physicalAddressType = $physicalAddressType -replace "Address",""
							
							if ([System.String]::IsNullOrEmpty($currentPhysicalAddressType)) {
								#Initialize first address entry
								$currentPhysicalAddressType = $physicalAddressType
								$contactPhysicalAddressEntry = New-Object Microsoft.Exchange.WebServices.Data.PhysicalAddressEntry
								$contactPhysicalAddressEntry.$contactPropertyShortName = $contact.$contactPropertyName
							} elseif ($currentPhysicalAddressType -ne $physicalAddressType) {
								#Save previous physical address entry
								$newContact.PhysicalAddresses.Item(`
								[Microsoft.Exchange.WebServices.Data.PhysicalAddressKey]::$currentPhysicalAddressType`
								) = $contactPhysicalAddressEntry
								
								#Create new physical address entry and change the value of $currentPhysicalAddressType
								#e.g., The physical address type changes from Business to Home
								$contactPhysicalAddressEntry = New-Object Microsoft.Exchange.WebServices.Data.PhysicalAddressEntry
								$currentPhysicalAddressType = $physicalAddressType
								$contactPhysicalAddressEntry.$contactPropertyShortName = $contact.$contactPropertyName
							} else {
								#Populate property for each address entry
								$contactPhysicalAddressEntry.$contactPropertyShortName = $contact.$contactPropertyName
							}						
						}
						"Phone|Fax|Callback|Isdn|Pager|Telex" {
							#Set phone numbers
							$newContact.PhoneNumbers.Item(`
							[Microsoft.Exchange.WebServices.Data.PhoneNumberKey]::$contactPropertyName`
							) = $contact.$contactPropertyName
						}
						"Photo" {
							#Set contact picture
							if (-not [System.String]::IsNullOrEmpty($contact.$contactPropertyName)) {
								if (-not (Test-Path -Path $contact.$contactPropertyName -PathType Leaf)) {
									$warningMsg = $Messages.InvalidPhotoPath
									$warningMsg = $warningMsg -f $contact.$contactPropertyName
									$PSCmdlet.WriteWarning($warningMsg)								
								} else {
									$newContact.SetContactPicture($contact.$contactPropertyName)
								}
							}
						}
						Default {
							#Set other properties
							Try
							{
								$newContact.$contactPropertyName = $contact.$contactPropertyName
							}
							Catch
							{
								$PSCmdlet.WriteError($_)
							}
						}
					}
				}
			}
			
			#Set FileAsMapping property
			$newContact.FileAsMapping = $FileAsMapping
			
			#Save contact in the parent folder
			$newContact.Save($ParentFolder.Id)
		}
	}
}

Export-ModuleMember -Function "Connect-OSCEXWebService","Get-OSCEXPublicFolder","New-OSCEXContactImportFile","Import-OSCEXContact"