﻿## Exchange Mailbox Permission###
# written by: Rahmatullah Fedayizada
# www.msexchangepr.blogspost.com
#Rahmat_fedayizada@hotmail.com
##############################
## path to export your result as CSV
$path = z:\exchange.csv

foreach($mailbox in Get-Mailbox -ResultSize Unlimited)
{Get-MailboxPermission $mailbox |  Where-Object {($_.AccessRights -like "*FullAccess*") -and ($_.User -notlike "NT AUTHORITY\SELF")-and ($_.IsInherited -eq $false)} | Select-Object identity,user | Export-Csv -Path $path -Append}

Write-Host Exported the result

