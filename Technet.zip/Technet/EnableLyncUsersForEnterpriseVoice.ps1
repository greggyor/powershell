﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Export-OSCCsAdUser 
{
	#.EXTERNALHELP Export-OSCCsAdUser-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$OU,		
		[Parameter(Mandatory=$true,Position=2)]
		[string]$CsvFilePath,
		[Parameter(Mandatory=$true,Position=3)]
		[string]$RegistrarPool,
		[Parameter(Mandatory=$false,Position=4)]
		[ValidateSet("EmailAddress","UserPrincipalName")]
		[string]$SipAddressType="EmailAddress",
		[Parameter(Mandatory=$false,Position=5)]
		[switch]$EnableEnterpriseVoice,
		[Parameter(Mandatory=$false,Position=6)]
		[hashtable]$Policy
	)
	DynamicParam
	{
        if ($EnableEnterpriseVoice) {
			#Define Dynamic Param: LineUriPrefix
            $attributes = New-Object System.Management.Automation.ParameterAttribute
            $attributes.ParameterSetName = "__AllParameterSets"
            $attributes.Mandatory = $true
			$attributes.Position = 7
            $attributeCollection = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
            $attributeCollection.Add($attributes)
            $lineUriPrefix = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("LineUriPrefix", [string], $attributeCollection)
            $paramDictionary = New-Object -Type System.Management.Automation.RuntimeDefinedParameterDictionary
            $paramDictionary.Add("LineUriPrefix", $lineUriPrefix)
			#Define Dynamic Param: NumberRangeStart
            $attributes = New-Object System.Management.Automation.ParameterAttribute
            $attributes.ParameterSetName = "__AllParameterSets"
            $attributes.Mandatory = $true
			$attributes.Position = 8
            $attributeCollection = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
            $attributeCollection.Add($attributes)
            $NumberRangeStart = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("NumberRangeStart", [int], $attributeCollection)
            $paramDictionary.Add("NumberRangeStart", $NumberRangeStart)			
			#Define Dynamic Param: NumberRangeEnd
            $attributes = New-Object System.Management.Automation.ParameterAttribute
            $attributes.ParameterSetName = "__AllParameterSets"
            $attributes.Mandatory = $true
			$attributes.Position = 9
            $attributeCollection = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
            $attributeCollection.Add($attributes)
            $NumberRangeEnd = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("NumberRangeEnd", [int], $attributeCollection)
            $paramDictionary.Add("NumberRangeEnd", $NumberRangeEnd)
			#Define Dynamic Param: GenerateRandomPhoneNumber
            $attributes = New-Object System.Management.Automation.ParameterAttribute
            $attributes.ParameterSetName = "__AllParameterSets"
            $attributes.Mandatory = $false
			$attributes.Position = 10
            $attributeCollection = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
            $attributeCollection.Add($attributes)
            $generateRandomPhoneNumber = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("GenerateRandomPhoneNumber", [switch], $attributeCollection)
            $paramDictionary.Add("GenerateRandomPhoneNumber", $generateRandomPhoneNumber)
			#Define Dynamic Param: NumberOfRetryAttempts
            $attributes = New-Object System.Management.Automation.ParameterAttribute
            $attributes.ParameterSetName = "__AllParameterSets"
            $attributes.Mandatory = $false
			$attributes.Position = 11
            $attributeCollection = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
            $attributeCollection.Add($attributes)
            $retryAttempts = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("RetryAttempts", [int], $attributeCollection)
            $paramDictionary.Add("RetryAttempts", $retryAttempts)
            return $paramDictionary
        }
	}
	Process
	{
		#Try to get a list of users who are not enabled for Lync Server
		Try
		{
			if (-not [System.String]::IsNullOrEmpty($OU)) {
				$csUsers = Get-CsAdUser -OU $OU -Filter {Enabled -eq $null}
			} else {
				$csUsers = Get-CsAdUser -Filter {Enabled -eq $null}
			}
		}
		Catch
		{
			$pscmdlet.WriteError($Error[0])
		}
		#Parameter validation for Enterprise Voice
		if ($EnableEnterpriseVoice) {
			if ($NumberRangeStart.Value -ge $NumberRangeEnd.Value) {
				$errorMsg = $Messages.MinGreaterThanOrEqualMax
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)					
			} elseif (($NumberRangeStart.Value -lt 0) -or ($NumberRangeEnd.Value -lt 0)) {
				$errorMsg = $Messages.NegativePhoneNumber
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)
			} else {
				$totalPhoneNumbers = $NumberRangeEnd.Value - $NumberRangeStart.Value + 1
			}
			$tempLineUri = "$($lineUriPrefix.Value)$($NumberRangeStart.Value)"
			if (-not $tempLineUri.StartsWith("tel:+")) {
				$errorMsg = $Messages.WrongE164Format
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)
			}
			#Define the number of retry attempts
			if (-not $retryAttempts.IsSet) {
				$retryAttemptsValue = 5
			} else {
				if ($retryAttempts.Value -le 0) {
					$errorMsg = $Messages.WrongRetryAttempts
					$customError = New-OSCPSCustomErrorRecord `
					-ExceptionString $errorMsg `
					-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
					$pscmdlet.ThrowTerminatingError($customError)
				} else {
					$retryAttemptsValue = $retryAttempts.Value
				}
			}
			#Get the method for generating phone numbers  
			$generateRandomPhoneNumberValue = $generateRandomPhoneNumber.Value
		} else {
			if ($Policy -ne $null) {
				foreach ($policyType in $Policy.Keys.GetEnumerator()) {
					if ($policyType -match "DialPlan|Voice") {
						$errorMsg = $Messages.CannotSetEVPolicy
						$customError = New-OSCPSCustomErrorRecord `
						-ExceptionString $errorMsg `
						-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
						$pscmdlet.ThrowTerminatingError($customError)
					}
				}
			}
		}
		#Policy type and name validation, only qualified policy will be exported.
		if ($Policy -ne $null) {
			$wellknownPolicyTypes = "Voice","DialPlan","Conferencing","Pin","ExternalAccess",`
			"Location","Client","ClientVersion","Presence","Mobility","Archiving"
			foreach ($policyType in $Policy.Keys.GetEnumerator()) {
				if ($wellknownPolicyTypes -notcontains $policyType) {
					$errorMsg = $Messages.UnqualifiedPolicyType
					$errorMsg = $errorMsg -replace "Placeholder01",$policyType
					$customError = New-OSCPSCustomErrorRecord `
					-ExceptionString $errorMsg `
					-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
					$pscmdlet.ThrowTerminatingError($customError)
				} else {
					$policyName = $Policy[$policyType]
					if ($policyType -eq "DialPlan") {
						$command = "Get-CsDialPlan -Identity `"$policyName`" -Verbose:`$false"
					} else {
						$command = "Get-Cs$($policyType)Policy -Identity `"$policyName`" -Verbose:`$false"
					}
					Try
					{
						$specificPolicy = Invoke-Expression -Command $command
					}
					Catch
					{
						$pscmdlet.WriteError($Error[0])
					}
					if ($specificPolicy -eq $null) {
						return $null						
					}
				}
			}
		}
		#Begin to prepare the output
		if ($csUsers -ne $null) {
			$outputUsers = @()
			#Variable for tracking the LineURI assignments for new users.
			#It will be used if the phone number will be generated in random.
			$newPhoneNumbers = @{}
			#Variable for tracking the LineURI assignments for new users.
			#It will be used if the phone number will be generated in sequence.
			$phoneNumberCursor = [int]$NumberRangeStart.Value
			#If the total number of users is large than the available phone numbers,
			#You need to assign a new phone number range. 
			$csUserCount = ($csUsers | Measure-Object).Count
			if (($EnableEnterpriseVoice) -and ($csUserCount -gt $totalPhoneNumbers)) {
				$errorMsg = $Messages.InadequatePhoneNumbers
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)						
			}
			#Prepare output user list
			foreach ($csUser in $csUsers) {
				$outputUser = New-Object System.Management.Automation.PSObject
				#Prepare required parameters for enabling users
				if ($SipAddressType -eq "EmailAddress") {
					$sipAddress = "sip:$($csUser.WindowsEmailAddress)"
				} else {
					$sipAddress = "sip:$($csUser.UserPrincipalName)"
				}
				$outputUser | Add-Member -MemberType NoteProperty -Name SamAccountName -Value $csUser.SamAccountName
				$outputUser | Add-Member -MemberType NoteProperty -Name RegistrarPool -Value $RegistrarPool
				$outputUser | Add-Member -MemberType NoteProperty -Name SipAddress -Value $sipAddress
				$outputUser | Add-Member -MemberType NoteProperty -Name EnableEnterpriseVoice -Value $EnableEnterpriseVoice
				#Prepare additional user scope policy for output
				if ($Policy -ne $null) {
					foreach ($policyType in $Policy.Keys.GetEnumerator()) {
						$outputUser | Add-Member -MemberType NoteProperty -Name "$($policyType)Policy" -Value $Policy[$policyType]
					}
				}
				#Generate LineUri for new users
				if ($EnableEnterpriseVoice) {
					#If any confliction occurs, this function will retry 5 times to get an available number by default.
					for ($counter = 0; $counter -lt $retryAttemptsValue; $counter++) {
						if ($generateRandomPhoneNumberValue) {
							$phoneNumber = Get-Random -Minimum $NumberRangeStart.Value -Maximum $NumberRangeEnd.Value
							if (-not $newPhoneNumbers.ContainsKey($phoneNumber)) {
								$newPhoneNumbers.Add($phoneNumber,$csUser.SamAccountName)
								$conflictWithNewUser = $false
							} else {
								$verboseMsg = $Messages.ConflictWithNewUser
								$verboseMsg = $verboseMsg -replace "Placeholder01",$lineUri
								$verboseMsg = $verboseMsg -replace "Placeholder02",$newPhoneNumbers[$phoneNumber]
								$pscmdlet.WriteVerbose($verboseMsg)							
								$conflictWithNewUser = $true
							}
						} else {
							$phoneNumber = $phoneNumberCursor++
						}
						$lineUri = "$($lineUriPrefix.Value)$phoneNumber"
						#LineUri Confliction Detection
						$objectsWithLineUri= "User","AnalogDevice","CommonAreaPhone","ExUmContact",`
						"DianinConferencingAccessNumber","TrustedApplicationEndpoint"
						foreach ($objectName in $objectsWithLineUri) {
							if ($objectName -eq "User") {
								$command  = "Get-CsUser -Filter {(LineUri -eq '$lineUri') -or (PrivateLine -eq '$lineUri')}"
							} else {
								$command  = "Get-Cs$($objectName) -Filter {LineUri -eq '$lineUri'}"
							}
							Try
							{
								$existingObject = Invoke-Expression -Command $command
								if ($existingObject -ne $null) {
									$verboseMsg = $Messages.ConflictWithExistingObject
									$verboseMsg = $verboseMsg -replace "Placeholder01",$lineUri
									$verboseMsg = $verboseMsg -replace "Placeholder02",$objectName
									$verboseMsg = $verboseMsg -replace "Placeholder03",$existingObject.Name
									$pscmdlet.WriteVerbose($verboseMsg)
									break
								}
							}
							Catch
							{
								#Suppress any errors
							}
						}
						if ($existingObject -ne $null) {
							$conflictWithExistingObjects = $true
						} else {
							$conflictWithExistingObjects = $false
						}
						if ($conflictWithExistingObjects -or $conflictWithNewUser) {
							$lineUriConflictionFlag = $true
						} else {
							$lineUriConflictionFlag = $false
							break
						}
					}
					#In some cases, you need to assign LineUri manually.
					if (-not $lineUriConflictionFlag) {
						$outputUser | Add-Member -MemberType NoteProperty -Name LineURI -Value $lineUri
					} else {
						$outputUser | Add-Member -MemberType NoteProperty -Name LineURI -Value $Messages.LineUriConfliction
					}					
				}
				$outputUsers += $outputUser
			}
			Try
			{
				$outputUsers | Export-Csv -Path $CsvFilePath -NoTypeInformation
			}
			Catch
			{
				$pscmdlet.WriteError($Error[0])
			}
		} else {
			$verboseMsg = $Messages.CannotFindUsers
			$pscmdlet.WriteVerbose($verboseMsg)
		}
	}
}

Function Enable-OSCCsUser
{
	#.EXTERNALHELP Enable-OSCCsUser-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$CsvFilePath
	)
	Process
	{
		#Import users from a .csv file
		Try
		{
			$csUsers = Import-Csv -Path $CsvFilePath
		}
		Catch
		{
			$pscmdlet.ThrowTerminatingError($Error[0])
		}
		if ($csUsers -ne $null) {
			#Get Policy Names, it may contains one or more policies.
			$policies = @{}
			$csUsers | Get-Member -MemberType NoteProperty -Name "*Policy" | %{$policies.Add($_.Name,"")}
			#Try to enable user and grant policy if applicable.
			foreach ($csUser in $csUsers) {
				$csUserSamAccountName = $csUser.SamAccountName
				$csUserSipAddress = $csUser.SipAddress
				$csUserRegistrarPool = $csUser.RegistrarPool
				$csUserPolicyName = $csUser.$policyName
				if ($csUser.EnableEnterpriseVoice -eq "False") {
					$verboseMsg = $Messages.EnablingUserWithoutEV
					$verboseMsg = $verboseMsg -replace "Placeholder01",$csUserSamAccountName
					$pscmdlet.WriteVerbose($verboseMsg)
					Try
					{
						Enable-CsUser -Identity $csUserSamAccountName -SipAddress $csUserSipAddress `
						-RegistrarPool $csUserRegistrarPool -Verbose:$false
					}
					Catch
					{
						$pscmdlet.WriteError($Error[0])
					}
					foreach ($policyName in $policies.Keys.GetEnumerator()) {
						$verboseMsg = $Messages.GrantingPolicy
						$verboseMsg = $verboseMsg -replace "Placeholder01",$policyName
						$verboseMsg = $verboseMsg -replace "Placeholder02",$($csUser.$policyName)
						$verboseMsg = $verboseMsg -replace "Placeholder03",$csUserSamAccountName
						$pscmdlet.WriteVerbose($verboseMsg)
						$command = "Grant-Cs$($policyName) -Identity $csUserSamAccountName -PolicyName '$($csUser.$policyName)' -Verbose:`$false"
						Try
						{
							Invoke-Expression -Command $command
						}
						Catch
						{
							$pscmdlet.WriteError($Error[0])
						}
					}
				} else {
					$verboseMsg = $Messages.EnablingUserWithEV
					$verboseMsg = $verboseMsg -replace "Placeholder01",$csUserSamAccountName
					$pscmdlet.WriteVerbose($verboseMsg)
					Try
					{
						Enable-CsUser -Identity $csUserSamAccountName -SipAddress $csUserSipAddress `
						-RegistrarPool $csUserRegistrarPool -Verbose:$false
						Set-CsUser -Identity $csUserSamAccountName -EnterpriseVoiceEnabled $true -LineURI $csUser.LineUri -Verbose:$false
					}
					Catch
					{
						$pscmdlet.WriteError($Error[0])
					}
					foreach ($policyName in $policies.Keys.GetEnumerator()) {
						$verboseMsg = $Messages.GrantingPolicy
						$verboseMsg = $verboseMsg -replace "Placeholder01",$policyName
						$verboseMsg = $verboseMsg -replace "Placeholder02",$($csUser.$policyName)
						$verboseMsg = $verboseMsg -replace "Placeholder03",$csUserSamAccountName
						$pscmdlet.WriteVerbose($verboseMsg)
						if ($policyName -ne "DialPlanPolicy") {
							$command = "Grant-Cs$($policyName) -Identity $csUserSamAccountName -PolicyName '$($csUser.$policyName)' -Verbose:`$false"
						} else {
							$command = "Grant-CsDialPlan -Identity $csUserSamAccountName -PolicyName '$($csUser.$policyName)' -Verbose:`$false"
						}
						Try
						{
							Invoke-Expression -Command $command
						}
						Catch
						{
							$pscmdlet.WriteError($Error[0])
						}
					}
				}
			}
		}
	}
}

