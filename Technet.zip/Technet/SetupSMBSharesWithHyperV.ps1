﻿Param(
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVClusterName,
    [Parameter(Mandatory=$true)]
    [string]
    $ScaleOutFSName,
    [Parameter(Mandatory=$true)]
    [string]
    $ShareName,
    [Parameter(Mandatory=$true)]
    [string]
    $HyperVObjectADGroupSamName,
    [int]
    $CSVVolumeNumber = 1,
    [string]
    $VHDFolderName = "VHDs",
    [string]
    $VMFolderName = "VMs"
)

# Add and import needed features
if ((Get-WindowsFeature | ? Name -Like "RSAT-Clustering-PowerShell") | ? InstallState -NotLike Installed)
{
    Install-WindowsFeature "RSAT-Clustering-PowerShell"
}
Import-Module -Name FailoverClusters

# Get cluster nodes
$HyperVNodes = (Get-clusternode -Cluster $HyperVClusterName).Name

# Setup AD groups
.\ADGroupSetup.ps1 -HyperVClusterName $HyperVClusterName -HyperVObjectADGroupSamName $HyperVObjectADGroupSamName 

# Setup Kerberos Constrained Delegation for SMB and Live Migration
.\KCDSetup.ps1 -HyperVClusterName $HyperVClusterName -ScaleOutFSName $ScaleOutFSName EnableLM:$true

# Setup File Share
.\FileShareSetup.ps1 -HyperVClusterName $HyperVClusterName -ScaleOutFSName $ScaleOutFSName -HyperVObjectADGroupSamName $HyperVObjectADGroupSamName -ShareName $ShareName -CSVVolumeNumber $CSVVolumeNumber

# Restart Hyper-V Nodes (required for KCD settings to take effect)
Restart-Computer $HyperVNodes -Wait -For PowerShell -Force

# Modify Hyper-V Node settings to reflect above changes
Set-VMHost -ComputerName $HyperVNodes -VirtualMachineMigrationAuthenticationType Kerberos -VirtualHardDiskPath \\$ScaleoutFSName\$ShareName\$VHDFolderName -VirtualMachinePath \\$ScaleoutFSName\$ShareName\$VMFolderName