﻿#================================================================================= 
# Created by    :   Bruce Langworthy 
# Organization  : Microsoft Corporation 
# Filename      : StoragePerformanceCounters.PS1    
#================================================================================= 
# Note: The performance information displayed by these counters are the 
#       current values only, they do not show trends. This information 
#       should be used as a measurement only of the current system state. 
#================================================================================= 

#   Retrieve the current Disk performance counter information. 
$computer         = $ENV:Computername 
$instance         = "_total" 

@("\\$Computer\PhysicalDisk(*)\Current Disk Queue Length", 
  "\\$Computer\PhysicalDisk(*)\% Disk Time", 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk Queue Length", 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk Read Queue Length", 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk Write Queue Length", 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk sec/Transfer" 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk sec/Read", 
  "\\$Computer\PhysicalDisk(*)\Avg. Disk sec/Write") |% { 
    (Get-Counter $_.replace("*",$instance)).CounterSamples } | 
    Select-Object Path,CookedValue | 
    Format-Table -AutoSize 


#   Retrieve the current Processor performance counter information. 
$computer         = $ENV:Computername 
$instance         = "_total" 
@("\\$Computer\Processor(*)\% Processor Time", 
  "\\$Computer\Processor(*)\% User Time", 
  "\\$Computer\Processor(*)\% Privileged Time", 
  "\\$Computer\Processor(*)\Interrupts/sec", 
  "\\$Computer\Processor(*)\% DPC Time", 
  "\\$Computer\Processor(*)\DPCs Queued/sec" 
  "\\$Computer\Processor(*)\% Idle Time", 
  "\\$Computer\Processor(*)\% Interrupt Time") |% { 
    (Get-Counter $_.replace("*",$instance)).CounterSamples } | 
    Select-Object Path,CookedValue | 
    Format-Table -AutoSize 

# Retreive the current Memory counter information 
$computer         = $ENV:Computername 
$instance         = "_total" 
@("\\$Computer\Memory\Page Faults/sec", 
  "\\$Computer\Memory\Available Bytes", 
  "\\$Computer\Memory\Committed Bytes", 
  "\\$Computer\Memory\Commit Limit", 
  "\\$Computer\Memory\Pages/sec", 
  "\\$Computer\Memory\Free System Page Table Entries" 
  "\\$Computer\Memory\Pool Paged Resident Bytes", 
  "\\$Computer\Memory\Available MBytes") |% { 
    (Get-Counter $_.replace("*",$instance)).CounterSamples } | 
    Select-Object Path,CookedValue | 
    Format-Table -AutoSize 

#================================================================================================ 
#The following examples shows how to list the available paths to query for several counter sets 
#================================================================================================ 
#$PhysCounter  = get-counter -ListSet PhysicalDisk 
#$PhysCounter.Paths 

#Memory Counters 
#$MemCounter   = get-counter -ListSet Memory 
#$MemCounter.Paths 


#CPU Counters 
#$CpuCounter   = get-counter -ListSet Processor 
#$CpuCounter.Paths 