﻿<#
.NOTES
    Name: Sync-ADLyncSitesSubnets.ps1
    Author: Daniel Sheehan
    Requires: PowerShell v2, AD module, and Lync module installed on the 
	computer running the script. Also the account running this script needs
	to be a member of the Lync RTCUniversalUserAdmins group, and have read 
	permissions to the AD Sites and Services container.
	The order in which the code executes tasks is critical. For example a
	new region has to be created before sites can be added or moved to it,
	and as another example a site must have all subnets moved/removed from
	it before it can be deleted.
	AD connection code that allowed extracting the site description borrowed
	from:
	http://blogs.msdn.com/b/adpowershell/archive/2009/08/18/active-directory-powershell-to-manage-sites-and-subnets-part-3-getting-site-and-subnets.aspx
    Version History:
    1.0 - 9/22/2012 - Initial Release.
.SYNOPSIS
    Duplicates and maintains the AD sites and subnets information into Lync,
	including creating Lync regions.
.DESCRIPTION
    This script populates the AD sites and subnets into Lync as Lync sites
	and subnets. The Lync regions are dynamically pulled from the consistently
	formatted description fields of the AD sites. Since the AD site location
	and description fields are important, this script will generate a report
	of the sites missing them and halt.
	All activity the script takes is emailed to the designated location.
.EXAMPLE  
    [PS] C:\>.\Sync-ADLyncSitesSubnets.ps1 <no parameters>
    The script does not have any parameters.
#>

# --- Admin Defined Variables ---
# Specify the Lync central site that all new sites will be added to by default.
$CentralSite = "LyncCentralSite1"
# Define who should get the email report, separated by a ;, if there are no changes or issues.
$StandardEmailReport = "DailyReports@company.com"
# Define who should get the email report, separated by a ;, if there are changes and/or issues.
$AlertEmailReport = "LyncAdmins@company.com;DailyReports@company.com"
# --- Admin Defined Variables ---

# Capture the date and time in a variable using the "Nov 11/01/2010 6:00 AM" format.
$DateTime = Get-Date -Format "ddd MM/dd/yyyy h:mm tt"

# Import the required modules which must be pre-installed on teh server running the PowerShell script.
Import-Module ActiveDirectory
Import-Module Lync

# Create a datatable to hold the AD site information pulled from AD.
$ADSiteTable = New-Object System.Data.DataTable "ADSiteTable"
$ADSiteTable.Columns.Add("Name",[String]) | Out-Null
$ADSiteTable.Columns.Add("Location",[String]) | Out-Null
$ADSiteTable.Columns.Add("Description",[String]) | Out-Null
$ADSiteTable.Columns.Add("Region",[String]) | Out-Null
# Make the Name column the primary and unique key.
$ADSiteTable.Columns["Name"].Unique = $true
$ADSiteTable.PrimaryKey = $ADSiteTable.Columns["Name"]

# Create a datatable to hold the AD site information of sites in AD with insufficient information.
$BadADSiteTable = New-Object System.Data.DataTable "BadADSiteTable"
$BadADSiteTable.Columns.Add("Name",[String]) | Out-Null
$BadADSiteTable.Columns.Add("Location",[String]) | Out-Null
$BadADSiteTable.Columns.Add("Description",[String]) | Out-Null
# Make the Name column the primary and unique key.
$BadADSiteTable.Columns["Name"].Unique = $true
$BadADSiteTable.PrimaryKey = $BadADSiteTable.Columns["Name"]

#Create a datatable to hold the Lync site information pulled from Lync.
$LyncSiteTable = New-Object System.Data.DataTable "LyncSiteTable"
$LyncSiteTable.Columns.Add("Name",[String]) | Out-Null
$LyncSiteTable.Columns.Add("Location",[String]) | Out-Null
$LyncSiteTable.Columns.Add("Region",[String]) | Out-Null
# Make the Name column the primary and unique key.
$LyncSiteTable.Columns["Name"].Unique = $true
$LyncSiteTable.PrimaryKey = $LyncSiteTable.Columns["Name"]

# Create a datatable to hold the AD sites not in Lync and subsequently added to Lync.
$AddLyncSiteTable = New-Object System.Data.DataTable "AddLyncSiteTable"
$AddLyncSiteTable = $LyncSiteTable.Clone()

#Create a datatable to hold the Lync sites updated with information from AD.
$ChgLyncSiteTable = New-Object System.Data.DataTable "ChgLyncSiteTable"
$ChgLyncSiteTable = $LyncSiteTable.Clone()

# Create a datatable to hold the Lync sites not in AD an subsequently removed from Lync.
$DelLyncSiteTable = New-Object System.Data.DataTable "DelLyncSiteTable"
$DelLyncSiteTable = $LyncSiteTable.Clone()

# Create a datatable to hold the AD subnet information pulled form AD.
$ADSubnetTable = New-Object System.Data.DataTable "ADSubnetTable"
$ADSubnetTable.Columns.Add("Name",[String]) | Out-Null
$ADSubnetTable.Columns.Add("Mask",[String]) | Out-Null
$ADSubnetTable.Columns.Add("Description",[String]) | Out-Null
$ADSubnetTable.Columns.Add("Site",[String]) | Out-Null
# Make the Name column the primary and unique key.
$ADSubnetTable.Columns["Name"].Unique = $true
$ADSubnetTable.PrimaryKey = $ADSubnetTable.Columns["Name"]

# Create a datatable to hold the AD subnet information of duplicate subnets in AD.
$DupADSubnetTable = New-Object System.Data.DataTable "BadADSubnetTable"
$DupADSubnetTable.Columns.Add("Name",[String]) | Out-Null
$DupADSubnetTable.Columns.Add("Description",[String]) | Out-Null
$DupADSubnetTable.Columns.Add("Site",[String]) | Out-Null

# Create a datatable to hold the Lync subnet information pulled from Lync.
$LyncSubnetTable = New-Object System.Data.DataTable "LyncSubnetTable"
$LyncSubnetTable = $ADSubnetTable.Clone()

# Create a datatable to hold the AD subnets not in Lync and subsequently added to Lync.
$AddLyncSubnetTable = New-Object System.Data.DataTable "AddLyncSubnetTable"
$AddLyncSubnetTable = $LyncSubnetTable.Clone()

#Create a datatable to hold the Lync subnets updated with information from AD.
$ChgLyncSubnetTable = New-Object System.Data.DataTable "ChgLyncSubnetTable"
$ChgLyncSubnetTable = $LyncSubnetTable.Clone()

# Create a datatable to hold the Lync subnets not in AD an subsequently removed from Lync.
$DelLyncSubnetTable = New-Object System.Data.DataTable "DelLyncSubnetTable"
$DelLyncSubnetTable = $LyncSubnetTable.Clone()

# By default all reports are considered a standard report unless something changes that condition further 
#   in the script.
$ToWho = $StandardEmailReport

# Prep the body of an HTML email message summarizing all the work the script has performed, with table
#   styles to control the formatting of any tables present it it.
$EmailBody = "<Html xmlns=`"http://www.w3.org/1999/xhtml`">`r`n"
$EmailBody += "<Head>`r`n"
$EmailBody += "<Style>`r`n"
$EmailBody += "TABLE{border-width: 1px;border-style: outset;border-color: black;border-spacing:" + `
	"1px;border-collapse: separate;}`r`n"
$EmailBody += "TH{border-width: 1px;padding: 1px;border-style: inset;border-color: black;}`r`n"
$EmailBody += `
    "TD{border-width: 1px;padding-left: 3px;padding-right: 3px;border-style: inset;border-color: black;}`r`n"
$EmailBody += "TABLE.First{border-style: none;}`r`n"
$EmailBody += "TD.First{border-style: none;}`r`n"
$EmailBody += "</Style>`r`n"
$EmailBody += "</Head>`r`n"
$EmailBody += "<Body>`r`n"

# Create a connection to the AD forest configuration naming context and define a link to the Sites container 
#   therein.
$ConfigNCDN = (Get-ADRootDSE).ConfigurationNamingContext
$SiteContainerDN = ("CN=Sites," + $ConfigNCDN)
# Grab the list of AD sites listed in the Sites container, including their subnet lists (siteObjectBL),
#   Location, and Description information.
$ADSites = Get-ADObject -SearchBase $SiteContainerDN -Filter { objectClass -eq "site" } `
  -Properties "siteObjectBL", "Location", "Description"

# Loop through each AD site listed in AD and add the information to the appropriate table.
Write-Host -ForegroundColor Green "Extracting site and subnet information from AD.`r`n"
Foreach ($ADSite in $ADSites) {
    # Check to see if the AD site has the required "(*)" region information, and also to make sure the
	#   Location information is not blank.
    If ((($ADSite.Description -notlike "(*") -or ($ADSite.Description -notlike "*)*")) -or ($ADSite.Location `
		-eq $null)) {
        # If either checks fail, then add the AD site to the Bad AD Site Table for reporting.
        $BadADSiteRow = $BadADSiteTable.NewRow()
        $BadADSiteRow.Name = $ADSite.Name
        If ($ADSite.Location -ne $Null) {$BadADSiteRow.Location = $ADSite.Location}
        If ($ADSite.Description -ne $Null) {$BadADSiteRow.Description = $ADSite.Description}
        $BadADSiteTable.Rows.Add($BadADSiteRow)
    } Else {
        # Otherwise add the site's information to the AD site table for further processing.
        $ADSiteRow = $ADSiteTable.NewRow()
        # Capture the AD site name, turning any character into an underscore that isn't an than alaphanumeric 
		#   character plus the space ( ), period (.) or underscore (_).
		$ADSiteRow.Name = ($ADSite.Name -Replace "[^\w\. ]", "_")
        $ADSiteRow.Location = $ADSite.Location
        # Capture the region name pulled from the text in between the ( and ) characters in the Description
		#   field, turning any character into an underscore that isn't an than alaphanumeric character plus
		#   the space ( ), period (.) or underscore (_).
        $ADSiteRow.Region = ($ADSite.Description.Split("()")[1] -Replace "[^\w\. ]", "_")
        # Even though the AD site description was only needed to pull out the region, it's added to the data 
		#   table for troubleshooting purposes.
		$ADSiteRow.Description = $ADSite.Description
        $ADSiteTable.Rows.Add($ADSiteRow)
        # While in each site, grab the subnets associated with that site and add them to the AD subnet table,
		#   including their Location and also their description if it is populated.
        Foreach ($ADSubnetDN in $ADSite.siteObjectBL) {
            $ADSubnet = Get-ADObject -Identity $ADsubnetDN -properties "Description", "Location"
            $ADSubnetRow = $ADSubnetTable.NewRow()
            $ADSubnetRow.Name = $ADSubnet.Name.Split("/")[0]
			$ADSubnetRow.Mask = $ADSubnet.Name.Split("/")[1]
            If ($ADSubnet.Description -ne $Null) {$ADSubnetRow.Description = $ADSubnet.Description}
            $ADSubnetRow.Site = $ADSite.Name
            $ADSubnetTable.Rows.Add($ADSubnetRow)
        	# Check to see if there was an error adding the subnet to the AD subnet table.
			If (!$?) {
				# An error was detected, so add the subnet to the bad AD subnet table.
				$DupADSubnetRow = $DupADSubnetTable.NewRow()
	            $DupADSubnetRow.Name = $ADSubnet.Name
				If ($ADSubnet.Description -ne $Null) {$DupADSubnetRow.Description = $ADSubnet.Description}
	            $DupADSubnetRow.Site = $ADSite.Name 
	            $DupADSubnetTable.Rows.Add($DupADSubnetRow)
 			}
		}
    }
}

# Check to see if there are any AD sites with missing information.
If ($BadADSiteTable.Rows.Count -ne 0) {
    # AD sites with missing information were found, so kick out of the rest of the synchronization code and
	#   generate an alert email report.
	$ToWho = $AlertEmailReport
	Write-Host -ForegroundColor Yellow "The following AD sites need to either have data added to thier" + `
		" Location attribute and/or include `"(Area)`" at the beginning of the Description attribute" + `
		" before this script can continue processing."
    $BadADSiteTable
	$Emailbody += "<br>- Bad AD Sites -`r`n"
	$EmailBody += $BadADSiteTable | ConvertTo-Html -Fragment @{Label="Site Name";Expression={$_.Name}},`
		Location,Description
} Else {
    # Create a list of regions by extracting the unique region names from the AD site table.
    $ADRegionList = $ADSiteTable | Select-Object -ExpandProperty Region -Unique
    # Create a list of regions by extracting the region names directly from Lync.
    $LyncRegionList = Get-CSNetworkRegion | Select-Object -ExpandProperty Identity

    # Loop through the region list pulled form AD and check to see if the region exists in Lync.
    Write-Host "Checking for new Lync regions."
	$AddRegionList = @()
    Foreach ($ADRegion in $ADRegionlist) {
        # If the region is missing in Lync, then add it to the $AddRegionList variable for reporting and
		#   add it as a Region in Lync.
        If (!($LyncRegionList -eq $ADRegion)) {
            New-CSNetworkRegion -Identity $ADRegion -CentralSite $CentralSite
            $AddRegionList += $ADRegion
        }
    }
	# Check to see if any Lync regions were added and sleep 60 seconds if there were to sure replication has
	#   time to occur before moving on.
	If ($AddRegionList.Count -gt 0) {
		Write-Host -ForegroundColor Green "One or more Lync Regions have been added. Waiting 60 seconds" + `
			" for replication before continuing."
		Start-Sleep 60
	}
	
    # Grab the list of Lync sites from Lync, including their description (Location) and region information,
	#   and add them to the Lync site table.
	$LyncSites = Get-CsNetworkSite | Select Identity,Description,NetworkRegionID
    Foreach ($LyncSite in $LyncSites) {
        $LyncSiteRow = $LyncSiteTable.NewRow()
        $LyncSiteRow.Name = $LyncSite.Identity
        $LyncSiteRow.Location = $LyncSite.Description
        $LyncSiteRow.Region = $LyncSite.NetworkRegionID
        $LyncSiteTable.Rows.Add($LyncSiteRow)
    }

    # Loop through the sites defined in AD to check them against the sites defined in Lync.
    Write-Host "Checking for new and reviewing existing Lync sites."
	Foreach ($ADSite in $ADSiteTable) {
        # Check to see if the AD site name is found in Lync.
        $LyncSiteMatch = $LyncSiteTable.Rows.Find($ADSite.Name)
		If ($LyncSiteMatch) {
            # The AD site was found in Lync, so check to make sure the other attributes are set correctly.
            If (($LyncSiteMatch.Location -ne $ADSite.Location) -or ($LyncSiteMatch.Region -ne `
				$ADSite.Region)) {
                # A difference was found, so record the changes in the change Lync site table and update
				#   the site in Lync. 
				$ChgLyncSiteRow = $ChgLyncSiteTable.NewRow()
                $ChgLyncSiteRow.Name = $ADSite.Name
				# Check to see if the location changed.
				If ($LyncSiteMatch.Location -ne $ADSite.Location) {
					# If it did change, record the change in the row.
					$ChgLyncSiteRow.Location = ("[" + $LyncSiteMatch.Location + "] --> [" + `
					$ADSite.Location + "]")
				} Else {
					# Otherwise record the existing record in the row.
					$ChgLyncSiteRow.Location = $ADSite.Location
				}
				# Check to see if the region changed.
				If ($LyncSiteMatch.Region -ne $ADSite.Region) {
					# If it did change, record the change in the row.
					$ChgLyncSiteRow.Region = ("[" + $LyncSiteMatch.Region  + "] --> [" + `
					$ADSite.Region + "]")
                } Else {
					# Otherwise record the existing record in the row.
                	$ChgLyncSiteRow.Region = $ADSite.Region
				}
                $ChgLyncSiteTable.Rows.Add($ChgLyncSiteRow)
                # Update the site information in Lync.
				Set-CsNetworkSite $ADSite.Name -Description $ADSite.Location -NetworkRegionID $ADSite.Region
            } Else {
				# If there were no differences detected, then do nothing.
			}
        } Else {
            # The AD site wasn't found in Lync, so add it to the add Lync site table and add it to Lync.
            $AddLyncSiteTable.ImportRow($ADSite)
            New-CsNetworkSite $ADSite.Name -Description $ADSite.Location -NetworkRegionID $ADSite.Region
        }
    }
	# Check to see if any Lync sites were added and sleep 60 seconds if there were to sure replication has
	#   time to occur before moving on.
	If ($AddLyncSiteTable.Rows.Count -gt 0) {
		Write-Host -ForegroundColor Green "One or more Lync Sites have been added. Waiting 60 seconds for" + `
			" replication before continuing."
		Start-Sleep 60
	}

    # Grab the list of Lync subnets from Lync, including their description and site information, and add them
	#   to the Lync subnet table.
    $LyncSubnets = Get-CsNetworkSubnet | Select Identity,MaskBits,Description,NetworkSiteID
    Foreach ($LyncSubnet in $LyncSubnets) {
        $LyncSubnetRow = $LyncSubnetTable.NewRow()
        $LyncSubnetRow.Name = $LyncSubnet.Identity.ToString()
		$LyncSubnetRow.Mask = $LyncSubnet.MaskBits
        $LyncSubnetRow.Description = $LyncSubnet.Description
        $LyncSubnetRow.Site = $LyncSubnet.NetworkSiteID
        $LyncSubnetTable.Rows.Add($LyncSubnetRow)
    }
    
    # Loop through the subnets defined in AD to check them against the subnets defined in Lync.
    Write-Host "Checking for new and reviewing existing Lync subnets."
	Foreach ($ADSubnet in $ADSubnetTable) {
        # Check to see if the AD subnet name is found in Lync.
        $LyncSubnetMatch = $LyncSubnetTable.Rows.Find($ADSubnet.Name)
		If ($LyncSubnetMatch) {
            # The AD subnet and mask was found in Lync, so check to make sure the other attributes are set
			#   correctly.
            If (($LyncSubnetMatch.Mask -ne $ADSubnet.Mask) -or ($LyncSubnetMatch.Description `
				-ne $ADSubnet.Description) -or ($LyncSubnetMatch.Site -ne $ADSubnet.Site)) {
                # A difference was found, so record the changes in the change lync subnet table and update 
				#   the subnet in Lync. 
				$ChgLyncSubnetRow = $ChgLyncSubnetTable.NewRow()
                $ChgLyncSubnetRow.Name = $ADSubnet.Name
				# Check to see if the subnet mask changed.
				If ($LyncSubnetMatch.Mask -ne $ADSubnet.Mask) {
					# If it did change, record the change in the row.
					$ChgLyncSubnetRow.Mask = ("[" + $LyncSubnetMatch.Mask + "] --> [" + $ADSubnet.Mask + "]")
				} Else {
					# Otherwise record the existing record in the row.
					$ChgLyncSubnetRow.Mask = $ADSubnet.Mask
				}
				# Check to see if the subnet description changed.
				If ($LyncSubnetMatch.Description -ne $ADSubnet.Description) {
					# If it did change, record the change in the row.
					$ChgLyncSubnetRow.Description = ("[" + $LyncSubnetMatch.Description + "] --> [" + `
						$ADSubnet.Description + "]")
				} Else {
					# Otherwise record the existing record in the row.
					$ChgLyncSubnetRow.Description = $ADSubnet.Description
				}
				# Check to see if the subnet site changed.
				If ($LyncSubnetMatch.Site -ne $ADSubnet.Site) {
					# If it did change, record the change in the row.
					$ChgLyncSubnetRow.Site = ("[" + $LyncSubnetMatch.Site + "] --> [" + $ADSubnet.Site + "]")
                } Else {
					# Otherwise record the existing record in the row.
					$ChgLyncSubnetRow.Site = $ADSubnet.Site
				}
				$ChgLyncSubnetTable.Rows.Add($ChgLyncSubnetRow)
                # Update the subnet information in Lync.
				Set-CsNetworkSubnet $ADSubnet.Name -MaskBits $ADSubnet.Mask -Description $ADSubnet.Description `
				-NetworkSiteID $ADSubnet.Site
            } Else {
				# If there were no differences detected, then do nothing.
			}
		} Else {
            # The AD site wasn't found in Lync, so add it to the add Lync site table and add it to Lync.
            $AddLyncSubnetTable.ImportRow($ADSubnet)
            New-CsNetworkSubnet -Identity $ADSubnet.Name -MaskBits $ADSubnet.Mask `
				-Description $ADSubnet.Description -NetworkSiteID $ADSubnet.Site
        }
    }    

    # Loop through the subnets defined in Lync to check them against AD.
	Write-Host "Checking for stale Lync subnets."
    Foreach ($LyncSubnet in $LyncSubnetTable) {
        # Check to see if the Lync subnet name is defined in AD.
        If ($ADSubnetTable.Rows.Find($LyncSubnet.Name)) {
            # The Lync subnet was found in AD, and since changes to any Lync subnet were handled above, no 
			#   action needs to be taken.
        } Else {
            # The Lync subnet was not in AD, so add it to the delete Lync subnet table and remove it from
			#   Lync.
            $DelLyncSubnetTable.ImportRow($LyncSubnet)
            Remove-CsNetworkSubnet $LyncSubnet.Name
        }
    }
    
	# Loop through the sites defined in Lync to check them against the sites in AD.
	Write-Host "Checking for stale Lync sites."
    Foreach ($LyncSite in $LyncSiteTable) {
        # Check to see if the Lync site name is defined in AD.
        If ($ADSiteTable.Rows.Find($LyncSite.Name)) {
            # The Lync site was found in AD and since changes to any Lync sites were handled above, no 
			#   action needs to be taken.
        } Else {
            # The Lync site was not found in AD, so add it to the delete Lync site table and remove it from
			#   Lync.
            $DelLyncSiteTable.ImportRow($LyncSite)
            Remove-CsNetworkSite $LyncSite.Name
        }
    }

    # Loop through the regions defined in Lync and check to see if the region exists in the region list pulled
	#   from AD.
	Write-Host "Checking for stale Lync regions."
	$DelRegionList = @()
    Foreach ($LyncRegion in $LyncRegionList) {
        If (!($ADRegionList -eq $LyncRegion)) {
			# The Lync region doesn't exist in AD so add it to the $DelRegionList variable for reporting and 
			#   remove it as a region in Lync.
            Remove-CSNetworkRegion -Identity $LyncRegion
            $DelRegionList += $LyncRegion
        }
    }

	# List a summary of changes in a special table leveraging the "First" table class style listed above.
	$Emailbody += "<table class=`"First`">`r`n"
	# Note the number of regions added, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Regions Added</b></td><td class=`"First`"><b>:</b> " + `
	    $AddRegionList.Count + "</td></tr>`r`n"
	# Note the number of regions removed, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Regions Removed</b></td><td class=`"First`"><b>:</b> " + `
	    $DelRegionList.Count + "</td></tr>`r`n"
	# Note the number of Lync sites added, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Sites Added</b></td><td class=`"First`"><b>:</b> " + `
	    $AddLyncSiteTable.Rows.Count + "</td></tr>`r`n"
	# Note the number of Lync sites changed, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Sites Updated</b></td><td class=`"First`"><b>:</b> " + `
	    $ChgLyncSiteTable.Rows.Count + "</td></tr>`r`n"
	# Note the number of Lync sites removed, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Sites Removed</b></td><td class=`"First`"><b>:</b> " + `
	    $DelLyncSiteTable.Rows.Count + "</td></tr>`r`n"
		# Note the number of Lync subnets added, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Subnets Added</b></td><td class=`"First`"><b>:</b> " + `
	    $AddLyncSubnetTable.Rows.Count + "</td></tr>`r`n"
	# Note the number of Lync subnets changed, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Subnets Updated</b></td><td class=`"First`"><b>:</b> " + `
	    $ChgLyncSubnetTable.Rows.Count + "</td></tr>`r`n" 
	# Note the number of Lync subnets removed, even if there were none.
	$Emailbody += "<tr><td class=`"First`"><b>Subnets Removed</b></td><td class=`"First`"><b>:</b> " + `
	    $DelLyncSubnetTable.Rows.Count + "</td></tr>`r`n"
	# Close the "First" table.
	$Emailbody += "</table>`r`n"

	# If there were any AD subnets in the bad AD subnet table, list them in a table (using the default table 
	#   style above) with friendly column names.
	If ($DupADSubnetTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br><b>- Duplicate AD Subnets (</b><i>Please follow up on these</i><b>) -</b>`r`n"
	    $EmailBody +=  $DupADSubnetTable | ConvertTo-Html -Fragment @{Label="Subnet";Expression={$_.Name}},`
			Description,Site
	} 
	
	# If there were any new regions, then list them in in a single line separated with commas.
	If ($AddRegionList.Count -gt 0) {
		$ToWho = $AlertEmailReport
		$Emailbody += (("<br>- Regions Added :" + ("$AddRegionList" -Replace " ",",") + "`r`n"))
		$Emailbody += "(</b><i>Please review the Region Links and add/adjust as necessary</i><b>)`r`n" 
	} 
	# If there were any regions deleted, then list them in in a single line separated with commas.
	If ($DelRegionList.Count -gt 0) {
		$ToWho = $AlertEmailReport
		$Emailbody += (("<br>- Regions Removed : " + ("$DelRegionList" -Replace " ",",") + "`r`n"))
		$Emailbody += "(</b><i>Please review the Region Links and remove/adjust as necessary</i><b>)`r`n" 
	} 

	# If there were any Lync sites added then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($AddLyncSiteTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Sites Added -`r`n"
	    $EmailBody += $AddLyncSiteTable | ConvertTo-Html -Fragment @{Label="Site Name";Expression={$_.Name}},`
	        Location,Region
	} 

	# If there were any Lync sites changed then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($ChgLyncSiteTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Sites Updated -`r`n"
	    $EmailBody += ($ChgLyncSiteTable | ConvertTo-Html -Fragment `
			@{Label="Site Name";Expression={$_.Name}},Location,Region) `
			-Replace("--&gt;","<font face=`"Wingdings`">&#224;</font>")
	} 

	# If there were any Lync sites removed then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($DelLyncSiteTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Sites Removed -`r`n"
	    $EmailBody += $DelLyncSiteTable | ConvertTo-Html -Fragment @{Label="Site Name";Expression={$_.Name}},`
	        Location,Region
	} 

	# If there were any Lync subnets added then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($AddLyncSubnetTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Subnets Added -`r`n"
	    $EmailBody += $AddLyncSubnetTable | ConvertTo-Html -Fragment @{Label="Subnet";Expression={$_.Name}},`
	        Mask,Descripton,Site
	} 

	# If there were any Lync subnets changed then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($ChgLyncSubnetTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Subnets Updated -`r`n"
	    $Emailbody += ($ChgLyncSubnetTable | ConvertTo-Html -Fragment @{Label="Subnet";Expression={$_.Name}},`
			Mask,Description,Site) -Replace("--&gt;","<font face=`"Wingdings`">&#224;</font>")
	} 

	# If there were any Lync subnets removed then list them in a table (using the default table style above)
	#   with friendly column names.
	If ($DelLyncSubnetTable.Rows.Count -gt 0) {
		$ToWho = $AlertEmailReport
	    $Emailbody += "<br>- Lync Subnets Removed -`r`n"
	    $EmailBody += $DelLyncSubnetTable | ConvertTo-Html -Fragment `
			@{Label="Site Name";Expression={$_.Name}},Mask,Description,Site
	} 
}

# Close out the HTML content in the body of the email message.
$EmailBody += "</Body>`r`n"
$EmailBody += "</Html>`r`n"

#Formatting the email subject line to include the $DateTime variable.
$EmailSubject = "Daily Lync/AD Site & Subnet synchronization report for $DateTime."

# Write to the screen the sychronization is complete and send the email report.
Write-Host  -ForegroundColor Green "`r`nThe synchronization is complete and the report is being generated."
Send-MailMessage -Subject $EmailSubject -From "DoNotReply@company.com" -To $ToWho.Split(";") -Body $EmailBody `
	-BodyAsHtml -SmtpServer "smtprelay.company.com"