﻿


#Create random records
$range = 1..1000

$count = $range.Count
For($i=0; $i -lt $count; $i++) 
{
    
    $random = Get-RandomZoneName -count 10
    $result = Add-DnsServerResourceRecordA -ComputerName dns-dc1 -Name $random -ZoneName contosouniversity.edu -IPv4Address 10.10.10.1 -ErrorVariable Err -ErrorAction SilentlyContinue
    if ($Err)
    {
        Write-Host $Err -ForegroundColor Yellow
    }
}


#Delete random records
$records = Get-DnsServerResourceRecord -RRType A -ZoneName contosouniversity.edu
foreach ($record in $records)
{
    
    Remove-DnsServerResourceRecord -Name $record.HostName -ZoneName contosouniversity.edu -RRType A -Force
}

$records = Get-DnsServerResourceRecord -ZoneName contosouniversity.edu
$records.count

Function Get-RandomZoneName ($count)
{
    $output = $null
    $v = ($a = "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o","p","q","r","s","t","u","v","w","x","y","z") | Get-Random -Count $count
    foreach ($r in $v) {$output = $output + $r} Return "RandomRecord" + $output
}
