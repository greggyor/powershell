
function Add-AccessRule {
Param(
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Rule Name          		 	")] $RuleName,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="All=0, Specified=1, All Except =2	")] $ProtocolSelection,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Protocol           		 	")]  $Protocol,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Allow=1, Deny=0    		 	")] $Action,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Users              		 	")] $USerSet,
[parameter(Mandatory=$false, ValueFromPipeline=$true, HelpMessage="Users  Include=0, Exclude=1      	")] $UserSetInEx=0,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Source Network     		 	")] $Source,
[parameter(Mandatory=$false, ValueFromPipeline=$true, HelpMessage="Source Include=0, Exclude=1      	")] $SourceInEx=0,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Destination Network		 	")]  $Destination,
[parameter(Mandatory=$false, ValueFromPipeline=$true, HelpMessage="Destination Include=0, Exclude=1 	")]  $DestinationInEx=0,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Array TMG Master   		 	")] $StorageServer,
[parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Array Name         		 	")] $EMSArrayName

)

#Begin
#Connecting to Storage Configuration server
$tmgrootEMS = New-Object -ComObject "FPC.Root"
$tmgrootems.ConnectToConfigurationStorageServer($StorageServer)

#Finding the right Array
#You need this if you are using a EMS
foreach ($EMSarray in $tmgRootems.Arrays) 
	{ 
	if ($EMSArrayName=$EmsArray.Name) then
		{
		 Exit For
		}
	}

#Creating emty rule set
$PolicyRules = $EMSarray.ArrayPolicy.PolicyRules

#Rule creatoin
$newrule = $PolicyRules.AddAccessRule($RuleName)
$newrule.Action=$Action
$newrule.SourceSelectionIPs.Networks.Add($Source, $SourceInEx)
$newrule.AccessProperties.DestinationSelectionIPs.Networks.Add($Destination,$DestinationInEx)
$newrule.AccessProperties.SpecifiedProtocols.Add("FTP", $ProtocolSelection)  
$newrule.AccessProperties.ProtocolSelectionMethod =  $ProtocolSelection
$newrule.AccessProperties.UserSets.Add($USerSet, $USerSetInEx)

#Saving the rule
$policyrules.Save()

#End
}
