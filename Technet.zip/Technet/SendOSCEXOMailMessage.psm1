<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Load .NET Assembly for Windows PowerShell V2
Add-Type -AssemblyName System.Core

$webSvcInstallDirRegKey = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Exchange\Web Services\2.0" -PSProperty "Install Directory" -ErrorAction:SilentlyContinue
if ($webSvcInstallDirRegKey -ne $null) {
	$moduleFilePath = $webSvcInstallDirRegKey.'Install Directory' + 'Microsoft.Exchange.WebServices.dll'
	Import-Module $moduleFilePath
} else {
	$errorMsg = $Messages.InstallExWebSvcModule
	throw $errorMsg
}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Connect-OSCEXOWebService
{
	#.EXTERNALHELP Connect-OSCEXOWebService-Help.xml

    [cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[System.Management.Automation.PSCredential]$Credential,
		[Parameter(Mandatory=$false,Position=2)]
		[Microsoft.Exchange.WebServices.Data.ExchangeVersion]$ExchangeVersion="Exchange2010_SP2",
		[Parameter(Mandatory=$false,Position=3)]
		[string]$TimeZoneStandardName,
		[Parameter(Mandatory=$false)]
		[switch]$Force
	)
	Process
	{
        #Get specific time zone info
        if (-not [System.String]::IsNullOrEmpty($TimeZoneStandardName)) {
            Try
            {
                $tzInfo = [System.TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneStandardName)
            }
            Catch
            {
                $PSCmdlet.ThrowTerminatingError($_)
            }
        } else {
            $tzInfo = $null
        }

		#Create the callback to validate the redirection URL.
		$validateRedirectionUrlCallback = {
            param ([string]$Url)
			if ($Url -eq "https://autodiscover-s.outlook.com/autodiscover/autodiscover.xml") {
            	return $true
			} else {
				return $false
			}
        }	
	
		#Try to get exchange service object from global scope
		$existingExSvcVar = (Get-Variable -Name exService -Scope Global -ErrorAction:SilentlyContinue) -ne $null
		
		#Establish the connection to Exchange Web Service
		if ((-not $existingExSvcVar) -or $Force) {
			$verboseMsg = $Messages.EstablishConnection
			$PSCmdlet.WriteVerbose($verboseMsg)
            if ($tzInfo -ne $null) {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion,$tzInfo)			
            } else {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion)
            }
			
			#Set network credential
			$userName = $Credential.UserName
			$exService.Credentials = $Credential.GetNetworkCredential()
			Try
			{
				#Set the URL by using Autodiscover
				$exService.AutodiscoverUrl($userName,$validateRedirectionUrlCallback)
				$verboseMsg = $Messages.SaveExWebSvcVariable
				$PSCmdlet.WriteVerbose($verboseMsg)
				Set-Variable -Name exService -Value $exService -Scope Global -Force
			}
			Catch [Microsoft.Exchange.WebServices.Autodiscover.AutodiscoverRemoteException]
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
			Catch
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
		} else {
			$verboseMsg = $Messages.FindExWebSvcVariable
            $verboseMsg = $verboseMsg -f $exService.Credentials.Credentials.UserName
			$PSCmdlet.WriteVerbose($verboseMsg)            
		}
	}
}

Function Send-OSCEXOEmailMessage
{
	#.EXTERNALHELP Send-OSCEXOEmailMessage-Help.xml

    [cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[string]$From,
		[Parameter(Mandatory=$false,Position=2)]
		[string[]]$To,
		[Parameter(Mandatory=$false,Position=3)]
		[string[]]$Cc,
		[Parameter(Mandatory=$false,Position=4)]
		[string[]]$Bcc,
		[Parameter(Mandatory=$true,Position=5)]
		[string]$Subject,
		[Parameter(Mandatory=$false,Position=6)]
		[string]$Body,
		[Parameter(Mandatory=$false,Position=7)]
        [ValidateSet("Normal","Low","High")]
		[string]$Priority="Normal",
		[Parameter(Mandatory=$false,Position=8)]
		[string[]]$Attachments,
		[Parameter(Mandatory=$false,Position=9)]
		[string[]]$InlineAttachments,
 		[Parameter(Mandatory=$false,Position=10)]
		[datetime]$DeferredSendTime,
 		[Parameter(Mandatory=$false)]
		[switch]$RequestReadReceipt,
 		[Parameter(Mandatory=$false)]
		[switch]$RequestDeliveryReceipt
	)
	Begin
	{
        #Verify the existence of exchange service object
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
	}
    Process
    {
		#Verify recipient mail addresses
        if ([System.String]::IsNullOrEmpty($To) -and `
            [System.String]::IsNullOrEmpty($Cc) -and `
            [System.String]::IsNullOrEmpty($Bcc)) {
			$errorMsg = $Messages.RequiresRecipient
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }

		#Verify each attachment
        foreach ($attchmentPath in $Attachments) {
            if (-not (Test-Path -Path $attchmentPath)) {
 			    $errorMsg = $Messages.CannotFindFile
                $errorMsg = $errorMsg -f $attchment
			    $customError = New-OSCPSCustomErrorRecord `
			    -ExceptionString $errorMsg `
			    -ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			    $PSCmdlet.ThrowTerminatingError($customError)               
            }
        }

		#Verify each inline attachment
        foreach ($inlineAttachmentPath in $inlineAttchments) {
            if (-not (Test-Path -Path $inlineAttachmentPath)) {
 			    $errorMsg = $Messages.CannotFindFile
                $errorMsg = $errorMsg -f $attchment
			    $customError = New-OSCPSCustomErrorRecord `
			    -ExceptionString $errorMsg `
			    -ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			    $PSCmdlet.ThrowTerminatingError($customError)               
            }
        }

        #Verify DeferredSendTime
        Try
        {
            if ($DeferredSendTime -ne $null) {
                $sendTime = [System.DateTime]::Parse($DeferredSendTime)
                $sendTime = $sendTime.ToUniversalTime().ToString()
            }
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }

        #Create a new email message object
        $emailMessage = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage($exService)

        #Populate from address
        if (-not [System.String]::IsNullOrEmpty($From)) {
            $emailMessage.From = $From
        }

        #Populate recipient addresses
        if (-not [System.String]::IsNullOrEmpty($To)) {
            foreach ($toRecipient in $To) {
                $emailMessage.ToRecipients.Add($toRecipient) | Out-Null
            }
        }
        if (-not [System.String]::IsNullOrEmpty($Cc)) {
            foreach ($ccRecipient in $Cc) {
                $emailMessage.CcRecipients.Add($ccRecipient) | Out-Null
            }
        }
        if (-not [System.String]::IsNullOrEmpty($Bcc)) {
            foreach ($bccRecipient in $Bcc) {
                $emailMessage.CcRecipients.Add($bccRecipient) | Out-Null
            }
        }

        #Add properties to the email message
        $emailMessage.Subject = $Subject
        $emailMessage.Body = $Body
        $emailMessage.Importance = $Priority
        $emailMessage.IsReadReceiptRequested = $RequestReadReceipt.ToBool()
        $emailMessage.IsDeliveryReceiptRequested = $RequestDeliveryReceipt.ToBool()
        
        #Add attachments
        foreach ($attachmentPath in $Attachments) {
            $attachment = $emailMessage.Attachments.AddFileAttachment($attachmentPath)
        }

        #Add inline attachments
        foreach ($inlineAttachmentPath in $InlineAttachments) {
            $fileName = $inlineAttachmentPath.Split("\")[-1]
            $inlineAttachment = $emailMessage.Attachments.AddFileAttachment($fileName,$inlineAttachmentPath)
            $inlineAttachment.IsInline = $true
            $inlineAttachment.ContentId = $fileName
        }

        #Add extended properties
        if ($DeferredSendTime -ne $null) {
            #Identify the extended properties that are used to set the time when the email message is sent.
            $pidTagDeferredSendTime = 16367
            $prDeferredSendTime = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(`
                                  $pidTagDeferredSendTime,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
            #Identify when the email message will be sent and delivered.
            $emailMessage.SetExtendedProperty($prDeferredSendTime,$sendTime)        
        }

        #Send email message
        Try
        {
            $emailMessage.SendAndSaveCopy()
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
	End {}
}

Export-ModuleMember -Function "Connect-OSCEXOWebService","Send-OSCEXOEmailMessage"