﻿<#
.SYNOPSIS
Sets a User Quota limit on a FSRM managed quota
.DESCRIPTION
This Script Cmdlet uses the built-in dirquota.exe (wich requires you to install the FSRM RSAT tool)
It let you use dirquota.exe in a PowerShell way, Without the need to know in wich server or path the user is on. 
Please Notice - This function requires the advticedirectory module loaded and the FSRM RSAT tool installed!
.PARAMETER User
Mandatory.
Accepts pipeline input.
This parameter is passed to the Get-ADUser Identity parameter.
it accepts the following attributes:
 SamAccountName, DistringuishedName, objectSid, and ObjectGuid.
.PARAMETER Limit
Mandatory.
The quota limit that you want to give to the folder.
Supply the value in megabytes only.
there is no need to type (for example) "1500MB". the script adds the 'MB' suffix.

.EXAMPLE

Set-HomeFolderQuota -User James -Limit 1300

Sets a quota limit of 1300MB on \\FileServer\Users\James

#>
function Set-FSRMQuota {
   
   [CmdletBinding()]
    
    param(
        [Parameter(Mandatory=$True, ValueFromPipeline=$True, ValueFromPipelineByPropertyName=$True)]
        [string]$User,
        [Parameter(Mandatory=$True)]
        [string]$limit
    )
        
        BEGIN{
            Write-Warning "`nthis cmdlet does not use regular PowerShell Cmdlets or .NET objects, it parameter passes data to dirquota.exe`n"
        }

        PROCESS{
             
            #### Extract File Server and the UNC of the folder(Used for dirquota) ####
            $ad = Get-ADUser $User -Properties homedirectory
            $sam = $ad | select -ExpandProperty samaccountname
            $UNC = $ad | select -ExpandProperty homedirectory
            Write-Debug "UNC is $UNC"

            $FolderUNC = (Get-Item $UNC).Parent | select -ExpandProperty name
            Write-Debug "UNC is $FolderUNC"

            $ServerUNC = ($UNC -replace "$FolderUNC.*").trim('\')
            Write-Debug "SERVER is $ServerUNC"            

            $path = Get-WmiObject win32_share -ComputerName $serverUNC | Where-Object {$_.name -like $FolderUNC} | select -ExpandProperty path
            Write-Debug "path is $path"
            $limit = $limit + "mb"

            #### The dirquota command ####
            dirquota.exe q m /remote:$serverUNC /path:$path\$sam /limit:$limit
            
            Write-Host "dirquota.exe commnd:`ndirquota.exe q m /remote:$ServerUNC /path:$path\$sam /limit:$limit"
            
            #### Acknowledgement ####
            $text = dirquota.exe q l /remote:$ServerUNC /path:$path\$sam | Select-String "limit:", "used:", "available:" | ForEach-Object {$_.tostring().split(":")[1].trimstart()}
            
            $ack = New-Object -TypeName PSObject -Property @{ 
                                                                SamAccountName = $Sam;
                                                                UNC = $UNC;
                                                                QuotaLimit = $text[0];
                                                                Used = $text[1];
                                                                Available = $text[2];                                               
                                                            }
            Write-Output $ack                                                                                                                
        }

        END{}
}