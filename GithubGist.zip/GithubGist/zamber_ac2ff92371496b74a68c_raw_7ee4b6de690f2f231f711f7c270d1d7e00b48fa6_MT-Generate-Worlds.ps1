#
# MTSH (MoreTerra Simple Helper) v0.1.0
# PowerShell 3.0
#
# Generate world images from Terraria world with MoreTerra
# Configure and fork it as you see fit.
#
# To schedule it as a task follow this http://j.mp/schedule-powershell 
#
# To host it use http://cestana.com/mongoose.shtml
#
# Remember to http://j.mp/powershell-dl Get-Help About_Signing
#
# @author Piotr Zaborowski
# @license CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0/
#

# # config

$root   = "C:\Users\zamber\Documents"
$mt     = "$root\MoreTerra"
$worlds = "$root\My Games\Terraria\Worlds"
$dest   = "$root\World Maps"
$log    = "$root\World Maps\log.txt"

Function Log {
    Param ([String]$logstring)
    $date = Get-Date -UFormat %c
    Add-Content $log -Value "$date : $logstring" 
}

function Main {
    
    Log "Starting ----------------------------------------------------------"
    
    Get-ChildItem $worlds\* -Include *.wld | % {
        
        $image = "$dest\" + $_.Name + ".png"
        
        $worldPath = $_.FullName
        $args = "-w `"$worldPath`" -o `"$image`""
        
        Log "Running $mt\MoreTerra.exe $args"
        
        Start-Process "cmd.exe" "/c $mt\MoreTerra.exe $args" -Wait
        
        Log "Done"

    }
}

Main

