function vs {
	param($Path = ".")
	
	if ($Path -inotmatch "\.sln$") { $Path = Join-Path $Path "*.sln" }
	
	dir -ErrorAction SilentlyContinue -recurse *.sln |
		&{
			$d = @($input)
			
			if ($d.Count -eq 1) { $d[0] }
			elseif ($d.Count -eq 0) { $null }
			else {
				$choice = Read-Host ("Please select a solution:`n" + ($d | %{$i = 0} { "[$i] $_`n"; $i++ }))
				$d[([int]$choice)]
			}
		} |
		&{
			$p = @($input)[0]
			if ($p -ne $null) {
				Write-Host "Opening $p"
				& "C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\devenv.exe" $p
			}
		}
}

