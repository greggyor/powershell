svn status --no-ignore |
    Select-String '^[?I]' |
    ForEach-Object {
        [Regex]::Match($_.Line, '^[^\s]*\s+(.*)$').Groups[1].Value
    } |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

