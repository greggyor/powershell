# Set a static IP and default gateway
Get-NetAdapter -Name Ethernet | New-NetIPAddress -AddressFamily IPv4 -IPAddress 10.0.1.100 -PrefixLength 24 -Type Unicast `
-DefaultGateway 10.0.1.1

# Configure DNS server address
Get-NetAdapter -Name Ethernet | Set-DnsClientServerAddress -InterfaceAlias Ethernet -ServerAddresses 10.0.1.10

# Join computer to a domain
Add-Computer -DomainName "psa.local" -Credential "psa\adminaccount"







# Preferences:
# 1 --- http://thepracticalsysadmin.com/powershell/

