# based on http://blogs.msdn.com/b/wats/archive/2014/05/19/how-to-determine-current-guest-os-family-only-for-pass-instance-web-role-and-worker-role-windows-azure-powershell.aspx
# 
# setup Azure publish settings according to http://blogs.msdn.com/b/wats/archive/2013/02/18/windows-azure-powershell-getting-started.aspx

foreach ($Subscription in (Get-AzureSubscription))
{
	Select-AzureSubscription -SubscriptionName $Subscription.SubscriptionName
	Write-Host "Subscription:" $Subscription.SubscriptionName
	
	foreach ($Service in (Get-AzureService))
	{
		Write-Host "    Service:" $Service.ServiceName
		
		foreach ($Deployment in (Get-AzureDeployment -ErrorAction SilentlyContinue -ServiceName $Service.ServiceName))
		{
			Write-Host "        Deployment:" $Deployment.Label
		
			[System.Xml.XmlDocument] $DeploymentConfigurationXML = new-object System.Xml.XmlDocument
			$DeploymentConfigurationXML.LoadXml($Deployment.Configuration)
			Write-Host "        SDK:" $Deployment.SdkVersion
			Write-Host "        OS Family:" $DeploymentConfigurationXML.ServiceConfiguration.osFamily
			Write-Host "        OS Version:" $DeploymentConfigurationXML.ServiceConfiguration.osVersion
			Write-Host
		}
	}
	
	Write-Host
}


