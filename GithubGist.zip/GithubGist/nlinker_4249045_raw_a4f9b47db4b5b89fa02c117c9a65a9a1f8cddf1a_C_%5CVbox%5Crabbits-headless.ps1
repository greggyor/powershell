# make sure this mode is enabled under administrator: Set-ExecutionPolicy RemoteSigned
# use a batch file like this:
# C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe C:\Vbox\rabbits-headless.ps1


$items = @( 'vagrant-rabbitmq-cluster_1351840619', 'vagrant-rabbitmq-cluster_1351840685', 'vagrant-rabbitmq-cluster_1351840745', 'vagrant-rabbitmq-cluster_1351840804' )

Foreach ($item in $items) {
	$p = '-s ' + $item
	start-process 'C:\ProgramsX\Oracle\VirtualBox\VBoxHeadless.exe' $p -WindowStyle Hidden
}

write-host "All systems go" -foregroundcolor "magenta" -backgroundcolor "blue"


