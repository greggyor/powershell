function filesDifferent($sourceFilename, $targetFilename) {
   $targetFileExists = fileExists $targetFilename
   if (!($targetFileExists)) {
      return $TRUE
   }

   if ($sourceFilename.Contains(".jar")) {
      removeFolder "c:\tmp\jartest\source"
      removeFolder "c:\tmp\jartest\target"

      $extractSource = 'mkdir c:\tmp\jartest\source && cd c:\tmp\jartest\source && jar xvf "' + $sourceFilename + '"'
      #Write-Host $extractSource
      cmd /C $extractSource 2>&1 | Out-Null
      
      $extractTarget = 'mkdir c:\tmp\jartest\target && cd c:\tmp\jartest\target && jar xvf "' + $targetFilename + '"'
      #Write-Host $extractTarget
      cmd /C $extractTarget 2>&1 | Out-Null

      removeFolder "c:\tmp\jartest\source\META-INF"
      removeFolder "c:\tmp\jartest\target\META-INF"

      $result = foldersDifferent "c:\tmp\jartest\source" "c:\tmp\jartest\target" $FALSE
      
      #Write-Host "result = " $result
      
      removeFolder "c:\tmp\jartest\source"
      removeFolder "c:\tmp\jartest\target"

      return $result      
   } else {

      if (@(Compare-Object $(Get-Content $sourceFilename -encoding byte) $(Get-Content $targetFilename -encoding byte) -sync 0).length -eq 0) {
    
          return $FALSE
      } else {
          return $TRUE
      }
   }
}

function fileExists($filename) {
   $targetFileExists = (Test-Path $targetFilename -PathType Leaf)
   if ($targetFileExists) {
      return $TRUE
   } else {
      return $FALSE
   }
}

function foldersDifferent($sourcePath, $targetPath, $syncFile) {
    $result = $FALSE

    #Write-Host ""
    #Write-Host "Comparing:"
    #Write-Host $sourceFolder.path
    #Write-Host $targetPath
    #Write-Host ""

    $sourceFolder = getFolderFromPath($sourcePath)
    
    foreach ($sourcefile in $sourceFolder.files) {
        #Write-Host ""
        #Write-Host "Found file = {0}", $sourceFile.name
        if (processFile $sourceFile $targetPath $syncFile) {
           #Write-Host "Different (1)"
           $result = $TRUE
        }
    }

    foreach ($subFolder in $sourceFolder.subfolders) {
        #Write-Host ""
        #Write-Host "Found subfolder = {0}", $subFolder.name
        $result = foldersDifferent $subFolder.path ($targetPath + "\" + $subFolder.name) $syncFile
    }
    
    return $result
}

function removeFolder($path) {
    if ((Test-Path -path $path)) {
        #Write-Host "Removing: {0}" $path 
        Get-ChildItem -Path $path -Recurse | Remove-Item -force -recurse
        Remove-Item $path
    }
}

function processFile($sourceFile, $targetPath, $syncFile) {
  $result = $FALSE
  
  $sourceFilename = $sourceFile.path
  $targetFilename = $targetPath + "\" + $sourceFile.name
  
  #Write-Host "sourceFilename = {0}" $sourceFilename
  #Write-Host "targetFilename = {0}" $targetFilename

  $result = filesDifferent $sourceFilename $targetFilename
  #Write-Host "result = " $result
  
  if ($result) {
     #Write-Host "Different (2)"
     #$result = $TRUE
     
     if ($syncFile) {
        Write-Host("{0} Different", $sourceFilename)
        # Copy new over original
        $targetFileExists = fileExists $targetFilename
        if ($targetFileExists) {
            remove-item $targetFilename
        }
        New-Item -ItemType File -Path $targetFilename -Force
        copy-item $sourceFilename $targetFilename -Force
     }
  }

  return $result
}

function getParentFolderName($file) {
   $parentFolderName = $file.ParentFolder.name

   return $parentFolderName
}

function dump($obj) {
   foreach ($property in $obj.PSObject.Properties) { 
      Write-Host "$($property.Name)=$($obj.PSObject.properties[$property.Name].Value)" 
   }
}

function getFolderFromPath($path) {
    $fc = new-object -com scripting.filesystemobject
    $folder = $fc.getfolder($path)
    
    return $folder
}

function syncFolders($sourcePath, $targetPath) {
    Write-Host "sourcePath = {0}", $sourcePath
    Write-Host "targetPath = {0}", $targetPath
    
    Write-Host "==================================================================="
    Write-Host "Starting to process the plugin folder" 
    Write-Host "==================================================================="

    $result = foldersDifferent $sourcePath $targetPath $TRUE
    
    if (!$result) {
       Write-Host "No differences found"
    }

    Write-Host "==================================================================="
    Write-Host "Completed processing the plugin folder"
    Write-Host "==================================================================="
}


