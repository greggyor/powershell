Function Get-FileName($initialDirectory) {
    Add-Type -Assembly System.windows.forms | Out-Null
    $initialDirectory = "C:\"
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.InitialDirectory = $initialDirectory
    $OpenFileDialog.Filter = "Log files (*.Log)| DhcpSrvLog-*.log"
    $OpenFileDialog.Multiselect = $false
    $OpenFileDialog.ShowDialog() | Out-Null
    $OpenFileDialog.FileName
} #end function Get-FileName

# *** Entry Point to Script ***
$log = Get-FileName
$logdate = (Get-ItemProperty $log).LastWriteTime.AddDays(-1) -split ' '
$namedate = $logdate[0] -split '/' -join '-'
$events = Get-Content $log

$csvhead = "ID","Date","Time","Description","IP Address","Host Name","MAC Address","User Name","TransactionID","QResult","Probationtime",`
"CorrelationID","Dhcid","VendorClass(Hex)","VendorClass(ASCII)","UserClass(Hex)","UserClass(ASCII)","RelayAgentInformation","DnsRegError"

$lines = $events | Select-String -Pattern "\b(?:\d{1,3}\.){3}\d{1,3}\b" | ConvertFrom-Csv -Header $csvhead

$csvfile = $lines | where { $_.ID -eq '10' } | select -Unique 'MAC Address','Host Name','IP Address'

$Pre = "<h1>DHCP Log ""$($log.Split('\.')[-2])"" from ""$($logdate[0])""</h1> <h2>There were $($csvfile.Length) unique leases.</h2>"

#Create the HTML formating
$Header = @"
<style>
TABLE {border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}
TH {border-width: 1px;padding: 3px;border-style: solid;border-color: black;background-color: #6495ED;}
TD {border-width: 1px;padding: 3px;border-style: solid;border-color: black;}
</style>
<Title>
New IP Address Leases
</Title>
"@

#And create HTML file...
$csvfile | sort-object 'MAC Address' | ConvertTo-HTML -PreContent $Pre -head $Header | Out-File -Append "$env:USERPROFILE\Documents\$($log.Split('\.')[-2])-$namedate.html"

