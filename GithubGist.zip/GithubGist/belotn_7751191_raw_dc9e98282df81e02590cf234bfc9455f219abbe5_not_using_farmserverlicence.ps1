get-xaserver | get-xaserverconfiguration |? {! $_.LicenseServerUseFarmSettings } | select ServerName

