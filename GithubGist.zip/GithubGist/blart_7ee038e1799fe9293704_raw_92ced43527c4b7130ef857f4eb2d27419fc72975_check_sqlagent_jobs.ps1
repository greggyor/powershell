# SQL Agent Job Status - check_mk local plugin check.
# Copyright 2014 Iomart Hosting Limited - coreservices@iomart.com.
 
# Directions for use:
#
# Place in the check_mk plugin directory.
# Edit the check_mk ini file to allow execution of ps1 powershell files.
# Edit c:\program files (x86)\check_mk\sqlservers.txt to contain the server (and instance if applicable)
 
# Reset our output buffer size as we shouldn't do any line wrapping.
$host.UI.RawUI.BufferSize=new-object System.Management.Automation.Host.Size(2048,50)
 
# Load SMO extension
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null;
# Get List of sql servers to check
$sqlservers = Get-Content "C:/Program Files (x86)/check_mk/sqlservers.txt";
 
# Loop through each sql server from sqlservers.txt
foreach($sqlserver in $sqlservers)
{
    # Create an SMO Server object
    $srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $sqlserver;
 
    # For each jobs on the server
    foreach($job in $srv.JobServer.Jobs) {
        $jobName = $job.Name;
        $jobEnabled = $job.IsEnabled;
        $jobLastRunOutcome = $job.LastRunOutcome;
        $jobLastRunDate = $job.LastRunDate
 
        $checkName = "SQL Agent Status $jobName"
        $checkName = $checkName.replace(" ", "_")
 
        # Skip jobs that are not enabled.
        if ($jobEnabled -eq "True") {
            # default for each job.
            $status = 3
            $statusText = 'UNKNOWN'
 
            # Successfully completed.
            if($jobLastRunOutcome -eq "Failed") {
                $status = 2
                $statusText = 'CRITICAL'
            }
            elseif ($jobLastRunOutcome -eq "Succeeded") {
                $status = 0
                $statusText = 'OK'
            }
 
 
            Write-Host $status $checkName - "$statusText - Job last run status: $jobLastRunOutcome at $jobLastRunDate";
        }
    }
}

