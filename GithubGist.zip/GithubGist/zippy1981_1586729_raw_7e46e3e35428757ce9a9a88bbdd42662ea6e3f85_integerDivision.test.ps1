<#
	In which I prove that that the terser [int][Math]::Floor($a/$b) gives the
	same results as the technet recommended [Math]::Floor([int]$a / [int]$b)
	Said technet recomendation is available at:
	http://technet.microsoft.com/en-us/library/ee176879.aspx
	One extra cast is probably slower too.
#>

1.. 1000 | ForEach-Object {
	Foreach ($divisor in 2,3,5,7) {
		$a = [int][Math]::Floor($_ / $divisor)
		$b = [Math]::Floor([int]$_ / [int]$divisor)
		if ($a -ne $b) {
			"$($a) <> $($b) : $($a)/$($b)"
		}
	}


}

