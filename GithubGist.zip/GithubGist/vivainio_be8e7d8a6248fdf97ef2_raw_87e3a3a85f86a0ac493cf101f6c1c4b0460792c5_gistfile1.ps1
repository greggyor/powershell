# edit this by: notepad $PROFILE
# assumes you have Github for Windows installed (or just posh-git may be enough?)
# Load posh-git example profile
. 'C:\Users\villevai\Documents\WindowsPowerShell\Modules\posh-git\profile.example.ps1'

# Set up a simple prompt, adding the git prompt parts inside git repos
function global:prompt {
    $realLASTEXITCODE = $LASTEXITCODE

    # Reset color, which can be messed up by Enable-GitColors
    $Host.UI.RawUI.ForegroundColor = $GitPromptSettings.DefaultForegroundColor

    Write-Host($pwd.ProviderPath) -nonewline -foregroundcolor DarkGray

    Write-VcsStatus

    Write-Host

    $global:LASTEXITCODE = $realLASTEXITCODE
    return "$ "
}

Enable-GitColors



