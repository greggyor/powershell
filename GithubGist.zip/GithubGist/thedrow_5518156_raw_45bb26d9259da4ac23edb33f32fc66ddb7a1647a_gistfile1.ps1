cinst poshgit
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Confirm

