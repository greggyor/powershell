$Folders = get-childitem *db* -path "D:\MDB" -Recurse
foreach ($folder in $folders)
{
    $DBName = $folder.Name
    $ExchangeServer = $DBName.split("-")[0]
    $LogFolderPath = $folder.Fullname.Replace("DB","LOG")
    $edbfilepath = "$($folder.FullName)\$DBName.edb"

    if (!(get-mailboxdatabase $DBName -erroraction 0))
    {
        New-mailboxdatabase -server $ExchangeServer -name $dbname -LogFolderPath $LogFolderPath 
    }
}

