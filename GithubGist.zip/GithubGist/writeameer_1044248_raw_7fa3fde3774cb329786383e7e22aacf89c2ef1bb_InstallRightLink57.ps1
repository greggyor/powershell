###
# This script installs RightLink on a Windows Server 2008 R2 Server Core machine

function Download-File 
{
	param (
		[parameter(Mandatory=$true)] $url
    )
	
	$fileName = $url.Split("/")[-1]
	$webClient = New-Object System.Net.WebClient
	Write-Host "Downloading: $url"
	$webClient.DownloadFile($url,$fileName)
	
}


function Install-RightLink()
{


	# Download Installer from RightScale Mirror
	$baseUrl = "http://mirror.rightscale.com/rightscale_rightlink/latest_windows/"
	$x86FileName = "Rightscale_Windows_i386_5.7.1.msi"
	$x64FileName = "Rightscale_Windows_x64_5.7.1.msi"
	
	$osArchitecture = (gwmi win32_OperatingSystem).OsArchitecture

	if ($osArchitecture -eq "32-bit")
	{
		$url = $baseUrl + $x86FileName
	}
	else
	{
		$url = $baseUrl + $x64FileName
	}
	
	Download-File -url $url
	$fileName = $url.Split("/")[-1]
	if (Test-Path(".\$fileName"))
	{
		Write-Host "RightLink Installer downloaded successfully...."
		gci ".\$fileName"
	}
	else
	{
		Write-Host "Error! Could not download installer"
	}
	
	# Run installer
	$cmd = ".\$fileName /quiet"
	Invoke-Expression $cmd
	
	# Verify Installation was successful
	$rightScaleService = gwmi win32_service -filter "Name='RightScale'"
	$rightLinkService = gwmi win32_service -filter "Name='RightLink'"
	
	if ($rightScaleService -eq $null)
	{
		Write-Error "RightScale service not installed!"
		Exit 1
	}
	elseif ($rightLinkService -eq $null)
	{
		Write-Error "RightLink service not installed!"
		Exit 1
	}
	else
	{
		Write-Host "RightLink Installed Successfully !"
	}

	
}

function Install-PrintSpooler()
{
	$cmd = "dism /Online /Enable-Feature /FeatureName:Printing-ServerCore-Role"
	Invoke-Expression $cmd
}

Install-PrintSpooler
Install-RightLink


