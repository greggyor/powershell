function Get-DatabaseProvider 
{
    [CmdletBinding()]
    param ($Provider)
    if ($provider -eq $null) 
    { 
        [Data.OleDb.OleDbFactory]::Instance 
    } 
    elseif (!($provider -is [Data.Common.DbProviderFactory])) 
    {
        if (!($provider -is [string])) 
        {
            throw "Provider must be a string or an object of $([Data.Common.DbProviderFactory]) type."
        }
        [Data.Common.DbProviderFactories]::GetFactory($provider)
    }
    else 
    {
        $provider
    }
}

function Get-DatabaseQuery
{
    [CmdletBinding()]
    param 
    (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,
        [Parameter(Mandatory = $true)]
        [string]$Query,
        [hashtable]$Parameters,
        $Provider
    )
    $provider = Get-DatabaseProvider -ea Stop $provider
    #$errorActionPreference =  [Management.Automation.ActionPreference]'Stop'
    $connection = $provider.CreateConnection()
    $connection.ConnectionString = $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    if ($parameters -ne $null) 
    {
        $parameters.GetEnumerator() | % { 
            $parameter = $command.CreateParameter();
            $parameter.ParameterName = "$($_.Name)"
            $parameter.Value = $_.Value
            $command.Parameters.Add($parameter) | Out-Null
        }
    }
    $command
}

function Get-DatabaseData 
{
    [CmdletBinding()]
    param 
    (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,
        [Parameter(Mandatory = $true)]
        [string]$Query,
        [hashtable]$Parameters,
        $Provider,
        [scriptblock]$OnConnecting        
    )

    $provider = Get-DatabaseProvider -ea Stop $provider
    $command = Get-DatabaseQuery -ea Stop $connectionString $query $parameters $provider
    $connection = $command.Connection
    if ($onConnecting)
    {
        & $onConnecting $connection
    }
    $connection.Open()
    try
    {
        $reader = $command.ExecuteReader()
        if ($reader.FieldCount -gt 0)
        {
            $ordinals = 0..($reader.FieldCount - 1)
            [string[]]$names = $ordinals | % { 
                $name = $reader.GetName($_) 
                if ($name.Length -eq 0) { "Column$($_ + 1)" } else { $name }
            }
            $e = New-Object Data.Common.DbEnumerator($reader)
            while ($e.MoveNext()) 
            { 
                $obj = New-Object psobject
                $ordinals | % {
                    Add-Member NoteProperty `
                        -InputObject $obj `
                        -Name ($names)[$_] `
                        -Value $e.Current.GetValue($_) }
                $obj
            }
            if ($reader.NextResult()) 
            { 
                Write-Warning 'Query had additional result sets but this does not return them.' 
            }
        }
    }
    finally
    {
        if ($reader -ne $null) { $reader.Close() }
        $connection.Close()
    }
}

function Invoke-DatabaseQuery 
{
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
    param 
    (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,
        [Parameter(Mandatory = $true)]
        [string]$Query,
        [hashtable]$Parameters,
        $Provider
    )
        
    $provider = Get-DatabaseProvider -ea Stop $provider
    #$errorActionPreference =  [Management.Automation.ActionPreference]'Stop'
    $command = Get-DatabaseQuery -ea Stop $connectionString $query $parameters $provider
    if ($pscmdlet.ShouldProcess($query)) 
    {
        $connection = $command.Connection
        $connection.Open()
        try 
        {
            $command.ExecuteNonQuery()
        } 
        finally 
        {
            $connection.Close()
        }
    }
}

function Get-SqlData 
{
    [CmdletBinding()]
    param 
    (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,
        [Parameter(Mandatory = $true)]
        [string]$Query,
        [hashtable]$Parameters,
        [switch]$SqlVerbose
    )

    Get-DatabaseData -ea Stop `
        $connectionString $query $parameters `
        ([Data.SqlClient.SqlClientFactory]::Instance) `
        -OnConnecting $(if ($sqlVerbose) {
        { 
            param($conn)
            $conn.add_InfoMessage({
                param($sender, $e) 
                Write-Verbose $e.Message
            })
        }}
         else { $null })
}

function Invoke-SqlQuery
{
    [CmdletBinding()]
    param 
    (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,
        [Parameter(Mandatory = $true)]
        [string]$Query,
        [hashtable]$Parameters
    )

    Invoke-DatabaseQuery -ea Stop `
        $connectionString $query $parameters `
        ([Data.SqlClient.SqlClientFactory]::Instance)
}
