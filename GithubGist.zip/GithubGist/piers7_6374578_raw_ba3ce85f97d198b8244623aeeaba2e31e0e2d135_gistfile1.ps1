<#
.Synopsis
Adds/sets environment variables on the local machine for common build dependencies
#>
$ErrorActionPreference = 'stop';
$programFiles32 = $env:ProgramFiles
if (Test-Path environment::"ProgramFiles(x86)") { $programFiles32 = (gi "Env:ProgramFiles(x86)").Value };

# Accumulate the variables that we will be creating
$environmentVars = @{}

# Sniff PowerShell versions
foreach($version in (dir 'REGISTRY::\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PowerShell' | 
    Select-Object -ExpandProperty:PSChildName |
    ? { $_ -match '^[\d\.]+$'}
)){
    $environmentVars["PowerShellV$version"] = $true;
}

# Sniff things based on paths
# (registry keys, file system, anything really)
# 'Property' is optional
$pathChecks = @(
    @{
        # Sniff out local SQL versions installed
        Name = 'SqlSMO';
        Path = 'REGISTRY::\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\SharedManagementObjects\CurrentVersion';
        Property = 'Version';
    }
    ,@{
        Name = 'Ssis2012Runtime';
        Path = 'REGISTRY::\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\110\SSIS\Setup\DTSPath';
        Property = '(Default)';
    }
    ,@{
        Name = 'Sql2012Tools';
        Path = 'REGISTRY::\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\110\Tools\ClientSetup';
        Property = 'Path';
    }
    ,@{
        Path = "$programFiles32\MSBuild\Microsoft\VisualStudio\v10.0\SSDT";
        Name = 'VS2010_SsdtTargets';
    }
    ,@{
        Path = "$programFiles32\MSBuild\Microsoft\VisualStudio\v11.0\SSDT";
        Name = 'VS2012_SsdtTargets';
    }
)
foreach($check in $pathChecks){
    if(Test-Path $check.Path){
        if($check.Property){
            $value = (Get-ItemProperty -Path:$check.Path -Name:$check.Property)."$($check.Property)";
        }else{
            $value = $true;
        }
        $environmentVars[$check.Name] = $value;
    }
}


# Finally, setup environment variables to match
# These are set as system-wide, so will affect all new processed spawned
# ...and this one (this agent)
foreach($key in $environmentVars.GetEnumerator()){
    Write-Host ("Set {0}={1}" -f $key.Name,$key.Value)
    [System.Environment]::SetEnvironmentVariable($key.Name,$key.Value,'Machine')
}

