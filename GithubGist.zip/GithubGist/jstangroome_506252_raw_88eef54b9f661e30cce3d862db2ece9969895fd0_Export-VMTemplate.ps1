#requires -version 2.0

param (
    [parameter(Mandatory=$true)]
    $VM,

    [parameter(Mandatory=$true)]
    [string]
    $TemplateName,
    
    $VMMServer,
    
    [parameter(Mandatory=$true)]
    $LibraryServer,
    
    [switch]
    $PassThru
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Add-PSSnapin -Name Microsoft.SystemCenter.VirtualMachineManager -ErrorAction SilentlyContinue

if (-not $VMMServer) {
    $VMMServer = [Microsoft.SystemCenter.VirtualMachineManager.Remoting.ServerConnection]::ActiveConnection
} elseif ($VMMServer -is [string]) {
        $VMMServer = Get-VMMServer -ComputerName $VMMServer
} elseif ($VMMServer -isnot [Microsoft.SystemCenter.VirtualMachineManager.Remoting.ServerConnection]) {
    throw 'VMMServer parameter must be a string or ServerConnection'
}

if ($VM -is [string]) {
    $VM = Get-VM -Name $VM
} elseif ($VM -isnot [Microsoft.SystemCenter.VirtualMachineManager.VM]) {
    throw 'VM parameter must be a string or VM'
}

if ($LibraryServer -is [string]) {
    $LibraryServer = Get-LibraryServer -ComputerName $LibraryServer
} elseif ($LibraryServer -isnot [Microsoft.SystemCenter.VirtualMachineManager.LibraryServer]) {
    throw 'LibraryServer parameter must be a string or LibraryServer'
}

# Check VM Additions are installed
if (-not $VM.HasVMAdditions) {
    throw 'VM must have VM Additions installed'
}

$Response = Read-Host -Prompt "Does the local Administrator account for $($VM.Name) have a blank password?"
if ($Response -notlike 'y*') {
    throw 'Set the local Administrator account password to blank before creating a template.'
}

$WasRunning = $VM.Status -eq 'Running'
if ($VM.Status -ne 'PowerOff') {
    Write-Host 'Shutting down VM...'
    $VM | Shutdown-VM | Out-Null
}

Write-Host 'Dismounting DVD drives...'
$VM.VirtualDVDDrives |
    Where-Object {
        $_.Connection -ne 'None'
    } |
    ForEach-Object {
        $_ | Set-VirtualDVDDrive -NoMedia | Out-Null
    }
    
$VMPath = $VM.VMHost.VMPaths | Select-Object -First 1

$SharePath = Get-LibraryShare |
    Where-Object {
        $_.LibraryServer -eq $LibraryServer
    } |
    Select -First 1 -ExpandProperty Path

Write-Host 'Cloning VM...'
$CloneVM = New-VM -VM $VM -VMHost $VM.VMHost -Name $TemplateName -Path $VMPath

Write-Host 'Creating template...'
$Template = New-Template -Name $TemplateName -VM $CloneVM -LibraryServer $LibraryServer -SharePath $SharePath

if ($WasRunning) {
    Write-Host 'Restarting VM...'
    $VM | Start-VM | Out-Null
}

if ($PassThru) {
    Write-Output $Template
}


