
# % gal -def foreach-object
# 
# CommandType     Name                               Definition
# -----------     ----                               ----------
# Alias           %                                  ForEach-Object
# Alias           foreach                            ForEach-Object

foreach ($i in 1..9) {
    foreach ($j in 1..9 ) {
      write-host ("{0:00}" -f ($i*$j)).padright(3, " ") -nonewline
    }
    write-host
}

1..9 | % {
  $i = $_; "$( 1..9 | % { "{0:000}" -f ($_*$i) } )"
}

1..9 | % {
  $i = $_; "$( 1..9 | % { ("{0:000}" -f ($_ * $i)).padleft(4, "+") })"
}


