
$arg1 = "hello1"
$arg2 = "hello2"

$p = $(start-process -filepath .\bin\debug\hello.exe -argumentlist $arg1 -nonewwindow -passthru; start-process -filepath .\bin\debug\hello.exe -argumentlist $arg2 -nonewwindow -passthru);
#$p | wait-process

[console]::TreatControlCAsInput = $true

while($true)
{
	if ( [console]::KeyAvailable )
	{
		$key = [system.console]::readkey($true)
		if(($key.modifiers -band [consolemodifiers]"control") -and ($key.key -eq "C"))
		{
			"shutting down"
			$p | % { $_.Kill() }
			break;
		}
	}
}

