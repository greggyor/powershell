gci -r | where {$_.extension -match ".html|.htm|.php|.asp"} | select FullName

