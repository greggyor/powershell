Param
(
     [String]$Path = (Get-Location)
)

# Elevate
Write-Host "Checking for elevation... " -NoNewline
$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
if (($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) -eq $false)  {
    ArgumentList = "-noprofile -noexit -file `"{0}`" -Path `"$Path`""
    If ($ValidateOnly) {$ArgumentList = $ArgumentList + " -ValidateOnly"}
    If ($SkipValidation) {$ArgumentList = $ArgumentList + " -SkipValidation $SkipValidation"}
    Write-Host "elevating"
    Start-Process powershell.exe -Verb RunAs -ArgumentList ($ArgumentList -f ($myinvocation.MyCommand.Definition))
    Exit
}



