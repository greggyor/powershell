# カレントディレクトリに移動
cd "対象ディレクトリ";

# 各ファイルに対して操作
Get-ChildItem | ForEach-Object
{
    # ファイル名を'-'で区切ってみたり
    $data = $_.Name.Split('-');

    # ファイル名が"H"で始まってたら除外したり
    if($data[0][0] -ne 'H')
    {
        # 新しいファイル名を並び替えで作ったり
        $newname = $data[1] + "-" + $data[0] + "-" + $data[2];

        # pdfじゃなかったら末尾に"-abs.pdf"を追加したりして
        if(!($newname.EndsWith(".pdf")))
        {
            $newname += "-abs.pdf";
        }

        # ファイル名を変更
        Rename-Item $_ -newName $newname;
    }
}