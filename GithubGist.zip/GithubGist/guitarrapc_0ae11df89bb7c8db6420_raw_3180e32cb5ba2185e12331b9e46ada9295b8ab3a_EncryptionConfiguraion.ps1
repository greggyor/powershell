$configuraionData = @{
    AllNodes = 
    @(
        @{
            NodeName = "*"
            PSDscAllowPlainTextPassword = $false
            CertificateFile = "c:\test.cer"
            Thumbprint = (ls Cert:\LocalMachine\My | where Subject -eq "CN=test").Thumbprint
        },
        @{
            NodeName = "localhost"
            Role = "test"
        }
    )
}

Configuration Encryption
{
    param
    (
        [PSCredential]$Credential = (Get-Credential)
    )

    Node $AllNodes.Where{$_.Role -eq "test"}.NodeName
    {
        User Encryption
        {
            UserName = $Credential.UserName
            Password = $Credential
            Ensure = "Present"
        }

        LocalConfigurationManager
        {
            CertificateId =  $AllNodes.ThumbPrint
        }
    }
}

