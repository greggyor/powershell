# Url da Web em que sua página se encontra
$web = Get-SPWeb("http://awesomesharepointsite/web") 
# Url da página que você deseja alterar o Page Layout
$file = $web.GetFile("http://awesomesharepointsite/web/pages/pagename.aspx") 
# Check-out na página
$file.CheckOut("Online", $null) 
# Atualização do Page Layout passando a URL relativa do page layout desejado plus o título deste page layout
$file.Properties["PublishingPageLayout"] = "/_catalogs/masterpage/page_layout_file.aspx, page_layout_title"
# Update + CheckIn
$file.Update() 
$file.CheckIn("Changing PageLayout", [Microsoft.SharePoint.SPCheckinType]::MajorCheckIn)
$web.Dispose()

