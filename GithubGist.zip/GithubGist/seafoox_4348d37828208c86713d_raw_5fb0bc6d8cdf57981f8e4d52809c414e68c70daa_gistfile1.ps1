# Open terminal and type
defaults write com.google.Chrome.plist AppleEnableSwipeNavigateWithScrolls -bool FALSE

# For mavericks
defaults write com.google.Chrome AppleEnableSwipeNavigateWithScrolls -bool FALSE

