Write-Host "MassFlash – Version 1.0"
Write-Host "Author: SS du Plooy"
Write-Host "———————–"

If($args.Length -eq 0)
{
  $DirectoryToCopy = "c:DefaultFromCopyLocation"
}
Else
{
  $DirectoryToCopy = $args[0]
}

Write-Host "Preparing flash disks with files from" $DirectoryToCopy
$drives = Get-WmiObject Win32_LogicalDisk -filter "DriveType=2"

Foreach($drive in $drives)
{
  [int] $driveSize = $drive.Size/1073741824 #convert to gigabytes

  If($driveSize -ge 1 -and $driveSize -le 64)
  {
    $driveLetter = $drive.DeviceID
    $volume = Get-WmiObject -Class Win32_Volume -Filter "DriveLetter = ‘$driveLetter’"
    $label = "MF"+$(get-date -f ssfff)

    Write-Host Formatting drive $driveLetter [$label] [$driveSize GB]
    $volume.Format("FAT32", $true, 4096, $label, $false)
    Write-Host "Copying $DirectoryToCopy to $driveLetter"
    Copy-Item $DirectoryToCopy $driveLetter -recurse
    Write-Host Dismounting drive $driveLetter
    $volume.Dismount($true, $false)
  }
}
Write-Host "Done."

