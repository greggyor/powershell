# You can add this line in your profile instead of here... Set-PSBreakpoint -Variable BreakOnException -Mode ReadWriteWrite-Host "Enter"# then just add this where you want to enable breaking on exceptionstrap { $BreakOnException; continue }Write-Host "Starting"throw "stones"Write-Host "Ending"

