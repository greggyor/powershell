cls
# Define variables
$AGNodes = "azsedb001","azsedb002" # SQL AAG VMs in SEVNET
$ServiceName = "azsedb" # SQL VMs Cloud Service in SEVNET
$EndpointName = "SQLAAG" # name of the endpoint
$EndpointPort = "1433" # public port to use for the endpoint

# Configure a load balanced endpoint for each node in $AGNodes, with direct server return enabled
ForEach ($node in $AGNodes)
{
    Get-AzureVM -ServiceName $ServiceName -Name $node | Add-AzureEndpoint -Name $EndpointName -Protocol "TCP" -PublicPort $EndpointPort -LocalPort $EndpointPort -LBSetName "$EndpointName-LB" -ProbePort 59999 -ProbeProtocol "TCP" -DirectServerReturn $true | Update-AzureVM
}

# Define variables
$AGNodes = "azusdb001" # SQL AAG VMs in USVNET
$ServiceName = "azusdb" # SQL VMs Cloud Service in USVNET


# Configure a load balanced endpoint for each node in $AGNodes, with direct server return enabled
ForEach ($node in $AGNodes)
{
    Get-AzureVM -ServiceName $ServiceName -Name $node | Add-AzureEndpoint -Name $EndpointName -Protocol "TCP" -PublicPort $EndpointPort -LocalPort $EndpointPort -LBSetName "$EndpointName-LB" -ProbePort 59999 -ProbeProtocol "TCP" -DirectServerReturn $true | Update-AzureVM
}