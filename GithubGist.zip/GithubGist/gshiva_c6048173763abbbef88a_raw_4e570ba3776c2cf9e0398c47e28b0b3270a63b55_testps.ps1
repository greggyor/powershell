cinst git
echo "Hello"

