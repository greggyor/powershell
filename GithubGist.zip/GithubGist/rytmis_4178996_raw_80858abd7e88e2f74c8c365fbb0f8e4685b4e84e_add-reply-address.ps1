$addresses = $principal.Addresses
$addresses.Add((New-MsolServicePrincipalAddresses -Address http://localhost:81))
$addresses.Add((New-MsolServicePrincipalAddresses -Address http://my-deployment-endpoint.cloudapp.net))
Set-MsolServicePrincipal -AppPrincipalId 3dc125e6-d518-40d2-9392-87a03dac8f68 -Addresses $addresses

