Add-Type -AssemblyName "Microsoft.TeamFoundation.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, processorArchitecture=MSIL"
Add-Type -AssemblyName "Microsoft.TeamFoundation.Build.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a, processorArchitecture=MSIL"
$tfsUri = New-object Uri("[[http://your.tfs.server:8080/defaultcollection]]")
$teamProjectCollection = [Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory]::GetTeamProjectCollection($tfsUri)
$service = $teamProjectCollection.GetService([Type]"Microsoft.TeamFoundation.Build.Client.IBuildServer")
$spec = $service.CreateBuildDetailSpec("[[Your Project Name]]", "[[ Your build definition name]]")

$spec.MaxBuildsPerDefinition = 1
$spec.QueryOrder = [Microsoft.TeamFoundation.Build.Client.BuildQueryOrder]::FinishTimeDescending
$spec.Status = [Microsoft.TeamFoundation.Build.Client.BuildStatus]::Succeeded

$results = $service.QueryBuilds($spec)

if ($results.Builds.Length -eq 1) { $results.Builds[0].DropLocation } else { Write-Error "No builds found." }