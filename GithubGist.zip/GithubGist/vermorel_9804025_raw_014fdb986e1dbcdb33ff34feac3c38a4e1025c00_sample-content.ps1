# Sample-Content
# By Joannes Vermorel, 2014
# Keep only 1 line out of N of a flat file
# Usage: sample-content .\myfile.csv 100

function Sample-Content()
{
  param
  (
    [string]$path = $null,
    [int]$ratio = 100
  );
  
  $path = (get-item $path).FullName;
  $outpath = $path + ".sample";
  $count = -1; # preserve the first line to keep the headers (if any)
  $r = [IO.File]::OpenText($path)
  while ($r.Peek() -ge 0)
  {
    $line = $r.ReadLine();
  	$count = $count + 1;
	if(($count % $ratio) -eq 0)
	{
	  $line | out-file $outpath -Append;
	}
  }
  $r.Dispose();
}

