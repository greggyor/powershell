//Navigate to directory where files need to be renamed are 

Dir | Rename-Item –NewName { $_.name –replace “ “,”_” }