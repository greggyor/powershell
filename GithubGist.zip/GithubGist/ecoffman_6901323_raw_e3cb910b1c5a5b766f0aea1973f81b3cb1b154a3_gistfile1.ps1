param([string]$spSiteUrl)

$spSite = Get-SPSite -Identity $spSiteUrl
if($SPSite -eq $null)
{
    Write-Host "`nSPSite at '$($spSiteUrl)' is null.";
    return;
}

$siteRootWeb = $spSite.RootWeb

foreach ($spWeb in $SPSite.AllWebs)
{
    if ($siteRootWeb.Url -eq $spWeb.Url)
    {
        continue # Ignore site root!
    }
    Write-Host $spWeb.Url;
}

$spSite.Dispose();


