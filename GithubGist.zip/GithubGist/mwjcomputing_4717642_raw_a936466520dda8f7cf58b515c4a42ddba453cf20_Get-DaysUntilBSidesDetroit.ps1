function Get-DaysUntilBSidesDetroit {
  Write-Host "There are $((New-Timespan -end '6/7/2013 9:00:00AM').Days) days until BSidesDetroit."
}

