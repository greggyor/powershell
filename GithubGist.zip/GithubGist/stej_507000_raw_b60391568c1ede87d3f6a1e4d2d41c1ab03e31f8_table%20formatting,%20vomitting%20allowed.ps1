      if ( $psc -eq $null )            { $psc = $pscmdlet }   ; if (-not $PSBoundParameters.psc) {$PSBoundParameters.add("psc",$psc)}
      if ( $image.count -gt 1       )  { [Void]$PSBoundParameters.Remove("Image") ;  $image | ForEach-object {Save-Image -Image $_ @PSBoundParameters }  ; return}
      if ($filename -is [scriptblock]) {$fname = Invoke-Expression $(".{$filename}") }
      else                             {$fname = $filename } 
      if (test-path $fname)            {if     ($noclobber) {write-warning "$fName exists and WILL NOT be overwritten"; if ($passthru) {$image} ; Return }
                                        elseIF ($pscmdlet.shouldProcess($FName,"Delete file")) {Remove-Item  -Path $fname -Force -Confirm:$false }
                                        else   {Return}
      }  
      if ((Test-Path -Path $Fname -IsValid) -and ($pscmdlet.shouldProcess($FName,"Write image")))  { $image.SaveFile($FName) }
      if ($passthru) {$image} 

