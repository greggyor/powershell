$skypePath = (Get-ItemProperty -Path hkcu:\SOFTWARE\Skype\Phone).SkypePath

if (!(Test-Path $skypePath -pathType leaf)) {
  Write-Host "Unable to find Skype for Desktop. Is it installed correctly?"
  pause
  exit 1
}

$dataPath = "$($env:localappdata)\SkypePortable"
$instanceCount = 2

for ($i = 1; $i -le $instanceCount; $i++) {
        $instanceData = "$($dataPath)\Skype.$($i)"
        if (!(Test-Path $instanceData -pathType container)) {
                Write-Host "Creating: $instanceData"
                New-Item $instanceData -force -itemtype directory
        }

  Write-Host "Running Skype instance $i. Data directory: $instanceData"
        & $skypePath /datapath:"$($instanceData)" /removable /secondary
        sleep 5
}

$null


