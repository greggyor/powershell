$ipath = "C:\PATH_TO_THUMBNAILS"

$images = gci -Path $ipath

$jpgBytes = $null

foreach ($image in $images) {
    $jpgBytes = $null

    $jpgBytes = [byte[]]$jpg = Get-Content ($image.fullName) -encoding byte

    set-aduser -id $image.BaseName -replace @{thumbnailPhoto = $jpgBytes}
}

