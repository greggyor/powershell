################################################################################
# Run Files Last Accessed After Date
Get-ChildItem C:\Input |
  Select-Object FullName, LastAccessTime |
  Where-Object {$_.LastAccessTime -g "01/01/2013"}
  %{.\SuperAwesomize.exe $_.FullName}
  
################################################################################
# Get full path of last file accessed item in directory
# ? is short for Where-Object
Get-ChildItem C:\Input |
  Sort-Object $_.LastAccessTime -Descending |
  ? { $_.psiscontainer -ne $true } |
  Select-Object -First 1 -ExpandProperty FullName

################################################################################
# Get whether the last command was a success
# If it was not, write the last error
if ($? -ne $true){
  Write-Error $Error[0]
}


################################################################################
# Help Block
<#
.SYNOPSIS
Short description

.DESCRIPTION
Long description

.PARAMETER LogName
Parameter description

.EXAMPLE
.\ExampleCommand.ps1

Description
-----------
Example command description

.LINK 
http://blachniet.com
#>

################################################################################
# Determine installed version of PowerShell
$psversiontable
$psversiontable.psversion

################################################################################
# Install all NuGet packages referenced in solution
# Execute this from the solution dir (default if using Package Manager Console)
Get-ChildItem -Path *\packages.config | % { nuget install $_.FullName -OutputDirectory packages }

################################################################################
# Copy some dlls to a subdir and remove the dot-separated version from them.
Get-Item *.dll |
% { Copy-Item -Path $_.FullName -Destination (Join-Path nover ($_.Name -replace "\.\d+\.\d+\.\d+\.\d+", ""))}

