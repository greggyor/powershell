Function Invoke-SubversionScript {
    <#
    .Synopsis
    Runs a script directly from Subversion.
    
    .Description
    Given a valid Subversion URL and credentials (Basic authentication) invokes the script on the local machine.
    
    .Parameter Url
    The URL of the script. Should be a valid URL, and end in PS1

    .Parameter Username
    The username used to access Subversion (Basic authentication).
    
    .Parameter Password
    The password for the account used to access Subversion (Basic authentication).
    
    .Example
    Runs the script at the specified URL.
    
    Invoke-SubversionScript -Url "http://subversion/svn/repository/folder/SCOM2012Functions.ps1" -Username "Domain\Username" -Password "Password1"
    
    .Notes
    Ben Neise 18/11/2013
    
    #>
	Param (
        [ValidateScript({$_ -Match '^(?:http)(?:s)?(?:://)(?:www\.)?(?:[^\ ]*).ps1$'})]
        [Parameter(Mandatory=$true,Position=0)]
        [String]
		$Url,

        [Parameter(Mandatory=$false,Position=1)]
        [String]
        $Username = "",
        
        [Parameter(Mandatory=$false,Position=2)]
        [String]
        $Password = ""
	)
    Process {
        $strAuthentication = 'Basic ' + [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Username + ":" + $Password ))
        $objWebClient = New-Object System.Net.WebClient
        $objWebClient.Headers.Add("Content-Type", "application/xml")
        $objWebClient.Headers.Add("Accept", "application/xml")
        $objWebClient.Headers.Add("Authorization", $strAuthentication )
        Try {
            $strCommand = $objWebClient.DownloadString($Url)
        }
        Catch {
            Write-Error -Message "Can't read URL"
            Exit
        }
    }
    End {
        Invoke-Expression -Command $strCommand
    }
}

