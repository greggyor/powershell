# http://boxstarter.org/package/url?

# Boxstarter options
$Boxstarter.RebootOk=$true # Allow reboots?
$Boxstarter.NoPassword=$false # Is this a machine with no login password?
$Boxstarter.AutoLogin=$true # Save my password securely and auto-login after a reboot

#####################
# BEGIN CONFIGURATION
#####################
 
#region Initial Windows Config
 
 	Install-WindowsUpdate -AcceptEula
 	Update-ExecutionPolicy Unrestricted

 	Enable-RemoteDesktop
 	Enable-MicrosoftUpdate
    Set-WindowsExplorerOptions -EnableShowHiddenFilesFoldersDrives -EnableShowFileExtensions
    Disable-InternetExplorerESC
     
#endregion
 
# Let's get the latest version of powershell, .net frameworks, etc.
cinst binroot
cinst PowerShell
cinst ChocolateyGUI
cinst DotNet3.5
cinst DotNet4.0
cinst DotNet4.5
cinst DotNet4.5.1
cinst mono

