$ head eng.examples
! It's his pet theory.
"'And next?' I cried, and would have turned on, but the cool hand of the grave woman delayed me.
"'I've made a great sacrifice,' I told the whip as I got in.
"'Next?' I insisted, and struggled gently with her hand, pulling up her fingers with all my childish strength, and as she yielded and the page came over she bent down upon me like a shadow and kissed my brow.
"A boy is a creature of odd feelings.
"A divo'ce," repeated Ransie, with a solemn nod.
"A man killed."
"A man less brave would have changed his plans about the camp-bed at once and said, "For you, my dear man, of course--why not?" Constantine chattered nervously as he took his seat in the car next to his host, the driver.
"A million times more--a million times more," thought Constantine hysterically, but with an effort he said nothing.

$ cat eng.examples | sed -e 's/ /\n/g' | head
!
It's
his
pet
theory.
"'And
next?'
I
cried,
and
$ cat eng.examples | sed -e 's/ /\n/g' | sort | head
€100
€20
\1,000,000,
\1,000,000.
\10,
\10,
\10,
\10,
\10,000
\10,000
$ cat eng.examples | sed -e 's/ /\n/g' | sort | uniq -c | head
      1 €100
      1 €20
      1 \1,000,000,
      1 \1,000,000.
      4 \10,
      3 \10,000
      1 \10,000,000
      1 \10,000,000.
      1 \100,
      1 \100,000-a-month
$ cat eng.examples | sed -e 's/ /\n/g' | sort | uniq -c | sort -rn | head
 335954 the
 243861 to
 230664 a
 214451 I
 167194 you
 129626 of
 109477 is
 105941 in
  84601 for
  84549 and

