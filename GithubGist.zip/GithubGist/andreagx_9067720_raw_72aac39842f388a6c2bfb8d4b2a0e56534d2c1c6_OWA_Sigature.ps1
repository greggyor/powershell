# OWA Signature import by Andrea Gallazzi www.andreagallazzi.com

#var old is text to remove
$old = 'src=".+?_file/image001.gif"'

#var $new = the text you want to replace
$new = 'src="http://www.mypublicwebsite.com/image001.gif"'

#change the Get-ChildItem to a folder or your choice
Get-ChildItem C:\Signatures\*.htm  | Where {$_ -IS [IO.FileInfo]} |
 
% {
 
(Get-Content $_.FullName) -replace $old, $new | Set-Content $_.FullName
 Write-Host "----- WORKING   ----------"
 Write-Host "Processed: " + $_.FullName
 
}
 #REMOVE DONE

 # Import OWA Signatures in EMS
 
$mailboxes = Get-Mailbox
$mailboxes| foreach {$file= "C:\Signatures\" + ($_.alias) + ".htm"; Set-MailboxMessageConfiguration -identity $_.alias -AutoAddSignature $True -SignatureHtml "$(Get-Content -Path $file -ReadCount 0)"} 
