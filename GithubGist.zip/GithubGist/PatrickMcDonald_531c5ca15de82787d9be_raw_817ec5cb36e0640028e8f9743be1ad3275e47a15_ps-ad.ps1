Import-Module ActiveDirectory

# List members of a group
Get-ADGroupMember "Domain Admins" -recursive | Select-Object name

# list group memberships for user
Get-ADPrincipalGroupMembership "username" | Select-Object name


