import-module SSIS
$ssis_package = "D:\MyFile.dtsx";
$package = Get-ISPackage -path $ssis_package;
$package.Executables | Where-Object { $_.InnerObject -like 'Microsoft.SqlServer.Dts.Tasks.ExecuteSQLTask.ExecuteSQLTask' }  | %{ $fn = $_.Name+".sql"; $_.InnerObject.SqlStatementSource > $fn }

