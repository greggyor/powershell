# 現在のユーザー名とホスト名をタイトルに
$global:currentuser = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$user_and_host = ($currentuser.name -replace "(.*?)\\(.*?)$", "`$2@`$1")
$Host.UI.RawUI.WindowTitle = $user_and_host + " - Windows PowerShell"

# プロンプトのカスタマイズ
function prompt {
  write-host ""

  # ディレクトリの表示 (バックスラッシュをスラッシュに変換)
  $pwd = $(get-location) -replace "\\", "/"
  write-host $pwd -nonewline -foregroundcolor yellow
  write-host " " -nonewline

  # Gitリポジトリがあった場合
  if (Test-Path .git) {
    $branch = $(get_git_branch_name)
    # ブランチ名の表示を右寄せする
    $oldposition = $host.ui.rawui.CursorPosition
    $Endline = $oldposition
    # 一行の行数からブラケットとブランチ名の長さを引く
    $Endline.X = 120 - 2 - $branch.Length
    $host.ui.rawui.CursorPosition = $Endline

    if ($(get_git_status) -eq 1) {
      write-host ("[" + $branch + "]") -nonewline -foregroundcolor white -backgroundcolor red
    } else {
      write-host ("[" + $branch + "]") -nonewline -foregroundcolor red
    }

    $host.ui.rawui.CursorPosition = $oldposition
  }

  write-host ""
  return "$ "
}

# Git: ブランチ名を取得
function get_git_branch_name () {
  $name = ""

  git branch | foreach {
    if ($_ -match "^\*(.*)"){
      $name += ($matches[1] -replace "^ ", "")
    }
  }

  return $name
}

# Git: 更新があるかどうかを取得
function get_git_status () {
  $status = 1

  git st | foreach {
    if ($_ -match "^nothing to commit \(") {
      $status = 0
    }
  }

  return $status
}


