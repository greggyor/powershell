function Get-VMWareResourceStatus {
	<#
		.SYNOPSIS
			Get resource status from VMWare vSphere

		.DESCRIPTION
			Get overall status, configuration status and any configuration issues on VMWare resources by querying vSphere.

		.EXAMPLE
			Get-VMWareResourceStatus -VIServer 'VIServer01' -ResourceType 'VirtualMachine'
			Get the resource status of all virtual machines from 'VIServer01'

		.EXAMPLE
			Get-VMWareResourceStatus -VIServer 'VIServer01','VIServer02' -Name 'ESXHost01' -ResourceType 'HostSystem'
			Get the resource status of ESX host 'ESXHost01' by querying VIServer01 and VIServer02

		.EXAMPLE
			Get-VMWareResourceStatus -VIServer 'VIServer01' -Name 'Server01','Server02' -ResourceType 'VirtualMachine'
			Get resource status for Server01 and Server02 from VIServer01

		.NOTES
			Author: Øyvind Kallstad
			Date: 15.10.2014
			Version: 1.0
	#>
	[CmdletBinding()]
	param (
		# vSphere server(s) to connect to
	 	[Parameter(Mandatory = $true)]
	 	[string[]] $VIServer,

	 	# Name(s) used to filter the result
	 	[Parameter()]
	 	[string[]] $Name,

	 	# ResourceType to search for
	 	[Parameter(Mandatory = $true)]
	 	[ValidateSet('ClusterComputeResource','ComputeResource','Datacenter','Datastore','DistributedVirtualPortgroup','DistributedVirtualSwitch','Folder','HostSystem','Network','ResourcePool','StoragePod','VirtualApp','VirtualMachine','VmwareDistributedVirtualSwitch')]
	 	[string] $ResourceType
	)

	try {
		# Check if VMWare snapin is loaded, and load it if it's not
		if ((Get-PSSnapin -Name 'VMWare.VimAutomation.Core' -ErrorAction 'SilentlyContinue') -eq $null) {
			Add-PSSnapin -Name 'VMWare.VimAutomation.Core'
			Write-Verbose 'VMWare.VimAutomation.Core snapin loaded'
		}

		# Connect to VIserver(s)
		Connect-VIServer -Server $VIServer -WarningAction 'SilentlyContinue' | Out-Null
		Write-Verbose 'Connected to VIServer(s)'

		if ($PSBoundParameters['Name']) {
			# if more than one name is given, generate correct regex for the filtering
			if ($Name.Length -gt 1) {
				$regexString = ($Name | ForEach-Object {"($($_)`$)"}) -Join '|'
				Get-View -ViewType $ResourceType -Property Name,OverallStatus,ConfigStatus,ConfigIssue -Filter @{"Name"=$regexString} | Select-Object Name,OverallStatus,ConfigStatus,ConfigIssue
			}
			# if only one name is given, the filter is easier
			else {
				Get-View -ViewType $ResourceType -Property Name,OverallStatus,ConfigStatus,ConfigIssue -Filter @{"Name"="$($Name)`$"} | Select-Object Name,OverallStatus,ConfigStatus,ConfigIssue
			}
			Write-Verbose 'Got data from vSphere'
		}

		# if the name parameter is not used, no filtering is done
		else {
			Get-View -ViewType $ResourceType -Property Name,OverallStatus,ConfigStatus,ConfigIssue | Select-Object Name,OverallStatus,ConfigStatus,ConfigIssue
			Write-Verbose 'Got data from vSphere'
		}

	}
	catch {
		Write-Warning $_.Exception.Message
	}
}

