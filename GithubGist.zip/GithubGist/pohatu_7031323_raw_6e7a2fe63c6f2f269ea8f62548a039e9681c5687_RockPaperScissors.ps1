# A simple Rock, Paper Scissors Game in Powershell by pohatu
# Uses very cool Select-Item function by James O'Neill
# Presented here: http://blogs.technet.com/b/jamesone/archive/2009/06/24/how-to-get-user-input-more-nicely-in-powershell.aspx
#
# Also uses a clever trick to make remainder act like modulo for negative numbers presented by StackOverflow user polygenelubricants
# here: http://stackoverflow.com/questions/3417183/modulo-of-negative-numbers/3417598#3417598
# You can see the difference between columns labeled Excel:(b-a)%3 and PS:(b-a)%3 column
#
#
# p1   		p2			    a-b	xls:a-b%3 result PS:(b-a)%3
# rock		0	rock		0	0	0	      draw   0
# rock		0	paper		1	-1	2	      b      1
# rock		0	scissors	2	-2	1	      a       2
# paper		1	rock		0	1	1	      a      -1
# paper		1	paper		1	0	0	      draw   0
# paper		1	scissors	2	-1	2	      b      1
# scissors	2	rock		0	2	2	      b      -2
# scissors	2	paper		1	1	1	      a      -1
# scissors	2	scissors	2	0	0	      draw   0

$RPS=@{Rock=0; Paper=1; Scissors=2;}

function Get-RPSWinner($p1, $p2){
  #returns 1 if p1 wins, 2 if p2 wins, 0 if tie.
  #See table above. Hack due to remainder()<>mod().  
  return ($(((($p1-$p2)%3)+3)%3))
}

function TestGet-RPSWinner(){
#Draw
  $(Get-RPSWinner $RPS.Rock $RPS.Rock) -eq 0
  $(Get-RPSWinner $RPS.Paper $RPS.Paper) -eq 0
  $(Get-RPSWinner $RPS.Scissors $RPS.Scissors) -eq 0
#Player 1 wins
  $(Get-RPSWinner $RPS.Paper $RPS.Rock) -eq 1
  $(Get-RPSWinner $RPS.Scissors $RPS.Paper) -eq 1
  $(Get-RPSWinner $RPS.Rock $RPS.Scissors) -eq 1
#Player 2 wins
  $(Get-RPSWinner $RPS.Rock $RPS.Paper) -eq 2
  $(Get-RPSWinner $RPS.Paper $RPS.Scissors) -eq 2
  $(Get-RPSWinner $RPS.Scissors $RPS.Rock) -eq 2
}

##
## Select-Item (C) James O'Neill
## http://blogs.technet.com/b/jamesone/archive/2009/06/24/how-to-get-user-input-more-nicely-in-powershell.aspx
##
Function Select-Item 
{    
<# 
     .Synopsis
        Allows the user to select simple items, returns a number to indicate the selected item. 

    .Description 

        Produces a list on the screen with a caption followed by a message, the options are then
        displayed one after the other, and the user can one. 
  
        Note that help text is not supported in this version. 

    .Example 

        PS> select-item -Caption "Configuring RemoteDesktop" -Message "Do you want to: " -choice "&Disable Remote Desktop",
           "&Enable Remote Desktop","&Cancel"  -default 1
       Will display the following 
  
        Configuring RemoteDesktop   
        Do you want to:   
        [D] Disable Remote Desktop  [E] Enable Remote Desktop  [C] Cancel  [?] Help (default is "E"): 

    .Parameter Choicelist 

        An array of strings, each one is possible choice. The hot key in each choice must be prefixed with an & sign 

    .Parameter Default 

        The zero based item in the array which will be the default choice if the user hits enter. 

    .Parameter Caption 

        The First line of text displayed 

     .Parameter Message 

        The Second line of text displayed     
#> 

Param(   [String[]]$choiceList, 

         [String]$Caption="Please make a selection", 

         [String]$Message="Choices are presented below", 

         [int]$default=0 

      ) 

   $choicedesc = New-Object System.Collections.ObjectModel.Collection[System.Management.Automation.Host.ChoiceDescription] 

   $choiceList | foreach  { $choicedesc.Add((New-Object "System.Management.Automation.Host.ChoiceDescription" -ArgumentList $_))} 

   $Host.ui.PromptForChoice($caption, $message, $choicedesc, $default) 
}  


function PlayGame()
{
  do {
    #$human = Read-Host -Prompt "Rock [0], Paper[1] or Scissors[2]?"
    $human = Select-Item -Caption "Rock Paper Scissors" -Message "Choose Rock, Paper or Scissors" -choiceList "&Rock", "&Paper", "&Scissors"
    $computer = $RPS.Values | Get-Random
    write-host "You chose $($($RPS.Keys)[$human])"
    write-host "Computer chose $($($RPS.Keys)[$computer])"
    
    switch($(Get-RPSWinner $human $computer))
    {
      0 {$caption="Tie Game."; $msg = "$caption`n$($($RPS.Keys)[$computer]) ties $($($RPS.Keys)[$human]).";}
      1 {$caption="You Won.";  $msg = "$caption`n$($($RPS.Keys)[$human]) beats $($($RPS.Keys)[$computer]).";}
      2 {$caption="You Lost."; $msg = "$caption`n$($($RPS.Keys)[$computer]) beats $($($RPS.Keys)[$human]).";}
    }    
    write-host $msg
    $playAgain = Select-Item -Caption "$caption" -Message $($msg + "`nPlay Again?") -choiceList "&No", "&Yes"
  }while ($playAgain)
}

TestGet-RPSWinner
PlayGame

