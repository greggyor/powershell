$vsphere = "my-vc"
$new_user = "newbie"
$new_user_passwd = "new_sekret"
$new_user_grp = "root"

$root_user = "root"
$root_passwd = "really_sekret"

# Get all of the ESX servers (connect using Windows credentials)
connect-viserver -server $vsphere
$hosts = get-view -type hostsystem
disconnect-viserver -confirm:$false

# For each ESX server, connect and see if the new account exists.
# If it does, reset the password and ensure the account is granted shell access.
# If it doesn't, create it and add to the root group (this seems to be necessary to allow ssh login in ESX4.0)
$hosts | %{ $_.name } | %{
  echo $_
  connect-viserver -server $_ -user $root_user -password $root_passwd
  if ($?) {
    if (! (get-vmhostaccount | ?{ $_.id -eq $new_user })) {
      new-vmhostaccount -useraccount -id $new_user -password $new_user_passwd -grantshellaccess
	  set-vmhostaccount -groupaccount -id root -assignusers $new_user
    }
	else {
	  set-vmhostaccount -useraccount $new_user -password $new_user_passwd -grantshellaccess $true
	}
    
	disconnect-viserver -confirm:$false "*"
  }
}

