cd C:\Documents and Settings\Administrator
mkdir Programs
bitsadmin /transfer pythondownloadjob  /download /priority normal https://www.python.org/ftp/python/3.4.1/python-3.4.1.msi C:\Documents and Settings\Administrator\Programs\python-3.4.1.msi
cd Programs
msiexec /quiet /i python-3.4.1.msi
setx PATH "%PATH%;C:\Python34\;C:\Python34\Scripts\"
 
pip install awscli
mkdir C:\Documents and Settings\Administrator\.aws
echo [default] > C:\Documents and Settings\Administrator\.aws\config
echo "aws_access_key_id = %AWS_ACCESS_KEY_ID%" >> C:\Documents and Settings\Administrator\.aws\config
echo "aws_secret_access_key = %AWS_SECRET_ACCESS_KEY%" >> C:\Documents and Settings\Administrator\.aws\config
echo "region = us-east-1" >> C:\Documents and Settings\Administrator\.aws\config
cd C:\
notepad C:\Documents and Settings\Administrator\.aws\config
 
cd C:\Documents and Settings\Administrator
 
mkdir ITOA
aws s3 sync s3://sproutling-chime/ITOA ITOA
cd ITOA
\Documents and Settings\Administrator\Programs\unzip.exe itoa12a.zip
cmd /c itoa
 
cd C:\Documents and Settings\Administrator
mkdir -p chime\orig
mkdir chime\conv
mkdir chime\scripts
 
cd C:\Documents and Settings\Administrator\Programs
bitsadmin /transfer rubyinstallerjob  /download /priority normal http://dl.bintray.com/oneclick/rubyinstaller/rubyinstaller-1.9.3-p545.exe C:\Documents and Settings\Administrator\Programs\rubyinstaller-1.9.3-p545.exe
mkdir C:\Ruby193
.\rubyinstaller-1.9.3-p545.exe /silent /tasks="addtk,assocfiles,modpath"
setx PATH "%PATH%;C:\Ruby193\bin"
bitsadmin /transfer unzipjob  /download /priority normal http://stahlworks.com/dev/unzip.exe C:\Documents and Settings\Administrator\Programs\unzip.exe
 
aws s3 cp s3://sproutling-chime-converted/scripts/convert.rb C:\Documents and Settings\Administrator\chime\scripts\convert.rb
 
cd chime\orig
mkdir 10010
aws s3 sync s3://sproutling-chime/10010 10010
 
cd C:\Documents and Settings\Administrator
ruby chime\scripts\convert.rb
 
cd ITOA
cmd /c C:\Documents and Settings\Administrator\chime\itoacmds.bat
 
cd C:\Documents and Settings\Administrator
aws s3 sync chime\conv s3://sproutling-chime-converted