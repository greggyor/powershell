# Input params
$projectName = "TroyPSTest"

# Constants
$dbServerName = "snyb5o1pxk"
$dbServerLogin = "troyhunt"
$dbServerPassword = "P@ssw0rd"
$apiVersion = "2014-04-01"

# Computed vars
$dbName = $projectName + "Db"
$dbLogin = $dbName + "Login"

# Switch over to the resource manager
Switch-AzureMode AzureResourceManager

# Remove the tag from the website
$p = Get-AzureResource -Name $projectName -ResourceGroupName $webResourceGroup -ResourceType Microsoft.Web/sites -ApiVersion $apiVersion
Set-AzureResource -Name $projectName -ResourceGroupName $webResourceGroup -ResourceType Microsoft.Web/sites -ApiVersion $apiVersion -PropertyObject $p.Properties -Tags @{ }

# Remove the tag from the DB
Set-AzureResource -Name $dbName -ResourceGroupName $dbResourceGroup -ParentResource servers/$dbServerName -ResourceType Microsoft.Sql/servers/databases -ApiVersion $apiVersion -Tags @{ }

# Delete the tag (if you try to only delete, it may still be attached to resources even if you've already deleted THEM!)
Remove-AzureTag -Name Project -Value $projectName -Force

# Make sure we kick off in service management mode
Switch-AzureMode AzureServiceManagement

# Delete the website
Remove-AzureWebsite $projectName -Force

# Delete the database
Remove-AzureSqlDatabase -ServerName $dbServerName -DatabaseName $dbName -Force

# Delete the SQL login
Import-Module SQLPS -DisableNameChecking
$conn = New-Object System.Data.SqlClient.SqlConnection
$conn.ConnectionString = "Server=tcp:" + $dbServerName + ".database.windows.net;Database=master;User ID=" + $dbServerLogin + ";Password=" + $dbServerPassword + ";"
$srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $conn
$srv.Logins[$dbLogin].Drop()


