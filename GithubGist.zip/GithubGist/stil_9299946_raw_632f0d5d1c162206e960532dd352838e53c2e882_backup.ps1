# CONFIGURATION
$dirToBackup = "C:\Users\John" # path to directory we back up (no following backslash)
$outputDir = "E:\bak" # path directory we store our backups (no following backslash)
$params = '-t7z', '-r', '-ms=off', '-mx1'

# THE SCRIPT
$fullBackup = $outputDir + "\full.7z"

if (Test-Path  ($fullBackup)) { # Let's check whether full backup exists
  Write-Host "Full backup already exists"
  $args = ,'u' + $params
  $args += '-u-', "-up0q3r2x2y2z0w2!`"$($outputDir)\diff-$(Get-Date -format "yyyyMMdd-HHmmss").7z`""
  $args += $fullBackup, $dirToBackup
} else {
  $args = , ('a') + $params + $fullBackup + $dirToBackup
}

& 7z $args

