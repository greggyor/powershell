$header = @"
プログレスバーサンプル

"@
Write-Output $header


$loop = $true

while($loop){

	$userInput = Read-Host "[1]一本バー [2]二本バー [3] とりあえず待機 [他]終了"
	switch($userInput){
		1{
			# 一本バーサンプル
			# -PercentCompleteは、0〜100で。（うっかり0.01〜1にすると、期待通りに動作しない）
			foreach($i in (1..10)){
				Write-Progress "サンプル" -Status "なにがしか進捗中" -PercentComplete ($i * 10)
				Start-Sleep -Milliseconds 300
			}
		}
		2{
			# 二本バーサンプル
			# 二本以上の場合、IDを指定すること。でないと、バーが重なって見えなくなる。
			$outerLoop = 1
			$innerLoop = 2
			foreach($i in (0..9)){
				Write-Progress -Id $outerLoop "サンプル" -Status "進捗中" -PercentComplete ($i * 10)
				foreach($j in (1..10)){
					Write-Progress -Id $innerLoop "サンプル" -Status "詳細ステータス" -PercentComplete ($j * 10) -CurrentOperation "○○処理中"
					Start-Sleep -Milliseconds 100
				}
			}
		}
		3{
			# ステータスだけ
			# 進捗状況は割り出せないけど、待機状態をユーザに表示したい時などに
			Write-Progress "サンプル" -Status "初期化中"
			
			# なんか長い処理
			Start-Sleep -Seconds 2
			
			# -Completeを指定すると画面には表示されないけども、コード上でプログレスバーの終了を明示したい時などに
			Write-Progress "サンプル" -Status "初期化おわり" -Complete
			Start-Sleep -Seconds 1
		}
		default{
			$loop = $false
		}
	}
}

