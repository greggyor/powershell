$database_host = "<host>"
$database_name = "<database>"
$output_file = "<output_file>"
$user = "<username>"
$password = "<password>"

[system.reflection.assembly]::loadWithPartialName('Microsoft.SqlServer.SMO') 
$server = new-object "Microsoft.SqlServer.Management.Smo.Server" $database_host 
$server.connectionContext.loginSecure = $false
$server.connectionContext.set_Login($user)
$server.connectionContext.set_Password($password)

$database = $server.databases[$database_name]

$scripter = new-object "Microsoft.SqlServer.Management.Smo.Scripter" $server
$scripter.options.fileName = $output_file
$scripter.options.scriptSchema = $false
$scripter.options.scriptData = $true
$scripter.options.toFileOnly = $true

foreach ($s in $scripter.enumScript($database.tables)) { write-host $s } 