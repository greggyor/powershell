# Add Git bin directory to path for this session
$env:path += ";" + (Get-Item "Env:ProgramFiles(x86)").Value + "\Git\bin"

