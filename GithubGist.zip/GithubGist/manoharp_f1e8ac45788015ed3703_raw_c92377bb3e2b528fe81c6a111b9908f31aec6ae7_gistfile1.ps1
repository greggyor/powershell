# Set shortcut for sublime command line
Set-Alias subl 'C:\Program Files (x86)\Sublime Text 3\subl.exe'

# Launch the sublime text
subl test.py


