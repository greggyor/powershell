[cmdletbinding()]
param(
	[parameter(mandatory=$true, position=1)]
	[string]$path,
	
	[switch]$recurse,
	
	[array]$include,
	
	[array]$exclude,
	
	[string]$filter
)

if( $recurse -eq $true )
{
	$files = get-childitem	-recurse `
							  -path $path `
							  -exclude $exclude `
							  -include $include `
							  -filter $filter `
							  | where { ! $_.PSIsContainer }
}
else
{
	$files = get-childitem `
							-path $path `
							-exclude $exclude `
							-include $include `
							-filter $filter `
							| where { ! $_.PSIsContainer }
}

foreach( $file in $files )
{
	write-host $file.fullname
	$data = get-content $file.fullname
	$data | out-file -encoding utf8 -filepath $file.fullname
}


