Get-FileHash C:\tools\FileName.zip -Algorithm md5

<#
Algorithm       Hash                                                                   Path                                     
---------       ----                                                                   ----                                     
MD5             0A58C113534FAA4D531442E8A3221E7A                                       C:\tools\FileName.zip
#>

