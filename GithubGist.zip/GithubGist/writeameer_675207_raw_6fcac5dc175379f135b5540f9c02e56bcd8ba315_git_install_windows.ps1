# Set download URLs
$git_download_url = "http://msysgit.googlecode.com/files/PortableGit-1.7.3.1-preview20101002.7z"
$7zip_download_url = "http://downloads.sourceforge.net/sevenzip/7za465.zip"

# Create Software folder
$software_folder = "$env:SystemDrive\software"
mkdir -force $software_folder 

# Create temp folder
$temp_folder  = "$env:userprofile\temp\install_git"
if (test-path("$temp_folder")) {ri -r -force "$temp_folder"}
mkdir -force $temp_folder
cd $temp_folder

# Download Portable Git and 7zip required to extract portable git
$wc = new-object System.Net.WebClient
$wc.DownloadFile($git_download_url,"$temp_folder\" + $git_download_url.Split("/")[-1])
$wc.DownloadFile($7zip_download_url,"$temp_folder\" + $7zip_download_url.Split("/")[-1])

# Install 7-zip (just unzipping file to a 7zip folder)
if (test-path("$software_folder\7zip")) {ri -r -force "$software_folder\7zip"}
mkdir "$software_folder\7zip"
$shell_app=new-object -com shell.application
$zip_file = $shell_app.namespace("$temp_folder\7za465.zip")
$destination =$shell_app.namespace("$software_folder\7zip")
$destination.Copyhere($zip_file.items())

# Add 7zip to path 
[Environment]::SetEnvironmentVariable("PATH","$env:path;$software_folder\7zip","MACHINE")
$env:path = "$env:path;$software_folder\7zip" 

# Install Portable Git
$git_archive = $git_download_url.Split("/")[-1]
if (test-path("$software_folder\git")) {ri -r -force "$software_folder\git"}
mkdir -force "$software_folder\git"
& "7za" x -y "-o$software_folder\git" "$temp_folder\$git_archive"


# Add git to path and reload path
[Environment]::SetEnvironmentVariable("PATH","$env:path;$software_folder\git\bin","MACHINE")
$env:path = "$env:path;$software_folder\git\bin" 

# Remove temp folder
cd c:\
ri -r -force "$temp_folder"

# Display git help
cls
git help


