<# 
    Remove log source from Application Event Log - requires ADMIN PRIVILEGES

    Peter Tyrrell
#>


param(
    [Parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0)]
    [string]$logsrc
)

# check for admin
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Warning ("You do not have admin privileges. Re-run this script as an administrator.")
    break
}

try {
    [System.Diagnostics.EventLog]::DeleteEventSource($logsrc)
    Write-Host ("INFO Deleted '{0}'' from Application Event Log." -f $logsrc)
}
catch {
    Write-Host ("INFO The source '{0}' is not registered on the machine." -f $logsrc)
}


