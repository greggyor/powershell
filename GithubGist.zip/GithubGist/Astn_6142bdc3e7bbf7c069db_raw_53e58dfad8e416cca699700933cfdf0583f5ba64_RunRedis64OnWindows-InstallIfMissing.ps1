function elevateme {
    # Get the ID and security principal of the current user account
    $myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
  
    # Get the security principal for the Administrator role
    $adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
  
    # Check to see if we are currently running "as Administrator"
    if ($myWindowsPrincipal.IsInRole($adminRole))
    {
    # We are running "as Administrator" - so change the title and background color to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
    $Host.UI.RawUI.BackgroundColor = "DarkBlue"
    clear-host
    }
    else
    {
    # We are not running "as Administrator" - so relaunch as administrator
    
    # Create a new process object that starts PowerShell
    $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
    
    # Specify the current script path and name as a parameter
    $newProcess.Arguments = $myInvocation.MyCommand.Definition;
    
    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";
    
    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);
    
    # Exit from the current, unelevated, process
    exit
    }
}

function restart {
    # Create a new process object that starts PowerShell
    $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
    
    # Specify the current script path and name as a parameter
    $newProcess.Arguments = $myInvocation.MyCommand.Definition;
    
    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);
    
    # Exit from the current, unelevated, process
    exit
}

function get-Choco-IfMissing {
    if ($env:ChocolateyInstall -ne $null){
        Write-Host "Found Chocolatey" -ForegroundColor Green
        return
    }

    Write-Host "Checking for Chocolatey"
    $needChoco = $false
    try {
        $version = choco version
    } catch [System.Exception] {
        $needChoco = $true
        Write-Host "Chocolatey missing..."
    }

    if ($version -eq $null -or $version.Count -eq 0) {
        $needChoco = $true
    }

    if ($needChoco -eq $true) {
        Write-Host "Checking execution policy"
        $currentPolicy = Get-ExecutionPolicy
        if ($currentPolicy -ne "RemoteSigned"){
    
            Write-Warning "Execution Policy set too low, currently: $currentPolicy"
            Write-Warning "Attempting to change it to: RemoteSigned"
            # need to elevate permissions to change execution policy
            elevateme                

            # end of elevation code
            Set-ExecutionPolicy RemoteSigned
            Write-Host "installing chocolatey"
            iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
        } else {
            Write-Host "installing chocolatey"
            iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
        }
        restart
    }
}

function get-Redis-IfMissing {
    $fastFind = $false
    pushd "$env:ChocolateyInstall\lib\"
        if ( (ls -filter redis-64* | measure).count -gt 0){
            $fastFind = $true
        }            
    popd

    if ($fastFind -eq $true){
        Write-Host "Found redis-64" -ForegroundColor Green
        return
    }

    Write-Host "Detecting redis-64"
    $localRedis = (choco list redis-64 -lo)

    Write-Host $localRedis

    if (($localRedis | %{ $_.ToString() } | ? { $_ -match "^redis-64\b"} | measure).count -eq 0) {
        Write-Host "Installing redis-64"
        cinst redis-64 
    } else {
        Write-Host "Found redis-64"
    }
}

get-Choco-IfMissing

get-Redis-IfMissing

$chocoLib = "$env:ChocolateyInstall\lib\"
pushd $chocoLib
$redisDir = (ls -filter redis*)[0].Name
popd

Write-Host "Redis install at: $($env:ChocolateyInstall)\lib\$($redisDir)" -ForegroundColor Green
Write-Host "Launching redis-64 ..." -ForegroundColor DarkYellow
Start-Process "$($env:ChocolateyInstall)\lib\$($redisDir)\redis-server.exe"
Write-Host "Launching redis-cli ..." -ForegroundColor DarkYellow
Start-Process "$($env:ChocolateyInstall)\lib\$($redisDir)\redis-cli.exe"
