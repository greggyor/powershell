Param (
    [parameter(
        Position = 0,
        Mandatory = $true,
        HelpMessage = 'This is the version number, such as "22.0".  Valid version numbers can be found here: http://mzl.la/1c9hPmo'
    )]
    [string] $version,
    [parameter(
        Position = 1,
        Mandatory = $false,
        HelpMessage = 'This is language string, such as "en-US".  Valid language strings can be found here: http://mzl.la/1c9n7OJ'
    )]
    [string] $language
)

Write-Debug "VERS: $version"
Write-Debug "TEMP: $env:Temp"

$ini_file = @"
[Install]
QuickLaunchShortcut=false
DesktopShortcut=false
MaintenanceService=false
"@
Write-Debug "INI: $ini_file"

Write-Debug "LANG: $language"
if (-not $language) {
    Write-Debug "Language NOT supplied ..."
    $lang_pattern = '^[^(]+\(([^)]+)\)'
    try {
        Write-Debug "Detecting Language x64 ..."
        $language = [regex]::Replace((Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Mozilla\Mozilla Firefox" -ErrorAction Stop).CurrentVersion, $lang_pattern, '$1', 'IgnoreCase')
    } catch {
        try {
            Write-Debug "Detecting Language x86 ..."
            $language = [regex]::Replace((Get-ItemProperty "HKLM:\SOFTWARE\Mozilla\Mozilla Firefox" -ErrorAction Stop).CurrentVersion, $lang_pattern, '$1', 'IgnoreCase')
        } catch {
            Write-Debug "Language NOT detectable, using default ..."
            $language = "en-US"
        }
    }
}
Write-Debug "LANG: $language"

$url = "http://ftp.mozilla.org/pub/mozilla.org/firefox/releases/${version}/win32/${language}/Firefox Setup ${version}.exe"
Write-Debug "URL: $url"
$webclient = New-Object System.Net.WebClient

Write-Debug "Downloading ..."
try {
    $webclient.DownloadFile($url, "${env:Temp}\Firefox Setup ${version}.exe")
} catch {
    Throw("Download of Firefox setup exe file failed.  Check your version number and try again.`nValid version numbers can be found here: http://mzl.la/1c9hPmo`n ")
}

Write-Debug "Creating .ini file ..."
$ini_file | Out-File -Encoding ASCII -FilePath "${env:Temp}\FirefoxSetup${version}.ini"

Write-Debug "Installing ..."
$proc = Start-Process "${env:Temp}\Firefox Setup ${version}.exe" -ArgumentList "/INI=""${env:Temp}\FirefoxSetup${version}.ini""" -Wait -PassThru

Write-Debug ("Done:{0}!" -f $proc.ExitCode)
Exit $proc.ExitCode

