[CmdletBinding()] 
param (
    [parameter(Mandatory=$true)][string]$adminuser,
    [parameter(Mandatory=$true)][string]$adminpassword
)
 
$computer = gc env:computername
 
# did you enter valid credentials for a local user? 
[Reflection.Assembly]::LoadFile('C:\Windows\assembly\GAC_MSIL\System.DirectoryServices\2.0.0.0__b03f5f7f11d50a3a\System.DirectoryServices.dll')
Add-Type -assemblyname system.DirectoryServices.accountmanagement 
$DS = New-Object System.DirectoryServices.AccountManagement.PrincipalContext([System.DirectoryServices.AccountManagement.ContextType]::Machine)
 
if ($DS.ValidateCredentials($adminuser, $adminpassword)) {
    # yay!
} else {
    # boo!
}

