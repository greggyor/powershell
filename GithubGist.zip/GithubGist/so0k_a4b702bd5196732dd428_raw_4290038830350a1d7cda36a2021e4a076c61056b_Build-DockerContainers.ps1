Param(
    [switch]$keepalive
)

#region script config
    $dockerhost = "localdocker"
    $User = "docker"
    $PWord = (new-object System.Security.SecureString) #this is how you define blank password
    $keyfile = "C:\Path\To\keys"
#endregion

function isAlive($hostName){
    Test-Connection -ComputerName $hostName -Count 1 -Quiet
}

#ensure $dockerhost is alive
if (!(isAlive $dockerhost))
{
    #try to get the ip & update the hosts file
    start cmd -ArgumentList @('/C','Set-localdocker.bat')
}

if (isAlive $dockerhost)
{
    #region sync data to docker host
    #make sure project directory exists remotely
    $RemoteProjectDirectory = "\\$dockerhost\data\{0}" -f (Get-Item $PSScriptRoot).BaseName
    $result = New-Item -Path ($remoteProjectDirectory)  -Type Directory -Force 

    Write-Host -ForegroundColor Green "Syncing data.. By default files are copied only if"
    Write-Host -ForegroundColor Green "   * the source and destination have different time stamps or "
    Write-Host -ForegroundColor Green "   * the source and destination have different file sizes"
    Write-Host -ForegroundColor Green "(ignoring .git .idea .grunt)"
    Write-Host -ForegroundColor Green "$PSScriptRoot TO $remoteProjectDirectory\"
    #sync the data between this directory and remote directory, ignore powershell scripts *.ps1 
    robocopy $PSScriptRoot $remoteProjectDirectory /MIR /COPY:DAT /E /NFL /NDL /NS /NC /NJH /R:3 /W:3 /XD .git .idea .grunt /XF *.ps1 *.sublime*
    #endregion

    #region ensure ssh connection works
    $index = -1 #init index to -1
    $sessions = @(Get-SSHSession | ? {$_.Host -eq $dockerhost })
    if($sessions.Count -lt 1){
        #open session without prompting user
        $Credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $User, $PWord
    
        $session = New-SSHSession -ComputerName $dockerhost -KeyFile $keyfile -Credential $Credential        
        if($session.Connected){
            Write-Host -ForegroundColor Green ("Connected to {0}" -f $session.Host)
            $index = $session.Index
        }else{
            Write-Host  -ForegroundColor Red "Unable to open SSH session"
            $index = -1
        }
    }else{
        Write-Host -ForegroundColor Green ("Re-using connection to {0}" -f $sessions[0].Host)
        $index = $sessions[0].Index
    }
    #endregion

    #region run ssh commands
    if($index -gt -1){
        $bin = "/var/lib/boot2docker/data/{0}" -f (Get-Item $PSScriptRoot).BaseName
        #stop containers
        Write-Host -ForegroundColor Green "Stopping Containers..."
        Write-Host -ForegroundColor Cyan (Invoke-SSHCommand -Index $index -Command "cd $bin;. gm-env.sh stop").Output

        #build containers
        Write-Host -ForegroundColor Green "Building Containers..."
        Write-Host -ForegroundColor Cyan (Invoke-SSHCommand -Index $index -Command "cd $bin;. build_containers.sh").Output

        #remove orphaned containers - sometimes you will still need to manually clean containers when a build fails
        Write-Host -ForegroundColor Green "Cleaning up..."
        Write-Host -ForegroundColor Cyan (Invoke-SSHCommand -Index $index -Command "docker images --no-trunc| grep none | awk '{print $3}' | xargs -r docker rmi").Output

        #start containers
        Write-Host -ForegroundColor Green "Starting Containers..."
        Write-Host -ForegroundColor Cyan (Invoke-SSHCommand -Index $index -Command "cd $bin;. gm-env.sh start").Output

        if( -Not $keepalive) {
            #clean up session
            $removed = Remove-SSHSession -Index $index
        }

        Write-Host -ForegroundColor Green "Done."
    }
    #endregion

}else {
    Write-Host -ForegroundColor Red "Could not find $dockerhost"
}

