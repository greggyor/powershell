echo "Downlading.."

$file = ""
$client = new-object System.Net.WebClient

for($i = 1; $i -le 797; $i++)
{
	
	if ($i -lt 10) { $file = "000$($i)" }
	elseif (($i / 10) -lt 10) { $file = "00$($i)" }
	elseif (($i / 100) -lt 100) { $file = "0$($i)" }

	Try {
		$client.DownloadFile("http://www.dragonball-multiverse.com/es/pages/final/$($file).jpg", "C:\Users\mdumrauf\Desktop\dbz-multiverse\$($file).jpg")
		echo "INFO :: File $($file) download completed"
	}
	Catch
	{
		[System.Net.WebException]
		echo "WARN :: File $($file) is not a jpg! Downloading png instead.."

		Try {
			$client.DownloadFile("http://www.dragonball-multiverse.com/es/pages/final/$($file).png", "C:\Users\mdumrauf\Desktop\dbz-multiverse\$($file).png")
			echo "INFO :: File $($file) download completed"
		}
		Catch
		{
			[System.Net.WebException]
			echo "ERROR :: File $($file) is not a valid image! Ignoring."
		}
	}
}

