$dirs = Get-ChildItem -Path .\* | ?{ $_.PSIsContainer }
$currentDir = Get-Location

# dir env:ProgramFiles`(x86`)
# dir "env:ProgramFiles(x86)"
# ${Env:ProgramFiles(x86)}
# [Environment]::GetEnvironmentVariable("ProgramFiles(x86)")

# & ${Env:WinDir}\notepad.exe
# Invoke-Item ${Env:WinDir}\notepad.exe

foreach ($dir in $dirs)
{
    Set-Location $dir.FullName
    Write-Host $dir.FullName
    &"${Env:ProgramFiles(x86)}\Git\bin\git.exe" pull origin
    &"${Env:ProgramFiles(x86)}\Git\bin\git.exe" fetch --all
    &"${Env:ProgramFiles(x86)}\Git\bin\git.exe" reset --hard origin
}

Set-Location $currentDir.Path


