fuga | %{$_} # Now you'll see Intellisence work when you type $_. 

