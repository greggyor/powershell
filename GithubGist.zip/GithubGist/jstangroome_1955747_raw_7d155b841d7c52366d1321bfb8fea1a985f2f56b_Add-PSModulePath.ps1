[CmdletBinding()]
param (
    [string]
    $Path
)

if (-not $Path -and $MyInvocation.ScriptName) {
    $Path = Join-Path -Path ($MyInvocation.ScriptName | Split-Path) -ChildPath Modules
}

if (-not $Path -or -not (Test-Path -Path $Path -PathType Container)) {
    throw "$($MyInvocation.MyCommand): Path required."
}

$Path = (Resolve-Path -Path $Path).ProviderPath

$ExistingPaths = $Env:PSModulePath -split ';' -replace '\\$',''
if ($ExistingPaths -notcontains $Path) {
    $Env:PSModulePath = $Path + ';' + $Env:PSModulePath
    Write-Verbose "$($MyInvocation.MyCommand): Prepended to PSModulePath: $Path"
}

