$MyFilter = New-WmiEventFilter –Name WatchFolderRoboCopy –Query 'SELECT * FROM __InstanceCreationEvent WITHIN 10 WHERE TargetInstance ISA "CIM_DirectoryContainsFile" AND TargetInstance.GroupComponent = "Win32_Directory.Name=\"c:\\\\FileHistory\""' –EventNamespace "root\cimv2"
$MyConsumer = New-WmiEventConsumer –ConsumerType CommandLine –Name WatchFolderRoboCopy –CommandLineTemplate "c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe -ExecutionPolicy Bypass -<<<ParameterName1>>> %TargetInstance.<<<WmiPropertyName>>>%"
New-WmiFilterToConsumerBinding –Filter $MyFilter –Consumer $MyConsumer

