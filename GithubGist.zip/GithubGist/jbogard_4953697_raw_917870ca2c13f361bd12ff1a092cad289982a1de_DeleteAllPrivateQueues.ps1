[Reflection.Assembly]::LoadWithPartialName("System.Messaging")
[System.Messaging.MessageQueue]::GetPrivateQueuesByMachine("localhost") | % { [System.Messaging.MessageQueue]::Delete($_.Path) } 

