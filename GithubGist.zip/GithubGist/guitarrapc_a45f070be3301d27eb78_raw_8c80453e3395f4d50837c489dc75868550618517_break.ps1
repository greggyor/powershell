1..3 | %{
    $_
    break
    $_
}
 
<#
1
#>
 
foreach ($x in (1..3))
{
    $x
    break
    $x
}
 
<#
1
#>

