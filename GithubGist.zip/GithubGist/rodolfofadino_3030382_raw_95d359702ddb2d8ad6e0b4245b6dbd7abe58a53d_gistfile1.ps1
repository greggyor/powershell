Add-Type -Path "C:\Program Files (x86)\AWS SDK for .NET\bin\AWSSDK.dll"


$instancias = New-Object System.Collections.Generic.List[System.Collections.Hashtable]

$instancias.Add(@{"maquina" = "i-xxxxx"; "ip" = ""; endpoint= "https://ec2.sa-east-1.amazonaws.com/"})
##$instancias.Add(@{"maquina" = "i-xxxxx"; "ip" = "111.111.1.11"; endpoint= "https://ec2.sa-east-1.amazonaws.com/"})
##$instancias.Add(@{"maquina" = "i-xxxxx"; "ip" = "111.111.1.11"; endpoint= "https://ec2.sa-east-1.amazonaws.com/"})
##$instancias.Add(@{"maquina" = "i-xxxxx"; "ip" = "111.111.1.11"; endpoint= "https://ec2.sa-east-1.amazonaws.com/"})

$secretKeyID="Secret key"
$secretAccessKeyID="Access key"

##Urls de endpoint
##US East (Northern Virginia) Region	ec2.us-east-1.amazonaws.com	HTTP and HTTPS
##US West (Oregon) Region	ec2.us-west-2.amazonaws.com	HTTP and HTTPS
##US West (Northern California) Region	ec2.us-west-1.amazonaws.com	HTTP and HTTPS
##EU (Ireland) Region	ec2.eu-west-1.amazonaws.com	HTTP and HTTPS
##Asia Pacific (Singapore) Region	ec2.ap-southeast-1.amazonaws.com	HTTP and HTTPS
##Asia Pacific (Tokyo) Region	ec2.ap-northeast-1.amazonaws.com	HTTP and HTTPS
##South America (Sao Paulo) Region	ec2.sa-east-1.amazonaws.com	HTTP and HTTPS


foreach ($item in $instancias)
{
    $config = New-Object Amazon.EC2.AmazonEC2Config
    $config.WithServiceURL($item.endpoint)
    $client = [Amazon.AWSClientFactory]::CreateAmazonEC2Client($secretAccessKeyID,$secretKeyID,$config)

    $request = New-Object Amazon.EC2.Model.StopInstancesRequest
    $request.WithInstanceId($item.maquina)

    $client.StopInstances($request)
}

