$TSEKey="SYSTEM\ControlSet001\Control\Terminal Server\WinStations\RDP-Tcp"
get-XAserver | %{ 
  $reg=[microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine',$_.ServerName)
  $copy = $_
  $reg.OpenSubKey($TSEKey).getValueNames() |? { $_ -like 'fDisable*'}  |% {
		  $copy | Add-member -Type NoteProperty -Name $_ -Value $reg.OpenSubKey($TSEKey).getValue($_)
	}
	$copy
} | select ServerName, fDisable* 

