$packageName = '{PACKAGE_NAME}'
$url = 'http://SITE.COM/FILE.ZIP'
$subFolderFilter = '*SUBFOLDER*'

try {
    $rootDir = Join-Path "$env:systemdrive\" $packageName

    if (Test-Path "$rootDir") {
        Write-Host "Removing existing files, keeping config-files"
    
        Remove-Item "$rootDir\*" -Recurse -force -exclude *.config
    }

    Install-ChocolateyZipPackage "$packageName" "$url" "$rootDir"

    $subFolder = Join-Path $rootDir (Get-ChildItem $rootDir $subFolderFilter | ?{ $_.PSIsContainer })

    Write-Host "Moving items from subfolder"

    Get-ChildItem $subFolder -Recurse | ?{$_.PSIsContainer } | Move-Item -Destination $rootDir
    Get-ChildItem $subFolder | ?{$_.PSIsContainer -eq $false } | Move-Item -Destination $rootDir

    Remove-Item "$subFolder"
    
    Write-ChocolateySuccess "$packageName"
} catch {
    Write-ChocolateyFailure "$packageName" "$($_.Exception.Message)"
    throw
}

