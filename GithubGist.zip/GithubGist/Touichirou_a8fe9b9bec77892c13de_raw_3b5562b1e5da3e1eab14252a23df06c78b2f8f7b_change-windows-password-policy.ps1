# Export LocalSecurityPolicy.cfg
& SecEdit.exe /export /cfg .\LocalSecurityPolicy.cfg
Get-Item -Path ".\LocalSecurityPolicy.cfg"
& notepad.exe .\LocalSecurityPolicy.cfg

# Import LocalSecurityPolicy.cfg after changing
& SecEdit.exe /configure /db .\LocalSecurityPolicy.db /cfg .\LocalSecurityPolicy.cfg
Get-Item -Path ".\LocalSecurityPolicy.db"

