Function Get-CountDownTime([int]$seconds){ 

for ($time=$seconds;$time -ge 0;$time--){ 
$min = [math]::floor([int]$time/[int]60) 
$sec = $time % 60 

if ($sec -lt 10){
$sec = "0$sec"
} 

[string]"$min`:$sec" 

Start-Sleep -Seconds 1 

Clear-Host 
} 
}# Get-CountDownTime 関数の終わり 

# *** スクリプトのエントリ ポイント *** 
 get-CountDownTime 1800
 
[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

[System.Windows.Forms.MessageBox]::Show("時間です！休憩してください。");



