try
{
    $key = 'HKLM:\SOFTWARE\Microsoft\Microsoft SDKs\ServiceHosting'
    $registryProperty = Get-ChildItem $key -ErrorAction Stop | Sort CreationTime -Descending | Select -First 1 | Get-ItemProperty -ErrorAction Stop
    $fullVersion = ($registryProperty | Select FullVersion).FullVersion
    $installPath = ($registryProperty | Select InstallPath).InstallPath

    if ($fullVersion -lt "2.2.0000.0") { throw }
    $ref1 = "${installPath}ref\Microsoft.WindowsAzure.Storage.dll"
    $ref2 = "${installPath}ref\Microsoft.WindowsAzure.StorageClient.dll"
    if (-not(Test-Path $ref1) -or -not(Test-Path $ref2)) { throw }
}
catch
{
    throw "Windows Azure Storage SDK wasn't found. Please check you have installed the dependencies."
}

