# Pull from PWNAGERobotics/PWNAGE
git fetch upstream

# Checkout user master
git checkout master

# Merge PWNAGERobotics/PWNAGE:master into local user/PWNAGE:master
git merge upstream/master

# Push to user/PWNAGE:master origin
git push


