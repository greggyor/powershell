#
# Script: fix-phone.ps1
#
# Purpose: Reformat phone numbers in .txt files from XXX-XXX-XXXX to
#          (XXX) XXX-XXXX.
#
# Written by Steven Klassen, sklassen@gmail.com
#
#############################################################################

# define the pattern
$rxPhone = New-Object System.Text.RegularExpressions.Regex "(?<Prefix>\d+)-(?<Number>\d+-\d+)"

# run through the txt files
Get-Item "*.txt" | ForEach-Object {
    # read in the contents of the original file
    $text = [System.IO.File]::ReadAllText($_.FullName)
    
    # do the replacement
    $text = $rxPhone.Replace($text, "(`${Prefix}) `${Number}")
    
    # write it back out to a new file
    $outputFile = [System.IO.File]::CreateText($_.BaseName + ".fixed.txt")
    $outputFile.Write($text)
    
    $outputFile.Close()
}

