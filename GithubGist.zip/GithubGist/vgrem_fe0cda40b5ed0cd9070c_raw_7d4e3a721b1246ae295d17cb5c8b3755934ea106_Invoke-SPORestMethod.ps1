.\Get-SPOAccessToken.ps1

<#
.Synopsis
    Sends an HTTP or HTTPS request to a SharePoint Online REST-compliant web service.
.DESCRIPTION
    This function sends an HTTP or HTTPS request to a Representational State
    Transfer (REST)-compliant ("RESTful") SharePoint Online web service.
.EXAMPLE
   Invoke-SPORestMethod -Uri "https://contoso.sharepoint.com/_api/web" -AccessToken $accessToken
#>
Function Invoke-SPORestMethod()
{
Param(
  [Uri]$Uri,
  [Object]$Body,
  [Hashtable]$Headers,
  [Microsoft.PowerShell.Commands.WebRequestMethod]$Method = [Microsoft.PowerShell.Commands.WebRequestMethod]::Get,
  [string]$AccessToken
)
    $contentType = 'application/json;odata=verbose'
    if(-not $Headers) {
       $Headers = @{}    
    }
    $Headers["Accept"] = "application/json;odata=verbose"
    $Headers.Add('Authorization','Bearer ' + $AccessToken)
    Invoke-RestMethod -Method $Method -Uri $Uri -ContentType $contentType -Headers $Headers -Body $Body 
}


