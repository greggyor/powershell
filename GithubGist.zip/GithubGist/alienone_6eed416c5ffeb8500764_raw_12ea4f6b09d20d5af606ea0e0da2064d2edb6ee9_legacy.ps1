<#
.SYNOPSIS

This script is utilized to append JMX remote management parameters 
to an ArcSight Smart Connector's agent.properties file

Function: Append Parameters
Author: Justin Jessup
Contributions: Bob Fialla - utilize literal Regex, utilize counter $remote_port 
Email: Justin@alienonesecurity.com
Required Dependencies: Run script as Administrator
Optional Dependencies: None
Version: 0.5

.DESCRIPTION

- Ensure script is being executed by the Administrator user
- Find any remote.management artifacts within agent.properties file and zero out the lines
- Leveraging process table determine $PATH/S to ArcSight Smart Connector - return array of $paths
- We now know the $PATHS to the agent.properties files for any smart connector installed on the system
- Ensure a unique TCP port 9001 +1 - if more than one smart connector - each smart connector will have unique management port
- We can now append the remaining remote management parameters 
- Conduct a clean stop, then a clean start of the smart connector/s on the system 

.EXAMPLE

remote.management.enabled=true
remote.management.listener.host=simcone05.jello.com
remote.management.listener.port=9002
remote.management.user=jello
remote.management.password=lemon_jello
remote.management.ssl.organizational.unit=UkY20YBABCAAdL0V69WOw

.NOTES

RETURN CODES
--

FunctionName: TestUserPermissions
--
Return Code 10 => TestUserPermissions -> Test verified script is excuting as the Administrator user
Return Code 11 => TestUserPermissions -> Test failed - script is not being executed as the Administrator user

FunctionName: FindReplaceLine
--
Return Code 20 => FindReplaceLine -> Any 'remote.management' parameters within the ArcSight Smart Connector agent.properties file have been removed

FunctionName: AppendRemote
--
Return Code 30 => AppendRemote -> 'remote.management' parameters added to the ArcSight Smart Connector/s agent.properties/'s file/s
Return Code 31 => AppendRemote -> 'agent.properties' file does not exist at PATH: continuing 

FunctionName: StopStart
--
Return Code 0 => StopStart -> Conducted clean stop of the ArcSight Windows Service 
Return Code 0 => StopStart -> Conducted clean start of the ArcSight Windows Service 
Return Code 40 => Stopping Service Failed
Return Code 50 => Starting Service Failed
Return Code 98 => First Global Failure
Return Code 99 => Global Failure

.LINK

GITHUB: https://gist.github.com/alienone/7883f311c26c57f0de17

#>


Function LogWrite($logstring){
    $hostname = $env:computername
    $LogPath = "C:\Windows\Temp\"
    $logfilename = $hostname + "-powershell-arcsight-remote.txt"
    $Logfile = $LogPath + $logfilename
    $timestamp = $((get-date).ToString("yyyy:MM:dd:T:hh:mm:ss:CDT"))
    Add-content $Logfile -value ($timestamp + " " + $logstring)
}


Function TestUserPermissions{
    $currentUser = [Environment]::UserName
    If ($currentUser -eq "Administrator") {
        $return_code_one = @"
        Return Code 0 => TestUserPermissions -> Test 
        verified script is excuting as the Administrator user
"@
        LogWrite $return_code_one
        return 0
    }Else{
        $return_code_two = @"
        Run this script as the Administrator user
        Return Code 11 => TestUserPermissions -> Test 
        failed - script is not being executed as the Administrator user
"@
        LogWrite $return_code_two
        return 11
        Break
    }
}


Function FindReplaceLine{
    $paths = (gwmi win32_service|?{$_.name -like "*arc_*"}).pathname
    foreach ($path in $paths) {
        $str_array = $path.split('"')[1]
        $pos = $str_array.IndexOf("\bin")
        $arc_home_path = $str_array.SubString(0, $pos)
        $agent_properties = $arc_home_path + "\user\agent\agent.properties"
        (Get-Content $agent_properties) | Foreach-Object{$_ -replace '^remote.+', ""} `
                                        | Add-Content $agent_properties
        (Select-String -Pattern "\w" -Path $agent_properties) | ForEach-Object { $_.line } `
                                                              | Set-Content -Path $agent_properties 
        $return_code = @"
        Return Code 0 => FindReplaceLine -> Any 'remote.management' 
        parameters within the ArcSight Smart Connector 
        agent.properties file have been removed
"@
        LogWrite $return_code
        return 0
      }
}


Function AppendRemote($remote_param_array){
    $remote_port = 9002
    $paths = (gwmi win32_service|?{$_.name -like "*arc_*"}).pathname
    foreach ($path in $paths) {
        $str_array = $path.split('"')[1]
        $pos = $str_array.IndexOf("\bin")
        $arc_home_path = $str_array.SubString(0, $pos)
        $agent_properties = $arc_home_path + "\user\agent\agent.properties"
        If (Test-Path $agent_properties) {
            Add-Content -Path $agent_properties -Value "`r`nremote.management.listener.port=$remote_port"
            $remote_port++
            foreach ($param in $remote_param_array) {Add-Content -Path $agent_properties -Value "`n$param"}
        }Else{
            LogWrite "31"
            LogWrite "Smart Connector Path $agent_properties"
            $return_code_one = @"
            Return Code 31 => AppendRemote -> 'agent.properties' file does 
            not exist at PATH
"@
            LogWrite "`t`t`t" + $agent_properties 
            LogWrite $return_code_one
            LogWrite "continuing ...."
            continue
         }
    $return_code_two = @"
    Return Code 0 => AppendRemote -> 'remote.management' parameters added 
    to the ArcSight Smart Connector/s agent.properties/'s file/s
"@
    LogWrite $return_code_two
    return 0
     }
 }


Function StopStart{
     $service_hash = Get-Service | Where-Object {$_.name -like '*arc_*'}
     $service_array = $service_hash.Name
     foreach($service in $service_array) {
         If (Stop-Service $service -PassThru){
             "0"
             LogWrite "Return Code 0 => StopStart -> Conducted clean stop of the ArcSight Windows Service"
         }Else{
            "40"
            "98"
             LogWrite "Return Code 40 => Stopping Service Failed"
             LogWrite "Return Code 98 => First Global Failure" 
             }
         If (Start-Service $service -PassThru) {
             "0"
             LogWrite "Return Code 0 => StopStart -> Conducted clean start of the ArcSight Windows Service"
         }Else{
             "50"
             "99"
             LogWrite "Return Code 50 => Starting Service Failed" 
             LogWrite "Return Code 99 => Global Failure" 
             }
    }
}


Function MainFunction{
    $remote_param_array = ("remote.management.enabled=true", `
                           "remote.management.listener.host=SIMCONC05.target.com", `
                           "remote.management.user=lemon", `
                           "remote.management.password.hashed=OBFUSCATE.4.8.1:P2pyGopvrRzq2l9Loi8jlw==", `
                           "remote.management.ssl.enabled=true")
    #TestUserPermissions
    FindReplaceLine
    AppendRemote $remote_param_array
    StopStart
}


MainFunction