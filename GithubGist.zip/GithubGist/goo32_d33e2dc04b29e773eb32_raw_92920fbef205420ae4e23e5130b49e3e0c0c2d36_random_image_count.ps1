ls | ?{ $_.PSIsContainer } | Get-Random | gci -filter *.jpg -recurse | Measure-Object


