# Script that traverses a directory and strips all content from files larger than 
# $filesizelimit This comes handy when we need to transfer a backuped directory 
# structure to our local environment. We are normally not interested in the content 
# of the files when debugging.

# Version 0.1, 
# By Erik Billerby, billerby[-at-]acando.com

# Location where 7-Zip is installed on your computer.
# The default is in a folder, '7-Zip' in your Program Files directory.

# The backup archive name needs to be on the following format for this script to 
# operate correctly backup_[YYYY-MM-DD].zip
# To run script: start cmd.exe with administrator privileges: 

# prompt> powershell.exe
# prompt> .\strip-content-from-alf-data-dir.ps1

# To begin with, enter the date for the backup you want to process below:
# TODO - parameterize
$backupdate="2012-10-13"

# Only strip files larger than the limit stated below:
$filesizelimit=25KB

# Alias for 7-zip
if (-not (test-path "$env:ProgramFiles\7-Zip\7z.exe")) {throw "$env:ProgramFiles\7-Zip\7z.exe needed"}
set-alias sz "$env:ProgramFiles\7-Zip\7z.exe"

# Path to the directory that contain the backups
$backupdir="C:\Alfresco\backups"

# Path to directory to store the stripped version
$strippeddir="C:\Alfresco-stripped-backups"

# copy the backup file to a new temporary directory
echo $backupdir"\backup_"$backupdate".zip"
Copy-Item $backupdir"\backup_"$backupdate".zip" $strippeddir

"Uncompressing backup file"
$outputOption = "-o$strippeddir/backup_$backupdate"
sz x  $strippeddir\"backup_"$backupdate".zip" $outputOption

$dirtostrip = "$strippeddir\backup_$backupdate\$backupdate\alf_data\contentstore"

$files=((dir $dirtostrip -recurse)  |?{$_.psiscontainer -eq $false})
"stripping content from files larger than $filesizelimit"
# feedback, number of trunkaded files
$matches = 0;
$totalfiles = 0;
for ($i=0;$i -ne $files.count; $i++) 
{
	if ($files[$i] -eq $null) {continue}
	if ($files[$i].length -gt $filesizelimit) {
		Clear-Content $files[$i].FullName
		$matches++;
	}
    $totalfiles++;  
}

"$matches files of total $totalfiles have had their content stripped..."

sz a $strippeddir\stripped-$backupdate.zip $strippeddir\backup_$backupdate\$backupdate


