################################################
#              Map  shares                     #
# Author: H.L.                                 #
# Version: 0.3                                 #
# Description: map shares to the system        #
################################################

#############################what's new
#--v0.3--
#- Mount fix, while described multiple shares
#- Possibility to skip asking credentials
#--v0.2--
#- fix small error's in code
#- fix values moved to system settings
#- if credentials was not set script will ask for that using password form
#- template for domain like accounts
#--v0.1--
#- Basic functionality
#- Try to mount drive 3 times(fixed)
#- timeout to mount operation, max 8 sec, fixed
#- password can be set inside script only
########################################
 
#vars--system settings
[int]$global:_mnt_max_trys = 3;
[int]$global:_mnt_min_waittime= 8;
[bool]$global:_mnt_increase_waittime= $False;
[int]$global:_mnt_increase_step= 3;
#--vars-global
$global:version="v0.3";
$global:_share="";  #!!! type here ip address of host
$global:_domain="";   #used only in case of blank username and password
#!!credentials - leave blank to show "ask user name" every time before launch
$global:_usepass=$False;
$global:_user="";
$global:_pass="";

$global:_drives=( 
            ("O:","SomeShare")   #!!!!describe here list of shares
        );
 
#functions

function startApp([string]$name,[string]$prms,[int]$wait){
    $si=new-object System.Diagnostics.ProcessStartInfo;
    $si.UseShellExecute = $False;
    $si.RedirectStandardError=$True;
    $si.RedirectStandardOutput=$True;
    $si.FileName = $name;
    $si.Arguments = $prms;

    try{
      $process=[System.Diagnostics.Process]::Start($si);
      $spend_time=0;
      while ( $spend_time -lt ($wait*1000)){
       if ($process.HasExited -eq $True) {
           if ($process.ExitCode -gt 0){
             return $False;
           } else {
             return $True;                    
          }
         }         
        Start-Sleep -m 200;
        $spend_time+=200;         
       }              
       $process.Kill;
        #workaround =(
        Stop-Process $process.Id;
        return $False;
    } catch {
        return $False;
    }
}

function callMounter($event, [int]$wtime, [string]$mntpoint="",[string]$share=""){
  switch ($event){
   "mount"{
     if ($global:_usepass -eq $True){
      return (startApp "net.exe" "use $mntpoint \\$global:_share\$share $global:_pass /USER:$global:_user /persistent:no" $wtime);
	 } else {
	  return (startApp "net.exe" "use $mntpoint \\$global:_share\$share /persistent:no" $wtime);
	 }
   }
   "unmount"{
    return (startApp "net.exe" "use /delete $mntpoint" $wtime);
   }
  
  }
 return $False;
}


function unmountDrive([string]$drive){
 #return startApp "net.exe" "use /delete $drive" 3;
 return callMounter "unmount" 3 $drive;
}
 
function mountDrive{
              Param([string]$share,[string]$mntpoint,[int]$tTry) ;
  $waittime=$global:_mnt_min_waittime;
  $canExit=0;
  $curr_pos=$host.ui.rawui.CursorPosition;
  #unmount previous drive
  Write-Host "Try to unmount $mntpoint..." -noNewLine;
  unmountDrive $mntpoint; 
  $host.ui.rawui.CursorPosition=$curr_pos;
  Write-Host "                                       " -noNewLine;
  $host.ui.rawui.CursorPosition=$curr_pos;
   
  #try to mount new drive
  Write-Host "Mounting $share at $mntpoint...." -noNewLine;  
  $curr_pos=$host.ui.rawui.CursorPosition;
  while ($canExit -lt $tTry){          
       # if ( (startApp "net.exe" "use $mntpoint \\$global:_share\$share $global:_pass /USER:$global:_user /persistent:no" $waittime) -eq $True){
       if ( (callMounter "mount" $waittime $mntpoint $share) -eq $True){
             if ($canExit -gt 0){
              Write-Host "] " -noNewLine;
             }
             Write-Host "ok";
             $canExit=$tTry;
             return $True;
         } else {
             if ($canExit -eq 0){ # first time showed
               Write-Host "[" -noNewLine;
              }
             Write-Host "." -noNewLine;
             if ($canExit -eq ($tTry-1)){
               Write-Host "] fail";
             }  
         } 
         
        #wait time handling
        if ($global:_mnt_increase_waittime -eq $True){
           $waittime+=$global:_mnt_increase_step;
        }
         $canExit++;                   
    }
 return $False;
} 
#===========================================main()
Write-Host "Network Share mounter $global:version" -foregroundcolor Cyan;
if ($global:_user -eq "" -and $global:_pass -eq "" -and $global:_usepass -eq $True){
 Write-Host "Username and Password is required....";
 try{
     $credential= Get-Credential "";
     $global:_user=$credential.GetNetworkCredential().username;
     $global:_pass=$credential.GetNetworkCredential().password;
     if ($global:_domain -ne ""){
        $global:_user=$global:_domain+"\"+$global:_user;
     }
 } catch {
   Write-Host "Login is invalid or operation canceled." -foregroundcolor "Red";
   Start-Sleep -s 2;
   exit;
 }
}

if ($global:_drives[0].GetType().BaseType.Name -ne "Array"){  #array contain only one element
  mountDrive $global:_drives[1] $global:_drives[0] $global:_mnt_max_trys|out-null; 
} else {
    foreach ( $map in $global:_drives ) { 
       mountDrive $map[1] $map[0] $global:_mnt_max_trys|out-null; 
    }
}
exit; 
#======conditions
#-eq	Equal to
#-lt	Less than
#-gt	Greater than
#-ge	Greater than or Eqaul to
#-le	Less than or equal to
#-ne	Not equal to

#====logic operators
# -not	Not
# !	    Not
# -and	And
# -or	Or 

