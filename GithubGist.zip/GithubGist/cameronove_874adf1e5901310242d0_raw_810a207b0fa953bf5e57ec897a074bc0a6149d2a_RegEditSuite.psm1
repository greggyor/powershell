<# 
    2010 Scripting Games PowerShell: Advanced Event 1
    Author:  Cameron Ove
    Date:  4/30/2010
    Copyright:  NONE :-D
    
    Synopsis of functions:
        I really wanted to the ability to provide credentials when contacting remote workstations.
        .Net seems limited in that regard.  So I used WMI.
        In paticular I used the root\default namespace and StdRegProv thus enabing the ability for credentials across the network.
        
        There is quite a number of functions here but the one that will probably be judged is the Set-RegValue.  However, there
        are a lot of supporting functions here in this suit.  For example you could use the Get-RegValue function to create
        a report of all workstations on your network if a reg key and value exists.  I broke out setting, testing, removing, and getting
        reg keys.
        
        So now you have a whole suit of functions to do your registry work either locally, a workstation on your network, a list of workstations
        across your network.
        
        Each function will work on it's own and each function can accept computer names from a file:
        
        Example:
        PS>Get-Content .\networkcomputers.txt | 
            foreach{Get-RegValue -hive HKLM -path software\ScriptingGuys\2010ScriptingGames -ComputerName $_ -Credential $admin}
            
        That will connect to each computer in the file and report the existance of a value in the registry.  You could us Get-ADComputer
        and pipe the names of computers in AD to the function as well.
        
        
        Have fun!
#>


#This function provides a mechanism for the user to confirm a change.
function Get-Answer([string]$Header,[string]$Question){
    $yes= ([System.Management.Automation.Host.ChoiceDescription]"&yes")
    $no= ([System.Management.Automation.Host.ChoiceDescription]"&no")
    $selection = [System.Management.Automation.Host.ChoiceDescription[]]($yes,$no)
    return $host.ui.PromptForChoice($Header,$Question,$selection,1)
}

#Most of the function need the WMI StdRegProv object so I broke out its creation in a seperate function
#It returns the object as well as error info if unable to create the object.
function Get-RegProvider{
<#
.Synopsis
    Used by by several functions to get a wmi registry provider object to work with keys and values.
.Description
    This function uses WMI root\defauult namespace and the StdRegProv class.  I wanted to use WMI in order
    to maintain the ability to use credentials when attaching to workstations over the network.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Get-RegProvider
    
    ----------------------
    Returns a registry object of the registry on the localhost.
.Example
    PS>Get-RegProvider wrkstation1 $admincreds
    
    ----------------------
    If $admincreds is a PSCredential object then this example returns a registry object of the registry on the computer specified
    without being prompted for credentials.
#>
    param(
            [string]$ComputerName = '.',
            $Credential = $null
        )
    
    $Result = '' | Select Reg,Result,ErrorReason,ErrorDescription
    if($Credential -ne $null){
        Try{
            $Result.Reg = gwmi -Namespace root\default -ComputerName $ComputerName -Credential $Credential -query "select * FROM meta_class WHERE __Class = 'StdRegProv'"
            $Result.Result = "SUCCESS"
            return $Result
        }catch{
            $Result.Reg = $null
            $Result.Result = "FAILED"
            $Result.ErrorReason = "CONNECTION"
            $Result.ErrorDescription = $error[0]
            return $Result
        }
    }else{
        Try{
            $Result.Reg = gwmi -Namespace root\default -ComputerName $ComputerName -query "select * FROM meta_class WHERE __Class = 'StdRegProv'"
            $Result.Result = "SUCCESS"
            return $Result
        }catch{
            $Result.Reg = $null
            $Result.Result = "FAILED"
            $Result.ErrorReason = "CONNECTION"
            $Result.ErrorDescription = $error[0]
            return $Result
        }
    }
}

#Function to test the existance of a registry key
function Test-RegKey{
<#
.Synopsis
    Used to test the existance of a registry key
.Description
    If the function cannot connect to the workstation to get the StdRegProv object then it returns 'CANNOT_CONNECT'
    If it can connect but it does not find the registry key it returns $false.  If it finds the key it returns
    $true.  If an invalid Hive is specified it returns 'BAD_HIVE'.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Test-RegKey -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames
    
    ----------------------
    Connects to local registry and returns $true if it finds key and $false if not.
.Example
    PS>Test-RegKey -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will probably return an error because when connecting to a remote workstation the HKCU is of the user specified by the Credential
    object.  You would need to use HKU and specify the <SID> of the current user as the beginning of the path
    in order to set that test for that key for the user that is logged into the machine.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    $CheckKey = ($reg.enumkey($root,$path)).ReturnValue
    if($CheckKey -eq 0){
        return $True
    }else{
        return $False
    }
        
}

#Function to create a registry key
function Set-RegKey{
<#
.Synopsis
    Used to create a registry key
.Description
    If the function cannot connect to the workstation to get the StdRegProv object then it returns 'CANNOT_CONNECT'
    If it can connect but it does not create the registry key it returns $false.  If it creates the key it returns
    $true.  If an invalid Hive is specified it returns 'BAD_HIVE'.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Set-RegKey -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames
    
    ----------------------
    Connects to local registry and returns $true if it creates the key and $false if not.
.Example
    PS>Set-RegKey -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and create the key in the specified path and hive.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    $CheckKey = ($reg.CreateKey($root,$path)).ReturnValue
    if($CheckKey -eq 0){
        return $True
    }else{
        return $False
    }
        
}

#Function to remove a registry key
function Remove-RegKey{
<#
.Synopsis
    Used to remove a registry key
.Description
    If the function cannot connect to the workstation to get the StdRegProv object then it returns 'CANNOT_CONNECT'
    If it can connect but it does not remove the registry key it returns $false.  If it removes the key it returns
    $true.  If an invalid Hive is specified it returns 'BAD_HIVE'.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Remove-RegKey -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames
    
    ----------------------
    Connects to local registry and returns $true if it removes the key and $false if not.
.Example
    PS>Remove-RegKey -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and remove the key in the specified path and hive.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    $CheckKey = ($reg.DeleteKey($root,$path)).ReturnValue
    if($CheckKey -eq 0){
        return $True
    }else{
        return $False
    }
        
}

#Function to test if you have permisson to access a registry key
function Test-RegAccess{
<#
.Synopsis
    Used to test if you have permission to access a registry key
.Description
    If the function cannot connect to the workstation to get the StdRegProv object then it returns 'CANNOT_CONNECT'
    If it can connect but it can't check access to the registry key it returns $false.  If it can check access to the 
    key it returns $true.  If an invalid Hive is specified it returns 'BAD_HIVE'.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Test-RegAccess -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames
    
    ----------------------
    Connects to local registry and returns $true if you have permission to access the key and $false if not.
.Example
    PS>Test-RegAccess -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and test access to the key in the specified path and hive.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    $CheckKey = ($reg.CheckAccess($root,$path)).ReturnValue
    if($CheckKey -eq 0){
        return $True
    }else{
        return $False
    }
        
}

function Remove-RegValue{
<#
.Synopsis
    Used to delete a ValueName under the specified key.
.Description
    If the function cannot connect to the workstation to get the StdRegProv object then it returns 'CANNOT_CONNECT'
    If it can connect but it can't remove the valuename returns $false.  If it can remove the valuename 
    it returns $true.  If an invalid Hive is specified it returns 'BAD_HIVE'.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ValueName
    The name of the value you want to delete in the specified registry key.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Remove-RegValue -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames -ValueName LastUpdated
    
    ----------------------
    Connects to local registry and returns $true if it deleted the valuename and $false if not.
.Example
    PS>Remove-RegValue -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ValueName LastUpdate -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and remove the valuename in the specified path and hive.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ValueName,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    $CheckKey = ($reg.DeleteValue($root,$path,$ValueName)).ReturnValue
    if($CheckKey -eq 0){
        return $True
    }else{
        return $False
    }
        
}

function Get-RegValue{
<#
.Synopsis
    Used to retrieve a value from the registry.
.Description
    This function uses an System.Object to keep track of the informations it retrieves.  It returns that object when it is finished.
    The object will keep track of detailed errors as it tries to contact workstations to assess its registry.
    You could subsequently sort the output and get computers that were successful or ones that you value wasn't found to 
    take additionl actions on.  For example if it reports that the value is not found you could pipe the object to the set-regvalue
    function to have it create the key and value.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ValueName
    The name of the valuename you want find in the specified registry key.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Get-RegValue -Hive HKLM -Path Software\ScriptingGuys\2010ScriptingGames -ValueName LastUpdated
    
    ----------------------
    Connects to local registry and returns detailed information about the value and/or errors that occurred in the processs
    of retrieving the informaiton
.Example
    PS>Remove-RegValue -Hive HKCU -path Software\ScriptingGuys\2010ScriptingGames -ComputerName wrkstation1 -Credential $admincreds
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and returns detailed information about the value and/or errors 
    that occurred in the processs of retrieving the informaiton in the specified path and hive.
#>
    param(
            [string]$Path,
            [string]$Hive,
            [string]$ValueName,
            $Credential = $null,
            $ComputerName = '.'
        )
    
    $RegEntry = '' | select ComputerName,Hive,Subkey,ValueName,ValueType,Data,Result,ErrorReason,ErrorDescription
    $RegEntry.ComputerName = $computername
    $RegEntry.Hive = $Hive.ToUpper()
    $RegEntry.SubKey = $Path
    $RegEntry.ValueName = $ValueName
    $ErrorActionPreference = "Stop"
    $ValueTypes = @{
             "1"="REG_SZ"
             "2"="REG_EXPAND_SZ"
             "3"="REG_BINARY"
             "4"="REG_DWORD"
             "7"="REG_MULTI_SZ"
             "11"="REG_QWORD"
            }
            
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   { $RegEntry.Result = "FAILED"
                    $RegEntry.ErrorReason = "BAD_HIVE"
                    $RegEntry.ErrorDescription = "Hive NOT Specified Correctly"
                    Return $RegEntry}
    }
     
    $Result = Get-RegProvider $RegEntry.ComputerName $Credential
    if($Result.Result -eq "SUCCESS"){
        $reg = $Result.reg
    }else{
        $RegEntry.Result = $Result.Result
        $RegEntry.ErrorReason = $Result.ErrorReason
        $RegEntry.ErrorDescription = $Result.Description
        return $RegEntry
    } 
    
    if($RegEntry.ComputerName -eq '.'){$RegEntry.ComputerName = $reg.__SERVER} 
    
    Try{
        if(($reg.CheckAccess($root,$path)).bGranted -eq $True){       
            $RegNames = ($reg.enumvalues($root,$path)).sNames
            $RegTypes = ($reg.enumvalues($root,$path)).Types
        }else{
            $RegEntry.Result = "FAILED"
            $RegEntry.ErrorReason = "PERMISSION_DENIED"
            $RegEntry.ErrorDescription = "Access to SubKey is denied:  $path"
            return $RegEntry
        }
    }catch{
        $RegEntry.Result = "FAILED"
        $RegEntry.ErrorReason = "SEE_DESCRIPTION"
        $RegEntry.ErrorDescription = $error[0]
        return $RegEntry
    }
    
    $exists = $RegNames | ?{$_ -eq $ValueName}
    if(-not $exists){
        $RegEntry.Result = "FAILED"
        $RegEntry.ErrorReason = "NOT_FOUND"
        $RegEntry.ErrorDescription = "Registry value name was not found on workstation.`nPlease check your path and try again.`nIf path is correct then the Value is not present; please create it."
        return $RegEntry
    }else{
        for($i=0;$i -lt $RegNames.count;$i++){
            $ValuesToTypes += @{$RegNames[$i] = $ValueTypes.[string]$RegTypes[$i]} #taking advantage of hash tables to get dynamic information
        }
        $RegEntry.ValueType = $ValuesToTypes.$ValueName #again taking advantage of hash tables for dynamic information
        switch ($ValuesToTypes.$ValueName){
            "REG_SZ"            {
                                    $RegEntry.Data = ($reg.GetStringValue($root,$path,$ValueName)).sValue
                                    $RegEntry.Result = "SUCCESS"
                                }
            "REG_EXPAND_SZ"     {
                                    $RegEntry.Data = ($reg.GetExpandedStringValue($root,$path,$ValueName)).sValue
                                    $RegEntry.Result = "SUCCESS"
                                }
            "REG_BINARY"        {
                                    $RegEntry.Data = ($reg.GetBinaryValue($root,$path,$ValueName)).uValue
                                    if($RegEntry.Data[0] -eq $Null){$RegEntry.Data = $Null}
                                    $RegEntry.Result = "SUCCESS"
                                }
            "REG_DWORD"         {
                                    $RegEntry.Data = ($reg.GetDWORDValue($root,$path,$ValueName)).uValue
                                    $RegEntry.Result = "SUCCESS"
                                }
            "REG_MULTI_SZ"      {
                                    $RegEntry.Data = ($reg.GetMultiStringValue($root,$path,$ValueName)).sValue
                                    if($RegEntry.Data[0] -eq $Null){$RegEntry.Data = $Null}
                                    $RegEntry.Result = "SUCCESS"
                                }
            "REG_QWORD"         {
                                    $RegEntry.Data = ($reg.GetQWORDValue($root,$path,$ValueName)).uValue
                                    $RegEntry.Result = "SUCCESS"
                                }
        }
        return $RegEntry
    }                         
} 

function Set-RegValue{
<#
.Synopsis
    Used to create a value from the registry.
.Description
    This function will create a value of specified name and type in the specified registry key.  You need to specify the hive, path of the key, the valuename, the valuetype,
    and the actual value.  You can also specify the remote workstation and credentials to use when connecting.
.Parameter Hive
    Values:
        HKCR      HKEY_CLASSES_ROOT
        HKCU      HKEY_CURRENT_USER
        HKLM      HKEY_LOCAL_MACHINE
        HKU       HKEY_USERS
        HKCC      HKEY_CURRENT_CONFIG
        
    Specify the Hive with three or four character acronym.  It will retrieve the correct unsigned [int] that represents 
    the hive specified.
.Parameter Path
    The path in the registry from the hive root.
.Parameter ValueName
    The name of the valuename you want find in the specified registry key.
.Parameter ValueType
    Values:
        REG_SZ            
        REG_EXPAND_SZ     
        REG_BINARY
        REG_DWORD
        REG_MULTI_SZ
        REG_QWORD     

    There are six types of data you can create in the registry.  Each of the values above is associcated to a numeric type i.e. REG_SZ is type 1 and REG_QWORD is type 11.
    There are several different types that need to be provided in order the the set-regvalue to work. For example REG_DWORD takes a value of type [uint32].  So the functions 
    tries to prevent you from specifying a string for DWORD and a UINT32 for a string value by asking you to supply the type of registry entry you want to create.
.Parameter ComputerName
    Target workstation.  It defaults to localhost '.'
.Parameter Credential
    PSCredential object should be passed if not then you will be prompted for credentials.  Defaults to $null
    so that if you are access local registry you don't have to provide credentials.
.Example
    PS>Set-RegValue -Hive HKCU -Path software\scriptingguys\2010ScriptingGames -ValueName LastUpdated -ValueType REG_SZ -Value ((get-date).tostring())
    
    ----------------------
    Connects to local registry and creates a valuename with the specified data in the specified key and hive.
.Example
    PS>Set-RegValue -Hive HKCU -Path software\scriptingguys\2010ScriptingGames -ValueName LastUpdated -ValueType REG_SZ -Value ((get-date).tostring()) -ComputerName wrkstation1 -Credential $admin
    
    ----------------------
    Will connect to the remote workstation with the credentials provided and create a valuename with the specified data in the specified key and hive.
#>
    param(
            [string]$Hive,
            [string]$Path,
            [string]$ValueName,
            [string]$ValueType,
            $Value,
            [string]$ComputerName = '.',
            $Credential = $null
        )
    switch ($hive){
        "HKCR"    {$root = [uint32]'0x80000000'} #HKEY_CLASSES_ROOT
        "HKCU"    {$root = [uint32]'0x80000001'} #HKEY_CURRENT_USER
        "HKLM"    {$root = [uint32]'0x80000002'} #HKEY_LOCAL_MACHINE
        "HKU"     {$root = [uint32]'0x80000003'} #HKEY_USERS
        "HKCC"    {$root = [uint32]'0x80000005'} #HKEY_CURRENT_CONFIG
        Default   {return "BAD_HIVE"}
    }
    
    $result = Test-RegKey $hive $path -ComputerName $Computername -Credential $Credential
    if($result -eq $false){
        $answer = Get-Answer "Registry Change!!!" "The registry key you specified does not exist.  Would you like to create it?"
        if($answer -eq 0){
            $SetResult = Set-RegKey $hive $path -ComputerName $ComputerName -Credential $Credential
        }else{
            return "BAD_REGISTRY_PATH"
        }
    }elseif($result -ne $True){return $result}
        
    $Result = Get-RegProvider -ComputerName $ComputerName -Credential $Credential
    if($Result.Result -eq 'Success'){
        $reg = $Result.Reg
    }else{
        return "CANNOT_CONNECT"
    }
    
    switch ($ValueType){
        "REG_SZ"            {if($Value -isnot [string]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.setStringValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        "REG_EXPAND_SZ"     {if($Value -isnot [string]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.SetExpandedStringValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        "REG_BINARY"        {if($Value -isnot [byte[]]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.SetBinaryValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        "REG_DWORD"         {if($Value -isnot [uint32] -and $Value -isnot [int]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.SetDWORDValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        "REG_MULTI_SZ"      {if($Value -isnot [string[]]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.SetMultiStringValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        "REG_QWORD"         {if($Value -isnot [uint64]){
                                return "BAD_VALUE"
                            }else{
                                $Result = ($reg.SetQWORDValue($root,$path,$ValueName,$Value)).ReturnValue
                                if($Result -eq 0){
                                    return $True
                                }else{
                                    return $False
                                }
                            }}
        Default           {return "BAD_VALUE_TYPE"}
    }
}

