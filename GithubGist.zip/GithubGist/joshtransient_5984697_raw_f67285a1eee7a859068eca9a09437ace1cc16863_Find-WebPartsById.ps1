param([string] $webconfigpath = 'c:\path\to\web.config')

$apppath = new-object System.IO.FileInfo $webconfigpath
$binpath = [System.IO.Path]::Combine($apppath.Directory.FullName, 'bin\')
$wpClassAspNet = [System.Type]::GetType('System.Web.UI.WebControls.WebParts.WebPart, System.Web, Version=2.0.0.0, Culture=Neutral, PublicKeyToken=b03f5f7f11d50a3a')

#$wpClassSharePoint = [System.Reflection.Assembly]::LoadFrom('C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\12\ISAPI\Microsoft.SharePoint.dll').GetType('Microsoft.SharePoint.WebPartPages.WebPart')

function Get-AssemblyWebparts([Parameter(ValueFromPipeline=$True)][string] $assemblyName){
  if ($assemblyName -match 'Microsoft.SharePoint' -or $assemblyName -match 'System.Web' -or [string]::IsNullOrEmpty($assemblyName)) {
		return
	}

	try {
		$a = [System.Reflection.Assembly]::Load($assemblyname)
	} catch {
		$idx = $assemblyname.IndexOf(',')
		if ($idx -ge 0){ $path = $assemblyname.Substring(0, $idx) }
		else { $path = $assemblyname }
		$a = [System.Reflection.Assembly]::LoadFrom($binpath + $path+'.dll')
	}

	if ($a -eq $null) {
		write-host "Unable to resolve assembly $assemblyName"
		return
	}

	$a.GetTypes() | where-object {$_.IsSubclassOf($wpClassAspNet)}
}

function Get-WebpartTypeId([System.Type] $wpType){
	$prov = new-object System.Security.Cryptography.MD5CryptoServiceProvider
	[Guid]$prov.ComputeHash( [System.Text.Encoding]::Unicode.GetBytes( $wpType.Assembly.FullName + "|" + $wpType.FullName ) )
}

function New-Tuple() {
	param ( [object[]]$list= $(throw "Please specify the list of names and values") )
	$tuple = new-object psobject
	for ( $i= 0 ; $i -lt $list.Length; $i = $i+2) {
		$name = [string]($list[$i])
		$value = $list[$i+1]
		$tuple | add-member NoteProperty $name $value
	}
	return $tuple
}

[xml]$config = gc $webconfigpath
$assemblies = $config.SelectNodes('//SafeControl') | where-object {$_.Safe -ieq 'True' } | group-object -Property Assembly | %{$_.Name.ToString()}
$f = @{Expression={$_.Assembly.FullName};Label='Assembly'},@{Expression={$_.FullName};Label='Type'},@{Expression={Get-WebpartTypeId $_};Label='ID'}
#Get-AssemblyWebparts 'PS.WebParts.Rollup, Version=12.0.0.0, Culture=neutral, PublicKeyToken=90e3045b123af1c3' | format-table $f
$types = $assemblies | foreach-object { Get-AssemblyWebparts $_ }
$types | foreach-object { $id = Get-WebpartTypeId $_; new-tuple Assembly,$_.Assembly.FullName,Type,$_.FullName,Id,$id}

