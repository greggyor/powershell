function Cleanup-Folders($path) {
  if($path) {
		Get-ChildItem -recurse | Where {$_.PSIsContainer -and @(Get-ChildItem -Lit $_.Fullname -r | Where {!$_.PSIsContainer}).Length -eq 0} | Remove-Item -recurse -whatif
	} 
}

Cleanup-Folders "c:\temp\blah"


