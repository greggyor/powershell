function global:Delete-BinObj()
{
    $path = join-path $solutionScriptsContainer '..' -resolve
    Get-ChildItem $path -include bin,obj -recurse -Force | remove-item -force -recurse
}

