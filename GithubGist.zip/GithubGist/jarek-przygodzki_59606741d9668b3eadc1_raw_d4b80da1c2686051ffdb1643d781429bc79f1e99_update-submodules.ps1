$GIT_CMD = '/path/to/git.exe'
& $GIT_CMD submodule update --remote 
$difference =  & $GIT_CMD status --porcelain
$git_update_count = [regex]::matches($differences, "^M+").count

if($git_update_count -ne 0) {
    & $GIT_CMD commit -m "Aktualizacja wersji submodułów"
    & $GIT_CMD push origin
}

