# la recherche à effectuer :
$recherche = '*sip*'


# si vous êtes sur un poste avec vos identifiants sauvegardés
Connect-e_session

# dans le cas contraire, vous devrez préciser les paramètres
# ServerUrl : l'url racine de votre gestion commerciale
# Username : l'adresse e-mail de connexion à utiliser
# Password : le mot de passe associé
# Connect-e_session -serverurl 'http://e-gestcom' -Username test@test.com -password test123#

Get-e_mediationtype $recherche

