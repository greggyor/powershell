# List-DistributionGroups.ps1
# Peter Mellett 2012
# 
# Find all distribution groups of a user and list them to the console
#
# Example:
# .\List-DistributionGroups.ps1 aperson@company.com
#
# Name
# ====
# Marketing
# Managers
# 

[CmdletBinding()]
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$email
)

if (Test-Path 'C:\Program Files\Microsoft\Exchange Server\V14\bin\RemoteExchange.ps1') {
    . 'C:\Program Files\Microsoft\Exchange Server\V14\bin\RemoteExchange.ps1'
    Connect-ExchangeServer -auto

    Write-Host "$email belongs to: "
    $lists = Get-DistributionGroup -ResultSize unlimited
    $lists | where { (Get-DistributionGroupMember $_ | foreach {$_.PrimarySmtpAddress}) -contains $email } | select Name
} else {
    Wite-Host "This script requires Exchange 2010 Shell to be installed. Either use this script on an Exchange server or install the EMC from the Exchange install media."
}

