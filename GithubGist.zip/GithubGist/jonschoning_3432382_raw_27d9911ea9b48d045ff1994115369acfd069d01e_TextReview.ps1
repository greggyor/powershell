# This script extracts all the string literals from a source code tree
# so the strings can be examined in a spell checker.
#
# Author: John D. Cook 
# http://www.johndcook.com

# If path is not provided as an argument, the script searches the current directory.
param($srcRoot=(pwd))

# Make an array of file names in the directory matching source file extensions
$sourceExtensions = "\.(cs|vb|aspx|resx|cpp|rc|h|js|xml)$"
$files = (dir -recurse $srcRoot | %{$_.FullName}) -match $sourceExtensions

# Process each file
foreach ($file in $files)
{
    $allLines = (get-content $file)
    $linesToKeep = @()
    $lineNumber = 0
    
    # Process each line in a file
    foreach ($line in $allLines)
    {
        $lineNumber++
        
        # Exclude C++ header includes
        if ($line -match "^#include") 
        {
            continue
        } 
        
        # Extract quoted strings
        # Process each literal on each line
        $pattern = '"[^"]*"' # a quoted string "
        $literals = ([regex]::matches($line, $pattern) | %{$_.value})       
        foreach ($literal in $literals)
        {
            $literal = ($literal -replace '\\[a-z]', " ") # get rid of \n etc. 
            $literal = ($literal -replace "&(?=\w)", "")  # remove amperands followed immediately by letters, as in menu shortcut notation

            if ($literal -notmatch "\w")
            {
                continue # no word characters in literal
            }
            if ($literal -match " ")
            {
                # Literals containing no spaces are often code rather than blocks of prose.
                # We reduced our false positive rate quite a bit when we limited 
        # the script to only report strings containing at least one space.
                $linesToKeep += "$lineNumber`t $literal"
            }
        }        
    }
    
    # Print report for files that have literals that haven't been filtered out
    if ($linesToKeep.Length -gt 0)
    {
        $file
        " "
        $linesToKeep
        "___________________________________________"
        " "
    }
    
    # Parse XML files again, looking for text not contained in quotes but contained inside XML elements 
    if ($file -match "\.(xml|aspx|resx)$")
    {
        $lineNumber = 0
        $linesToKeep = @()


        foreach ($line in $allLines)
        {
            $lineNumber++
            $line = ($line -replace "<[^>]*>", " ") # strip XML tags
            $line = ($line -replace "&nbsp;", " ")  # get rid of space entities
            if ($line -match "\w") # There's some text left after the above processing
            {
                $line = $line.trim()
                $linesToKeep += "`t$lineNumber $line"
            }
        }
    
        if ($linesToKeep.Length -gt 0)
        {
            $file
            " "
            $linesToKeep
            "___________________________________________"
            " "
        }
    } 
}


