new-alias jrun "C:\ColdFusion9\runtime\bin\jrun.exe"

function cf($server="coldfusion"){
    jrun -start $server
}

