# Script assumes you have setup your subscription and 
# have a default storage account in West US.

# You should change these to values you want.
$cloudService = "{cloudservice}"
$hostname = "{dockermanagementhost}"
$linuxUser = "{linxuser}"
$linuxPass = "{linxpasswd}"
$location = "West US"

# use CentOS 7 image
$centOSImageName = (Get-AzureVMImage | Where-Object {$_.ImageName -like "*OpenLogic-CentOS-70*"})[0].ImageName

New-AzureVMConfig -Name $hostname -InstanceSize Small -ImageName $centOSImageName | Add-AzureProvisioningConfig –Linux –LinuxUser $linuxUser -Password $linuxPass | New-AzureVM -ServiceName $cloudService -Location $location

