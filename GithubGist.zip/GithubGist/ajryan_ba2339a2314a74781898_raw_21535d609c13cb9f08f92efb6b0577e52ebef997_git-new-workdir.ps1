param (
  [string]$NewWorkDir = $( Read-Host 'New work dir' ),
  [string]$Branch = $( Read-Host 'Branch' )
)

$gitDir = git rev-parse --git-dir
if (!$gitDir) {
  exit 128
}

# cannot operate on bare repo
$isBare = git --git-dir="$gitDir" config --bool --get core.bare
if ($isBare -Eq "true") {
  echo "'$gitDir' has core.bare set to true, remove from '$gitDir/config' to use"
  exit 128
}

# cannot operate on a workdir (config file is a symlink)
$configFile = Get-Item "$gitDir\config" -Force -ea 0
if ($configFile.Attributes -band [IO.FileAttributes]::ReparsePoint) { 
  echo "current directory is working directory only"
  exit 128
}

# don't overwrite existing directory
if (Test-Path $NewWorkDir) {
  echo "destination directory '$NewWorkDir' already exists"
  exit 128
}

# get the absolute path to the git directory
$gitPath = $(Resolve-Path $gitDir).Path

# create the .git folder in the new directory
$newGitPath = Join-Path $NewWorkDir '.git'
mkdir $newGitPath | Out-Null
# create logs parent to hold refs link
mkdir (Join-Path $newGitPath 'logs')

# sym link from the new .git folder into the original .git folders
ForEach ($subDir in 'config', 'refs', 'logs\refs', 'objects', 'info', 'hooks', 'packed-refs', 'remotes', 'rr-cache', 'svn') {
  $newSubDir = Join-Path $newGitPath $subDir
  $origSubDir = Join-Path $gitPath $subDir

  cmd /c mklink /D $newSubDir $origSubDir
}

# set up the new working dir
cd $NewWorkDir
copy (Join-Path $gitPath HEAD) .git\HEAD
git checkout -f $Branch