function Start-ManagementConsole {
    Param( [string]$ComputerName = '.' ) 
    Start-Process -FilePath "${env:windir}\System32\mmc.exe" `
        -ArgumentList "compmgmt.msc /computer:\\${ComputerName}"
 }

 New-Alias -Name manage -Value "Start-ManagementConsole" -Scope Global

