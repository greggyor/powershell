# copy items
# if you have a zip here: http://myserver.com/my.zip and it contains myFile.txt and myFolder/myOtherFile.txt
# you can call this script like so:
# .\download_zip.ps1 http://myserver.com/my.zip "myFile.txt|c:\myFileDestination\myFileHere.txt" "myFolder/myOtherFile.txt|c:\myOtherDestination\myOtherFile.txt"
# 

"download script -----------------------------------------"
"------"
"Downloads from the given url, unzips it then for each string arg, copies the file to the destination"

"params : zip.url 'name|destination[, name|destination...]'"



$index = 0
$url = $args[0]


"url: $url"
$pwd = "$(get-location)"

if( !(test-path "$pwd\download") )
{
    mkdir -p "$pwd\download"
}

if( !(test-path "$pwd\download\expanded") )
{
    mkdir -p "$pwd\download\expanded"
}

$save_path = "$pwd\download\mobius.zip"
$expand_path = "$pwd\download\expanded"

"Downloading [$url]`n"
$client = new-object System.Net.WebClient
$client.DownloadFile( $url, $save_path )

"Download complete.."
$shell_app=new-object -com shell.application 

"Unzipping`n"
$zip_file = $shell_app.namespace($save_path) 
$destination = $shell_app.namespace($expand_path)
#0x14 forces an overwrite
$destination.Copyhere($zip_file.items(), 0x14) 

foreach( $arg in $args ){

    if( $index -ne 0 )
    {
        $split = $arg.split("|")
        $file_to_copy = $split[0]
        $destination = $split[1]
        
        $destination -match "(.*)\\(.*)"
        
        $final_folder = $matches[1]
        $final_name = $matches[2]
		
		if( $file_to_copy -match "(.*)\\(.*)" )
		{
			$filename_to_rename = $matches[2]
        }
		else
		{
			$filename_to_rename = $file_to_copy
		}
		""
        "$file_to_copy ->>>- $destination"        
        "final_folder: $final_folder"
        "final_name: $final_name"
        "file_to_copy: $file_to_copy"
		"file_to_rename: $filename_to_rename"
        
        Copy-Item "$expand_path\$file_to_copy" "$final_folder" -force
        Move-Item "$final_folder\$filename_to_rename" "$final_folder\$final_name" -force
    }
     $index++
}

