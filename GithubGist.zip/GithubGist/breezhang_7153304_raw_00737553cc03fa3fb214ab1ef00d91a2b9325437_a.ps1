#find -type f  |xargs md5sum --binary >file.txt

$db = New-Object -TypeName System.Collections.Specialized.NameValueCollection;

foreach($item in (gc 'path\file.txt')){
       $temp = $item.Split("*");
       $db.add([string]$temp[0],[string]$temp[1]);
}
;

$Global:result=$db.AllKeys | %{ if($db[$_].Split(",").Length -gt 1){@{hash=$_ ;filename=@($db[$_].Split(","))}}};

