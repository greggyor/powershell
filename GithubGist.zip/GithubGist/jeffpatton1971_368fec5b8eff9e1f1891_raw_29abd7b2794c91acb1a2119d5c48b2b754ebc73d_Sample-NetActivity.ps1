#
# Enable-WSManCredSSP -Role Client -DelegateComputer localhost
# Enable-WSManCredSSP -Role Server
#
Try{
    $ErrorActionPreference = "Stop";
    $WinRMUser = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{5408AD4E-3052-4F73-B45E-7DADBB999FE4}\`d.T.~Ed/";
    $WinRMPass = ConvertTo-SecureString -String "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{98301C29-F4AF-4A43-88D3-851520744C6B}\`d.T.~Ed/" -AsPlainText -Force;
    $Credential = New-Object System.Management.Automation.PSCredential ($WinRMUser, $WinRMPass);
    #
    # We will connect to and run powershell from the local orchestrator server
    #
    $ComputerName = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{B0699ECA-EA8F-40B6-A73F-00D220D955C6}\`d.T.~Ed/";
    #
    # Pass these into invoke
    #
    $AdsPath = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{332FD283-912F-431C-A481-26433B5FB78D}\`d.T.~Ed/";
    $SearchFilter = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{401BF2E1-D1CF-4650-A9D4-22E6955B547F}\`d.T.~Ed/";
    #
    # The following two modules are my custom modules for working with AD and text logfiles
    #
    $LogModulePath = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{C230740F-832C-44D8-A496-D4BBD86018B0}\`d.T.~Ed/";
    $ADModulePath = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{2652BC51-9A85-45C3-ADD8-8A9FF7FB92E7}\`d.T.~Ed/";
    #
    # Set this to be the location of your logfiles, if you leave it blank the functions will create C:\Logfiles and store them there
    #
    $LogPath = "\`d.T.~Ed/{34846A7C-5BC4-4C23-A22A-D21C1DC99DF8}.{2563F269-803F-4855-A3D2-198BCDDEEB07}\`d.T.~Ed/";
    #
    # A descriptive name that will become the logfile
    #
    $LogName = "";
    #
    # Add whatever variablese you need here
    #
    New-EventLog -LogName "Windows PowerShell" -Source $LogName -ErrorAction SilentlyContinue
    $Session = New-PSSession -ComputerName $ComputerName -Credential $Credential -Authentication Credssp
    #
    # Whatever additional variables you add above, make sure to add them to the argumentlist below
    #
    Invoke-Command -Session $Session -ArgumentList $AdsPath, $SearchFilter, $LogModulePath, $ADModulePath, $LogPath, $LogName -ScriptBlock{
        #
        # Param == Argumentlist check your work here
        #
        Param ($AdsPath, $SearchFilter, $LogModulePath, $ADModulePath, $LogPath, $LogName)
        try{
            Import-Module $LogModulePath;
            Import-Module $ADModulePath;
            #
            # Import any other required modules here
            #
            #
            # Start the work
            #
            Write-LogFile -LogPath $LogPath -LogName $LogName -Source "Execution" -EventID 100 -EntryType "Information" -Message "Begin Office 365 Provisioning";
            #
            # End the work
            #
            Write-LogFile -LogPath $LogPath -LogName $LogName -Source "Execution" -EventID 100 -EntryType "Information" -Message "End Office 365 Provisioning";
            }
        catch{
            #
            # This catch handles any errors that may occur inside the session
            #
            Write-EventLog -LogName 'Windows PowerShell' -EntryType Error -Source $LogName -EventId 2 -Message (ConvertTo-Xml -InputObject $Error[0].InvocationInfo).InnerXml;
            Write-EventLog -LogName 'Windows PowerShell' -EntryType Error -Source $LogName -EventId 2 -Message $Error[0].Exception;
            }
        }
    }
catch{
    #
    # You may need to hardcode your logname here, this catch handles any connection errors that may occur
    #
    Write-EventLog -LogName 'Windows PowerShell' -EntryType Error -Source $LogName -EventId 1 -Message (ConvertTo-Xml -InputObject $Error[0].InvocationInfo).InnerXml;
    Write-EventLog -LogName 'Windows PowerShell' -EntryType Error -Source $LogName -EventId 1 -Message $Error[0].Exception;
    }

