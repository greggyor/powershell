# -----------------------------------------------------------------------------
#                     S C R I P T   P R O P E R T I E S 
# -----------------------------------------------------------------------------
Properties {
	$solution = (Get-ChildItem *.sln).Name
	$solutionname = $solution.Substring(0, $solution.LastIndexOf('.'))
}

