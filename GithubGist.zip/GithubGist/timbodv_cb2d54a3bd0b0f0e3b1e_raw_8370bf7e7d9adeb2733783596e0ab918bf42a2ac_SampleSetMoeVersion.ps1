param([string]$MOEVersion)

New-Item HKLM:SOFTWARE\MOE
New-ItemProperty HKLM:SOFTWARE\MOE -Name Version -Value "$MOEVersion"

$computerDetails = Get-WmiObject Win32_ComputerSystem

# clean up the manufacturer name
$manufacturer = $($computerDetails.Manufacturer)
$manufacturer = $manufacturer.Replace(" Inc.", "")
$manufacturer = $manufacturer.Replace("innotek GmbH", "Oracle")

New-ItemProperty HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation -Name Model -Value "$manufacturer $($computerDetails.Model) running MOE $MOEVersion"


