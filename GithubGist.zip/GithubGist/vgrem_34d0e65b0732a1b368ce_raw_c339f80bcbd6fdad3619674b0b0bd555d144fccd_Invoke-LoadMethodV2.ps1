Function Invoke-LoadMethodV2() {
param(
   $Context = $(throw "Please provide an Client Context"),
   $Object = $(throw "Please provide an Client Object instance on which to invoke the generic method")
) 
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load") 
   $type = $Object.GetType()
   $clientObjectLoad = $load.MakeGenericMethod($type) 
   $clientObjectLoad.Invoke($Context,@($Object,$null))
}

