#  Script creates local git repository linked with bare "remote" copy in dropbox directory,
#  so you gain cloud backups ater pushing changes.
#  Add following function to you PS Profile (don't forget to restart the shell)

#-----------------------------------------------------------------
#  Git-Init
#-----------------------------------------------------------------
$boxRepoPath = '{PATH_TO_DROPBOX_DIR where repos will be stored}'
function Git-Init($repoName $(throw "Parameter repoName is required.")) {  # run inside directory where you want working copy to put

# TODO:
  ## if not repoName : show_usage_and_break
  ## if repo exist   : show_usage_and_break
  ## if repo is path : extract filename

  Push-Location
  cd "$boxRepoPath"
  mkdir $repoName
  cd $repoName
  $remoteRepo = pwd
  git init --bare
	
  Pop-Location	##TODO: if given repoName is path, go to baseDir(repoName) and clone repo there
  git clone "$remoteRepo"
  # check that above command succeds and new directory is created
  
  cd $repoName
  
  # Make initial commit and push to link branches in both repos
  New-Item -Type file .gitignore
  New-Item -Type file README.md
  git add .
  git commit -am "Repository bootstrap"
  
  git push -u origin master
}


