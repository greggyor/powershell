Read-ApacheLog *.log|
?{($_.Status -eq 200) -and ($_.Path -like "*.php")}|
Group-Object Date|
%{
    $m = $_ | select -ExpandProperty Group | measure -Property TimeTaken -Average -Maximum -Minimum
    $_ | Add-Member Average $m.Average
    $_ | Add-Member Max $m.Maximum
    $_ | Add-Member Min $m.Minimum
    $_
}|
select Name, Count, Average, Max, Min|
ft -AutoSize

