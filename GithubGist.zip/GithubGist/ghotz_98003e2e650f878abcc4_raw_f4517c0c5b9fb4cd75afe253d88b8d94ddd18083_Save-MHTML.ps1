#
# Save to MHTML file
# Adapted from http://stackoverflow.com/questions/995339/saving-webpage-as-mhtm-file
#
# COM SaveOptionsEnum
# Const adSaveCreateNotExist = 1
# Const adSaveCreateOverWrite = 2
#
# COM StreamTypeEnum
# Const adTypeBinary = 1
# Const adTypeText = 2

$SourceURL = "http://www.ghotz.com";
$DestinationFile = "D:\Temp\test.mhtml";

$CDOMessage = New-Object -ComObject CDO.Message;
$ADODBStream = New-Object -ComObject ADODB.Stream;

$ADODBStream.Type = 2;
$ADODBStream.Charset = "US-ASCII";
$ADODBStream.Open();

$CDOMessage.CreateMHTMLBody($SourceURL, 0);
$CDOMessage.DataSource.SaveToObject($ADODBStream, "_Stream");

$ADODBStream.SaveToFile($DestinationFile, 2);

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($CDOMessage);
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($ADODBStream);


