$TOOLS = "D:\Tools"
$WIM_FILE = "C:\ISOs\install_win2008_r2_std_core.wim"
$IMG_INDEX = 1
$VHD_FILE = "C:\VHD - DA\win2008r2_offline.vhd"
$VHD_SIZE = 20480
$LETTER = "Z"
$MOUNT = "$($LETTER):"
$ANSWER_FILE = "c:\ISOs\win2008_r2_offline.xml"
$FEATURES = "NetFx2-ServerCore", 
			"IIS-WebServerRole", 
			"MicrosoftWindowsPowerShell", 
			"ServerManager-PSH-Cmdlets"


function private:Notify
{
	param($text)
	Write-Host -ForegroundColor Green $text
}

Set-Alias bootsect "$($TOOLS)\bootsect.exe"
Set-Alias imagex "$($TOOLS)\imagex.exe"

if(Test-Path $VHD_FILE)
{
	Notify "VHD file exist. Removing..."
	Remove-Item -Force $VHD_FILE
}

Notify "Creating VHD disk"

$cmd = "create vdisk file=`"$($VHD_FILE)`" type=expandable maximum=$($VHD_SIZE)
attach vdisk
create partition primary
format fs=ntfs quick
active
assign letter=$($LETTER)
exit"

$cmd | diskpart

Notify "Extracting image"
imagex /apply $WIM_FILE $IMG_INDEX $MOUNT

Notify "Caching unattended installation answer file"
Copy-Item -Path $ANSWER_FILE -Destination "$($MOUNT)\Windows\system32\sysprep\Unattend.xml"

Notify "Applying unatteded installation answer file"
dism /image:$MOUNT /apply-unattend:$ANSWER_FILE

Notify "Installing features"
foreach($feature in $FEATURES)
{
	Notify "Installing feature $($feature)"
	dism /image:$MOUNT /enable-feature /featureName:$feature
}

Notify "Installing bootloader"
bootsect /nt60 $MOUNT /force /mbr

Notify "Creating BCD"
bcdboot "$($MOUNT)\Windows" /s $MOUNT

Notify "Detaching VHD disk"

$cmd = "select vdisk file=`"$($VHD_FILE)`"
detach vdisk
exit"

$cmd | diskpart

Notify "Installation done"


