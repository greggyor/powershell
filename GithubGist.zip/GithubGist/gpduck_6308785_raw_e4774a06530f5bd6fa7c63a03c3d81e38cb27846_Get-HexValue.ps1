function Get-HexValue {
	param(
		[Parameter(Mandatory=$true)]
		[Char]$Character,
		
		[ValidateSet("ASCII","BigEndianUnicode","Default","Unicode","UTF32","UTF7","UTF8")]
		[String]$Encoding = "Unicode"
	)
	$E = [Text.Encoding]::$Encoding
	$Bytes = $E.GetBytes($Character)
	if($Encoding -ne "BigEndianUnicode") {
		[Array]::Reverse($Bytes)
	}
	-join ( $Bytes | Foreach-Object { "{0:X2}" -f $_ })
}

