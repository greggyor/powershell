#Provided by @mrlesmithjr
#EveryThingShouldBeVirtual.com
#
# Set variable for all hosts in current vCenter
$vmhosts = @(Get-VMHost)
foreach ($vmhost in $vmhosts) {
  Get-NetworkAdapter $vmhost
}


