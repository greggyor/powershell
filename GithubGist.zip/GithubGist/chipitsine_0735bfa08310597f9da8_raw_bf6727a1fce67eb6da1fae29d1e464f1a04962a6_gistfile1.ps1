#requires -version 4
cls

ipmo VirtualMachineManager

get-scvirtualmachine | % {

 [String] $vm = $_.Name
 ($_.VirtualNetworkAdapters).Where({$_.MACAddressType -eq 'Dynamic'},'First') | % { 
      Write-Host $vm
 }


}

