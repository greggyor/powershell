function Get-DiskUsage {
<#
.SYNOPSIS
    Gives details on disk free space
.DESCRIPTION
    Returns a list of drives on the local machine
.NOTES
    Name: Get-DiskUsage
    Author: James Santiago
    DateCreated: 08/21/2013
.EXAMPLE
    Get-DiskUsage
Description
------------
 Returns a list of drives on the local machine
.EXAMPLE
    Get-DiskUsage
Description
------------
Returns a list of drives on the local machine

#>    
Begin {
		
    }
Process {
			
	Try 
	{
		$drives = get-wmiobject win32_volume -filter 'drivetype = 3' -erroraction 0
	}
	Catch [Exception] {
		Write-Host $_.Exception.ToString()
	}
    }
End {
	return $drives | select __SERVER, driveletter, label, @{Name='GBfreespace';Expr={$($_.freespace/1GB).ToString("0.0")}}, @{Name='GBcapacity';Expr={$($_.capacity/1GB).ToString("0.0")}},  @{Name='Available%';Expr={$($_.freespace/$_.Capacity * 100).ToString("0")}} | Out-String
    }
}



