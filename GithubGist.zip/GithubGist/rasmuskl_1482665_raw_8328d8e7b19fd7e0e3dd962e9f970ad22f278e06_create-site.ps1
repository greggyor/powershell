param([string]$site=$(throw "Site argument is required."))

function vdir-exists([string]$name)
{
	if((Test-Path -path $name) -eq $False)
	{
		return $False
	}	

	(Get-Item $name).GetType().Name -eq "ConfigurationElement"
}

Write-Host "Creating or updating site: $site"

if ((Test-Path -path iis:) -ne $True)
{
	throw "Must have IIS snap-in enabled. Use ImportSystemModules to load."
}

$sitepath = "c:\inetpub\wwwroot\$site"

if ((Test-Path -path $sitepath) -ne $True)
{
	Write-Host "Creating directory: $sitepath"
	new-item $sitepath -type Directory > $null
}

$apppool = "iis:\apppools\$site"

if ((Test-Path -path $apppool) -ne $True)
{
	Write-Host "Creating AppPool..."
	New-Item $apppool > $null
}

$iissite = "iis:\sites\$site"

if ((Test-Path -path $iissite) -ne $True)
{
	Write-Host "Creating IIS Site..."
	New-Item $iissite -bindings @{protocol="http";bindingInformation="*:80:$site"} -physicalPath $sitepath -applicationPool $site > $null
}

$appdatadir = "$sitepath\App_Data"

if ((Test-Path -path $appdatadir) -ne $True)
{
	Write-Host "Creating App_Data directory..."
	New-Item $sitepath\App_Data -type Directory > $null
}

Write-Host "Setting permissions on App_Data directory..."
icacls $sitepath\App_Data /grant 'NT Authority\NetworkService:(OI)(CI)(F)' > $null


$surveydir = "$sitepath\Surveys"

if ((Test-Path -path $surveydir) -ne $True)
{
	Write-Host "Creating Survey directory..."
	New-Item $sitepath\Surveys -type Directory > $null
}

Write-Host "Setting permissions on survey directory..."
icacls $sitepath\Surveys /grant 'NT Authority\NetworkService:(OI)(CI)(F)' > $null


if ((vdir-exists("$iissite\Images")) -eq $False)
{
	Write-Host "Creating Images virtual directory..."
	New-Item $iissite\Images -type virtualDirectory -physicalPath c:\inetpub\wwwroot\_Images > $null		
}

if ((vdir-exists("$iissite\Fragments")) -eq $False)
{
	Write-Host "Creating Fragments virtual directory..."
	New-Item $iissite\Fragments -type virtualDirectory -physicalPath c:\inetpub\wwwroot\_Fragments > $null		
}



