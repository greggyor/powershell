1..10 | ForEach  {
    
    $r   = 0..($_-1) -join ''
    $exp = "$($r)*9+$_"     
    
    "{0,15}={1}" -f $exp, ($exp|Invoke-Expression)
}

''

1..9 | ForEach {
    
    $r   = 1..($_) -join ''
    $exp = "$($r)*8+$_"     
    
    "{0,15}={1}" -f $exp, ($exp|Invoke-Expression)
}

