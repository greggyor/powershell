#Original Doug Finke's gist - https://gist.github.com/4467657
#download all scripting games code by Rohn Edwards
$url="http://2012sg.poshcode.org/Scripts/By/862"

(Invoke-WebRequest $url).links | where{$_.innerHTML -eq "Download"} | ForEach {
    $outFile = "c:\temp\$($_.outerText)"
    #"Downloading $($_.InnerHtml) -> $($outFile)"
    $callstring = "http://2012sg.poshcode.org"+$_.href
    $callstring
    Invoke-WebRequest $callstring -OutFile $outFile
}
#>
<#
Doug Finke Script Mod.
Take the URL
for each URL.Links get links which are -like 2012sg.poshcode.org/number
populate that into an array
for each member in the array
call 2012sg.poshcode.org/Scripts/Get/ The number
Script is not generating the files as 4567.ps1. Will check this later.
#>

