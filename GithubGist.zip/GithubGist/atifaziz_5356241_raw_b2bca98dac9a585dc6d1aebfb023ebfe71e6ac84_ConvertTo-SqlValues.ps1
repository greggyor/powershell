function ConvertTo-SqlValues
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)]
        [object]$InputObject,
        [string]$TableName = 'Data',
        [Parameter(Position = 0)]
        [string[]]$Property,
        [switch]$DontForceDateTimeOffset
    )

    BEGIN 
    { 
        function SqlIdent([string]$s) { "[$($s -replace ']', ']]')]" }
        $initialized = $false; $i = -1 
        $sqlTableName = SqlIdent($tableName)
    }

    PROCESS
    {
        $i++
        if (!$initialized) 
        { 
            $initialized = $true
            $names = if (!$property) 
            { 
                $aliasProperty = [Management.Automation.PSMemberTypes]'AliasProperty'
                $inputObject | 
                    Get-Member -MemberType Properties | 
                    ? { $_.MemberType -ne $aliaProperty } |
                    Select -Expand Name 
            } 
            else 
            { 
                $property 
            }
            if ($names) 
            {
                $columns = ($names | % { SqlIdent($_) }) -join ', '
                "SELECT $columns FROM (VALUES"
            }
            else
            { 
                Write-Warning 'No properties found in input object.' 
            }
        }
        $literals = $names | % { 
            $v = $inputObject.$_
            switch ($(if ($v -ne $null) { $v.GetType() } else { [Void] }))
            {
                { [string], [char] -contains $_ } { "N'" + ($v -replace "'", "''") + "'" }
                { [int], [long], [single], [double], [decimal] -contains $_ } { [string]$v }
                { $_ -eq [bool] } { [int]$v }
                { $_ -eq [datetime] } { if ($DontForceDateTimeOffset) { "CONVERT(datetime, '{0:yyyy-MM-dd HH:mm:ss.fff}', 121)" -f $v } else { "CAST('{0:o}' AS datetimeoffset)" -f $v } }
                { $_ -eq [guid] } { "CAST('$(([string]$v).ToUpperInvariant())' AS uniqueidentifier)" }
                default { 'NULL' }
            }
        }
        if ($names) { "  $(if ($i -gt 0) { ',' } else { ' ' }) ($($literals -join ', '))" }
    }
    
    END { if ($initialized -and $names) { ") $sqlTableName($columns)" } }
}
