# -------------------------------------------------
# Function Run-Salescast
# By Joannes Vermorel, Lokad, 2015-01
#
# Triggers the execution of Salescast project within a Lokad account.
#
# Syntax:
#     run-salescast 'myemail' 'mypassword' 'myfolder'
# -------------------------------------------------
function Run-Salescast()
{
    param 
    (
        [string] $username,
        [string] $password,
        [string] $folder
    )
    $Url = 'https://salescast2.lokad.com/rest/basicstartrun?folder=' + $folder 
    $webclient = new-object system.net.webclient
    $webclient.credentials = new-object system.net.networkcredential($username, $password)
    return $webclient.DownloadString($Url)
}

