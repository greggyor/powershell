Function Get-Data {
  Param (
    [int] $data = -1
  )
  return $data;
}

