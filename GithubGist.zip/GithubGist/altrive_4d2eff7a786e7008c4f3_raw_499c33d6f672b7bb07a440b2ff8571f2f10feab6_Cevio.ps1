if([Environment]::Is64BitProcess){
   throw "64bitプロセス内だとDLLロードに失敗する"
}

$ErrorActionPreference = "Stop"

Add-Type -Path "${env:ProgramFiles(x86)}\CeVIO\CeVIO Creative Studio\CeVIO.Talk.RemoteService.dll"

[CeVIO.Talk.RemoteService.ServiceControl]::StartHost($true) >$null
$talker = New-Object CeVIO.Talk.RemoteService.InteroperableComponents.Talker

#キャスト設定
$talker.Cast = "さとうささら";

#（例）音量設定
$talker.Volume = 50

#（例）再生
$state = $talker.Speak("こんにちは")
$state.Wait()
$state = $talker.Speak("さとうささらです")
$state.Wait()

#（例）音素データ取得
$phonemes = $talker.GetPhonemes("はじめまして")

# （例）音素データをトレース出力
foreach ($phoneme in $phonemes.Core)
{
    Write-Host ("" + $phoneme.Phoneme + " " + $phoneme.StartTime + " " + $phoneme.EndTime)
}

#[CeVIO.Talk.RemoteService.ServiceControl]::CloseHost()