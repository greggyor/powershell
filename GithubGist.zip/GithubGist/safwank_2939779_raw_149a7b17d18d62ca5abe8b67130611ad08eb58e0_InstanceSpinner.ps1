param([string]$operation, [string]$secretKeyId, [string]$secretAccessKeyId, [string[]]$instanceIds)

Add-Type -Path ".\AWSSDK.dll"

function StartInstances()
{
	$ec2Client = CreateEC2Client
	
	$request = New-Object -TypeName Amazon.EC2.Model.StartInstancesRequest
	$request.InstanceId = GetInstancesFromParameterList
	
	$response = $ec2Client.StartInstances($request)
}

function StopInstances()
{
	$ec2Client = CreateEC2Client
	
	$request = New-Object -TypeName Amazon.EC2.Model.StopInstancesRequest
	$request.InstanceId = GetInstancesFromParameterList
	
	$response = $ec2Client.StopInstances($request)
}

function CreateEC2Client()
{
	$ec2Client = [Amazon.AWSClientFactory]::CreateAmazonEC2Client($secretKeyId, $secretAccessKeyId)
	$ec2Client
}

function GetInstancesFromParameterList()
{
	$instances = New-Object -TypeName System.Collections.Generic.List[string]
	
	foreach ($instanceId in $instanceIds) 
	{
		$instances.Add($instanceId)
	}
	
	,$instances
}

if ($operation -eq "start")
{
	StartInstances 
}
elseif ($operation -eq "stop") 
{
	StopInstances
}

