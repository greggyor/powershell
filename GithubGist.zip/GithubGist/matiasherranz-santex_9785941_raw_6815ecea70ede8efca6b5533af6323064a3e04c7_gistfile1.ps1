$ git init

