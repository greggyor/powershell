# First you'll need to download posh-hg from one of the following locations:
# http://github.com/JeremySkinner/posh-hg
# http://poshhg.codeplex.com

# Add the following code to your profile.ps1 (usually in C:\Users\User\Documents\WindowsPowershell)

# Import the posh-hg module from wherever it is saved
Import-Module "Path\To\posh-hg"

# Override the default prompt behaviour:

# text that appears before branch name 
$global:HgPromptSettings.BeforeText = ' on '
# Colour of text before branch name
$global:HgPromptSettings.BeforeForegroundColor = [ConsoleColor]::White
# Include a new line after the repository information...
#...followed by the text "hg" to identify it as a mercurial repo
$global:HgPromptSettings.AfterText = " `nhg"
# Text that appears before tag list
$global:HgPromptSettings.BeforeTagText = ' at '

# ...and you also need to include a custom prompt function:

function prompt {    
  # Display current path before mercurial prompt
  write-host "$pwd" -NoNewLine -foregroundcolor green
  
  # Display the Mercurial prompt
  Write-HgStatus
  
  # prompt arrows  
  write-host "»" -NoNewLine -ForegroundColor green
  # display path in console title
  $Host.UI.RawUI.WindowTitle = $pwd
  return ' '
}

#If you want tab expansion for hg commands:

if(-not (Test-Path Function:\DefaultTabExpansion)) {
    Rename-Item Function:\TabExpansion DefaultTabExpansion
}

function TabExpansion($line, $lastWord) {
  $LineBlocks = [regex]::Split($line, '[|;]')
  $lastBlock = $LineBlocks[-1] 
 
  switch -regex ($lastBlock) {
    '(hg|hgtk) (.*)' { HgTabExpansion($lastBlock) }
     # Fall back on existing tab expansion
     default { DefaultTabExpansion $line $lastWord }
  }
}




