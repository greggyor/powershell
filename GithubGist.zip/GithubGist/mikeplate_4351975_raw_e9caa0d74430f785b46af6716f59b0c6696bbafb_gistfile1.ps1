# List all users
$filter = "(&(objectClass=user)(objectCategory=person))"
$users = ([adsiSearcher]$filter).findall()
$users | %{ $_.Properties['displayname'] }
# Sort
$users | %{ $_.Properties['displayname'] } | sort
# Filter by part of name
$users | %{ $_.Properties['displayname'] } | where { $_ -match "John" }


