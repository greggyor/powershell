# @powershell -NoProfile -ExecutionPolicy unrestricted -Command "iex ((new-object net.webclient).DownloadString('https://raw.github.com/gist/3817081/first-chocolatey.ps1'))"
# install Chocolatey
iex ((new-object net.webclient).DownloadString('http://bit.ly/psChocInstall'))
# basic
cinst vlc
cinst 7zip
cinst pdfcreator
cinst keepass
cinst git
cinst ccleaner
cinst unlocker
cinst apache.ant
cinst virtualclonedrive
cinst xyzzy
cinst vim
cinst putty
cinst groovy
cinst freemind
cinst dia
cinst evernote
cinst adobereader
# Synergy should be the last one. It will reboot machine silently.
cinst synergy


