$base_downloads_dir = "S:\downloads\"
$base_archive_dir = "S:\downloads\archive"

if(-not (Test-Path $base_archive_dir)) {
    [void] (mkdir $base_archive_dir)
}

$to_archive_files = get-childitem $base_downloads_dir | ? { $_.Name -ne "archive" -and $_.CreationTime -lt (Get-Date).AddDays(-1) }

foreach($to_archive in $to_archive_files){
    $name = $to_archive.Name
    $i = 1
    while ( Test-Path "$base_archive_dir\$($name)" ) {
        $name = "$($to_archive.BaseName) ($i)$($to_archive.Extension)"
        $i+=1;
    }
    echo "Moving $($to_archive.FullName) to $base_archive_dir\$name"
    Move-Item "$($to_archive.FullName)" "$base_archive_dir\$name"
}

