# Get All Applications with .msi
$apps = Get-WmiObject -Query "SELECT * FROM win32_product"

foreach ($app in $apps) {
  Write-Host $app.Name $app.Vendor
}

# Get Application with .msi selected by name
$apps = Get-WmiObject -Query "SELECT * FROM win32_product WHERE name = 'Adobe AIR'"
Write-Host $app.Name $app.Vendor



