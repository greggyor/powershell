param(
    [string[]]$targetDirectories = $(throw "targetDirectories parameter is required"),
    [string]$size = "1920x1280"
)

function getUrl ($imageNumber) {
    $monthNumber =[System.DateTime]::Today.Month
    $monthName = [System.Globalization.DateTimeFormatInfo]::InvariantInfo.GetAbbreviatedMonthName($monthNumber).ToLower()
    $imageId = 4 * ($monthNumber - 1) + $imageNumber
    $urlFormat = "http://ecalendar.thomsonreuters.com/download.asp?size={0}&mo={1}&id={2}"

    return [String]::Format($urlFormat, $size, $monthName, $imageId)
}

function downloadWallpaper($url, $path) {
    "Downloading $url to $path"

    $webclient = New-Object System.Net.WebClient
    $webclient.DownloadFile($url, "$path")
}

1..4 | % { 
    $url = getUrl $_
    $filename = [string]::Format("tr_{0}.jpg", $_-1)

    $targetDirectories | % {
        downloadWallpaper $url "$_\$filename"
    }    
}

