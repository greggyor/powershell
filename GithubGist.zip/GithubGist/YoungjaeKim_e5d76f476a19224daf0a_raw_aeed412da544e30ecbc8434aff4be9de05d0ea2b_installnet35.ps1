# original: http://anuchandy.blogspot.kr/2014/06/automating-net-35-installation-on-azure.html
# Method that returns path to the directory holding 'installnet35.ps1' script. 
function Get-ScriptDirectory
{
  $Invocation = (Get-Variable MyInvocation -Scope 1).Value
  Split-Path $Invocation.MyCommand.Path
}

# Gets path to the local resource we reserved for manipulating the zip file.
[void]([System.Reflection.Assembly]::LoadWithPartialName("Microsoft.WindowsAzure.ServiceRuntime"))
$localStoreRoot = ([Microsoft.WindowsAzure.ServiceRuntime.RoleEnvironment]::GetLocalResource("net35resource")).RootPath.TrimEnd('\\')

# .NET 3.5 source (in blob storage)
# Note that you can also include the .NET 3.5 source zip file in the package
$net35Source = "http://<your_blob_storage_address>.blob.core.windows.net/windows-source-for-webrole/net35.zip"

# Destination path for the zip file
$net35ZipDestination = Join-Path $localStoreRoot "net35.zip"

# Use WebClient to download the the zip file
$webClient = New-Object System.Net.WebClient
$webClient.DownloadFile($net35Source, $net35ZipDestination)

# Destination path to hold the extracted files
$net35ExtractDestination = Join-Path $localStoreRoot "net35"
$pathExists = Test-Path $net35ExtractDestination
if (!$pathExists)
{
  new-item $net35ExtractDestination -itemtype directory
}

# Build command to unzip
$zipTool = (Join-Path (Get-ScriptDirectory) "\7za.exe")
$unzipCommandArgs = "x " + $net35ZipDestination + " -o$net35ExtractDestination -y"

# Unzip the file
Start-Process $zipTool $unzipCommandArgs -NoNewWindow -Wait
$net35ExtractDestination = Join-Path $net35ExtractDestination "net35"

# Install .NET 3.5 using -Source option
Install-WindowsFeature NET-Framework-Core –Source $net35ExtractDestination


