#
# HKEY_CLASSES_ROOT   2147483648
# HKEY_CURRENT_USER   2147483649
# HKEY_LOCAL_MACHINE  2147483650
# HKEY_USERS          2147483651
# HKEY_CURRENT_CONFIG 2147483653
# HKEY_DYN_DATA       2147483654
#
#

$loc = Get-Location
$dir = $loc.Path
$csvfile = $dir + "\" + $Args[0]
$outputfile = $dir + "\" + $Args[1]

function ConvertLocalTime($time)
{
    $d = [DateTime]::Parse($time)
    $lt = $d.ToLocalTime()

    return $lt.ToString()
}

function OutputTitle
{
    $title = "Name,DetectError,DetectLastTime,DownloadError,DownloadLastTime,InstallError,InstallLastTime"
    Write-Output $title | Add-Content -Encoding UTF8 $outputfile
    Write-Host $title
}

function GetUpdateRegistry($computer, $key)
{
    $hklm = 2147483650
    $wup_regpath = "SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results"
    $regpath = $wup_regpath + "\" + $key
    $wmipath = "\\" + $computer + "\root\default:stdRegProv"
    $wmi = [wmiclass]$wmipath
    
    $LastError = ($wmi.GetDWORDValue($hklm,$regpath,"LastError")).uValue
    $LastSuccessTime = ($wmi.GetStringValue($hklm,$regpath,"LastSuccessTime")).svalue

    return New-Object psobject -property @{
        LastError=$LastError;
        LastSuccessTime=$LastSuccessTime;
    }
}

function BuildRecord($computer, $detect, $download, $install)
{
    $record = $computer + ","
    if (($detect.LastError -ne $null) -and ($detect.LastSuccessTime -ne $null)) {
        $record += $detect.LastError.ToString("X") + "," + (ConvertLocalTime($detect.LastSuccessTime)) + ","
    } else {
        $record += ",,"
    }
    if (($download.LastError -ne $null) -and ($download.LastSuccessTime -ne $null)) {
        $record += $download.LastError.ToString("X") + "," + (ConvertLocalTime($download.LastSuccessTime)) + ","
    } else {
        $record += ",,"
    }
    if (($install.LastError -ne $null) -and ($install.LastSuccessTime -ne $null)) {
        $record += $install.LastError.ToString("X") + "," + (ConvertLocalTime($install.LastSuccessTime)) + ","
    } else {
        $record += ",,"
    }
    
    return $record
}

function BuildNoResponseRecord ($computer) {
    $record = "$computer,,,,,,,"

    return $record
}

function GetCurrentPCRegistry ($plist) {
    $wup_regpath = "hklm:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results"
    $wup_detect_path = $wup_regpath + "\Detect"
    $wup_download_path = $wup_regpath + "\Download"
    $wup_install_path = $wup_regpath + "\Install"

    foreach ($pc in $plist) {
        $wup_detect = Get-ItemProperty -Path $wup_detect_path
        $wup_download = Get-ItemProperty -Path $wup_download_path
        $wup_install = Get-ItemProperty -Path $wup_install_path
    
        $record = $pc.Name + "," +
                  $wup_detect.LastError + "," + (ConvertLocalTime($wup_detect.LastSuccessTime)) + "," +
                  $wup_download.LastError + "," + (ConvertLocalTime($wup_download.LastSuccessTime)) + "," +
                  $wup_install.LastError + "," + (ConvertLocalTime($wup_install.LastSuccessTime))

        Write-Output $record | Add-Content -Encoding UTF8 $outputfile
        Write-Host $record
    }
}

function GetPCRegistry ($computer) {
    $pcreg = @{}    
    $wup_regpath = "SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\Results"
    
    $pcreg.Detect = GetUpdateRegistry $computer "Detect"
    $pcreg.Download = GetUpdateRegistry $computer "Download"
    $pcreg.Install = GetUpdateRegistry $computer "Install"

    return $pcreg
}

function ProcessPc ($pc_list)
{
    foreach ($pc in $pc_list) {
        $record = $null
        $result = Test-Connection -ComputerName $pc.Name -Quiet

        if ($result) {
            $reg = GetPCRegistry $pc.Name
            $record = BuildRecord $pc.Name $reg.Detect $reg.Download $reg.Install
        } else {
            $record = BuildNoResponseRecord $pc.Name
        }
        Write-Output $record | Add-Content -Encoding UTF8 $outputfile
        Write-Host $record
    }
}

$pclist = Import-Csv $csvfile
OutputTitle
ProcessPc $pclist


