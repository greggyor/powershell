## TODO: Add header, licence ...
# Missing parts:
#  * Error handlig
#  * User friendly configuration and customization
#  * Usage info
 
 #    ===== Configuration ====    #
$SVNCMD = "C:\Program Files\TortoiseSVN\bin\svn.exe"
$BUILDTOOL = "C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"
 
# What is file name with AssemblyVersion attribute of your project
$asminfoFile = "SharedAssemblyInfo.cs"
 
$ToolInfo = "[SimpleVersioning v0.1.0]"
 
$rx = "Checked out revision (\d+)\."
$asmrx = '\[assembly: AssemblyVersion\("(\d+\.\d+\.)(-?\d+)\.(\d+)"'
$verrx = '(\s*\[assembly: AssemblyVersion\("\d+\.\d+\.)-?\d+\.\d+("\)\]\s*)'
 
$repofile = '.\repo.txt'
foreach ($repo in cat $repofile) {
  $out = (&$SVNCMD co $repo | Out-String)
  echo $repo, $out
  if ($out -match $rx) {
	$revision = $Matches[1]
	echo "Most update revision: $revision"
	
	# Get shared assembly info file and prepare version info
	$repoDir = [System.IO.Path]::GetFileName($repo)  # There is an error PS v2.0 with: Split-Path -Leaf $repo
	echo "Searching SharedAsmInfo in $repoDir repository directory"
	$sai = ls -Path $repoDir -Recurse -Filter "$asminfoFile"
	if ($sai -ne $nul) {
		echo "Found at $($sai.FullName)"
		
		$asm = (cat $sai.FullName | Out-String)
		if ($asm -match $asmrx) {
			$mm = $Matches[1]
			$build = [int]$Matches[2]
			$rev = $Matches[3]
			echo "Matched AssemblyVersion attribute value $mm$build.$rev" 
			echo "[Major.Minor] won't be modified`t`t`t : $mm"
			echo "[Build] will be increased by 1`t`t`t : $build -> $($build+1)"		
			echo "[Revision] will be current repo revision`t : $rev -> $revision"
			# Increase build number
			$build = $build + 1
			# Replace revision with last checked-out revision number
			$rev = $revision
			
			# Prepare new version string
			$asver = $mm + $build + "." + $rev
			
			# Replace asm version with prepared one
			$dummy= $asm -match $verrx
			$currAsmVersion = $Matches[0] -replace "`t|`n|`r",""
			echo "$currAsmVersion   ->  AssemblyVersion(""$asver"")"
			$asm = $asm -replace $verrx, "`${1}$build.$rev`${2}"
			echo $asm | Set-Content -Path $sai.FullName -Encoding UTF8
			
			# Build solution
			Push-Location $sai.DirectoryName
			&$BUILDTOOL
			&$SVNCMD ci $sai.Name -m "$(Get-Date -Format 'yyyyMMddHHmmss') $ToolInfo Preparing version *$asver*. Code included up to revision $rev. Build machine *$(hostname)*."
			Pop-Location
		}
	}
  }
}

## Sample output
# PS C:\Projects\Learn\AutoVersioning\build> .\build.ps1
# file:///C:/Projects/Learn/AutoVersioning/BareRepo
# A    BareRepo\tags
# A    BareRepo\trunk
# A    BareRepo\trunk\ProjectName
# A    BareRepo\trunk\ProjectName\SharedAssemblyInfo.cs
# A    BareRepo\branches
# Checked out revision 3.
# 
# Most update revision: 3
# Searching SharedAsmInfo in BareRepo repository directory
# Found at C:\Projects\Learn\AutoVersioning\build\BareRepo\trunk\ProjectName\SharedAssemblyInfo.cs
# Matched AssemblyVersion attribute value 1.0.-1.0
# [Major.Minor] won't be modified                  : 1.0.
# [Build] will be increased by 1                   : -1 -> 0
# [Revision] will be current repo revision         : 0 -> 3
# 
# [assembly: AssemblyVersion("1.0.-1.0")]  ->  AssemblyVersion("1.0.0.3")
# --  BUILD output is skiped --
# Sending        SharedAssemblyInfo.cs
# Transmitting file data .
# Committed revision 4.
#
# Commit message from auto-versioning tool:
# 20130807142723 [SimpleVersioning v0.1.0] Preparing version *1.0.0.3*. Code included up to revision 3. Build machine *NOT-EXPOSED*.

