$Session = New-PSSession -ComputerName '<ComputerName>'

    $block = { 
        import-module 'webAdministration' 

            # Call IIS cmdlets here for adding app pools, creating web site and so on
    } 

Invoke-Command -Session $Session -ScriptBlock $block


