# =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
#       Script: TW-CreateBlankClientExtranetSite.ps1
#
#       Author: Pete Skelly
#       Twitter: ThreeWillLabs
 #               http://www.threewill.com
#
#  Description: Add a blank site collection to an Office 365 tenant in SharePoint Online 
#
#       WARNING: Script provided AS IS with no warranty.  Your mileage will vary.  Use 
#               this script on a production list AT YOUR OWN RISK.          
#
#
#
# NOTES / CREDITS:  Script based on (among others) http://alexbrassington.com/2014/08/20/creating-sharepoint-site-collection-through-powershell-csom/
# Next to incorporate is the use of a WSP for Client Extranets like http://blogs.msdn.com/b/frank_marasco/archive/2014/08/10/upload-and-activate-sandbox-solutions-using-csom.aspx
#
# =+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
 

#Add the dlls required for working with Office 365
Add-Type -Path "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.dll" 
Add-Type -Path "C:\Program Files\SharePoint Online Management Shell\Microsoft.Online.SharePoint.PowerShell\Microsoft.Online.SharePoint.Client.Tenant.dll"
 
#URLs and prerequisites
$adminSiteUrl = "<tenant-admin-url>"
$newsiteUrl = "<tenant-url> + /teams/ + <site_name>"  #OR whatever you wish
$username = "<username>"
$password = Read-Host "Please enter your Password" -AsSecureString
 
Write-Host "Establishing Connection to Office 365."
#Get the context and feed in the credentials
$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($adminSiteUrl) 
$credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($username, $password)  
$ctx.Credentials = $credentials
 
Write-Host "Configuring the new Site Collection"
 
#Get the tenant object
$tenant = New-Object Microsoft.Online.SharePoint.TenantAdministration.Tenant($ctx)
 
#Set the Site Creation Properties values
$properties = New-Object Microsoft.Online.SharePoint.TenantAdministration.SiteCreationProperties
$properties.Url = $newsiteUrl
 ## TODO: DO NOT Set this and wait until the site template can be added 
$properties.Template =  "STS#0" 
$properties.Owner = $username
$properties.StorageMaximumLevel = 500
$properties.UserCodeMaximumLevel = 100
 
#Create the site using the properties
##  this is the original script 
##---  $tenant.CreateSite($properties) | Out-Null
 
#retrieve the SPO Operation return value during creation
$spOnlineOperation = $tenant.CreateSite($properties)

#load the tenant object
$ctx.Load($tenant)
#load the SPO operation
$ctx.Load($spOnlineOperation)
#run the command
$ctx.ExecuteQuery()

#wait for SPO Operation to complete
while($spOnlineOperation.IsComplete -eq $false)
{
  write-host “Waiting…” -ForegroundColor Yellow
  Start-Sleep 10
  $spOnlineOperation.RefreshLoad()
  $tenantCtx.ExecuteQuery()
}


Write-Host "Completed creation of site collection."


