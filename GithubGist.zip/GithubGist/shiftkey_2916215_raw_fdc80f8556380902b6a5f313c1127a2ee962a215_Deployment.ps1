properties {
    $BaseDir = Resolve-Path "..\"
    $SolutionFile = "$BaseDir\Cocoon.sln"
    $OutputDir = "$BaseDir\Deploy\Package\"
    $ArtifactsDir = "$BaseDir\artifacts\"
    $NuGetPackDir = Join-Path "$OutputDir" "Pack\"
    $Version = "1.0.0." + (git rev-list --all | wc -l).trim() + "-rc" # TODO: better implementation
    $Debug="false"
}

function Log-Message ($message) {
    write-host $message -foregroundcolor "green"
}

function Set-Version {
    param([Parameter(Mandatory=$true)][string]$assembly_info,[Parameter(Mandatory=$true)][string]$Version)

    $infile=get-content $assembly_info
    $regex = New-Object System.Text.RegularExpressions.Regex "\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"
    $replace = $regex.Replace($infile,$version)
    set-content -Value $replace $assembly_info
}

function Create-IfNotFound {
    param([Parameter(Mandatory=$true)][string]$Directory)

    if ((Test-Path $Directory -PathType Container) -ne $true) {
        mkdir $Directory | out-null 
    }
}

function Clear-Recursively {
    param([Parameter(Mandatory=$true)][string]$Directory)

    if (Test-Path $Directory -PathType Container) {
        ri $Directory -Recurse | out-null 
    }
}

function Create-Package {
    param([Parameter(Mandatory=$true)][string]$PackageName,[Parameter(Mandatory=$true)][string]$TempDir)

    Create-IfNotFound $TempDir
    Create-IfNotFound $ArtifactsDir
    Create-IfNotFound "$TempDir\lib\winrt45\"

    $PackageNameFile = "$PackageName.nuspec"
    $nuspecFile = "$BaseDir\build\$PackageName\$PackageName.nuspec"

    cp $nuspecFile $TempDir
    cp "$OutputDir\$PackageName\$PackageName.dll" "$TempDir\lib\winrt45\" # add initial assembly
    rm "$OutputDir\$PackageName\Cocoon.*.dll" # remove assemblies available from other Cocoon packages
    cp "$OutputDir\$PackageName\*.dll" "$TempDir\lib\winrt45\" # include other binary dependencies

    if (Test-Path "$PackageName\tools\") { # import any PS scripts for this package
        cp "$PackageName\tools\*" "$TempDir\tools\"
    }
   
    Log-Message "Modifying placeholder in nuspec file"
    $Spec = [xml](get-content "$TempDir\$PackageNameFile")
    $Spec.package.metadata.version = ([string]$Spec.package.metadata.version).Replace("{version}",$Version)
    foreach($dependency in $Spec.package.metadata.dependencies.dependency) { 
        $dependency.version = ([string]$dependency.version).Replace("{version}",$Version)
    } 

    $Spec.Save("$TempDir\$PackageNameFile")
    exec { ..\.nuget\NuGet.exe pack "$TempDir\$PackageNameFile" -Output $ArtifactsDir }
    Clear-Recursively $TempDir
}

task default -depends package

task clean {
    #git checkout -- ..\
    #git clean -df ..\
    Clear-Recursively $OutputDir
    Clear-Recursively $ArtifactsDir
}

task version -depends clean {
    Log-Message "Updating version to $version"
    foreach ($assemblyinfo in $(get-childitem -Path $BaseDir -Include "AssemblyInfo.cs" -recurse)) {
        Set-Version -assembly_info "$assemblyinfo" -Version $Version
    }
}   

task compile -depends clean,version  {
    msbuild $SolutionFile "/p:OutDir=$OutputDir" "/p:Configuration=Release"  "/verbosity:quiet"
}

task package -depends compile {
    Create-Package -PackageName "Cocoon" -TempDir $NuGetPackDir
    Create-Package -PackageName "Cocoon.Data" -TempDir $NuGetPackDir
    Create-Package -PackageName "Cocoon.MEF" -TempDir $NuGetPackDir
    Create-Package -PackageName "Cocoon.Autofac" -TempDir $NuGetPackDir
}

