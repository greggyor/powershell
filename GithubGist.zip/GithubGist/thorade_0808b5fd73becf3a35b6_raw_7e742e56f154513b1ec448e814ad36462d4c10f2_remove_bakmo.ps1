# This Windows PowerShell script 
#	recursively deletes Dymola *.bak-mo backup files 
#   from all folders below itself

# get current directory
$curDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# delete files
get-childitem $curDir -include *.bak-mo -recurse | foreach ($_) {remove-item $_.fullname}

