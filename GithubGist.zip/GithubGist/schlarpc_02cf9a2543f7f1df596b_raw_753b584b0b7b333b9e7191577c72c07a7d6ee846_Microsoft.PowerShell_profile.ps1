(Get-Host).UI.RawUI.WindowTitle = "Windows PowerShell"

function Get-DirAlias ([string]$loc) {
    return $loc.Replace($env:homedrive + $env:homepath, "~")
}

function prompt {
    Write-Host "$env:username@$env:computername" -NoNewLine -ForegroundColor Green
    Write-Host ":" -NoNewLine
    Write-Host "$(Get-DirAlias($(Get-Location)))" -NoNewLine -ForegroundColor Cyan
    return "$ "
}


