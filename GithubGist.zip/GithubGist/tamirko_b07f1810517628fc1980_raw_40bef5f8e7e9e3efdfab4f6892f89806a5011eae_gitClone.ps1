if ($ENV:GSA_MODE -ne "agent") {
	# Create the git clone service/task here ….  
	$javaExe = "$javaDir\bin\java"
	$gitUtilZipName = "gitUtil.zip"
	$gitUtilZipUrl = "REPLACE_THIS_WITH_FULL_URL/$gitUtilZipName"
	$gitUtilLocalZip = "$parentDirectory\$gitUtilZipName"
	$gitUtilFolder = "$parentDirectory\gitutil"
	$destGitFolder = "$parentDirectory\gigaspaces\work\cloudify_recipes_clone"
	$gitRepoUrl = "git@github.com:CloudifySource/cloudify-recipes.git"
	
	Write-Host "Downloading the git clone utility from $gitUtilZipUrl to $gitUtilLocalZip ..."
	download $gitUtilZipUrl $gitUtilLocalZip
	
	Write-Host "Unzipping the git clone utility ( $gitUtilLocalZip ) to $gitUtilFolder ..."
	unzip $gitUtilLocalZip $gitUtilFolder
	
	Write-Host "Creating the git clone (cloudify-git) task to run every 10 minutes ..."
	schtasks.exe /create /TN cloudify-git /IT /SC MINUTE /MO 10 /TR "$gitUtilFolder\MyGitGetter.bat $javaExe $gitUtilFolder $destGitFolder $gitRepoUrl" /RU $ENV:USERNAME /RP $ACTUAL_PASSWORD
	Write-Host "running the cloudify-git task"
	schtasks.exe /run /TN cloudify-git

	Write-Host "Created and ran the cloudify-git task"
}
 
Write-Host "Remote execution ended successfully"
exit 0

