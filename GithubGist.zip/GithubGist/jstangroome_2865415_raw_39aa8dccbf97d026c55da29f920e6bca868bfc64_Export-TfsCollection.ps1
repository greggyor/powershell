[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]
    $ServerUrl,

    [Parameter(Mandatory=$true)]
    [string]
    $Name,

    [Parameter(Mandatory=$true)]
    [string]
    $ExportPath
)

function Get-Collection (
    $ConfigurationServer,
    $Name
) {
    $CollectionService = $ConfigurationServer.GetService([Microsoft.TeamFoundation.Framework.Client.ITeamProjectCollectionService])
    $Collection = $CollectionService.GetCollections() |
        Where-Object { $_.Name -eq $Name } |
        Select-Object -First 1
    if (-not $Collection) { 
        throw "$($MyInvocation.MyCommand): Collection '$Name' not found"
    }
    return $Collection
}

function Detach-Collection (
    $ConfigurationServer, 
    $Collection
) {
    $CollectionService = $ConfigurationServer.GetService([Microsoft.TeamFoundation.Framework.Client.ITeamProjectCollectionService])

    $ServicingTokens = $null
    $StopMessage = "$($MyInvocation.MyCommand): Export started $(Get-Date)"
    $ConnectionString = ''
    $Job = $CollectionService.QueueDetachCollection($Collection, $ServicingTokens, $StopMessage, [ref]$ConnectionString)

    $ResultCollection = $CollectionService.WaitForCollectionServicingToComplete($Job)

    return (New-Object -TypeName PSObject -Property @{
        CollectionName = $Name
        ConnectionString = $ConnectionString
    })
}

function Attach-Collection (
    $ConfigurationServer, 
    $ConnectionString
) {
    $CollectionService = $ConfigurationServer.GetService([Microsoft.TeamFoundation.Framework.Client.ITeamProjectCollectionService])

    $AttachServicingTokens = $null
    $CloneCollection = $false
    $Job = $CollectionService.QueueAttachCollection($ConnectionString, $AttachServicingTokens, $CloneCollection)

    $Collection = $CollectionService.WaitForCollectionServicingToComplete($Job)

    if ($Collection.State -ne 'Started') {
        throw "$($MyInvocation.MyCommand): Collection at '$ConnectionString' was not attached"

    }

    Write-Verbose "$($MyInvocation.MyCommand): Collection '$($Collection.Name)' attached"
    return $Collection
}

function Backup-Collection ($ConnectionString, $Path) {
    $CSBuilder = New-Object -TypeName System.Data.SqlClient.SqlConnectionStringBuilder -ArgumentList $ConnectionString
    $DatabaseName = $CSBuilder.InitialCatalog
    $BackupFilePath = $Path | Join-Path -ChildPath "$DatabaseName.bak"

    if (Test-Path -Path $BackupFilePath) {
        Remove-Item -Path $BackupFilePath
    }

    $Connection = New-Object -TypeName System.Data.SqlClient.SqlConnection
    $Connection.ConnectionString = $CSBuilder.ConnectionString
    $Connection.Open()
    try {
        $Command = $Connection.CreateCommand()
        $Command.CommandType = 'Text'
        $Command.CommandText = "BACKUP DATABASE [{0}] TO DISK = N'{1}' WITH COPY_ONLY, COMPRESSION, STATS" -f $DatabaseName, $BackupFilePath
        $Command.CommandTimeout = (New-TimeSpan -Minutes 10).TotalSeconds
        $Command.ExecuteNonQuery() | Out-Null
        $Command.Dispose()
    } catch {
        Write-Warning "$($MyInvocation.MyCommand): Backup failed. $_"
    } finally {
        $Connection.Close()
    }

    Get-Item -Path $BackupFilePath
}

$script:ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$PSScriptRoot = $MyInvocation.MyCommand.Path | Split-Path

Add-Type -AssemblyName System.Web

'Microsoft.TeamFoundation.Client',
'Microsoft.TeamFoundation.Common' |
    ForEach-Object {
        Add-Type -AssemblyName "$_, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
    }

$Server = New-Object -TypeName Microsoft.TeamFoundation.Client.TfsConfigurationServer -ArgumentList $ServerUrl
$CollectionService = $Server.GetService([Microsoft.TeamFoundation.Framework.Client.ITeamProjectCollectionService])

Write-Verbose "$($MyInvocation.MyCommand): Finding collection '$Name'"
$Collection = Get-Collection -ConfigurationServer $Server -Name $Name
$Name = $Collection.Name

Write-Verbose "$($MyInvocation.MyCommand): Detaching collection '$Name'"
$DetachedCollection = Detach-Collection -ConfigurationServer $Server -Collection $Collection

Write-Verbose "$($MyInvocation.MyCommand): Backing up database for collection '$Name'"
try {
    $BackupItem = Backup-Collection -ConnectionString $DetachedCollection.ConnectionString -Path $ExportPath
} catch {
    Write-Warning "$($MyInvocation.MyCommand): Backup failed"
}

Write-Verbose "$($MyInvocation.MyCommand): Re-attaching collection '$Name'"
$Collection = Attach-Collection -ConfigurationServer $Server -ConnectionString $DetachedCollection.ConnectionString


