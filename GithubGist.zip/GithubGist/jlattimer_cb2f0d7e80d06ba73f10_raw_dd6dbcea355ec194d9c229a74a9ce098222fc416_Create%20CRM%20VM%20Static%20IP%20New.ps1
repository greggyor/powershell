<# Make sure you have installed the Azure PowerShell cmdlets: https://www.windowsazure.com/en-us/manage/downloads/ and then reboot #>

<# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    The steps need to be run individually 
   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #>

<# Step 1: Run this first to download your publisher file from Azure #>
Get-AzurePublishSettingsFile

<# Step 2: Change the path to the file you downloaded: C:\xxx\xxx.publishsettings #>
$publisherFileLocation = "C:\xxx\xxx.publishsettings"
Import-AzurePublishSettingsFile $publisherFileLocation

<# Step 3: Input the 'Name' of the subscription from the output of the previous step #>
$subscriptionName = "Visual Studio Ultimate with MSDN"
Select-AzureSubscription -SubscriptionName $subscriptionName

<# Step 4: Run this to output the list of Azure storage accounts associated with your account #>
Get-AzureStorageAccount 

<# Step 5: Input the subscription 'Name' again and the 'StorageAccountName' from the output of the previous step
when the VM gets created it will use that Azure Storage account #>
$sortageAccountName = "portalxxxxxxxxxxxxxxxxx" 
Set-AzureSubscription -SubscriptionName $subscriptionName -CurrentStorageAccount $sortageAccountName

<# Step 6: Create a reserved/static IP for your VM - input the name/label and the region your VM will be in #>
$reservedIPName = "CRMIP"
$reservedIPLabel = "CRMIP"
$location = “North Central US” 
New-AzureReservedIP –ReservedIPName $reservedIPName –Label $reservedIPLabel –Location $location
<# Use this to remove the reserved IP if you end up not needing it #>
<# Remove-AzureReservedIP -ReservedIPName "CRMIP" -Force# >
<# Show the list of reserved IP addresses if you are interested #>
<# Get-AzureReservedIP #>

<# Step 7: Run this to output the list of Azure VM images to base the server on, Windows Server 2012 R2 for example #>
$images = Get-AzureVMImage
$images | where {$_.Label -like 'windows server 2012 r2*'} | select Label, RecommendedVMSize, PublishedDate | Format-Table -AutoSize

<# Step 8: Input the the 'Label' and 'Publish Date' of the specific image you want to start with #>
$vmImage = Get-AzureVMImage `
    | Where-Object -Property ImageFamily -ilike "Windows Server 2012 R2*" `
    | Sort-Object -Descending -Property PublishedDate `
    | Select-Object -First(1)

Write-Output $imageName

<# Step 9: Input the VM & cloud service names, VM size, and admin username & password and create the VM #>
$vmName = "CRM2015"
$cloudServiceName = "CRM2015"
$instanceSize = "ExtraLarge"
$adminUsername = "crmadmin"
$adminPassword = "Str0ngP@ssw0rd?"
New-AzureVMConfig -Name $vmName -InstanceSize $instanceSize -ImageName $vmImage.ImageName | 
    Add-AzureProvisioningConfig -Windows -AdminUsername $adminUsername -Password $adminPassword |
    Add-AzureEndpoint -Name "HTTP" -Protocol "tcp" -PublicPort 80 -LocalPort 80 | 
    Add-AzureEndpoint -Name "HTTPS" -Protocol "tcp" -PublicPort 443 -LocalPort 443 |
    Add-AzureEndpoint -Name "HTTPS2" -Protocol "tcp" -PublicPort 444 -LocalPort 444 | <# Only if you need ADFS on the same server #>
    Add-AzureEndpoint -Name "Remote Desktop" -Protocol "tcp" -PublicPort 60523 -LocalPort 3389 |
    New-AzureVM -ServiceName $cloudServiceName -ReservedIPName $reservedIPName -Location $location

