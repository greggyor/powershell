Function Invoke-LoadMethod() {
param(
   $ClientObject = $(throw "Please provide an Client Object instance on which to invoke the generic method")
) 
   $ctx = $ClientObject.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load") 
   $type = $ClientObject.GetType()
   $clientObjectLoad = $load.MakeGenericMethod($type) 
   $clientObjectLoad.Invoke($ctx,@($ClientObject,$null))
}


