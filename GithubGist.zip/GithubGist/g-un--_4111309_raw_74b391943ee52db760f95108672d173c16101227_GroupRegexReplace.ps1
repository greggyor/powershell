"Test 1.1.1.1" -replace "(?<first>\d+\.\d+\.\d+\.)\d+", '${1}2'

