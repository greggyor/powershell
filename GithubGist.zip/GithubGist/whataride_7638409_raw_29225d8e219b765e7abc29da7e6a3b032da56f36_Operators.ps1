# Arithmatic operators


# Comparison operators
# -eq, -lt, -gt, -ge, -le, -ne

# Logical operators
# -not, ! (the same as -not), -and, -or

# Conditional operators
# -Match (-NotMatch for negative), -Like (-NotLike, -CLike that force case sensitivity)
# -Contains, -NotIn
$Guy ="Guy Thomas 1949"
$Guy -Match "Th"
# Result PS> True

# one can use wild card ? and *
$Guy ="Guy Thomas 1949"
$Guy -Match "19?9"
# Result PS> True

Get-WmiObject -List | Where {$_.name -Match "cim*"}

# -Match operator can also work on character classes; think of any regex expression 
# \w matches any word character, meaning letters and numbers.
# \s matches any white space character, such as tabs, spaces, and so forth.
# \d matches any digit character.
$Guy ="Guy Thomas 1949"
$Guy -Match "\w"
# Result PS> True

# -Like check if two strings are the same
$Guy ="Guy Thomas 1949"
$Guy -Like "Th"
# Result PS> False

$Guy ="Guy Thomas 1949"
$Guy -Like "Guy*"
# Result PS> True

$Guy ="Guy Thomas 1949"
$Guy -Like "*Th*"
# Result PS> True


