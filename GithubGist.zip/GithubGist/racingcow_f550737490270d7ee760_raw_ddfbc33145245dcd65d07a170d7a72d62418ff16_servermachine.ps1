############################################################

# Join domain

############################################################

# Rename-Computer -NewName DEVCE1 -LocalCredential admin

# if (Test-PendingReboot) { Invoke-Reboot }

# Add-Computer -DomainName CT -Credential CT\imagioprodsvc 

# if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# Boxstarter options

############################################################

$Boxstarter.RebootOk=$true # Allow reboots?

$Boxstarter.NoPassword=$false # Is this a machine with no login password?

$Boxstarter.AutoLogin=$true # Save my password securely and auto-login after a reboot

############################################################

#basic setup

############################################################

Update-ExecutionPolicy Unrestricted

Set-ExplorerOptions -showHidenFilesFoldersDrives -showProtectedOSFiles -showFileExtensions

Enable-RemoteDesktop

Disable-InternetExplorerESC

Disable-UAC

Set-TaskbarSmall

Write-BoxstarterMessage "Setting time zone to Central Standard Time"
& C:\Windows\system32\tzutil /s "Central Standard Time"

cinst Microsoft-Hyper-V-All -source windowsFeatures

cinst IIS-WebServerRole -source windowsfeatures

cinst IIS-HttpCompressionDynamic -source windowsfeatures

cinst IIS-WindowsAuthentication -source windowsfeatures

cinst DotNet3.5

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# Update Windows and reboot if necessary

############################################################

Install-WindowsUpdate -AcceptEula

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# utils, plugins, frameworks, and other miscellany

############################################################

cinst javaruntime

cinst webpi

cinst adobereader

cinst flashplayeractivex

cinst flashplayerplugin

cinst AdobeAIR

cinst 7zip

cinst PDFCreator

cinst lockhunter

cinst windirstat

cinst ransack

if (Test-PendingReboot) { Invoke-Reboot }



############################################################

# development

############################################################

cinst DotNet3.5 # Not automatically installed with VS 2013. Includes .NET 2.0. Uses Windows Features to install.

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# text editors

############################################################

cinst notepadplusplus.install

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# browsers

############################################################

cinst GoogleChrome

cinst GoogleChrome.Canary

cinst Firefox

cinst Opera

cinst safari

cinst lastpass

if (Test-PendingReboot) { Invoke-Reboot }

