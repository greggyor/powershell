$tr = New-Object system.Xml.XmlTextReader("c:\metrics\scripts\out.xml")
$tw = New-Object system.Xml.XmlTextWriter("c:\metrics\scripts\fullmig.xml",$null)
$tw.WriteStartDocument()

# Our document will resemble something like this:
############
# <Objects>
#   <Object>
#  <!-- Scenario 1: regular key/value -->
#     <Property Name="Key">[Key]</Property>
#     <Property Name="Value">[Value]</Property>
#  <!-- Scenario 2: blank value -->
#     <Property Name="Key">[Key]</Property>
#     <Property Name="Value" />
#  <!-- Scenario 3: scalar array value -->
#     <Property Name="Key">[Key]</Property>
#     <Property Name="Value">
#       <Property>[Value 1]</Property>
#       <Property>[Value 2]</Property>
#       ...
#     </Property>
#  <!-- Scenario 4: nested hashtable -->
#     <Property Name="Key">[Key]</Property>
#     <Property Name="Value">
#       <Property>
#         <Property Name="Key">[Key]</Property>
#         <Property Name="Value">[Value]</Property>
#         ...
#       </Property>
#     </Property>
#   </Object>
# </Objects>
############
# In the root scenario, <Objects/> is the collection of web applications, and each <Object/> is
# a separate web application. Because we're importing from a hashtable, sibling Keys and Values
# correspond to a variable, so the goal is to read them sequentially and output something like
# <[KeyName]>[Value]</[KeyName]>. However, since this is a very deeply nested hashtable (plus
# scalar arrays), it's not exactly that simple, hence the four extra scenarios.
############

while($tr.Read()) {
  switch($tr.NodeType) {
    Element    {
      switch($tr.Name) {
        Objects  { $tw.WriteStartElement('WebApps'); break }
        Object   { $tw.WriteStartElement('WebApp');  break }
        Property {

# Poll for attributes weeds out scenario 3/scalar array
          if($tr.HasAttributes) {

# Keys are easy to deal with
            if($tr.GetAttribute('Name') -eq 'Key') {
              [void]$tr.Read()                  # Skip to the value
              $tw.WriteStartElement($tr.Value)  # Start a new element based on the value
              [void]$tr.Read()                  # Skip the closing element
            } else {                            # Either <Property Name="Value"> or <Property>

# Handle scenario 2 with a self-closing tag check, otherwise the next read will skip it
              if($tr.IsEmptyElement) { $tw.WriteEndElement() }              
              [void]$tr.Read()                  # Skip the opening

# Handle scenario 1, which is regular text
              if($tr.HasValue) { $tw.WriteValue($tr.Value) }

# Handle scenarios 3+4, start a new <Item> if current node isn't text or an EndElement
              elseif($tr.NodeType -ne 'EndElement') { $tw.WriteStartElement('Item') }
# Lack of a regular "else" here also handles scenarios 3+4 by letting a leftover EndElement be
# caught by the outside switch()
            }

# Handle scenario 3 by creating a plain <Item> node
          } else { $tw.WriteStartElement('Item') }
        }
      } break;
    }

# Handle scenario 1 (regular text value)
    Text       { $tw.WriteValue($tr.Value); break }
# Handle scenario 2 (blank value)
    EndElement { $tw.WriteEndElement(); break }
  }
}

$tr.Close()
$tw.Flush()
$tw.Close()

