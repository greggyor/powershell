clear
$regpath = "HKCU:\Software\SimonTatham\PuTTY\Sessions"
$sessions = gci -path $regpath
foreach($session in $sessions){
    $fixedsession = $session -replace 'HKEY_CURRENT_USER','HKCU:'
    $sessionname = Split-Path $fixedsession -Leaf
    Write-Host $($sessionname -replace 'RS:|%20|.public.','')  `t`t    $(Get-ItemProperty -path $fixedsession).HostName
    }


