function show-all-project-branches
{
	$Workspace = "C:\Workspace\"
	$InitialLocation = Get-Location
	
	function show-repo-branch($dir)
	{
		$GitDir = $dir.FullName + "\.git"
		$IsRepository = Test-Path $GitDir
		
		if (!$IsRepository) { return }
	 
		cd $dir.FullName
		$CurrentBranch = git rev-parse --abbrev-ref HEAD 
	 
		Write-Host "$dir`:  $CurrentBranch"
	}
	
	Get-ChildItem -Directory $Workspace | foreach { show-repo-branch($_); }
	cd $InitialLocation
}

