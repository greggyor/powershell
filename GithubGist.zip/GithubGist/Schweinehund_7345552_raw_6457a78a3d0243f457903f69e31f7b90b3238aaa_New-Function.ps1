Function New-Function 
{
<#
#>
	[CmdletBinding()]
	PARAM
	(
	[Parameter(Mandatory=$true)]
	[String]
	$Parameter
	)
	
	BEGIN{}
	PROCESS{}
	END{}
}

