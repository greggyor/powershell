# Check if Servers on Text List exist on VMware
# Assumes that the VM object name matches the server's DNS name

# Set this to the text file containing the list of servers, one per line
$strServerList = "C:\path\to\textFile.txt"

# Create empty array for servers which are found
$arrFoundServers = @()

# Assign all of the VM objects to a variable
$objVMs = Get-VM

# Read the list of servers, and assign it to a variable
$strServersOnList = (Get-Content -Path $serverlist)

# Loop through each VM
ForEach ($objVM in $objVMs){
	# Loop through each server on the list
	ForEach ($strServer in $strServersOnList){
		# If the current VM object name matches the current item on the list
		If ($objVM.Name -Like $strServer){
			# Add it to the array of found machines
			$arrFoundServers += $objVM
		}
	}
}

# Display the list of found machines
$arrFoundServers

