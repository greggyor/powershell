function Read-IIS7Log
{
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $Path
    )
    Get-Content -Path $Path |
    ?{$_.ToString().StartsWith("#") -eq $false }| 
    % {
        if ($_ -notmatch "^(?<date>.*?) (?<time>.*?) (?<s_ip>.*?) (?<cs_method>.*?) (?<cs_uri_stem>.*?) (?<cs_uri_query>.*?) (?<s_port>.*?) (?<cs_username>.*?) (?<c_ip>.*?) (?<useragent>.*?) (?<sc_status>.*?) (?<sc_substatus>.*?) (?<sc_win32_status>.*?) (?<time_taken>.*?)$") {
            throw "Invalid line: $_"
        }
        $entry = $matches
        $entry.DateTime = (Get-Date ($entry.date + " " + $entry.time)).AddHours(+9)
        New-Object PSObject -Property $entry
    }
}

Export-ModuleMember -Function Read-IIS7Log

