# ----------------------------------------------------------------------------- 
# Script: netapp_volume_report.ps1 
# Author: @espennilsen
# Date: 12/30/2013
# Keywords: volume, report
# comments: Creates report of all volumes on a netapp controller
# 
# ----------------------------------------------------------------------------- 
param(  
        [Parameter(Mandatory=$true,ValueFromPipeline=$True,HelpMessage="Enter the FQDN of your NetApp 7-MODE Controller")]  
        $Controller,
        [Parameter(Mandatory=$true,ValueFromPipeline=$True,HelpMessage="Enter the Username for Accessing the Controller")]  
        $UserName,
        [Parameter(Mandatory=$true,ValueFromPipeline=$True,HelpMessage="Enter the Password for Accessing the Controller")]  
        $Password  
      ) 

Import-Module DataONTAP -ErrorAction SilentlyContinue

$ControllerPassword = ConvertTo-SecureString -String $Password -AsPlainText -force
$ControllerCredential = New-Object System.Management.Automation.PsCredential($UserName,$ControllerPassword)
$Location = ".\volume reports\"

#Create $Location if it doesn't exist
if(!(Test-Path -Path $Location )){
    New-Item -ItemType directory -Path $Location
}

Foreach ($filer in $controller)
{

Connect-NaController -Name $filer -Credential $ControllerCredential

Write-Verbose "Collecting Volume Information for $filer" -Verbose



Get-NaVol | Select @{Name="VolumeName";Expression={$_.name}},@{Name="TotalSize(GB)";Expression={[math]::Round([decimal]$_.SizeTotal/1gb,2)}},@{Name="AvailableSize(GB)";Expression={[math]::Round([decimal]$_.SizeAvailable/1gb,2)}},@{Name="UsedSize(GB)";Expression={[math]::Round([decimal]$_.SizeUsed/1gb,2)}},@{Name="SnapshotBlocksReserved(GB)";Expression={[math]::Round([decimal]$_.SnapshotBlocksReserved/1gb,2)}}`
,SnapshotPercentReserved,Aggregate,IsDedupeEnabled,type,DiskCount,RaidStatus,Autosize,ChecksumStyle,state | Export-Csv $Location\$(get-date -f yyyy-MM-dd)-$filer-volumes.csv -Delimiter ";" -Force -NoTypeInformation -Verbose


Write-Verbose "Completed Collecting Volume Information for $filer" -Verbose

}







