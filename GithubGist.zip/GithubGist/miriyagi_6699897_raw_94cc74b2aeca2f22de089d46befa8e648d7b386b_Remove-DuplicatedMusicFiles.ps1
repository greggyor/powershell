Get-ChildItem -Hidden -Recurse . | %{
    [string] $originalFileName = (($_.FullName -replace ' 1\.m4a$', '.m4a') -replace '-YUKI\.m4a', '.m4a')
    if ($originalFileName -ne $_.FullName -and (Test-Path -LiteralPath $originalFileName)) {
        Remove-Item -Force -LiteralPath $_.FullName
    }
}

