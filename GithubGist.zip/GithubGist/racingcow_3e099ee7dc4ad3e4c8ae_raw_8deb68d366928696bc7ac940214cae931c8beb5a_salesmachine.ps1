############################################################

# Join domain

############################################################

#Rename-Computer -NewName devmachine -LocalCredential admin

#Add-Computer -DomainName CT -Credential CT\dmiller

############################################################

# Boxstarter options

############################################################

$Boxstarter.RebootOk=$true # Allow reboots?

$Boxstarter.NoPassword=$false # Is this a machine with no login password?

$Boxstarter.AutoLogin=$true # Save my password securely and auto-login after a reboot

############################################################

#basic setup

############################################################

Update-ExecutionPolicy Unrestricted

Set-ExplorerOptions -showHidenFilesFoldersDrives -showProtectedOSFiles -showFileExtensions

Enable-RemoteDesktop

Disable-InternetExplorerESC

Disable-UAC

Set-TaskbarSmall

Write-BoxstarterMessage "Setting time zone to Central Standard Time"
& C:\Windows\system32\tzutil /s "Central Standard Time"

cinst Microsoft-Hyper-V-All -source windowsFeatures

cinst DotNet3.5

cinst DotNet4.5.1

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# Update Windows and reboot if necessary

############################################################

Install-WindowsUpdate -AcceptEula

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# utils, plugins, frameworks, and other miscellany

############################################################

cinst javaruntime

cinst webpi

cinst adobereader

cinst flashplayeractivex

cinst flashplayerplugin

cinst AdobeAIR

cinst 7zip

cinst zoomit

cinst PDFCreator

cinst lockhunter

cinst windirstat

cinst teamviewer

cinst ransack

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# communications

############################################################

# cinst HipChat # <- seems to be old adobe air version

cinst skype

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# text editors

############################################################

cinst evernote

cinst notepadplusplus.install

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# browsers

############################################################

cinst GoogleChrome

cinst Firefox

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# to the cloud!

############################################################

cinst dropbox

if (Test-PendingReboot) { Invoke-Reboot }

cinst ShrewSoftVpn

if (Test-PendingReboot) { Invoke-Reboot }

