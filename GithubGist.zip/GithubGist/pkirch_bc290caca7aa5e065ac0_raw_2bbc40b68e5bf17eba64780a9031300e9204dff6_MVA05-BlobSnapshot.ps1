# step 1: get file
$blobFile = Get-AzureStorageBlob -Container source | Where-Object -Property Name -eq "version.txt"

# step 2: create snapshot
$cloudBlob = $blobFile.ICloudBlob
$cloudBlob.CreateSnapshot()

# step 3: get snapshots
$snapshot = Get-AzureStorageBlob -Container source | Where-Object -Property SnapshotTime

# step 4: download snapshot
$snapshot[0] | Get-AzureStorageBlobContent

