if(!(Test-Path *.sln)) {
    echo ($pwd.Path + " is not a vs solution folder")
}
else {
    #remove .nuget folder
    Remove-Item .nuget -Recurse

    #remove .nuget sln folder
    Get-Item *.sln | ForEach-Object {
        $c = [System.IO.File]::ReadAllText($_.Fullname)
        $c -replace '(?s)Project\("\{2150E333-8FDC-42A3-9474-1A3956D46DE8\}"\) = "\.nuget",.*?EndProjectSection.*?EndProject', "" | 
        Set-Content $_.FullName
    }

    #remove package restore from .csproj
    Get-Item *\*.csproj | ForEach-Object {
        $pc = Get-Content $_ | Where-Object {
            $_ -notmatch '<RestorePackages>true</RestorePackages>' -AND $_ -notmatch 'nuget.targets'
        }

        Set-Content ($_.FullName) $pc
    }
}

