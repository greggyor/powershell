# First N in file listing
function doSomething {}
ls $directory | select -first 10 | %{ &doSomething }

# Shutdown a list of machines with a name scheme of "machine-prefix-", numbered from 1-12
(0..12) | %{ shutdown -r -t 0 -f -m $("machine-prefix" + "{0:D2}" -f $_) }

