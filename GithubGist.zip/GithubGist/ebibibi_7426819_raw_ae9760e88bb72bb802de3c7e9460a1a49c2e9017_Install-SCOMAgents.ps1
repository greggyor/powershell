#This script installs SCOM agents to several clients.
#
#ex)
#.\Install-SCOMAgent.ps1 -ServerName scomserver.domain.name -Targets @("client1.domain.name", "client2.domain.name")

Param(
    [parameter(mandatory=$true)]$ServerName,
    [parameter(mandatory=$true)]$Targets
)

$InstallAccount = Get-Credential
$session = New-PSSession -ComputerName $ServerName -Credential $InstallAccount

Invoke-Command -Session $session -ScriptBlock {
    Import-Module OperationsManager
    foreach($Target in $using:Targets) {
        Write-Host "Install SCOM Agent to $Target ..."
        $PrimaryMgmtServer = Get-SCOMManagementServer -Name $using:ServerName
        Install-SCOMAgent -Name $Target -PrimaryManagementServer $PrimaryMgmtServer -ActionAccount $using:InstallAccount
    }
}

