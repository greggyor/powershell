# This is a powershell script which uses
# TwitProxy (https://twitproxy.heroku.com/) for updating twitter.
# Twittering using Windows Powershel
# Usage: .\Tweet.ps1 <the tweet>

[System.Reflection.Assembly]::LoadWithPartialName("System.Web") | out-null
$text = [System.Web.HttpUtility]::UrlEncode($args);
# Use your token here!
# Go to https://twitproxy.heroku.com/ and get one
$the_token = "";
$the_secret = "";
# Yes this needs to be filled in (TwitProxy is still a Beta)
$some_random_location = "&lat=0.000000&long=0.000000";


$url = "https://twitproxy.heroku.com/update?token=" + $the_token + "&secret=" + $the_secret + "&msg=" + $text + $some_random_location;
$r = [System.Net.WebRequest]::Create($url)
$resp = $r.GetResponse()
$reqstream = $resp.GetResponseStream()
$sr = new-object System.IO.StreamReader $reqstream
$result = $sr.ReadToEnd()
write-host $result 

