#
#    SharePoint must be configured to allow Remote Endpoint intranet calls to local web services by using the following Windows PowerShell commands. 
# 
Add-PSSnapin Microsoft.sharepoint.powershell 

$f = Get-SPFarm 
$f.Properties.DisableIntranetCalls = $false 
$f.Properties.DisableIntranetCallsFromApps = $false 
$f.Update()

