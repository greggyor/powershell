try {
    cinst javaruntime
    #cinst Gmac.TeamCity
    Set-ExplorerOptions -showHiddenFilesFoldersDrives -showProtectedOSFiles -showFileExtensions
    Install-WindowsUpdate -AcceptEula
    Write-ChocolateySuccess 'Setup-BuildServer'
} catch {
  Write-ChocolateyFailure 'Setup-BuildServer' $($_.Exception.Message)
  throw
}

