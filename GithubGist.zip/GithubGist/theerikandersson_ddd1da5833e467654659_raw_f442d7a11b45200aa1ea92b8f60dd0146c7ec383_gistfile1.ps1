# -------- config-parameters ------------

# db config
$userid = "{uid}"
$password = "{pwd}"
$connstring = "Data Source={server};Initial Catalog={db};User Id={0};Password={1}" -f $userid,$password

# output file config
$outpath = "{output folder}"
$filprefix = "{prefix for saved file}"

# sql config
$sql = "{select query or sp or what not}"

# ----end of config parameters-------------



Add-Type -AssemblyName System.Data 


$conn = New-Object System.Data.SqlClient.SqlConnection($connString) 
$adapter = New-Object System.Data.SqlClient.SqlDataAdapter($sql,$conn)
$adapter.SelectCommand.CommandTimeout = 1800 # 30 min timeout
$dt = New-Object System.Data.DataTable

$adapter.Fill($dt)

$csv = $dt | Convertto-Csv  -Delimiter ";" -NoTypeInformation
 
$csvstripped = $csv -Replace '"',""

$csvpath = [System.IO.Path]::Combine($outpath, "{0}_{1}.csv" -f @($filprefix, [DateTime]::Now.ToString("yyyyMMddHHmmss")))

$csvstripped | Set-Content -Path $csvpath 

Write-Host "Done!"

