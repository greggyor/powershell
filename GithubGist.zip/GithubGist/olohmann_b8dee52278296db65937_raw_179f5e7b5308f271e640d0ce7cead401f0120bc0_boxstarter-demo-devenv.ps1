# In PoSh: START http://boxstarter.org/package/nr/url?https://gist.githubusercontent.com/olohmann/b8dee52278296db65937/raw/71f8768586f6be4b4fe2dccac8384d16333b9fc1/boxstarter-demo-devenv.ps1   
# Boxstarter Script to prep a simple Dev Demo Box.

# Allow reboots
$Boxstarter.RebootOk=$true
$Boxstarter.NoPassword=$false
$Boxstarter.AutoLogin=$true

# Basic setup
Update-ExecutionPolicy Unrestricted
Set-ExplorerOptions -showHidenFilesFoldersDrives -showProtectedOSFiles -showFileExtensions

if (Test-PendingReboot) { Invoke-Reboot }

# Update Windows and reboot if necessary
Install-WindowsUpdate -AcceptEula

if (Test-PendingReboot) { Invoke-Reboot }

# Browsers
cinst google-chrome-x64
cinst firefox

# Tools
cinst sysinternals
cinst 7zip.install
cinst git.install
cinst sublimetext3
cinst sublimetext3.packagecontrol
cinst sublimetext3.powershellalias

cinst nodejs.install
cinst sourcetree
cinst fiddler4
cinst consolez

# Pins
Install-ChocolateyPinnedTaskBarItem "$($Boxstarter.programFiles86)\Google\Chrome\Application\chrome.exe"
Install-ChocolateyPinnedTaskBarItem "$($Boxstarter.programFiles86)\Mozilla Firefox\firefox.exe"
Install-ChocolateyPinnedTaskBarItem "$($Boxstarter.programFiles)\Sublime Text 3\sublime_text.exe"


