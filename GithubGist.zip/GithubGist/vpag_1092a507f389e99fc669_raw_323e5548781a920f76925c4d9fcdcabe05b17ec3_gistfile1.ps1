# get help
Get-Help <subj> -Online
Get-Help <subj> -ShowWindow

# grep -f
GetContent -Wait
#  gc  # alias

# WMI
Get-WmiObject <class> | Get-Member
Get-WmiObject <class> | Select-Object *
Get-WmiObject -Namespace "root/default" -List
(Get-WmiObject -Class Win32_Service -Filter "name='WinRM'").StopService()
Get-WmiObject <class> -ComputerName <hostA>, <hostB> -Credential administrator
Get-WMIObject -Query "Associators of {Win32_Service.Name='Winmgmt'} Where ResultRole=Antecedent" | Select-Object *
#  gwmi  # alias

# select/filter
Get-Process | Where-Object {$_.handles -ge 200}
Get-Content C:\Scripts\Test.txt | Select-String "\(\d{3}\)-\d{3}-\d{4}"


