$remoteservices = invoke-command -computer eaglexa1 -scriptblock {
    $a = Get-Service
    $b = Get-Process
    return $a
}

$remoteservices | Format-Table -Property Name,Status

