function Get-URL([string] $url) {
	(New-Object net.webclient).DownloadString($url)
}



