param([string]$filename, [string]$fullname)

$tempZ = "c:\temp\$filename.7z"

if (!(get-S3Object -BucketName database-backups -key (split-path $tempZ -leaf))) {
    exit 1
}
Read-S3Object -BucketName database-backups -key (split-path $tempZ -leaf) -File $tempZ

C:\7za.exe x $tempZ
mv "$filename" "$fullname"
rm $tempZ

