$PSVersionTable

# Name                           Value                                                                                   
# ----                           -----                                                                                   
# PSVersion                      4.0                                                                                     
# WSManStackVersion              3.0                                                                                     
# SerializationVersion           1.1.0.1                                                                                 
# CLRVersion                     4.0.30319.34209                                                                         
# BuildVersion                   6.3.9600.17090                                                                          
# PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0}                                                                    
# PSRemotingProtocolVersion      2.2    

Write-Host "========== function(map, list)"

$foo = "FOO"
"foo is $foo" # foo is FOO
$anotherMapFoo = @{ "foo" = "hoge" }
"anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is hoge
$anotherListFoo = ,"aka"
"anotherListFoo is $($anotherListFoo[0])" # anotherMapList is aka

function Update-foo($anotherMapFoo, $anotherListFoo) {
    "foo is $foo" # foo is FOO
    $foo = "BAR"
    "foo is $foo" # foo is BAR

    "anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is hoge
    $anotherMapFoo["foo"] = "fuga"
    "anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is fuga

    "anotherListFoo is $($anotherListFoo[0])" # anotherMapList is aka
    $anotherListFoo[0] = "sata"
    "anotherListFoo is $($anotherListFoo[0])" # anotherMapList is sata
}
Update-foo $anotherMapFoo $anotherListFoo

"foo is $foo" # foo is FOO
"anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is fuga
"anotherListFoo is $($anotherListFoo[0])" # anotherMapList is sata

Write-Host "========== nested-function"

function outer(){
    function inner(){
        "Inner"
    }
    inner
}
inner # Error: CommandNotFoundException
outer # Inner
inner # Error: CommandNotFoundException

Write-Host "========== nested-function#2"

$foo = "FOO"
"foo is $foo" # foo is FOO
function outer(){
    "foo is $foo" # foo is FOO
    $foo = "BAR"
    "foo is $foo" # foo is BAR
    function inner(){
        "foo is $foo" # foo is BAR
        $foo = "BAZ"
        "foo is $foo" # foo is BAZ
    }
    inner
    "foo is $foo" # foo is BAR
}
outer
"foo is $foo" # foo is FOO

Write-Host "========== With-XXX() Function"

$foo = "FOO"
"foo is $foo" # foo is FOO

function With-Foo($foo, $codeBlock){
    $codeBlock.Invoke()
}

With-Foo "hoge" {
    "foo is $foo" # foo is hoge

    With-Foo "fuga" {
        "foo is $foo" # foo is fuga

        With-Foo "moge" {
            "foo is $foo" # foo is moge
            $foo = "mongege"
        }

        "foo is $foo" # foo is fuga
        $foo = "fungege"
    }

    "foo is $foo" # foo is hoge
    $foo = "hongege"
}
"foo is $foo" # foo is FOO


Write-Host "========== if-condition"

$foo = "FOO"
"foo is $foo" # foo is FOO

if( $true ) {
    $foo = "BAR"
    "foo is $foo" # foo is BAR
}

"foo is $foo" # foo is BAR

Write-Host "========== & code-block"

$foo = "FOO"
"foo is $foo" # foo is FOO
& {
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}
"foo is $foo" # foo is FOO


Write-Host "========== . code-block"

$foo = "FOO"
"foo is $foo" # foo is FOO
. {
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}
"foo is $foo" # foo is BAZ

Write-Host "========== Invoke-Command"

$foo = "FOO"
"foo is $foo" # foo is FOO
Invoke-Command -ScriptBlock {
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}
"foo is $foo" # foo is FOO


Write-Host "========== Invoke-Command -NoNewScope"

$foo = "FOO"
"foo is $foo" # foo is FOO
Invoke-Command -ScriptBlock {
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
} -NoNewScope
"foo is $foo" # foo is BAZ


Write-Host "========== code-block#Invoke()"

$foo = "FOO"
"foo is $foo" # foo is FOO
{
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}.Invoke()
"foo is $foo" # foo is FOO

Write-Host "========== code-block.GetNewClosure()"

$foo = "FOO"
"foo is $foo" # foo is FOO
$gnc = {
    "foo is $foo" # foo is FOO
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}.GetNewClosure()
& $gnc
"foo is $foo" # foo is FOO

Write-Host "========== code-block.GetNewClosure()#2"

$myName = "knjname"
$gnc = {
    "My name is ${myName}."
}
$gnc.Invoke() # My name is knjname.
$myName = "usagi-chan"
$gnc.Invoke() # My name is usagi-chan.

$myName = "knjname"
$gnc = {
    "My name is ${myName}."
}.GetNewClosure()
$gnc.Invoke() # My name is knjname.
$myName = "usagi-chan"
$gnc.Invoke() # My name is knjname.


Write-Host "========== For-Each %"

$foo = "FOO"
"foo is $foo" # foo is FOO
, 1 | % {
    "foo is $foo" # foo is FOO
    $foo = "BOO"
    "foo is $foo" # foo is BOO
}
"foo is $foo" # foo is BOO

Write-Host "========== For-Each %#2"

$foo = "FOO"
"foo is $foo" # foo is FOO
$cdb = {
    "foo is $foo" # foo is FOO
    $foo = "BOO"
    "foo is $foo" # foo is BOO
}
, 1 | % $cdb
"foo is $foo" # foo is BOO


Write-Host "========== Multiple For-Each %"

$foo = "FOO"
"foo is $foo" # foo is FOO
1,2,3 | % {
    $foo = "(${foo}"
} | % {
    $foo = "${foo})"
} | % {
    $foo = "<${foo}>"
}
"foo is $foo" # foo is (((FOO


Write-Host "========== Multiple For-Each %#2"

$foo = "FOO"
"foo is $foo" # foo is FOO
1,2,3 | % {
    $foo
    $foo = "(${foo}"
} | % {
    $foo
    $foo = "${foo})"
} | % {
    $foo
    $foo = "<${foo}>"
}
"foo is $foo" # foo is <(<(<(FOO)>)>)>


Write-Host "========== Multiple For-Each %#3"

$foo = "FOO"
"foo is $foo" # foo is FOO
1,2,3 | % {
    $foo
    $foo = "(${foo}"
} | % {
    $foo = "${foo})"
} | % {
    $foo
    $foo = "<${foo}>"
}
"foo is $foo" # foo is (((FOO)))

Write-Host "========== For-Each"

$foo = "FOO"
"foo is $foo" # foo is FOO
foreach ( $hoge in ,1 ){
    $foo = "boo"
    "foo is $foo" # foo is boo
}
"foo is $foo" # foo is boo

Write-Host "========== For-Each (shadowing)"

$foo = "FOO"
"foo is $foo" # foo is FOO
foreach ( $foo in ,1 ){
    "foo is $foo" # foo is 1
}
"foo is $foo" # foo is 1

Write-Host "========== For-Each (shadowing2)"

$foo = "FOO"
"foo is $foo" # foo is FOO
 # foo is 1
 # foo is 3
 # foo is 4
 # foo is 4
 # foo is 2
 # foo is 3
 # foo is 4
 # foo is 4
foreach ( $foo in ,1,2 ){
    "foo is $foo"
    foreach ( $foo in ,3,4 ){
        "foo is $foo"
    }
    "foo is $foo"
}
"foo is $foo" # foo is 4

Write-Host "========== Pipeline function"

$foo = "FOO"
"foo is $foo" # foo is FOO
function Pipeline($foo) {
    Begin {
        "foo is $foo" # foo is FOO
        $foo = "begin"
        "foo is $foo" # foo is begin
    }

    Process {
        "foo is $foo" # foo is begin
        $foo = "process"
        "foo is $foo" # foo is process
    }

    End {
        "foo is $foo" # foo is process
        $foo = "end"
        "foo is $foo" # foo is end
    }
}

,1 | Pipeline

"foo is $foo" # foo is FOO

Write-Host "========== Where"

$foo = "FOO"
"foo is $foo" # foo is FOO
, 1 | Where {
    Write-Host "foo is $foo" # foo is FOO
    $foo = "BOO"
    Write-Host "foo is $foo" # foo is BOO
    $false
}

"foo is $foo" # foo is BOO

Write-Host "========== Do-While"

$foo = "FOO"
"foo is $foo" # foo is FOO
do {
    "foo is $foo" # foo is FOO
    $foo = "BOO"
    "foo is $foo" # foo is BOO
} while ($false)

"foo is $foo" # foo is BOO

Write-Host "========== While"

$foo = "FOO"
"foo is $foo" # foo is FOO
while ($true) {
    "foo is $foo" # foo is FOO
    $foo = "BOO"
    "foo is $foo" # foo is BOO
    break
}

"foo is $foo" # foo is BOO

Write-Host "========== For"

function Inside-Loop(){
    for ($i = 0; $i -lt 2; $i++) {
        $i # 0, 1
    }
}

# 0
# 0
# 1
# 0
# 1
# 0
# 1
# 1
for ($i = 0; $i -lt 2; $i++) {
    $i # 0, 1
    Inside-Loop
    $i # 0, 1
}

Write-Host "========== For nested"

# 0
# 0
# 0
# 1
# 2
# 2
for ($i = 0; $i -lt 2; $i++) {
    $i

    , 1 | % {
        $i
        for ($i = 0; $i -lt 2; $i++) {
            $i
        }
        $i
    }

    $i
}

Write-Host "========== my For-Each"

Function MyForEach($list, $scriptblock) {
    for($i = 0; $i -lt $list.Length; $i++){
        Invoke-Command -ScriptBlock $scriptblock -ArgumentList $i, $list[$i]
    }
}

# 0: a
# 1: b
# 2: c
MyForEach "a", "b", "c" {
    param($i, $elem)
    "${i}: ${elem}"
}

# d
# 0: a
# 1: b
# 2: c
# d
$elem = "d"
$elem
MyForEach "a", "b", "c" {
    param($i, $elem)
    "${i}: ${elem}"
}
$elem


# d
# 0: a
# 1: b
# 2: c
# d
$elem = "d"
$elem
MyForEach "a", "b", "c" {
    param($i, $element)
    "${i}: ${element}"
    $elem = "e"
}
$elem

Write-Host "========== try-catch-finally"

$foo = "FOO"
"foo is $foo" # foo is FOO
try {
    "foo is $foo" # foo is FOO
    $foo = "BOO"
    "foo is $foo" # foo is BOO
    1 / 0
} catch [Exception] {
    "foo is $foo" # foo is BOO
    $foo = "BAR"
    "foo is $foo" # foo is BAR
} finally {
    "foo is $foo" # foo is BAR
    $foo = "BAZ"
    "foo is $foo" # foo is BAZ
}

"foo is $foo" # foo is BAZ

Write-Host "========== Start-Job"

$foo = "FOO"
"foo is $foo" # foo is FOO
$anotherMapFoo = @{"foo" = "HOGE"}
"anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is HOGE
$job = Start-Job -ScriptBlock {
    param($anotherMapFoo)
    "foo is $foo" # foo is 
    $foo = "BAR"    
    "foo is $foo" # foo is BAR

    "anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is HOGE
    $anotherMapFoo["foo"] = "FUGA"
    "anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is FUGA
} -ArgumentList $anotherMapFoo
Wait-Job $job
Receive-Job $job
"foo is $foo" # foo is FOO
"anotherMapFoo is $($anotherMapFoo.foo)" # anotherMapFoo is HOGE



