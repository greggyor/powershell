# hide_metro.ps1

# sends <Win>+D to minimize Metro on login
# save as C:\Users\<Your User>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\hide_metro.ps1

$shell = New-Object -ComObject "Shell.Application"
$shell.minimizeall()
