$LastLine = ""

while ($true) {
    $Bps = Get-WMIObject -Class Win32_PerfFormattedData_Tcpip_NetworkInterface `
         | Measure-Object BytesTotalPersec -Sum | %{ $_.Sum }

    $ThisLine = "{0:F2} KiB/sec" -f ($Bps / 1024)
    [Console]::Write("`r{0}" -f (" " * $LastLine.Length))
    [Console]::Write("`r$ThisLine")

    $LastLine = $ThisLine
    Start-Sleep -Seconds 1
}
