$path = "c:\usr\local\monitor\log\status"

if ( ! (Test-Path $path))
{
	Write-Error "Status file not found!"
	exit
}

# Don't care about the first four lines
$null, $null, $null, $null, $siastatusfile = Get-Content $path

# Matches normal lines
# PORT_OpswAgent        0    INST:1       300    Armed/Normal     08/09/2011 01:52:03
$regex  = "(?<name>\S+)\s+"
$regex += "(?<value>\S+)\s+"
$regex += "(?<type>\S+)\s+"
$regex += "(?<frequency>\S+)\s+"
$regex += "(Armed/Normal|Out of Bounds|Invalid Data|Uninitialized)\s+" # <status> will end up at $matches[1]
$regex += "(?<lastcheckeddate>\S+)\s+"
$regex += "(?<lastcheckedtime>\S+)"

# Matches the following line where there is not a space between the Name and Value (Value must begin with a digit)
# Memory_Database_Usage21    INST:2       300    Armed/Normal     08/09/2011 01:52:03
$regex2  = "(?<name>\D+)"
$regex2 += "(?<value>\S+)\s+"
$regex2 += "(?<type>\S+)\s+"
$regex2 += "(?<frequency>\S+)\s+"
$regex2 += "(Armed/Normal|Out of Bounds|Invalid Data|Uninitialized)\s+" # <status> will end up at $matches[1]
$regex2 += "(?<lastcheckeddate>\S+)\s+"
$regex2 += "(?<lastcheckedtime>\S+)"

$siastatus = @()

foreach ($line in $siastatusfile)
{
	switch -regex ($line.Trim())
	{
		$regex
		{
			$obj = New-Object psobject -Property @{
				"Name"        = $matches.name
				"Value"       = $matches.value
				"Type"        = $matches.type
				"Frequency"   = $matches.frequency
				"Status"      = $matches[1]
				"LastChecked" = $matches.lastcheckeddate + " " + $matches.lastcheckedtime
			}
			$siastatus += $obj
			continue
		}
		$regex2
		{
			$obj = New-Object psobject -Property @{
				"Name"        = $matches.name
				"Value"       = $matches.value
				"Type"        = $matches.type
				"Frequency"   = $matches.frequency
				"Status"      = $matches[1]
				"LastChecked" = $matches.lastcheckeddate + " " + $matches.lastcheckedtime
			}
			$siastatus += $obj
			continue
		}
		# Don't bother with empty lines
		""{continue}
		# Warn on any lines that don't match
		default
		{
			Write-Warning "Could not match line: $line"
		}
	}
}

$siastatus

