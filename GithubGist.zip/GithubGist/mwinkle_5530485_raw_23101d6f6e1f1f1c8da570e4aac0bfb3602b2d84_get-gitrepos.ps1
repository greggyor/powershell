 # start of something to help me manage git repos...
 # starting with a very basic list of them. 
 
 gci -recurse -force -include .git | select -Property Parent, {$_.Parent.FullName}
 
 # ideal next step would potentially parse & return a list of remotes...
 
 # once I get remotes, I should also output current branches
 
 # serialize to a json doc and allow me to pick that back up elsewhere
 
 # integrate iwth a convention to turn into a true one-liner to sync a box

