#requires -Version 3

param(
    [string]$url = "www.example.com",
    [string]$subject,
    [string]$fromMail = "sending_account@example.com"
    [string[]]$toMail = ("receiving_account@example.com")
    [switch]$dontSend = $false
)

function execRemoteScript () {
    param( [Object]$browser, [string]$url )

    $document = $browser.document 
    $head = @($document.getElementsByTagName("head"))[0] 
    Write-Host "got head $url"
    $script = $document.createElement('script') 
    $script.type = 'text/javascript'
    $script.src = $url
    $head.appendChild($script) | Out-Null
}

if (-not $subject) { $subject = $url; }
$ie = new-object -com "InternetExplorer.Application"
$ie.visible = $true
$ie.navigate2($url)

# Wait for the page to start rendering
Start-Sleep -MilliSeconds 5000

$doc = $ie.Document
$win = $doc.parentWindow

if (-not $doc) { Write-Error "Browser document is null"; exit(0); }
if (-not $win) { Write-Error "Browser parent window is null"; exit(0); }

# Wait for the page to complete rendering
while ($ie.Busy -or $ie.Document.readyState -ne "complete") {
    Start-Sleep -MilliSeconds 100
    Write-Host $ie.Document.readyState
}

Write-Host "ReadyState: $($ie.Document.readyState)"

# Add the CSS links in the head.
$bodyHtml = "<!DOCTYPE html><html><head>";
foreach ($ss in $doc.styleSheets) {
    $href = $($ss | Select-Object -expandProperty href);
    Write-Output "Processing stylesheet $href";
    $bodyHtml += "<link rel='stylesheet' type='text/css' href='$($href)' />"
}

# Load canvg
execRemoteScript -browser $ie -url "http://canvg.googlecode.com/svn/trunk/rgbcolor.js"
execRemoteScript -browser $ie -url "http://canvg.googlecode.com/svn/trunk/canvg.js"

$now = [DateTime]::Now
$utcNow = [DateTime]::UtcNow

Start-Sleep -MilliSeconds 15000
#`$('body').append('<div style=""font-family: 'Segoe UI Web Semilight', 'Segoe UI', 'Open Sans Light', 'Helvetica Light', 'Arial', sans-serif; ""> generated $($now) $($utcNow) (UTC) &mdash; </p><a href=""$($surl)"">link</a> to site</div>'); 

$scriptCode = "
`$('body').append('<div style=""font-size:10px;""> <p>report generated $($now) ($($utcNow) UTC) &mdash; <a href=""$($surl)"">link</a> to site</p></div>'); 
`$('body').append('<div style=""font-size:8px;font-family:consolas, sans-serif;color:darkgreen;""><h3>DEBUG</h3><pre id=""debug""/></div>'); 
function dbg(a) { `$('#debug').text(`$('#debug').text() + '\n' + a); };

// Add a background
`$('svg').each(function () { d3.select(this).insert('rect', ':first-child').attr('width', '100%').attr('height', '100%').attr('fill', '#f0f0f0').attr('opacity','1.0').attr('z-order','-1000'); } )

// canvg doesn't seem to apply CSS styles to SVG elements, so we hack this by explicitly setting the attributes.
`$('svg').each(function () { d3.select(this).selectAll('.axis path, .axis line').attr('class', '').attr('stroke', 'black').attr('fill', 'none').attr('style', 'shape-rendering:crispEdges'); } )

canvg();

var id = 0;
`$('svg').each(function(d) {
    var svg_element = `$(this).parent();
    var canvas_element = (svg_element.parent().append('<canvas id=""canvas'+id+'""></canvas>'))[1];
    dbg('rendering svg to image: '+svg_element.context.parentNode.id );
    canvg('canvas'+id++, svg_element.html());
    svg_element.remove();
});

// Remove all the script on the page; we don't need to email it.
(function(){jQuery('script').remove();})();

`$('body').append('<div id=""defaultElement""/>'); 

var hard_code_attributes = ['background-color', 'color', 'font-size', 'font-family'];

var defaultElement = `$('#defaultElement').get()[0];

// add the computed style to the style attribute for every element.
// this prevents incorrect rendering with viewers which can't handle CSS3 (i.e. Outlook).
jQuery('*').each(function(e) {
    var newStyle = '';
    for (var i = 0; i < hard_code_attributes.length; i++) {
        var a = hard_code_attributes[i];

        if (this.currentStyle && this.currentStyle[a] && defaultElement.currentStyle && this.currentStyle[a] != defaultElement.currentStyle[a] ) {
            newStyle += a + ':' + this.currentStyle[a] + ';';
        }
    }
    this.setAttribute('style', newStyle);
});

var interval = setInterval(function(){
    var numSvg = `$('svg').length;
    if (numSvg === 0) {
        // Render all the canvases as images.
        `$('canvas').each( function(d) {
            dbg('  processing svg canvas to image:'+`$(this).context.parentNode.id);
            var img = this.toDataURL('image/png');
            var ii = `$('<img src=`"'+img+'`"/>').attr('src',img);
            `$(this).replaceWith(ii);
        } ); 
        clearInterval(interval);
    }
}, 100);


"
Write-Host -ForegroundColor Blue "Executing javascript..."+([DateTime]::Now.ToString())
$win.execScript($scriptCode, "javascript");
Write-Host -ForegroundColor Blue "Javascript done..."+([DateTime]::Now.ToString())
Start-Sleep -MilliSeconds 10000

$attachments = @();

$imgSuffix = ((($subject -replace ':','-') -replace '\s','') -replace "\[|\]",'')

# Outlook won't render data url images as large as we need, so take the turn the data url into a separate file.
# h/t http://social.technet.microsoft.com/Forums/en-US/winserverpowershell/thread/90ff6edd-75db-443a-bcaf-194f6f37e829
$imgNum = 1;
foreach ($img in $ie.Document.getElementsByTagName("img")) {
    $imgNum++
    $t1 = $img.ie8_getAttribute("src")
    $id = $img.ie8_getAttribute("id")
    $t1 = $img.src

    $imgFileName = "imgid$($id)_$($imgSuffix).png"
    if ($t1) {
        $txt = $t1.Replace("data:image/png;base64,", "")
        $imghref = "cid:$($imgFileName)"
        if ($dontSend) {
            $imghref = $imgFileName;
        }
        if (-not ($txt -imatch '^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$')) {
            Write-Host "Image is not base64 encoded! {$txt}"
        } else {
            $bytes  = [System.Convert]::FromBase64String($txt)
            if ($bytes) {
                $decoded = [System.Text.Encoding]::Default.GetString($bytes)
                [Byte[]]$bytes_imagefront=[System.Text.Encoding]::Default.GetBytes($decoded)
                 [io.file]::WriteAllBytes($imgFileName, $bytes_imagefront)
                $Attachment = New-Object System.Net.Mail.Attachment($imgFileName)
                $Attachment.ContentDisposition.Inline = $true
                $Attachment.ContentDisposition.DispositionType = "Inline"
                $Attachment.ContentType.MediaType = "image/png"
                $Attachment.ContentId = $imgFileName
                $attachments += $Attachment
                
                $img.ie8_setAttribute("src", $imghref)
                $img.src = $imghref
                $img.style = "width:100%;height:100%;"
                $img.ie8_setAttribute("style", "width:100%;height:100%;")
            }
            else
            {
                Write-Output "bytes is null for $id {$txt}"
            }
        }
    }
}

$body = $ie.Document.body.innerHtml;
$bodyHtml += $body;

$bodyHtml += "</html>";

$bodyHtml = $bodyHtml.Replace("—", "`&mdash;").Replace("†", "`&dagger;").Replace("‡", "`&Dagger;");

$bodyHtml | out-File -Encoding ascii -FilePath "body_$($imgSuffix).html"

$smtpServer = "smtphost"
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = $fromMail
foreach ($account in $toMail) {
    $msg.To.Add($account)
}
$msg.Subject = $subject
$msg.Body = $bodyHtml
$msg.IsBodyHtml = $true
$attachments |% { $msg.Attachments.Add($_); }
$smtp.UseDefaultCredentials = $true
#$smtp.EnableSsl = $true

if (-not $dontSend) {
    $smtp.Send($msg)
}


#http://stackoverflow.com/questions/7333973/how-to-get-rendered-html-processed-by-javascript-in-webbrowser-control
#http://stackoverflow.com/questions/9435616/powershell-ie-automation-getelementbyid-with-multiple-entries
$ie.Quit()


