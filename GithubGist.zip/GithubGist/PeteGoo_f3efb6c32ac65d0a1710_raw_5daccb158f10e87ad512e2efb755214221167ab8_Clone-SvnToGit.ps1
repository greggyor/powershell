<#
.SYNOPSIS
    Clones an SVN repository usng git-svn, mapping users using Active Directory.

.DESCRIPTION
    This function is a wrapper around git-svn that tries to resolve the names and email addresses of all users in the commit history
	    
.Parameter SvnPath
    The full path to the SVN repository

.Parameter CloneFolderName
    An optional name for the folder into which the code will be cloned
        
.EXAMPLE
    Clone-SvnToGit svn://mysvnserver/Projects/myproject

    Clone the SVN repo at Projects/myproject to a folder named myproject.

.EXAMPLE
    Clone-SvnToGit svn://mysvnserver/Projects/myproject -CloneFolderName foo

    Clone the SVN repo at Projects/myproject to a folder named foo.
#>
function Clone-SvnToGit
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True, ValueFromPipeline=$True)] $SvnPath, 
        [string] $CloneFolderName
    )
    
	Write-Verbose "Getting the list of authors"
	$allAuthors = ([xml](svn log $SvnPath --stop-on-copy --xml)).log.logentry.author | Select -Unique

	if($LASTEXITCODE -ne 0){
		Write-Error "There was a problem getting history from SVN. Make sure the path given is an SVN repository $SvnPath"
		return;
	}
    
    $tempAuthorsFile = [System.IO.Path]::GetTempFileName()

    Write-Verbose "Creating authors.txt file at $tempAuthorsFile"

    $authorMap = @()

    foreach($username in $allAuthors){
        $displayName = Get-ADUserDisplayName $username
        if(!($displayName)){
            $displayName = $username
            $title = "Unknown User"
            $message = "We could not find the display name of the user $username. What do you want to do?"

            $default = New-Object System.Management.Automation.Host.ChoiceDescription "&Default", `
                "Use their display name as their real name."

            $specify = New-Object System.Management.Automation.Host.ChoiceDescription "&Specify", `
                "Specify the display name manually."

            $options = [System.Management.Automation.Host.ChoiceDescription[]]($default, $specify)

            $result = $host.ui.PromptForChoice($title, $message, $options, 0) 

            switch ($result)
            {
                0 {
                        
                }
                1 {
                    $displayName = Read-Host 'Please write the users display name. e.g. John Doe'
                }
            }
        }

        $authorMap += "{0} = {1}<{0}@mydomain.com>" -f $username, $displayName
    }

    $authorMap | Set-Content $tempAuthorsFile

    Write-Verbose ("Temp authors file created with {0} mapped authors" -f $authorMap.Length)

    Write-Verbose "Starting clone of SVN codebase"

    $output = (git svn clone -A $tempAuthorsFile $SvnPath $CloneFolderName) *>> git-svn-clone.log.txt

    if($LASTEXITCODE -ne 0){
        Write-Error "There was a problem with the git clone. Check the log at git-svn-clone.log.txt"
        Get-Content .\git-svn-clone.log.txt | where {$_ -ne ""} | Select -Last 1 | Write-Error
    }
    else{
        Write-Verbose "Done!"
    }
    
}


function Get-ADUserDisplayName{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True, ValueFromPipeline=$True)] $Username
    )

    $strFilter = "(&(objectCategory=User)(sAMAccountName=$Username))"

    $objDomain = New-Object System.DirectoryServices.DirectoryEntry

    $objSearcher = New-Object System.DirectoryServices.DirectorySearcher
    $objSearcher.SearchRoot = $objDomain
    $objSearcher.PageSize = 1000
    $objSearcher.Filter = $strFilter
    $objSearcher.SearchScope = "Subtree"

    $colProplist = @("name")
    foreach ($i in $colPropList){$_ = $objSearcher.PropertiesToLoad.Add($i)}

    $colResults = $objSearcher.FindAll()

    $user = $colResults | Select -First 1

    return $user.Properties.name
}

