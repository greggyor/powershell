$prodvms | select -Property Name,@{Name='IPAddress';Expression={$_.Guest.IPAddress }},@{Name='OS';Expression={$_.Guest.OSFullName}},NumCpu,MemoryMB,@{Name='Disks';Expression={$_.Guest.Disks | % { $_.Path + ': ' + [Math]::Round($_.CapacityGB + $_.FreeSpaceGB, 2) }}} | out-gridview


