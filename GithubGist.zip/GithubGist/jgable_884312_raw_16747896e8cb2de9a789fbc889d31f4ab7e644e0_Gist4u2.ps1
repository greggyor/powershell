# Serializer loader
$extAssembly = [Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")    
$serializer = New-Object System.Web.Script.Serialization.JavaScriptSerializer

# Url's formatted
$gistUserListUrlForm = "http://gist.github.com/api/v1/json/gists/{0}";
$gistInfoUrlForm = "http://gist.github.com/api/v1/json/{0}";
$gistContentsUrlForm = "http://gist.github.com/raw/{0}/{1}";

# Json downloader
$webClient = New-Object System.Net.WebClient

# Json Parser
function parseJson([string]$json, [bool]$throwError = $true) {    
    try {
        $result = $serializer.DeserializeObject( $json );    
        return $result;
    } catch {                
        if($throwError) { throw "ERROR: Parsing Error"}
        else { return $null }            
    }
}

function downloadString([string]$stringUrl) {
    try {        
        return $webClient.DownloadString($stringUrl)
    } catch {         
        throw "ERROR: Problem downloading from $stringUrl"
    }
}

function parseUrl([string]$url) {
    return parseJson(downloadString($url));
}

function downloadUserGists([string]$userName) {
    return parseUrl([string]::Format($gistUserListUrlForm, $userName))
}

function downloadGistInfo([string]$gistId) {
    return parseUrl([string]::Format($gistInfoUrlForm, $gistId))
}

function downloadGistFile([string]$gid, [string]$fname) {
    return downloadString([string]::Format($gistContentsUrlForm, $gid, $fname))
}

function List-Gists {
    param ([string]$user = '')

    if([string]::IsNullOrEmpty($user)) {
        'ERROR: Must Specify User'
    }
    else {
        $userGists = downloadUserGists($user)
        if($userGists -eq $null) {
            'ERROR: Nothing Found'
        }
        else {
            $userGists.gists | % { 
                $names = ''
                $_.files | % { 
                    $names = "$names, $_"
                }
                [string]::Format("Id({0}): Files[{1}]", $_.repo, $names.SubString(2))
            }
        }        
    }
}

function Gist-Info {
    param ([string]$gistId = '')
    
    if([string]::IsNullOrEmpty($gistId)) {
        "ERROR: Must Provide Gist Id"
        return;
    }
    
    $gist = downloadGistInfo($gistId)
    if($gist -eq $null -or $gist.gists -eq $null -or $gist.gists.Length -lt 1) {
        "ERROR: Gist Not Found with Id $gistId"
        return;
    }
    
    $g = $gist.gists[0]    
    
    $repo = $g.repo    
    $owner = $g.owner    
    $created_at = $g.created_at
    $description = $g.description
    "         Id: $repo"
    "      Owner: $owner"
    "    Created: $created_at"
    "Description: $description"
    "      Files: "
    $g.files | % { "           - $_" }
}

function Gist-Contents {
    param ([string]$gistId = '', [string]$fileName = '')
    
    if([string]::IsNullOrEmpty($gistId)) { 
        "ERROR: Must provide Gist Id"
        return;
    }
    elseif([string]::IsNullOrEmpty($fileName)) {
        "ERROR: Must provide file name"
        return;
    }    
    
    $file = downloadGistFile $gistId $fileName
    
    return $file
}

function Gist-Insert {
    param ([string]$gistId = '', [string]$fileName = '')
    if([string]::IsNullOrEmpty($gistId)) { 
        "ERROR: Must provide Gist Id"
        return;
    }
    elseif([string]::IsNullOrEmpty($fileName)) {
        $gist = downloadGistInfo($gistId)
        if($gist -eq $null -or $gist.gists -eq $null -or $gist.gists.Length -lt 1) {
            "ERROR: Gist Not Found with Id $gistId"
            return;
        }        
        $fileName = $gist.gists[0].files[0]
        "WARN: No file name provided, defaulting to first file [$fileName]"
    }
    
    $contents = Gist-Contents $gistId $fileName
    if($dte -eq $null -or $dte.ActiveDocument -eq $null -or $dte.ActiveDocument.Selection -eq $null) {
        "ERROR: Cannot Insert into Document, make sure a document is open and the cursor is where you want the file inserted."
        return;
    }
    
    $tempName = [System.IO.Path]::GetTempFileName()
    Set-Content $tempName $contents
    
    $dte.ActiveDocument.Selection.InsertFromFile($tempName)
    $dte.ActiveDocument.Selection.SelectAll()
    $dte.ActiveDocument.Selection.SmartFormat()
    
    del $tempName
}

