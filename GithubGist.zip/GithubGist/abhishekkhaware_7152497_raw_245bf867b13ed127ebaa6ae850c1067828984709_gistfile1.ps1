# Open Powershell profile

##  PS c:\> notepad $profile

# Add Path($PATH= C:\Program Files\Sublime Text 2\) to the System Envairoment Variable for easy access of Sublime_Text.exe

# Create a function for Sublime Text 2 or 3 in $profile

function sublime($arg1){ sublime_text.exe $arg1 }

# Now Create An Alias:

Set-Alias subl sublime

# Save The $profile file.
# Restart PowerShell And Try it:

##  PS c:\> subl

# OR, 

##   PS c:\> subl $profile

