cls
 
[Environment]::CurrentDirectory=(Get-Location -PSProvider FileSystem).ProviderPath 
$rss = (new-object net.webclient)
 
#Set the username for windows auth proxy
#$rss.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
 
# TechEd NA 2013
#$dataFeed = "http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/rss/mp4high/?sort=sequential&direction=desc&term=&r=Developer+Tools+%26+Application+Lifecycle+Management&r=Windows+Azure+Application+Development&y=Breakout&Media=true#fbid=FDnmapgI5Hf"

# TechEd NA 2013 - All
#$dataFeed = "http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/RSS/mp4high"

#TechEd NA 2013 - Windows Azure
#$dataFeed = "http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/rss/mp4high/?sort=sequential&direction=desc&term=&r=Windows+Azure+Application+Development&y=Breakout&Media=true#fbid=FDnmapgI5Hf"

# TechEd Europe 2013 - All
#$dataFeed = "http://channel9.msdn.com/Events/TechEd/Europe/2013/RSS/mp4high"

# TechEd Europe 2013 - Windows Azure
#$dataFeed = "http://channel9.msdn.com/Events/TechEd/europe/2013/RSS/mp4high/?sort=sequential&direction=desc&term=&r=Windows+Azure+Application+Development&y=Breakout&Media"

#BUILD 2013 - All
$dataFeed = "http://channel9.msdn.com/Events/Build/2013/RSS/mp4high#theSessions"
 
$a = ([xml]$rss.downloadstring($dataFeed)) 
$a.rss.channel.item | foreach{
	$mediaUrl = New-Object System.Uri($_.enclosure.url)
  	$pptxUrl = New-Object System.Uri($_.enclosure.url.Replace(".mp4", ".pptx"))
   	$file = $_.creator + " - " + $_.title.Replace(":", "-").Replace("?", "").Replace("/", "-").Replace("<", "-") + ".mp4"
   	$pptx = $_.creator + " - " + $_.title.Replace(":", "-").Replace("?", "").Replace("/", "-").Replace("<", "-") + ".pptx"
	
	if ($_.category -eq "windows-azure")
	{
	  	if (!(test-path $file)) 
	    	{ 
			$file 
	        	$wc = (New-Object System.Net.WebClient)
	        	#Set the username for windows auth proxy
	        	#$wc.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
	        	$wc.DownloadFile($mediaUrl, $file) 
	    	}
	
		if (!(test-path $pptx)) 
	    	{ 
			$pptx
	        	$wc = (New-Object System.Net.WebClient)
	        	#Set the username for windows auth proxy
	        	#$wc.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
	        	$wc.DownloadFile($pptxUrl, $pptx) 
	    	}
	}
}


