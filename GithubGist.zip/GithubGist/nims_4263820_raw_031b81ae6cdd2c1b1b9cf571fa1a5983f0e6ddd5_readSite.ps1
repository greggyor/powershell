$result = (new-object System.IO.StreamReader ([System.Net.WebRequest]::Create("URL_of_Site").GetResponse().GetResponseStream())).ReadToEnd()

