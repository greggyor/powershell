Get-Alias dir # エイリアスを作る
Get-Command # コマンドを表示
Import-Alias c:\scripts\alias.txt 
Write-Host   # いわゆるprint文
get-content "パス"
Get-Service  # 実行中のサービスを表示

# アプリケーション イベントログの最新15個のエントリを表示
Get-EventLog -logName Application -newest 15

# 通常の配列に関してもパイプラインを使用可能。
# 重複を取り除き、ソートをかける
@(3,5,10,1,2,1,1,1,2,6,4,4)|Sort-Object|Get-Unique

変数のスコープ
# どのスコープからも読み書き可能
$global:a = 1
# 現在のスコープからのみ読み書き可能
$private:a = 1
# 現在のスクリプトからのみ読み書き可能
$script:a = 1

# コマンドを実行する
powershell -command {Get-ChildItem C:\}

#     '  ← シングルクォートは継続行
if elseif else 構文

foreach 構文
foreach ( $name in $names) {
}

# Abs関数
$a = [math]::abs(-15) 

# Join
$a = "h","e","l","l","o" 
$b = [string]::join("", $a) 

# Date
$a = get-date -format d
=> 2006/9/1 

# Minute
$a =(get-date).minute 

# DateSerial
MyDate1 = DateSerial(2006, 12, 31) 
# or
$a = get-date -y 2006 -mo 12 -day 31 

http://winscript.jp/powershell/202

# 変数
$a = 1
$b = 2
$a -eq $b

# 論理演算子
-ne !=
-lt >
-gt <
-le >=
-ge <=

-ieq case insensitive
-ceq case sensitive


