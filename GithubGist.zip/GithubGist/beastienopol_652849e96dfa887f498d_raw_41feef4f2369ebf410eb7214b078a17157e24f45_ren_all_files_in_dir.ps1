#Rename all files in a directory , setting all characters to lowercase and excluding directories
gci -Path D:\temp\ -File -Filter "txt*" | foreach{$_| Rename-Item -NewName $_.Name.ToLower()} -ErrorAction SilentlyContinue


#Rename all files in a directory , change only the first letter to lowercase 
gci -Path D:\temp\ -File -Filter "*.txt" | foreach{$_| `
    Rename-Item -NewName $($_.Name.substring(0,1).Tolower() + $_.Name.Substring(1))} -ErrorAction SilentlyContinue 

#rename only x first file in directory , changing the first letter to lower case, if the source equals the destination we get an error message
gci -Path D:\temp\ -File -Filter "*.txt" | Select-Object -First 9 | foreach{$_| `
    Rename-Item -NewName $($_.Name.substring(0,1).Tolower() + $_.Name.Substring(1))} -ErrorAction SilentlyContinue

#test if first letter is uppercase or lowercase to avoid errors
gci -Path D:\temp\ -File - Filter "*.txt"| Select-Object -First 10| foreach{$_| Rename-Item -NewName $(if($_.name.substring(0,1) -cmatch "[a-z]") {$_.Name.substring(0,1).ToUpper() + $_.Name.Substring(1)}
                                                                                     elseif ($_.Name.substring(0,1) -cmatch "[A-Z]") {$_.Name.substring(0,1).ToLower() + $_.Name.Substring(1)})
                                                         } -ErrorAction SilentlyContinue

