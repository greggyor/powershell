$DocumentationFolder = "C:\Projects\sitecorepowershell\Trunk\Documentation"

$documented = Get-ChildItem $DocumentationFolder | % { $_.BaseName } 
$undocumented = get-command | ? { $_.DLL -match "Cognifide"}  | ? { "$($_.Verb)-$($_.Noun)" -Notin $documented } | %{ "$($_.Verb)-$($_.Noun)" }

$undocumented | % { 
    $fileName = "$DocumentationFolder\$_.TODO.ps1" 
    if(Test-Path $fileName){
        remove-item $filename
    } 
    New-Item $fileName -Type File | 
    Set-Content -Value @"
<#
    .SYNOPSIS
        $_.

    .DESCRIPTION
        $_.

	.PARAMETER Path
		Path to the item that should be published - can work with Language parameter to narrow the publication scope.

	.PARAMETER Id
		Id of the item that should be published - can work with Language parameter to narrow the publication scope.

    .INPUTS
        Sitecore.Data.Items.Item
    
    .OUTPUTS
        Sitecore.Data.Items.Item

    .NOTES
        Help Author: Adam Najmanowicz, Michael West, Michael Reynolds

    .LINK
        https://github.com/SitecorePowerShell/Console/

    .EXAMPLE
        PS master:\> $_ -Path master:\content\home
#>
"@
}