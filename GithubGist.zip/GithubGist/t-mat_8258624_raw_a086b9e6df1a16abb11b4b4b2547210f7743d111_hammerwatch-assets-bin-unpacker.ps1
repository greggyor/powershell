<# /*

unpack 'C:\Program Files (x86)\Steam\steamapps\common\Hammerwatch\assets.bin'

+0  int8[4]     'HWRA'  0x48, 0x57, 0x52, 0x41
+4  int32       number of files
+8  file #0

file
    +0              int8                filename_len
    +1              int8[filename_len]  filename (not NUL(0x00) terminated)
    +1+filename_len int32               file_len
    +5+filename_len int8[file_len]      file binary
*/ #>
Add-Type -Type @"
//"
using System;
using System.Text;
using System.IO;
using System.Net.Sockets;

namespace HammerWatchUnofficalTools {
    public static class AssetsBinUnpacker {
        public static void Unpack(string[] args) {
            string inputFilename = args[0];
            string outputBaseDir = args[1];
            BinaryReader br = new BinaryReader(File.Open(inputFilename, FileMode.Open));

            byte[] magic = br.ReadBytes(4);
            int nFile = br.ReadInt32();
            for(int iFile = 0; iFile < nFile; ++iFile) {
                int namelen = br.ReadByte();
                byte[] name = br.ReadBytes(namelen);
                int bodylen = br.ReadInt32();
                byte[] body = br.ReadBytes(bodylen);

                string filename = System.Text.Encoding.UTF8.GetString(name);
                filename = Path.Combine(outputBaseDir, filename);

                {
                    string dirname = Path.GetDirectoryName(filename);
                    if(! string.IsNullOrEmpty(dirname) && ! Directory.Exists(dirname)) {
                        Directory.CreateDirectory(dirname);
                    }
                }

                Console.WriteLine(filename);
                File.WriteAllBytes(filename, body);
            }
        }

        public static void Main(string[] args) {
            Unpack(args);
        }
    }
}
"@ #"   # end Add-Type

$inputFilename = "assets.bin"
$outputBaseDir = "__unpacked__assets.bin"

[HammerWatchUnofficalTools.AssetsBinUnpacker]::Main(@($inputFilename, $outputBaseDir))


