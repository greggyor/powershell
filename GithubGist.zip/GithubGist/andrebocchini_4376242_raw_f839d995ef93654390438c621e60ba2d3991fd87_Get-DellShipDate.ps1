Function Get-DellShipDate($serviceTag) {
    $queryUrl = 'http://support.dell.com/support/topics/global.aspx/support/my_systems_info/details?c=us&l=en&s=gen&logout=&ServiceTag=' + $serviceTag 

    $wc = New-Object System.Net.WebClient
    $wc.Encoding = [System.Text.Encoding]::UTF8
    $results = $wc.DownloadString($queryUrl)

    $startPattern = 'Ship Date:</td><td class="gridCell" valign="top">'
    $endPattern = '</td></tr><tr><td class="gridCellAlt" valign="top" width="85">Country:'

    $matchStart = $results.indexOf($startPattern)
    $matchEnd = $results.indexOf($endPattern)
    $date = $results.Substring($matchStart + $startPattern.Length, $matchEnd - ($matchStart + $startPattern.Length))
    
    return $date
}