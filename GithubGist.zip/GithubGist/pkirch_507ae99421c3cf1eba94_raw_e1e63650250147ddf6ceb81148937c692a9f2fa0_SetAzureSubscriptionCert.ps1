# Get certificate from personal certificate store. 
$cert = Get-Item Cert:\CurrentUser\My\096E6A67C50C4BCED9E27D51013CA92272F73FCD 

# Add Azure subscription parameter set including name, ID, and certificate. 
Set-AzureSubscription -SubscriptionName "Azure MSDN - pkirchner" -SubscriptionId c6244819-a8d6-4279-b492-4a47f4301c54 -Certificate $cert

# No output

