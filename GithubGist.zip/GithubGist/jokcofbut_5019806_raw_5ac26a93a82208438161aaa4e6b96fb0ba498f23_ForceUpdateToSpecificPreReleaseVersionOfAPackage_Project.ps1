#Requires https://github.com/jokcofbut/NuGetHelpers
Force-Update-Package -Id MyPackage -Version 1.0.12275.5-VersionName -source "MyRepo" -IncludePreRelease -Project "MyProject"

