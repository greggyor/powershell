# Set the default framework (3.5 by default)
$framework = '4.0'

