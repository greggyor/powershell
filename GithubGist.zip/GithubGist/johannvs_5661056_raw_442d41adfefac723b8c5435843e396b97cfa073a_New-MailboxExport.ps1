<#
.SYNOPSIS
New-MailboxExport.ps1 - Export an Exchange Mailbox to PST remotely.

.DESCRIPTION 
Export an Exchange Mailbox to PST remotely instead of using the Exchange Management Shell.

.PARAMETER RemoteExchangeServer
FQDN of Exchange Server to where a PSSession will be established for the export request.

.PARAMETER User
The SAMAccountName of the user for which the mailbox must be exported to PST.

.PARAMETER PSTFilePath
The shared path to where the PST will be exported. The user that executes the script must have write permissions to the share.

.PARAMETER EmailFrom
(Optional)
From email adrress.

.PARAMETER EmailTo
To email address. Email will be sent to this email.

.PARAMETER SMTPServer
SMTP server that is used to send the email.

.EXAMPLE
.\New-MailboxExport.ps1 -RemoteExchangeServer -exchange.test.local -User test.user -PSTFilePath \\fileserver.test.local\Export -EmailTo test@test.local -SMTPServer mail.test.local
Will start an export request for the mailbox of test.user to be exported to \\fileserver.test.local\Export\test.user.pst.
Will watcht the export request status and write progress to console.
Will send an email to test@test.local via the mail.test.local smtp server. Email will come from mailboxexport@yourdomain.com.

.EXAMPLE
.\New-MailboxExport.ps1 -RemoteExchangeServer -exchange.test.local -User test.user -PSTFilePath \\fileserver.test.local\Export -EmailTo test@test.local -EmailFrom export@test.local -SMTPServer mail.test.local
Will start an export request for the mailbox of test.user to be exported to \\fileserver.test.local\Export\test.user.pst.
Will watcht the export request status and write progress to console.
Will send an email to test@test.local via the mail.test.local smtp server. Email will come from export@test.local.

.NOTES
Written By: Johann van Schalkwyk
Email: johann.van.schalkwyk@vodamail.co.za
Twitter: @scallie_84

Change Log
V1.0, 28/5/2013 - Initial version
V1.1, 28/5/2013 - Changed Get-Credential code to use the current user info. Changed the variable $25Sent, $50Sent and $75Sent to Boolean. 
                - Changed the email sent code so that if a mailbox jumps from 49% to 52% complete the email notification is not missed.
V2.0, 29/5/2113 - Removed Remote from script name that caused confusion.
#>

[CmdletBinding()]
Param(
        [Parameter(Mandatory=$True, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='FQDN of Exchange server to where a PSSession will be established for the export request.')]
        [String] 
        $RemoteExchangeServer = "exchange.test.local"
        ,
        [Parameter(Mandatory=$True, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='Active Directory username of user which mailbox is exported.')]
        [String] 
        $User = "test.user"
        ,
        [Parameter(Mandatory=$True, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='Shared directory where PST will be exported to. User that executes the request must have Read/Write permissions to share.')]
        [String] 
        $PSTFilePath = "\\fileserver.test.local\Export"   
        ,
        [Parameter(Mandatory=$False, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='From email address used in email notification.')]
        [Alias('From', 'Sender')]
        [String] 
        $EmailFrom = "mailboxexport@yourdomain.com"
        ,
        [Parameter(Mandatory=$True, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='Email address that will receive the notification.')]
        [Alias('To', 'Recipient')]
        [String] 
        $EmailTo = "mail@test.local"
        ,        
        [Parameter(Mandatory=$True, ValueFromPipeline=$False, ValueFromPipelineByPropertyName=$False, HelpMessage='SMTP Server used for sending the email notifications.')]
        [Alias('EmailServer')]
        [String] 
        $SMTPServer = "smtp.test.local"           
     )

Write-Verbose "Gets Credentials required for open PSSession"
$Credential = $host.ui.PromptForCredential("Enter Required Credentials", "Please enter your user name and password for $env:userdomain domain.", "$env:userdomain\$env:username", "")

Write-Verbose "Uses the $RemoteExchangeServer parameter to populate the required ConnectionUri variable for the PSSession"
$ConnectionUri = "http://$RemoteExchangeServer/Powershell"

Write-Verbose "Uses the $PSTFilePath parameter to populate the required FilePath variable for the Export Request"
$ExportPath = "$PSTFilePath\$User.pst"

Write-Verbose "Establishes a PSSession to the $RemoteExchangeServer"
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $ConnectionUri -Authentication Kerberos -Credential $Credential

Write-Verbose "Start the Export Request"
Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User, $Remote_ExportPath) New-MailboxExportRequest -Mailbox $Remote_User -FilePath $Remote_ExportPath } -ArgumentList $User, $ExportPath -HideComputerName

Write-Verbose "Gets initial mailbox export request status and populates required variables"
$ExportStats = Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User) Get-MailboxExportRequest -Mailbox $Remote_User | Get-MailboxExportRequestStatistics } -ArgumentList $User -HideComputerName
$SourceAlias = $ExportStats.SourceAlias
$PercentComplete = $ExportStats.PercentComplete
$ExportStatus = $ExportStats.Status
$25Sent = $False
$50Sent = $False
$75Sent = $False

Write-Verbose "While mailbox export request status is 'Queued', Sleep for 30seconds then gets mailbox export request status again."
WHILE ($ExportStatus -eq "Queued") { Start-Sleep 30 
                                     $ExportStats = Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User) Get-MailboxExportRequest -Mailbox $Remote_User | Get-MailboxExportRequestStatistics } -ArgumentList $User -HideComputerName
                                     $SourceAlias = $ExportStats.SourceAlias
                                     $PercentComplete = $ExportStats.PercentComplete
                                     $ExportStatus = $ExportStats.Status
                                    }

Write-Verbose "While mailbox export request is 'InProgess', Show the progess in the console with Write-Progess"
WHILE ($ExportStatus -eq "InProgress") { $ExportStats = Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User) Get-MailboxExportRequest -Mailbox $Remote_User | Get-MailboxExportRequestStatistics } -ArgumentList $User -HideComputerName
                                         $SourceAlias = $ExportStats.SourceAlias
                                         $PercentComplete = $ExportStats.PercentComplete
                                         $ExportStatus = $ExportStats.Status
                                         Clear-Host
                                         Write-Progress -Activity "Exchange Mailbox Export for $SourceAlias" -Status "Percent Complete: $PercentComplete" -PercentComplete $ExportStats.PercentComplete
    
                                         Write-Verbose "If the mailbox export is 25% complete send an email to $EmailTo"
                                         IF ($25Sent -eq $False ) { IF ($PercentComplete -ge "25" -and $PercentComplete -lt "49") { $MessageContent = "The Exchange Mailbox Export for $SourceAlias is 25% complete."                   
                                                                                                    Send-MailMessage -To $EmailTo -From $EmailFrom -Subject "Exchange Mailbox Export" -SmtpServer $SMTPServer -BodyAsHtml -Body $MessageContent -Priority High
                                                                                                    $25Sent = $True
                                                                                                 }
                                                                }
 
                                         Write-Verbose "If the mailbox export is 50% complete send an email to $EmailTo"
                                         IF ($50Sent -eq $False ) { IF ($PercentComplete -ge "50" -and $PercentComplete -lt "74") { $MessageContent = "The Exchange Mailbox Export for $SourceAlias is 50% complete."                   
                                                                                                   Send-MailMessage -To $EmailTo -From $EmailFrom -Subject "Exchange Mailbox Export" -SmtpServer $SMTPServer -BodyAsHtml -Body $MessageContent -Priority High
                                                                                                   $50Sent = $True
                                                                                                 }
                                                                }

                                         Write-Verbose "If the mailbox export is 75% complete send an email to $EmailTo"
                                         IF ($75Sent -eq $False ) { IF ($PercentComplete -ge "75" -and $PercentComplete -lt "99") { $MessageContent = "The Exchange Mailbox Export for $SourceAlias is 75% complete."                   
                                                                                                   Send-MailMessage -To $EmailTo -From $EmailFrom -Subject "Exchange Mailbox Export" -SmtpServer $SMTPServer -BodyAsHtml -Body $MessageContent -Priority High
                                                                                                   $75Sent = $True
                                                                                                 }
                                         Start-Sleep 30
                                                                }
                                       }

Write-Verbose "If the mailbox export request status is 'Failed', resume the mailbox export request and send email to $EmailTo that the request failed."
IF ($ExportStatus -eq "Failed") { Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User) Get-MailboxExportRequest -Mailbox $Remote_User | Resume-MailboxExportRequest } -ArgumentList $User -HideComputerName
                                  $MessageContent = "The Exchange Mailbox Export for $SourceAlias failed but was resumed."                   
                                  Send-MailMessage -To $EmailTo -From $EmailFrom -Subject "Exchange Mailbox Export" -SmtpServer $SMTPServer -BodyAsHtml -Body $MessageContent -Priority High
                                }

Write-Verbose "If the mailbox export request is complete, remove the mailbox export request and send email to $EmailTo that the export is complete."
IF ($ExportStatus -eq "Completed") { Invoke-Command -Session $Session -ScriptBlock { Param($Remote_User) Get-MailboxExportRequest -Mailbox $Remote_User | Remove-MailboxExportRequest } -ArgumentList $User -HideComputerName
                                     $MessageContent = "The Exchange Mailbox Export for $SourceAlias is completed."                   
                                     Send-MailMessage -To $EmailTo -From $EmailFrom -Subject "Exchange Mailbox Export" -SmtpServer $SMTPServer -BodyAsHtml -Body $MessageContent -Priority High
                                   }

Write-Verbose "Close Remote-PSSession"
Remove-PSSession -Session $Session

