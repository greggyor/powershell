# Using the Windows Azure Active Directory Module for Windows PowerShell
#
# Connect to the tenant to modify
Connect-MsolService # => login

# Get Service Principal to add the role to
$servicePrincipal = Get-MsolServicePrincipal -ServicePrincipalName Principal.Name

# Get role object ID
# Alternatively, you can list all the roles (in order to get a different role name) using just `Get-MsolRole`
$roleId = (Get-MsolRole -RoleName "Directory Readers").ObjectId

# Add role to service principal
Add-MsolRoleMember -RoleObjectId $roleId -RoleMemberObjectId $servicePrincipal.ObjectId -RoleMemberType servicePrincipal

# Check our work
Get-MsolRoleMember -RoleObjectId $roleId # => should include Principal.Name in list

