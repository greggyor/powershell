Get-Federationtrust | Set-FederationTrust –RefreshMetadata

