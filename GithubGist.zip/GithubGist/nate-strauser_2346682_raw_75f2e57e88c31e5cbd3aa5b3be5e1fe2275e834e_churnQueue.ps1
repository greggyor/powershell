function get-queueLength(){
  try {
    $s = (New-Object net.webclient).DownloadString('http://localhost:56785/stats.json')
  }
  catch {
    return "queue length unavailable"
  }
  $queueLength = $s -split (',') | foreach{if ($_ | select-string "queueLength" -quiet){ ($_ -split ":")[1]}}
  return $queueLength
}


$service = "Kiln Queuing Service"
$queueLength = get-queueLength
while($queueLength -gt 1){
	"queue length $queueLength"
	$status = sc.exe query $service
	$running = $status -match "RUNNING"
	if (!$running){
		"service was not running - starting"
		sc.exe start $service
		start-sleep -s 5
		$status = sc.exe query $service
		"service started"
		$status
	}else{
		"service already running"
	}
	start-sleep -s 15
	$queueLength = get-queueLength
}


