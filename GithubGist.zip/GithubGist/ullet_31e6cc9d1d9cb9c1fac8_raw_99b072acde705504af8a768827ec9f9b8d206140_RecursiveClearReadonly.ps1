# Recursively clear read-only flag for all files in current directory and 
# sub-directories.

Get-ChildItem . -Recurse | 
  Where-Object {-not $_.PSIsContainer} | 
  Set-ItemProperty -name IsReadOnly -value $false


