function Convert-ToBase64
{
    param( [Parameter(Mandatory=$true)][String]$target )
    $b  = [System.Text.Encoding]::UTF8.GetBytes($target)
    [System.Convert]::ToBase64String($b)
}

function Convert-FromBase64
{
    param( [Parameter(Mandatory=$true)][String]$target )
    $b  = [System.Convert]::FromBase64String($target)
    [System.Text.Encoding]::UTF8.GetString($b)
}

