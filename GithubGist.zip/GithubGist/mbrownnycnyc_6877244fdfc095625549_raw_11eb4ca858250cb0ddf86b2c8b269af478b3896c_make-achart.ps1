Import-Module .\charting.psm1 -Force

# Create simple dataset
$simpleDataset = @{
    "Microsoft" = 800
    "Apple" = 250
    "Google" = 400
    "RIM" = 0
}

# Create chart and show it
New-Chart -Dataset $simpleDataset | Show-Chart



# Create ordered hashmap
$osloTemperature = [ordered]@{}

# Request weather data for Oslo, and put into dataset
[xml]$weather = (Invoke-WebRequest -Uri http://www.yr.no/place/Norway/Oslo/Oslo/Oslo/varsel.xml).Content
$weather.weatherdata.forecast.tabular.time | foreach {
    $osloTemperature[$_.from] = $_.temperature.value   
}

# Create chart, add dataset and show
New-Chart -Title "Temperature in Oslo" -XInterval 4 -YInterval 2 -Width 1200 | 
    Add-ChartDataset -Dataset $osloTemperature -DatasetName "Temperature" -SeriesChartType Spline -OutVariable tempChart |
    Show-Chart

# Save the chart as a PNG to the desktop
$tempChart.SaveImage($Env:USERPROFILE + "\Desktop\Chart.png", "PNG")

