$ErrorActionPreference = "Stop"

#$version = "1.0.5-alpha"
$version = "1.0.4.1-patched"
$packageSpec = "..\smartconf\SmartConf\SmartConf.nuspec"

$solutionFile = "..\smartconf\SmartConf.sln"
$projectFile = "..\smartconf\SmartConf\SmartConf.csproj"
$solutionConfiguration = "Release"

function Main() {
	# internal variables
	$packageTmpDir = ".\_pkg"
	$packageLibDir = Join-Dirs $packageTmpDir "lib"
	$packageNetSpecificDir = Join-Dirs $packageLibDir (Get-FrameworkAbbrevatedName (Get-TargetProjectFramework $projectFile))
	$projectDir = [System.IO.Path]::GetDirectoryName($projectFile)

	Build-Solution

	# recreate directory tree
	Recreate-Path $packageTmpDir
	Recreate-Path $packageLibDir
	Recreate-Path $packageNetSpecificDir

	#copy necessary files
	Copy-Item (Join-Dirs $projectDir "bin" $solutionConfiguration "*") -Destination $packageNetSpecificDir -Include "*.dll","*.xml" -Recurse
	Copy-Item $packageSpec $packageTmpDir

	Build-Package (Join-Dirs $packageTmpDir $([System.IO.Path]::GetFileName($packageSpec)))
}

function Build-Package($packageSpecFile) {
	Exec {
		NuGet.exe pack $packageSpecFile -version $version
	}
}

function Build-Solution() {
	Exec {
		MSBuild.exe $solutionFile /t:Rebuild /p:Configuration=$solutionConfiguration /p:Platform="Any CPU"
	}
}

function Get-TargetProjectFramework($projectFile) {
	$projectFileContent = [xml](Get-Content $projectFile)

	#$frameworkVersionNode = $projectFileContent.SelectSingleNode("/Project/PropertyGroup/TargetFrameworkVersion")
	$frameworkVersionNode = $projectFileContent.GetElementsByTagName("TargetFrameworkVersion") | select -First 1
	if (!$frameworkVersionNode) {
		throw "Target framework not found in project file `"$projectFile`""
	}

	return $frameworkVersionNode.InnerText
}

function Get-FrameworkAbbrevatedName($version) {
	"net" + ($version -replace "[v\.]","")
}

function Recreate-Path($path) {
	if (Test-Path $path) {
		[void](Remove-Item -Path $path -Recurse)
	}
	[void](md $path)
}

function Join-Dirs() {
	[System.IO.Path]::Combine([string[]]$args)
}

function Exec([scriptblock]$cmd, [hashtable]$warningCodes = @{}, [string]$errorMessage = "Error executing command: " + $cmd) {
	& $cmd
	if ($LastExitCode -ne 0) {
		$sExitCode = $LastExitCode.ToString()
		if ($warningCodes.Contains($sExitCode)) {
			$warningMessage = $warningCodes[$sExitCode]
			if (! [string]::IsNullOrEmpty($warningMessage)) {
				Write-Warning "$warningMessage"
			}
			return
		}
		throw $errorMessage
	}
}

Main


