ls -Recurse | ? { $_ -match "^(bin|obj)$" }

