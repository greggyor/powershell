# Set environment variables for Visual Studio Command Prompt
pushd 'c:\Program Files (x86)\Microsoft Visual Studio 12.0\VC'
cmd /c "vcvarsall.bat&set" |
foreach {
  if ($_ -match "=") {
    $v = $_.split("="); set-item -force -path "ENV:\$($v[0])"  -value "$($v[1])"
  }
}
popd
write-host "`nVisual Studio 2013 command prompt variables set." -ForegroundColor Yellow

# Create alias for sublime text
Set-Alias sublime 'C:\Program Files\Sublime Text 3\sublime_text.exe'

# Add python to path
$env:Path += ";C:\Python27"
# Add premake to path
$env:Path += ";C:\premake4"

# Print path variable
($env:Path).Replace(';',"`n")

# Set startup directory
Set-Location D:\dev\projects

