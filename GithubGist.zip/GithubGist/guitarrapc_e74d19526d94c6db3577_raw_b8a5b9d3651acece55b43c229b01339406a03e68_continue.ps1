1..3 | %{
    $_
    continue
    $_
}
 
<#
1
#>
 
foreach ($x in (1..3))
{
    $x
    continue
    $x
}
 
<#
1
2
3
#>

