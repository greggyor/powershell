$StandardGitIgnoreFile = Resolve-Path ".\std.gitignore"
function Git-InitStandard() {
	git init .
	Copy-Item $StandardGitIgnoreFile ".\.gitignore"
	Write-Host "Added standard gitignore file."
}

<#
This assumes you have a file next to your Powershell profile (where this function is defined) named std.gitignore.  Here's what's in mine:

#ignore thumbnails created by windows
Thumbs.db
#Ignore files build by Visual Studio
*.obj
*.exe
*.pdb
*.user
*.aps
*.pch
*.vspscc
*_i.c
*_p.c
*.ncb
*.suo
*.tlb
*.tlh
*.bak
*.cache
*.ilk
*.log
[Bb]in
[Dd]ebug*/
*.lib
*.sbr
obj/
[Rr]elease*/
_ReSharper*/
[Tt]est[Rr]esult*
packages/**/

#>

