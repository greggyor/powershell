# Initial Draft - needs cleanup

Function getInputGrid($choice)
{
	#7 10 10
	if ($choice -eq "DefaultInput")
	{
		return '..........
..........
..#.......
...#......
.###......
..........
..........
..........
..........
..........'
	}
	#32 17 17
	elseif ($choice -eq "challenge")
	{
		return '.................
.................
....###...###....
.................
..#....#.#....#..
..#....#.#....#..
..#....#.#....#..
....###...###....
.................
....###...###....
..#....#.#....#..
..#....#.#....#..
..#....#.#....#..
.................
....###...###....
.................
.................'
	}
	#10 10 10 
	elseif ($choice -eq 'StillLife')
	{
		return '..........
.##.......
.##.......
.....##...
.....#.#..
......#...
..##......
.#..#.....
..##......
..........'
	} #10 5 5
	elseif ($choice -eq 'oscillate')
	{
		return '.....
.....
.###.
.....
.....'
	}
	#50 20 20
	elseif ($choice -eq 'glider')
	{
		return '....................
..#.................
...#................
.###................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................
....................'

	}
}



function outputGrid($grid, $height, $iteration)
{
	Write-Host "Iteration #" $iteration
	for ($i = 0 ; $i -lt $height; $i++ )
	{

		Write-Host  -NoNewline $grid[$i]
		Write-Host ""
	}
}

function nextIteration($grid)
{
	$nextGrid = @()
	
	#create a copy of the current grid to modify for the next state
	for ($i = 0 ; $i -lt $grid.length ; $i++ )
	{
		$nextGrid += ,@($grid[$i].Clone())
	}

	for ($i = 0 ; $i -lt $grid.length ; $i++ )
	{
		for ($j = 0 ; $j -lt $grid[$i].length ; $j++ )
		{
			
			if ($grid[$i][$j] -eq '.') #current cell is off
			{
				$neighborsOn = neighborsOn $grid $i $j
				
				if ($neighborsOn -eq 3 )
				{
					$nextGrid[$i][$j] = '#' # turn current cell on
				}
			}
			else #current cell is on
			{
				$neighborsOn = neighborsOn $grid $i $j
			
				if ($neighborsOn -lt 2 -or $neighborsOn -gt 3)
				{
					$nextGrid[$i][$j] = '.' # turn current cell off
				}
			}
			
		}
	
	}

	return $nextGrid
}

function neighborsOn($grid, $row, $col)
{

	$numOn = 0
	$gridHeight = $grid.length
	$gridWidth = $grid[0].length
	
	#NW
		$y = $row - 1
		$x = $col - 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#N
		$y = $row - 1
		$x = $col 
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#NE
		$y = $row - 1
		$x = $col + 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#E
		$y = $row
		$x = $col + 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#SE
		$y = $row + 1
		$x = $col + 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#S
		$y = $row + 1
		$x = $col
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#SW
		$y = $row + 1
		$x = $col - 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
	#W
		$y = $row 
		$x = $col - 1
		if ($y -lt 0 ) {$y = $gridHeight - 1} 
		if ($y -ge $gridHeight ) {$y = 0} 
		if ($x -lt 0 ) {$x = $gridWidth - 1} 
		if ($x -ge $gridWidth ) {$x = 0} 
		if ($grid[$y][$x] -eq '#')
		{
			$numOn += 1
		}
		
	return $numOn;
}

$iterations = 50 #Read-Host "Number of Iterations"
$gridWidth = 20 #Read-Host "Grid Width"
$gridHeight = 20 #Read-Host "Grid Height"
$choice = 'glider' #Read-Host "Choose Input Grid: A, B"

# load the input Grid into an array
$inputGrid = getInputGrid($choice)
$inputGrid = [char[]]$inputGrid

$grid = @()
$offset = 0

for ($i = 0 ; $i -lt $gridHeight ; $i++)
{
	$currentRow = @()
	
	
	for ($j = 0 ; $j -lt $gridWidth ; $j++)
	{
		$currentRow += ,@($inputGrid[$j + $offset])
	}
	$offset += $j + 2 #add two to account for CR/LF at end of each line
	
	$grid += ,@($currentRow)
}

#perform the simulation
for ($i = 0 ; $i -le $iterations ; $i++ )
{
	Clear-Host
	outputGrid $grid $gridHeight $i
	Start-Sleep 1
	$grid = nextIteration $grid

}


