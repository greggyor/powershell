cd ~/apps/coherence/lib
mvn install:install-file  `
  -D groupId=com.oracle.coherence  `
  -D artifactId=coherence  `
  -D version=3.7.1.7  `
  -D file=coherence.jar  `
  -D packaging=jar `
  -D generatePom=true

