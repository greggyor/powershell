$myString = "99 Bottles of beer on the wall!"
$myValue = $myString -replace '[ !,.a-zA-Z]'
Write-Host $myValue

