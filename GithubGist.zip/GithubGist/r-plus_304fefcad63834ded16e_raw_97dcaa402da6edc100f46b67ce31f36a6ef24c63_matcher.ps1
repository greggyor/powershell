$json = @"
{
    "matcher":
    [
        {
            "regexp" : "^re$",
            "dest" : "dest1"
        },
        {
            "regexp" : "^h\\w+eほげ.{3}我$",
            "dest" : "dest2"
        },
        {
            "regexp" : ".*",
            "dest" : "dest3"
        }
    ]
}
"@ | ConvertFrom-Json
# ConvertFrom-Json requred PowerShell version 3.0 or later.

$string = "ho
geほげフガ負我"

# chomp
$string = $string -replace "`t|`n|`r",""

# matching
$json.matcher | % {
    echo "trying $($_.regexp) ..."
    if ($string -cmatch $_.regexp) {
        echo hit!
        break;
    }
}


