# you must connect and authenticate to a vCenter server
# use Connect-VIServer to do so

# establish Export file name
$csvname = Read-Host 'Please provide the file path and name for your CSV export'

# start by gathering the list of virtual machines for this vCenter, enter a ForEach loop
Get-View -ViewType virtualmachine | ForEach-Object {

# Capture the name of the virtual machine as a variable
$vmname=$_.Name

# Capture the details of the VMDK file(s) for the virtual machine, including path(s)
$vmdkname=$_.layoutex.file.name

# Capture the name of the datastore for the virtual machine, as reported by the vm
$dsname=$_.config.DatastoreUrl.name

# For each virtual machine, capture datastore details, using the
# name of the datastore AS REPORTED BY THE VIRTUAL MACHINE for the filter,
# capture the NAA ID of the LUN for the datastore,
# then export select properties to the CSV file named previously
Get-View -ViewType datastore -Filter @{"Name"= "^$dsname$"} |Select-Object @{n="VM Name";e={$vmname}}, @{n="VMDK Name";e={$vmdkname}}, @{n="VM Datastore Name";e={$dsname}}, name,@{n='NAA';e={$_.info.vmfs.extent.diskname}} | Export-Csv $csvname -NoTypeInformation –Append
}

