function Out-CapitalizedString {
    param([string]$String)
    if(-not([System.String]::IsNullOrEmpty($String))) {
        foreach ($sentence in ($String.Split('.'))) {
            if(-not([System.String]::IsNullOrEmpty($sentence))) {
                $sentence = $sentence.Trim()
                [array]$outputString += [char]::ToUpper($sentence[0]) + $sentence.Substring(1)
            }
            else {
                [array]$outputString += $sentence
            }
        }
        Write-Output ($outputString -join '. ').Trim()
    }
}

