#requires -version 3.0
[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [string]
    $Path
)

function Sort-NodeArray {
    param (
        [System.Xml.XmlNode[]]
        $SortedNodes
    )

    foreach ($Node in $SortedNodes) {
        $Node.ParentNode.AppendChild($Node.ParentNode.RemoveChild($Node)) | Out-Null
    }
}

$Path = $PSCmdlet.GetUnresolvedProviderPathFromPSPath($Path)
$TempPath = [IO.Path]::GetTempFileName()

Add-Type -AssemblyName System.Web.Services

$ServiceDescription = [System.Web.Services.Description.ServiceDescription]::Read($Path)
$ServiceDescription.Namespaces = $null
$ServiceDescription.Write($TempPath)

$Namespaces = @{
    wsdl = 'http://schemas.xmlsoap.org/wsdl/'
    xs = 'http://www.w3.org/2001/XMLSchema'
}

$TypesNode = Select-Xml -Path $TempPath -XPath wsdl:definitions/wsdl:types -Namespace $Namespaces |
    Select-Object -ExpandProperty Node -First 1 

$Schemas = @(
    Select-Xml -Xml $TypesNode -XPath xs:schema -Namespace $Namespaces |
        Select-Object -ExpandProperty Node |
        Sort-Object -Property { $_.GetAttribute('targetNamespace') }
)

Sort-NodeArray -SortedNodes $Schemas

foreach ($Schema in $Schemas) {

    $ImportNodes = @(
        Select-Xml -Xml $Schema -XPath xs:import -Namespace $Namespaces |
            Select-Object -ExpandProperty Node |
            Sort-Object -Property { $_.GetAttribute('namespace') }
    )

    Sort-NodeArray -SortedNodes $ImportNodes
    
    $SimpleTypeNodes = @(
        Select-Xml -Xml $Schema -XPath xs:simpleType -Namespace $Namespaces |
            Select-Object -ExpandProperty Node |
            Sort-Object -Property { $_.GetAttribute('name') }
    )

    Sort-NodeArray -SortedNodes $SimpleTypeNodes

    $ComplexTypeNodes = @(
        Select-Xml -Xml $Schema -XPath xs:complexType -Namespace $Namespaces |
            Select-Object -ExpandProperty Node |
            Sort-Object -Property { $_.GetAttribute('name') }
    )

    Sort-NodeArray -SortedNodes $ComplexTypeNodes
}


$OutputPath = $Path

$TypesNode.OwnerDocument.Save($TempPath)
$ServiceDescription = [System.Web.Services.Description.ServiceDescription]::Read($TempPath)

$ServiceDescription.Namespaces = $null
$ServiceDescription.Namespaces.Add('tns', $ServiceDescription.TargetNamespace)
$ServiceDescription.Namespaces.Add('wsdl', 'http://schemas.xmlsoap.org/wsdl/')
$ServiceDescription.Namespaces.Add('soap', 'http://schemas.xmlsoap.org/wsdl/soap/')

foreach ($Schema in $ServiceDescription.Types.Schemas) {
    $Schema.Namespaces = $null
    $Schema.Namespaces.Add('tns', $Schema.TargetNamespace)
    $Schema.Namespaces.Add('xs', 'http://www.w3.org/2001/XMLSchema')
    $NamespaceIndex = 1
    foreach ($Include in $Schema.Includes) {
        $Schema.Namespaces.Add("ns$NamespaceIndex", $Include.Namespace)
        $NamespaceIndex++
    }

}
$ServiceDescription.Write($OutputPath)

Remove-Item -Path $TempPath


