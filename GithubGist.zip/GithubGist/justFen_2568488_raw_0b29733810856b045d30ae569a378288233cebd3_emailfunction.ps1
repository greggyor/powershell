$smtp = "nice.smtp.server.brok"
$from = "Test@Testing.com"
$to = "Self@DismantleRepair.me"
$subject = "Interesting subject~!"
$body = "Nice Curves!"
Send-Mailmessage -SmtpServer $smtp -From $from -To $to -Subject $subject -Body $body

