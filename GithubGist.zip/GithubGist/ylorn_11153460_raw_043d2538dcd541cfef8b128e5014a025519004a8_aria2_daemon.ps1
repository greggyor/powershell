# troy at 164.218.21.198.tigernet.wifi.dyn.clemson.edu in ~ [15:17:28]
$ ps aux|grep aria2c
root               92   7.8  0.3  2464048  21292   ??  Ss    2:58PM   0:20.59 /usr/local/Cellar/aria2/1.18.5/bin/aria2c --conf-path=/Users/troy/.aria2/aria2.conf
troy              990   0.0  0.0  2442000    632 s000  S+    3:17PM   0:00.00 grep aria2c

