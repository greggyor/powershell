# Description: script to create a managed property for search that maps to the Active (ows_RoutingEnabled) site column

# a few convenience variables
$YesNo = [Microsoft.SharePoint.Search.Administration.ManagedDataType]::YesNo
$searchApp = Get-SPEnterpriseSearchServiceApplication

# get reference to "Active" property - internally known as ows_RoutingEnabled
$crawledProperty = Get-SPEnterpriseSearchMetadataCrawledProperty -SearchApplication $searchApp -Name ows_RoutingEnabled
$crawledProperty.IsMappedToContents = $true
$crawledProperty.Update()

# get reference to Active managed property or create if needed
$managedProperty = Get-SPEnterpriseSearchMetadataManagedProperty -SearchApplication $searchApp | ? { $_.Name -eq "Active" }
if ($managedProperty -eq $null) {
  $managedProperty = New-SPEnterpriseSearchMetadataManagedProperty -Name Active -SearchApplication $searchApp -Type $YesNo -EnabledForScoping $true
}

#get reference to Active managed property mapping and add ows_RoutingEnabled crawled property if needed
$mapping = Get-SPEnterpriseSearchMetadataMapping -SearchApplication $searchApp -ManagedProperty Active | ? { $_.CrawledPropertyName -eq "ows_RoutingEnabled" }
if ($mapping -eq $null) {
  New-SPEnterpriseSearchMetadataMapping -SearchApplication $searchApp -ManagedProperty $managedProperty -CrawledProperty $crawledProperty
} else {
  "Warning: mapping already exists between Active and ows_RoutingEnabled"
}


