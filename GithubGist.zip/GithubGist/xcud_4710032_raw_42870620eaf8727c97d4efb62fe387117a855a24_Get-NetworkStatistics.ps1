<#
.Synopsis
  PowerShellized netstat. Building on Shay Levy's work
  	Shay Levy's Blog => http://blogs.microsoft.co.il/blogs/scriptfanatic/
    
.Example
	PS> Get-NetworkStatistics skype | ft -AutoSize
  
Protocol LocalAddress LocalPort RemoteAddress  RemotePort State       ProcessName PID
-------- ------------ --------- -------------  ---------- -----       ----------- ---
TCP      0.0.0.0      443       0.0.0.0        0          LISTENING   Skype       4608
TCP      0.0.0.0      56448     0.0.0.0        0          LISTENING   Skype       4608
TCP      10.1.0.13    49255     157.55.235.162 40010      ESTABLISHED Skype       4608
TCP      10.1.0.13    49257     193.120.199.13 12350      ESTABLISHED Skype       4608
TCP      10.1.0.13    49258     65.54.48.131   443        ESTABLISHED Skype       4608
UDP      0.0.0.0      443       *              *                      Skype       4608
UDP      0.0.0.0      56448     *              *                      Skype       4608
UDP      127.0.0.1    56357     *              *                      Skype       4608
UDP      127.0.0.1    62782     *              *                      Skype       4608

.Example	
	PS> Get-NetworkStatistics -Port 80
  
Protocol      : TCP
LocalAddress  : 0.0.0.0
LocalPort     : 80
RemoteAddress : 0.0.0.0
RemotePort    : 0
State         : LISTENING
ProcessName   : System
PID           : 4

Protocol      : TCP
LocalAddress  : 10.1.0.13
LocalPort     : 50293
RemoteAddress : 69.59.197.29
RemotePort    : 80
State         : ESTABLISHED
ProcessName   : chrome
PID           : 3416

#>
function Get-NetworkStatistics 
{ 
	param(	
		[string]$ProcessName, 
		[net.ipaddress]$Address, 
		[int]$Port = -1,
		[int]$ProcessId = -1
	)

	$properties = 'Protocol','LocalAddress','LocalPort', 
				  'RemoteAddress','RemotePort','State','ProcessName','PID' 

    $netstatEntries = netstat -ano | Select-String -Pattern '\s+(TCP|UDP)'

	foreach($_ in $netstatEntries) {
	
        $item = $_.line.split(" ",[System.StringSplitOptions]::RemoveEmptyEntries) 

        if($item[1] -notmatch '^\[::') 
        {            
			($localAddress, $localPort) = Split-AddressPort($item[1])			
			($remoteAddress, $remotePort) = Split-AddressPort($item[2])

			$netProcessName = (Get-Process -Id $item[-1] -ErrorAction SilentlyContinue).Name
			
			# apply ProcessName filter
			if(![string]::IsNullOrEmpty($ProcessName) -and 
				[string]::Compare($ProcessName, $netProcessName, $true) -ne 0) {
				continue
			}

			# apply Port filter
			if($Port -ne -1 -and $localPort -ne $Port -and $remotePort -ne $Port) {
				continue
			}
			
			# apply Address filter
			if($Address -ne $null -and $localAddress -ne $Address -and $remoteAddress -ne $Address) {
				continue
			}
			
			# apply PID filter
			$netPID = $item[-1]
			if($ProcessId -ne -1 -and $ProcessId -ne $netPID) {
				continue
			}

			New-Object PSObject -Property @{ 
                PID = $netPID 
                ProcessName = $netProcessName 
                Protocol = $item[0] 
                LocalAddress = $localAddress 
                LocalPort = $localPort 
                RemoteAddress = $remoteAddress 
                RemotePort = $remotePort 
                State = if($item[0] -eq 'tcp') {$item[3]} else {$null} 
            } | Select-Object -Property $properties 
        } 
    } 
}

<#
.Synopsis
  Splits an ipaddress string from 'netstat' into its respective address/port parts.
.Example
  PS> Split-AddressPort [fe80::4442:f854:4707:3c0f%15]:1900
  fe80::4442:f854:4707:3c0f%15
	1900
#>
function Split-AddressPort([string]$ipaddressAsString) {
	$ipaddress = $ipaddressAsString -as [ipaddress]
	if ($ipaddress.AddressFamily -eq 'InterNetworkV6') 
    { 
       $retvalAddress = $ipaddress.IPAddressToString 
       $retvalPort = $ipaddressAsString.split('\]:')[-1] 
    } 
    else 
    { 
        $retvalAddress = $ipaddressAsString.split(':')[0] 
        $retvalPort = $ipaddressAsString.split(':')[-1] 
    }  
	return @($retvalAddress, $retvalPort);
}

