workflow ScaleVMs
{
param(
         [parameter(Mandatory=$true)]
          [string]$VMNames,
          [parameter(Mandatory=$true)]
          [string]$VMSize
     )

 $subscriptionName = Get-AutomationVariable -Name "SubscriptionName"
 $subscriptionID = Get-AutomationVariable -Name "SubscriptionID"
 $certificateName = Get-AutomationVariable -Name "CertificateName"
 $certificate = Get-AutomationCertificate -Name $certificateName 
 Set-AzureSubscription -SubscriptionName $subscriptionName -SubscriptionId $subscriptionID -Certificate $certificate
 Select-AzureSubscription $subscriptionName 
 
 Write-Output $("Scaling " + $VMNames + " to " + $VMSize)
 
 $VMNames -split "," | ForEach {
     $VMName = $_.trim()
     Write-Output $("Beginning scale operation " + $VMName + " -> " + $VMSize)
      
     Get-AzureVM –ServiceName $VMName –Name $VMName |
         Set-AzureVMSize $VMSize |
         Update-AzureVM
 }
 
  Write-Output "Scaling operations completed" 
 
 }

