<# --------------------------
  Azure VM şifresini sıfırlamak için
  Mehmet Kut
  mail@mehmetkut.com
---------------------------- #>

Import-AzurePublishSettingsFile C:\AzureScripts\30-1-2015-credentials.publishsettings
Get-AzureSubscription

$adminCredentials = Get-Credential -Message "Yeni Giriş Bilgileri"
(Get-AzureVM) | 
Where-Object -Property Status -EQ "ReadyRole" |
Select-Object -Property Name, ServiceName |
Out-GridView -Title "VM Seçiniz…" -PassThru |
ForEach-Object {
    $VM = Get-AzureVM -Name $_.Name -ServiceName $_.ServiceName
    If ($VM.VM.ProvisionGuestAgent) {
        Set-AzureVMAccessExtension -VM $VM `
            -UserName $adminCredentials.UserName `
            -Password $adminCredentials.GetNetworkCredential().Password `
            -ReferenceName "VMAccessAgent" | 
        Update-AzureVM
        Restart-AzureVM -ServiceName $VM.ServiceName -Name $VM.Name
    } else {
        Write-Output "$($VM.Name): VM Agent kurulu değil"
    }
}

