$s = New-PSSession -ComputerName servermaame

#I am using PID 0,4, assigned to System and Idle for testing, as they are always available.
$pid1 = 4
$processId = 0

# CASE: Remote session variable, but no argument list to pass.
# This wont work, because there is no argument list assignment to pass to the scriptblock
Invoke-Command -Session $s -Script { param($processId) Get-Process -Id $processId } 

# CASE: Local Variable passed to remote session.
# This works. $pid1 (local variable), is passed to $processid in remote computer
# Pass by Reference
Invoke-Command -Session $s -Script { param($processId) Get-Process -Id $processId } -Args $pid1

# CASE: Remote Session variable only. We cant guess which remote processid is active. 
# This works. Scriptblock is using $PID system variabe assigned to the powershell HOST. 
# There is no local to remote session variable passing.
# Passed Remotely *only*
Invoke-Command -Session $s -Script { Get-Process -Id $pid} 

# CASE: Remote Session variable only. We cant guess which remote processid is active. 
# This doesnt work on my system, as no process id 7808 exists remotely.
# $pid 7808 is defined locally, and is being passed by Value.
# Pass by Value
Invoke-Command -Session $s -Script { Get-Process -Id $args[0]} -Args $pid

# CASE: Remote Session variable passed using $args[0].
# This works. 
# Passed by Reference.
Invoke-Command -Session $s -Script { Get-Process -Id $args[0]} -Args $pid1



