Function Process-RunbookFolder
{
    Param (
        $Path,
        [switch]$recurse
        )
    $allwfs = get-childitem -Path $Path -Recurse:$recurse
    $Global:referencelist = New-Object System.Collections.ArrayList
    [System.Collections.ArrayList]$Global:ToProcessList = $allwfs | select -ExpandProperty Fullname
    $Global:DoneProcessList = New-Object System.Collections.ArrayList
    foreach ($wf in $ToProcessList)
    {
        #Validate-RunbookFile -path $wf.FullName -erroraction Stop
        Get-RunbookReference -path $wf
        Process-RunbookFile -path $wf -basepath $Path -recurse:$recurse
    }
    #get-variable processlist -Scope global | Remove-Variable
}

Function Get-RunbookReference
{
    Param ($path)
    $ThisWf = get-content $path -Raw
    $ThisWfSB = [scriptblock]::Create($ThisWf)
    #$ThisWfAST = $ThisWfSB.Ast
    $TokenizedWF = [System.Management.Automation.PSParser]::Tokenize($ThisWfSB,[ref]$null)
    $referencedCommands = $TokenizedWF | where {$_.Type -eq "Command"} | select -ExpandProperty "Content"
    $myobj = "" |Select Fullname, ReferencedRunbooks
    $myobj.Fullname  =$path
    $myobj.ReferencedRunbooks = $referencedCommands
    $Global:referencelist += $myobj; $myobj = $null

}

Function Process-RunbookFile
{
    Param ($path, $basepath, [switch]$recurse)
    
    $path = get-item $path
    if ($DoneProcessList -contains ($path.FullName))
    {
        Write-Verbose "SKIPPING: Already processed runbook $($path.BaseName)"
        return
    }
    Write-Verbose "PARSING: Runbook $($path.BaseName)"
    #Parse to find wfs this one depends on, and process
    $ThisWf = get-content $path -Raw
    $ThisWfSB = [scriptblock]::Create($ThisWf)
    #$ThisWfAST = $ThisWfSB.Ast
    $TokenizedWF = [System.Management.Automation.PSParser]::Tokenize($ThisWfSB,[ref]$null)
    $referencedCommands = $TokenizedWF | where {$_.TYpe -eq "Command"}
    foreach ($referencedCommand in $referencedCommands)
    {
        $runbookpath = get-childitem -Path $basepath -Recurse:$recurse |where {$_.BaseName -eq $referencedCommand.Content}
        if ($runbookpath)
        {
            Write-Verbose "REFERENCE: $($path.BaseName)--> $($referencedCommand.content)"
            Process-RunbookFile -path $runbookpath.FullName
        }  
    }

    #WHen all referenced runbooks are imported, import this one
    Write-Verbose "PUBLISH: Publishing runbook $($path.BaseName)"
    $Global:DoneProcessList += $path.FullName

}


Process-RunbookFolder -Path "D:\trond.hindenes\Desktop\wftest"


