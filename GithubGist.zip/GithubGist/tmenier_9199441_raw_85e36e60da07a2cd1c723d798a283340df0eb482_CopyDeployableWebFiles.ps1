function copy-deployable-web-files($proj_path, $deploy_dir) {
	# copy files where Build Action = "Content" 
	$proj_dir = split-path -parent $proj_path
	[xml]$xml = get-content $proj_path
	$xml.Project.ItemGroup | % { $_.Content } | % { $_.Include } | ? { $_ } | % {
		$from = "$proj_dir\$_"
		$to = split-path -parent "$deploy_dir\$_"
		if (!(test-path $to)) { md $to }
		cp $from $to
	}
	
	# copy everything in bin
	cp "$proj_dir\bin" $deploy_dir -recurse
}


