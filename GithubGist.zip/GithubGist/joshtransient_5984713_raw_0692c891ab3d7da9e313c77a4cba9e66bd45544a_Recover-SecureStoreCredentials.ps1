<#
.SYNOPSIS
    Secure Store Credential Extraction
.NOTES
    Author: Josh Leach, Critigen
    Date:   27 Mar 2013
    Adapted from http://msdn.microsoft.com/en-us/library/ff394459(v=office.14).aspx
.DESCRIPTION
    Pulls information about Secure Store target applications. The account running this script must be a member of each Secure Store app, otherwise you'll receive access denied.
.PARAMETER AppName
    [All (default)|<Target Application ID>]: Name of the secure store target application, or all of them.
.PARAMETER Retrieve
    [Credentials (default)|Admins|Members]: Retrieve stored credentials, target application administrators, or target application members.
.EXAMPLE
    .\storextract.ps1 -AppName 'MySecStoreApplication' -Retrieve Credentials
    Gets stored credentials from MySecStoreApplication.
.EXAMPLE
    .\storextract.ps1 -Retrieve Members
    Retrieves all claims for members of every secure store target application.
#>

# Some parameters!
Param (
  [string]$AppName = 'All',
  [string][ValidateSet('Credentials','Admins','Members')]$Retrieve = 'Credentials'
)

#REGION Globals and Functions

# Instantiate local Admin web app
$admin = [microsoft.sharepoint.administration.spadministrationwebapplication]::Local

# Check for use of AppName param, instantiate store
if($AppName -eq 'All') {
  $store = Get-SPSecureStoreApplication -ServiceContext $admin.url -All
} else {
  $store = Get-SPSecureStoreApplication -ServiceContext $admin.url -Name "$AppName" -ErrorAction Stop
}

Function Retrieve-Credentials {
# Grab the SPSite for the SecStore Provider's context
  $aSite = Get-SPSite $admin.url

# Set up SecStore provider
  $issp         = [microsoft.office.securestoreservice.server.securestoreproviderfactory]::Create()
  $issp.Context = [microsoft.sharepoint.spservicecontext]::GetContext($aSite)

# Set up an array for output mechanism
  $data = @()

# Enum through each SecStore app, then through the stored credentials
  foreach($app in $store) { foreach($cred in $issp.GetCredentials($app.TargetApplication.ApplicationId)) {
    $row = '' | Select-Object AppID,CredType,Value
    $row.AppID    = $app.TargetApplication.ApplicationId
    $row.CredType = $cred.CredentialType.ToString()

# Good one-liner for decrypting a SecureString. Stolen from:
# http://blogs.msdn.com/b/timid/archive/2009/09/09/powershell-one-liner-decrypt-securestring.aspx
    $row.Value    = [System.Runtime.InteropServices.marshal]::PtrToStringAuto([System.Runtime.InteropServices.marshal]::SecureStringToBSTR($cred.Credential))
    $data += $row
  }}
  $data
}

Function Retrieve-Users {
# Not worried about validating set here since we do it in the main script params
  Param([string]$UserType)
  $data = @()
# Enum through each SecStore app...
  foreach($app in $store) {
# ...then determine which set of claims to get
    if($users -eq 'Admins') { $claims = $app.TargetApplicationClaims.AdministratorClaims }
                       else { $claims = $app.TargetApplicationClaims.GroupClaims }
    $claims |% {
      $row = '' | Select-Object AppId,ClaimType,Value
      $row.AppId     = $app.TargetApplication.ApplicationId
      $row.ClaimType = $_.ClaimIssuer
      $row.Value     = $_.ClaimValue
      $data += $row
    }
  }
  $data
}

#ENDREGION

#REGION Main Program

if($Retrieve -eq "Credentials") { Retrieve-Credentials }
                           else { Retrieve-Users -UserType $Retrieve }

#ENDREGION

