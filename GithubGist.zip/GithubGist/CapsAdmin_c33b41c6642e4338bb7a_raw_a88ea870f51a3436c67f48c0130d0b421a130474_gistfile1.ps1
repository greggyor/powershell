#download zip file and extract specific directory with powershell

$url = "https://github.com/CapsAdmin/rpg_hitmarks/archive/master.zip"
$folder_in_zip = "rpg_hitmarks-master\lua"
$output_folder = $PSScriptRoot + "\windows_lol"

function download()
{
	if(!(Test-Path $output_folder)) {New-Item -ItemType directory -Path $output_folder}
	
	Write-Output $output_folder
	
	$download_location = (get-item $output_folder).parent.FullName + "\temp.zip"
		
	Remove-Item $download_location -ErrorAction SilentlyContinue -Confirm:$false -Recurse:$true
	
	Invoke-WebRequest $url -OutFile $download_location
		
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($download_location)

	foreach($item in $zip.items())
	{
		$shell.Namespace($output_folder).copyhere($item)
	}
	
	Move-Item ($output_folder + "\" + $folder_in_zip + "\*") $output_folder -ErrorAction SilentlyContinue -Confirm:$false
	Remove-Item ($download_location) -ErrorAction SilentlyContinue -Confirm:$false -Recurse:$true
	Remove-Item ($output_folder + "\" + ($folder_in_zip -split '\\')[0]) -ErrorAction SilentlyContinue -Confirm:$false -Recurse:$true
}

download

