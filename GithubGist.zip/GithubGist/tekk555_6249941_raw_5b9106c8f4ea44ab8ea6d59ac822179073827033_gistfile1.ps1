$ runlevel
N 2

# 0 停止
# 1 シングルユーザモード
# 2 マルチユーザモード
# 6 リブート
# Ubuntu 12.04 LTS. Debian 系 OS では、2-5を区別しない。

