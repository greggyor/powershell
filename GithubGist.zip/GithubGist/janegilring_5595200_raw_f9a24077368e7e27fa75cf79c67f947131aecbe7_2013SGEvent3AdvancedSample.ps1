function Ping-SYHost ([string] $hostName) {
<#
    .SYNOPSIS
        Tests server availability by using PING command.
         
    .DESCRIPTION
        This script will ping a host and return TRUE/FALSE.  Use this function to determine if the host is reachable.
               
    .EXAMPLE
        Ping-SYHost -hostName "CHAGRES01"
#>
    [bool] $result = 0
    $oPing = New-Object System.Net.NetworkInformation.Ping
     
    try {
        $PingStatus = $oPing.Send("$hostName")
        if ($PingStatus.Status -eq "Success"){
            $result = 1
        }
        else {
            $result = 0
        }
    }
    catch {
        $result = 0       
    }
    $result
}
 
 
function Get-SYEvent3{
<#
    .SYNOPSIS
        Displays information about local storage.
 
    .DESCRIPTION
        Queries the Win32_LogicalDisk class to display general information about local storage.  
          
    .EXAMPLE
        Get-SYEvent3 CHAGRES01
        Display local storage information for computer CHAGRES01
         
    .EXAMPLE
        Get-Content C:\PoSh\2013Scripting\Events\3\Event3.txt|% {Get-SYEvent3 -HostList $_ -TargetPath "C:\PoSh\2013Scripting\Events\3"}
        Display local storage information for computers listed in the "Event3.txt" file
#>
    param(
        [Parameter(ValueFromPipeline = $true,
                   ValueFromPipelineByPropertyName = $true)] [array] $HostList = "$env:COMPUTERNAME",
        [string] $TargetPath = "$env:HOMEDRIVE$env:HOMEPATH"
    )
     
$sHTML = ""   
$sHead = @"
<head><title>Drive Free Space Report</title>
<style type="text/css">
BODY{font-family:Verdana; background-color:#white;}
TABLE{table-layout:auto;border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse; background-color:#FFFFFF}
TH{font-family:Verdana,Sans-Serif; color:#000000; font-size:1em; font-weight:bold; border-width: 1px; padding: 2px; border-style: solid; border-color: black; background-color:#CCCCCC}
TD{font-family:Verdana,Sans-Serif; font-size:0.7em; border-width: 1px; padding: 2px; border-style: solid; border-color: black; background-color:#FFFFFF}
</style></head>
<body>
"@
     
    foreach ($HostName in $HostList) {
        if ($HostList.Count -gt 1){
            $sHostName = $HostName
        } else {
            $sHostName = $HostList
        }
 
        if (Ping-SYHost $HostName) {
            $Drives = Get-WmiObject -computername "$HostName" Win32_LogicalDisk -filter "DriveType=3" | foreach {
                add-member -in $_ -membertype NoteProperty -Name SizeGB -Value $([math]::round(($_.Size/1GB),2))
                add-member -in $_ -membertype NoteProperty -Name FreeMB -Value $([math]::round(($_.FreeSpace/1MB),2)) -passThru}
 
            $sHTMLBody = "<H2>Local Fixed Disk Report for $sHostName</H2>"
            $sHTML = $Drives|SELECT @{Name="Drive";Expression={$_.DeviceID}}, @{Name="DriveSize(GB)";Expression={$_.SizeGB}}, @{Name="FreeSpace(MB)";Expression={$_.FreeMB}}|ConvertTo-Html -Fragment
            $sHTMLFooter = "<hr>This report was generated on $(Get-Date -f 'MM/dd/yyyy HH:mm:ss')"
        } else {
            WRITE "Computer $sHostName did not respond to a PING command in a timely manner, check to make suere it is online."
        }
         
        $regex = [regex] '<td>'
        if ($regex.IsMatch($sHTML)){
            if(!(Test-Path "$TargetPath")){
                New-Item -ItemType directory -Path "$TargetPath"
            }
 
            $sBody = "$sHead $sHTMLBody $sHTML $sHTMLFooter </body>"
            $sBody|Out-File -FilePath $TargetPath\$sHostName.htm
            WRITE "$TargetPath\$sHostName.htm"
        }
        start "file:///$TargetPath\$sHostName.htm"
    }
}

