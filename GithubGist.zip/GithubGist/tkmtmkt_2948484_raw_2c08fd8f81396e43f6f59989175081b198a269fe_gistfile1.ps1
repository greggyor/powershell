gwmi -Namespace root\wmi WmiMonitorID | %{
    New-Object PSObject -Property @{
        ManufacturerName  = -join ($_.ManufacturerName | %{[char]$_})
        ProductCodeID     = -join ($_.ProductCodeID    | %{[char]$_})
        SerialNumberID    = -join ($_.SerialNumberID   | %{[char]$_})
        UserFriendlyName  = -join ($_.UserFriendlyName | %{[char]$_})
        WeekOfManufacture = $_.WeekOfManufacture
        YearOfManufacture = $_.YearOfManufacture
    }
}


