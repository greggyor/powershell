Function Get-EventedLogin {
param (
    [int]$eventid
)

#WQL on InstanceCreationEvent
$query = "Select * FROM __InstanceCreationEvent WITHIN 10 WHERE TargetInstance ISA 'Win32_NTLogEvent' AND TargetInstance.LogFile='Security' AND TargetInstance.EventCode='$eventid'"

#WMI Evented Log Monitor
$registerAnEvent = Register-WmiEvent <#-ComputerName $computer#> -Query $query -SourceIdentifier MonitorEvent -Action{
        $output = "" | Select ComputerName,EventCode,EventType,LogFile,Message,TimeGenerated
    
        $Global:MonitorEvent=$event 
        $eventTarget= $Event.SourceEventArgs.NewEvent.TargetInstance
    
        $output.ComputerName = $eventTarget.ComputerName
        $output.EventCode = $eventTarget.EventCode 
        $output.EventType = $eventTarget.EventType
        $output.LogFile = $eventTarget.LogFile
        $output.Message = $eventTarget.Message
        $output.TimeGenerated= $EventTarget.TimeGenerated
    
        # I am using Write-Host so that you can see the result on screen.
        # Write-Output will return the output in Jobs Output Parameter.
        # If your job-id is 3
        # Try (Get-Job -id 3).Output to see how Write-Output / or Just $output writes to the Jobs Output Variable.
        Write-host $output
        } #End of Action Block.

if (! (Get-job -Name MonitorEvent)) {
    $registerAnEvent
    }
    #else { (Get-job -Name MonitorEvent) | Stop-Job; (Get-job -Name MonitorEvent) | Remove-Job; $registerAnEvent}
} #End of Function

Get-EventedLogin -eventid 4648
#Get-EventedLogin -eventid 4624


