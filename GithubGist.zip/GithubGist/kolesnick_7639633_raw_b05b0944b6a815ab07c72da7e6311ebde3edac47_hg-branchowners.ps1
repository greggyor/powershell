hg branches | %{ $_.Split(' ')[0] } | group { hgbranchowner $_ } | %{
    write $_.Name
    $_.Group | write
    write ''
}

