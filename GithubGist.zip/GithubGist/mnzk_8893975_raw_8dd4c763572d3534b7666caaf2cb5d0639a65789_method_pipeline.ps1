# 追加したメソッドをパイプラインで使いたい

$foo = "abc" | Add-Member ScriptMethod Repeat{
    param($n)
    $this * $n
} -PassThru

#Helper で対応
filter Invoke-Method($method){
    $method.Invoke($_)
}
Set-Alias im Invoke-Method


5 | im $foo.Repeat  #=> abcabcabcabcabc



