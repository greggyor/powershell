param(
[String]$filePath="",
[String]$fileName=""
)

$logFile = "C:\temp\log.txt"

Function Log($fileName, $filePath)
{
  $currentDate = Get-Date
  Add-Content $logFile "File Name: ${fileName} FileP Path: ${filePath}"
}

Log $fileName $filePath

