$apikey = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
$baseurl = "http://localhost/redmine"

# issue ID
$child = 1
$parent = 100

$header = @{"Content-Type"="application/xml"}
$url = $baseurl + "/issues/${child}.xml?key=" + $apikey
$xml = [xml] "<?xml version=`"1.0`" encoding=`"UTF-8`"?><issue><parent_issue_id>${parent}</parent_issue_id></issue>"

$result = Invoke-RestMethod $url -Method Put -Body $xml -headers $header


