
var name = "System.Management.Automation, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
var asmName = new System.Reflection.AssemblyName(name);
var asm = System.Reflection.Assembly.Load(asmName);


