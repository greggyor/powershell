
function bootstrap-tentacle{
param($username,$password,$environments,$roles)
          
     $rolestring="@(""" + ($roles -join """,""") + """)"
     $environmentstring="@(""" + ($environments -join """,""") + """)"
     $command = ". c:\redist\configuremachine.ps1;install-tentacle -environments $environmentstring -roles $rolestring"
     $command | set-content c:\installoctopus.ps1
     
     Write-Host "Starting Tentacle install script:"
     $a = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy unrestricted -file c:\installoctopus.ps1 > c:\tentacle-install.log"
     Register-ScheduledTask -TaskName tentacle  -RunLevel Highest -User $username -Password $password -Action $a | Start-ScheduledTask     
     do{
        Start-Sleep -Seconds 15
        $task=Get-ScheduledTask -TaskName tentacle 
    }while($task.State -eq 4)

}



function Install-Tentacle
{ 
    param($environments,$roles)
    
      Write-Output "Beginning Tentacle installation"

      Write-Output "Installing MSI"
      $msiExitCode = (Start-Process -FilePath "msiexec.exe" -ArgumentList "/i c:\redist\octopus.Tentacle.msi /quiet" -Wait -Passthru).ExitCode
      Write-Output "Tentacle MSI installer returned exit code $msiExitCode"
      if ($msiExitCode -ne 0) {
        throw "Installation aborted"
      }

      Write-Output "Configuring and registering Tentacle for $environment $roles"

      cd "${env:ProgramFiles}\Octopus Deploy\Tentacle"
      & .\tentacle.exe create-instance --instance "Tentacle" --config "${env:SystemDrive}\Octopus\Tentacle\Tentacle.config" --console
      & .\tentacle.exe configure --instance "Tentacle" --home "${env:SystemDrive}\Octopus" --console
      & .\tentacle.exe configure --instance "Tentacle" --app "${env:SystemDrive}\Octopus\Applications" --console
      & .\tentacle.exe New-certificate --instance "Tentacle" --console
      $args = @("register-with","--instance","Tentacle","--server","https://YOUR_OCTO_SERVER","--apiKey","YOUR_API_KEY","--comms-style","TentacleActive","--force","--console")
      foreach($role in $roles){
        $args+="--role"
        $args+=$role
      }
      foreach($environment in $environments){
        $args+="--environment"
        $args+=$environment
      }

      & .\Tentacle.exe $args
      & .\tentacle.exe service --instance "Tentacle" --install --console 


}


