########################################################################
# AWS EC2 Windows Bootstrapping Script 
# Supported OS: 
#    - Windows 2008 Server R2 SP1 (TESTED)
#    - Windows 2008 Server (TO BE TESTED)
#    - Windows 2012 Server (TO BE TESTED)

# Image Transformation Target Cloud
#    - VMWare vSphere & VCD
#
# Coppyright (c) 2014, CliQr Technologies, Inc. All rights reserved.
########################################################################
 
param(
	[Parameter(Mandatory=$true)][string]$AccessId,
	[Parameter(Mandatory=$true)][string]$SecretKey,
    [Parameter(Mandatory=$true)][string]$AdminPass,
    [Parameter(Mandatory=$true)][string]$ImageName
)

Start-Transcript -Path 'c:\bootstrap-transcript.txt' -Force
Set-StrictMode -Version Latest
Set-ExecutionPolicy Unrestricted

$log = 'c:\Bootstrap.txt'

$client = new-object System.Net.WebClient


# Disable EC2 agent service
Set-Service -name Ec2Config -startupType Disabled 

Start-Sleep -s 10
Remove-Item *.exe

# TODO: Call pre bundle script
#

# Bundle 
Add-Content $log -value "Creating bundle..."
$client.DownloadFile('https://s3.amazonaws.com/osmosixdev-test/disk2vhd.exe', 'disk2vhd.exe')
Start-Process -FilePath 'C:\Users\Administrator\disk2vhd.exe' -ArgumentList "c: z:\disk.vhd -accepteula" -Wait
Add-Content $log -value "Done."


# Convert VHD to VMDK
&qemu-img convert -O vmdk z:\disk.vhd y:\disk.vmdk

# Convert VMDK
$client.DownloadFile('https://s3.amazonaws.com/osmosixdev-test/vm.ovf', 'y:\vm.ovf')
&ovftool y:\vm.ovf x:\$ImageName.ovf

# Bundle 
Add-Content $log -value "Uploading bundle..."

$client.DownloadFile('http://mvnrepo.cliqr.com/install/gof3r.exe', 'gof3r.exe')

$Env:AWS_ACCESS_KEY_ID = $AccessId
$Env:AWS_SECRET_ACCESS_KEY = $SecretKey

Start-Process -FilePath 'C:\Users\Administrator\gof3r.exe' -ArgumentList "put /p x:\$ImageName-disk1.vmdk /b osmosixdev-test /k $ImageName-disk1.vmdk /c 20"-Wait
Start-Process -FilePath 'C:\Users\Administrator\gof3r.exe' -ArgumentList "put /p x:\$ImageName.ovf /b osmosixdev-test /k $ImageName.ovf /c 20" -Wait

Add-Content $log -value "Done."

#Start-Sleep -m 300000

Add-Content $log -value "Cleaning up..."
$Env:AWS_ACCESS_KEY_ID = "*"
$Env:AWS_SECRET_ACCESS_KEY = "*"



# shutdown /s /f 


