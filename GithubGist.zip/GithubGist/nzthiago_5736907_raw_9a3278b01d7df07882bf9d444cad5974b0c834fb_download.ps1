[Environment]::CurrentDirectory=(Get-Location -PSProvider FileSystem).ProviderPath 
$rss = (new-object net.webclient)
#Set the username for windows auth proxy
#$rss.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
$a = ([xml]$rss.downloadstring("http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/RSS/mp4high")) 
$a.rss.channel.item | foreach{
   $code = $_.comments.split("/") | select -last 1	
   $url = New-Object System.Uri($_.enclosure.url)
   $file = $code + "-" + $_.creator + "-" + $_.title.Replace(":", "-").Replace("?", "").Replace("/", "-").Replace("<", "") + ".mp4"
  if (!(test-path $file)) 
    { 
	$file 
        $wc = (New-Object System.Net.WebClient)
        #Set the username for windows auth proxy
        #$wc.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
        $wc.DownloadFile($url, $file) 
    } 
}

