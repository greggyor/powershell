Function New-DNATRule (
		$EdgeGateway,
		$ExternalNetwork,
		$OriginalIP,
		$OriginalPort,
		$TranslatedIP,
		$TranslatedPort,
		$Protocol) {
	$Edgeview = Search-Cloud -QueryType EdgeGateway -name $EdgeGateway | Get-CIView
	if (!$Edgeview) {
		Write-Warning "Edge Gateway with name $Edgeview not found"
		Exit
	}
	$URI = ($edgeview.Href + "/action/configureServices")
	$wc = New-Object System.Net.WebClient
	# Add Authorization headers
	$wc.Headers.Add("x-vcloud-authorization", $Edgeview.Client.SessionKey)
	$wc.Headers.Add("Content-Type", "application/vnd.vmware.admin.edgeGatewayServiceConfiguration+xml")
	$wc.Headers.Add("Accept", "application/*+xml;version=5.1")
	$webclient = New-Object system.net.webclient
    $webclient.Headers.Add("x-vcloud-authorization",$Edgeview.Client.SessionKey)
    $webclient.Headers.Add("accept",$EdgeView.Type + ";version=5.1")
    [xml]$EGWConfXML = $webclient.DownloadString($EdgeView.href)
	[xml]$OriginalXML = $EGWConfXML.EdgeGateway.Configuration.EdgegatewayServiceConfiguration.NatService.outerxml
	$NewID = [int]($OriginalXML.NatService.natrule | Sort-Object id | Select-Object Id -Last 1).id + 1
    If($NewID -eq 1){
        $NewID = 65537
    }
	$strXML = '<NatRule>
	            <RuleType>DNAT</RuleType>
	            <IsEnabled>true</IsEnabled>
	            <Id>' + $NewID + '</Id>
	            <GatewayNatRule>
	                <Interface type="application/vnd.vmware.admin.network+xml" name="' + $ExternalNetwork.Name + '" href="' + $ExternalNetwork.Href + '"/>
	                <OriginalIp>' + $OriginalIP + '</OriginalIp>
	                <OriginalPort>' + $OriginalPort + '</OriginalPort>
	                <TranslatedIp>' + $TranslatedIP + '</TranslatedIp>
	                <TranslatedPort>' + $TranslatedPort + '</TranslatedPort>
	                <Protocol>' + $Protocol + '</Protocol>
	            </GatewayNatRule>
	        </NatRule>'

	$GoXML = '<?xml version="1.0" encoding="UTF-8"?>
	<EdgeGatewayServiceConfiguration xmlns="http://www.vmware.com/vcloud/v1.5" >
	    <NatService>
	        <IsEnabled>true</IsEnabled>'
	$OriginalXML.NatService.NatRule | ForEach-Object {
		$GoXML += $_.OuterXML
	}
	$GoXML += $StrXML
	$GoXML += '</NatService>
	</EdgeGatewayServiceConfiguration>'
	
	[byte[]]$byteArray = [System.Text.Encoding]::ASCII.GetBytes($GoXML) 
	$UploadData = $wc.Uploaddata($URI, "POST", $bytearray)
}	

Function New-SNATRule (
		$EdgeGateway,
		$ExternalNetwork,
		$OriginalIP,
		$OriginalPort,
		$TranslatedIP,
		$TranslatedPort,
		$Protocol) {
	$Edgeview = Search-Cloud -QueryType EdgeGateway -name $EdgeGateway | Get-CIView
	if (!$Edgeview) {
		Write-Warning "Edge Gateway with name $Edgeview not found"
		Exit
	}
	$URI = ($edgeview.Href + "/action/configureServices")
	$wc = New-Object System.Net.WebClient
	$wc.Headers.Add("x-vcloud-authorization", $Edgeview.Client.SessionKey)
	$wc.Headers.Add("Content-Type", "application/vnd.vmware.admin.edgeGatewayServiceConfiguration+xml")
	$wc.Headers.Add("Accept", "application/*+xml;version=5.1")
	$webclient = New-Object system.net.webclient
    $webclient.Headers.Add("x-vcloud-authorization",$Edgeview.Client.SessionKey)
    $webclient.Headers.Add("accept",$EdgeView.Type + ";version=5.1")
    [xml]$EGWConfXML = $webclient.DownloadString($EdgeView.href)
	[xml]$OriginalXML = $EGWConfXML.EdgeGateway.Configuration.EdgegatewayServiceConfiguration.NatService.outerxml
	$NewID = [int]($OriginalXML.NatService.natrule | Sort-Object id | Select-Object Id -Last 1).id + 1
    If($NewID -eq 1){
        $NewID = 65537
    }
	$strXML = '<NatRule>
		<RuleType>SNAT</RuleType>
		<IsEnabled>true</IsEnabled>
		<Id>' + $NewID + '</Id>
		<GatewayNatRule>
			<Interface type="application/vnd.vmware.admin.network+xml" name="' + $ExternalNetwork.Name + '" href="' + $ExternalNetwork.Href + '"/>
			<OriginalIp>' + $OriginalIP + '</OriginalIp>
			<TranslatedIp>' + $TranslatedIP + '</TranslatedIp>
		</GatewayNatRule>
	</NatRule>'

	$GoXML = '<?xml version="1.0" encoding="UTF-8"?>
	<EdgeGatewayServiceConfiguration xmlns="http://www.vmware.com/vcloud/v1.5" >
	    <NatService>
	        <IsEnabled>true</IsEnabled>'
	$OriginalXML.NatService.NatRule | ForEach-Object {
		$GoXML += $_.OuterXML
	}
	$GoXML += $StrXML
	$GoXML += '</NatService>
	</EdgeGatewayServiceConfiguration>'
	
	[byte[]]$byteArray = [System.Text.Encoding]::ASCII.GetBytes($GoXML) 
	$UploadData = $wc.Uploaddata($URI, "POST", $bytearray)
}	

Function Get-EdgeNATRule ($EdgeGateway)  {  
    $Edgeview = Search-Cloud -QueryType EdgeGateway -name $EdgeGateway | Get-CIView
	if (!$Edgeview) {
		Write-Warning "Edge Gateway with name $Edgeview not found"
		Exit
	}
    $webclient = New-Object system.net.webclient
    $webclient.Headers.Add("x-vcloud-authorization",$Edgeview.Client.SessionKey)
    $webclient.Headers.Add("accept",$EdgeView.Type + ";version=5.1")
    [xml]$EGWConfXML = $webclient.DownloadString($EdgeView.href)
    $NATRules = $EGWConfXML.EdgeGateway.Configuration.EdgegatewayServiceConfiguration.NatService.Natrule
    $Rules = @()
    if ($NATRules){
		$NATRules | ForEach-Object {
	        $NewRule = new-object PSObject -Property @{
	        AppliedOn = $_.GatewayNatRule.Interface.Name;
	        Type = $_.RuleType;
	        OriginalIP = $_.GatewayNatRule.OriginalIP;
	        OriginalPort = $_.GatewayNatRule.OriginalPort;
	        TranslatedIP = $_.GatewayNatRule.TranslatedIP;
	        TranslatedPort = $_.GatewayNatRule.TranslatedPort;
	        Enabled = $_.IsEnabled;
	        Protocol = $_.GatewayNatRule.Protocol
	    }
	        $Rules += $NewRule
	    }
	}
    $Rules
}



# Example of using the functions

Get-EdgeNATRule -EdgeGateway "TEstEG"
New-SNATRule -EdgeGateway "TEstEG" -ExternalNetwork (Get-ExternalNetwork "Test") -OriginalIP "10.0.0.53" -TranslatedIP "192.168.1.53"
New-DNATRule -EdgeGateway "TEstEG" -ExternalNetwork (Get-ExternalNetwork "Test") -OriginalIP "192.168.1.52" -OriginalPort "any" -TranslatedIP "10.0.0.3" -TranslatedPort "any" -Protocol "tcp"