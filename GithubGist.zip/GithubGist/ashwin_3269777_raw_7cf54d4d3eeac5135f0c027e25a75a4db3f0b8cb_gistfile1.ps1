# Delete page 170 from foo.djvu
djvm -d foo.djvu 170

# Delete pages 170-174 from foo.djvu
for ( $i = 0; $i -lt 5; $i++ ) { djvm -d foo.djvu 170 }