gci "\\$(($d=$env:USERDNSDOMAIN))\sysvol\$d\Policies"|?{$_.Name-imatch"^(?<g>\{[A-F\d]{8}(-[A-F\d]{4}){3}-[A-F\d]{12}\})$"}|?{[ADSI]::Exists("LDAP://CN=$($Matched["g"]),CN=Policies,CN=System,DC=$($d-split"\."-join",DC=")")}|%{"{0} is an orphan, remove it"-f$_.FullName}

