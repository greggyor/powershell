# Monad distilled by @dfinke
# Doug's comment here - http://www.jsnover.com/blog/2011/10/01/monad-manifesto/
# Monad Manifesto - http://www.jsnover.com/Docs/MonadManifesto.pdf

<#
  Original Jeffrey Snover / Israel Gat value proposition construct.
  For <Customer> who <Qualifier>, <Product> <Value Statement>.  
  Unlike <Alternative>, <Product> <Differentiator>
#>

<#
  These 6 lines of code from Doug bring clarity of thought.
  Clarity of thought translates into clarity in action. (Script development / Product development.)
  
  We seek clarity for our own sake when we are building things, and for our customers, 
  so that they can understand whether our scripts and products solve their problems.
  
  Clarity is not only required, but paramount before commencing any development effort.
  This is pre-user stories, pre-requirements, pre-schedules and estimates.
  Lack of clarity translates into a muddled product, and this will show-up in your product.
  
  Get clarity before you write code.
#>

$Customer = “application developers”
$Qualifier = “need to expose their administrative functions as command lines and GUIs”
$Product = “PowerShell”
$ValueStatement = “provides a highly productive development framework.”
$Alternative = “building stand-alone command lines”
$Differentiator = @”
provides most of the common
functions including a parser, a data validator/encoder, error reporting mechanisms,
common functions like sorting/filtering/grouping/formatting/outputting and a set of
management models which provide common verb sets, error messages and solutions to
common problems and tools
“@

@”
For $Customer who $Qualifier, $Product $ValueStatement

Unlike $Alternative, $Product $Differentiator
“@


