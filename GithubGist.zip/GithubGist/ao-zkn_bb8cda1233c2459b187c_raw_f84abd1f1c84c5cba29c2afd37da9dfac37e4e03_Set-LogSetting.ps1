### 初期値の設定
 
# ログファイルパス
Remove-Variable -Name LogFilePath -Force -ea silentlycontinue
Set-Variable -Name LogFilePath -Value "common.log" -Option ReadOnly -Scope "Global"
 
# ログレベル
Remove-Variable -Name LogLevel -Force -ea silentlycontinue
Set-Variable -Name LogLevel -Value 1 -Option ReadOnly -Scope "Global"
 
# ログの文字エンコード
Remove-Variable -Name LogEncoding -Force -ea silentlycontinue
Set-Variable -Name LogEncoding -Value "utf8" -Option ReadOnly -Scope "Global"
 
# ------------------------------------------------------------------
# XMLファイルよりログ出力の設定情報をセットする
# 関数名：Set-LogSetting
# 引数  ：XMLFilePath XMLファイルパス
#       ：Appender アペンダ
# 戻り値：なし
# ------------------------------------------------------------------
function Set-LogSetting([String]$XMLFilePath, [String]$Appender){
  #XMLファイルの読込
  $xmlLogSetting = [XML](Get-Content $XMLFilePath -encoding "utf8")
  # 指定したアペンダを取得
  $params = $xmlLogSetting.configuration.appender | Where-Object{$_.name -eq $Appender}
  if($params){
    foreach($param In $params){
      # ログファイルパス
      if("file" -eq $param.name){
        Set-Variable -Name LogFilePath -Value ($param.value) -Option ReadOnly -Scope "Global" -Force
      }
      # ログ文字エンコード
      if("encode" -eq $param.name){
        Set-Variable -Name LogEncoding -Value ($param.value) -Option ReadOnly -Scope "Global" -Force
      }
      # ログの種類
      if("loglevel" -eq $param.name){
        Set-Variable -Name LogLevel -Value ($param.value) -Option ReadOnly -Scope "Global" -Force
      }
    }
  }
}