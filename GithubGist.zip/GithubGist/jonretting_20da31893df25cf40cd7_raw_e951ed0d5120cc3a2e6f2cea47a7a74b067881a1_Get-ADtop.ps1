# Get-ADtop
# @ JMR 2012 All right reserved, not for resale
#
# Retrieves Realtime CPU/MEM/DISK usage details from 
# AD Computer Objects via provided BaseDN
# Or from provided ComputerName
# Probes computer names for connectivity before executing
#

# -SampleTime is the amount of time to sample the CPU usage and provide avg
#   default is 2 seconds
# -Sort results will be sorted by CPU, MEM, or DISK usage descending
#   default is no sorting
# -BaseDN is the base search path used to gather computer object names
#   specify the default BaseDN by editing param->string->BaseDN
# -ComputerName will bypass generation of AD computer object list
#   and only scan the provided ComputerName

# Examples
# Get-ADtop -ComputerName ThisComputer -SampleTime 4
#   Get usage details of "ThisComputer" and sample the CPU usage over a 4 second period
# Get-ADtop -Sort MEM
#   Sort results by Memory usage
# Get-ADtop -BaseDN "OU=name,DC=domain,DC=com" -Sort CPU
#   Use the provided BaseDN and sort by CPU usage
# Get-ADtop -SampleTime 1 -Sort CPU
#   Sample CPU usage for 1 second and sort results by CPU usage

Function Get-ADtop {
    [CmdletBinding()]
    param(
        [String]$ComputerName,
        [String]$Sort = "none",  
        [String]$BaseDN = "OU=name,DC=domain,DC=com",  # Edit Default Base DN
        [String]$SampleTime = 2
    )
    If ($ComputerName) {
        $Computers = $ComputerName
    } else {
        $Computers = Get-ADComputer -Filter * -Properties * -SearchBase $BaseDN -EA SilentlyContinue | % {$_.Name}
    }
    $DataSet = @()
    $Targets = @()
    ForEach ($Comp in $Computers) {
        If (Test-Connection -ComputerName $Comp -Count 1 -Quiet -TimeToLive 1 -EA SilentlyContinue) {
            If (!(Get-WmiObject -ComputerName $Comp win32_OperatingSystem -EA SilentlyContinue)) { break }
            $Targets += $Comp
        }
    }
    $CompCount = $Computers | Measure-Object | % {$_.Count}
    $DeadCount = $CompCount - ($Targets | Measure-Object | % {$_.Count})
    If (!($DeadCount -eq 0)) {
        Write-Host "`n$DeadCount unavailable computers removed"
    }
    Write-Host "`nGathering realtime CPU/MEM/DISK Usage data from $CompCount computers..."
    ForEach ($Comp in $Targets) {
        $proc = (Get-WmiObject -ComputerName $Comp -class win32_processor -EA SilentlyContinue | Measure-Object -property LoadPercentage -Average | Select Average | % {$_.Average / 100}).ToString("P")
        $mem = Get-WmiObject -ComputerName $Comp win32_OperatingSystem -EA SilentlyContinue 
        $mem = (($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / $mem.TotalVisibleMemorySize).ToString("P")
        $disk = Get-WmiObject -ComputerName $Comp -class Win32_LogicalDisk -filter "DriveType=3" -EA SilentlyContinue 
        $disk = (($disk.Size - $disk.FreeSpace) / $disk.Size).ToString("P")
        $Info = [pscustomobject]@{
            'Computer' = $Comp
            'CPU Usage' = $proc
            'MEM Usage' = $mem
            'Disk Usage' = $disk
        }
        $DataSet += Add-Member -InputObject $Info -TypeName Computers.CPU.Usage -PassThru    
    }
    Switch ($Sort) {
        "none" { $DataSet }
        "CPU" { $DataSet | Sort-Object -Property "CPU Usage" -Descending }
        "MEM" { $DataSet | Sort-Object -Property "MEM Usage" -Descending }
        "DISK" { $DataSet | Sort-Object -Property "DISK Usage" -Descending }
    }
}


