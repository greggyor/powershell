# convert tifs to jpgs
# requires imagemagick

Param(
    [int]$size = 1000,
    [string]$indir = ".",
    [string]$outdir = $indir
    )

if (!(test-path $outdir)) {
    mkdir $outdir
}

$files = ls "$indir\*.*" -include *.tif,*.tiff

foreach ($file in $files) {
    $input = ('"{0}"' -f  $file.FullName)
    $output = ('"{0}\{1}.jpg"' -f $outdir, $file.BaseName)
    $args = "$input -colorspace RGB -resize $size -colorspace sRGB $output"
    write-host $args
    start-process convert $args -wait -NoNewWindow
 }

