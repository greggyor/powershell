$megs=1000;$w=New-Object IO.streamWriter $env:temp\data.dat;[char[]]$c='azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN0123456789-_';1..$megs|ForEach-Object{1..4|ForEach-Object{$r=$c|Get-Random -Count $c.Count;$s=-join $r;$w.Write($s*4kb);}};

