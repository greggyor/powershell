
function Get-GroupMailAddresses {
    PARAM([string[]]$GroupName)
    BEGIN { 
        $DSGroupNameBasis = { PARAM([string]$Name) PROCESS { "(&(groupType=-2147483646)(name=$Name))" } }
    }
    PROCESS { 
        (new-object DirectoryServices.DirectorySearcher( & $DSGroupNameBasis -Name $GroupName )).
        FindAll().
        Properties['member'] | 
        % {
            ([ADSI]"LDAP://$_").mail
        }
    }
    END { }
}


