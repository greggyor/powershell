$json = @"
{"A": {"property1": "value1", "property2": "value2"}, "B": {"property1": "value3", "property2": "value4"}}
"@

$parsed = $json | ConvertFrom-Json
foreach ($line in $parsed | Get-Member) {
	echo $parsed.$($line.Name).property1
	echo $parsed.$($line.Name).property2
}

