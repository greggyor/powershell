# find_suspect_kbs.ps1

# MS14-045: Description of the security update for kernel-mode drivers: August 12, 2014
# http://support.microsoft.com/kb/2982791
# 
# http://blogs.technet.com/b/heyscriptingguy/archive/2011/08/22/use-powershell-to-easily-find-information-about-hotfixes.aspx

gwmi -cl win32_reliabilityRecords -filter "sourcename = 'Microsoft-Windows-WindowsUpdateClient'" |

where { $_.message -match 'KB2982791' -OR $_.message -Match 'KB2970228' -OR $_.message -Match 'KB2975719' -OR $_.message -Match 'KB2975331'} |

FT @{LABEL = "date";EXPRESSION = {$_.ConvertToDateTime($_.timegenerated)}},

message -autosize –wrap


