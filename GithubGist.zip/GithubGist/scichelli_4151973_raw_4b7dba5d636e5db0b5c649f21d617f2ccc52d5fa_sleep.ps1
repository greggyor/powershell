$WarningDuration = 5
$MessagePlural = ""
if ($WarningDuration -gt 1) { $MessagePlural = "s" }

[System.Media.SystemSounds]::Asterisk.play()
[void] [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[windows.forms.messagebox]::show(("Save your work. Sleep in {0} minute{1}." -f $WarningDuration, $MessagePlural))
Start-Sleep -Second ($WarningDuration * 60)

[System.Media.SystemSounds]::Beep.play()
Start-Sleep -Second 2
[System.Windows.Forms.Application]::SetSuspendState("Suspend", $false, $true)

