param (
    [Parameter(Position = 0, Mandatory=$True)]
    [string]$ProjectName,

    [Parameter(Position = 1, Mandatory=$True)]
    [string]$SiteName,

    [Parameter(Position = 2, Mandatory=$True)]
    [string]$Environment
)

$NewRelicLicenseKey = "<license key>"
$PackagePath = "$ProjectName.csproj.zip"
$StagingSiteName = "$SiteName(staging)"
$ApplicationEnvironment = "Testing";
if ($Environment -eq "production")
{
    $ApplicationEnvironment = "Production";
}

function AbortDeployment( $message )
{
    Write-Output "##teamcity[buildStatus status='FAILURE' text='$message']"
    Exit 1
}

function StartTeamCityBlock( $name )
{
    Write-Output "##teamcity[blockOpened name='$name']"
}

function StopTeamCityBlock( $name )
{
    Write-Output "##teamcity[blockClosed name='$name']"
}

function LogTeamCityStatus( $message )
{
    Write-Output "##teamcity[message text='$message']"
}

if (!(Test-Path "$PackagePath"))
{
    AbortDeployment "Web site package $PackagePath not found"
}

#
# Initialize the Azure environment.
#

$SubscriptionName = "<Azure subscription name>"
Select-AzureSubscription "$SubscriptionName"

#
# Stop the current staging web site and prepare for a new deployment.
#

function DeployPackageToStaging()
{
    StartTeamCityBlock "Staging deployment"

    LogTeamCityStatus "Disabling NewRelic RPM profiling"
    $appSettings = @{
        "COR_ENABLE_PROFILING" = "0";
    }
    try
    {
        Set-AzureWebsite -Name "$SiteName" -Slot "staging" -AppSettings $appSettings -Verbose -ErrorAction Stop 
    }
    catch
    {
        Write-Host "Exception caught during NewRelic deactivation ($($_.Exception.GetType().FullName)): $($_.Exception.Message)"
        AbortDeployment "Unable to deactivate NewRelic RPM"
    }

    LogTeamCityStatus "Deploying web site $StagingSiteName"
    try
    {
        Publish-AzureWebsiteProject -Name "$SiteName" -Slot "staging" -Package "$PackagePath" -Verbose -ErrorAction Stop
    }
    catch
    {
        Write-Host "Exception caught during deployment ($($_.Exception.GetType().FullName)): $($_.Exception.Message)"
        AbortDeployment "Unable to deploy website"
    }

    LogTeamCityStatus "Enabling NewRelic RPM profiling"
    $appSettings = @{
        "COR_ENABLE_PROFILING" = "1";
        "COR_PROFILER" = "{71DA0A04-7777-4EC6-9643-7D28B46A8A41}";
        "COR_PROFILER_PATH" = "C:\Home\site\wwwroot\newrelic\NewRelic.Profiler.dll";
        "NEWRELIC_HOME" = "C:\Home\site\wwwroot\newrelic";
        "NEWRELIC_LICENSEKEY" = "$NewRelicLicenseKey";
        "ApplicationEnvironment" = "$ApplicationEnvironment";
        "NewRelic.AppName" = "$SiteName";
    }
    try
    {
        Set-AzureWebsite -Name "$SiteName" -Slot "staging" -AppSettings $appSettings -Verbose -ErrorAction Stop 
    }
    catch
    {
        Write-Host "Exception caught during NewRelic deactivation ($($_.Exception.GetType().FullName)): $($_.Exception.Message)"
        AbortDeployment "Unable to deactivate NewRelic RPM"
    }

    StopTeamCityBlock "Staging deployment"
}

#
# Swap the current staging web site to the production site.
#

function SwapStagingToProduction()
{
    StartTeamCityBlock "Production swap"

    LogTeamCityStatus "Swapping staging deployment to production"
    try
    {
        Switch-AzureWebsiteSlot -Name "$SiteName" -Force -Verbose -ErrorAction Stop
    }
    catch
    {
        Write-Host "Exception caught during slot swapping ($($_.Exception.GetType().FullName)): $($_.Exception.Message)"
        AbortDeployment "Unable to swap staging site to production"
    }

    StopTeamCityBlock "Production swap"
}

#
# Main entry point; start the deployment process
#

DeployPackageToStaging
SwapStagingToProduction

LogTeamCityStatus "Azure Web Site $ProjectName successfully deployed to environment $Environment"
Write-Output "##teamcity[buildStatus status='SUCCESS']"


