# Epitech / EIP Technical assessment
# VM EIP: Launch first `Set-ExecutionPolicy RemoteSigned`

# Variables
$basedir = "$env:HOMEDRIVE$env:HOMEPATH\Desktop\tmp"
$nodeVersion = "v0.8.18"

# Common
$webClient = New-Object System.Net.WebClient
$shell = New-Object -com shell.application

# Create Base directory
echo "[+] Creating $basedir"
if (test-path $basedir) { Remove-Item -Recurse -Force -ErrorAction 0 $basedir | out-null }
mkdir $basedir -ErrorAction 0 | out-null

# Download and install Node.js
echo "[+] Downloading http://nodejs.org/dist/$nodeVersion/node-$nodeVersion.msi"
$webClient.DownloadFile("http://nodejs.org/dist/$nodeVersion/node-$nodeVersion-x86.msi","$basedir\node-$nodeVersion-x86.msi")
echo "[+] Installing node-$nodeVersion-x86.msi"
Start-Process -FilePath msiexec.exe -ArgumentList @("/i", "$basedir\node-$nodeVersion-x86.msi", "/qr") -Wait

# Musicjson
$zipGithub = "https://github.com/FlatIO/musicjson/archive/master.zip"
echo "[+] Downloading $zipGithub"
$webClient.DownloadFile($zipGithub, "$basedir\musicjson.zip")
echo "[+] Unzipping $basedir\musicjson.zip"
$shell.Namespace("$basedir").CopyHere($shell.Namespace("$basedir\musicjson.zip").Items(), 16)
echo "[+] npm install -d"
cd ($basedir + "\" + @($shell.Namespace("$basedir\musicjson.zip").Items())[0].Name)
npm install -d -q

# Musicjson test / Todo Cakefile instead of UNIX makefile ?
echo "[=] JSHint"
node_modules/.bin/jshint bin lib
echo "[=] Unit tests"
node_modules/.bin/nodeunit tests

