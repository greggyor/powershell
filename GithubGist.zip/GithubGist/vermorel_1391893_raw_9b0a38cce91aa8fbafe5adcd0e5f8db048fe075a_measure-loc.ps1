# Measure-Loc
# By Joannes Vermorel, 2010
# Recurse directories and compute the number of C# lines
# Usage: measure-loc

function Measure-Loc
{

param(
)

begin
{
}

process
{

  ls -recurse -filter *.cs | gc | ? { $_.Trim().Length -gt 1 } | measure-object -line
}

end
{
}

}


