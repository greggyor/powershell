## --------------------------------------------------------------------------------------
## Configuration
## --------------------------------------------------------------------------------------

$isEnabled = $OctopusParameters["Octopus.Action.IISWebSite.CreateOrUpdateWebSite"]
if (!$isEnabled -or ![Bool]::Parse($isEnabled)) 
{
   exit 0
}

$WebSiteName = $OctopusParameters["Octopus.Action.IISWebSite.WebSiteName"]
$ApplicationPoolName = $OctopusParameters["Octopus.Action.IISWebSite.ApplicationPoolName"]
$bindingString = $OctopusParameters["Octopus.Action.IISWebSite.Bindings"]
$appPoolFrameworkVersion = $OctopusParameters["Octopus.Action.IISWebSite.ApplicationPoolFrameworkVersion"]
$webRoot = $OctopusParameters["Octopus.Action.IISWebSite.WebRoot"]
$enableWindows = $OctopusParameters["Octopus.Action.IISWebSite.EnableWindowsAuthentication"]
$enableBasic = $OctopusParameters["Octopus.Action.IISWebSite.EnableBasicAuthentication"]
$enableAnonymous = $OctopusParameters["Octopus.Action.IISWebSite.EnableAnonymousAuthentication"]
$applicationPoolIdentityType = $OctopusParameters["Octopus.Action.IISWebSite.ApplicationPoolIdentityType"]
$applicationPoolUsername = $OctopusParameters["Octopus.Action.IISWebSite.ApplicationPoolUsername"]
$applicationPoolPassword = $OctopusParameters["Octopus.Action.IISWebSite.ApplicationPoolPassword"]

if (! $webRoot) {
	$webRoot = "."
}

$webRoot = (resolve-path $webRoot)

$wsbindings = new-object System.Collections.ArrayList

# Each binding string consists of a protocol/binding information (IP, port, hostname)/SSL thumbprint
# Binding strings are pipe (|) separated to allow multiple to be specified
$bindingString.Split("|") | foreach-object {
    $bindingParts = $_.split("/")
    $wsbindings.Add(@{ protocol=$bindingParts[0];bindingInformation=$bindingParts[1];thumbprint=$bindingParts[2] }) | Out-Null
}

Import-Module WebAdministration

# For any HTTPS bindings, ensure the certificate is configured for the IP/port combination
$wsbindings | where-object { $_.protocol -eq "https" } | foreach-object {
    $sslCertificateThumbprint = $_.thumbprint.Trim()
    Write-Host "Finding SSL certificate with thumbprint $sslCertificateThumbprint"
    
    $certificate = Get-ChildItem Cert:\LocalMachine -Recurse | Where-Object { $_.Thumbprint -eq $sslCertificateThumbprint -and $_.HasPrivateKey -eq $true }
    if (! $certificate) 
    {
        throw "Could not find certificate under Cert:\LocalMachine with thumbprint $sslCertificateThumbprint. Make sure that the certificate is installed to the Local Machine context and that the private key is available."
    }

    Write-Host ("Found certificate: " + $certificate.Subject)

    $bindingInfo = $_.bindingInformation
    $bindingParts = $bindingInfo.split(':')
    $ipAddress = $bindingParts[0]
    if (! $ipAddress) {
        $ipAddress = "0.0.0.0"
    }
    $port = $bindingParts[1]

    $sslBindingsPath = ("IIS:\SslBindings\" + $ipAddress + "!" + $port)

    $sslBinding = get-item $sslBindingsPath -ErrorAction SilentlyContinue
    if (! $sslBinding) {
        new-Item $sslBindingsPath -Value $certificate | Out-Null
    } else {
        Set-Item $sslBindingsPath -Value $certificate | Out-Null
    }
}

## --------------------------------------------------------------------------------------
## Run
## --------------------------------------------------------------------------------------

pushd IIS:\

$appPoolPath = ("IIS:\AppPools\" + $ApplicationPoolName)
$pool = Get-Item $appPoolPath -ErrorAction SilentlyContinue
if (!$pool) { 
    Write-Host "Application pool `"$ApplicationPoolName`" does not exist, creating..." 
    new-item $appPoolPath
    $pool = Get-Item $appPoolPath
} else {
    Write-Host "Application pool `"$ApplicationPoolName`" already exists"
}

Write-Host "Set application pool identity: $applicationPoolIdentityType"
if ($applicationPoolIdentityType -eq "SpecificUser") {
	Set-ItemProperty $appPoolPath -name processModel -value @{identitytype="SpecificUser"; username="$applicationPoolUsername"; password="$applicationPoolPassword"}
} else {
	Set-ItemProperty $appPoolPath -name processModel -value @{identitytype="$applicationPoolIdentityType"}
}

Write-Host "Set .NET framework version: $appPoolFrameworkVersion" 
Set-ItemProperty $appPoolPath managedRuntimeVersion $appPoolFrameworkVersion

$sitePath = ("IIS:\Sites\" + $webSiteName)
$site = Get-Item $sitePath -ErrorAction SilentlyContinue
if (!$site) { 
    Write-Host "Site `"$WebSiteName`" does not exist, creating..." 
    $id = (dir iis:\sites | foreach {$_.id} | sort -Descending | select -first 1) + 1
    new-item $sitePath -bindings @{protocol="http";bindingInformation=":81:od-temp.example.com"} -id $id -physicalPath $webRoot
} else {
    Write-Host "Site `"$WebSiteName`" already exists"
}

Write-Host "Assigning website to application pool..."
Set-ItemProperty $sitePath -name applicationPool -value $ApplicationPoolName

Write-Host ("Home directory: " + $webRoot)
Set-ItemProperty $sitePath -name physicalPath -value "$webRoot"

Write-Host "Assigning bindings to website..."
Clear-ItemProperty $sitePath -name bindings
for ($i = 0; $i -lt $wsbindings.Count; $i = $i+1) {
    Write-Host ("Binding: " + ($wsbindings[$i].protocol + " " + $wsbindings[$i].bindingInformation))
    New-ItemProperty $sitePath -name bindings -value ($wsbindings[$i])
}

Write-Host "Anonymous authentication enabled: $enableAnonymous"
Set-WebConfigurationProperty -filter /system.webServer/security/authentication/anonymousAuthentication -name enabled -value "$enableAnonymous" -location $WebSiteName -PSPath "IIS:\"

Write-Host "Basic authentication enabled: $enableBasic"
Set-WebConfigurationProperty -filter /system.webServer/security/authentication/basicAuthentication -name enabled -value "$enableBasic" -location $WebSiteName -PSPath "IIS:\"

Write-Host "Windows authentication enabled: $enableWindows"
Set-WebConfigurationProperty -filter /system.webServer/security/authentication/windowsAuthentication -name enabled -value "$enableWindows" -location $WebSiteName -PSPath "IIS:\"

# It can take a while for the App Pool to come to life (#490)
Start-Sleep -s 1

$state = Get-WebAppPoolState $ApplicationPoolName
if ($state.Value -eq "Stopped") {
    Write-Host "Application pool is stopped. Attempting to start..."
    Start-WebAppPool $ApplicationPoolName
}

$state = Get-WebsiteState $WebSiteName
if ($state.Value -eq "Stopped") {
    Write-Host "Web site is stopped. Attempting to start..."
    Start-Website $WebSiteName
}

popd

Write-Host "IIS configuration complete"


