param( $logsDirectory, $compressionDirectory )

$ScriptDir = $MyInvocation.MyCommand.Path | split-path
# https://github.com/remotex/Scripts/tree/master/Windows
Set-Alias enableFeature $ScriptDir\Enable-WindowsFeature.ps1

$wantedFeatures = @()
# install IIS Role
$wantedFeatures += "IIS-WebServerRole"
$wantedFeatures += "IIS-WebServer"
$wantedFeatures += "IIS-CommonHttpFeatures"
$wantedFeatures += "IIS-DefaultDocument"
$wantedFeatures += "IIS-DirectoryBrowsing"
$wantedFeatures += "IIS-HttpErrors"
$wantedFeatures += "IIS-HttpRedirect"
$wantedFeatures += "IIS-StaticContent"
$wantedFeatures += "IIS-HealthAndDiagnostics"
$wantedFeatures += "IIS-HttpTracing"
$wantedFeatures += "IIS-CustomLogging"
$wantedFeatures += "IIS-HttpLogging"
$wantedFeatures += "IIS-LoggingLibraries"
$wantedFeatures += "IIS-RequestMonitor"
$wantedFeatures += "IIS-Performance"
$wantedFeatures += "IIS-HttpCompressionDynamic"
$wantedFeatures += "IIS-HttpCompressionStatic"
$wantedFeatures += "IIS-Security"
$wantedFeatures += "IIS-BasicAuthentication"
$wantedFeatures += "IIS-WindowsAuthentication"
$wantedFeatures += "IIS-RequestFiltering"
$wantedFeatures += "IIS-WebServerManagementTools"
$wantedFeatures += "IIS-ManagementConsole"
$wantedFeatures += "IIS-ManagementScriptingTools"
$wantedFeatures += "IIS-ISAPIExtensions"
$wantedFeatures += "IIS-ISAPIFilter"
$wantedFeatures += "IIS-NetFxExtensibility"
$wantedFeatures += "IIS-ASPNET"
$wantedFeatures += "IIS-ApplicationDevelopment"

$wantedFeatures += "NetFx3"
$wantedFeatures += "WAS-WindowsActivationService"
$wantedFeatures += "WAS-NetFxEnvironment"
$wantedFeatures += "WAS-ConfigurationAPI"
$wantedFeatures += "WCF-HTTP-Activation"
$wantedFeatures += "WCF-NonHTTP-Activation"

enableFeature -features $wantedFeatures

Import-Module WebAdministration

if( $logsDirectory ) {

  Write-Host "Configuring site defaults logging settings to point out base directory $logsDirectory"			

	$logFilesDir = join-path $logsDirectory "LogFiles"
	$frebFilesDir = join-path $logsDirectory "FailedReqLogFiles"

	if(!(Test-Path $logFilesDir)) {
		mkdir $logFilesDir | Out-Null
	}
	if(!(Test-Path $frebFilesDir)) {
		mkdir $frebFilesDir | Out-Null
	}	

	Set-WebConfigurationProperty "/system.applicationHost/sites/siteDefaults" -pspath IIS:\ -name logfile.directory -value $logFilesDir
	Set-WebConfigurationProperty "/system.applicationHost/sites/siteDefaults" -pspath IIS:\ -name traceFailedRequestsLogging.directory -value $frebFilesDir
}

# error handling routine for error that only occurs when you are trying to do this on a server with high load. (Pro tip: Already checked MaxMbPerShell prop of wsman shell settings!)
function applyConfigWithRetry( [ScriptBlock] $sb ) {
	$done = $false
	do {
		try {
			& $sb
			$done = $true
		} catch {
			if( $_.Exception.Message -notlike "*HRESULT: 0x800700B7*" -and $_.Exception.Message -notlike "*HRESULT: 0x80070008*" -and $_.Exception.Message -notlike "*error: 800705af*" ) {
				throw $_
			}
			sleep -Milliseconds 500
		}
	}
	while( !$done )
}			
# http://stackoverflow.com/questions/2203798/in-iis7-gzipped-files-do-not-stay-that-way
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/serverRuntime" -pspath IIS:\ -name frequentHitThreshold -value 1 }
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/urlCompression" -pspath IIS:\ -name doStaticCompression -value "true" }
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/urlCompression" -pspath IIS:\ -name doDynamicCompression -value "true" }
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/httpCompression" -pspath IIS:\ -name minFileSizeForComp -value 1024 }
if( $compressionDirectory ) {
	applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/httpCompression" -pspath IIS:\ -name directory -value $compressionDirectory }
}
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/httpCompression/scheme[@name='gzip']" -pspath IIS:\ -name staticCompressionLevel -value 9 }
applyConfigWithRetry { Set-WebConfigurationProperty "/system.webServer/httpCompression/scheme[@name='gzip']" -pspath IIS:\ -name dynamicCompressionLevel -value 4 }
applyConfigWithRetry { 
	clear-webconfiguration -filter "/system.webServer/httpCompression/dynamicTypes/add[@mimeType='application/xml']" -pspath IIS: -WarningAction SilentlyContinue
	add-webconfiguration "/system.webServer/httpCompression/dynamicTypes" -pspath IIS:\ -value (@{mimeType="application/xml";enabled="true"}) 
}
applyConfigWithRetry { 
	clear-webconfiguration -filter "/system.webServer/httpCompression/dynamicTypes/add[@mimeType='application/json']" -pspath IIS: -WarningAction SilentlyContinue
	add-webconfiguration "/system.webServer/httpCompression/dynamicTypes" -pspath IIS:\ -value (@{mimeType="application/json";enabled="true"}) 
}