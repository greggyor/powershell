Framework "4.0"
# Framework "4.0x64"

properties {
  $solutionDir = "..\src"
  $buildConfiguration = 'RELEASE'
  $packages = join-path $solutionDir "packages"
}

task default -depends run-unit-tests

function Get-Solutions (){
  ls (join-path $solutionDir "*.sln") | %{ $_.FullName}
}

function Run-MsBuild ($a) {
   Get-Solutions | %{ exec { msbuild $_ /NoLogo /m /p:Configuration=$buildConfiguration /v:m $a}}
}

function Restore-SolutionNugets() {
  if (!(test-path $packages)) { mkdir $packages }
  pushd $packages
  exec {..\.nuget\nuget install ..\.nuget\packages.config}
  popd
}

task clean {
  Run-MsBuild '/t:Clean'
}

task compile -depends clean {
  Restore-SolutionNugets 
  Run-MsBuild '/t:Build'
}

function  testDlls($pattern)  {
  return  ls "$SolutionDir\*\bin\$buildConfiguration" -rec `
      | where { $_.Name.EndsWith(".dll") } `
      | where { $_.Name.Contains("Tests") } `
      | where { (Test-Path ((split-path $_.FullName) + $pattern)) -eq $True } `
      | % { $_.FullName }
}

task run-unit-tests -depends compile -description "xUnit unit tests" {
    $xunitDlls = testDlls "\xunit.dll"
    $xunit = @(ls $solutionDir -Include "xunit.console.clr4.exe" -Recurse)[0].FullName
    exec{ & $xunit $xunitDlls /noshadow }
}


