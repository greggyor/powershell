#create directory if not exists
$TARGETDIR = "c:\Temp\test\1\2"
if(!(Test-Path -Path $TARGETDIR )){
    New-Item -ItemType directory -Path $TARGETDIR
}

#get basename of url
$URL = "http://stackoverflow.com/questions/4546567/get-last-element-of-pipeline-in-powershell"
$NAME = $URL.Split('/') | Select-Object -Last 1
echo $NAME



