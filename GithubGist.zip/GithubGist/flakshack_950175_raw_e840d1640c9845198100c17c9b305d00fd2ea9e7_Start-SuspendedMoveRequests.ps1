#############################################################################
# Procedure:	Start-SuspendedMoveRequests.PS1		                          
# Author:	Scott Vintinner                                   
# Last Edit:    4/30/2011
# Purpose:      This script will start a move request in suspended mode and 
#		email the selected user.
#
# PS Notes      Computers must have Powershell scripts enabled by an admin:
#		set-executionpolicy remotesigned
##
# This work is licensed under a Creative Commons Attribution 3.0 Unported License. 
# http://creativecommons.org/licenses/by/3.0/
# © 2011 Scott Vintinner 
#############################################################################

# Parameters
Param([string[]]$identities);
$identities = $identities | Sort-Object;

#Constants
$smtpserver = '10.1.19.40';
$emailFrom = "youremail@example.com";
$body = "
	I will begin moving your mailbox in the next few minutes.  Your Outlook mailbox will be offline for somewhere between 10 minutes and 2 hours depending on the amount of data.  In addition, you will not be able to send or receive Blackberry emails during this time.

Please contact me as soon as possible if this is a problem.

	";



# Submit the move requests in SUSPENDED state
foreach($identity in $identities) {
	new-MoveRequest -Identity $identity -BadItemLimit 5 -Suspend:$true;
	
	# Email a notification to the user
	Write-Host "Sending 15-minute until move email notification to $identity";
	$timeOfMove = ((get-date).AddMinutes(15)).toShortTimeString();  
	$subject = "Mailbox move starting @ $timeOfMove";

	$emailAddress = (Get-Mailbox -Identity $identity | select PrimarySmtpAddress).PrimarySmtpAddress;		
	$smtp = new-object Net.Mail.SmtpClient($smtpServer);
	$smtp.Send($emailFrom, $emailAddress, $subject, $body);		
}



