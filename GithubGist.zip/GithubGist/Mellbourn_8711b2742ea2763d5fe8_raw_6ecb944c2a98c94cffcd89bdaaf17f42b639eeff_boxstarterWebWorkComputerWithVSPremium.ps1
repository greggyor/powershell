Set-WindowsExplorerOptions -EnableShowHiddenFilesFoldersDrives -EnableShowFileExtensions -EnableShowFullPathInTitleBar
Update-ExecutionPolicy RemoteSigned

[Environment]::SetEnvironmentVariable("HTTP_PROXY", "http://seproxy.hm.com:8080/", "Machine")
[Environment]::SetEnvironmentVariable("HTTP_PROXY", "http://seproxy.hm.com:8080/", "Process")

choco install git.install
#choco install notepadplusplus.install
#choco install notepad2
choco install 7zip.install
# some want google chrome beta channel
choco install Google-Chrome-x64
choco install PowerShell				
# note that some need Professional
choco install VisualStudio2013Premium -InstallArguments "/Features:'SQL WebTools'"
choco install visualsvn
choco install resharper
choco install stylecop
choco install kdiff3
choco install tortoisesvn
choco install poshgit

choco install gitextensions
choco install tortoisegit
choco install nodejs.install
# this is old and not maintained
#choco install typescript
choco install fiddler4

#not needed anymore
# choco install Compass

choco install visualstudio2013-webessentials.vsix
choco install jdk8

choco install atom
choco install ConEmu
choco install sysinternals
choco install rdcman
choco install nuget.commandline

choco install mssqlserver2014express
choco install mssqlservermanagementstudio2014express

# Proxy settings are needed for the NPM calls.
npm config set proxy http://seproxy.hm.com:8080
npm install -g grunt
npm install -g gulp

git.exe config --global core.autocrlf false
git.exe config --global core.safecrlf false
git.exe config --global push.default simple
git.exe config --global core.preloadindex true
git.exe config --global mergetool.keepbackup false
git.exe config --global http.proxy http://seproxy.hm.com:8080



