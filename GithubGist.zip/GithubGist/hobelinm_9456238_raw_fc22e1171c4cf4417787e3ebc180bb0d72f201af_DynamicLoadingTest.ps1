# Considering the test function in a given location
# you can ignore the following line
"function test{""Original Test""}" > test.ps1

# This is a sample of the stub that would peform the function of 
# finding and downloading the original function. For the sake of
# the test we can consider that's already done in test.ps1 in $PWD
function test
{
  "Stub Test"
  # Future calls will go to the original test method and not this stub
  Remove-Item function:test 
  # Replace this line for finding-loading-installing locally
  Import-Module .\test.ps1 -Global
  # Since the intended call was to the original function, call it
  test
}

