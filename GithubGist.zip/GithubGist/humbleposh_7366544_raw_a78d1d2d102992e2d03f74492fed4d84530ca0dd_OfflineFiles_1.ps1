# Emumerate Offline Files
$OfflineFilesItem = [wmiclass]"\\localhost\root\cimv2:win32_offlinefilesItem"
$FileList = $OfflineFilesItem.GetInstances()

# Filter based on share that you want to know if someone has taken offline
$FileList | ?{$_.ItemPath -like "\\server\share*"} | select ItemPath


