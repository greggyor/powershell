#############################################################################
#
# Desc: Helper file to be dotted/imported in so that some things
#       can be done a little bit easier
#
# Date: 2014-11-04 - M. Stevenson - Initial Version
#                                   Added HC-EnableRDP, HC-EnterSession
#
#############################################################################

#
# Desc: enable RDP on remote computer
# Date: 2014-11-04 - M. Stevenson - Initial Version
#
Function HC-EnableRDP {
    [CmdletBinding()]
    param(
        [parameter(Mandatory=$true,ValueFromPipeline=$true,HelpMessage="Enter the name of the computer to enable RDP on")]
        [string]$computer
    )
    PROCESS {
        if (!(Test-Connection -ComputerName $computer -Count 1 -ea 0)) {
            Write-Host "$computer : OFFLINE"
            Continue
        }

        try {
            $rdp = gwmi -Class Win32_TerminalServiceSetting `
                        -Namespace root\CIMV2\TerminalServices `
                        -ComputerName $computer `
                        -Authentication 6 `
                        -ErrorAction Stop
        } catch {
            Write-Host "$computer : WMIQueryFailed"
            Continue
        }

        if ($rdp.AllowTSConnections -eq 1) {
            Write-Host "$computer : RDP Already enabled"
            continue
        } else {
            try {
                $result = $rdp.SetAllowTSConnections(1,1)
                if ($result.ReturnValue -eq 0) {
                    Write-Host "$computer : Enabled RDP Successfully"
                } else {
                    Write-Host "$computer : Failed to enable RDP"
                }
            } catch {
                Write-Host "$computer : Failed to enable RDP"
            }
        }
    }

    end {}
}


#
# Desc: Helper to Enter-PSSession to make credssp easier on the domain
# Date: 2014-11-04 - M. Stevenson - Initial Version
#
Function HC-EnterSession {
    [CmdletBinding()]
    param(
        [parameter(Mandatory=$true,ValueFromPipeline=$true,HelpMessage="Enter the hostname of the PC")]
        [string]$computer
    )

    PROCESS {
    
        $domainName = "ENTERDOMAINNAME"

        # add the domain name if it doesn't exist
        if (!($computer.ToLower().EndsWith($domainName.ToLower()))) {
           $computer = $computer + $domainName
        }

        # get the user's credential's for credssp
        $creds = Get-Credential

        Enter-PSSession -ComputerName $computer -Authentication Credssp -Credential $creds
    }

    end {}
}

#
# Desc: Get installed programs on PC, allow for removal
# Date: 2014-11-04 - M. Stevenson - Initial Version
#                                   Note: only dealing with things found in Win32_Product at this point
#
Function HC-GetPrograms {
    [CmdletBinding()]
    param(
        [parameter(Mandatory=$true,ValueFromPipeline=$true,HelpMessage="Enter the computer name/IP")]
        [string]$computer
    )

    PROCESS {
        if (!(Test-Connection -ComputerName $computer -Count 1 -ErrorAction SilentlyContinue)) {
            Write-Host "$computer is offline"
            Continue
        }

        try {
            $applications = Get-WmiObject -ComputerName $computer -Class Win32_Product -ErrorAction SilentlyContinue
        } catch {
            Write-Host "There was an error getting the application list. Aborting."
            Continue
        }

        $numOfApps = ($applications.length-1)

        For ($i = 0; $i -le $numOfApps; ++$i) {
            $app = $applications[$i]
            Write-Host "$($i): $($app.Name) - $($app.Vendor)"
        }

        # ask if they want to uninstall something
        do {
            $yn = Read-Host "Do you want to uninstall something? (y/n)"
        } until ($yn.ToLower() -eq "y" -or $yn.ToLower() -eq "n")

        if ($yn -eq "y") {
            # make sure people enter an actual number
            do {
                try {
                    $isNum = $true
                    [int]$deleteNumber = Read-Host "Enter number of application to remove: 0-$($numOfApps)"
                } catch { $isNum = $false }
            } until (($deleteNumber -ge 0 -and $deleteNumber -le $numOfApps) -and $isNum)

            $app = $applications[$deleteNumber]
            $app.uninstall()

            # run again
            HC-GetPrograms $computer
        }
    }

    end {}
}

