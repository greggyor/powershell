<#
.DESCRIPTION
  Load appropriate PowerCLI PSSnapins. These are based on PowerCLI 5.8 R1.
#>

[cmdletbinding()]
param()

PROCESS {
  try {
    Add-PSSnapin VMware.VimAutomation.Core
    Add-PSSnapin VMware.VimAutomation.Vds
    Add-PSSnapin VMware.VimAutomation.License
    Add-PSSnapin VMware.DeployAutomation
    Add-PSSnapin VMware.ImageBuilder
    Add-PSSnapin VMware.VimAutomation.Storage
  } catch {
    Write-Warning -Message "Error adding one of the PowerCLI PSSnapins - $_"
  } # end try/catch block
} # end process block

