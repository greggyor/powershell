  Get-ADOrganizationalUnit -Filter 'OU -like "*Citrix*"' -SearchBase 'dc=fabricam,dc=com' -Properties * |% { 
	$_.gpLink -split ']' } |? { 
	$_ -match '[0,2]$'} |% {
	(($_ -replace '\[','').split(';')[0]) -replace 'LDAP://',''} |% { 
	get-adobject $_ -properties * } |
	sort -Unique DisplayName | 
	select DisplayName,flags,@{N='flagsRecommended';E={
		if([bool]( gci "$($_.gPCFileSysPath)\User") -eq $false){
			if([bool](gci "$($_.gPCFileSysPath)\Machine") -eq $false){
				3
			}else{
				1
			}
		}else {
			if([bool](gci "$($_.gPCFileSysPath)\Machine") -eq $false){
				2
			}ELSE{
				0
			}
		}
	} }

