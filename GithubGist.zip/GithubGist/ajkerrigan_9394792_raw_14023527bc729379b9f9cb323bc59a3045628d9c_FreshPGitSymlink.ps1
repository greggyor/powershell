# Anytime GitHub for Windows updates itself, the PortableGit pathname changes.
# Powershell and GitHub for Windows handle this just fine, but explicit links
# to the PortableGit installation will fail (for instance, Git binary paths
# in Sublime Text packages). This little bit of code in a Powershell profile
# will ensure that a symbolic link always points to the most recent PortableGit
# installation.

$linkDir = 'c:\util\pgit'
# Get-ReparsePoint requires the Powershell Community Extensions (Pscx) module.
$currentSymlinkTarget = (Get-ReparsePoint $linkDir).Target

# Since GitHub for Windows installs PortableGit into a path with a trailing
# GUID, just find the most recent PortableGit directory.
$latestGitDir = (ls $env:LOCALAPPDATA\GitHub\PortableGit_* |
    Sort-Object -Property LastWriteTime -Descending)[0].FullName

# If the most recent PortableGit path doesn't match our existing symlink target,
# kill the old link and create a new one.
if ($currentSymlinkTarget -ne $latestGitDir) {
    "Updating PortableGit symlink '$linkDir' to '$latestGitDir'..."
    cmd /c "rmdir `"$linkDir`""
    cmd /c "mklink /d `"$linkDir`" `"$latestGitDir`""
}
