# 対象機器のIPアドレスを格納した配列
# 名前とＩＰは同じ順番で入れてね
[String[]]$addressAp = @('localhost')
[String[]]$userName = @('OWN')

#ファイル名の指定
[string]$HtmlFileName = [Environment]::GetFolderPath('Desktop') + '\pingResult.html'

# HTMLファイルの上部
[string]$htmlhead = @"
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <title>pingResult</title>
</head>
<body>
  <table border=4 width=400 align=center>
    <caption>【pingResult】</caption>
    <tr bgcolor="#cccccc">
     <th>server</th>
     <th>status</th>
    </tr>
"@

# HTMLファイルの下部
[string]$htmlbottom = @"
</body>
</html>
"@
[string]$ResultStr = ''
$ResultStr += $htmlhead

# 実行結果を確認します。
for($i = 0; $i -lt $addressAp.Count; $i++) {

   # Pingを実行します。
   $pingAlive = @(Test-Connection -ComputerName $addressAp[$i] -Quiet)

   $ResultStr  += '<tr>'
   $ResultStr  += '<td align=left>' + $userName[$i] + '</td>'

   # Ping成功の場合
   if ($pingAlive -eq $True) {

       $ResultStr  += '<td>Living</td>'
       
   } else {
   # Ping失敗の場合
       $ResultStr  += '<td bgcolor="#ff0000">Dead！</td>'
   }

   # 行を閉じる
   $ResultStr  += '</tr>'
}
#テーブルを閉じる
$ResultStr  += '</table>'

#実行日付取得
$ResultStr  += (Get-Date -format g )

# HTMLを閉じる
$ResultStr  += $htmlbottom

#実行結果をファイルに出力
Write-Output $ResultStr | Out-file $HtmlFileName

