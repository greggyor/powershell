[string] $Path = 'OU=foo,OU=test,DC=domain,DC=com'
try {
  if (!([adsi]::Exists("LDAP://$Path"))) {
		Throw('Supplied Path does not exist.')
	} else {
		Write-Debug "Path Exists:  $Path"
	}
} catch {
	# If invalid format, error is thrown.
	Throw("Supplied Path is invalid.`n$_")
}

