function Get-MappedDrives {
<#
.Synopsis
   Returns the Mapped Drives on the system
.DESCRIPTION
   This function uses WMI to query computers on the network and return the mapped drives, not local drives.
   If no user is logged on there will likely be an error about RPC server not available.
.PARAMETER ComputerName
   The name of the system(s) you want to check
.EXAMPLE
   Get-MappedDrives
   Get-MappedDrives system1
   Get-MappedDrives -ComputerName system1,system2 -FileLoc "c:\myfile.txt"
   Get-ADComputer -Filter * -SearchBase "OU=computers,DC=contoso,DC=net" | select -ExpandProperty Name | Get-MappedDrives
   (Get-ADComputer -Filter * -SearchBase "OU=computers,DC=contoso,DC=net").Name | Get-MappedDrives -ToFile
#>


[CmdletBinding()]

    Param (
        [parameter(
            Position=0,
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true,
            HelpMessage='The name of the system(s) you want to check. Leave blank for local system.')]
        [string[]]$Name=$env:COMPUTERNAME,
        [parameter(
            HelpMessage='Location to save the ouput files, defaut: C:\PSResults\')]
        [string]$FileLoc="$env:SystemDrive\PSResults",
        [parameter(
            HelpMessage='Use this flag if you want to save the results to a file')]
        [switch]$ToFile
    )

    Begin {
	if ($ToFile) {
	    if (!(Test-Path $FileLoc)) { # Check if we have an output directory, if not, create one
	        New-Item -Path $FileLoc -ItemType Directory | Out-Null
	    }
	}
        $err = @()
    }

    Process {
        if ($ToFile) {
        $file = "$FileLoc\DriveMaps.txt"
            foreach ($n in $Name) {
                $n | FT | Out-File -Append $file
                try {
                    Get-WmiObject Win32_MappedLogicalDisk -ComputerName $n -ErrorAction Stop |
                    FT @{Label="Drive Letter";Expression={$_.Name}},@{Label="Drive Path";Expression={$_.ProviderName}} |
                    Out-File -Append $file
                } catch {
                    Add-Content -Path $file -Value "Could not connect to the system"
                }
            }
        } else {
	    try { Get-WmiObject Win32_MappedLogicalDisk -ComputerName $Name -ErrorAction Stop |
	        FT @{Label="Drive Letter";Expression={$_.Name}},@{Label="Drive Path";Expression={$_.ProviderName}},@{Label="Computer";Expression={$_.SystemName}}
            } catch {
            $err += $Name
            } 
	}
    }

    End {
        if ($ToFile) {
            if (!($err[0] -eq $null)) { Write-Warning "Could not connect to some systems" }
        } else {
            if (!($err[0] -eq $null)) {
                Write-Host "Could not connect to the following systems:"
                $err
            }
        }
    }
}

