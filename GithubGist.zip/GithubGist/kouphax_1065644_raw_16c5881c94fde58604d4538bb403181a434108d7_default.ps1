Properties {
}

$framework = '4.0'

Task Default -depends Build

Task Build {
    Exec { msbuild .\MySolution.sln /v:quiet }
}

