[Environment]::CurrentDirectory=(Get-Location -PSProvider FileSystem).ProviderPath 
$rss = (new-object net.webclient)
#Set the username for windows auth proxy
#$rss.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
#http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/rss/mp4high/?sort=sequential&direction=desc&term=&r=Developer+Tools+%26+Application+Lifecycle+Management&r=Windows+Azure+Application+Development&y=Breakout&Media=true#fbid=FDnmapgI5Hf
#http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/RSS/mp4high
#http://channel9.msdn.com/Events/Build/2013/RSS/mp4high#theSessions
#http://channel9.msdn.com/Events/TechEd/NorthAmerica/2013/rss/mp4high/?sort=sequential&direction=desc&term=&r=Developer+Tools+%26+Application+Lifecycle+Management&r=Windows+Azure+Application+Development&y=Breakout&Media=true#fbid=FDnmapgI5Hf
$a = ([xml]$rss.downloadstring("http://channel9.msdn.com/Events/Build/2013/RSS/mp4high#theSessions")) 
$a.rss.channel.item | foreach{  
   $url = New-Object System.Uri($_.enclosure.url)
   $file = $_.creator + "-" + $_.title.Replace(":", "-").Replace("?", "").Replace("/", "-") + ".mp4"
  if (!(test-path $file)) 
    { 
	$file 
        $wc = (New-Object System.Net.WebClient)
        #Set the username for windows auth proxy
        #$wc.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
        $wc.DownloadFile($url, $file) 
    } 
}

