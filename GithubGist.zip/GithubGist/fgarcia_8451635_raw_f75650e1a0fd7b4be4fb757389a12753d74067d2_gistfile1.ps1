#!/bin/bash
#
# Start CouchBase Server 2.2
##
[ "$HOME" != "" ] && exec -c $0

export SHLVL=1
export HOME=/Users/dominik
export COUCHDB_ADDITIONAL_CONFIG_FILE=/Users/dominik/Library/Preferences/couchbase-server.in

cd "/Applications/Couchbase Server.app/Contents/Resources" 
./start-server.sh

