# open web
$web = Get-SPWeb http://yoursite
# get list
$list = $web.Lists["Your List"]
# get item
$item = $list.GetItemById(1)
 
# disable event firing 
$myAss = [Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint");
$type = $myAss.GetType("Microsoft.SharePoint.SPEventManager");
$prop = $type.GetProperty([string]"EventFiringDisabled",[System.Reflection.BindingFlags] ([System.Reflection.BindingFlags]::NonPublic -bor [System.Reflection.BindingFlags]::Static));
$prop.SetValue($null, $true, $null);
 
# change properties
$item["Title"] = "New Title"
 
# update item (without changing the Modified or Modified By fields)
$item.SystemUpdate($false)
 
# enable event firing
$prop.SetValue($null, $true, $null);

