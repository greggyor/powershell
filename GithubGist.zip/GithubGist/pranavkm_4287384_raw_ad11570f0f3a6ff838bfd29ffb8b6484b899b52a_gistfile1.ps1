function Get-ProjectFiles {
    Process {
        if ($_.Kind -eq "{6BB5F8EF-4483-11D3-8BCF-00C04F8EC28C}" -or $_.Kind -eq "{66A26720-8FB5-11D2-AA7E-00C04F688DDE}") {
            $_.ProjectItems | Get-ProjectFiles
        }
        else {
            $_
        }
    }
}

function Get-ProjectFilePath {
  param(
      $file
  )
  ($.file.Properties | Where { $_.Name -eq "FullPath" }).Value
   
}

function Get-RazorFiles {
    param(
        [parameter(ValueFromPipelineByPropertyName = $true)]
        [string]$ProjectName
    )
    
    (Resolve-ProjectName $ProjectName).ProjectItems | Get-ProjectFiles | Where { 
        $_.Name.EndsWith('.cshtml') -and !(Get-ChildItem (Get-ProjectFilePath $_)).IsReadOnly
    }
}


function Redo-RazorGenerator {
    param(
        [parameter(ValueFromPipelineByPropertyName = $true)]
        [string]$ProjectName
    )
    Process {
        Get-RazorFiles $ProjectName | % { 
            if ($_.Properties.Item("CustomTool")) {
                $_.Object.RunCustomTool()
            }
        }
    }
}

