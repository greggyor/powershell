# This PowerShell script converts all eps files in all subfolders to pdf files

$curDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$epsFiles = Get-ChildItem -Recurse $curDir\*.eps
$texBin = "${env:ProgramFiles(x86)}\MiKTeX 2.9\miktex\bin"
Set-Alias eps2pdf $texBin\epstopdf.exe

ForEach ($file In $epsFiles){
    eps2pdf $file
}

