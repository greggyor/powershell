
function _fixLink([Microsoft.SharePoint.Navigation.SPNavigationNode]$link, [String]$bad, [String]$good) {
    write-verbose ('checking link "' + $link.title + '" (' + $link.url + ')')
    #$link | Get-Member
    $url = $link.url -replace $bad, $good
    if ([string]::Compare($url, $link.url, $True) -ne 0)
    {
        write-output("fixing url ("+$link.url+") to ("+$url+")")
        $link.url = $url
        $link.update()
    }
}

function fixLinks {
    <#
    .SYNOPSIS
    fixes broken links
    .DESCRIPTION
    Searches through all navigation links in the Quick launch menu, and corrects all urls based on string replacement.
    .EXAMPLE
    fixLinks (Get-SPweb "http://mdsp01/clients/") "/All Client Sites/" "/clients/" -verbose
    .PARAMETER SPSite
    The sharepoint site to fix.
    .PARAMETER bad
    the bad string that needs to be replaced from the url
    .PARAMETER good
    the good string that needs to be replace the bad one in the url
    #>[CmdletBinding()]
    param
    (
        [Parameter(Position=1,
        Mandatory=$True,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the address of the sharepoint site collection/ site/ subsite you would like to fix?')]
        [Alias('site')]
        [Microsoft.SharePoint.SPWeb]$SPSite,
        
        [Parameter(Position=2,
        Mandatory=$True,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the old string that needs to be replaced from link urls on the site?')]
        [Alias('bad')]
        [String]$badUrlString,
        
        [Parameter(Position=3,
        Mandatory=$True,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the new string to correct link urls on the site?')]
        [Alias('good')]
        [String]$goodUrlString
    )
    BEGIN {}
    PROCESS {
        $SPPubWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($SPSite);

        foreach($node in $SPPubWeb.Navigation.CurrentNavigationNodes) {
            foreach($link in $node) {  
                _fixLink $link $badUrlString $goodUrlString
                foreach($childLink in $link.children) {
                    _fixLink $childLink $badUrlString $goodUrlString
                }
            }
        }
        $SPPubWeb.update()
    }
    END{}
}

function fixNav {
    <#
    .SYNOPSIS
    Enforces a navigation policy on the input site
    .DESCRIPTION
    Global and local navigation for this site and all subsites will be fixed to match desired rules set in this function.
    .EXAMPLE
    fixNav (Get-SPweb "http://mdsp01/clients")
    .EXAMPLE
    fixNav (Get-SPweb "http://mdsp01/clients") -verbose
    .EXAMPLE
    fixNav (Get-SPweb "http://mdsp01/clients") "/All Client Sites/" "/clients/"
    .PARAMETER SPSite
    The sharepoint site to fix.
    .PARAMETER verbose
    whether to pring before and after information etc.
    #>[CmdletBinding()]
    param
    (
        [Parameter(Position=1,
        Mandatory=$True,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the address of the sharepoint site collection/ site/ subsite you would like to fix?')]
        [Alias('site')]
        [Microsoft.SharePoint.SPWeb]$SPSite,
        
        [Parameter(Position=2,
        Mandatory=$false,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the old string that needs to be replaced from link urls on the site?')]
        [Alias('bad')]
        [String]$badUrlString = $null,
        
        [Parameter(Position=3,
        Mandatory=$false,
        ValueFromPipeline=$True,
        ValueFromPipelineByPropertyName=$True,
        HelpMessage='What is the new string to correct link urls on the site?')]
        [Alias('good')]
        [String]$goodUrlString = ""
    )
    BEGIN {
        Write-Output("-------------------------------------------------------------------------------");
        Write-Output("fixing site: " + $SPSite.title + " at " + $SPSite.url);

        ## Save AllowUnsafeUpdates setting and set it to allow.
        $AllowUnsafeUpdatesStatus = $SPSite.AllowUnsafeUpdates;
        $SPSite.AllowUnsafeUpdates = $true;
    }
    PROCESS {
        ## Get a PublishingWeb object for the current web
        $SPPubWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($SPSite);
                
        Write-Verbose("Navigation Before: " + [string] ($SPPubWeb.Navigation | select *));

        ## fix links if received
        if ($badUrlString) {
            fixLinks $SPSite $badUrlString $goodUrlString;
        } else {
                Write-Verbose("Skipping link url corrections.");
        }

        ## UnComment the setting you will use:
        ## Global settings
        $SPPubWeb.Navigation.InheritGlobal = $true
        # $SPPubWeb.Navigation.InheritGlobal = $false
        # $SPPubWeb.Navigation.GlobalIncludeSubSites = $true
        $SPPubWeb.Navigation.GlobalIncludeSubSites = $false
        # $SPPubWeb.Navigation.GlobalIncludePages = $true
        $SPPubWeb.Navigation.GlobalIncludePages = $false
        $SPPubWeb.Navigation.GlobalDynamicChildLimit = 10
        ## Current settings
        ## See combination of the two below
        $SPPubWeb.Navigation.InheritCurrent = $false
        $SPPubWeb.Navigation.ShowSiblings = $false
        $SPPubWeb.Navigation.CurrentIncludeSubSites = $true
        $SPPubWeb.Navigation.CurrentIncludePages = $true
        $SPPubWeb.Navigation.CurrentDynamicChildLimit = 20
        ## Sorting
        $SPPubWeb.Navigation.OrderingMethod = "Automatic"
        # $SPPubWeb.Navigation.OrderingMethod = "Manual"
        # $SPPubWeb.Navigation.OrderingMethod = "ManualWithAutomaticPageSorting”
        $SPPubWeb.Navigation.AutomaticSortingMethod = "Title"
        # $SPPubWeb.Navigation.AutomaticSortingMethod = "CreatedDate"
        # $SPPubWeb.Navigation.AutomaticSortingMethod = "LastModifiedDate"
        $SPPubWeb.Navigation.SortAscending = $true
        # $SPPubWeb.Navigation.SortAscending = $false
        $SPPubWeb.Update()

        Write-Verbose("Navigation After: " + [string] ($SPPubWeb.Navigation | select *))
        
        ## recurse through subsites
        foreach ($SPWeb in $SPSite.Webs)
        {
            ## check that this is not the root web or suffer infinite recursion
            if (!$SPWeb.IsRootWeb)
            {
                fixNav $SPWeb $badUrlString $goodUrlString
            }
        }
    }
    END {
        $SPSite.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
        $SPSite.Dispose() 
    }
}

