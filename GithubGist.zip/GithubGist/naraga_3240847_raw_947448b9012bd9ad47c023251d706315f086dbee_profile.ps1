function Get-GitRepoPath
{
@(  $i=0;`
    $pwd.path -split "\\"| `
    %{"$(@($pwd.path -split '\\')[0..$i] -join '\')";$i++} | `
    ? {test-path "$_\\.git"})[0]
}

function Get-GitCurrentBranch
{
    ((cat "$(Get-GitRepoPath)\.git\HEAD") -split "/")[-1]
}

function prompt
{
    "$($pwd.path)[$(Get-GitCurrentBranch)]>"
}


