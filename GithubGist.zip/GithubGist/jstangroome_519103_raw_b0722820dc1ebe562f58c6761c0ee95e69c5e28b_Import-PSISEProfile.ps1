if ($psise) {
    if (!(test-path $profile)) { new-item $profile -fo -it file }
    $e = $psise.CurrentPowerShellTab.Files.Add($profile).Editor
    $col = $e.GetLineLength($e.LineCount)+1
    $e.Select($e.LineCount,$col,$e.LineCount,$col)
    $e.InsertText("`n" + (new-object Net.WebClient).DownloadString(
        'http://gist.github.com/raw/518638/3e0beb7a5a6ddc19446d5a6d38c8267794c92eba/Microsoft.PowerShellISE_profile.ps1'
    ))
} else { throw 'Run this script using the ISE' }


