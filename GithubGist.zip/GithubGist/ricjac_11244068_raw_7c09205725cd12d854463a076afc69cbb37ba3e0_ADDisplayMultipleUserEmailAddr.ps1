Import-Module activedirectory

$users2Find = @("USERNAME1","USERNAME2")

foreach ($user in $users2Find)
{
	$tempuser = Get-ADUser $user -Properties mail
	Write-Host $tempuser.mail
}

