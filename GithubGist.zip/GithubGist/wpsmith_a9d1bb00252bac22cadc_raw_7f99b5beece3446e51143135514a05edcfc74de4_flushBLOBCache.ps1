Param(
  [string]$webAppURL
)

#Loading SharePoint Powershell Snaping
Add-PSSnapin Microsoft.SharePoint.Powershell -ErrorAction SilentlyContinue

if (!$webAppURL) { $webAppURL = Read-Host "What is the web application's URL?" }

Write-Host "Checking:" $webAppURL
$webApp = Get-SPWebApplication $webAppURL
[Microsoft.SharePoint.Publishing.PublishingCache]::FlushBlobCache($webApp)
Write-Host "Flushed the BLOB cache for:" $webApp

