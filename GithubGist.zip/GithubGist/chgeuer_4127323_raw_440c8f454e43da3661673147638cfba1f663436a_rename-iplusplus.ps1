function Rename-ItemsPrepend {
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$True,
      ValueFromPipeline=$False,
      ValueFromPipelineByPropertyName=$True,
      HelpMessage='Which number should be first prefixed')]
    [int]$start
  )

  begin {
    write-verbose "Renaming files"
  }

  process {

    write-verbose "Beginning process loop"

    $i = $start
    Get-ChildItem | Sort-Object -Property CreationTime | foreach ($_) {  
       $nn = [System.String]::Format("{0:d2}__{1}", $i++, $_.Name)
       Rename-Item -Path $_.FullName -NewName $nn
    }
  }
}

Set-Alias -Name renumber -Value Rename-ItemsPrepend



