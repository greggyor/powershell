Import-Module ActiveDirectory

Function Refresh_Group ($groupname, $newmembers)
{
    $oldmembers = Get-ADGroupMember -Identity $groupname
    $rmmembers = $null
    $addmembers = $null

    if ($oldmembers -eq $null -and $newmembers -eq $null) {
        return
    }

    if ($oldmembers -ne $null -and $newmembers -ne $null) {
        $comparemembers = Compare-Object $oldmembers $newmembers

        $rmmembers = ($comparemembers | Where-Object { $_.SideIndicator -eq '<=' }).InputObject
        $addmembers = ($comparemembers | Where-Object { $_.SideIndicator -eq '=>' }).InputObject
    }
    elseif ($oldmembers -eq $null) {
        $addmembers = $newmembers
    }
    else {
        $rmmembers = $oldmembers
    }

    if ($addmembers -ne $null) {
        $addmembers | ForEach-Object { Add-ADGroupMember -Identity $groupname -Members $_ }
    }
    if ($rmmembers -ne $null) {
        $rmmembers | ForEach-Object { Remove-ADGroupMember -Identity $groupname -Members $_ -Confirm:$false }
    }
}

Function Clean_Duplicates_1 ($main, $other1)
{
    $mainmembers = Get-ADGroupMember -Identity $main
    if ($mainmembers -eq $null) {
        return
    }

    foreach ($item in $mainmembers) {
        Try { Remove-ADGroupMember -Identity $other1 -Members $item -Confirm:$false } Catch {}
    }
}

Function Clean_Duplicates_2 ($main, $other1, $other2)
{
    $mainmembers = Get-ADGroupMember -Identity $main
    if ($mainmembers -eq $null) {
        return
    }

    foreach ($item in $mainmembers) {
        Try { Remove-ADGroupMember -Identity $other1 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other2 -Members $item -Confirm:$false } Catch {}
    }
}

Function Clean_Duplicates_3 ($main, $other1, $other2, $other3)
{
    $mainmembers = Get-ADGroupMember -Identity $main
    if ($mainmembers -eq $null) {
        return
    }

    foreach ($item in $mainmembers) {
        Try { Remove-ADGroupMember -Identity $other1 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other2 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other3 -Members $item -Confirm:$false } Catch {}
    }
}

Function Clean_Duplicates_4 ($main, $other1, $other2, $other3, $other4)
{
    $mainmembers = Get-ADGroupMember -Identity $main
    if ($mainmembers -eq $null) {
        return
    }

    foreach ($item in $mainmembers) {
        Try { Remove-ADGroupMember -Identity $other1 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other2 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other3 -Members $item -Confirm:$false } Catch {}
        Try { Remove-ADGroupMember -Identity $other4 -Members $item -Confirm:$false } Catch {}
    }
}

Function Groups_Intersection_1 ($name1)
{
    return Get-ADGroupMember $name1
}

Function Groups_Intersection_2 ($name1, $name2)
{
    return (Compare-Object $(Get-ADGroupMember $name1) $(Get-ADGroupMember $name2) -ExcludeDifferent -IncludeEqual).InputObject
}

Function Groups_Intersection_3 ($name1, $name2, $name3)
{
    $ret = (Compare-Object $(Get-ADGroupMember $name1) $(Get-ADGroupMember $name2) -ExcludeDifferent -IncludeEqual).InputObject
    return (Compare-Object $ret $(Get-ADGroupMember $name3) -ExcludeDifferent -IncludeEqual).InputObject
}

Function Groups_Intersection_4 ($name1, $name2, $name3, $name4)
{
    $ret1 = (Compare-Object $(Get-ADGroupMember $name1) $(Get-ADGroupMember $name2) -ExcludeDifferent -IncludeEqual).InputObject
    $ret2 = (Compare-Object $(Get-ADGroupMember $name3) $(Get-ADGroupMember $name4) -ExcludeDifferent -IncludeEqual).InputObject
    return (Compare-Object $ret1 $ret2 -ExcludeDifferent -IncludeEqual).InputObject
}

Function Groups_Intersection_5 ($name1, $name2, $name3, $name4, $name5)
{
    $ret1 = (Compare-Object $(Get-ADGroupMember $name1) $(Get-ADGroupMember $name2) -ExcludeDifferent -IncludeEqual).InputObject
    $ret2 = (Compare-Object $(Get-ADGroupMember $name3) $(Get-ADGroupMember $name4) -ExcludeDifferent -IncludeEqual).InputObject
    $ret3 = (Compare-Object $ret1 $ret2 -ExcludeDifferent -IncludeEqual).InputObject
    return (Compare-Object $ret3 $(Get-ADGroupMember $name5) -ExcludeDifferent -IncludeEqual).InputObject
}

Function Groups_Intersection_6 ($name1, $name2, $name3, $name4, $name5, $name6)
{
    $ret1 = (Compare-Object $(Get-ADGroupMember $name1) $(Get-ADGroupMember $name2) -ExcludeDifferent -IncludeEqual).InputObject
    $ret2 = (Compare-Object $(Get-ADGroupMember $name3) $(Get-ADGroupMember $name4) -ExcludeDifferent -IncludeEqual).InputObject
    $ret3 = (Compare-Object $(Get-ADGroupMember $name5) $(Get-ADGroupMember $name6) -ExcludeDifferent -IncludeEqual).InputObject
    $ret4 = (Compare-Object $ret1 $ret2 -ExcludeDifferent -IncludeEqual).InputObject
    return (Compare-Object $ret4 $ret3 -ExcludeDifferent -IncludeEqual).InputObject
}

