# May require 
# Set-ExecutionPolicy Remote
# if Get-ExecutionPolicy returns "Restricted"

Set-Service W3SVC -StartupType Automatic
Start-Service W3SVC
iisreset

