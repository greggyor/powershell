# Hello, World.
$hello = "Hello, World."

function say_hello
{
    Write-Output $hello
}

say_hello

<#
If this is your first time running a Powershell (.ps1) script, you may have an issue
running the script due to default resrictions. 

Type this into the shell:

Set-ExecutionPolicy RemoteSigned
#>

