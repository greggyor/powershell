#Upload the given file via FTP to the given server with the given credentials
function FTPFile
{
	Param(
		#Ensure $Filename exists and is not a folder
		[ValidateScript({Test-Path $_ -PathType 'Leaf'})]
		[string]
		$FilePath
		,
		[ValidateNotNullOrEmpty()]
		[string]
		$FTPUser
		,
		[ValidateNotNullOrEmpty()]
		[string]
		$FTPPassword
		,
		[ValidateNotNullOrEmpty()]
		[string]
		$FTPServerPath
	)

	#Create the URI
	$Filename = Split-Path $FilePath -leaf
	$FTPUrl = "ftp://$FTPUser`:$FTPPassword`@$FTPServerPath$Filename"
	$WebClient = New-Object System.Net.WebClient
	$URI = New-Object System.Uri($FTPUrl)

	#Attempt to upload the file
	Notify "Uploading $FilePath"
	try
	{
		$ErrorActionPreference = "Stop"; #Make all errors terminating
		$WebClient.UploadFile($URI, $FilePath)
		Notify "Upload for $Filename was successful."
		Start-Sleep -Seconds 5
	}
	catch 
	{
		Warn "Error. Could not upload file $Filename!"
		Start-Sleep -Seconds 5
		Throw
	} 
	finally
	{
		$ErrorActionPreference = "Continue"; #Reset the error action pref to default
	}
}

