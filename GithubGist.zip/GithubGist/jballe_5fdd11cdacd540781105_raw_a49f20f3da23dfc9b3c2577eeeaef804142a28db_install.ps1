#chocolatey
(iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1')))>$null 2>&1

# now install
cinst javaruntime-preventasktoolbar
cinst javaruntime

cinst git
cinst hg
cinst microsoft-build-tools

cinst Thoughtworks.Go.Server -source 'https://www.myget.org/F/jballe-chocolatey/'
cinst Thoughtworks.Go.Agent -source 'https://www.myget.org/F/jballe-chocolatey/'


