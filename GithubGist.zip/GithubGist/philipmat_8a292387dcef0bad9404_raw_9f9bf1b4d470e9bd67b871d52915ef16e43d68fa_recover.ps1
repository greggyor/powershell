# Usage: (execute in the .git/objects folder)
# recover.ps1 -startDate "8/13/2014 1:22:00pm" -endDate "8/13/2014 8:00:00pm" > borked_files.txt
[CmdletBinding()]
Param(
	[string]$startDate,
	[string]$endDate
)

$start = [datetime]::Today
if ($startDate) {
	$start = [datetime]::Parse($startDate)
}

$end = $start.AddDays(1)
if ($endDate) {
	$end = [datetime]::Parse($endDate)
}


Write-Host "Searching for git objects created between $start and $end"
$files = Get-ChildItem -recurse | where {$_.CreationTime -gt $start -and $_.CreationTime -lt $end}
$sha_length = "fe19a805b91c63cca33f53c56499fa53b2436303".Length

$count_files = $files.Length
Write-Host "Files: $count_files"

$i = 0
foreach ($file in $files) {
    $composed = $file.Directory.BaseName + $file.BaseName
    if ($composed.Length -eq $sha_length) {
        Write-Output "----=====SHA1: $composed"
        git show $composed
        $i++
        Write-Host -NoNewline "."
        if ($i % 50 -eq 0) { Write-Host -ForegroundColor Green "= $i/$count_files" }
    } else {
    	Write-Host -ForegroundColor DarkRed "Ignoring: $composed"
    }
}


