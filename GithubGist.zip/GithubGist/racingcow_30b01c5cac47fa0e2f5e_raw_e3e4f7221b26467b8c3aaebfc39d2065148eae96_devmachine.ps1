############################################################

# Join domain

############################################################

#Rename-Computer -NewName devmachine -LocalCredential admin

#Add-Computer -DomainName CT -Credential CT\dmiller

############################################################

# Boxstarter options

############################################################

$Boxstarter.RebootOk=$true # Allow reboots?

$Boxstarter.NoPassword=$false # Is this a machine with no login password?

$Boxstarter.AutoLogin=$true # Save my password securely and auto-login after a reboot

############################################################

#basic setup

############################################################

Update-ExecutionPolicy Unrestricted

Set-ExplorerOptions -showHidenFilesFoldersDrives -showProtectedOSFiles -showFileExtensions

Enable-RemoteDesktop

Disable-InternetExplorerESC

Disable-UAC

Set-TaskbarSmall

Write-BoxstarterMessage "Setting time zone to Central Standard Time"
& C:\Windows\system32\tzutil /s "Central Standard Time"

cinst Microsoft-Hyper-V-All -source windowsFeatures

cinst IIS-WebServerRole -source windowsfeatures

cinst IIS-HttpCompressionDynamic -source windowsfeatures

cinst IIS-WindowsAuthentication -source windowsfeatures

cinst DotNet3.5

cinst f.lux

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# Update Windows and reboot if necessary

############################################################

Install-WindowsUpdate -AcceptEula

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# utils, plugins, frameworks, and other miscellany

############################################################

cinst javaruntime

cinst webpi

cinst mousewithoutborders

cinst adobereader

cinst flashplayeractivex

cinst flashplayerplugin

cinst AdobeAIR

cinst 7zip

cinst zoomit

cinst PDFCreator

cinst lockhunter

cinst windirstat

cinst teamviewer

cinst ransack

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# communications

############################################################

# cinst HipChat # <- seems to be old adobe air version

cinst skype

if (Test-PendingReboot) { Invoke-Reboot }

cinst tweetdeck

############################################################

# graphics

############################################################

cinst gimp

cinst paint.net

cinst greenfishiconeditor

cinst IrfanView

cinst InkScape

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# design

############################################################

cinst freemind

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# development

############################################################

cinst VisualStudio2013Premium -InstallArguments "/Features:'Blend OfficeDeveloperTools WebTools Win8SDK WindowsPhone80'"

if (Test-PendingReboot) { Invoke-Reboot }

cinst DotNet3.5 # Not automatically installed with VS 2013. Includes .NET 2.0. Uses Windows Features to install.

if (Test-PendingReboot) { Invoke-Reboot }

cinst resharper

if (Test-PendingReboot) { Invoke-Reboot }
cinst MsSqlServerManagementStudio2014Express
if (Test-PendingReboot) { Invoke-Reboot }

cinst NugetPackageExplorer

cinst nodejs.install

cinst mongodb

cinst PhantomJS

cinst fiddler4

cinst SublimeText3

cinst Brackets

cinst Brackets.Theseus

cinst IntelliJIDEA

cinst githubforwindows

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# text editors

############################################################

cinst evernote

cinst notepadplusplus.install

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# fun!

############################################################

cinst spotify

cinst steam

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# browsers

############################################################

cinst GoogleChrome

cinst GoogleChrome.Canary

cinst Firefox

cinst Opera

cinst safari

cinst lastpass

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# to the cloud!

############################################################

cinst dropbox

if (Test-PendingReboot) { Invoke-Reboot }

############################################################

# Items pinned to taskbar

############################################################

Install-ChocolateyPinnedTaskBarItem "$($Boxstarter.programFiles86)\Google\Chrome\Application\chrome.exe"

Install-ChocolateyPinnedTaskBarItem "$($Boxstarter.programFiles86)\Microsoft Visual Studio 12.0\Common7\IDE\devenv.exe"

if (Test-PendingReboot) { Invoke-Reboot }

