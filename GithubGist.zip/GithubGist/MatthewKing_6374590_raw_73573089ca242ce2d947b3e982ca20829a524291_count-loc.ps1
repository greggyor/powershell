(Get-ChildItem -include *.cs -recurse | Select-String .).Count

