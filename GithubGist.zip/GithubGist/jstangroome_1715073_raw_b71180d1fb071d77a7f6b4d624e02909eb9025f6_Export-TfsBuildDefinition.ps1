[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^https?://')]
    [string]
    $CollectionUri,

    [string]
    $ProjectName = '*',

    [Alias('Name')]
    [string]
    $BuildDefinitionName = '*'
)

function New-TypedObject (
    [string] $TypeName,
    [hashtable] $Property
) {
    $o = New-Object -TypeName PSObject -Property $Property
    $o.PSObject.TypeNames.Insert(0, $TypeName)
    return $o
}

$script:ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

'', '.Client', '.Build.Client' |
    ForEach-Object {
        Add-Type -AssemblyName "Microsoft.TeamFoundation$_, Version=10.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a"
    }

$Collection = [Microsoft.TeamFoundation.Client.TfsTeamProjectCollectionFactory]::GetTeamProjectCollection($CollectionUri)
$BuildServer = $Collection.GetService([Microsoft.TeamFoundation.Build.Client.IBuildServer])
$BuildServer.QueryBuildDefinitions($ProjectName) |
    Where-Object { $_.Name -like $BuildDefinitionName } |
    ForEach-Object {
        $Properties = @{
            CollectionUri = $CollectionUri
            TeamProject = $_.TeamProject
            Name = $_.Name
            Description = $_.Description
            Enabled = $_.Enabled
            ContinuousIntegrationType = $_.ContinuousIntegrationType.ToString()
            BuildControllerName = $_.BuildController.Name
            DefaultDropLocation = $_.DefaultDropLocation
            Process = $_.Process.ServerPath
            ProcessParameters = $_.ProcessParameters
        }
        $Properties['WorkspaceMappings'] = @(
            $_.Workspace.Mappings |
                ForEach-Object {
                    New-TypedObject -TypeName CodeAssassin.TeamBuild.WorkspaceMapping -Property @{
                        MappingType = $_.MappingType.ToString()
                        ServerItem = $_.ServerItem
                        LocalItem = $_.LocalItem
                        Depth = $_.Depth.ToString()
                    }
                }
        )
        if ($_.ContinuousIntegrationType -eq 'Batch') {
            $Properties['ContinuousIntegrationQuietPeriod'] = $_.ContinuousIntegrationQuietPeriod
        } elseif ('Schedule', 'ScheduleForced' -contains $_.ContinuousIntegrationType) {
            $Properties['Schedules'] = @(
                $_.Schedules | 
                    ForEach-Object {
                        New-TypedObject -TypeName CodeAssassin.TeamBuild.Schedule -Property @{
                            DaysToBuild = $_.DaysToBuild.ToString()
                            StartTime = New-TimeSpan -Seconds $_.StartTime
                            TimeZone = $_.TimeZone.Id
                            Type = $_.Type
                        }
                    }
            )
        }
        $Properties['RetentionPolicyList'] = @(
            $_.RetentionPolicyList |
                ForEach-Object {
                    New-TypedObject -TypeName CodeAssassin.TeamBuild.RetentionPolicy -Property @{
                        BuildReason = $_.BuildReason.ToString()
                        BuildStatus = $_.BuildStatus.ToString()
                        NumberToKeep = $_.NumberToKeep
                        DeleteOptions = $_.DeleteOptions.ToString()
                    }
                }
        )
        New-TypedObject -TypeName CodeAssassin.TeamBuild.BuildDefinition -Property $Properties
    } 

