$partitions = Get-WmiObject -computerName "."  Win32_DiskPartition

$partitions | foreach {
	Get-WmiObject -computerName "." -query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($_.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition" | 
	add-member -membertype noteproperty PartitionName $_.Name -passthru |
	add-member  -membertype noteproperty Block $_.BlockSize -passthru |
	add-member  -membertype noteproperty StartingOffset $_.StartingOffset -passthru |
	add-member  -membertype noteproperty StartSector $($_.StartingOffset/$_.BlockSize) -passthru |
	add-member  -membertype noteproperty BadAlign4k $($_.StartingOffset % 4096) -passthru 
} |
Select SystemName, Name, PartitionName, Block, StartingOffset, StartSector, BadAlign4k

