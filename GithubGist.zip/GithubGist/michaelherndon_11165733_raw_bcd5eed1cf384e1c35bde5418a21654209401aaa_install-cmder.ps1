<#
The Cmder chocolatey package is a hot mess. 
 
This is a shame, because Cmder finally brings a decent tabbed console
interface to windows.  
 
This script wraps the install of Cmder from Chocolatey:
 * installs a start menu shortcut, which can be pinned
 * removes all the batch files that automatically created from the vendor folder
 * adds git-bash as a Cmder Task. Powershell & cmd already exist. 
 
 
The MIT License (MIT)
 
Copyright (c) 2014 Michael Herndon dev.michaelherndon.com
 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#>
 
#install chocolatey first
#https://gist.github.com/michaelherndon/11100457
 
if($env:ChocolateyInstall -eq "" -or $env:ChocolateyInstall -eq $null)
{
     setx ChocolateyInstall "c:\opt\apps\chocolatey"
     $env:ChocolateyInstall = "c:\opt\apps\chocolatey"
     echo "path set"
}
 

 
if(! (Test-Path  "$env:ChocolateyInstall\lib\Cmder.*"))
{
    cinst Cmder
}

$test = gci "$env:ChocolateyInstall\lib\Cmder.*"
 
 
$folders = gci "$env:ChocolateyInstall\lib\Cmder.*"  | ?{ $_.PSIsContainer -and -not $_.Name.Contains(".portable.") } | Sort-Object {$_.Name } -Descending
 
$cmder = $folders[0].FullName
$version = $cmder.Replace("Cmder.", "")
$version = $version.Substring($version.LastIndexOf("\") +1)
echo $version
 
 
# start menu shortcut
$shortCutPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Cmder.lnk"
 
if(! (Test-Path $shortCutPath))
{
    echo "Adding Start Menu Shortcut"
    $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($shortCutPath)
    $Shortcut.TargetPath = 'cmd'
    $Shortcut.Arguments = "/C ""$env:ChocolateyInstall\lib\cmder.portable.$version\tools\cmder\Cmder.bat"""
    $Shortcut.IconLocation = "$env:ChocolateyInstall\lib\cmder.portable.$version\tools\cmder\icons\cmder.ico"
    $Shortcut.WorkingDirectory = "$env:SystemDrive\opt\"
    $Shortcut.Save()
}
 
 
 
# clean up all the clutter
$executables = gci "$env:ChocolateyInstall\lib\cmder.portable.$version\*.exe" -Recurse
$bin = "$env:ChocolateyInstall\bin"
 
if($executables.Length -gt 0)
{
    echo "Cleaning up bat files"
}
 
 
foreach($exe in $executables)
{
    
    $file = "$bin\" + $exe.Name.Replace(".exe", "")
    $bat = $file + ".bat"
    if(Test-Path ($file))
    {
        Remove-Item $file -Force
    }
 
    if(Test-Path ($file))
    {
        Remove-Item $bat -Force
    }
}
 
# ConEmu config
$conEmuConfig = "$env:ChocolateyInstall\lib\cmder.portable.$version\tools\cmder\config\ConEmu.xml"
 
# Backup the configuration
if(! (Test-Path ($conEmuConfig + ".bck")))
{
    Copy-Item $conEmuConfig  ($conEmuConfig + ".bck")
}
 
[xml]$cfg = New-Object XML
$cfg.Load($conEmuConfig)
$xpath = "//key[@name=""Task3""]"
<#
<key name="Task3" modified="2014-01-07 12:14:38" build="131107">
					<value name="Name" type="string" data="{git-bash}"/>
					<value name="Hotkey" type="dword" data="00000000"/>
					<value name="GuiArgs" type="string" data=""/>
					<value name="Active" type="dword" data="00000000"/>
					<value name="Count" type="dword" data="00000001"/>
					<value name="Cmd1" type="string" data="&quot;C:\opt\apps\chocolatey\lib\cmder.portable.1.1.1\tools\cmder\vendor\msysgit\bin\sh.exe&quot; --login -i"/>
 
#>
 
$node = $cfg.key.key.key.key | Where-Object { $_.name -eq "Tasks" }
echo $node.ChildNodes.Count
$ns = $cfg.DocumentElement.NamespaceURI
 
 
Function CreateAttr($n, $value)
{
    $attr = $cfg.CreateAttribute($n);
    $attr.Value = $value
    return $attr
}
 
# Add Git-Bash
if($node.ChildNodes.Count -eq 3)
{
    echo "children"
    
    # update count
    $node.ChildNodes[0].SetAttribute("data", "00000003")
    
 
    $task = $cfg.CreateElement("key",  $ns)
    $at = CreateAttr "name" "Task3" 
    $task.Attributes.Append($at)
    $task.Attributes.Append((CreateAttr "modified" "2014-01-07 12:14:38"))
    $task.Attributes.Append((CreateAttr "build" "131107" ))
 
    $attr = $cfg.CreateElement("value", $cfg.DocumentElement.NamespaceURI)
    $attr.Attributes.Append((CreateAttr "name" "Name"))
    $attr.Attributes.Append((CreateAttr "type" "string"))
    $attr.Attributes.Append((CreateAttr "data"  "{git-bash}"))
    $task.AppendChild($attr);
 
    $hk = $cfg.CreateElement("value", $cfg.DocumentElement.NamespaceURI)
    $hk.Attributes.Append((CreateAttr "name" "HotKey" ))
    $hk.Attributes.Append((CreateAttr "type" "dword"))
    $hk.Attributes.Append((CreateAttr "data" "00000000" ))
    $task.AppendChild($hk);
 
    
    $gui = $cfg.CreateElement("value", $cfg.DocumentElement.NamespaceURI)
    $gui.Attributes.Append((CreateAttr "name" "GuiArgs"))
    $gui.Attributes.Append((CreateAttr "type" "string"))
    $gui.Attributes.Append((CreateAttr "data" ""))
    $task.AppendChild($gui);
 
 
    
    $act = $cfg.CreateElement("value",$cfg.DocumentElement.NamespaceURI)
    $act.Attributes.Append((CreateAttr "name" "Active"))
    $act.Attributes.Append((CreateAttr "type" "dword"))
    $act.Attributes.Append((CreateAttr "data" "00000000"))
    $task.AppendChild($act);
 
 
    
    $ct = $cfg.CreateElement("value", $cfg.DocumentElement.NamespaceURI)
    $ct.Attributes.Append((CreateAttr "name" "Count"))
    $ct.Attributes.Append((CreateAttr "type" "dword"))
    $ct.Attributes.Append((CreateAttr "data" "00000001"))
    $task.AppendChild($ct);
 
    
    $cm = $cfg.CreateElement("value", $cfg.DocumentElement.NamespaceURI)
 
    $cm.Attributes.Append((CreateAttr "name" "Cmd1"))
    $cm.Attributes.Append((CreateAttr "type" "string"))
    $cm.Attributes.Append((CreateAttr "data" """$env:ChocolateyInstall\lib\cmder.portable.$version\tools\cmder\vendor\msysgit\bin\sh.exe"" --login -i"))
    $task.AppendChild($cm);
 
    $node.AppendChild($task);
}
$cfg.Save($conEmuConfig)

