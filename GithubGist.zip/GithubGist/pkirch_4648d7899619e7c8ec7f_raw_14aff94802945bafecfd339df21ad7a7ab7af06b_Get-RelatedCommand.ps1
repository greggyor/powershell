# Sample by Peter Kirchner (peter.kirchner@microsoft.com)

PS C:\Users\pkirch> Get-Command -Module Azure -Noun AzureService

<# Output

CommandType     Name                                               ModuleName                                                                                                
-----------     ----                                               ----------                                                                                                
Cmdlet          Get-AzureService                                   Azure                                                                                                     
Cmdlet          New-AzureService                                   Azure                                                                                                     
Cmdlet          Remove-AzureService                                Azure                                                                                                     
Cmdlet          Set-AzureService                                   Azure                                                                                                     
Cmdlet          Start-AzureService                                 Azure                                                                                                     
Cmdlet          Stop-AzureService                                  Azure                                                                                                     

#>

PS C:\Users\pkirch> Get-Command -Module Azure -Noun AzureVM

<# Output

CommandType     Name                                               ModuleName                                                                                                
-----------     ----                                               ----------                                                                                                
Cmdlet          Export-AzureVM                                     Azure                                                                                                     
Cmdlet          Get-AzureVM                                        Azure                                                                                                     
Cmdlet          Import-AzureVM                                     Azure                                                                                                     
Cmdlet          New-AzureVM                                        Azure                                                                                                     
Cmdlet          Remove-AzureVM                                     Azure                                                                                                     
Cmdlet          Restart-AzureVM                                    Azure                                                                                                     
Cmdlet          Start-AzureVM                                      Azure                                                                                                     
Cmdlet          Stop-AzureVM                                       Azure                                                                                                     
Cmdlet          Update-AzureVM                                     Azure                                                                                                     

#>

