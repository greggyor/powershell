function Get-MoreMemoryThanVisualStudio()
{
   $d = (Get-Process devenv | Measure-Object -Sum PrivateMemorySize64);
   Get-Process | Where-Object {$_.PrivateMemorySize64 -gt $d.Sum}
}

