# Get administration certificate.
# Get-AzurePublishSettingsFile
# Import-AzurePublishSettingsFile -PublishSettingsFile "C:\Users\pkirch\Downloads\Azure MSDN - pkirchner-9-11-2014-credentials.publishsettings"

# Settings
$SubscriptionName = "Azure MSDN - pkirchner"
$StorageAccountName = "pkmsft"
$Container = "vhds"
$LocalVhd = "C:\Users\pkirch\fixedvhd20mb.vhd"

# Select my Microsoft Azure Subscription.
Select-AzureSubscription -SubscriptionName $SubscriptionName

# Get locations. Need to know one for storage account creation.
# Get-AzureLocation | Select -Property DisplayName

# Create new storage account.
New-AzureStorageAccount -Location "West Europe" -StorageAccountName $StorageAccountName -Type Standard_LRS

# Create container for VHDs.
$StorageAccountKey = Get-AzureStorageKey -StorageAccountName $StorageAccountName

New-AzureStorageContext -StorageAccountKey $StorageAccountKey.Primary -StorageAccountName $StorageAccountName | `
    New-AzureStorageContainer -Name $Container -Permission Off

# Add-AzureVhd needs the CurrentStorageAccountName to be set.
Set-AzureSubscription -SubscriptionName $SubscriptionName -CurrentStorageAccountName $StorageAccountName

# Build destination path automatically.
$NewContainer = Get-AzureStorageContainer -Name $Container
$VhdFile = Split-Path -Path $LocalVhd -Leaf
$Destination = $NewContainer.CloudBlobContainer.Uri.AbsoluteUri + "/" +  $VhdFile

$Destination

# Upload VHD
Add-AzureVhd -Destination $Destination -LocalFilePath $LocalVhd

## Clean Up ##
# Delete storage account.
# Remove-AzureStorageAccount -StorageAccountName $StorageAccountName


########################################################################
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF    #
# ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO  #
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A       #
# PARTICULAR PURPOSE.                                                  #
########################################################################

