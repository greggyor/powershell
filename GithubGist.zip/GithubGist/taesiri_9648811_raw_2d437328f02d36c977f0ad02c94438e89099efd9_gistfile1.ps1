write-host("Ad-Hoc Creator")
write-host("Please enter an SSID") -foreground "green"
$network_name = Read-Host
write-host("Please enter a Password") -foreground "green"
$network_pass = Read-Host
write-host "Stopping current hosted network ..." -foreground "yellow"
netsh wlan stop hostednetwork 
write-host "Creating new network ..."-foreground "green"
netsh wlan set hostednetwork mode=allow ssid=$network_name key=$network_pass
write-host("Starting network ...") -foreground "green" 
netsh wlan start hostednetwork


