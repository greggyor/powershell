######################################################################################
#
# svnlog2loc.ps1
# svnのログを解析し、開発種別を表す特定キーワード別の開発規模（行数）を取得する。
#
# USAGE:
#  svnlog2loc.ps1 <リポジトリパス> <開始レビジョン> <終了レビジョン> <出力ファイル>
# 例）
#  svnlog2loc.ps1 file:///usr/local/svn/a25Project 2000 HEAD a25_SVN_LOC.csv
#
# History:
#   2012.11.26 初版 Iwasaki written by perl
#   2013.07.16 PowerShellへ移植
#   2014.01.31 公開用整理
#
######################################################################################
Param(
[Parameter(Mandatory=$true,HelpMessage="リポジトリパスを入力してください")][string]$repospath,
[Parameter(Mandatory=$true,HelpMessage="開始レビジョンを入力してください")][string]$startrev,
[Parameter(Mandatory=$true,HelpMessage="終了レビジョンを入力してください")][string]$endrev,
[Parameter(Mandatory=$true,HelpMessage="出力ファイル名を入力してください")][string]$outfile = "outfile.txt"
)

######################################################################################
# 指定リビジョンの差分情報から追加行数を数えて返す関数
######################################################################################
function countloc($rev) {
    $total_LOC = 0;
    # 差分情報をパースする為の正規表現パターン
    [regex]$filename_regex = "^Index: (.*)$"
    [regex]$suffix_regex = "(\.cpp$)|(\.c$)|(\.hpp$)|(\.h$)|(\.rc$)|(\.rc2$)"
    [regex]$incr_regex = "^\+"          # 追加行のパターン
    [regex]$whiteline_regex = "^\+\s*$" # 追加行だけど空行のパターン

    # テンポラリファイルハンドル、ファイル名取得
    $tempfile = [IO.Path]::GetTempFileName()

    # 指定リビジョンの差分情報をテンポラリファイルに書き出す
    # `svn diff -c $r $repospath > $fname`;
    Start-Process -FilePath svn -ArgumentList "diff -c${rev} ${repospath}" -RedirectStandardOutput $tempfile -NoNewWindow -Wait
    
    #--------------------------------------------------------------------------
    # 書き出した差分情報を取り込みながらパースして行数カウントを行っていく
    #
    #   foreach でも良いが元の Perl スクリプトが $_ 前提コードだったので雰囲気を合わせるために ForEach-Object を使う
    #
    Get-Content $tempfile -Encoding UTF8 -ErrorAction Stop | ForEach-Object {
        # Index から始まるファイル名の行を引っかけて行数カウントするかどうかのフラグをセットする
        if ($_ -cmatch $filename_regex) {
            # ファイル名の拡張子をチェックする
            #   PowerShell では \1 は $Matches[1] を使う
            if ($Matches[1] -match $suffix_regex) {
                $stat_flag = $TRUE;
            } else {
                $stat_flag = $FALSE;
            }
        }
        # セットした行数カウントフラグに基づいて "+" 行をカウントする
        # ただし、空行はカウントから除外する
        if ($stat_flag -eq $TRUE) {
            if (($_ -match $incr_regex) -and ($_ -notmatch $whiteline_regex)) {
                $total_LOC++
            }
        }
    }
    # for debug
    #echo "countloc : rev = $rev, LOC = $total_LOC"
    
    # テンポラリファイルの削除
    Remove-Item $tempfile
    
    return $total_LOC
}

######################################################################################
# main
######################################################################################

# ログ中に書いたキーワードの正規表現
# ここでは S0012103-ISS という開発種別コードを表すキーワードパターンをセットしている
[regex]$MET_regex = "[SE]\d\d\d\d\d\d-[A-Z][A-Z]*"

# テンポラリファイルハンドル、ファイル名取得
$tempfile = [IO.Path]::GetTempFileName()

# 指定リビジョンのコミットログをテンポラリファイルに書き出す
#`svn log -r $startrev:$endrev $repospath > $fname_log`;
Start-Process -FilePath svn -ArgumentList "log --xml -r${startrev}:${endrev} ${repospath}" -RedirectStandardOutput $tempfile -NoNewWindow -Wait

# 書き出したコミットログを XML として取り込む
[xml]$svndoc = Get-Content $tempfile -Encoding UTF8 -ErrorAction Stop

# テンポラリファイルの削除
Remove-Item $tempfile

#--------------------------------------------------------------------------
# コミットログを辿りながらログ情報の修正とLOCエントリの追加を行う
#
#   元のスクリプトでは新規に連想配列を生成していたが、
#   本スクリプトでは取り込んだ svn log の XML 構造を流用して LOC エントリを追加する方式とした
#
foreach($commit in $svndoc.log.logentry) {
    # コミット日付をフォーマットして .date に再代入する
    $commit.date = ([datetime]$commit.date).ToString("yyyy/MM/dd HH:mm:ss")
    # METコードパターンを抽出して .msg に再代入する
    $commit.msg = [string]($MET_regex.Matches($commit.msg) | ForEach-Object {$_.Value})
    # LOCエレメントを追加
    [void]$commit.AppendChild($svndoc.CreateElement("LOC"))
    # LOCを計算して代入する
    $commit.loc = [string](countloc $commit.revision)
}

# 出来上がった svndoc を CSV ファイルに出力する
echo $svndoc.log.logentry | Export-Csv $outfile -Force -Encoding UTF8 -NoTypeInformation

exit


