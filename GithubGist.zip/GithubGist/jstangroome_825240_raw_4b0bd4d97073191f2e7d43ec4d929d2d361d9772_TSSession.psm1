function Get-TSSession {
    
    & query session |
        Select-Object -Skip 1 |
        ForEach-Object {
            if ($_ -match '^(?<this>.)(?<sessionname>.{18})(?<username>.{22})(?<id>.{6})(?<state>.{8})(?<type>.{8})(?<device>.*)') {
                New-Object -TypeName PSObject -Property @{
                    SessionName = $Matches.sessionname.TrimEnd()
                    UserName = $Matches.username.TrimEnd()
                    SessionId = [int]::Parse($Matches.id)
                    State = $Matches.state.Trim()
                    Type = $Matches.type.TrimEnd()
                    Device = $Matches.device.TrimEnd()
                    Current = $Matches.this -ne ' '
                }
            }
        }
   
    
}

function Remove-TSSession (
    [Parameter(Mandatory=$true, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
    [int]
    $SessionId
) {
    'y' | & reset session $SessionId
}


