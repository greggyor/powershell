"foo" | Set-Content helloworld.txt
hg add helloworld.txt
hg commit -m "added helloworld"
(Measure-Command { hg log -G -l 5 }).TotalSeconds

