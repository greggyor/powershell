<#
    name: gui_form_template.ps1
    auth: nich0s
    desc: Template for building GUIs in PowerShell.
#>

# Imports
Import-Module SomethingWindowsy

# Main function
function GenerateForm {
    [reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
    [reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
    $formMain = New-Object System.Windows.Forms.Form
    $btnButton = New-Object System.Windows.Forms.Button
    $rtbRichTextBox = New-Object System.Windows.Forms.RichTextBox
    $lvListView = New-Object System.Windows.Forms.ListView
    $cbCheckBox = New-Object System.Windows.Forms.CheckBox
    $InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState

    # onClick btnButton
    function btnButtonOnClick {
        $btnButton.Text = "Working..."
        $selectedItemsInListView = '$lvListView.SelectedItems | %{$_.Text}'
        $itemQuery = Invoke-Expression $selectedItemsInListView
        ForEach ($item in $itemQuery) {
            $itemInfo = Get-Something $item -Property *
            ForEach ($prop in $itemInfo.PropertyNames) {
                $rtbRichTextBox.Text += "`n ${prop}: "
                $rtbRichTextBox.Text += $itemInfo.$prop
            }
        }
        $btnButton.Text = "Original Text"
    }

    function checkBoxAction1 {
        # Checkbox stateChange event
    }

    function checkBoxAction2 {
        # Checkbox stateChange event   
    }

    function onLoad {
        checkBoxAction2
    }

    $onFormLoad = {$formMain.WindowState = $InitialFormWindowState} # Correct the initial state of the form to prevent the .Net maximized form issue

    # Form "Main"
    $formMain.Text = "Title"
    $formMain.Name = "formMain"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 512
    $System_Drawing_Size.Height = 512
    $formMain.ClientSize = $System_Drawing_Size
    $formMain.DataBindings.DefaultDataSourceUpdateMode = 0
    $formMain.AutoScaleMode = 0

    # List Box
    $lvListView.Text = ""
    $lvListView.Name = "lvListView"
    $lvListView.UseCompatibleStateImageBehavior = $False
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 128
    $System_Drawing_Size.Height = 256
    $lvListView.Size = $System_Drawing_Size
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 0
    $System_Drawing_Point.Y = 0
    $lvListView.Location = $System_Drawing_Point
    $lvListView.View = 1
    $lvListView.Columns.Add("Items", 96) | out-null
    $lvListView.FullRowSelect = $True
    $lvListView.TabIndex = 0
    $lvListView.DataBindings.DefaultDataSourceUpdateMode = 0
    $formMain.Controls.Add($lvListView)

    # Rich Text Box
    $rtbRichTextBox.Text = ""
    $rtbRichTextBox.Name = "rtbRichTextBox"
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 128
    $System_Drawing_Point.Y = 0
    $rtbRichTextBox.Location = $System_Drawing_Point
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 384
    $System_Drawing_Size.Height = 512
    $rtbRichTextBox.Size = $System_Drawing_Size
    $rtbRichTextBox.TabIndex = 1
    $rtbRichTextBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $formMain.Controls.Add($rtbRichTextBox)

    # Button "Button"
    $btnButton.Text = "Button"
    $btnButton.Name = "btnButton"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 96
    $System_Drawing_Size.Height = 24
    $btnButton.Size = $System_Drawing_Size
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 16
    $System_Drawing_Point.Y = 256
    $btnButton.Location = $System_Drawing_Point
    $btnButton.TabIndex = 2
    $btnButton.DataBindings.DefaultDataSourceUpdateMode = 0
    $btnButton.UseVisualStyleBackColor = $True
    $btnButton.add_Click({btnButtonOnClick})
    $formMain.Controls.Add($btnButton)

    # CheckBox "CheckBox"
    $cbCheckBox.Text = "CheckBox"
    $cbCheckBox.Name = "cbCheckBox"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 96
    $System_Drawing_Size.Height = 24
    $cbCheckBox.Size = $System_Drawing_Size
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 16
    $System_Drawing_Point.Y = 304
    $cbCheckBox.Location = $System_Drawing_Point
    $cbCheckBox.TabIndex = 4
    $cbCheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $cbCheckBox.UseVisualStyleBackColor = $True
    $cbCheckBox.Add_CheckStateChanged({
        If ($cbCheckBox.Checked) {
            checkBoxAction1
            } Else {
            checkBoxAction2
        }
    })
    $formMain.Controls.Add($cbCheckBox)


    # Finish Building Form
    $InitialFormWindowState = $formMain.WindowState
    $formMain.add_Load($onFormLoad)
    $formMain.add_Load({onLoad})
    $formMain.ShowDialog()| Out-Null
}

GenerateForm

