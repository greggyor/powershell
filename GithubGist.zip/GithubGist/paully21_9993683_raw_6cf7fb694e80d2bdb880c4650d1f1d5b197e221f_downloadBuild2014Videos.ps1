[Environment]::CurrentDirectory=(Get-Location -PSProvider FileSystem).ProviderPath 
$rss = (new-object net.webclient)
$a = ([xml]$rss.downloadstring("http://channel9.msdn.com/Events/Build/2014/RSS/mp4high")) 
$a.rss.channel.item | foreach{  
   $url = New-Object System.Uri($_.enclosure.url)
   $file = $_.title.Replace(":", "-").Replace("?", "").Replace("/", "-") + "-" + $_.creator + ".mp4"
  if (!(test-path $file)) 
    { 
	$file 
        $wc = (New-Object System.Net.WebClient)
        $wc.DownloadFile($url, $file) 
    } 
}

