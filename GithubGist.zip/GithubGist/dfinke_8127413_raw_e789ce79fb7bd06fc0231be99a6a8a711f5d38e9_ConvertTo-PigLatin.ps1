function ConvertTo-PigLatin {
    param(
        [Parameter(ValueFromPipeline)]        
        [string[]]$string
    )

    Process {
        $r += $(foreach($s in $string) {    

            if(Write-Output b c d f g h j k l m n p q r s t v w x y z -eq $s[0]) {
                "{0}{1}ay" -f ($s[1..($s.length)] -join ''), $s[0]
            } else {
                $s + "way"
            }
        }) + ' '
    }

    End {$r.Trim()}
}


