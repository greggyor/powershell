DesktopWipe.ps1
# Desktop Wipe version .3
# Moved to powershell 
# Better program flow

# Set the user
$strUser="andrewliebowitz.ad"

Get-ChildItem -Force "C:\Users\$strUser\desktop" | ForEach-Object {$_} {remove-item $_.fullname -exclude *.lnk,*.ini -recurse}


