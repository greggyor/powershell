# Get some services on srv and srv1 computers
Get-Service -ComputerName 'srv_pko', 'srv_pko1' -Name 'IISADMIN', 'MSSQL$AUTODESKVAULT', 'Autodesk DataManagement Job Dispatch' |`
# Select properties
Select-Object -Property 'Status','Name','DisplayName','MachineName' |`
# Puch to GridView with possibility to select several items
Out-GridView -OutputMode Multiple -Title 'Vault services' |`
# Start selected in GridView services
ForEach-Object { Set-Service $_.Name -Status Stopped -ComputerName $_.MachineName}

