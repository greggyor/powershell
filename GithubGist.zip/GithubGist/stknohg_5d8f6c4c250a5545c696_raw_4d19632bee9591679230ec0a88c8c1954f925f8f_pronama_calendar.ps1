#
# プロ生ちゃん #カレンダープログラミング プチコンテスト用カレンダーPowerShell版
# 日曜始まりの当月のカレンダーを表示します。
# 土曜日は青色、日曜日は赤色で表示されます。
#
$Today = (Get-Date).Date; $Year = $Today.Year; $Month = $Today.Month;
$CharWidth = 2; $SpaceWidth = 1; $DefaultColor= 'White';
Write-Host ( "{0:yyyy/MM}" -F $Today).PadLeft(($CharWidth * 7 + $SpaceWidth * 6) / 2 + 4 ) -ForegroundColor:$DefaultColor;
Write-Host "".PadLeft(($CharWidth + $SpaceWidth) * (Get-Date -Year $Year -Month $Month -Day 1).DayOfWeek) -NoNewline;
1..[DateTime]::DaysInMonth($Year, $Month) | ForEach-Object {
    $Params = @{ 'SpaceWidth' = $SpaceWidth; 'NoNewLine' = $true; 'ForeColor' = $DefaultColor; }
    Switch ( (Get-Date -Year $Year -Month $Month -Day $_).DayOfWeek )
    {
        Saturday { $Params.SpaceWidth = 0;           $Params.NoNewLine = $false; $Params.ForeColor = 'Blue'; }
        Sunday   { $Params.SpaceWidth = $SpaceWidth; $Params.NoNewLine = $true;  $Params.ForeColor = 'Red'; }
        Default  { $Params.SpaceWidth = $SpaceWidth; $Params.NoNewLine = $true;  $Params.ForeColor = $DefaultColor; }
    }
    Write-Host ("{0,$CharWidth}" -F $_ ).PadRight($CharWidth + $Params.SpaceWidth) -NoNewline:$Params.NoNewLine -ForegroundColor:$Params.ForeColor;
}
Write-Host -NoNewline:(!$Params.NoNewLine);


