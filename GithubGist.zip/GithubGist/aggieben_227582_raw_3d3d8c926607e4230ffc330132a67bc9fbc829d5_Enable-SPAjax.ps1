# script for AJAX-enabling a SharePoint (MOSS 2007 / WSS 3.0) config
# Copyright © 2009 Benjamin Collins <ben.collins@acm.org>
#
# Compatible with .NET 3.5 AJAX support and AJAX Control Toolkit
#
# usage:
#  enable-spajax <path to web.config>
#

function usage {
    write-host "Enable-SpAjax <path>"
    write-host "Copyright © 2009 Benjamin Collins <ben.collins@acm.org>"    
}

# validate args
if ($args.count -eq 1 && $args{0}

# First, create backup
Write-Host "Making backup..."
copy-item $args{0}