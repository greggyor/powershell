#
# 既知の素数リストを保存しているファイルを読み込み
# 続きから素数を列挙する
#
# 素数リストファイルは
# primes000.txt, primes001.txt, primes002.txt ...
# と複数ファイルに分割されていても良い。
# ファイル番号の順に内容を連結した時、素数が昇順に並んでいること。
# 新たな素数は、ファイル番号最大+1のファイル名で保存します。
#
# ファイルが１つもない場合、初めにprimes000.txt を生成します。
#
 
# [実行例]
# 下記スクリプトを読みこんだ後、
#
# > enumerate-prime-numbers 100000
#
 
#
# $path : 作業フォルダ
# $test_count : 何回素数テストを行うか
# 

function enumerate-prime-numbers($test_count) {

    $path = "S:\temp\primes2"

    function floor($n){ [long][Math]::Floor($n) }

    $files = ls (Join-Path $path "primes*.txt") | sort

    $next_file_number = &{
        if($null -eq $files){
            0
        }else{
            $f = $files[$files.Length-1]
            1 + ($f.Name -replace "[^\d]","")
        }
    }
    
    $next_filename = Join-Path $path ("primes{0:d3}.txt" -f $next_file_number)

    if($next_file_number -eq 0){
        echo 2,3 > $next_filename
        $files = @($next_filename)
    }


    [System.Collections.Generic.List[long]]`
    $primes_list = New-Object System.Collections.Generic.List[long]

    [void]$primes_list.AddRange([long[]](cat $files))

    $primes_counter = $primes_list.Count
    $last_prime = $primes_list[$primes_counter - 1]

    [void]$primes_list.RemoveAt(0) # 2を削除 (奇数のみテストするため）

    1 .. (floor ($test_count / 2)) | % { $x=$last_prime } {

        $x += 2
        $test_limit = floor([Math]::Sqrt($x))

        $is_prime = $true
        foreach($p in $primes_list){
            if($p -gt $test_limit){ break }
            if($x % $p -eq 0){ $is_prime = $false; break }
        }

        if($is_prime){
            echo $x >> $next_filename
            [void]$primes_list.Add($x)

            $primes_counter++
            echo "$primes_counter : $x"
        }
    }
}


