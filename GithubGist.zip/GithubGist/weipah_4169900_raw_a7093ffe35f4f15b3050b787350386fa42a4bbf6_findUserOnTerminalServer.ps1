#require	-version	2.0	

# based on source from: http://www.nivot.org/blog/post.aspx?id=1f8255b2-05a7-4947-8dc3-01ce3c478cc2

# does not really work, because the waithandle is not processed correctly
# using $wait[$i].WaitOne() in for-loop would work, but is not the right way to process jobs in parallel

# create a pool of 10 runspaces	
$pool = [runspacefactory]::CreateRunspacePool(1,10)	
$pool.Open()
	
write-host "Available Runspaces: $($pool.GetAvailableRunspaces())"	
	
$jobs = @()	
$pipes = @()
$wait = @()	

$file = "C:\Users\adm-ml\Documents\WindowsPowerShell\Modules\PSTerminalServices\aco-terminal-servers.txt"

$location = (get-location)

# run multiple background pipelines
$servers = (Get-Content	$file)

for ($i=0; $i -lt $servers.count; $i++)	{	
		
	# create a "powershell pipeline runner"	
	[PowerShell]$ps	= [powershell]::create()	
	
	# assign our pool of runspaces to use	
	$ps.runspacepool = $pool

	# Add commands to pipeline
	#[String]$command  = "param($servername) Import-Module PSTerminalServices; get-tssession -ComputerName $servername -State active -Username mlenhardt;"
	# [Scriptblock]$ScriptBlock = [ScriptBlock]::Create($command)
	[ScriptBlock]$ScriptBlock = {
		param([String]$servername)
		set-location C:\Users\adm-ml\Documents\WindowsPowerShell
		Import-Module PSTerminalServices; 
		get-tssession -Computername $servername -Username mlenhardt;
	}
	
	[void]$ps.AddScript($ScriptBlock).AddArgument($servers[$i])
	
	# Organize pipelines in an Array
	$pipes += $ps
	
	#[void]$pipes[$i].AddScript($ScriptBlock)
	
	$jobs += $pipes[$i].BeginInvoke();	
	
	write-host "Available runspaces: $($pool.GetAvailableRunspaces())"
	
	# store wait handles for WaitForAll call
	$wait += $jobs[$i].AsyncWaitHandle
	[System.Threading.WaitHandle]::WaitAll($wait)
}	

# wait 20 seconds for all jobs to complete, else abort
#$success = [System.Threading.WaitHandle]::WaitAll($wait)
	
write-host "All completed?	$success"

# End asynchronous call..

# create array to receive results for each job
[PSObject]$result = @()
for	($i = 0; $i	-lt	$servers.count;	$i++) {	
	write "Job $($i): $($jobs[$i].iscompleted)"
	
	try {
		write "receive results for job $($i)"
		$result += $pipes[$i].endinvoke($jobs[$i])
		write "-- end result --"
	} catch {	
		#	Catch-Error...	
		write-warning	"error:	$_"	
	}
	
	# info about completed pipelines	
	#$info = $pipes[$i].InvocationStateInfo	
	
	#write-host	"State:	$($info.state)	;	Reason:	$($info.reason)"	
}	
	
#	all runspaces should be available again...	
write-host "Available runspaces: $($pool.GetAvailableRunspaces())"

