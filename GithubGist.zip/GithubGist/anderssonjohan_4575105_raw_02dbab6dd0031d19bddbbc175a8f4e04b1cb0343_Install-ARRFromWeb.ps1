param(
  [parameter(mandatory=$true, valuefrompipeline=$true)]
	$TargetHost,
	[switch] $force
)
begin {
	$packages = @( `
		@{ Name = "rewrite.msi"; Url = "http://download.microsoft.com/download/6/7/D/67D80164-7DD0-48AF-86E3-DE7A182D6815/rewrite_2.0_rtw_x64.msi" }, `
		@{ Name = "webpi.msi"; Url = "http://download.microsoft.com/download/B/0/0/B00FEF21-79DE-48B0-8731-F9CFE70CE613/WebPlatformInstaller_3_10_amd64_en-US.msi" }, `
		@{ Name = "webfarm.msi"; Url = "http://download.microsoft.com/download/3/4/1/3415F3F9-5698-44FE-A072-D4AF09728390/webfarm_amd64_en-US.msi" }, `
		@{ Name = "arr.msi"; Url = "http://download.microsoft.com/download/A/A/E/AAE77C2B-ED2D-4EE1-9AF7-D29E89EA623D/requestRouter_amd64_en-US.msi" }, `
		@{ Name = "extcache.msi"; Url = "http://download.microsoft.com/download/3/4/1/3415F3F9-5698-44FE-A072-D4AF09728390/ExternalDiskCache_amd64_en-US.msi" } `
	)

	Push-Location $env:TEMP
	function download( $url, $filename ) {
		if(!(Test-Path $filename) -or $force) {
			curl -o $filename $url
			if( $LASTEXITCODE -ne 0 -or !(Test-Path $filename) ) {
				Pop-Location
				throw "Failed to download $url to $filename"
				exit 1
			}
		}
	}

	Write-Host "Downloading MSI packages..."
	$packages | %{ 
		Write-Host ("Downloading MSI package: {0}" -f $_.Name)
		download $_.Url $_.Name
	}
}
process {
	$remotePackageDir = join-path $targetHost.ScriptSharePath "\"
	$packageNames = $packages | %{ $_.Name } 
	Write-Host "Copying packages to server: $packageNames"
	$packageNames | cp -Destination $remotePackageDir
	Write-Host "Done. Performing installation..."
	$Session = $targetHost.Connect()
	Invoke-Command -Session $Session -ArgumentList $packageNames -ScriptBlock {
		if( Get-Service was ) {
			Write-Host "Stopping IIS and WAS..."
			Stop-Service was -Force
		}

		Push-Location $targetHost.ScriptShareLocalPath
		$args | %{
			Write-Host "Installing MSI package: $_"
			$exitCode = (Start-Process -FilePath "msiexec" -ArgumentList "/q /i $_ /L*v install.log" -PassThru -Wait).ExitCode
			if( $exitCode -ne 0 ) {
				Pop-Location
				throw "MSIEXEC exited $exitCode Failed to install $_"
				exit 1
			}
			rm $_
		}
		Pop-Location

		if( Get-Service was ) {
			Start-Service was,w3svc -Verbose
		}
	}
	if( $? ) {
		Write-Host "ARR installed!"
	} else {
		cp $remotePackageDir\install.log -Verbose
		gc install.log | ?{ $_ -match "error|fail|requisite" }
	}
}
end {
	Pop-Location
}