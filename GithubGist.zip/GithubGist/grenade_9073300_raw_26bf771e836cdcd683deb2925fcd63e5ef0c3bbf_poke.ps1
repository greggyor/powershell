param (
  [hashtable] $pokes,
  [string] $config
)
$xml = (Get-Content $config) -as [xml]
foreach($xpath in $($pokes.Keys)){
  $xml.SelectSingleNode($xpath).set_InnerXML($pokes[$xpath])
}
$xml.Save($config)

