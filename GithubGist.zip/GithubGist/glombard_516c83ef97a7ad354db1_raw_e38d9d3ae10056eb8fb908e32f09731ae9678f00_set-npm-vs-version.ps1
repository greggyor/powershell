# See: https://www.npmjs.org/package/node-gyp
$vsVersion = "2012"
if (Test-Path HKLM:\Software\Microsoft\VisualStudio\12.0) {
	$vsVersion = "2013"
}
npm.cmd config set msvs_version $vsVersion


