# Comando para visualizar erros
get-splogevent | ?{$_.Correlation -eq "{CorrelationId}"} | select Area, Category, Level, EventID, Message | Format-List > C:\filename.log

# Exemplo real
get-splogevent | ?{$_.Correlation -eq "bf16df13-48c8-4c45-8fc7-1c855599c7a3"} | select Area, Category, Level, EventID, Message | Format-List > C:\log_today.log


