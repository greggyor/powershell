$user = Get-WMIObject Win32_UserAccount -Filter "Name='Administrator'"
$username = -join ([Char[]]'abcdefghijklmnopqrstuvwxyz._-~´`àéèç' | Get-Random -count 15)
$user.Rename($username)

