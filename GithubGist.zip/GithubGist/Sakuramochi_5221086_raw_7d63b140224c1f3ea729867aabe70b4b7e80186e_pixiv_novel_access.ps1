# pixivへお遣いにいってnovel情報を取ってくるスクリプト
# 言語
# Windows Powershell

# 書式
# pixiv_access_pattern [-novel_id] ノベル番号 [[-u_id] ユーザーID] [[-u_pass] ユーザーパスワード]

# オプション
# novel_id  小説のID
# u_id		ユーザID
# u_pass	パスワード

param( $novel_id =-1, $u_id = "ユーザーID", $u_pass="ユーザーパスワード" )

# ログイン部分はコメントアウト中 ログイン必須時のパラメータは下記
#param( $novel_id = -1, $u_id = "", $u_pass = "" )


# デバッグ出力設定
#$DebugPreference = "Continue"
$DebugPreference = "SilentlyContinue"

# ======================================================= #

# 引数チェック

if( $novel_id -eq -1 )
{
	# 入力NG
	Write-Host "Input novel no."
    exit
}

if( $u_id -eq "" )
{
	Write-Host "Input user id."
    exit
}

if( $u_pass -eq "" )
{
	Write-Host "Input password"
    exit
}

<#
 # アドレス定義
 #>

# コンテンツのURI
$pixiv_url_api_base = "http://spapi.pixiv.net/iphone/"
$pixiv_url_pc_base = "http://spapi.pixiv.net/iphone/novel_text.php?id="
$pixiv_url_mobile_base = "http://touch.pixiv.net/"


# ログインURL
$login_url = $pixiv_url_api_base + `
    "login.php?mode=login&pixiv_id=" + $u_id +"&pass=" + $u_pass + "&skip=0"


# API用URL
# 小説本文(セッションIDなしでOK)
$novel_text_url = $pixiv_url_api_base + "novel_text.php?id=" + $novel_id
# 小説概要
$novel_url = $pixiv_url_api_base + "novel.php?id=" + $novel_id


# ======================================================= #
# 関数定義
# ======================================================= #
#
# ログイン＆セッションID取得
#
function login_get_sessionid( )
{

    $webReq = [Net.HttpWebRequest]::Create( $login_url )
    $webReq.Method = "GET"
	# ユーザーエージェントはIE10を設定
    $webReq.UserAgent = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)"

    $webRes = $webReq.GetResponse()
    Write-Debug "====webres.ResponseUri"
    Write-Debug $webres.ResponseUri
    Write-Debug "====転送先URI webres.ResponseUri.AbsoluteUri"
    Write-Debug $webres.ResponseUri.AbsoluteUri
    Write-Debug "====Query"
    Write-Debug $webres.ResponseUri.Query

    # 転送先URI(Query)にのってくるセッションIDの取得
    # ?PHPSESSID=セッションID
    $session_id = $webres.ResponseUri.Query

    $webRes.Close()

    $session_id = $session_id -replace "[`?`&](PHPSESSID=.*?)([`?`&]|$)", "`$1"
    $session_id

}

#
# CSV形式(カンマ区切り)の1行を分割して配列に格納する
# ConvertFrom-CSVの使い方はわからんので自前
#
function csv_split_line( $str )
{
	$split_data = @()

	# 1行分割
	while ( $str.length -gt 0 )
	{
		# "データ",,"データ","データ"を分割
		if( $str -match "(?:`"((?:[^`"]|`"`")*)`"|([^,`"]*))(?:$|,)" )
		{
			$tmp_data = $matches[1]
			$str_pos = $matches[0].length
			$split_data += $tmp_data -replace ",$", ""
			if( $str.length -gt $str_pos )
			{
				$str = $str.substring( $str_pos )
			}else
			{
				$str = ""
			}
		}else
		{
			# フォーマット異常？
			Write-Host "CSV形式異常 $str"
			break
		}
	}

    $split_data

}

# ======================================================= #


$novel_data_list = @{}

# ログイン＆セッションID取得
# セッションIDはPHPSESSID=付き
# 小説概要と小説本文にはセッションIDは不要のためコメントアウト
#$session_id = login_get_sessionid

# データ取得(タイトル、作者)
$client = New-Object System.Net.WebClient
$enc = [Text.Encoding]::GetEncoding("utf-8") 

# 小説概要:APIから
$novel_header = ("小説id","ユーザーid","表紙の拡張子(jpgなど)","タイトル","要素4","ユーザー名", `
    "表紙のアドレス(サムネイル用)","要素7","要素8","表紙のアドレス(フルサイズ用)","要素10", `
    "要素11","投稿日時 YYYY-MM-DD hh:mm:ss","タグ(スペース区切り)","要素14","数値15", `
    "数値16","数値17","キャプション","数値19","数値20", `
    "数値21","数値22","数値23","p_sabi","要素25", `
    "0","シリーズid","要素28","プロフィール画像", "要素30")


$novel_data = $enc.GetString( $client.DownloadData( $novel_url ) )

# カンマ区切りで分割
$cnt = 0
csv_split_line $novel_data | % {
    $novel_data_list[$novel_header[$cnt]] = $_
    $cnt++
}

# 項目呼出し例
Write-Host "====小説概要 novel_data"
Write-Host "タイトル`t" $novel_data_list["タイトル"]
Write-Host "作者名`t" $novel_data_list["ユーザー名"]
Write-Host "作者ID`t" $novel_data_list["ユーザーid"]


# データ取得(本文)
# 小説本文取得:APIから
$novel_text_header = @()

$novel_text_data = $enc.GetString( $client.DownloadData( $novel_text_url ) )
Write-Host "====小説本文 novel_text_data"
$novel_text_data




