<#
  Report on unmerged changesets for release planning.
#>
function get_unmerged_changesets($source, $target)
{
  write-host "getting unmerged changesets for $source and $target"

  $changesets = @()


  $data = tf merge /candidate $source $target /recursive


<# $START_INDEX is because tf merge command returns header info we want to skip. e.g.

  Changeset Author                           Date
  --------- -------------------------------- ----------
#>
 
  $START_INDEX = 2  


  $CHANGESET_INDEX = 0  
  $AUTHOR_INDEX = 1
  $DATE_INDEX = 2



  for($i=$START_INDEX; $i -lt $data.count; $i++)
  {
    $changeset = new-object object 

    $tokens = $data[$i].Split(" ", [StringSplitOptions]::RemoveEmptyEntries)

     add-member -memberType NoteProperty -name "ChangeSetId" -value $tokens[$CHANGESET_INDEX] -inputObject $changeset
     add-member -memberType NoteProperty -name "Author" -value $tokens[$AUTHOR_INDEX] -inputObject $changeset
     add-member -memberType NoteProperty -name "Date" -value $tokens[$DATE_INDEX] -inputObject $changeset

     $comment = get_changeset_comment $changeset.ChangeSetId

     add-member -memberType NoteProperty -name "Comments" -value $comment -inputObject $changeset


     $changesets += $changeset
   
  }
  
  return $changesets

}


<#
  grab the comment from changeset id.

#>
function get_changeset_comment($changeset_id)
{
  write-debug "get_changeset_details($changeset_id)"

  $COMMENT_INDEX = 5

  $details = tf changeset $changeset_id /noprompt
  
  return $details[$COMMENT_INDEX].Trim()
}

<# e.g.

$changesets = @()

$changesets += get_unmerged_changesets "$/dev" "$/main"

$changesets | export-csv 

#>

