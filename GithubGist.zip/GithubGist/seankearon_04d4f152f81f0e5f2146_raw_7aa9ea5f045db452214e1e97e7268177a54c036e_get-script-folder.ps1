# Get the script's folder
function get_script_directory # http://blogs.msdn.com/b/powershell/archive/2007/06/19/get-scriptdirectory.aspx
{
    $Invocation = (Get-Variable MyInvocation -Scope 1).Value
    Split-Path $Invocation.MyCommand.Path
}
$scriptpath = get_script_directory
cd $scriptpath

# Pause for user to press a key
Write-Host "Press any key to continue ..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

