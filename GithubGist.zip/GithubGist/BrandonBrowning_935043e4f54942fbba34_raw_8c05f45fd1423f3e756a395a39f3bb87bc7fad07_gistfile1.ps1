# pk: pk - Azure Table Storage Log Partition Key Generator
#   by Brandon Browning
#
# Usage: pk [time-expression]...
# Time expression examples: +5s, -1h15s, 30m
# Examples:
#   pk           # Gets current time keys
#   pk -30s      # Gets time keys 30 seconds ago
#   pk 0s -1h5s  # Gets time keys now, and 1 hour 5 seconds ago
# Example output:
#   PS C:\Users\bbrowning> pk 0s -1h +2h15s +1d
#   2014-05-30T20:13:13.0665297Z    PartitionKey ge '0635370775930665297'    PartitionKey ge '1401480793'
#   2014-05-30T19:13:13.0665297Z    PartitionKey ge '0635370739930665297'    PartitionKey ge '1401477193'
#   2014-05-30T20:13:28.0665297Z    PartitionKey ge '0635370776080665297'    PartitionKey ge '1401480808'
#   2014-05-31T20:13:13.0665297Z    PartitionKey ge '0635371639930665297'    PartitionKey ge '1401567193'

$start = [DateTime]::UtcNow

if ($args.Count -eq 0) {
    $args = @('+0s')
}

foreach ($arg in $args) {
    $now = $start.AddSeconds(0)

    foreach ($match in [Regex]::Matches($arg, '(?:(\d+)(\w))+')) {
        if ($arg[0] -eq '-') {
            $mult = -1
        } else {
            $mult = 1
        }

        if ($match.Groups[2].Value.ToLower() -eq 'd') {
            $now = $now.AddDays($mult * [int]$match.Groups[1].Value)
        } elseif ($match.Groups[2].Value.ToLower() -eq 'h') {
            $now = $now.AddHours($mult * [int]$match.Groups[1].Value)
        } elseif ($match.Groups[2].Value.ToLower() -eq 'm') {
            $now = $now.AddMinutes($mult * [int]$match.Groups[1].Value)
        } elseif ($match.Groups[2].Value.ToLower() -eq 's') {
            $now = $now.AddSeconds($mult * [int]$match.Groups[1].Value)
        }
    }

    $epoch = New-Object DateTime 1970, 1, 1
    $pk = '0' + $now.Ticks.ToString()
    $unix = [int]($now - $epoch).TotalSeconds
    "{0}    PartitionKey ge '{1}'    PartitionKey ge '{2}'" -f ($now.ToString('o'), $pk, $unix)
}

