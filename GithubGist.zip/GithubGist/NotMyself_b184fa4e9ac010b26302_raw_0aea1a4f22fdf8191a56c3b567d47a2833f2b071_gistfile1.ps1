$dir = 'c:\exports\'
$years = @{ 2013=18 } #;2014=19;2012=17; 2011=16; 2010=15; 2009=14; 2008=13; 2007=12; 2006=11
$domains = @("MSPHSPE", "EOC", "WAAS", "WELPA") #"MSPHSPE", "EOC", "WAAS", "WELPA", "AYP"

$years.Keys | % { 
    $path = "$dir$_\"
    if((Test-Path -Path $path)) {
        Remove-Item -Recurse -Force $path
    }
    New-Item -ItemType directory -Path $path

	$year = $years[$_]
	$domains | ForEach-Object {
		Invoke-Expression ".\GenerateDownloadFiles.exe -o $path -y $year -d $_"
	}
}

