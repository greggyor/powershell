function TypeToIdentity {
    param (
        [type]
        $Type
    )

    if ($Type.HasElementType) {
        $typeIdentity = TypeToIdentity $Type.GetElementType()
    } else {
        $typeIdentity = $Type.Name
    }

    if ($Type.IsByRef) {
        $typeIdentity += "Ref"
    }

    if ($Type.IsArray) {
        $typeIdentity += "Array"
    }

    if ($Type.IsPointer) {
        $typeIdentity += "Pointer"
    }
    
    if ($Type.IsGenericType) {
        $typeIdentity = $typeIdentity -replace '`', ''
    }
    
    $typeIdentity
}

function ParameterInfoToIdentity {
    param (
        [System.Reflection.ParameterInfo]
        $ParameterInfo
    )

    TypeToIdentity $ParameterInfo.ParameterType
}

function ParameterInfosToIdentity {
    param (
        [System.Reflection.ParameterInfo[]]
        $ParameterInfos
    )

    $paramsIdentity = ""
    if (0 -lt $ParameterInfos.Length) {
        $paramIdentities = New-Object "System.Collections.Generic.List[string]"
        foreach ($param in $ParameterInfos) {
            $paramIdentities.Add((ParameterInfoToIdentity $param))
        }
        $paramsIdentity = [string]::Join('', $paramIdentities)
    }
    $paramsIdentity
}

function ConstructorInfoToIdentity {
    param (
        [System.Reflection.ConstructorInfo]
        $ConstructorInfo
    )

    $name = "Constructor"
    $paramsIdentity = ParameterInfosToIdentity $ConstructorInfo.GetParameters() 
    $name + $paramsIdentity
}

function MethodInfoToIdentity {
    param (
        [System.Reflection.MethodInfo]
        $MethodInfo
    )

    $name = ($MethodInfo.Name -creplace '^get_(.*)', '$1Get') -creplace '^set_(.*)', '$1Set'
    
    $genericArgsName = ""
    if ($MethodInfo.IsGenericMethod) {
        $genericArgs = $MethodInfo.GetGenericArguments()
        $genericArgNames = New-Object "System.Collections.Generic.List[string]"
        foreach ($genericArg in $genericArgs) {
            $genericArgNames.Add("Of" + $genericArg.Name)
        }
        $genericArgsName = [string]::Join('', $genericArgNames)
    }

    $paramsIdentity = ParameterInfosToIdentity $MethodInfo.GetParameters()

    $name + $genericArgsName + $paramsIdentity
}

function ConvertTo-MethodIdentity {

    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true)]
        [System.Reflection.MethodBase[]]
        $InputObject
    )

    begin {
        
    } process {
        if ($null -ne $InputObject) {
            foreach ($methodBase in $InputObject) {
                switch ($methodBase)
                {
                    { $_ -is [System.Reflection.ConstructorInfo] } {  
                        ConstructorInfoToIdentity $methodBase
                    }
                    { $_ -is [System.Reflection.MethodInfo] } {  
                        MethodInfoToIdentity $methodBase
                    }
                    Default { 
                        throw New-Object System.ArgumentException ('Parameter $Info({0}) is not supported.' -f $methodBase.GetType()) 
                    }
                }
            }
        }
    } end {

    }
}

[array].GetMembers() | ? { $_ -is [System.Reflection.MethodBase] } | ConvertTo-MethodIdentity
# ---
# GetEnumerator
# AsReadOnlyOfTTArray
# ResizeOfTTArrayRefInt32
# CreateInstanceTypeInt32
# CreateInstanceTypeInt32Int32
# CreateInstanceTypeInt32Int32Int32
# CreateInstanceTypeInt32Array
# CreateInstanceTypeInt64Array
# CreateInstanceTypeInt32ArrayInt32Array
# CopyArrayArrayInt32
# CopyArrayInt32ArrayInt32Int32
# ConstrainedCopyArrayInt32ArrayInt32Int32
# CopyArrayArrayInt64
# CopyArrayInt64ArrayInt64Int64
# ClearArrayInt32Int32
# GetValueInt32Array
# GetValueInt32
# GetValueInt32Int32
# GetValueInt32Int32Int32
# GetValueInt64
# GetValueInt64Int64
# GetValueInt64Int64Int64
# GetValueInt64Array
# SetValueObjectInt32
# SetValueObjectInt32Int32
# SetValueObjectInt32Int32Int32
# SetValueObjectInt32Array
# SetValueObjectInt64
# SetValueObjectInt64Int64
# SetValueObjectInt64Int64Int64
# SetValueObjectInt64Array
# LengthGet
# LongLengthGet
# GetLengthInt32
# GetLongLengthInt32
# RankGet
# GetUpperBoundInt32
# GetLowerBoundInt32
# SyncRootGet
# IsReadOnlyGet
# IsFixedSizeGet
# IsSynchronizedGet
# Clone
# BinarySearchArrayObject
# BinarySearchArrayInt32Int32Object
# BinarySearchArrayObjectIComparer
# BinarySearchArrayInt32Int32ObjectIComparer
# BinarySearchOfTTArrayT
# BinarySearchOfTTArrayTIComparer1
# BinarySearchOfTTArrayInt32Int32T
# BinarySearchOfTTArrayInt32Int32TIComparer1
# ConvertAllOfTInputOfTOutputTInputArrayConverter2
# CopyToArrayInt32
# CopyToArrayInt64
# ExistsOfTTArrayPredicate1
# FindOfTTArrayPredicate1
# FindAllOfTTArrayPredicate1
# FindIndexOfTTArrayPredicate1
# FindIndexOfTTArrayInt32Predicate1
# FindIndexOfTTArrayInt32Int32Predicate1
# FindLastOfTTArrayPredicate1
# FindLastIndexOfTTArrayPredicate1
# FindLastIndexOfTTArrayInt32Predicate1
# FindLastIndexOfTTArrayInt32Int32Predicate1
# ForEachOfTTArrayAction1
# IndexOfArrayObject
# IndexOfArrayObjectInt32
# IndexOfArrayObjectInt32Int32
# IndexOfOfTTArrayT
# IndexOfOfTTArrayTInt32
# IndexOfOfTTArrayTInt32Int32
# LastIndexOfArrayObject
# LastIndexOfArrayObjectInt32
# LastIndexOfArrayObjectInt32Int32
# LastIndexOfOfTTArrayT
# LastIndexOfOfTTArrayTInt32
# LastIndexOfOfTTArrayTInt32Int32
# ReverseArray
# ReverseArrayInt32Int32
# SortArray
# SortArrayArray
# SortArrayInt32Int32
# SortArrayArrayInt32Int32
# SortArrayIComparer
# SortArrayArrayIComparer
# SortArrayInt32Int32IComparer
# SortArrayArrayInt32Int32IComparer
# SortOfTTArray
# SortOfTKeyOfTValueTKeyArrayTValueArray
# SortOfTTArrayInt32Int32
# SortOfTKeyOfTValueTKeyArrayTValueArrayInt32Int32
# SortOfTTArrayIComparer1
# SortOfTKeyOfTValueTKeyArrayTValueArrayIComparer1
# SortOfTTArrayInt32Int32IComparer1
# SortOfTKeyOfTValueTKeyArrayTValueArrayInt32Int32IComparer1
# SortOfTTArrayComparison1
# TrueForAllOfTTArrayPredicate1
# Initialize
# ToString
# EqualsObject
# GetHashCode
# GetType


