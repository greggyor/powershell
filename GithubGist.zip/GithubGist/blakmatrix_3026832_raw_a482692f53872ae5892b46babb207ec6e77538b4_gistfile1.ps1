
PS C:\Users\fred rosak> cd .\projects
PS C:\Users\fred rosak\projects> jitsu install
path.existsSync is now called `fs.existsSync`.
info:   Welcome to Nodejitsu blakmatrix
info:   It worked if it ends with Nodejitsu ok
info:   Executing command install
help:   The install command downloads pre-built node applications
help:   To continue, you will need to select an application
info:   Please choose a node app so we can get you started
info:   Available node apps:
info:   helloworld    demo `hello world` http server
info:   express       express.js boilerplate
info:   socket.io     socket.io boilerplate
info:   http-server   a robust and customizable http server
prompt: Which node app would you like to install? (helloworld): socket.io
info:   Installing socket.io locally
warn:   Downloading packages from npm, this may take a moment...
info:   socket.io installed
path.exists is now called `fs.exists`.
help:   You can now jitsu deploy this application
prompt: Would you like to start this application locally? (yes):
info:   socket.io is now starting
help:   To exit application, press CTRL-C

'.' is not recognized as an internal or external command,
operable program or batch file.
error:  Error running command install
error:  nodeapps-socket.io@0.1.0-1 start: `./bin/server`
`cmd "/c" "./bin/server"` failed with 1
info:   Nodejitsu not ok
PS C:\Users\fred rosak\projects> ls


    Directory: C:\Users\fred rosak\projects


Mode                LastWriteTime     Length Name
----                -------------     ------ ----
d----         6/30/2012   9:34 PM            socket.io


PS C:\Users\fred rosak\projects> c socket.io
The term 'c' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the name, or if a path was included,
verify that the path is correct and try again.
At line:1 char:2
+ c <<<<  socket.io
    + CategoryInfo          : ObjectNotFound: (c:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

PS C:\Users\fred rosak\projects> cd socket.io
PS C:\Users\fred rosak\projects\socket.io> ls


    Directory: C:\Users\fred rosak\projects\socket.io


Mode                LastWriteTime     Length Name
----                -------------     ------ ----
d----         6/30/2012   9:34 PM            bin
d----         6/30/2012   9:34 PM            node_modules
d----         6/30/2012   9:34 PM            public
-a---         6/30/2012   9:34 PM        453 package.json
-a---         6/30/2012   9:34 PM       1669 ReadMe.md


PS C:\Users\fred rosak\projects\socket.io> jitsu login
path.existsSync is now called `fs.existsSync`.
info:   Welcome to Nodejitsu blakmatrix
info:   It worked if it ends with Nodejitsu ok
info:   Executing command login
prompt: username: blakmatrix
prompt: password: tty.setRawMode: Use `process.stdin.setRawMode()` instead.

info:   Authenticated as blakmatrix
info:   Nodejitsu ok
PS C:\Users\fred rosak\projects\socket.io> jitsu deploy
path.existsSync is now called `fs.existsSync`.
info:   Welcome to Nodejitsu blakmatrix
info:   It worked if it ends with Nodejitsu ok
info:   Executing command deploy
warn:
warn:   Your package.json file is missing required fields:
warn:
warn:     subdomain
warn:
warn:   Your package.json file has invalid required fields:
warn:
warn:     engines
warn:
warn:   Prompting user for required fields.
warn:   Press ^C at any time to quit.
warn:
help:
help:   The subdomain is where your application will reside.
help:   Your application will then become accessible at: http://yourdomain.jit.su
help:
prompt: subdomain (blakmatrix.socket.io):
prompt: engines (0.8.x):
warn:   About to write C:\Users\fred rosak\projects\socket.io\package.json
data:
data:   {
data:       subdomain: 'blakmatrix.socket.io',
data:       optionalDependencies: {},
data:       devDependencies: {},
data:       dependencies: { socket.io: 'v0.8.x', express: 'v2.5.x' },
data:       scripts: { start: './bin/server' },
data:       version: '0.1.0-1',
data:       name: 'nodeapps-socket.io',
data:       author: { email: 'support@nodejitsu.com', name: 'Nodejitsu Inc.' },
data:       engines: { node: '0.8.x' },
data:       dist: { shasum: '34ed79d668fbf5265c2db137cffcf939f9b97e0a' },
data:       analyze: false
data:   }
data:
prompt: Is this ok? (yes):
info:   Skipping require-analyzer because noanalyze option is set
info:   Checking app availability nodeapps-socket.io
info:   Creating app nodeapps-socket.io
info:   Creating snapshot 0.1.0-1
info:   Updating app nodeapps-socket.io
info:   Activating snapshot 0.1.0-1 for nodeapps-socket.io
info:   Stopping app nodeapps-socket.io
info:   App nodeapps-socket.io is now stopped
info:   Starting app nodeapps-socket.io
error:  Error running command deploy
error:  Nodejitsu Error (500): Internal Server Error
error:  There was an error while attempting to deploy your application.
error:
error:  Error spawning drone: no matching engine found
error:  Repository configuration
error:
error:  This type of error is usually a user error.
error:  Error output from Haibu:
error:
error:  Error: Error spawning drone: no matching engine found
error:      at [object Object].getSpawnOptions (/root/haibu-orchestra/node_modules/haibu/lib/haibu/core/spawner.js:34:17)
error:      at [object Object].getSpawnOptions (/root/haibu-orchestra/node_modules/haibu/lib/haibu/plugins/useraccounts.js:30:33)
error:      at spawnNpm (/root/haibu-orchestra/node_modules/haibu/lib/haibu/plugins/useraccounts.js:58:32)
error:      at Object.oncomplete (/root/haibu-orchestra/node_modules/haibu/node_modules/tar/node_modules/fstream/node_modules/graceful-fs/graceful-fs.js:94:5)
info:   Nodejitsu not ok
PS C:\Users\fred rosak\projects\socket.io>






