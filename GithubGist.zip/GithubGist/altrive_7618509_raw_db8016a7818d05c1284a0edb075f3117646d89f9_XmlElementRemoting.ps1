$xmlDocument = [xml] "<root><elem>abcd</elem></root>"
$xmlElement = $xmlDocument.root

Invoke-Command localhost -ScriptBlock {
    $arg = $using:xmlDocument
    Write-Host ("Type={0}, Value={1}" -f $arg.GetType(), $arg.OuterXml)
}

Invoke-Command localhost -ScriptBlock {
    $arg = $using:xmlElement
    Write-Host ("Type={0}, Value={1}" -f $arg.GetType(), $arg) #XmlElement is not supported by PSRemiting
}