${c:\a.file} = 12345 # set
${c:\a.file} = ""  #empty
${c:\a.file} +="file" #apply 
${c:\a.file} = ${c:\b.file}  #copy file 


