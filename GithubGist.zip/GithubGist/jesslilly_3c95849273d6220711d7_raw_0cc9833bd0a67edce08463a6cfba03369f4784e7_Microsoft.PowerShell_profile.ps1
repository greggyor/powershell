#
# vi $profile
# C:\Users\userid\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1
#
new-alias vi "C:\Program Files\Sublime Text 2\sublime_text.exe"
new-alias grep select-string

