function nyao
{
    [OutputType([int])]
    [CmdletBinding()]
    param()
    return [uri]"http://google.com"
}

