#1. one way to do it.
2,3,4,10 | ForEach { $_ * 10}


#2. other way
$numbers = 2,3,4,10

ForEach ($Number in $Numbers) {
  
  $Number * 10 | Out-File text.txt -append
}

