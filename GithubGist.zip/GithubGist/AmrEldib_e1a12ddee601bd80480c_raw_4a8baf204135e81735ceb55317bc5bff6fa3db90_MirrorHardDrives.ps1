Clear-Host
# Decleare variable to hold the service name
$serviceName = "MSSQL`$SQLEXPRESS"

# Where the log file will be stored
$logHome = "D:\Amr\Backup\BackupLogs\"

# Get timestamp
$timeStamp = Get-Date -Format "yyyy-MM-dd HH-mm-ss"

# Generate name of log file
$logFile = $logHome + "Backup Log " + $timeStamp + ".txt"

# Write a starting message
"Starting backup at $timestamp" | out-file $logFile -Append -Force

# Stop the SQL service if it's running
$serviceStatus = Get-SqlServiceStatus ($serviceName)
"Service $serviceName is $serviceStatus." | out-file $logFile -Append -Force
if ($serviceStatus -eq "Running")
{
    "SQL service is running, stopping it..." | out-file $logFile -Append -Force
    Stop-SqlService ($serviceName) | out-file $logFile -Append -Force
}

# Unmount Codebox if it was already mounted
$CodeboxMounted = Exists-Drive "M:"
if ($CodeboxMounted -eq "True")
{
    "Codebox is mounted. Unmounting Codebox..." | out-file $logFile -Append -Force
    # Unmount Codebox
    Unmount-Codebox | out-file $logFile -Append -Force
    "Codebox is not mounted now." | out-file $logFile -Append -Force
}
else
{
    "Codebox is not mounted" | out-file $logFile -Append -Force
}

# Run sync toy
Run-SyncToy ("TestBackup") | out-file $logFile -Append -Force

# Mount Codebox if it was already mounted
if ($CodeboxMounted -eq "True")
{
    "Mounting Codebox..." | out-file $logFile -Append -Force
    # Mount Codebox
    Mount-Codebox | out-file $logFile -Append -Force
    "Codebox is mounted now." | out-file $logFile -Append -Force
}

# Run the SQL service if it's stopped
$serviceStatus = Get-SqlServiceStatus ($serviceName)
"Service $serviceName is $serviceStatus." | out-file $logFile -Append -Force
if ($serviceStatus -eq "Stopped")
{
    "Starting SQL service..." | out-file $logFile -Append -Force
    Start-SqlService ($serviceName) | out-file $logFile -Append -Force
}

# Write end message
$finishTime = Get-Date -Format "yyyy-MM-dd HH-mm-ss"
"Backup script finished at $finishTime" | out-file $logFile -Append -Force