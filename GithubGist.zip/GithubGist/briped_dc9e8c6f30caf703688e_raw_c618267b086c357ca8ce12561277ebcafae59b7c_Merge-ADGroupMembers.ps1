Param(
    [parameter(Mandatory=$true,
        HelpMessage="Enter one or more AD groups to merge/copy from.")]
        [string[]]
        $SourceGroups,
    [parameter(Mandatory=$true,
        HelpMessage="Enter AD group to merge/copy to.")]
        [string]
        $TargetGroup,
    [parameter(Mandatory=$false,
        HelpMessage="Enter one or more AD groups with users to exclude from TargetGroup.")]
        [string[]]
        $ExcludeGroup
)
Import-Module -Name ActiveDirectory -ErrorAction SilentlyContinue

If (!(Get-ADGroup -Identity $TargetGroup | Out-Null))
{
    Write-Warning -Message "The AD Group '$($TargetGroup)' does not exist. Exiting script."
    Exit
}

ForEach ($Source in $SourceGroups) {
    Get-ADGroupMember -Recursive -Identity $Source | Get-ADUser | Where-Object { $_.Enabled -eq $true } | ForEach-Object { 
        Add-ADGroupMember -Identity $TargetGroup -Members $_.SamAccountName 
    }
}

ForEach ($Exclude in $ExcludeGroup) {
    If (!(Get-ADGroup -Identity $Exclude | Out-Null))
    {
        Write-Warning -Message "The AD Group '$($Exclude)' does not exist. Skipping."
        Continue
    }
    Get-ADGroupMember -Recursive -Identity $Exclude | ForEach-Object {
        Remove-ADGroupMember -Identity $TargetGroup -Members $_.SamAccountName -Confirm:$false
    }
}

