Send-MailMessage -From <from> -to <to> -subject <subject> -SmtpServer email-smtp.us-east-1.amazonaws.com -Credential 
  $(New-Object System.Management.Automation.PSCredential -argumentlist <AWS_ACCESS_KEY>,
    $(ConvertTo-SecureString -AsPlainText -String <AWS_SECRET_KEY> -Force)
  ) 
-UseSsl -Port 587


