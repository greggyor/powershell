Service -ConfigurationData $configuraionData -OutputPath service

