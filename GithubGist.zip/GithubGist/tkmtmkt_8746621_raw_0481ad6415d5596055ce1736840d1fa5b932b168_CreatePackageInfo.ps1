<#
.SYNOPSIS
パッケージ情報ファイルを作成します。
#>
ls -dir -r | select -skip 3 | %{
    $dir = $_.fullname
    $packageInfoFile = "$dir\package-info.java"
    $packageName = (resolve-path $dir -rel).substring(2).replace('\','.')

    if (test-path $packageInfoFile) {
        $result = "    "
    } else {
        $content = @"
package $packageName;

/**
 * TODO: パッケージの説明を記入する
 * @since 1.0
*/
"@ -split "`r*`n"
        [System.IO.File]::WriteAllLines($packageInfoFile, $content)
        $result = "new "
    }
    write-host "$result $(resolve-path $packageInfoFile -rel)"
}

# vim: set ts=4 sw=4 et:

