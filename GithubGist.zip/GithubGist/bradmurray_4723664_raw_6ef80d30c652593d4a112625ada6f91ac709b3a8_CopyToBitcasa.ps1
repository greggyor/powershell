# Usage: CopyToBitcasa FileSpec [-move] [-dir=DestinationDirectory]
#   FileSpec: A file to copy/move (accepts wildcards)
#   -move: File(s) will be moved to the Bitcasa directory
#   -dir: The directory beneath $BitcasaDirectory that where the files(s) will go. If omitted copy will go to the root. This directory must exist on Bitcasa.
# Created by: Brad Murray murraybrad+copytobitcasa@gmail.com

$BitcasaDirectory = "I:\My Infinite"
$BitcasaOutgoingDirectory = $home+"\AppData\Roaming\com.bitcasa.Bitcasa\Data\bks\outgoing"
$MoveToBitcasa = ""

function SmartFileSize([int64]$fileSize) {
    # Return file size at optimal scale
    If ($fileSize -lt 1KB) { return ($fileSize.ToString()) }
    ElseIf  ($fileSize -lt 1MB) { return ([string]::Format("{0:N3} KB", $fileSize / 1KB)) }
    ElseIf  ($fileSize -lt 1GB) { return ([string]::Format("{0:N3} MB", $fileSize / 1MB)) }
    ElseIf  ($fileSize -lt 1TB) { return ([string]::Format("{0:N3} GB", $fileSize / 1GB)) }
    Else { return ($fileSize.ToString()) }
}

function WriteTime($timeIn) {
    If ($timeIn.Hours -gt 0) { return [string]::Format("{0}:{1:00}:{2:00}", $timeIn.Hours, $timeIn.Minutes, $timeIn.Seconds) }
    ElseIf ($timeIn.Minutes -gt 0) { return [string]::Format("{0}:{1:00}", $timeIn.Minutes, $timeIn.Seconds) }
    Else { return [string]::Format("{0} sec", $timeIn.Seconds) }
}

function GetBitcasaOutgoingDirSize() {
    try {
        [string]$root = $(resolve-path $BitcasaOutgoingDirectory)
        $cItem = Get-ChildItem -re $root -erroraction 'silentlycontinue' | ?{ -not $_.PSIsContainer } | measure-object -sum -property Length -erroraction 'silentlycontinue'
        [long]$dirSize = $cItem.sum
        return $dirSize
    }
    catch {
        return [long]-1
    }
}

If (!(Test-Path $BitcasaDirectory -pathType container)) {
    Write-Host $BitcasaDirectory does not exist -ForegroundColor Red
    Exit
}
If (!(Test-Path $BitcasaOutgoingDirectory -pathType container)) {
    Write-Host $BitcasaOutgoingDirectory does not exist -ForegroundColor Red
    Exit
}

# Get any command-line arguments
ForEach ($arg in $args)
{
    Write-Host $arg
    Switch ($arg.ToLower().Split("=")[0])
    {
        "-move" { $MoveToBitcasa = "/MOV" }
        "-dir" { $BitcasaDirectory = $BitcasaDirectory + "\" + $arg.Split("=")[1]
            Write-Host "NEWDIR " $BitcasaDirectory
        }
    }
}

Get-ChildItem $args[0] | ForEach-Object {
    Write-Host $_.FullName -ForegroundColor Cyan
    Write-Host "Mod Date:" $LastWriteDate -ForegroundColor Cyan
    Write-Host "Size:" (SmartFileSize($_.Length)) -ForegroundColor Cyan
    
    # Copy the show to Bitcasa
    If (Test-Path $BitcasaDirectory -pathType container)
    {
        [DateTime]$waitStart = Get-Date
        $dirSize = GetBitcasaOutgoingDirSize
        while(!($dirSize -eq 0)) {
            # Wait for Bitcasa outgoing queue to empty before adding another file
            $waitTime = (Get-Date) - $waitStart
            write-host $([string]::Format("Waiting since {0} {1} {2}      ", $waitStart, (WriteTime($waitTime)), (SmartFileSize($dirSize)))) -nonewline -ForegroundColor White
            write-host $("`r") -nonewline
            Start-Sleep 10;
            $dirSize = GetBitcasaOutgoingDirSize
        }
        write-host ""

        & RoboCopy $_.DirectoryName $BitcasaDirectory $_.Name /W:10 /R:1 /NJH /NDL $MoveToBitcasa
    }
    Else
    {
        Write-Host $BitcasaDirectory does not exist -ForegroundColor Red
        break
    }
}


