#set up vars
$computername = Get-Content 'server_list.txt'
$msiname = "NewRelicAgent_x86_3.4.24.0.msi"
$licenseKey = "aaaaabbbbbbcccccdddddeeeeeffffggggghhhhh"
$destinationFolder = "\\$computer\C$\temp\install"
$payload = $destinationFolder + "\" + $msiname


foreach ($computer in $computername) 
{
    #This section will copy the $sourcefile to the $destinationfolder. If the Folder does not exist it will create it.
    if (!(Test-Path -path $destinationFolder))
    {
        New-Item $destinationFolder -Type Directory
    }
    Copy-Item -Path $sourcefile -Destination $destinationFolder
    #stop IIS
    Invoke-Command -ComputerName $computer { iisreset.exe /stop }
    
    $exitCode =Invoke-Command -ComputerName $computer -ScriptBlock { msiexec.exe /i $payload /qn  NR_LICENSE_KEY=$licenseKey}
    if($exitCode -eq 0) {
        Write-Host "Installation successful!" -ForegroundColor Green
    } else {
        Write-Host "Installation unsuccessful. Exitcode: $exitCode" -ForegroundColor Red        
    }
}




