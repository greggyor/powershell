# Requires -Version 3.0
 
<#
.SYNOPSIS
    This script is used to perform basic configuration tasks on one or many Server 2012 core installations.
.DESCRIPTION
    New-CoreVMConfig is a script that will import a list of MAC addresses located at C:\Mac.txt by default and then query the DHCP server using the DhcpServer module 
    introduced in PowerShell 3.0 and Server 2012 to determine its associated dynamically assigned IP address.  When these results have been gathered we will process 
    each IP address one at a time, joining the machine to the domain.  During the join operation we will also be renaming the machine to SERVER(count) as well as 
    restarting the machine after the join is completed.  This operation will force the join and will not propmt the user for confirmation as defined by the event 6 
    rules to minimize user interaction.  Any non-terminating errors will be genereated in a more friendly manner by using Write-Warning and the exception message 
    returned for troubleshooting.  Successful operations will continue to move foward in the script.
.EXAMPLE
    .\New-CoreVMConfig.ps1
.NOTES
    2013 PowerShell Scripting Games - Beginner Event 6
.NOTES
    Thanks to everyone for the feedback both good and bad in this years PowerShell Games.  
    This was my first go at the games and I'd like to think I've learned alot during the last 6 weeks.
#>
 
# Test for the DhcpServer PowerShell Module that is required for operation
 
if (-not(Get-Module -Name DhcpServer)) {
    if (Get-Module -ListAvailable | Where-Object { $_.Name -eq 'DhcpServer' }) {
        Import-Module -Name DhcpServer
    }
    else {
        throw "The DhcpServer PowerShell Module is required and is not available."
    }
     
}
 
# Assigning our static variables
 
$ipAddrs = @()
$macAddrs = Get-Content -Path 'C:\Mac.txt'
$domainCreds = Get-Credential -Credential "COMPANY\Administrator"
$localCreds = Get-Credential -Credential "Administrator"
 
# Begin our foreach loop for processing of the MAC addresses and querying DHCP
  
foreach ($macAddr in $macAddrs) {
    try 
    {
        $ipAddrs += Get-DhcpServerv4Lease -ComputerName DCHP1.COMPANY.LOCAL -ScopeId 10.0.0.0 -ClientId $macAddr -ErrorAction Stop
         
    }
    catch [System.Exception] 
    {
        Write-Warning -Message "$($_.Exception.Message)"
    }
}
 
# Begin our foreach loop for processing of the IP Addreses and joining the machine to the domain
 
foreach ($ip in $ipAddrs) {
    try {
        $serverCount = 1
        Add-Computer -ComputerName $($ip.IPAddress.IPAddressToString) -Credential $domainCreds -LocalCredential $localCreds -DomainName COMPANY.LOCAL -NewName $("SERVER" + $serverCount++) -Restart -Force -ErrorAction Stop
    }
 
    catch [System.Exception] {
        Write-Warning -Message "$($_.Exception.Message)"
    }
}

