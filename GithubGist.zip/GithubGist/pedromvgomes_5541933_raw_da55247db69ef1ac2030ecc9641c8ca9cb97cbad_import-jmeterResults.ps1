# This PowerShell scripts loads the JMeter results (XML) into a given database table

Param (
    $provider,
    $connectionString,
    $tableName,
    $inputFile,
    $tag
)

Cls
Write-Host 'JMeter XML Results Importer 1.0'

if ($provider -eq $null -or $connectionString -eq $null -or $tableName -eq $null -or $input -eq $null) {
    Write-Host
    Write-Host 'Syntax Error' -foregroundcolor Red
    Write-Host 'USAGE: import-testresults.ps1 -provider <provider name> -connectionString <connection string> -tableName <table name> -input <file name>.' -foregroundcolor Red
}

# check if input file exists
Write-Progress -id 1 -activity "Importing data" -status "Opening input file" -percentComplete -1

$flag = (Test-Path $inputFile -PathType Leaf)
If (!($flag)) {
    Write-Host
    Write-Host 'Input file not found.' -foregroundcolor Red
    exit
}

Write-Progress -id 1 -activity "Importing data" -status "Opening database connection" -percentComplete -1;

$providerFactory = [System.Data.Common.DbProviderFactories]::GetFactory($provider);
$dbConnection = $providerFactory.CreateConnection()
$dbConnection.ConnectionString = $connectionString
$dbConnection.Open()

$selectCommand = $providerFactory.CreateCommand()
$selectCommand.CommandText = "SELECT RowID, ResultsTag, StartTime, ThreadName, Label, SampleTime, StatusCode, StatusMessage, Bytes, Latency FROM {0}" -f $tableName
$selectCommand.Connection = $dbConnection

$adapter = $providerFactory.CreateDataAdapter()
$adapter.SelectCommand = $selectCommand

$cmdBuilder = $providerFactory.CreateCommandBuilder()
$cmdBuilder.DataAdapter = $adapter

# Get the insert command
$adapter.InsertCommand = $cmdBuilder.GetInsertCommand()
$dataTable = New-Object System.Data.DataTable
$adapter.FillSchema($dataTable, [System.Data.SchemaType]::Mapped);
$dateKindUTC = [System.DateTimeKind]::Utc
$timeStampStart = New-Object -TypeName System.DateTime 1970, 1, 1, 0, 0, 0, 0, $dateKindUTC

#$transaction = $dbConnection.BeginTransaction();
#$adapter.InsertCommand.Transaction = $transaction

$stream = [System.IO.File]::OpenRead($inputFile);
$reader = New-Object System.Xml.XmlTextReader $stream

Write-Progress -id 1 -activity "Importing data" -status "Database data insert" -percentComplete 50

try {
    while ($reader.Read()) {
        if ($reader.NodeType -eq [System.Xml.XmlNodeType]::Element -and ($reader.LocalName -eq "sample" -or $reader.LocalName -eq "httpSample")) {
        
            $newRow = $dataTable.NewRow()
            $newRow.Item("RowID") = [guid]::NewGuid().ToString("N")
            $newRow.Item("ResultsTag") = $tag
        
            $newRow.Item("StartTime") = $timeStampStart.AddMilliseconds([long]$reader.GetAttribute("ts"))
            $newRow.Item("ThreadName") = $reader.GetAttribute("tn")
            $newRow.Item("Label") = $reader.GetAttribute("lb")
            $newRow.Item("SampleTime") = [int]$reader.GetAttribute("t")
            $newRow.Item("StatusCode") = $reader.GetAttribute("rc")
            $newRow.Item("StatusMessage") = $reader.GetAttribute("rm")
            $newRow.Item("Bytes") = [int]$reader.GetAttribute("by")
            $newRow.Item("Latency") = [int]$reader.GetAttribute("lt")
            $dataTable.Rows.Add($newRow)
        }
        
        if ($dataTable.Rows.Count -eq 100) {
            $insertedRows = $adapter.Update($dataTable)
                                 
            # free memory
            $dataTable.Rows.Clear()
            $dataTable.AcceptChanges()
        }
        
        $percentComplete = $stream.Position * 100 / $stream.Length
        Write-Progress -id 1 -activity "Importing data" -status "Database data insert" -percentComplete $percentComplete
    }
    
    $insertedRows = $adapter.Update($dataTable)
    #$transaction.Commit()
    
    Write-Progress -id 1 -activity "Importing data" -status "Database data insert" -Completed
}
catch {
    #$transaction.Rollback()
    
    write-host ("Exception of type {0} thrown" -f $_.Exception.GetType().FullName) -foregroundcolor Red
    write-host $_.Exception.Message -foregroundcolor Red
    exit
}
finally {
    $stream.Dispose()
    $adapter.Dispose()
    $dbConnection.Close()
    $dbConnection.Dispose()
}

