[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web")
function waei($value)
{
    $value = [Web.HttpUtility]::UrlEncode($value)
	ie http://dictionary.goo.ne.jp/srch/je/$value/m0u/
}

