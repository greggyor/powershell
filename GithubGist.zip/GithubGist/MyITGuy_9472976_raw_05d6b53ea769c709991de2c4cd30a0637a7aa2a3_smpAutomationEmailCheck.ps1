[CmdletBinding(SupportsShouldProcess=$True)]
param (
	#SMTP server name
	[string]$smtpServer = "smtp",
	[string]$From,
	#[string]$ReplyTo = "",
	[string]$To,
	[string]$Cc,
	[string]$Subject = "Automation Policies Email Verification",
	[switch]$Export
)
Import-Module SQLPS
Import-Module ActiveDirectory

function sendMail {

	Write-Verbose "Sending email"

	#Creating a Mail object
	Write-Verbose "Creating Net.Mail.MailMessage object"
	$MailMessage = New-Object Net.Mail.MailMessage

	#Creating SMTP server object
	Write-Verbose "Creating Net.Mail.SmtpClient object using: $($smtpServer)"
	$SmtpClient = New-Object Net.Mail.SmtpClient($smtpServer)
	$SmtpClient.UseDefaultCredentials = $true
	#$Credential = Get-Credential
	Write-Verbose "Using credentials: $($Credential.UserName)"
	#$SmtpClient.Credentials = $Credential

	#Email structure
	Write-Verbose "From: $($From)"
	$MailMessage.From = $From
#	Write-Verbose "ReplyTo: $($ReplyTo)"
#	$MailMessage.ReplyTo = $ReplyTo
	Write-Verbose "To: $($To)"
	$MailMessage.To.Add($To)
	Write-Verbose "Cc: $($Cc)"
	$MailMessage.Cc.Add($Cc)
	Write-Verbose "Subject: $($Subject)"
	$MailMessage.Subject = $Subject
	Write-Verbose "Body: $($Body)"
	$MailMessage.Body = "$HTML"
	$MailMessage.IsBodyHTML = $true

	#Sending email
	try {
		$SmtpClient.Send($MailMessage)
	} catch {
		Write-Verbose $_
		return
	}
}

if ($PSBoundParameters['Verbose']) {
    Write-Verbose "Verbose logging enabled"
}

$CurrentLocation = Get-Location

$AutomationPolicies = Invoke-Sqlcmd -ServerInstance "SMP" -Database "Symantec_CMDB" -InputFile "AeX_Show_Automation_Policy_Email_Recipients.sql"

Set-Location $CurrentLocation

$Validators = New-Object -TypeName PSObject
$Validators = @()

foreach ($AutomationPolicy In $AutomationPolicies) {
	$Name = $AutomationPolicy.'Automation Policy'
	$EmailAddresses = @()
	if ($AutomationPolicy.TO_EMAIL -ne $null -and $AutomationPolicy.TO_EMAIL -ne '') {$EmailAddresses += ($AutomationPolicy.TO_EMAIL -split ',' | Where {($EmailAddresses -notcontains $_)})}
	if ($AutomationPolicy.CC_EMAIL -ne $null -and $AutomationPolicy.CC_EMAIL -ne '') {$EmailAddresses += ($AutomationPolicy.CC_EMAIL -split ',' | Where {($EmailAddresses -notcontains $_)})}
	
	$EmailAddressesCount = ($EmailAddresses | Measure).Count
	
	$DiscoveredCount = 0
	$ValidSMTPAddresses = @()
	$InvalidSMTPAddresses = @()
	foreach ($EmailAddress In $EmailAddresses) {
		$EmailAddress = $EmailAddress.Trim()
		if ($EmailAddress.IndexOf('<') -ge 0) {
			# "Test Account" <test@something.local>
			$SMTPAddress = $EmailAddress.Substring($EmailAddress.IndexOf('<') + 1, (($EmailAddress.IndexOf('>')) - ($EmailAddress.IndexOf('<') + 1)))
			Write-Verbose "Using $($SMTPAddress) instead of $($EmailAddress)"
		} else {
			$SMTPAddress = $EmailAddress
		}
		$SMTPAddress = $SMTPAddress -replace ("'", "''")
		Try {
			$ThisCount = (Get-ADObject -Filter "proxyAddresses -eq 'SMTP:$($SMTPAddress)'" | Measure).Count
		} Catch {
			$_
			$ThisCount = 0
		}
		if ($ThisCount -le 0) {
			$InvalidSMTPAddresses += $EmailAddress
		} else {
			$ValidSMTPAddresses += $EmailAddress
			$DiscoveredCount += 1
		}
	}

	$Validator = New-Object -TypeName PSObject -Property @{
		Name			= $Name
		ValidCount		= $DiscoveredCount
		InvalidCount	= ($EmailAddressesCount - $DiscoveredCount)
		ValidSMTP		= $ValidSMTPAddresses -join ','
		InValidSMTP		= $InvalidSMTPAddresses -join ','
	}
	$Validators += $Validator

}

# use a calculated field and set the Ascending attribute to False
$HTML = $Validators | Sort -Property @{Expression = {$_.InvalidCount}; Descending = $true},@{Expression = {$_.ValidCount}; Ascending = $true} | Select Name,InvalidCount,InvalidSMTP,ValidCount,ValidSMTP | ConvertTo-Html -Title "Report" -Head "<style>body {font-family: verdana; font-size: 8pt;}</style>"

if ($Export) {
	$Validators | Sort -Property @{Expression = {$_.InvalidCount}; Descending = $true},@{Expression = {$_.ValidCount}; Ascending = $true} | Select Name,InvalidCount,InvalidSMTP,ValidCount,ValidSMTP | Export-Csv -NoTypeInformation "export.csv"
} else {
	$InvalidCount = ($Validators | Where {$_.InvalidCount -ne 0} | Measure).Count
	if ($InvalidCount -gt 0) {sendMail}
}

