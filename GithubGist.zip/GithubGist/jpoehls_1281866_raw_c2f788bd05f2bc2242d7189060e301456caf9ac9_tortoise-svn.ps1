# Helper function for opening the Tortoise SVN GUI from a PowerShell prompt.
# Put this into your PowerShell profile.
# Ensure Tortoise SVN is in your PATH (usually C:\Program Files\TortoiseSVN\bin).

function Svn-Tortoise([string]$Command = "commit") {
<#
.SYNOPSIS
  Launches TortoiseSVN with the given command.
  Opens the commit screen if no command is given.
  
  List of supported commands can be found at:
  http://tortoisesvn.net/docs/release/TortoiseSVN_en/tsvn-automation.html
#>
  TortoiseProc.exe /command:$Command /path:"$pwd"
}
Set-Alias tsvn "Svn-Tortoise"

