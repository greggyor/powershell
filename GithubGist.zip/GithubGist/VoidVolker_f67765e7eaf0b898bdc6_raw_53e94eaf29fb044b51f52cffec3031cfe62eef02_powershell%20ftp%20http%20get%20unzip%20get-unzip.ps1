# Download the file to a specific location
# get-unzip.ps1 "ftp://path/filename" "C:\path" "filename"
$clnt = new-object System.Net.WebClient
$url = $args[0]
$folder = $args[1]
$file = $args[2]
$path = $($args[1]+"\"+$args[2])
$clnt.DownloadFile($url,$path)

# Unzip the file to specified location
$shell_app=new-object -com shell.application
$zip_file = $shell_app.namespace($path)
$destination = $shell_app.namespace($folder)
$destination.Copyhere($zip_file.items())

