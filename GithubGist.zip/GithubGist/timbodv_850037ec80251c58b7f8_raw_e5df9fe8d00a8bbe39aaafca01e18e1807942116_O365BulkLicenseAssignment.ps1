# get a list of licenses and plans
Get-MsolAccountSku | foreach { Write-Output "$($_.AccountSkuId)"; foreach ($status in $_.ServiceStatus) { Write-Output $status } }

# example to modify a user
$license = New-MsolLicenseOptions -AccountSkuId "tenant:STANDARDPACK" -DisabledPlans "MCOSTANDARD,EXCHANGE_S_STANDARD"
(Get-MsolUser)[1] | Set-MsolUserLicense -AddLicenses "tenant:STANDARDPACK"
(Get-MsolUser)[1] | Set-MsolUserLicense -LicenseOptions $license


