#REQUIRES -Version 2.0

<#
.SYNOPSIS
Convert non-ascii Replays.info files to ascii so that they can be read by the game

.DESCRIPTION
When you enter "Replays" from the main menu a file called "Replays.info" will be populated with data about replays.
In the occurence of unicode or other non-ascii character it will fail to parse data and the replay will not show up in game. The solution is to remove these characters from individual replays in order for them to display properly. The purpose of this script is to automate this process.

.NOTES
This script needs to be put in the Data\Replays folder.
Use at your own risk. Consider backing up you Replays-folder before running.

.LINK
www.awesomenauts.com
#>

# Determine path and set location
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
Set-Location $dir

# Are we in the right folder?
if(-not(Test-Path -Path .\Replays.info)) {
  Read-Host 'Put me in the Replay folder!' | Out-Null
  exit
}

# All replays
$replays = (Get-ChildItem | ?{ $_.PSIsContainer } | % {$_.Name})

# Working replays
[xml]$xml = Get-Content .\Replays.info
$xml_replays = ($xml.SelectNodes("/Replays/Replay") | % {$_.Filename})

# Loop over replays
# If they do not show up in game, make a backup of the "Replays.info" file and create a new one.
$i = 0
foreach ($replay in $replays) {
  $info = "$replay\Replays.info"
  if ($xml_replays -notcontains $replay -and (Test-Path -Path "$info")) {
    # make sure its an individual replay and not a backed up 'Replay'-folder
    $single = ([xml] (Get-Content "$info")).Replay
    if ($single) {
      # if user runs script twice before visiting the Replay menu
      if (Test-Path -Path "${info}.bak") { continue }
      Move-Item -Path "$info" -Destination "${info}.bak"
      Get-Content "${info}.bak" | Out-File -FilePath "$info" -Encoding ASCII
      $i++
    }
  }
}

Read-Host "Fixed $i replay(s)" | Out-Null


