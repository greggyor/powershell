#删除sth目录下文件
git rm sth/* -r
#然后commit
git commit -a -m 'remove sth'
#再次push就可以了
git push -u origin master
#可以增加忽略文件:
vim .gitignore
#在文件中添加
sth/**/*

