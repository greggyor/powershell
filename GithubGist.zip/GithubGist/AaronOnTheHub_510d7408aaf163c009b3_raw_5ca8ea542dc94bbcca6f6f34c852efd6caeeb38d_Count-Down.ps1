##############################################################################
#.SYNOPSIS
# A count down.
#
#.DESCRIPTION
# Counts down from a number to zero, displaying the current step, with the 
# ability to control mucho.
#
#.PARAMETER startMessage
# Output prior to beginning of the countdown. Defaults to empty string.
#
#.PARAMETER completeMessage
# Output upon completion of the countdown. Defaults to empty string.
#
#.PARAMETER stepSleepMilliseconds
# Defaults to 250. How long (in milliseconds) to wait between steps.
#
#.PARAMETER stepCount
# The number to count down from. Defaults to 10. 
#
#.PARAMETER endSleepMilliseconds
# Defaults to 0. If given a value, the function will wait for the specified 
# number of milliseconds before returning flow back to the caller.
#
#.EXAMPLE 
# Count-Down -startMessage "Here we go" -completedMessage "All done" -stepSleepMilliseconds 1000 -stepCount 5 -endSleepMilliseconds 3
##############################################################################
function Count-Down {
    param (
    [string]$startMessage = "", 
    [string]$completeMessage = "", 
    [int]$stepSleepMilliseconds = 250, 
    [int]$stepCount = 10,
    [int]$endSleepMilliseconds = 0)
    
    if ($startMessage.Length -gt 0) {
        Write-Host $startMessage;
    };
    $currentStep = $stepCount;
    while ($currentStep -gt 0) {
        Start-Sleep -Milliseconds $stepSleepMilliseconds;
        Write-Host "$currentStep... " -NoNewline;
        $currentStep--;
    };
    if ($stepSleepMilliseconds -gt 0) {
        Start-Sleep -Milliseconds $endSleepMilliseconds;
        if ($completeMessage.Length -gt 0) {
            Write-Host $completeMessage -NoNewline;
        };
        Write-Host "";
    }
};
