param(
[String]$filePath="",
[String]$fileName=""
)

$encoderDirectory = "c:\temp\done"
$encoder = "C:\temp\done\sample.bat"
$extension = "*.jnt"

Function StripChar($s)
{
  $s.replace(" ","_").replace(",","_").replace("~","_").replace("#", "_")
}

Function MoveFile($filePath, $fileName)
{
  $newPath = "${encoderDirectory}\${fileName}"
  [System.IO.File]::Move($filePath, $newPath)
}

Function StartEncoding($fileName) {
  Start-Process $encoder $fileName
}

if($fileName -and $filePath)
{
  $fileFullName = "${filePath}\${fileName}"
  $fixedFileName = StripChar $fileName
  MoveFile $fileFullName $fixedFileName
  $encoderPath = "${encoderDirectory}\${fixedFileName}"
  StartEncoding $encoderPath
}

