########################################################################
# AWS EC2 Windows Bootstrapping Script 
# Supported OS: 
#    - Windows 2008 Server R2 SP1 (TESTED)
#    - Windows 2008 Server (TO BE TESTED)
#    - Windows 2012 Server (TO BE TESTED)

# Image Transformation Target Cloud
#    - Openstack
#
# Coppyright (c) 2014, CliQr Technologies, Inc. All rights reserved.
########################################################################


