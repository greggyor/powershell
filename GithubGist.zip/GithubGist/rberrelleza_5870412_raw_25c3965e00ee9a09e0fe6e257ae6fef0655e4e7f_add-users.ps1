$domain = (get-addomain).distinguishedname
$location = "OU=Engineering,$domain"
$domain_email = 'yourdomain.com'
$i = 0
Get-Content .\names.csv.txt | ForEach {
  $i++
  $names = $_.Split()
  $first = $names[0]
  $last = $names[1]
  $username = "$first" + "." + "$last"
  $email = "$username" + $domain_email
  $password =  ConvertTo-SecureString -AsPlainText "somethingG00D!" -force
  $sam = $first + '.' + $last
  New-ADUser $sam -AccountPassword $password -EmailAddress $email -UserPrincipalName $email -Enabled $true -GivenName $first -Surname $last

  $dn  = (Get-ADUser $sam).DistinguishedName 
  Move-ADObject -Identity $dn -TargetPath $location 
    
  $i.ToString() + ") Name: " + $dn 
}

