# Assumes that $appPoolName is set to the name of the application pool you want to modify. For example:
#
#   $appPoolName = "DefaultAppPool"
#   $appPoolName = $OctopusParameters["YourVariable"]

Import-Module WebAdministration
$appPoolStatus = Get-WebAppPoolState $appPoolName

if ($appPoolStatus.Value -eq "Stopped")
{
    Write-Host "Service is already stopped"
}
else
{
    Stop-WebAppPool $appPoolName
    Write-Host "Application pool is stopped"
}


