﻿#############################################################################
# New-UserAD and Email
# Create email and AD Account for new Users in Contoso.com
# Rahmatullah Fedayizada
# CIS Assistant
# Mobile: 0796660969
# Email: rahmat_fedayizada@hotmail.com
# ============================================================================


$date = Get-Date
#Set up Log files for output
$ErrorLog = "C:\Errorlog.txt"
$SuccessLog = "C:\Successlog.txt"
Add-Content $SuccessLog "-----------------------------------------------------------------"
Add-Content $SuccessLog $date
Add-Content $SuccessLog "-----------------------------------------------------------------"
Add-Content $ErrorLog "-------------------------------------------------------------------"
Add-Content $ErrorLog $date
Add-Content $ErrorLog "-------------------------------------------------------------------"

## Create Session with Exchange 2010 change your URI address 
$s=New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://contoso/powershell -Authentication Kerberos

Import-PSSession -Session $s
## Add AD Cmdlets
Import-Module ActiveDirectory
#Import CSV 

$csv = @() 
$csv = Import-Csv -Delimiter "," -Path "C:\ADuser.csv"
#Get Domain Base 
$searchbase = Get-ADDomain | ForEach {  $_.DistinguishedName } 
 
#Loop through all items in the CSV 
ForEach ($user In $csv) 
{ 

    ## change your OU with your own OU
    $OU = "OU=New Users,OU=Users,OU=employee,DC=Contoso,DC=com"  
    $Password = "Userlogin1"
    $title= $user.'New Post title'
    $lastname= ($user.'Last name'.Substring(0,1).toupper() + $User.'Last name'.Substring(1).tolower())
    $Detailedname = $User.'First name' + " " + $lastname 
    $UserFirstname = $User.'First name'  
    $SAM =  $User.'First name' + "." +  $lastname
    $UPN= $UserFirstname + "." +  $lastname + "@contoso.com"
    $ID= $user.ID
	$Displayname= "$Detailedname" + "  " + "-" + "  " + "$title"
	$Company= "Contoso"
    $Dis= "EUPOL User"
    $group= "All Users","AllInternational Users"
    $homedrive= "\\contoso-nas1\home\%username%"
    

  #Check if the User exists 
  $NameID = $user.ID
$User = Get-ADUser -LDAPFilter "(EmployeeID=$NameID)"
If ($User -eq $Null) 

    { 
      #Create the User if it doesn't exist 
      
      
      $create = New-ADUser -Name $Detailedname -SamAccountName $SAM -UserPrincipalName $UPN  -DisplayName $Displayname -GivenName $UserFirstname -Surname $lastname -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) -Enabled $true -Path $OU -EmployeeID $ID -Title $title -Description $Dis -Company $Company -HomeDrive Z: -HomeDirectory $homedrive -ChangePasswordAtLogon $true 
      
      Write-Host "AD Account $Detailedname created!" 
      
      add-content $SuccessLog  "User $SAM created Sucessfully."

   

      ## Adding User to Group
      Add-ADPrincipalGroupMembership -Identity $SAM -MemberOf $group
      
      Write-Host " Added to Groups Needed" 
      
      add-content $SuccessLog  "AD User $SAM Added to groups Sucessfully."
      Write-Host -ForegroundColor Green $SAM

      ## Creating Mailbox on EX2010
     Enable-Mailbox -Identity $SAM -Alias $SAM

 
 #Creating a Mail object
$outlook = new-object -ComObject Outlook.Application

## Create new mail
$mail = $outlook.CreateItem(0)

#Email structure 

$subject = "New User Information "
$mail.Recipients.Add("admin.it@contoso.com")
$mail.subject = $subject
$mail.body = ("Hello All," + "`r`n" + "`r`n" + "New User Information" + "`r`n" + "First Name :" + "  " + $UserFirstname + "`r`n" + "Last Name :" + "  " + $lastname +"`r`n" + "EUPOL ID# :" + "  " + $ID + "`r`n" + "Position :" + " " + $title + "`r`n" + "AD Account Created" + "`r`n" + "Thank you" + "`r`n" + " Rahmatullah Fedayizada" ) 
#Sending email 
$mail.Send()


Write-Host "Email sent to Admin.it"
    
Add-Content -Path $SuccessLog -Value "Email has been sent to Admin.it "

Add-Content $SuccessLog "-------------------------------------------------------------------"
## Dis Account###

Disable-ADAccount -Identity $SAM

}
Else

      {add-content $ErrorLog " User Already exist : $Detailedname"
      
      Add-Content $ErrorLog "-------------------------------------------------------------------"
  
      
      }
      

 }