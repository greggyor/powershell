﻿#========================================================================
# Created on:   02/01/2012
# Created by:   AUGAGNEUR Alexandre 
# Filename:     AD-Schema_Discover-1.0.ps1
# Description:	GUI to discover Active Directory schema details
#========================================================================


#----------------------------------------------
#region Application Functions
#----------------------------------------------

function OnApplicationLoad {
	
	return $true
}

function OnApplicationExit {
	
	$script:ExitCode = 0
}

#endregion Application Functions

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Call-AD-Schema_Analyzer_pff {

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formADSchemaDiscover10 = New-Object 'System.Windows.Forms.Form'
	$groupbox5 = New-Object 'System.Windows.Forms.GroupBox'
	$labelFile = New-Object 'System.Windows.Forms.Label'
	$buttonBrowse = New-Object 'System.Windows.Forms.Button'
	$lbCsvFile = New-Object 'System.Windows.Forms.Label'
	$linklabelDownloadCSVFile = New-Object 'System.Windows.Forms.LinkLabel'
	$labelVariousInformation = New-Object 'System.Windows.Forms.Label'
	$labelAttributesGroupedPer = New-Object 'System.Windows.Forms.Label'
	$groupbox4 = New-Object 'System.Windows.Forms.GroupBox'
	$rbTargetForest = New-Object 'System.Windows.Forms.RadioButton'
	$rbCurrentForest = New-Object 'System.Windows.Forms.RadioButton'
	$tbForestName = New-Object 'System.Windows.Forms.TextBox'
	$buttonConnect = New-Object 'System.Windows.Forms.Button'
	$panel1 = New-Object 'System.Windows.Forms.Panel'
	$labelSchemaCreationDateValue = New-Object 'System.Windows.Forms.Label'
	$labelADSchemaValue = New-Object 'System.Windows.Forms.Label'
	$labelExchangeSchemaValue = New-Object 'System.Windows.Forms.Label'
	$labelLyncSchemaValue = New-Object 'System.Windows.Forms.Label'
	$labelSchemaObjectsValue = New-Object 'System.Windows.Forms.Label'
	$labelSchemaObjectsUnkValue = New-Object 'System.Windows.Forms.Label'
	$labelSchemaCreationDate = New-Object 'System.Windows.Forms.Label'
	$labelSchemaObjectsUnknown = New-Object 'System.Windows.Forms.Label'
	$labelSchemaObjects = New-Object 'System.Windows.Forms.Label'
	$labelLyncSchema = New-Object 'System.Windows.Forms.Label'
	$labelExchangeSchema = New-Object 'System.Windows.Forms.Label'
	$labelADSchema = New-Object 'System.Windows.Forms.Label'
	$dgvSchemaDates = New-Object 'System.Windows.Forms.DataGridView'
	$groupbox1 = New-Object 'System.Windows.Forms.GroupBox'
	$buttonExport = New-Object 'System.Windows.Forms.Button'
	$dgvSchema = New-Object 'System.Windows.Forms.DataGridView'
	$Name = New-Object 'System.Windows.Forms.DataGridViewTextBoxColumn'
	$WhenCreated = New-Object 'System.Windows.Forms.DataGridViewTextBoxColumn'
	$ProvidedFor = New-Object 'System.Windows.Forms.DataGridViewTextBoxColumn'
	$openfiledialog1 = New-Object 'System.Windows.Forms.OpenFileDialog'
	$imagelistAnimation = New-Object 'System.Windows.Forms.ImageList'
	$timerCheckJob = New-Object 'System.Windows.Forms.Timer'
	$Date = New-Object 'System.Windows.Forms.DataGridViewTextBoxColumn'
	$Count = New-Object 'System.Windows.Forms.DataGridViewTextBoxColumn'
	$savefiledialog1 = New-Object 'System.Windows.Forms.SaveFileDialog'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	# List of AD Schema versions
	$script:SchemaHashAD = @{
		13="Windows 2000 Server";
		30="Windows Server 2003";
		31="Windows Server 2003 R2";
		44="Windows Server 2008";
		47="Windows Server 2008 R2";
		56="Windows Server 2012"
	}
	
	# List of Exchange Schema versions
	$script:SchemaHashExchange = @{
		4397="Exchange Server 2000";
		4406="Exchange Server 2000 SP3";
		6870="Exchange Server 2003";
		6936="Exchange Server 2003 SP3";
		10628="Exchange Server 2007";
		10637="Exchange Server 2007";
		11116="Exchange Server 2007 SP1";
		14622="Exchange Server 2007 SP2 or Exchange Server 2010";
		14726="Exchange Server 2010 SP1";
		14732="Exchange Server 2010 SP2";
		15137="Exchange Server 2013"
	}
	
	# List of Lync Schema versions
	$script:SchemaHashLync = @{
		1006="LCS 2005";
		1007="OCS 2007 R1";
		1008="OCS 2007 R2";
		1100="Lync Server 2010";
		1150="Lync Server 2013"
	}
	
	# List columns required for the CSV file
	$script:DefaultColumns = @('Name','CreatedBy')
	
	# Function retrieving and formatting schema data
	function Get-SchemaData
	{	
		# Retrieve schema
		$ADSearcher = New-Object System.DirectoryServices.DirectorySearcher
		$ADSearcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry($script:Forest.Schema.GetDirectoryEntry().Path)
		$ADSearcher.PageSize = 10000
		$ADSearcher.SearchScope = "Subtree"
	
		$SchemaProperties = @("name","whencreated")
	
		$ADSearcher.PropertiesToLoad.Clear()
		$ADSearcher.PropertiesToLoad.AddRange(@($SchemaProperties))
	
		$script:ADSchema = $ADSearcher.FindAll()
	
		$script:selectedProperties = $SchemaProperties | ForEach-Object {@{name="$_";expression=$ExecutionContext.InvokeCommand.NewScriptBlock("`$_['$_']")}}
		
		$script:Result = @()
	
		# Check Exchange schema extension and version
		try
		{
			$ExchangeVersion = "LDAP://CN=ms-Exch-Schema-Version-Pt,"+$forest.Schema.GetDirectoryEntry().distinguishedName
					
			if ( $script:SchemaHashExchange.ContainsKey($(([ADSI] $ExchangeVersion).rangeUpper)) )
			{
				$labelExchangeSchemaValue.Text = $script:SchemaHashExchange[$(([ADSI] $ExchangeVersion).rangeUpper)]
			}
			else
			{
				$labelExchangeSchemaValue.Text = "Unknown"
			}
		}
		catch
		{
			$labelExchangeSchemaValue.Text = "Not Found"
		}
		
		# Check Lync schema extension and version
		try
		{
			$LyncVersion = "LDAP://CN=ms-RTC-SIP-SchemaVersion,"+$forest.Schema.GetDirectoryEntry().distinguishedName


			if ( $script:SchemaHashLync.ContainsKey($(([ADSI] $LyncVersion).rangeUpper)) )
			{
				$labelLyncSchemaValue.Text = $script:SchemaHashLync[$(([ADSI] $LyncVersion).rangeUpper)]
			}
			else
			{
				$labelLyncSchemaValue.Text = "Unknown"
			}
		}
		catch
		{
			$labelLyncSchemaValue.Text = "Not Found"
		}
		
		# Retrieve AD schema version
		if ( $script:SchemaHashAD.ContainsKey($($Forest.Schema.GetDirectoryEntry().ObjectVersion)) )
		{
			$labelADSchemaValue.Text = $script:SchemaHashAD[$($Forest.Schema.GetDirectoryEntry().ObjectVersion)]
		}
		else
		{
			$labelADSchemaValue.Text = "Unknown"
		}
		
		# treatment of schema objects
		foreach ( $Object in $script:ADSchema )
		{
			# Specific treatment of "Schema" object
			if ( $Object.Properties["name"] -eq "Schema" )
			{
				$script:SchemaDateCreation = ($Object.Properties | Select-Object -Property $script:selectedProperties | Select-Object WhenCreated).WhenCreated 
				$labelSchemaCreationDateValue.Text = $script:SchemaDateCreation
			}
			else
			{
				# Check if CSV file is provided
				if ( $script:CsvFile )
				{
					$script:Result += $Object.Properties | Select-Object -Property $script:selectedProperties | Select-Object "name",@{Name="WhenCreated";Expression={ if ($_.WhenCreated -lt $script:SchemaDateCreation) { Get-Date $script:SchemaDateCreation -Format "yyyy/MM/dd" }else{ Get-Date $_.WhenCreated -Format "yyyy/MM/dd" }}},@{Name="ProvidedFor";Expression={ if ( $_.Name -like "Microsoft-Com-1991-Air-*") {"Mobile Information Server 2001"}else{ if ($script:htAttributes.ContainsKey($_.Name)) { $script:htAttributes[$_.Name] }else{ "Unknown"; $script:ObjectsUnknown++}}}}
				}
				else
				{
					$script:Result += $Object.Properties | Select-Object -Property $script:selectedProperties | Select-Object "name",@{Name="WhenCreated";Expression={ if ($_.WhenCreated -lt $script:SchemaDateCreation) { Get-Date $script:SchemaDateCreation -Format "yyyy/MM/dd" }else{ Get-Date $_.WhenCreated -Format "yyyy/MM/dd" }}},@{Name="ProvidedFor";Expression={ if ( $_.Name -like "Microsoft-Com-1991-Air-*") {"Mobile Information Server 2001"}else{"Unknown (No CSV File specified)"; $script:ObjectsUnknown++}}}
				}
			}
		}
		
		# Fill the dataGridView
		if ( $script:Result )
		{
			# Retrieve number of schema objects
			$labelSchemaObjectsValue.Text = $script:Result.Count
			
			foreach ( $Line in $script:Result )
			{
				$dgvSchema.Rows.Add($Line.Name,$Line.WhenCreated,$Line.ProvidedFor)
			}
			
			$script:dgvFilled = $true
			$buttonExport.Enabled = $true
		}
		
		# Retrieve number of unknown objects
		$labelSchemaObjectsUnkValue.Text = $script:ObjectsUnknown
		
		# Fill dataGridView with the objects grouped by date
		$script:Result | select name,@{Label="Date";Expression={Get-Date $_.WhenCreated -Format "yyyy/MM/dd"}} | Sort Date | group-object Date | select count,Name | %{ $dgvSchemaDates.Rows.Add($_.Name,$_.Count)}
	}
	
	#$formADSchemaAnalyzer10_Load={
	#	#TODO: Initialize Form Controls here
	#	
	#}
	
	$buttonConnect_Click={
		
		$script:ObjectsUnknown = 0
		$formADSchemaDiscover10.Cursor = 'WaitCursor'
		
		# Manage connect/disconnect
		if ( !($Connected) )
		{
			try
			{
				if ( $rbCurrentForest.Checked )
				{
					$script:Forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
				}
				else
				{
					$script:Context = new-object System.directoryServices.ActiveDirectory.DirectoryContext("Forest",$tbForestName.Text.ToString())
					$script:Forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetForest($script:Context)
				}
				
				$rbCurrentForest.Enabled = $false
				$rbTargetForest.Enabled = $false
				$tbForestName.Text = $script:Forest.Name
				$tbForestName.Enabled = $true
				$tbForestName.ReadOnly = $true
				$buttonConnect.Text = "Disconnect"
				$Connected = $true
				
				Get-SchemaData
			}
			catch
			{
				[System.Windows.Forms.MessageBox]::Show("$($_.Exception.Message)","AD Schema Analyzer",[Windows.Forms.MessageBoxButtons]::OK,[windows.forms.MessageBoxIcon]::Error)
				$formADSchemaDiscover10.Cursor = 'Default'
			}
		}
		# Reset all
		else
		{
			$dgvSchema.Rows.Clear()
			$dgvSchemaDates.Rows.Clear()
			$rbCurrentForest.Enabled = $true
			$rbTargetForest.Enabled = $true
			$tbForestName.Text = $null
			$tbForestName.ReadOnly = $false
			
			if ( $rbCurrentForest.Checked )
			{
				$tbForestName.Enabled = $false
			}
			
			$buttonConnect.Text = "Connect"
			$buttonExport.Enabled = $false
			
			$labelADSchemaValue.Text = $null
			$labelExchangeSchemaValue.Text = $null
			$labelLyncSchemaValue.Text = $null
			$labelSchemaObjectsUnkValue.Text = $null
			$labelSchemaCreationDateValue.Text = $null
			$labelSchemaObjectsValue.Text = $null
			$Connected = $false
		}

		$formADSchemaDiscover10.Cursor = 'Default'
	}
	
	#region Control Helper Functions
	function Load-DataGridView
	{
		<#
		.SYNOPSIS
			This functions helps you load items into a DataGridView.
	
		.DESCRIPTION
			Use this function to dynamically load items into the DataGridView control.
	
		.PARAMETER  DataGridView
			The ComboBox control you want to add items to.
	
		.PARAMETER  Item
			The object or objects you wish to load into the ComboBox's items collection.
		
		.PARAMETER  DataMember
			Sets the name of the list or table in the data source for which the DataGridView is displaying data.
	
		#>
		Param (
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.DataGridView]$DataGridView,
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			$Item,
		    [Parameter(Mandatory=$false)]
			[string]$DataMember
		)
		$DataGridView.SuspendLayout()
		$DataGridView.DataMember = $DataMember
		
		if ($Item -is [System.ComponentModel.IListSource]`
		-or $Item -is [System.ComponentModel.IBindingList] -or $Item -is [System.ComponentModel.IBindingListView] )
		{
			$DataGridView.DataSource = $Item
		}
		else
		{
			$array = New-Object System.Collections.ArrayList
			
			if ($Item -is [System.Collections.IList])
			{
				$array.AddRange($Item)
			}
			else
			{	
				$array.Add($Item)	
			}
			$DataGridView.DataSource = $array
		}
		
		$DataGridView.ResumeLayout()
	}#endregion
	
	$rbCurrentForest_CheckedChanged={
		$tbForestName.Enabled = $false
	}
	
	$rbTargetForest_CheckedChanged={
		$tbForestName.Enabled = $true
	}
	
	# Load CSV File on event "FileOk"
	$openfiledialog1_FileOk=[System.ComponentModel.CancelEventHandler]{
	
		if ($openfiledialog1.FileName)
		{
			$jobScript = { 
					$CSV = Import-Csv $args[0] -Delimiter ";"
					return $CSV
				}
		
			try
			{
				$script:job = Start-Job -ScriptBlock $jobScript -ArgumentList $openfiledialog1.FileName
				
				$buttonBrowse.Enabled = $false	
				$buttonBrowse.Text = "Loading..."
				$buttonBrowse.ImageIndex = 0
				$timerCheckJob.Tag = $script:job
				$timerCheckJob.Start()
			}
			catch [Exception]
			{
				Write-Debug $_
				$buttonBrowse.ImageIndex = -1
				$buttonBrowse.Enabled = $true
				$buttonBrowse.Visible = $true
				$timerCheckJob.Tag = $null
				$timerCheckJob.Stop()
			}
		}
	}
	
	$buttonBrowse_Click={
		$openfiledialog1.Title = "Select file..."
		$openfiledialog1.InitialDirectory = [System.Environment]::GetFolderPath("MyDocuments")
	 	$openfiledialog1.RestoreDirectory = $True
		$openfiledialog1.FileName = $null
		$openfiledialog1.Filter = "CSV (*.csv)|*.csv"
		$openfiledialog1.ShowDialog()
	}
	
	$timerCheckJob_Tick={
		#Check if the process stopped
		if($timerCheckJob.Tag -ne $null)
		{		
			if($timerCheckJob.Tag.State -ne 'Running')
			{
				#Stop the Timer
				$buttonBrowse.ImageIndex = -1
				$buttonBrowse.Text = "Browse"
				$buttonBrowse.Enabled = $true
				$buttonBrowse.Visible = $true
				$timerCheckJob.Tag = $null
				$timerCheckJob.Stop()
				
				$script:CsvFile = Receive-Job -Job $script:job
			
				# Return error on file empty
				if ( !($script:CsvFile) )
				{
					[void][System.Windows.Forms.MessageBox]::Show("File content is empty.","CSV File",[Windows.Forms.MessageBoxButtons]::OK,[windows.forms.MessageBoxIcon]::Error)
				}
				else
				{
					# Check the format of the file
					$CSVColumns = @()
					$script:CsvFile | Get-Member -MemberType NoteProperty | %{ $CSVColumns += $_.Name }
			
					$MissingColumns = Compare-Object $CSVColumns $script:DefaultColumns | Where-Object { $_.SideIndicator -eq "=>" } | Select-Object InputObject
					
					if ($MissingColumns)
					{
						foreach ( $Item in $MissingColumns )
						{
							$CSVErrorMsg += "Column '$($Item.InputObject)' not found.`n"
						}
						
						[void][System.Windows.Forms.MessageBox]::Show($CSVErrorMsg,"CSV File Validation",[Windows.Forms.MessageBoxButtons]::OK,[windows.forms.MessageBoxIcon]::Error)
						$CSVErrorMsg = $null
					}
					else
					{
						$formADSchemaDiscover10.Cursor = 'WaitCursor'
						$lbCsvFile.Font = "Segoe UI, 8.25pt"
						$lbCsvFile.Text = $openfiledialog1.FileName
					
						$script:htAttributes = @{}
						
						# Construct a hashtable based on the CSV file
						foreach ( $Item in $CSVFile )
						{
							$script:htAttributes[$Item.Name] = $Item.CreatedBy
						}
						
						$script:Result = @()
						
						# Fill the datagridview if already connected
						if ( ($Connected) -and ($script:dgvFilled) )
						{
							$dgvSchema.Rows.Clear()
							$script:ObjectsUnknown = 0
							
							foreach ( $Object in $script:ADSchema )
							{
								if ( $Object.Properties["name"] -ne "Schema" )
								{
									$script:Result += $Object.Properties | Select-Object -Property $script:selectedProperties | Select-Object "name",@{Name="WhenCreated";Expression={ if ($_.WhenCreated -lt $script:SchemaDateCreation) { Get-Date $script:SchemaDateCreation -Format "yyyy/MM/dd" }else{ Get-Date $_.WhenCreated -Format "yyyy/MM/dd" }}},@{Name="ProvidedFor";Expression={ if ( $_.Name -like "Microsoft-Com-1991-Air-*") {"Mobile Information Server 2001"}else{ if ($script:htAttributes.ContainsKey($_.Name)) { $script:htAttributes[$_.Name] }else{ "Unknown"; $script:ObjectsUnknown++}}}}
								}
							}	
							
							foreach ( $Line in $script:Result )
							{
								$dgvSchema.Rows.Add($Line.Name,$Line.WhenCreated,$Line.ProvidedFor)
							}
						
							# Retrieve number of schema objects
							$labelSchemaObjectsValue.Text = $script:Result.Count
						
							# Retrieve number of unknown objects
							$labelSchemaObjectsUnkValue.Text = $script:ObjectsUnknown
						}

						$formADSchemaDiscover10.Cursor = 'Default'
					}
				}
			}
			else
			{
				if($buttonBrowse.ImageIndex -lt $buttonBrowse.ImageList.Images.Count - 1)
				{
					$buttonBrowse.ImageIndex += 1
				}
				else
				{
					$buttonBrowse.ImageIndex = 0		
				}
			}
		}
	}
	
	$linklabelDownloadCSVFile_LinkClicked=[System.Windows.Forms.LinkLabelLinkClickedEventHandler]{
		[System.Diagnostics.Process]::Start("http://www.alexwinner.com/downloads/finish/3/8.html")
	}
	
	$buttonExport_Click={
		$savefiledialog1.Title = "Export to file..."
		$savefiledialog1.InitialDirectory = [System.Environment]::GetFolderPath("MyDocuments")
		$savefiledialog1.DefaultExt = "csv"
		$savefiledialog1.Filter = "CSV (*.csv)|*.csv"
	 	$savefiledialog1.RestoreDirectory = $True
		$savefiledialog1.ShowDialog()
	}
	
	$savefiledialog1_FileOk=[System.ComponentModel.CancelEventHandler]{
		$script:Result | Export-Csv $savefiledialog1.FileName -NoTypeInformation -Force
	}
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formADSchemaDiscover10.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonBrowse.remove_Click($buttonBrowse_Click)
			$linklabelDownloadCSVFile.remove_LinkClicked($linklabelDownloadCSVFile_LinkClicked)
			$rbTargetForest.remove_CheckedChanged($rbTargetForest_CheckedChanged)
			$rbCurrentForest.remove_CheckedChanged($rbCurrentForest_CheckedChanged)
			$buttonConnect.remove_Click($buttonConnect_Click)
			$buttonExport.remove_Click($buttonExport_Click)
			$openfiledialog1.remove_FileOk($openfiledialog1_FileOk)
			$timerCheckJob.remove_Tick($timerCheckJob_Tick)
			$savefiledialog1.remove_FileOk($savefiledialog1_FileOk)
			$formADSchemaDiscover10.remove_Load($Form_StateCorrection_Load)
			$formADSchemaDiscover10.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	#
	# formADSchemaDiscover10
	#
	$formADSchemaDiscover10.Controls.Add($groupbox5)
	$formADSchemaDiscover10.Controls.Add($labelVariousInformation)
	$formADSchemaDiscover10.Controls.Add($labelAttributesGroupedPer)
	$formADSchemaDiscover10.Controls.Add($groupbox4)
	$formADSchemaDiscover10.Controls.Add($panel1)
	$formADSchemaDiscover10.Controls.Add($dgvSchemaDates)
	$formADSchemaDiscover10.Controls.Add($groupbox1)
	$formADSchemaDiscover10.ClientSize = '733, 720'
	$formADSchemaDiscover10.FormBorderStyle = 'FixedSingle'
	$formADSchemaDiscover10.MaximizeBox = $False
	$formADSchemaDiscover10.Name = "formADSchemaDiscover10"
	$formADSchemaDiscover10.StartPosition = 'CenterScreen'
	$formADSchemaDiscover10.Text = "AD Schema Discover 1.0"
	#
	# groupbox5
	#
	$groupbox5.Controls.Add($labelFile)
	$groupbox5.Controls.Add($buttonBrowse)
	$groupbox5.Controls.Add($lbCsvFile)
	$groupbox5.Controls.Add($linklabelDownloadCSVFile)
	$groupbox5.Location = '10, 5'
	$groupbox5.Name = "groupbox5"
	$groupbox5.Size = '716, 47'
	$groupbox5.TabIndex = 47
	$groupbox5.TabStop = $False
	#
	# labelFile
	#
	$labelFile.Font = "Segoe UI, 8.25pt"
	$labelFile.Location = '12, 14'
	$labelFile.Name = "labelFile"
	$labelFile.Size = '55, 22'
	$labelFile.TabIndex = 29
	$labelFile.Text = "File:"
	$labelFile.TextAlign = 'MiddleLeft'
	#
	# buttonBrowse
	#
	$buttonBrowse.Font = "Segoe UI, 8.25pt"
	$buttonBrowse.ImageList = $imagelistAnimation
	$buttonBrowse.Location = '486, 14'
	$buttonBrowse.Name = "buttonBrowse"
	$buttonBrowse.Size = '88, 22'
	$buttonBrowse.TabIndex = 0
	$buttonBrowse.Text = "Browse"
	$buttonBrowse.TextImageRelation = 'ImageBeforeText'
	$buttonBrowse.UseVisualStyleBackColor = $True
	$buttonBrowse.add_Click($buttonBrowse_Click)
	#
	# lbCsvFile
	#
	$lbCsvFile.BackColor = 'InactiveBorder'
	$lbCsvFile.BorderStyle = 'Fixed3D'
	$lbCsvFile.Font = "Segoe UI, 8.25pt, style=Italic"
	$lbCsvFile.Location = '73, 14'
	$lbCsvFile.Name = "lbCsvFile"
	$lbCsvFile.Size = '407, 22'
	$lbCsvFile.TabIndex = 27
	$lbCsvFile.Text = "Specify a CSV File to map schema objects with MS Products"
	$lbCsvFile.TextAlign = 'MiddleCenter'
	#
	# linklabelDownloadCSVFile
	#
	$linklabelDownloadCSVFile.Font = "Segoe UI, 8.25pt"
	$linklabelDownloadCSVFile.Location = '580, 19'
	$linklabelDownloadCSVFile.Name = "linklabelDownloadCSVFile"
	$linklabelDownloadCSVFile.Size = '131, 16'
	$linklabelDownloadCSVFile.TabIndex = 28
	$linklabelDownloadCSVFile.TabStop = $True
	$linklabelDownloadCSVFile.Text = "Download CSV file"
	$linklabelDownloadCSVFile.add_LinkClicked($linklabelDownloadCSVFile_LinkClicked)
	#
	# labelVariousInformation
	#
	$labelVariousInformation.Font = "Segoe UI, 8.25pt, style=Bold"
	$labelVariousInformation.Location = '237, 128'
	$labelVariousInformation.Name = "labelVariousInformation"
	$labelVariousInformation.Size = '489, 17'
	$labelVariousInformation.TabIndex = 45
	$labelVariousInformation.Text = "Various Information"
	$labelVariousInformation.TextAlign = 'MiddleCenter'
	#
	# labelAttributesGroupedPer
	#
	$labelAttributesGroupedPer.Font = "Segoe UI, 8.25pt, style=Bold"
	$labelAttributesGroupedPer.Location = '10, 128'
	$labelAttributesGroupedPer.Name = "labelAttributesGroupedPer"
	$labelAttributesGroupedPer.Size = '221, 17'
	$labelAttributesGroupedPer.TabIndex = 12
	$labelAttributesGroupedPer.Text = "Attributes Grouped Per Date"
	$labelAttributesGroupedPer.TextAlign = 'MiddleCenter'
	#
	# groupbox4
	#
	$groupbox4.Controls.Add($rbTargetForest)
	$groupbox4.Controls.Add($rbCurrentForest)
	$groupbox4.Controls.Add($tbForestName)
	$groupbox4.Controls.Add($buttonConnect)
	$groupbox4.Font = "Segoe UI, 8.25pt, style=Bold"
	$groupbox4.Location = '10, 62'
	$groupbox4.Name = "groupbox4"
	$groupbox4.Size = '716, 57'
	$groupbox4.TabIndex = 29
	$groupbox4.TabStop = $False
	$groupbox4.Text = "Connection"
	#
	# rbTargetForest
	#
	$rbTargetForest.Font = "Segoe UI, 8.25pt"
	$rbTargetForest.Location = '135, 19'
	$rbTargetForest.Name = "rbTargetForest"
	$rbTargetForest.Size = '110, 24'
	$rbTargetForest.TabIndex = 1
	$rbTargetForest.Text = "Target Forest"
	$rbTargetForest.UseVisualStyleBackColor = $True
	$rbTargetForest.add_CheckedChanged($rbTargetForest_CheckedChanged)
	#
	# rbCurrentForest
	#
	$rbCurrentForest.Checked = $True
	$rbCurrentForest.Font = "Segoe UI, 8.25pt"
	$rbCurrentForest.Location = '12, 19'
	$rbCurrentForest.Name = "rbCurrentForest"
	$rbCurrentForest.Size = '117, 24'
	$rbCurrentForest.TabIndex = 0
	$rbCurrentForest.TabStop = $True
	$rbCurrentForest.Text = "Current Forest"
	$rbCurrentForest.UseVisualStyleBackColor = $True
	$rbCurrentForest.add_CheckedChanged($rbCurrentForest_CheckedChanged)
	#
	# tbForestName
	#
	$tbForestName.Enabled = $False
	$tbForestName.Font = "Segoe UI, 8.25pt"
	$tbForestName.Location = '250, 21'
	$tbForestName.Name = "tbForestName"
	$tbForestName.Size = '280, 22'
	$tbForestName.TabIndex = 22
	#
	# buttonConnect
	#
	$buttonConnect.Font = "Segoe UI, 8.25pt"
	$buttonConnect.Location = '607, 20'
	$buttonConnect.Name = "buttonConnect"
	$buttonConnect.Size = '92, 23'
	$buttonConnect.TabIndex = 20
	$buttonConnect.Text = "Connect"
	$buttonConnect.UseVisualStyleBackColor = $True
	$buttonConnect.add_Click($buttonConnect_Click)
	#
	# panel1
	#
	$panel1.Controls.Add($labelSchemaCreationDateValue)
	$panel1.Controls.Add($labelADSchemaValue)
	$panel1.Controls.Add($labelExchangeSchemaValue)
	$panel1.Controls.Add($labelLyncSchemaValue)
	$panel1.Controls.Add($labelSchemaObjectsValue)
	$panel1.Controls.Add($labelSchemaObjectsUnkValue)
	$panel1.Controls.Add($labelSchemaCreationDate)
	$panel1.Controls.Add($labelSchemaObjectsUnknown)
	$panel1.Controls.Add($labelSchemaObjects)
	$panel1.Controls.Add($labelLyncSchema)
	$panel1.Controls.Add($labelExchangeSchema)
	$panel1.Controls.Add($labelADSchema)
	$panel1.BorderStyle = 'FixedSingle'
	$panel1.Location = '237, 148'
	$panel1.Name = "panel1"
	$panel1.Size = '489, 130'
	$panel1.TabIndex = 44
	#
	# labelSchemaCreationDateValue
	#
	$labelSchemaCreationDateValue.BackColor = 'White'
	$labelSchemaCreationDateValue.BorderStyle = 'FixedSingle'
	$labelSchemaCreationDateValue.Font = "Segoe UI, 8.25pt"
	$labelSchemaCreationDateValue.Location = '265, 11'
	$labelSchemaCreationDateValue.Name = "labelSchemaCreationDateValue"
	$labelSchemaCreationDateValue.Size = '206, 17'
	$labelSchemaCreationDateValue.TabIndex = 11
	$labelSchemaCreationDateValue.TextAlign = 'MiddleLeft'
	#
	# labelADSchemaValue
	#
	$labelADSchemaValue.BackColor = 'White'
	$labelADSchemaValue.BorderStyle = 'FixedSingle'
	$labelADSchemaValue.Font = "Segoe UI, 8.25pt"
	$labelADSchemaValue.Location = '265, 29'
	$labelADSchemaValue.Name = "labelADSchemaValue"
	$labelADSchemaValue.Size = '206, 17'
	$labelADSchemaValue.TabIndex = 10
	#
	# labelExchangeSchemaValue
	#
	$labelExchangeSchemaValue.BackColor = 'White'
	$labelExchangeSchemaValue.BorderStyle = 'FixedSingle'
	$labelExchangeSchemaValue.Font = "Segoe UI, 8.25pt"
	$labelExchangeSchemaValue.Location = '265, 47'
	$labelExchangeSchemaValue.Name = "labelExchangeSchemaValue"
	$labelExchangeSchemaValue.Size = '206, 17'
	$labelExchangeSchemaValue.TabIndex = 9
	#
	# labelLyncSchemaValue
	#
	$labelLyncSchemaValue.BackColor = 'White'
	$labelLyncSchemaValue.BorderStyle = 'FixedSingle'
	$labelLyncSchemaValue.Font = "Segoe UI, 8.25pt"
	$labelLyncSchemaValue.Location = '265, 65'
	$labelLyncSchemaValue.Name = "labelLyncSchemaValue"
	$labelLyncSchemaValue.Size = '206, 17'
	$labelLyncSchemaValue.TabIndex = 8
	#
	# labelSchemaObjectsValue
	#
	$labelSchemaObjectsValue.BackColor = 'White'
	$labelSchemaObjectsValue.BorderStyle = 'FixedSingle'
	$labelSchemaObjectsValue.Font = "Segoe UI, 8.25pt"
	$labelSchemaObjectsValue.Location = '265, 83'
	$labelSchemaObjectsValue.Name = "labelSchemaObjectsValue"
	$labelSchemaObjectsValue.Size = '206, 17'
	$labelSchemaObjectsValue.TabIndex = 7
	#
	# labelSchemaObjectsUnkValue
	#
	$labelSchemaObjectsUnkValue.BackColor = 'White'
	$labelSchemaObjectsUnkValue.BorderStyle = 'FixedSingle'
	$labelSchemaObjectsUnkValue.Font = "Segoe UI, 8.25pt"
	$labelSchemaObjectsUnkValue.Location = '265, 101'
	$labelSchemaObjectsUnkValue.Name = "labelSchemaObjectsUnkValue"
	$labelSchemaObjectsUnkValue.Size = '206, 17'
	$labelSchemaObjectsUnkValue.TabIndex = 6
	#
	# labelSchemaCreationDate
	#
	$labelSchemaCreationDate.Font = "Segoe UI, 8.25pt"
	$labelSchemaCreationDate.Location = '12, 12'
	$labelSchemaCreationDate.Name = "labelSchemaCreationDate"
	$labelSchemaCreationDate.Size = '240, 17'
	$labelSchemaCreationDate.TabIndex = 5
	$labelSchemaCreationDate.Text = "Schema Creation Date :"
	#
	# labelSchemaObjectsUnknown
	#
	$labelSchemaObjectsUnknown.Font = "Segoe UI, 8.25pt"
	$labelSchemaObjectsUnknown.Location = '12, 99'
	$labelSchemaObjectsUnknown.Name = "labelSchemaObjectsUnknown"
	$labelSchemaObjectsUnknown.Size = '240, 17'
	$labelSchemaObjectsUnknown.TabIndex = 4
	$labelSchemaObjectsUnknown.Text = "Schema Objects 'Unknown' Found :"
	#
	# labelSchemaObjects
	#
	$labelSchemaObjects.Font = "Segoe UI, 8.25pt"
	$labelSchemaObjects.Location = '12, 82'
	$labelSchemaObjects.Name = "labelSchemaObjects"
	$labelSchemaObjects.Size = '240, 17'
	$labelSchemaObjects.TabIndex = 3
	$labelSchemaObjects.Text = "Schema Objects Found :"
	#
	# labelLyncSchema
	#
	$labelLyncSchema.Font = "Segoe UI, 8.25pt"
	$labelLyncSchema.Location = '12, 65'
	$labelLyncSchema.Name = "labelLyncSchema"
	$labelLyncSchema.Size = '240, 17'
	$labelLyncSchema.TabIndex = 2
	$labelLyncSchema.Text = "Lync Schema Version :"
	#
	# labelExchangeSchema
	#
	$labelExchangeSchema.Font = "Segoe UI, 8.25pt"
	$labelExchangeSchema.Location = '12, 48'
	$labelExchangeSchema.Name = "labelExchangeSchema"
	$labelExchangeSchema.Size = '240, 17'
	$labelExchangeSchema.TabIndex = 1
	$labelExchangeSchema.Text = "Exchange Schema Version :"
	#
	# labelADSchema
	#
	$labelADSchema.Font = "Segoe UI, 8.25pt"
	$labelADSchema.Location = '12, 30'
	$labelADSchema.Name = "labelADSchema"
	$labelADSchema.Size = '240, 17'
	$labelADSchema.TabIndex = 0
	$labelADSchema.Text = "Active Directory Schema Version :"
	#
	# dgvSchemaDates
	#
	$dgvSchemaDates.AllowUserToAddRows = $False
	$dgvSchemaDates.AllowUserToDeleteRows = $False
	$dgvSchemaDates.AutoSizeColumnsMode = 'Fill'
	$dgvSchemaDates.BackgroundColor = 'White'
	$dgvSchemaDates.ColumnHeadersHeightSizeMode = 'AutoSize'
	[void]$dgvSchemaDates.Columns.Add($Date)
	[void]$dgvSchemaDates.Columns.Add($Count)
	$System_Windows_Forms_DataGridViewCellStyle_1 = New-Object 'System.Windows.Forms.DataGridViewCellStyle'
	$System_Windows_Forms_DataGridViewCellStyle_1.Alignment = 'MiddleLeft'
	$System_Windows_Forms_DataGridViewCellStyle_1.BackColor = 'Window'
	$System_Windows_Forms_DataGridViewCellStyle_1.Font = "Segoe UI, 8.25pt"
	$System_Windows_Forms_DataGridViewCellStyle_1.ForeColor = 'ControlText'
	$System_Windows_Forms_DataGridViewCellStyle_1.SelectionBackColor = 'Highlight'
	$System_Windows_Forms_DataGridViewCellStyle_1.SelectionForeColor = 'HighlightText'
	$System_Windows_Forms_DataGridViewCellStyle_1.WrapMode = 'False'
	$dgvSchemaDates.DefaultCellStyle = $System_Windows_Forms_DataGridViewCellStyle_1
	$dgvSchemaDates.Location = '10, 148'
	$dgvSchemaDates.Name = "dgvSchemaDates"
	$dgvSchemaDates.ReadOnly = $True
	$System_Windows_Forms_DataGridViewCellStyle_2 = New-Object 'System.Windows.Forms.DataGridViewCellStyle'
	$System_Windows_Forms_DataGridViewCellStyle_2.Alignment = 'MiddleLeft'
	$System_Windows_Forms_DataGridViewCellStyle_2.BackColor = 'Control'
	$System_Windows_Forms_DataGridViewCellStyle_2.Font = "Segoe UI, 8.25pt"
	$System_Windows_Forms_DataGridViewCellStyle_2.ForeColor = 'WindowText'
	$System_Windows_Forms_DataGridViewCellStyle_2.SelectionBackColor = 'Highlight'
	$System_Windows_Forms_DataGridViewCellStyle_2.SelectionForeColor = 'HighlightText'
	$System_Windows_Forms_DataGridViewCellStyle_2.WrapMode = 'True'
	$dgvSchemaDates.RowHeadersDefaultCellStyle = $System_Windows_Forms_DataGridViewCellStyle_2
	$dgvSchemaDates.RowHeadersVisible = $False
	$dgvSchemaDates.SelectionMode = 'FullRowSelect'
	$dgvSchemaDates.Size = '221, 130'
	$dgvSchemaDates.TabIndex = 42
	#
	# groupbox1
	#
	$groupbox1.Controls.Add($buttonExport)
	$groupbox1.Controls.Add($dgvSchema)
	$groupbox1.Font = "Segoe UI, 8.25pt, style=Bold"
	$groupbox1.Location = '10, 289'
	$groupbox1.Name = "groupbox1"
	$groupbox1.Size = '716, 423'
	$groupbox1.TabIndex = 26
	$groupbox1.TabStop = $False
	$groupbox1.Text = "Schema Objects"
	#
	# buttonExport
	#
	$buttonExport.Enabled = $False
	$buttonExport.Font = "Segoe UI, 8.25pt"
	$buttonExport.Location = '630, 386'
	$buttonExport.Name = "buttonExport"
	$buttonExport.Size = '75, 23'
	$buttonExport.TabIndex = 25
	$buttonExport.Text = "Export"
	$buttonExport.UseVisualStyleBackColor = $True
	$buttonExport.add_Click($buttonExport_Click)
	#
	# dgvSchema
	#
	$dgvSchema.AllowUserToAddRows = $False
	$dgvSchema.AllowUserToDeleteRows = $False
	$dgvSchema.AllowUserToOrderColumns = $True
	$dgvSchema.AutoSizeColumnsMode = 'Fill'
	$dgvSchema.AutoSizeRowsMode = 'AllCells'
	$dgvSchema.BackgroundColor = 'White'
	$System_Windows_Forms_DataGridViewCellStyle_3 = New-Object 'System.Windows.Forms.DataGridViewCellStyle'
	$System_Windows_Forms_DataGridViewCellStyle_3.Alignment = 'MiddleLeft'
	$System_Windows_Forms_DataGridViewCellStyle_3.BackColor = 'Control'
	$System_Windows_Forms_DataGridViewCellStyle_3.Font = "Segoe UI, 8.25pt"
	$System_Windows_Forms_DataGridViewCellStyle_3.ForeColor = 'WindowText'
	$System_Windows_Forms_DataGridViewCellStyle_3.SelectionBackColor = 'Highlight'
	$System_Windows_Forms_DataGridViewCellStyle_3.SelectionForeColor = 'HighlightText'
	$System_Windows_Forms_DataGridViewCellStyle_3.WrapMode = 'True'
	$dgvSchema.ColumnHeadersDefaultCellStyle = $System_Windows_Forms_DataGridViewCellStyle_3
	[void]$dgvSchema.Columns.Add($Name)
	[void]$dgvSchema.Columns.Add($WhenCreated)
	[void]$dgvSchema.Columns.Add($ProvidedFor)
	$System_Windows_Forms_DataGridViewCellStyle_4 = New-Object 'System.Windows.Forms.DataGridViewCellStyle'
	$System_Windows_Forms_DataGridViewCellStyle_4.Alignment = 'MiddleLeft'
	$System_Windows_Forms_DataGridViewCellStyle_4.BackColor = 'Window'
	$System_Windows_Forms_DataGridViewCellStyle_4.Font = "Segoe UI, 8.25pt"
	$System_Windows_Forms_DataGridViewCellStyle_4.ForeColor = 'ControlText'
	$System_Windows_Forms_DataGridViewCellStyle_4.SelectionBackColor = 'Highlight'
	$System_Windows_Forms_DataGridViewCellStyle_4.SelectionForeColor = 'HighlightText'
	$System_Windows_Forms_DataGridViewCellStyle_4.WrapMode = 'False'
	$dgvSchema.DefaultCellStyle = $System_Windows_Forms_DataGridViewCellStyle_4
	$dgvSchema.Location = '12, 21'
	$dgvSchema.MultiSelect = $False
	$dgvSchema.Name = "dgvSchema"
	$dgvSchema.ReadOnly = $True
	$dgvSchema.RowHeadersVisible = $False
	$dgvSchema.SelectionMode = 'FullRowSelect'
	$dgvSchema.Size = '693, 359'
	$dgvSchema.TabIndex = 24
	#
	# Name
	#
	$Name.HeaderText = "Name"
	$Name.Name = "Name"
	$Name.ReadOnly = $True
	#
	# WhenCreated
	#
	$WhenCreated.HeaderText = "WhenCreated"
	$WhenCreated.Name = "WhenCreated"
	$WhenCreated.ReadOnly = $True
	#
	# ProvidedFor
	#
	$ProvidedFor.HeaderText = "ProvidedFor"
	$ProvidedFor.Name = "ProvidedFor"
	$ProvidedFor.ReadOnly = $True
	#
	# openfiledialog1
	#
	$openfiledialog1.FileName = "openfiledialog1"
	$openfiledialog1.add_FileOk($openfiledialog1_FileOk)
	#
	# imagelistAnimation
	#
	$Formatter_binaryFomatter = New-Object System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
	#region Binary Data
	$System_IO_MemoryStream = New-Object System.IO.MemoryStream (,[byte[]][System.Convert]::FromBase64String('AAEAAAD/////AQAAAAAAAAAMAgAAAFdTeXN0ZW0uV2luZG93cy5Gb3JtcywgVmVyc2lvbj00LjAu
MC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODkFAQAA
ACZTeXN0ZW0uV2luZG93cy5Gb3Jtcy5JbWFnZUxpc3RTdHJlYW1lcgEAAAAERGF0YQcCAgAAAAkD
AAAADwMAAAB2CgAAAk1TRnQBSQFMAgEBCAEAASgBAAEoAQABEAEAARABAAT/ASEBAAj/AUIBTQE2
BwABNgMAASgDAAFAAwABMAMAAQEBAAEgBgABMP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/
AP8AugADwgH/Az0B/wM9Af8DwgH/MAADwgH/A10B/wOCAf8DwgH/sAADPQH/AwAB/wMAAf8DPQH/
MAADggH/Az0B/wM9Af8DXQH/gAADwgH/Az0B/wM9Af8DwgH/IAADPQH/AwAB/wMAAf8DPQH/A8IB
/wNdAf8DggH/A8IB/xAAA8IB/wM9Af8DPQH/A8IB/wNdAf8DPQH/Az0B/wNdAf8EAAOSAf8DkgH/
A8IB/3AAAz0B/wMAAf8DAAH/Az0B/yAAA8IB/wM9Af8DPQH/A8IB/wOCAf8DPQH/Az0B/wOCAf8Q
AAM9Af8DAAH/AwAB/wM9Af8DwgH/A10B/wOCAf8DwgH/A5IB/wOCAf8DggH/A5IB/3AAAz0B/wMA
Af8DAAH/Az0B/zAAA10B/wM9Af8DPQH/A10B/xAAAz0B/wMAAf8DAAH/Az0B/xAAA5IB/wOSAf8D
kgH/A8IB/3AAA8IB/wM9Af8DPQH/A8IB/zAAA8IB/wNdAf8DggH/A8IB/xAAA8IB/wM9Af8DPQH/
A8IB/xAAA8IB/wOSAf8DkgH/A8IB/zgAA8IB/wM9Af8DPQH/A8IB/zAAA8IB/wOCAf8DXQH/A8IB
/zAAA8IB/wPCAf8DkgH/A8IB/zQAA8IB/wPCAf80AAM9Af8DAAH/AwAB/wM9Af8wAANdAf8DPQH/
Az0B/wNdAf8wAAOSAf8DggH/A4IB/wOSAf8wAAPCAf8DwgH/A8IB/wPCAf8wAAM9Af8DAAH/AwAB
/wM9Af8wAAOCAf8DPQH/Az0B/wOCAf8wAAPCAf8DggH/A5IB/wOSAf8wAAPCAf8DwgH/A8IB/wPC
Af8wAAPCAf8DPQH/Az0B/wPCAf8wAAPCAf8DggH/A10B/wPCAf8wAAPCAf8DkgH/A5IB/wPCAf80
AAPCAf8DwgH/EAADwgH/A8IB/xQAA8IB/wOCAf8DXQH/A8IB/zAAA8IB/wOSAf8DkgH/A8IB/zQA
A8IB/wPCAf9UAAPCAf8DwgH/A8IB/wPCAf8QAANdAf8DPQH/Az0B/wNdAf8wAAOSAf8DggH/A5IB
/wOSAf8wAAPCAf8DwgH/A8IB/wPCAf9QAAPCAf8DwgH/A8IB/wPCAf8DwgH/A8IB/wOSAf8DwgH/
A4IB/wM9Af8DPQH/A4IB/yQAA8IB/wPCAf8EAAPCAf8DggH/A5IB/wOSAf8wAAPCAf8DwgH/A8IB
/wPCAf9UAAPCAf8DwgH/BAADkgH/A4IB/wOCAf8DkgH/A8IB/wOCAf8DXQH/A8IB/yAAA8IB/wPC
Af8DwgH/A8IB/wPCAf8DkgH/A5IB/wPCAf80AAPCAf8DwgH/ZAADkgH/A5IB/wOSAf8DkgH/MAAD
wgH/A8IB/wPCAf8DwgH/sAADwgH/A5IB/wOSAf8DwgH/NAADwgH/A8IB/7QAA8IB/wPCAf8DkgH/
A8IB/zQAA8IB/wPCAf+0AAOSAf8DggH/A4IB/wOSAf8wAAPCAf8DwgH/A8IB/wPCAf+gAAPCAf8D
XQH/A4IB/wPCAf8DkgH/A5IB/wOSAf8DwgH/BAADwgH/A8IB/xQAA8IB/wPCAf8DkgH/A8IB/wPC
Af8DwgH/A8IB/wPCAf8kAAPCAf8DwgH/dAADggH/Az0B/wM9Af8DggH/A8IB/wOSAf8DkgH/A8IB
/wPCAf8DwgH/A8IB/wPCAf8QAAOSAf8DggH/A4IB/wOSAf8EAAPCAf8DwgH/JAADwgH/A8IB/wPC
Af8DwgH/cAADXQH/Az0B/wM9Af8DggH/EAADwgH/A8IB/wPCAf8DwgH/EAADkgH/A5IB/wOSAf8D
kgH/MAADwgH/A8IB/wPCAf8DwgH/cAADwgH/A10B/wNdAf8DwgH/FAADwgH/A8IB/xQAA8IB/wOS
Af8DkgH/A8IB/zQAA8IB/wPCAf9sAAPCAf8DPQH/Az0B/wPCAf8wAAPCAf8DXQH/A4IB/wPCAf8w
AAPCAf8DwgH/A5IB/wPCAf80AAPCAf8DwgH/NAADPQH/AwAB/wMAAf8DPQH/MAADggH/Az0B/wM9
Af8DXQH/MAADkgH/A4IB/wOCAf8DkgH/MAADwgH/A8IB/wPCAf8DwgH/MAADPQH/AwAB/wMAAf8D
PQH/MAADXQH/Az0B/wM9Af8DggH/MAADkgH/A5IB/wOSAf8DkgH/MAADwgH/A8IB/wPCAf8DwgH/
MAADwgH/Az0B/wM9Af8DwgH/MAADwgH/A10B/wNdAf8DwgH/MAADwgH/A5IB/wOSAf8DwgH/NAAD
wgH/A8IB/3wAA8IB/wM9Af8DPQH/A8IB/zAAA8IB/wNdAf8DggH/A8IB/zAAA8IB/wPCAf8DkgH/
A8IB/xAAA8IB/wM9Af8DPQH/A8IB/1AAAz0B/wMAAf8DAAH/Az0B/zAAA4IB/wM9Af8DPQH/A10B
/zAAA5IB/wOCAf8DggH/A5IB/xAAAz0B/wMAAf8DAAH/Az0B/1AAAz0B/wMAAf8DAAH/Az0B/zAA
A10B/wM9Af8DPQH/A4IB/wOSAf8DPQH/Az0B/wPCAf8gAAOSAf8DkgH/A5IB/wOSAf8DwgH/A10B
/wOCAf8DwgH/Az0B/wMAAf8DAAH/Az0B/1AAA8IB/wM9Af8DPQH/A8IB/zAAA8IB/wOCAf8DXQH/
A8IB/wM9Af8DAAH/AwAB/wM9Af8gAAPCAf8DkgH/A5IB/wPCAf8DggH/Az0B/wM9Af8DXQH/A8IB
/wM9Af8DPQH/A8IB/6AAAz0B/wMAAf8DAAH/Az0B/zAAA10B/wM9Af8DPQH/A4IB/7AAA8IB/wM9
Af8DPQH/A8IB/zAAA8IB/wOCAf8DXQH/A8IB/xgAAUIBTQE+BwABPgMAASgDAAFAAwABMAMAAQEB
AAEBBQABgAEBFgAD/4EABP8B/AE/AfwBPwT/AfwBPwH8AT8D/wHDAfwBAwHAASMD/wHDAfwBAwHA
AQMD/wHDAf8DwwP/AcMB/wPDAf8B8AH/AfAB/wHwAf8B+QH/AfAB/wHwAf8B8AH/AfAB/wHwAf8B
8AH/AfAB/wHwAf8B8AH/AfAB/wHwAf8B+QHnAcMB/wHDAf8B5wL/AsMB/wHDAf8BwwL/AcABAwH+
AUMB/wHDAv8B5AEDAfwBAwH/AecC/wH8AT8B/AE/BP8B/AE/Af4BfwT/AfwBPwH+AX8E/wH8AT8B
/AE/BP8BwAEnAcABPwHnA/8BwAEDAcIBfwHDA/8DwwH/AcMD/wHDAecBwwH/AecD/wEPAf8BDwH/
AQ8B/wGfAf8BDwH/AQ8B/wEPAf8BDwH/AQ8B/wEPAf8BDwH/AQ8B/wEPAf8BDwH/AQ8B/wGfA/8B
wwH/AcMB/wLDAv8BwwH/AcMB/wLDAv8BwwH/AcABPwHAAQMC/wHDAf8BwAE/AcABAwT/AfwBPwH8
AT8E/wH8AT8B/AE/Cw=='))
	#endregion
	$imagelistAnimation.ImageStream = $Formatter_binaryFomatter.Deserialize($System_IO_MemoryStream)
	$Formatter_binaryFomatter = $null
	$System_IO_MemoryStream = $null
	$imagelistAnimation.TransparentColor = 'Transparent'
	#
	# timerCheckJob
	#
	$timerCheckJob.add_Tick($timerCheckJob_Tick)
	#
	# Date
	#
	$Date.FillWeight = 101.522842
	$Date.HeaderText = "Date"
	$Date.Name = "Date"
	$Date.ReadOnly = $True
	#
	# Count
	#
	$Count.FillWeight = 98.47716
	$Count.HeaderText = "Count"
	$Count.Name = "Count"
	$Count.ReadOnly = $True
	#
	# savefiledialog1
	#
	$savefiledialog1.add_FileOk($savefiledialog1_FileOk)
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formADSchemaDiscover10.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formADSchemaDiscover10.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formADSchemaDiscover10.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formADSchemaDiscover10.ShowDialog()

} #End Function

# Detect if the script is running in STA mode
if($host.Runspace.ApartmentState -ne "STA")
{
	$script = $MyInvocation.MyCommand.Definition
	Start-Process powershell.exe -ArgumentList "-sta -file ""$script""" -WindowStyle Hidden
	Exit
}
else
{
	if((OnApplicationLoad) -eq $true)
	{
		#Start the application
		Call-AD-Schema_Analyzer_pff | Out-Null
	}
}