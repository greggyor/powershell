﻿<#
				"Satnaam WaheGuru Ji"
		
	Author  : Aman Dhally
	Email	: amandhally@gmail.com
	Date	: 16-August-2012
	Time	: 18:10
	Script	: Created AD user Within Date
	Purpose	: Find New AD users those are created With-In a Week
	website : www.amandhally.net
	twitter : https://twitter.com/#!/AmanDhally 
	
				/^(o.o)^\  V.1

#>

# Import Active Directory Module {RAT Tools} 
# http://www.amandhally.net/2012/02/13/automate-server-administration-tools/ 
	cls
	"`n"
	Write-Host " ==> Importing Active Direcotry Module." -ForegroundColor 'Green' 
	Import-Module -Name ActiveDirectory 

# set Date of One Week Back
# for 15 days use $week = (Get-Date).AddDays(-15)
# for month user $week = (Get-Date).AddDays(-30)
# for yea you can use $week = (Get-Date).AddDays(-365)
	Write-Host " ==> Setting Date Period defined by you." -ForegroundColor 'Yellow'
	$week = (Get-Date).AddDays(-7)

# Save the CSV File on users Desktop
	Write-Host " ==> Setting file path." -ForegroundColor 'Magenta'
	$filepath = "$env:USERPROFILE\desktop"

# run on all users and save the output to cs file and the file will be saved
# on your desktop

	Write-Host " ==> Running your query on all AD users." -ForegroundColor 'Cyan'
	"`n"
	
	Get-ADUser -Filter * -Properties * | `
	where { $_.whenCreated -ge $week } | select Name,whenCreated `
	| Export-Csv -Path "$filepath\NewAdusers.csv"

#Now open the file
	Write-Host " ==> Opening NewAdusers.csv file." -ForegroundColor 'Green'
	Invoke-Expression "$filepath\NewAdusers.csv"

#End of the script 

######################## a | m | a | n | ##############################
# quote 
"`n"
"`n"
Write-Host "  Quote of the script  " -ForegroundColor 'Red'
Write-Host "  Give up your selfishness, and you shall find peace," -ForegroundColor 'Yellow'
write-host "  like water mingling with water, you shall merge in absorption. SGGS" -ForegroundColor 'Magenta'
"`n"
### 





