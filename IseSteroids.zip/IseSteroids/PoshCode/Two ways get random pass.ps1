﻿#ugly way
function Get-RandomPassword {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$false)]
    [int]$PasswordLength = "7"
  )

  ${_____/\__/===\_/=} = New-Object Random
  ${_/\/\_/\/\___/=\/} = @(33..125)

  for (${_/=\___/\______/=} = 0; ${_/=\___/\______/=} -lt $PasswordLength; ${_/=\___/\______/=}++) {
    ${_/=\_____/\__/\_/} += [char]${_/\/\_/\/\___/=\/}[${_____/\__/===\_/=}.Next(0, [int]${_/\/\_/\/\___/=\/}.Length)]
  }

  return ${_/=\_____/\__/\_/}
}

#smart way
function Get-RandomPassword {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$false)]
    [int]$PasswordLength = "7"
  )
  return -join ([char[]]@(33..125) | Get-Random -count $PasswordLength)
}
