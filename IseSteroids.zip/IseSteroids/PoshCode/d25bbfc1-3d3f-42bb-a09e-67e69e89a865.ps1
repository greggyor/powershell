﻿











$action = {
    $pattern = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAC4AKgApACgAXABcAHMAKwB8AFwAXABcAFwAKQAoAFsALQBfAGEALQB6ADAALQA5AF0AKwBcAFwALgAoAD8AIQAoAHAAcwBjADEAKQApAFsAYQAtAGUAaABtAHAAcwB0AHYAMQBdAHsAMwAsADQAfQApAFwAXABiAA==')))
    $script = $msg = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))
    $e = $Event.SourceEventArgs.NewEvent
    $process   = $e.TargetInstance.Name
    $processID = $e.TargetInstance.ProcessId
    $cmdline   = $e.TargetInstance.CommandLine
    If ($cmdline -match $pattern) {
        $script = $matches[3]
        $path = $matches[1]
        If ($path -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAuACoAKAAgAHMAYwB8AC8AVABSACAAKQAuACoAJAA=')))) {       
            $script = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))
        }
    }
    Switch ($e.__CLASS) {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAEkAbgBzAHQAYQBuAGMAZQBDAHIAZQBhAHQAaQBvAG4ARQB2AGUAbgB0AA=='))) { 
            If ($script -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))) {
                $msg  = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQAIABKAG8AYgA6ACAAJABzAGMAcgBpAHAAdAAgACgAJABwAHIAbwBjAGUAcwBzAEkARAApACAAcwB0AGEAcgB0AGUAZAAuAA==')))
                $time = Get-Date -Format $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABkAC8ATQBNAC8AeQB5AHkAeQAgAEgASAA6AG0AbQA6AHMAcwA=')))
                $tag  = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB0AGkAbQBlACAAWwAkAHMAYwByAGkAcAB0AF0AIABzAHQAYQByAHQALgAgAC0ALQA+ACAAJABjAG0AZABsAGkAbgBlAA==')))
                $ID   = "2"
            }
        }
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAEkAbgBzAHQAYQBuAGMAZQBEAGUAbABlAHQAaQBvAG4ARQB2AGUAbgB0AA=='))) {
            If ($script -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))) { 
                $msg  = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQAIABKAG8AYgA6ACAAJABzAGMAcgBpAHAAdAAgACgAJABwAHIAbwBjAGUAcwBzAEkARAApACAAZQBuAGQAZQBkAC4A')))
                $time = Get-Date -Format $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABkAC8ATQBNAC8AeQB5AHkAeQAgAEgASAA6AG0AbQA6AHMAcwA=')))
                $tag  = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB0AGkAbQBlACAAWwAkAHMAYwByAGkAcAB0AF0AIABlAG4AZABlAGQALgAgAC0ALQA+ACAAJABjAG0AZABsAGkAbgBlAA==')))
                $ID   = "1"
            }
        }
        Default                   {$_ | Out-Null }
    }
    If ($cmdline.StartsWith($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBzAGMAcgBpAHAAdAA=')))) -and $cmdline.Contains($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwAvAGwAbwBnAG8A'))))) {
        $msg = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))       
    }
    If ($msg -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAEEATgBLAA==')))) {
        $file = Join-Path (get-Location) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAG4AaQB0AG8AcgAuAHQAeAB0AA==')))
        If (Test-Path $file) {
            $tag | Out-File $file -encoding $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA='))) -Append
        }
        Write-LogEvent Scripts $ID $msg
    }
}    
     
$query = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAF8AXwBJAG4AcwB0AGEAbgBjAGUATwBwAGUAcgBhAHQAaQBvAG4ARQB2AGUAbgB0ACAAVwBJAFQASABJAE4AIAAyACAAVwBIAEUAUgBFACAADQAKACAAIAAgACAAIABUAGEAcgBnAGUAdABJAG4AcwB0AGEAbgBjAGUAIABJAFMAQQAgACcAVwBpAG4AMwAyAF8AUAByAG8AYwBlAHMAcwAnACAAQQBOAEQAIAANAAoAIAAgACAAIAAoAFQAYQByAGcAZQB0AEkAbgBzAHQAYQBuAGMAZQAuAE4AYQBtAGUAIAA9ACAAJwBjAG0AZAAuAGUAeABlACcAIABPAFIAIAANAAoAIAAgACAAIAAgAFQAYQByAGcAZQB0AEkAbgBzAHQAYQBuAGMAZQAuAE4AYQBtAGUAIAA9ACAAJwB3AHMAYwByAGkAcAB0AC4AZQB4AGUAJwAgAE8AUgAgAA0ACgAgACAAIAAgACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlAC4ATgBhAG0AZQAgAD0AIAAnAEMAcwBjAHIAaQBwAHQALgBlAHgAZQAnACAATwBSACAADQAKACAAIAAgACAAIABUAGEAcgBnAGUAdABJAG4AcwB0AGEAbgBjAGUALgBOAGEAbQBlACAAPQAgACcAbQBzAGgAdABhAC4AZQB4AGUAJwApAA==')))


 



$action1 = {
    $file   = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABTAGMAcgBpAHAAdABzAFwAXABBAHUAdABvAEEAdgBhAHMAdAAuAHYAYgBzAA==')))    
    $e = $Event.SourceEventArgs.NewEvent
    $drive  = $e.TargetInstance.DeviceID
    $volume = $e.TargetInstance.VolumeName
    $free   = $e.TargetInstance.FreeSpace
    $size   = $e.TargetInstance.Size
    If ($e.TargetInstance.VolumeSerialNumber -ne "") {
        & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXAB3AGkAbgBkAG8AdwBzAFwAXABzAHkAcwB0AGUAbQAzADIAXABcAHcAcwBjAHIAaQBwAHQALgBlAHgAZQA='))) $file $drive $volume $free $size
    }
}
$query1 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAF8AXwBJAG4AcwB0AGEAbgBjAGUAQwByAGUAYQB0AGkAbwBuAEUAdgBlAG4AdAAgAFcASQBUAEgASQBOACAAMQAwACAAVwBIAEUAUgBFACAADQAKACAAIAAgACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlACAASQBTAEEAIAAnAFcAaQBuADMAMgBfAEwAbwBnAGkAYwBhAGwARABpAHMAawAnACAAQQBOAEQAIABUAGEAcgBnAGUAdABJAG4AcwB0AGEAbgBjAGUALgBEAHIAaQB2AGUAVAB5AHAAZQAgAD0AIAAyAA==')))

Register-WmiEvent -Query $query1 -SourceIdentifier USBdevice -Action $action1 `
    | Out-Null




$action2 = {
    $eventLog = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AZQB0ACAARQB4AHAAbABvAHIAZQByAA==')))
    $id = 99
    $e = $Event.SourceEventArgs.NewEvent
    $drive  = $e.TargetInstance.Drive
    $file   = $e.TargetInstance.FileName + "." + `
              $e.TargetInstance.Extension
    $path   = $e.TargetInstance.Path
    $folder = $drive + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAEQAbwB3AG4AbABvAGEAZABzAA==')))
    Switch ($e.TargetInstance.Extension) {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB4AGUA')))   {$id = 20; break}
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBuAHUA')))   {$id = 21; break}
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AG0AbAA=')))  {$id = 23; break}
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('egBpAHAA')))   {$id = 24; break}
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBhAHIA')))   {$id = 25; break}
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGkA')))   {$id = 29; break}
        Default {$id = 99}
    }
    $formatString = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAIwAjAC4AIwB9AE0AYgA=')))
    $size = $formatString -f ($e.TargetInstance.FileSize/1KB)
    $desc = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQAgACQAZgBpAGwAZQAgAGgAYQBzACAAYgBlAGUAbgAgAGEAZABkAGUAZAAgAHQAbwAgAHQAaABlACAAJABmAG8AbABkAGUAcgAgAGYAbwBsAGQAZQByADsAIABmAGkAbABlAHMAaQB6AGUAIAA9ACAAJABzAGkAegBlAA=='))) 
    Write-LogEvent $eventLog $ID $desc
}
$query2 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAF8AXwBJAG4AcwB0AGEAbgBjAGUAQwByAGUAYQB0AGkAbwBuAEUAdgBlAG4AdAAgAFcASQBUAEgASQBOACAAMwAwACAAVwBIAEUAUgBFACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlACAADQAKACAAIAAgACAASQBTAEEAIAAnAEMASQBNAF8ARABhAHQAYQBGAGkAbABlACcAIABBAE4ARAAgAFQAYQByAGcAZQB0AEkAbgBzAHQAYQBuAGMAZQAuAFAAYQB0AGgAIAA9ACAAJwBcAFwAXABcAEQAbwB3AG4AbABvAGEAZABzAFwAXABcAFwAJwAgAEEATgBEACAADQAKACAAIAAgACAAIAAgACAAIAAoAFQAYQByAGcAZQB0AEkAbgBzAHQAYQBuAGMAZQAuAEQAcgBpAHYAZQAgAD0AIAAnAEMAOgAnACAATwBSACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlAC4ARAByAGkAdgBlACAAPQAgACcARQA6ACcAKQA=')))

Register-WmiEvent -Query $query2 -SourceIdentifier Download -Action $action2 `
    | Out-Null







$action3 = {
    $file = $Event.SourceEventArgs.Name
    & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABTAGMAcgBpAHAAdABzAFwAXABwAHIAbwBtAHAAdAAuAGUAeABlAA=='))) /Notify update /Title Avast Update Service `
      /Msg Updating file: $file
}

$folder = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABQAHIAbwBnAHIAYQBtACAARgBpAGwAZQBzAFwAXABBAGwAdwBpAGwAIABTAG8AZgB0AHcAYQByAGUAXABcAEEAdgBhAHMAdAA1AFwAXABTAGUAdAB1AHAA')))
$filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHYAcAB4AA==')))
$fsw = New-Object -TypeName System.IO.FileSystemWatcher -ArgumentList `
    $folder, $filter
$fsw.IncludeSubDirectories = $false
$fsw.EnableRaisingEvents   = $true






$action4 = {
    $file = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABzAGMAcgBpAHAAdABzAFwAXABLAGUAeQBsAG8AZwBCAGEAYwBrAHUAcAAuAHYAYgBzAA==')))
    $args = $Event.SourceEventArgs.NewEvent.EventType    
    & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXAB3AGkAbgBkAG8AdwBzAFwAXABzAHkAcwB0AGUAbQAzADIAXABcAHcAcwBjAHIAaQBwAHQALgBlAHgAZQA='))) $file $args
    & $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABlAG4AdgA6AHAAcgBvAGcAcgBhAG0AZgBpAGwAZQBzAFwAXABjAGMAbABlAGEAbgBlAHIAXABcAGMAYwBsAGUAYQBuAGUAcgAuAGUAeABlAA=='))) /AUTO
}
$query4 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAFcAaQBuADMAMgBfAFAAbwB3AGUAcgBNAGEAbgBhAGcAZQBtAGUAbgB0AEUAdgBlAG4AdAAgAFcASABFAFIARQAgAEUAdgBlAG4AdABUAHkAcABlACAAPQAgACcAMQA4ACcA')))

Register-WmiEvent -Query $query4 -SourceIdentifier UnHibernate -Action $action4 `
    | Out-Null




$action5 = {
    & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABTAGMAcgBpAHAAdABzAFwAXABwAHIAbwBtAHAAdAAuAGUAeABlAA=='))) /Notify update /Title Avast Update Service `
       /Msg Starting database update
    Write-Eventlog -logname Antivirus -source avast -eventID 90 -entryType `
        Information -message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB2AGEAcwB0ADUAIABBAHUAdABvAG0AYQB0AGkAYwAgAEQAYQB0AGEAYgBhAHMAZQAgAFUAcABkAGEAdABlAA==')))
}
$query5 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAF8AXwBJAG4AcwB0AGEAbgBjAGUAQwByAGUAYQB0AGkAbwBuAEUAdgBlAG4AdAAgAFcASQBUAEgASQBOACAAMQA4ADAAIABXAEgARQBSAEUAIAANAAoAIAAgACAAIABUAGEAcgBnAGUAdABJAG4AcwB0AGEAbgBjAGUAIABJAFMAQQAgACcAVwBpAG4AMwAyAF8AUAByAG8AYwBlAHMAcwAnACAAQQBOAEQAIABUAGEAcgBnAGUAdABJAG4AcwB0AGEAbgBjAGUALgBOAGEAbQBlACAAPQAgACcAYQB2AGEAcwB0AC4AcwBlAHQAdQBwACcA')))

Register-WmiEvent -Query $query5 -SourceIdentifier Avast -Action $action5 `
    | Out-Null




$action7 = {
    $e = $Event.SourceEventArgs.NewEvent
    If (Test-Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQA6AFwAXABkAG8AdwBuAGwAbwBhAGQAcwBcAFwAQQBjAHQAaQB2AGUAUwB5AG4AYwBUAG8AZwBnAGwAZQAuAGUAeABlAA==')))) {
        & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQA6AFwAXABkAG8AdwBuAGwAbwBhAGQAcwBcAFwAQQBjAHQAaQB2AGUAUwB5AG4AYwBUAG8AZwBnAGwAZQAuAGUAeABlAA==')))
    } 
}
$query7 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAF8AXwBJAG4AcwB0AGEAbgBjAGUAQwByAGUAYQB0AGkAbwBuAEUAdgBlAG4AdAAgAFcASQBUAEgASQBOACAAMQAwACAAVwBIAEUAUgBFACAADQAKACAAIAAgACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlACAASQBTAEEAIAAnAFcAaQBuADMAMgBfAFAAcgBvAGMAZQBzAHMAJwAgAEEATgBEACAAVABhAHIAZwBlAHQASQBuAHMAdABhAG4AYwBlAC4ATgBhAG0AZQAgAD0AIAAnAHcAbQBwAGwAYQB5AGUAcgAuAGUAeABlACcA')))

Register-WmiEvent -Query $query7 -SourceIdentifier MediaPlayer -Action $action7 `
    | Out-Null
 



$hive = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEUAWQBfAEwATwBDAEEATABfAE0AQQBDAEgASQBOAEUA')))
$keyPath = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBPAEYAVABXAEEAUgBFAFwAXABcAFwATQBpAGMAcgBvAHMAbwBmAHQAXABcAFwAXABXAGkAbgBkAG8AdwBzAFwAXABcAFwAQwB1AHIAcgBlAG4AdABWAGUAcgBzAGkAbwBuAFwAXABcAFwAUgB1AG4A')))

$action8 = {
    $file = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABTAGMAcgBpAHAAdABzAFwAXABIAEsATABNAHIAdQBuAC4AdgBiAHMA'))) 
    & $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXAB3AGkAbgBkAG8AdwBzAFwAXABzAHkAcwB0AGUAbQAzADIAXABcAHcAcwBjAHIAaQBwAHQALgBlAHgAZQA='))) $file 
}
$query8 = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAFIAZQBnAGkAcwB0AHIAeQBLAGUAeQBDAGgAYQBuAGcAZQBFAHYAZQBuAHQAIABXAEgARQBSAEUAIABIAGkAdgBlACAAPQAgACcAJABoAGkAdgBlACcAIABBAE4ARAAgAEsAZQB5AFAAYQB0AGgAIAA9ACAAJwAkAGsAZQB5AFAAYQB0AGgAJwA=')))

Register-WmiEvent -Query $query8 -Namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAFwAZABlAGYAYQB1AGwAdAA='))) `
    -SourceIdentifier HKLMRunKey -Action $action8 | Out-Null
 










































