﻿function Get-WindowsExperienceRating {
[CmdletBinding()]
param(
  [Parameter(ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
  [string[]]$ComputerName='localhost'
)
process {
  Get-WmiObject -ComputerName $ComputerName Win32_WinSAT | ForEach-Object {
     if($_.WinSatAssessmentState -ne 1) {
        Write-Warning "WinSAT data for '$($_.__SERVER)' is out of date ($($_.WinSatAssessmentState))"
     }
     $_
  } | Select-Object -Property @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcAB1AHQAZQByAA==')));expression={$_.__SERVER}}, *Score 
}
}
