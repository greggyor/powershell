﻿function Ping-Host {param(	[string]$HostName,
							[int32]$Requests = 3)
	
	for ($i = 1; $i -le $Requests; $i++) {
		$Result = gwmi -Class Win32_PingStatus -ComputerName . -Filter $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAcgBlAHMAcwA9ACcAJABIAG8AcwB0AE4AYQBtAGUAJwA=')))
		sleep -Seconds 1
		if ($Result.StatusCode -ne 0) {return $FALSE}
	}
	return $TRUE
}
