﻿#requires -version 2.0
function ConvertTo-CliXml {
    param(
        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [PSObject[]]$InputObject
    )
    begin {
        ${01001011011111010} = [PSObject].Assembly.GetType('System.Management.Automation.Serializer')
        ${01000110110101000} = ${01001011011111010}.GetConstructor('instance,nonpublic', $null, @([System.Xml.XmlWriter]), $null)
        ${00011101101000001} = New-Object System.IO.StringWriter
        ${01110001001101110} = New-Object System.Xml.XmlTextWriter ${00011101101000001}
        ${01101100001010110} = ${01000110110101000}.Invoke(${01110001001101110})
        ${01111110001000010} = ${01001011011111010}.GetMethod('Serialize', 'nonpublic,instance', $null, [type[]]@([object]), $null)
        ${00101110101001101} = ${01001011011111010}.GetMethod('Done', [System.Reflection.BindingFlags]'nonpublic,instance')
    }
    process {
        try {
            [void]${01111110001000010}.Invoke(${01101100001010110}, $InputObject)
        } catch {
            Write-Warning "Could not serialize $($InputObject.GetType()): $_"
        }
    }
    end {    
        [void]${00101110101001101}.Invoke(${01101100001010110}, @())
        ${00011101101000001}.ToString()
        ${01110001001101110}.Close()
        ${00011101101000001}.Dispose()
    }
}
