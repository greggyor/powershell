﻿






























Function Convert-Delimiter([regex]$from,[string]$to) 
{
   begin
   {
      ${/=\/\____/\/=\/\/} = [char](222)
   }
   process
   {
      $_ = $_.Trim()
      $_ = $_ -replace "(?:`"((?:(?:[^`"]|`"`"))+)(?:`"$from|`"`$))|(?:$from)|(?:((?:.(?!$from))*.)(?:$from|`$))","${/=\/\____/\/=\/\/}`$1`$2${/=\/\____/\/=\/\/}$to"
      $_ = $_ -replace "${/=\/\____/\/=\/\/}(?:$to|${/=\/\____/\/=\/\/})?`$","${/=\/\____/\/=\/\/}"
      $_ = $_ -replace "`"`"","`"" -replace "`"","`"`"" 
      $_ = $_ -replace "${/=\/\____/\/=\/\/}((?:[^${/=\/\____/\/=\/\/}`"](?!$to))+)${/=\/\____/\/=\/\/}($to|`$)","`$1`$2"
      $_ = $_ -replace "${/=\/\____/\/=\/\/}","`"" -replace "${/=\/\____/\/=\/\/}","`""
      $_
   }
}






























Function Import-Delimited([regex]$delimiter=",", [string]$PsPath="")
{
    BEGIN {
        if ($PsPath.Length -gt 0) { 
            write-output ($PsPath | &($MyInvocation.InvocationName) $delimiter); 
        } else {
            ${script:_/=\___/==\_/\___} = [IO.Path]::GetTempFileName()
            write-debug "Using tempfile $(${script:_/=\___/==\_/\___})"
        }
    }
    PROCESS {
        if($_ -and $_.Length -gt 0 ) {
            if(Test-Path $_) {
                if($delimiter -eq ",") {
                    Get-Content $_ | Where-Object {if($_.StartsWith("#TYPE") -or $_.StartsWith("--")){ write-debug "SKIPPING: $_"; $false;} else { $true }} | Add-Content ${script:_/=\___/==\_/\___}
                } else {
                    Get-Content $_ | Convert-Delimiter $delimiter "," | Where-Object { if( $_.StartsWith("--") ) { write-debug "SKIPPING: $_"; $false;} else { $true }} | Add-Content ${script:_/=\___/==\_/\___}
                }
            } 
            else {
                if($delimiter -eq ",") {
                    $_ | Where-Object {-not $_.StartsWith("#TYPE")} | Add-Content ${script:_/=\___/==\_/\___}
                } else {
                    $_ | Convert-Delimiter $delimiter "," | Add-Content ${script:_/=\___/==\_/\___}
                }
            }
        }
    }
    END {
        
        if ($PsPath.Length -eq 0) {
            Import-Csv ${script:_/=\___/==\_/\___}
        }
    }
}

