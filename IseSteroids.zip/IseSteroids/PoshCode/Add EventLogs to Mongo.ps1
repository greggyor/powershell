﻿
${15} = 'C:\\Program Files (x86)\\MongoDB\\CSharpDriver 1.5'
Add-Type -Path "$(${15})\\MongoDB.Bson.dll";
Add-Type -Path "$(${15})\\MongoDB.Driver.dll";
${14} = [MongoDB.Driver.MongoDatabase]::Create('mongodb://localhost/eventmonitor');
${2} = ${14}['events'];
${13} = get-eventlog Application -newest 10
for (${12} = 0; ${12} -le ${13}.Count-1; ${12}++) {
${11} = ${13}[${12}].Index
${10}= ${13}[${12}].EntryType
${9}= ${13}[${12}].InstanceID
${8}= ${13}[${12}].Category
${7}= ${13}[${12}].ReplacementStrings
${6}= ${13}[${12}].Source
${5}= ${13}[${12}].TimeGenerated
${4}= ${13}[${12}].EventID
${3} = ${13}[${12}].Message
[MongoDB.Bson.BsonDocument] ${1} = @{
    "_id"= [MongoDB.Bson.ObjectId]::GenerateNewId();
    "Index"= "${11}";
    "EntryType"= "${10}";
    "InstanceID"= "${9}";
    "Category"= "${8}";
    "ReplacementStrings"= "${7}";
    "Source"= "${6}";
    "TimeGenerated"= "${5}";
    "EventID"= "${4}";
    "Message"= "${3}";
    };
${2}.Insert(${1});
}
