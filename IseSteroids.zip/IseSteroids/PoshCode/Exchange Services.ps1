﻿#Requires input from the user
$Server = read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAARQB4AGMAaABhAG4AZwBlACAAUwBlAHIAdgBlAHIAIABOAGEAbQBlAA==')))

#Finds only the services that contain "Exchange"
$Status = (Get-Service -ComputerName $server |Where-object {$_.Displayname -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBFAHgAYwBoAGEAbgBnAGUAKgA=')))})

#Displays which Exchange Services are stopped
  foreach ($Name in $status) {
     IF ($Name.status -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcABwAGUAZAA=')))){Write-Host $Name.displayname $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBhAHMAIABzAHQAbwBwAHAAZQBkAA=='))) -foreground red}} 

#Starts all stopped services
  foreach ($Name in $status) {
     IF ($Name.status -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcABwAGUAZAA=')))){Start-Service -InputObject $Name}}

#Displays all Exchange services and their Status  
Get-Service -ComputerName $server |Where-object {$_.Displayname -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBFAHgAYwBoAGEAbgBnAGUAKgA=')))
}
