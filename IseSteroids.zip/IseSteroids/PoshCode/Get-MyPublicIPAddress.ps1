﻿

	[CmdletBinding()]
	param ()
	
	
	$webClient = New-Object System.Net.WebClient
	
	
	$webClient.DownloadString('http://myip.dnsomatic.com/')

