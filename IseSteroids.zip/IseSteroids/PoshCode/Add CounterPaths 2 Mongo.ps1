﻿

$mongoDriverPath = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXABQAHIAbwBnAHIAYQBtACAARgBpAGwAZQBzACAAKAB4ADgANgApAFwAXABNAG8AbgBnAG8ARABCAFwAXABDAFMAaABhAHIAcABEAHIAaQB2AGUAcgAgADEALgA1AA==')))
Add-Type -Path "$($mongoDriverPath)\\MongoDB.Bson.dll";
Add-Type -Path "$($mongoDriverPath)\\MongoDB.Driver.dll";

$db = [MongoDB.Driver.MongoDatabase]::Create($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBvAG4AZwBvAGQAYgA6AC8ALwBsAG8AYwBhAGwAaABvAHMAdAAvAGUAdgBlAG4AdABzAFgA'))));
$collection = $db[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAHUAbgB0AGUAcgBzAA==')))];

$counters= $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBlAG0AbwByAHkA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAByAG8AYwBlAHMAcwBvAHIA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABvAGcAaQBjAGEAbABkAGkAcwBrAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABoAHkAcwBpAGMAYQBsAGQAaQBzAGsA')))
$paths = (get-counter -List $counters).paths 


$samples = (get-counter -Counter $paths).CounterSamples

foreach ($i in $samples) {

[MongoDB.Bson.BsonDocument] $doc = @{
    "_id"= [MongoDB.Bson.ObjectId]::GenerateNewId();
    "Time"= $i.TimeBase;
    "Counters"= [MongoDB.Bson.BsonDocument] [ordered] @{
        "Path"= $i.Path;
        "RawValue"= $i.RawValue;
        
        "TimeStamp"= ($i.Timestamp).AddMinutes(-240);
        "TimeStamp100nsec"= $i.Timestamp100NSec;
        }; 
    }; 

$collection.Insert($doc);
} 

