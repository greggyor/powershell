﻿
[System.Reflection.Assembly]::LoadWithPartialName(”System.Web") | Out-Null
Function f3([string] ${f1})
{ 
	[System.Net.ServicePointManager]::Expect100Continue = $false
	${13} = [System.Net.WebRequest]::Create("http://twitter.com/statuses/update.xml")
	${17} = "username"
	${16} = "password"
	${13}.Credentials = new-object System.Net.NetworkCredential(${17}, ${16})
	${13}.Method = "POST"
	${13}.ContentType = "application/x-www-form-urlencoded" 
	write-progress "Tweeting" "Posting status update" -cu ${f1}
	${15} = [System.Text.Encoding]::UTF8.GetBytes( "status="  + ${f1}  )
	${14} = ${13}.GetRequestStream()
		${14}.Write(${15}, 0, ${15}.Length)
	${14}.Close()
	${12} = ${13}.GetResponse()
	write-host ${12}.statuscode 
	${11} = new-object System.IO.StreamReader(${12}.GetResponseStream())
		${11}.ReadToEnd()
	${11}.Close()
}
Function f2()
{
	for (${10}=15; ${10} -gt 1; ${10}--) 
	{
	Write-Progress -Activity "Waiting for next poll" `
	-SecondsRemaining ${10} -Status "Please wait."
	sleep 1
	}
}
Write-Host "You are going to cheat;-)"
${9} = Read-Host "Are you sure you want to continue? (Y/N)"
if (${9} -eq 'N')
	{
	Write-host "Maybe a good choice. It has to be a fair competition ;-)"
	break
	}
for (;;)
{
    Write-host "Get calculation from Twitbrain website"
	${8} = New-Object net.WebClient
	${7} = ${8}.DownloadString("http://ajaxorized.com/twitbrain")
	${1} = [Environment]::CurrentDirectory=(gl -PSProvider FileSystem).ProviderPath
	${7} | sc $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAfQBcAFwAVAB3AGkAdABiAHIAYQBpAG4ALgBoAHQAbQBsAA==')))
	${6} = gc $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAfQBcAFwAVAB3AGkAdABiAHIAYQBpAG4ALgBoAHQAbQBsAA=='))) | out-string
	${5} = [regex]::match(${6},'(?<=\\<div class="challenge"\\>).+(?=\\</div>
					<p class="challenge-answer">)',"singleline").value.trim()
	${5} = ${5} -replace "\\*times\\*","*"
	${5} = ${5} -replace "\\+plus\\+","+"
	${5} = ${5} -replace "\\-minus\\-","-"
	${3} = invoke-expression ${5}
	${4} = "@twitbrain " + ${3}
	${2} = gc $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAfQBcAFwAbwBsAGQAcgBlAHMAdQBsAHQALgB0AHgAdAA=')))
	if (${3} -eq ${2})
	{
		write-host "No new Twitbrain question is published yet"
	}
	else 
	{
		Write-host "What is the result of the next question?"
		Write-host ${5}
		f3 ${4}
		write-host "Tweet publised"
		${2} = ${3}
		Write-host "Save oldresult to text file"
		${2} > "${1}\\oldresult.txt"
	}
	f2
}
