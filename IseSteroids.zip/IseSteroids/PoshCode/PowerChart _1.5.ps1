﻿function New-PowerChart() {
[CmdletBinding(DefaultParameterSetName='DataTemplate')]
param(
    [Parameter(Position=0, Mandatory=$true)]
    [ValidateSet("Area","Bar","Bubble","Column","Line","Pie","Scatter")]
    [String[]]
    ${ChartType}
,
    [Parameter(Position=1, Mandatory=$true, HelpMessage='The data for the chart ...')]
    [System.Management.Automation.ScriptBlock[]]
    ${ItemsSource}
,
    [Parameter(Position=2, Mandatory=$true, HelpMessage='The property name for the independent values ...')]
    [String[]]
    ${IndependentValuePath}
,  
    [Parameter(Position=3, Mandatory=$true, HelpMessage='The property name for the dependent values ...')]
    [String[]]
    ${DependentValuePath}
,
    [Parameter(Position=4, HelpMessage='The property name for the size values ...')]
    [String[]]
    ${SizeValuePath}
,  
    [TimeSpan]    
    ${Interval}
,
    [Switch]
    $Show
)
begin
{
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAHYAYQBsADoAIAAkAEkAbgB0AGUAcgB2AGEAbAA=')))
    Chart -ControlNale PowerChart -Tag @{Interval=$Interval; ItemsSource=$ItemsSource} -On_Loaded {
        $Interval = $this.Tag.Interval
        if($Interval) {
            Register-PowerShellCommand -ScriptBlock {     
                ${10100000100001100}=0
                $Window.Content.Series | ForEach{ $_.ItemsSource = &$($Window.Content.Tag.ItemsSource[${10100000100001100}++]) }
            } -in $Interval -run
        }
    } -Series {
      ${00110001010001101} = @()
      
      for(${01011110000101011}=0; ${01011110000101011} -lt $ChartType.length; ${01011110000101011}++) {
         $chartType = $ChartType[${01011110000101011}].ToLower()
         if($SizeValuePath -and $ChartType[${01011110000101011}] -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGIAYgBsAGUA')))) {
            ${00110001010001101} += iex "$($chartType)Series -DependentValuePath $($DependentValuePath[${01011110000101011}]) -IndependentValuePath $($IndependentValuePath[${01011110000101011}]) -SizeValuePath $($SizeValuePath[${01011110000101011}]) -ItemsSource `$(&{$($ItemsSource[${01011110000101011}])})" 
            
         } elseif($ChartType[${01011110000101011}] -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABpAGUA')))) {
            ${00110001010001101} += iex "$($chartType)Series -DependentValuePath $($DependentValuePath[${01011110000101011}]) -IndependentValuePath $($IndependentValuePath[${01011110000101011}]) -ItemsSource `$(&{$($ItemsSource[${01011110000101011}])})"
            
         } else {
            Write-Verbose "$($chartType)Series -DependentValuePath $($DependentValuePath[${01011110000101011}]) -IndependentValuePath $($IndependentValuePath[${01011110000101011}]) -ItemsSource `$(&{$($ItemsSource[${01011110000101011}])})" 
            ${00110001010001101} += iex "$($chartType)Series -DependentValuePath $($DependentValuePath[${01011110000101011}]) -IndependentValuePath $($IndependentValuePath[${01011110000101011}]) -ItemsSource `$(&{$($ItemsSource[${01011110000101011}])})" 
            
         }       
      }
      Write-Verbose "There are $(${00110001010001101}.Count) Series!"
      ${00110001010001101}
   } -Background Transparent -BorderThickness 0 -Show:$Show
}
}
