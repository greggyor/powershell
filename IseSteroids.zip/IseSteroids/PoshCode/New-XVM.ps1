﻿#Examples
<#
New-XVM -Name "WS2012-TestServer01" -SwitchName "Switch(192.168.2.0/24)" -VhdType NoVHD
New-XVM -Name "WS2012-TestServer02" -SwitchName "Switch(192.168.2.0/24)" -VhdType ExistingVHD -VhdPath 'D:\\vhds\\WS2012-TestServer02.vhdx'
New-XVM -Name "WS2012-TestServer03" -SwitchName "Switch(192.168.2.0/24)" -VhdType NewVHD
New-XVM -Name "WS2012-TestServer04" -SwitchName "Switch(192.168.2.0/24)" -VhdType NewVHD -DiskType Fixed -DiskSize 1GB
New-XVM -Name "WS2012-TestServer05" -SwitchName "Switch(192.168.2.0/24)" -VhdType NewVHD -DiskType Dynamic
New-XVM -Name "WS2012-TestServer06" -SwitchName "Switch(192.168.2.0/24)" -VhdType Differencing -ParentVhdPath 'D:\\vhds\\Windows Server 2012 RC Base.vhdx'
New-XVM -Name "WS2012-TestServer07" -SwitchName "Switch(192.168.2.0/24)" -VhdType NewVHD -Configuration @{"MemoryStartupBytes"=1GB;"BootDevice"="LegacyNetworkAdapter"}
#>
Function New-XVM
{
    [cmdletbinding()]
    Param
    (
        [Parameter(Mandatory=$false,Position=1)]
        [string]$ComputerName=$env:COMPUTERNAME,        
        [Parameter(Mandatory=$true,Position=2)]
        [string]$Name,
        [Parameter(Mandatory=$true,Position=3)]
        [string]$SwitchName,
        [Parameter(Mandatory=$true,Position=4)]
        [ValidateSet("NoVHD","ExistingVHD","NewVHD","Differencing")]
        [string]$VhdType,
        [Parameter(Mandatory=$false,Position=5)]
        [hashtable]$Configuration
    )
    DynamicParam
    {
        Switch ($VhdType) {
            "ExistingVHD" {
                ${___/==\/=\__/===\} = New-Object System.Management.Automation.ParameterAttribute
                ${___/==\/=\__/===\}.ParameterSetName = "_AllParameterSets"
                ${___/==\/=\__/===\}.Mandatory = $true
                ${_/==\_/\/\______/} = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
                ${_/==\_/\/\______/}.Add(${___/==\/=\__/===\})
                ${_/\/\___/\__/\_/=} = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("VhdPath", [String], ${_/==\_/\/\______/})
                ${/=\___/\/=====\/\} = New-Object -Type System.Management.Automation.RuntimeDefinedParameterDictionary
                ${/=\___/\/=====\/\}.Add("VhdPath",${_/\/\___/\__/\_/=})
                return ${/=\___/\/=====\/\}
                break
            }
            "NewVHD" {
                ${___/==\/=\__/===\} = New-Object System.Management.Automation.ParameterAttribute
                ${___/==\/=\__/===\}.ParameterSetName = "_AllParameterSets"
                ${___/==\/=\__/===\}.Mandatory = $false
                ${_/==\_/\/\______/} = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
                ${_/==\_/\/\______/}.Add(${___/==\/=\__/===\})
                ${__/\/=\__/\/=====} = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("DiskType", [String], ${_/==\_/\/\______/})
                ${/=\___/\/=====\/\} = New-Object -Type System.Management.Automation.RuntimeDefinedParameterDictionary
                ${/=\___/\/=====\/\}.Add("DiskType",${__/\/=\__/\/=====})
                ${___/==\/=\__/===\} = New-Object System.Management.Automation.ParameterAttribute
                ${___/==\/=\__/===\}.ParameterSetName = "_AllParameterSets"
                ${___/==\/=\__/===\}.Mandatory = $false
                ${_/==\_/\/\______/} = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
                ${_/==\_/\/\______/}.Add(${___/==\/=\__/===\})
                ${__/\/\/==\_______} = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("DiskSize", [uint64], ${_/==\_/\/\______/})
                ${/=\___/\/=====\/\}.Add("DiskSize",${__/\/\/==\_______})
                return ${/=\___/\/=====\/\}
                break
            }
            "Differencing" {
                ${___/==\/=\__/===\} = New-Object System.Management.Automation.ParameterAttribute
                ${___/==\/=\__/===\}.ParameterSetName = "_AllParameterSets"
                ${___/==\/=\__/===\}.Mandatory = $true
                ${_/==\_/\/\______/} = New-Object -Type System.Collections.ObjectModel.Collection[System.Attribute]
                ${_/==\_/\/\______/}.Add(${___/==\/=\__/===\})
                ${_/\___/\/\/=\_/\/} = New-Object -Type System.Management.Automation.RuntimeDefinedParameter("ParentVhdPath", [String], ${_/==\_/\/\______/})
                ${/=\___/\/=====\/\} = New-Object -Type System.Management.Automation.RuntimeDefinedParameterDictionary
                ${/=\___/\/=====\/\}.Add("ParentVhdPath",${_/\___/\/\/=\_/\/})
                return ${/=\___/\/=====\/\}
            }
        }
    }
    Begin
    {
        Try
        {
            ${/===\/===\_/=\/\_} = Get-VMHost -ComputerName $ComputerName -ErrorAction:Stop
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($Error[0])
        }
        ${/====\_/\/=\____/} = ${/===\/===\_/=\/\_}.VirtualHardDiskPath
    }
    Process
    {
        ${/=\_/=\/\/\/\____} = "MemoryStartupBytes","BootDevice"
        ${____/\___/\__/\/\} = @()
        Switch ($VhdType) {
            "NoVHD" {
                ${/=\/=\/=\_/\/\_/\} = $null
            }
            "ExistingVHD" {
                ${/=\/=\/=\_/\/\_/\} = ${_/\/\___/\__/\_/=}.Value
            }
            "NewVhd" {
                if (-not ${__/\/=\__/\/=====}.IsSet) {${__/\/=\__/\/=====}.Value = "Dynamic"}
                if (-not ${__/\/\/==\_______}.IsSet) {${__/\/\/==\_______}.Value = 127GB}
                ${/=\/=\/=\_/\/\_/\} = Join-Path -Path ${/====\_/\/=\____/} -ChildPath "$Name.vhdx"
                Switch (${__/\/=\__/\/=====}.Value) {
                    "Fixed" {
                        ${__/\/=\_/\/\/\_/=} = New-VHD -Fixed -SizeBytes ${__/\/\/==\_______}.Value -Path ${/=\/=\/=\_/\/\_/\} -ErrorAction Stop
                    }
                    "Dynamic" {
                        ${__/\/=\_/\/\/\_/=} = New-VHD -Dynamic -SizeBytes ${__/\/\/==\_______}.Value -Path ${/=\/=\/=\_/\/\_/\} -ErrorAction Stop
                    }
                }
            }
            "Differencing" {
                ${/=\/=\/=\_/\/\_/\} = Join-Path -Path ${/====\_/\/=\____/} -ChildPath "$Name.vhdx"
                ${__/\/=\_/\/\/\_/=} = New-VHD -Differencing -ParentPath ${_/\___/\/\/=\_/\/}.Value -Path ${/=\/=\/=\_/\/\_/\} -ErrorAction Stop
            }
        }
        if (${__/\/=\_/\/\/\_/=} -ne $null) {
            Try
            {
                ${/===\_/\___/==\__} = "New-VM -ComputerName $ComputerName -Name '$Name' -SwitchName '$SwitchName' -VHDPath '$(${__/\/=\_/\/\/\_/=}.Path)'"
            }
            Catch
            {
                $PSCmdlet.WriteError($Error[0])
                rd -Path ${__/\/=\_/\/\/\_/=}.Path
            }
        } else {
            ${/===\_/\___/==\__} = "New-VM -ComputerName $ComputerName -Name '$Name' -SwitchName '$SwitchName' -NoVHD"
        }
        if ($Configuration -ne $null) {
            foreach (${_/\/==\/=\___/===} in $Configuration.Keys.GetEnumerator()) {
                if (${/=\_/=\/\/\/\____} -contains ${_/\/==\/=\___/===}) {
                    ${____/\___/\__/\/\} += "-${_/\/==\/=\___/===}" + " " + $Configuration[${_/\/==\/=\___/===}]
                }
            }
            ${____/\___/\__/\/\} = ${____/\___/\__/\/\} -join " "
        }
        if (${____/\___/\__/\/\}.Count -eq 0) {
            ${/===\_/\___/==\__} += " -ErrorAction Stop"
        } else {
            ${/===\_/\___/==\__} += " ${____/\___/\__/\/\} -ErrorAction Stop"        
        }
        iex -Command ${/===\_/\___/==\__}
    }
    End {}
}
