﻿funtcion Add-SVNFile {
    param (
        [Parameter(Position=0,Mandatory=$true,ValueFromPipeline=$true)]
        [String[]]$File,
        [Parameter(Position=1,Mandatory=$true)]
        [String]$Uri, 
        [Parameter(Position=2,Mandatory=$true)]
        [String]$Comment = "Nothing"
    )
    saps -Filepath "svn.exe" -ArgumentList $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvACAAJAB1AHIAaQA='))) -Wait -WindowStyle Hidden
    saps -Filepath "svn.exe" -ArgumentList $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBkAGQAIAAkAEYAaQBsAGUA'))) -Wait -WindowStyle Hidden
    saps -Filepath "svn.exe" -ArgumentList $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBpACAALQBtACAAJABDAG8AbQBtAGUAbgB0ACAAJABGAGkAbABlAA=='))) -Wait -WindowStyle Hidden
}
