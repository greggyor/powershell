﻿

function f1([System.IO.FileInfo] $file = $(throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGEAZwBlADoAIABHAGUAdAAtAE0ARAA1ACAAWwBTAHkAcwB0AGUAbQAuAEkATwAuAEYAaQBsAGUASQBuAGYAbwBdAA==')))))
{
  	$stream = $null;
  	$cryptoServiceProvider = [System.Security.Cryptography.SHA512CryptoServiceProvider];
  	$hashAlgorithm = new-object $cryptoServiceProvider
  	$stream = $file.OpenRead();
  	$hashByteArray = $hashAlgorithm.ComputeHash($stream);
  	$stream.Close();

  	

  	trap
  	{
   		if ($stream -ne $null)
    		{
			$stream.Close();
		}
  		break;
	}	

 	foreach ($byte in $hashByteArray) { if ($byte -lt 16) {$result += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAB7ADAAOgBYAH0A'))) -f $byte } else { $result += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAWAB9AA=='))) -f $byte }}
	return [string]$result;
}

function f2 ( $first, $second)
{
    foreach($s in $second)
    {
        if ($first -eq $s) {return $false}
    }
    return $true
}







$hashespath=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFwAaABhAHMAaABlAHMALgB4AG0AbAA=')))
del variable:\\args3 -ea 0
del variable:\\args2 -ea 0
del variable:\\xfiles -ea 0
del variable:\\files -ea 0
del variable:\\exclude -ea 0
$args3=@()
$args2=$args
$nu = 0
$errs = 0
$fc = 0
$upd = $false
$create = $false

for($i=0;$i -lt $args2.count; $i++)
{
    if ($args2[$i] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBoACoA'))))                                             
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGEAZwBlADoAIAAgACAAIAAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABbAC0AaABdACAAWwAtAHUAXQAgAFsALQBjAF0AIABbAC0AeAAgADwAZgBpAGwAZQAgAHAAYQB0AGgAIABvAGYAIABoAGEAcwBoAGUAcwAgAC4AeABtAGwAIABkAGEAdABhAGIAYQBzAGUAPgBdACAAWwBmAGkAbABlACgAcwApAC8AZABpAHIAIAAjADEAXQAgAFsAZgBpAGwAZQAoAHMAKQAvAGQAaQByACAAIwAyAF0AIAAuAC4ALgAgAFsAZgBpAGwAZQAoAHMAKQAvAGQAaQByACAAIwBuAF0AIABbAC0AZQAgADwARABpAHIAcwA+AF0A')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAHQAaQBvAG4AcwA6ACAAIAAtAGgAIAAtACAASABlAGwAcAAgAGQAaQBzAHAAbABhAHkALgA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAGMAIAAtACAAQwByAGUAYQB0AGUAIABoAGEAcwBoACAAZABhAHQAYQBiAGEAcwBlAC4AIABJAGYAIAAuAHgAbQBsACAAaABhAHMAaAAgAGQAYQB0AGEAYgBhAHMAZQAgAGQAbwBlAHMAIABuAG8AdAAgAGUAeABpAHMAdAAsACAALQBjACAAdwBpAGwAbAAgAGIAZQAgAGEAcwBzAHUAbQBlAGQALgA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAHUAIAAtACAAVQBwAGQAYQB0AGUAIABjAGgAYQBuAGcAZQBkACAAZgBpAGwAZQBzACAAYQBuAGQAIABhAGQAZAAgAG4AZQB3ACAAZgBpAGwAZQBzACAAdABvACAAZQB4AGkAcwB0AGkAbgBnACAAZABhAHQAYQBiAGEAcwBlAC4A')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAHgAIAAtACAAcwBwAGUAYwBpAGYAaQBlAHMAIAAuAHgAbQBsACAAZABhAHQAYQBiAGEAcwBlACAAZgBpAGwAZQAgAHAAYQB0AGgAIAB0AG8AIAB1AHMAZQAuACAARABlAGYAYQB1AGwAdAAgAGkAcwAgAC4AXABcAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAGUAIAAtACAAZQB4AGMAbAB1AGQAZQAgAGQAaQByAHMALgAgAFAAdQB0ACAAdABoAGkAcwAgAGEAZgB0AGUAcgAgAHQAaABlACAAZgBpAGwAZQBzAC8AZABpAHIAcwAgAHkAbwB1ACAAdwBhAG4AdAAgAHQAbwAgAGMAaABlAGMAawAgAHcAaQB0AGgAIABTAEgAQQA1ADEAMgAgAGEAbgBkACAAbgBlAGUAZABzACAAdABvACAAYgBlACAAZgB1AGwAbABwAGEAdABoACAAKABlAC4AZwAuACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGIAbwBiACAAbgBvAHQAIAAuAC4AXABcAGIAbwBiACkALgA=')))
        ""
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGEAbQBwAGwAZQBzADoAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcACAAZAA6AFwAXAAgAC0AYwAgAC0AeAAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABiAG8AYgBcAFwAaABhAHMAaABlAHMAXABcAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABwAGkAYwB0AHUAcgBlAHMAXABcAHMAdQBuAHMAZQB0AC4AagBwAGcAIAAtAHUAIAAtAHgAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcABpAGMAdAB1AHIAZQBzAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGQAbwBjAHUAbQBlAG4AdABzACAAZAA6AFwAXABtAGUAZABpAGEAXABcAG0AbwB2AGkAZQBzACAALQB4ACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGUAdgBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcAByAGkAdgBhAHQAZQAuAHgAbQBsAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAIAAtAHgAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGgAYQBzAGgAZQBzAFwAXABwAHIAaQB2AGEAdABlAC4AeABtAGwAIAAtAGUAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGgAYQBzAGgAZQBzAA==')))
        ""
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAZQA6ACAAIAAgACAAIABmAGkAbABlAHMAIABpAG4AIABzAHUAYgBkAGkAcgBlAGMAdABvAHIAaQBlAHMAIABvAGYAIABhAG4AeQAgAHMAcABlAGMAaQBmAGkAZQBkACAAZABpAHIAZQBjAHQAbwByAHkAIABhAHIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABwAHIAbwBjAGUAcwBzAGUAZAAuAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABpAGYAIAB5AG8AdQAgAHMAcABlAGMAaQBmAHkAIABvAG4AbAB5ACAAYQBuACAALQB4ACAAbwBwAHQAaQBvAG4ALAAgAG8AcgAgAG4AbwAgAG8AcAB0AGkAbwBuACAAYQBuAGQAIAAuAFwAXABoAGEAcwBoAC4AeABtAGwAIABlAHgAaQBzAHQAcwAsACAAbwBuAGwAeQAgAGYAaQBsAGUAcwAgAGkAbgAgAHQAaABlACAAZABhAHQAYQBiAGEAcwBlACAAdwBpAGwAbAAgAGIAZQAgAGMAaABlAGMAawBlAGQALgA=')))
        exit
    }
    if ($args2[$i] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQB1ACoA')))) {$upd=$true;continue}                       
    if ($args2[$i] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBjACoA')))) {$create=$true;continue}                    
    if ($args2[$i] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQB4ACoA')))) {$i++;$hashespath=$args2[$i];continue}      
    if ($args2[$i] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBlACoA'))))                                             
    {
        do {
        $i++        
        if ($i -ge $args2.count) {break}
        $exclude+=@($args2[$i])                                             
        if (($i+1) -ge $args2.count) {break}
        } while ($args2[$i+1] -notlike "-*")
        continue
    }        
    $args3+=@($args2[$i])                                                   
}

$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGsASABhAHMAaAAuAHAAcwAxACAALQAgAC4AXABcAGMAaABrAGgAYQBzAGgALgBwAHMAMQAgAC0AaAAgAGYAbwByACAAdQBzAGEAZwBlAC4A')))
""

if ($args3.count -ne 0) 
{
    
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHUAbQBlAHIAYQB0AGkAbgBnACAAZgBpAGwAZQBzACAAZgByAG8AbQAgAHMAcABlAGMAaQBmAGkAZQBkACAAbABvAGMAYQB0AGkAbwBuAHMALgAuAC4A')))

    $files=@(dir -literalpath $args3 -recurse -ea 0 | ?{$_.mode -notmatch "d"} | ?{f2 $_.directoryname $exclude})              

    if ($files.count -eq 0) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQBzACAAZgBvAHUAbgBkAC4AIABFAHgAaQB0AGkAbgBnAC4A'))); exit}

    if ($create -eq $true -or !(test-path $hashespath))                        
    {       
        
    
        $files = $files | %{write-host "Hashing $($_.fullname) ...";add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(f1 $_.fullname) -passthru}
        $files |export-clixml $hashespath    
        "Created $hashespath"
        "$($files.count) file hash(es) saved. Exiting."
        exit
    }
    $xfiles=@(import-clixml $hashespath)                                
}
else
{
    if (!(test-path $hashespath)) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZABhAHQAYQBiAGEAcwBlACAAZgBvAHUAbgBkACAAbwByACAAcwBwAGUAYwBpAGYAaQBlAGQALAAgAGUAeABpAHQAaQBuAGcALgA='))); exit}
    $xfiles=@(import-clixml $hashespath)                                
    if ($xfiles.count -eq 0) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQBzACAAcwBwAGUAYwBpAGYAaQBlAGQAIABhAG4AZAAgAG4AbwAgAGYAaQBsAGUAcwAgAGkAbgAgAEQAYQB0AGEAYgBhAHMAZQAuAA==')))}
    $files=$xfiles
}

"Loaded $($xfiles.count) file hash(es) from $hashespath"
    
$hash=@{}
for($x=0;$x -lt $xfiles.count; $x++)                                    
{
    if ($hash.contains($xfiles[$x].fullname)) {continue}
    $hash.Add($xfiles[$x].fullname,$x)   
}
     
foreach($f in $files)
{
    $n=($hash.($f.fullname))
    if ($n -eq $null)
    {    
        $nu++                                           
        if ($upd -eq $false) {"Needs to be added: `"$($f.fullname)`"";continue}                 
        
        "Hashing $($f.fullname) ..."
        
        
        if ($f.SHA512)
        {
            $f.SHA512 = (f1 $f.fullname)
        }
        else 
        {
            $f=$f |%{add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(f1 $_.fullname) -passthru}
        }
        $xfiles+=@($f)                                  
        continue
    }
    if ($f.SHA512)
    {
        $f.SHA512 = (f1 $f.fullname)
    }
    else 
    {
        $f=$f |%{add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(f1 $_.fullname) -passthru}
    }
        
    
                                                                      
    $fc++                                               
    if ($xfiles[$n].SHA512 -eq $f.SHA512)               
    {
        continue
    }
    $errs++                                             
    if ($upd -eq $true) { $xfiles[$n]=$f; "Updated `"$($f.fullname)`"";continue}                                                   
    "Bad SHA-512 found: `"$($f.fullname)`""
}

if ($upd -eq $true)                                     
{
    $xfiles|export-clixml $hashespath                   
    "Updated $hashespath"
    "$nu file hash(es) added to database."
    "$errs file hash(es) updated in database."
    exit
}

"$errs SHA-512 mixmatch(es) found."
"$fc file(s) SHA512 matched." 
if ($nu -ne 0) {"$nu file(s) need to be added [run with -u option to Add file hashes to database]."}
