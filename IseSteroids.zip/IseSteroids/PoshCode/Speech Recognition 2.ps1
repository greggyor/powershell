﻿$null = [Reflection.Assembly]::LoadWithPartialName("System.Speech")
if(!${Global:00100001111001101}){ 
   ${Global:01111110011000111} = new-object System.Speech.Synthesis.SpeechSynthesizer
   ${Global:00100001111001101} = new-object System.Speech.Recognition.SpeechRecognizer
}
${Script:10000010101011011} = @{}
${Script:10000010101011011}.Add("Stop Listening", { ${script:00100001010000010} = $false; Suspend-Listening })
${Script:10111000101001111} = ${Env:ComputerName}
function Update-SpeechCommands {
   ${10101111100001100} = new-object System.Speech.Recognition.Choices
   foreach(${01001111101110011} in ${Script:10000010101011011}.GetEnumerator()) {
      ${00100101010010001} = New-Object System.Speech.Recognition.GrammarBuilder
      ${00111010110001001} = @(${01001111101110011}.Key -split "\\s*\\*\\s*")
      for(${10010101111010110}=0;${10010101111010110} -lt ${00111010110001001}.Count;${10010101111010110}++) {
         if(${00111010110001001}[${10010101111010110}].Length -gt 0) {
            ${00100101010010001}.Append( ${00111010110001001}[${10010101111010110}] )
            if(${10010101111010110}+1 -lt ${00111010110001001}.Count) {
               ${00100101010010001}.AppendDictation()
            }
         } elseif(${10010101111010110} -eq 0) {
            ${00100101010010001}.AppendDictation()
         }
      }
      ${10101111100001100}.Add( (New-Object System.Speech.Recognition.SemanticResultValue ${00100101010010001}, ${01001111101110011}.Value.ToString()).ToGrammarBuilder() )
   }
   if($VerbosePreference -ne "SilentlyContinue") { ${Script:10000010101011011}.Keys |
      % { Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABDAG8AbQBwAHUAdABlAHIALAAgACQAXwA='))) -Fore Cyan } }
   ${10101111100100011} = New-Object System.Speech.Recognition.GrammarBuilder $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABDAG8AbQBwAHUAdABlAHIALAAgAA==')))
   ${10101111100100011}.Append((New-Object System.Speech.Recognition.SemanticResultKey "Commands", ${10101111100001100}.ToGrammarBuilder()))
   ${00101110110001000} = new-object System.Speech.Recognition.Grammar ${10101111100100011}
   ${00101110110001000}.Name = "Power VoiceMacros"
   Unregister-Event "SpeechModuleCommandRecognized" -ErrorAction SilentlyContinue
   $null = Register-ObjectEvent ${00101110110001000} SpeechRecognized `
            -SourceIdentifier "SpeechModuleCommandRecognized" `
            -Action { $_ = $event.SourceEventArgs.Result.Text; iex $event.SourceEventArgs.Result.Semantics.Item("Commands").Value  }
   ${Global:00100001111001101}.UnloadAllGrammars()
   ${Global:00100001111001101}.LoadGrammarAsync( ${00101110110001000} )
}
function Add-SpeechCommands {
   [CmdletBinding()]
   Param([hashtable]$VoiceMacros,[string]$Computer=${Script:10111000101001111})
   ${Script:10000010101011011} += $VoiceMacros
   ${Script:10111000101001111} = $Computer
   Update-SpeechCommands
}
function Remove-SpeechCommands {
   Param([string[]]$CommandText)
   foreach(${10011110010100010} in $CommandText) { ${Script:10000010101011011}.Remove(${10011110010100010}) }
   Update-SpeechCommands
}
function Clear-SpeechCommands {
   ${Script:10000010101011011} = @{}
   ${Script:10000010101011011}.Add("Stop Listening", { Suspend-Listening })
   Update-SpeechCommands
}
function Start-Listening {
   ${Global:00100001111001101}.Enabled = $true
   Say "Speech Macros are $(${Global:00100001111001101}.State)"
   Write-Host "Speech Macros are $(${Global:00100001111001101}.State)"
}
function Suspend-Listening {
   ${Global:00100001111001101}.Enabled = $false
   Say "Speech Macros are disabled"
   Write-Host "Speech Macros are disabled"
}
function Out-Speech {
   Param( [Parameter(ValueFromPipeline=$true)][Alias("IO")]$InputObject )
   $null = ${Global:01111110011000111}.SpeakAsync(($InputObject|Out-String))
}
function Remove-SpeechXP {
   ${Global:00100001111001101}.Dispose(); ${Global:00100001111001101} = $null
   ${Global:01111110011000111}.Dispose(); ${Global:01111110011000111} = $null
}
set-alias asc Add-SpeechCommands
set-alias rsc Remove-SpeechCommands
set-alias csc Clear-SpeechCommands
set-alias say Out-Speech
set-alias listen Start-Listener
Export-ModuleMember -Function * -Alias * -Variable SpeechModuleListener, SpeechModuleSpeaker
