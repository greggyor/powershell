﻿####################################################################
#
#Script will list all selected workstations and currently logged on user.
#Results will be output to a file.  A query can be placed on a previous search.
#Currently script only works when run directly from a DC
#Author:  Adam Liquorish
#Date: 15/10/2011
####################################################################

${3}=read-host "Enter username to query corresponding computer"
${14}=read-host "Would you like to just find a user-computer in an existing file.YES/NO"
if(${14} -eq "No")
{
	${13}=read-host "Enter path to save all files ie.c:\\Temp\\"
	${12}=read-host "Specify LDAP path ie ou=test,dc=domain,dc=com"
	${11}=${13}+"computers.txt"
	${8}=${13}+"compuserlistfull.txt"
	${7}=${13}+"results.txt"
	
	#Get computers from a defined LDAP Path
	${4}=@()
	${10}=foreach(comp in (get-adcomputer -filter * -searchbase $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMgB9AA=='))))){${9}.name}
	${10}>${11}
	write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABpAHMAdAAgAG8AZgAgAGMAbwBtAHAAdQB0AGUAcgBzACAAcwBjAGEAbgBuAGUAZAAgAGgAYQBzACAAYgBlAGUAbgAgAG8AdQBwAHUAdAAgAHQAbwAgACQAewAxADEAfQA=')))
	
	#Use list of computers to conduct a WMI lookup of logged on users
	foreach(${9} in ${10})
	{
		$cs-gwmi win32_computersystem -comp ${9}
		${4}+=@{$cs.username=$cs.name}
	}
	${4}>${8}
	write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgAgAHQAbwAgAGMAbwBtAHAAdQB0AGUAcgBsAGkAcwB0ACAAaABhAHMAIABiAGUAZQBuACAAbwB1AHAAdQB0ACAAdABvACAAJAB7ADgAfQA=')))
	
	#Lookup user to computer list and find specified user
	${1}=foreach(${2} in ${4})
	{
		if(${2}.keys -like $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAkAHsAMwB9AA=='))))
		{
			new-object -typename psobject -property @{user=${2}.keys;computer=${2}.values}
		}
	}
	${1}>${7}
	write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdQBsAHQAcwAgAG8AdQB0AHAAdQB0ACAAdABvACAAJAB7ADcAfQA=')))
	write-host "Results found are.." -foregroundcolor blue
	${1}
}
else
{
	#Input user to computer list from a file and lookup specified user.
	${6}=read-host "enter input folder path for file. Folder must contain a file called compuserlistfull.txt"
	${5}=${6}+"compuserlistfull.txt"
	${4}=@()
	${4}=get-content ${5}
	${1}=foreach(${2} in ${4})
	{
		if(${2} -like $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAkAHsAMwB9ACoA'))))
		{
			new-object -typename psobject -property @{user=${2}}
		}
	}
	${1}
}
