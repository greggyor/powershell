﻿











if($PSVersionTable.CLRVersion -gt "4.0") {
    ${/=\/\/\/\__/\_/\/} = "CSharp" 
    Add-Type -AssemblyName "UIAutomationClient, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    Add-Type -AssemblyName "UIAutomationTypes, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
} else {
    
    ${/=\/\/\/\__/\_/\/} = "CSharpVersion3" 
    Add-Type -AssemblyName "UIAutomationClient, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    Add-Type -AssemblyName "UIAutomationTypes, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
}


${_/\_________/\/\/} = "System.Windows.Automation"








Add-Accelerator Automation         "${_/\_________/\/\/}.Automation"                   -EA SilentlyContinue
Add-Accelerator AutomationElement  "${_/\_________/\/\/}.AutomationElement"            -EA SilentlyContinue
Add-Accelerator TextRange          "${_/\_________/\/\/}.Text.TextPatternRange"        -EA SilentlyContinue

Add-Accelerator Condition          "${_/\_________/\/\/}.Condition"                    -EA SilentlyContinue
Add-Accelerator AndCondition       "${_/\_________/\/\/}.AndCondition"                 -EA SilentlyContinue
Add-Accelerator OrCondition        "${_/\_________/\/\/}.OrCondition"                  -EA SilentlyContinue
Add-Accelerator NotCondition       "${_/\_________/\/\/}.NotCondition"                 -EA SilentlyContinue
Add-Accelerator PropertyCondition  "${_/\_________/\/\/}.PropertyCondition"            -EA SilentlyContinue

Add-Accelerator AutoElementIds     "${_/\_________/\/\/}.AutomationElementIdentifiers" -EA SilentlyContinue
Add-Accelerator TransformIds       "${_/\_________/\/\/}.TransformPatternIdentifiers"  -EA SilentlyContinue


${_/==\/=====\/\/==} = Get-Type -Assembly UIAutomationClient -Base System.Windows.Automation.BasePattern 
            


Add-Type -Language ${/=\/\/\/\__/\_/\/} -ReferencedAssemblies UIAutomationClient, UIAutomationTypes -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Management.Automation;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Automation;
using System.Runtime.InteropServices;


[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
public class StaticFieldAttribute : ArgumentTransformationAttribute {
   private Type _class;

   public override string ToString() {
      return string.Format("[StaticField(OfClass='{0}')]", OfClass.FullName);
   }

   public override Object Transform( EngineIntrinsics engineIntrinsics, Object inputData) {
      if(inputData is string && !string.IsNullOrEmpty(inputData as string)) {
         System.Reflection.FieldInfo field = _class.GetField(inputData as string, BindingFlags.Static | BindingFlags.Public);
         if(field != null) {
            return field.GetValue(null);
         }
      }
      return inputData;
   }
   
   public StaticFieldAttribute( Type ofClass ) {
      OfClass = ofClass;
   }

   public Type OfClass {
      get { return _class; }
      set { _class = value; }
   }   
}

public static class UIAutomationHelper {

   [DllImport ("user32.dll", CharSet = CharSet.Auto)]
   static extern IntPtr FindWindow (string lpClassName, string lpWindowName);

   [DllImport ("user32.dll", CharSet = CharSet.Auto)]
   static extern bool AttachThreadInput (int idAttach, int idAttachTo, bool fAttach);

   [DllImport ("user32.dll", CharSet = CharSet.Auto)]
   static extern int GetWindowThreadProcessId (IntPtr hWnd, IntPtr lpdwProcessId);

   [DllImport ("user32.dll", CharSet = CharSet.Auto)]
   static extern IntPtr SetForegroundWindow (IntPtr hWnd);

   public static AutomationElement RootElement {
      get { return AutomationElement.RootElement; }
   }


   ///<synopsis>Using Win32 to set foreground window because AutomationElement.SetFocus() is unreliable</synopsis>
   public static bool SetForeground(this AutomationElement element)
   {
      if(element == null) { 
         throw new ArgumentNullException("element");
      }

      // Get handle to the element
      IntPtr other = FindWindow (null, element.Current.Name);

      // // Get the Process ID for the element we are trying to
      // // set as the foreground element
      // int other_id = GetWindowThreadProcessId (other, IntPtr.Zero);
      // 
      // // Get the Process ID for the current process
      // int this_id = GetWindowThreadProcessId (Process.GetCurrentProcess().Handle, IntPtr.Zero);
      // 
      // // Attach the current process's input to that of the 
      // // given element. We have to do this otherwise the
      // // WM_SETFOCUS message will be ignored by the element.
      // bool success = AttachThreadInput(this_id, other_id, true);

      // Make the Win32 call
      IntPtr previous = SetForegroundWindow(other);

      return !IntPtr.Zero.Equals(previous);
   }
}
"@
            





ForEach(${__/==\/\/===\/\__} in ${_/==\/=====\/\/==}){
   ${__/==\/\/===\/\__} | Add-Accelerator
   ${__/===\_/=\_/\/\_} = ${__/==\/\/===\/\__}.FullName
   ${/==\/\/=====\/===} = ${__/==\/\/===\/\__}.Name -Replace "Pattern","."
   ${__/\_/\____/\/=\/} = "`n`t`t"
   
   ni "Function:ConvertTo-$(${__/==\/\/===\/\__}.Name)" -Value "
   param(
      [Parameter(ValueFromPipeline=`$true)][Alias('Element','AutomationElement')][AutomationElement]`$InputObject
   )
   process { 
      trap { 
         if(`$_.Exception.Message -like '*Unsupported Pattern.*') {
            Write-Error `"Cannot get ```"$(${__/==\/\/===\/\__}.Name)```" from that AutomationElement, `$(`$_)` You should try one of: `$(`$InputObject.GetSupportedPatterns()|%{```"'```" + (`$_.ProgrammaticName.Replace(```"PatternIdentifiers.Pattern```",```"```")) + ```"Pattern'```"})`"; continue;
         }
      }
      Write-Output `$InputObject.GetCurrentPattern([${__/===\_/=\_/\/\_}]::Pattern).Current
   }"
   
   ${__/==\/\/===\/\__}.GetMethods() | 
   Where { $_.DeclaringType -eq $_.ReflectedType -and !$_.IsSpecialName } | 
   ForEach {
      ${/==\______/\/\/==} = "Function:Invoke-${/==\/\/=====\/===}$($_.Name)"
      ${/=\_/\_/=\/\/=\/\} = 1
      
      if (test-path ${/==\______/\/\/==}) { remove-item ${/==\______/\/\/==} }
      ${/=\/\/=\/==\_/===} = @("${__/\_/\____/\/=\/}[Parameter(ValueFromPipeline=`$true)]"+
                      "${__/\_/\____/\/=\/}[Alias('Parent','Element','Root','AutomationElement')]"+
                      "${__/\_/\____/\/=\/}[AutomationElement]`$InputObject"
                      ) + 
                    @(
                      "[Parameter()]${__/\_/\____/\/=\/}[Switch]`$Passthru"
                     ) + 
                    @($_.GetParameters() | % { "[Parameter(Position=$(${/=\_/\_/=\/\/=\/\}; ${/=\_/\_/=\/\/=\/\}++))]${__/\_/\____/\/=\/}[$($_.ParameterType.FullName)]`$$($_.Name)" })
      ${/=\/\/=\/==\_/===} = ${/=\/\/=\/==\_/===} -Join "${__/\_/\____/\/=\/},${__/\_/\____/\/=\/}"
      ${/==\/\_/\_/==\_/=} = '$' + (@($_.GetParameters() | select -Expand Name ) -Join ', $')

      ${___/\/=\_/==\____} = @"
   param(
      ${/=\/\/=\/==\_/===}
   )
   process { 
      ## trap { Write-Warning "`$(`$_)"; break }
      `$pattern = `$InputObject.GetCurrentPattern([${__/===\_/=\_/\/\_}]::Pattern)
      if(`$pattern) {
         `$Pattern.$($_.Name)($(if(${/==\/\_/\_/==\_/=}.Length -gt 1){ ${/==\/\_/\_/==\_/=} }))
      }
      if(`$passthru) {
         `$InputObject
      }
   }
"@
      
      trap {
         Write-Warning $_
         Write-Host ${___/\/=\_/==\____} -fore cyan
      }
      ni ${/==\______/\/\/==} -value ${___/\/=\_/==\____}
   }
   
   ${__/==\/\/===\/\__}.GetProperties() | 
   Where { $_.DeclaringType -eq $_.ReflectedType -and $_.Name -notmatch "Cached|Current"} |
   ForEach {
      ${/==\______/\/\/==} = "Function:Get-${/==\/\/=====\/===}$($_.Name)".Trim('.')
      if (test-path ${/==\______/\/\/==}) { remove-item ${/==\______/\/\/==} }
      ni ${/==\______/\/\/==} -value "
      param(
         [Parameter(ValueFromPipeline=`$true)]
         [AutomationElement]`$AutomationElement
      )      
      process { 
         trap { Write-Warning `"${__/===\_/=\_/\/\_} `$_`"; continue }
         `$pattern = `$AutomationElement.GetCurrentPattern([${__/===\_/=\_/\/\_}]::Pattern)
         if(`$pattern) {
            `$pattern.'$($_.Name)'
         }
      }"
   }
   
   ${__/==\/\/===\/\__}.GetFields() |
   Where { $_.FieldType.Name -like "*TextAttribute"} |
   ForEach {
      ${/==\______/\/\/==} = "Function:Get-Text$($_.Name -replace 'Attribute')"
      if (test-path ${/==\______/\/\/==}) { remove-item ${/==\______/\/\/==} }
      ni ${/==\______/\/\/==} -value "
      param(
         [Parameter(ValueFromPipeline=`$true)]
         [AutomationElement]`$AutomationElement
      )
      process { 
         trap { Write-Warning `"${__/===\_/=\_/\/\_} `$_`"; continue }
         `$AutomationElement.GetAttributeValue([${__/===\_/=\_/\/\_}]::$($_.Name))
      }"
   }
   
   ${__/==\/\/===\/\__}.GetFields() | Where { $_.FieldType -eq [System.Windows.Automation.AutomationEvent] } |
   ForEach {
      $Name = $_.Name -replace 'Event$'
      ${/==\______/\/\/==} = "Function:Register-$(${/==\/\/=====\/===}.Trim('.'))$Name"
      if (test-path ${/==\______/\/\/==}) { remove-item ${/==\______/\/\/==} }
      ni ${/==\______/\/\/==} -value "
      param(
         [Parameter(ValueFromPipeline=`$true)]
         [AutomationElement]`$AutomationElement
      ,
         [System.Windows.Automation.TreeScope]`$TreeScope = 'Element'
      ,
         [ScriptBlock]`$EventHandler
      )
      process { 
         trap { Write-Warning `"${__/===\_/=\_/\/\_} `$_`"; continue }
         [Automation]::AddAutomationEventHandler( [${__/===\_/=\_/\/\_}]::$Name, `$AutomationElement, `$TreeScope, `$EventHandler )
      }"
   }
}

${__/===\/======\/\} = [Condition]::FalseCondition
${_/\_/\/\___/==\_/}  = [Condition]::TrueCondition

Add-Type -AssemblyName System.Windows.Forms
Add-Accelerator SendKeys           System.Windows.Forms.SendKeys       -EA SilentlyContinue

${_/========\___/\_} = [system.windows.automation.automationelement+automationelementinformation].GetProperties()

sal Invoke-UIElement Invoke-Invoke.Invoke

function formatter  { END {
   $input | ft @{l="Text";e={$_.Text.SubString(0,25)}}, ClassName, FrameworkId -Auto
}}

function Get-ClickablePoint {
[CmdletBinding()]
param(
   [Parameter(ValueFromPipeline=$true)]
   [Alias("Parent","Element","Root")]
   [AutomationElement]$InputObject
)
   process {
      $InputObject.GetClickablePoint()
   }
}

function Show-Window {
[CmdletBinding()]
param(
   [Parameter(ValueFromPipeline=$true)]
   [Alias("Parent","Element","Root")]
   [AutomationElement]$InputObject
,
   [Parameter()]
   [Switch]$Passthru   
)
   process {
      __/\/\____/\_/\_/\ $InputObject
      if($passthru) {
         $InputObject
      }        
   }
}

function __/\/\____/\_/\_/\ {
[CmdletBinding()]
param(
   [Parameter(ValueFromPipeline=$true)]
   [Alias("Parent","Element","Root")]
   [AutomationElement]$InputObject
,
   [Parameter()]
   [Switch]$Passthru   
)
   process {
      try {
         [UIAutomationHelper]::SetForeground( $InputObject )
         $InputObject.SetFocus()
      } catch {
         Write-Verbose "SetFocus fail, trying SetForeground"
      }
      if($passthru) {
         $InputObject
      }        
   }
}

function Send-UIKeys {
[CmdletBinding()]
param(
   [Parameter(Position=0)]
   [string]$Keys
,
   [Parameter(ValueFromPipeline=$true)]
   [Alias("Parent","Element","Root")]
   [AutomationElement]$InputObject
,
   [Parameter()]
   [Switch]$Passthru
,
   [Parameter()]
   [Switch]$Async
)
   process {
      if(!$InputObject.Current.IsEnabled)
      {
         Write-Warning "The Control is not enabled!"
      }
      if(!$InputObject.Current.IsKeyboardFocusable)
      {
         Write-Warning "The Control is not focusable!"
      }
      __/\/\____/\_/\_/\ $InputObject
      
      if($Async) {
         [SendKeys]::Send( $Keys )
      } else {
         [SendKeys]::SendWait( $Keys )
      }
      
      if($passthru) {
         $InputObject
      }      
   }
}

function Set-UIText {
[CmdletBinding()]
param(
   [Parameter(Position=0)]
   [string]$Text
,
   [Parameter(ValueFromPipeline=$true)]
   [Alias("Parent","Element","Root")]
   [AutomationElement]$InputObject
,
   [Parameter()]
   [Switch]$Passthru   
)
   process {
      if(!$InputObject.Current.IsEnabled)
      {
         Write-Warning "The Control is not enabled!"
      }
      if(!$InputObject.Current.IsKeyboardFocusable)
      {
         Write-Warning "The Control is not focusable!"
      }
      
      ${_/=\/\/==\_/\/=\/} = $null
      if($InputObject.TryGetCurrentPattern([ValuePattern]::Pattern,[ref]${_/=\/\/==\_/\/=\/})) {
         Write-Verbose "Set via ValuePattern!"
         ${_/=\/\/==\_/\/=\/}.SetValue( $Text )
      } 
      elseif($InputObject.Current.IsKeyboardFocusable) 
      {
         __/\/\____/\_/\_/\ $InputObject
         [SendKeys]::SendWait("^{HOME}");
         [SendKeys]::SendWait("^+{END}");
         [SendKeys]::SendWait("{DEL}");
         [SendKeys]::SendWait( $Text )
      }
      if($passthru) {
         $InputObject
      }      
   }
}

function Select-UIElement {
[CmdletBinding(DefaultParameterSetName="FromParent")]
PARAM (
   [Parameter(ParameterSetName="FromWindowHandle", Position="0", Mandatory=$true)] 
   [Alias("MainWindowHandle","hWnd","Handle","Wh")]
   [IntPtr[]]$WindowHandle=[IntPtr]::Zero
,
   [Parameter(ParameterSetName="FromPoint", Position="0", Mandatory=$true)]
   [System.Windows.Point[]]$Point
,
   [Parameter(ParameterSetName="FromParent", ValueFromPipeline=$true, Position=100)]
   [System.Windows.Automation.AutomationElement]$Parent = [UIAutomationHelper]::RootElement
,
   [Parameter(ParameterSetName="FromParent", Position="0")]
   [Alias("WindowName")]
   [String[]]$Name
,
   [Parameter(ParameterSetName="FromParent", Position="1")]
   [Alias("Type","Ct")]
   [System.Windows.Automation.ControlType]
   [StaticField(([System.Windows.Automation.ControlType]))]$ControlType
,
   [Parameter(ParameterSetName="FromParent")]
   [Alias("UId")]
   [String[]]$AutomationId
,
   
   [Parameter(ParameterSetName="FromParent", ValueFromPipelineByPropertyName=$true )]
   [Alias("Id")]
   [Int[]]$PID
,
   [Parameter(ParameterSetName="FromParent")]
   [Alias("Pn")]
   [String[]]$ProcessName
,
   [Parameter(ParameterSetName="FromParent")]
   [Alias("Cn")]
   [String[]]$ClassName
,
   [switch]$Recurse
,
   [switch]$Bare,

   [Parameter(ParameterSetName="FromParent")]
   [Alias("Pv")]
   [Hashtable]$PropertyValue

)
process {

   Write-Debug "Parameters Found"
   Write-Debug ($PSBoundParameters | ft | Out-String)

   ${/==\/=\/=\/\/====} = "Children"
   if($Recurse) { ${/==\/=\/=\/\/====} = "Descendants" }
   
   $condition = [System.Windows.Automation.Condition]::TrueCondition
   
   Write-Verbose $PSCmdlet.ParameterSetName
   switch -regex ($PSCmdlet.ParameterSetName) {
      "FromWindowHandle" {
         Write-Verbose "Finding from Window Handle ${_/=\__/\/=\/\/=\/}"
         ${/===\__/===\/\/\_} = $(
            foreach(${_/=\__/\/=\/\/=\/} in $WindowHandle) {
               [System.Windows.Automation.AutomationElement]::FromHandle( ${_/=\__/\/=\/\/=\/} )
            }
         )
         continue
      }
      "FromPoint" {
         Write-Verbose "Finding from Point $Point"
         ${/===\__/===\/\/\_} = $(
            foreach(${__/\/\___/\/=\/\_} in $Point) {
               [System.Windows.Automation.AutomationElement]::FromPoint( ${__/\/\___/\/=\/\_} )
            }
         )
         continue
      }
      "FromParent" {
         Write-Verbose "Finding from Parent!"
         
         [ScriptBlock[]]${/==\/\___/=\__/=\} = @()
         if($AutomationId) {
            [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
               foreach(${_/\__/\_____/=\__} in $AutomationId) {
                  new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::AutomationIdProperty), ${_/\__/\_____/=\__}
               }
            )
            if(${/=======\_/\_/=\/}.Length -gt 1) {
               [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
            } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
               [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
            }  
         }
         if($PID) {
            [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
               foreach(${_/\/=\/\/\/=\/=\_} in $PID) {
                  new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ProcessIdProperty), ${_/\/=\/\/\/=\/=\_}
               }
            )
            if(${/=======\_/\_/=\/}.Length -gt 1) {
               [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
            } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
               [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
            }         
         }
         if($ProcessName) {
            if($ProcessName -match "\\?|\\*|\\[") {
               [ScriptBlock[]]${/==\/\___/=\__/=\} += { $(foreach(${_/\/=\/\/\/=\/=\_} in $ProcessName){ (ps -id $_.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ProcessIdProperty)).ProcessName -like ${_/\/=\/\/\/=\/=\_} }) -contains $true } 
            } else {
               [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
                  foreach(${_/\/=\/\/\/=\/=\_} in ps -Name $ProcessName) {
                     new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ProcessIdProperty), ${_/\/=\/\/\/=\/=\_}.id
                  }
               )
               if(${/=======\_/\_/=\/}.Length -gt 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
               } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
               }               
            }
         }
         if($Name) {
            Write-Verbose "Name: $Name"
            if($Name -match "\\?|\\*|\\[") {
               [ScriptBlock[]]${/==\/\___/=\__/=\} += { $(foreach(${_/\___/=\____/=\_} in $Name){ $_.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::NameProperty) -like ${_/\___/=\____/=\_} }) -contains $true } 
            } else {
               [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
                  foreach(${_/\___/=\____/=\_} in $Name){
                     new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::NameProperty), ${_/\___/=\____/=\_}, "IgnoreCase"
                  }
               )
               if(${/=======\_/\_/=\/}.Length -gt 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
               } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
               }   
            }
         }
         if($ClassName) {
            if($ClassName -match "\\?|\\*|\\[") {
               [ScriptBlock[]]${/==\/\___/=\__/=\} += { $(foreach(${____/=\/\/==\_/\_} in $ClassName){ $_.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ClassNameProperty) -like ${____/=\/\/==\_/\_} }) -contains $true } 
            } else {
               [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
                  foreach(${____/=\/\/==\_/\_} in $ClassName){
                     new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ClassNameProperty), ${____/=\/\/==\_/\_}, "IgnoreCase"
                  }
               )
               if(${/=======\_/\_/=\/}.Length -gt 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
               } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
               }                  
            }
         }
         if($ControlType) {
            if($ControlType -match "\\?|\\*|\\[") {
               [ScriptBlock[]]${/==\/\___/=\__/=\} += { $(foreach(${____/=\/\/==\_/\_} in $ControlType){ $_.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ControlTypeProperty) -like ${____/=\/\/==\_/\_} }) -contains $true } 
            } else {
               [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
                  foreach(${____/=\/\/==\_/\_} in $ControlType){
                     new-object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ControlTypeProperty), ${____/=\/\/==\_/\_}
                  }
               )
               if(${/=======\_/\_/=\/}.Length -gt 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
               } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
               }                  
            }
         }
         if($PropertyValue) {
            ${__/\/=\_/\_/\/\_/} = $PropertyValue.Keys[0]
            ${__/\/\/\__/\__/==} = $PropertyValue.Values[0]
            if(${__/\/\/\__/\__/==} -match "\\?|\\*|\\[") {
               [ScriptBlock[]]${/==\/\___/=\__/=\} += { $(foreach(${____/=\/\/==\_/\_} in $PropertyValue.GetEnumerator()){
                  $_.GetCurrentPropertyValue(  
                     [System.Windows.Automation.AutomationElement].GetField(
                        ${____/=\/\/==\_/\_}.Key).GetValue(([system.windows.automation.automationelement]))
                  ) -like ${____/=\/\/==\_/\_}.Value }) -contains $true } 
            } else {
               [System.Windows.Automation.Condition[]]${/=======\_/\_/=\/} = $(
                  foreach(${____/=\/\/==\_/\_} in $PropertyValue.GetEnumerator()){
                     new-object System.Windows.Automation.PropertyCondition (
                        [System.Windows.Automation.AutomationElement].GetField(
                        ${____/=\/\/==\_/\_}.Key).GetValue(([system.windows.automation.automationelement]))), ${____/=\/\/==\_/\_}.Value
                  }
               )
               if(${/=======\_/\_/=\/}.Length -gt 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += New-Object System.Windows.Automation.OrCondition ${/=======\_/\_/=\/}
               } elseif(${/=======\_/\_/=\/}.Length -eq 1) {
                  [System.Windows.Automation.Condition[]]${/=\/\__/\/\___/\/} += ${/=======\_/\_/=\/}[0]
               }                  
            }
         }         
         
         if(${/=\/\__/\/\___/\/}.Length -gt 1) {
            [System.Windows.Automation.Condition]$condition = New-Object System.Windows.Automation.AndCondition ${/=\/\__/\/\___/\/}
         } elseif(${/=\/\__/\/\___/\/}) {
            [System.Windows.Automation.Condition]$condition = ${/=\/\__/\/\___/\/}[0]
         } else {
            [System.Windows.Automation.Condition]$condition = [System.Windows.Automation.Condition]::TrueCondition
         }
         
         If($VerbosePreference -gt "SilentlyContinue") {
         
            function ___/=\__/=\__/=\__ {
               param([Parameter(ValueFromPipeline=$true)]$condition, $indent = 0)
               process {
                  Write-Debug ($Condition | fl *  | Out-String)               
                  if($condition -is [System.Windows.Automation.AndCondition] -or $condition -is [System.Windows.Automation.OrCondition]) {
                     Write-Verbose ((" "*$indent) + $Condition.GetType().Name )
                     $condition.GetConditions().GetEnumerator() | ___/=\__/=\__/=\__ -Indent ($Indent+4)
                  } elseif($condition -is [System.Windows.Automation.PropertyCondition]) {
                     Write-Verbose ((" "*$indent) + $Condition.Property.ProgrammaticName + " = '" + $Condition.Value + "' (" + $Condition.Flags + ")")
                  } else {
                     Write-Verbose ((" "*$indent) + $Condition.GetType().Name + " where '" + $Condition.Value + "' (" + $Condition.Flags + ")")
                  }
               }
            }
         
            Write-Verbose "CONDITIONS ============="
            ${global:_/\_/\___/\/===\_} = $condition
            foreach(${____/=\/\/==\_/\_} in $condition) {            
               ___/=\__/=\__/=\__ ${____/=\/\/==\_/\_}
            }
            Write-Verbose "============= CONDITIONS"
         }
         
         if(${/==\/\___/=\__/=\}.Count -gt 0) {
            ${/===\__/===\/\/\_} = $Parent.FindAll( ${/==\/=\/=\/\/====}, $condition ) | ? { ${___/==\__/\/==\_/} = $_;  foreach(${/=\/\/==\/\_/\_/=} in ${/==\/\___/=\__/=\}) { ${___/==\__/\/==\_/} = ${___/==\__/\/==\_/} | Where ${/=\/\/==\/\_/\_/=} }; ${___/==\__/\/==\_/} }
         } else {
            ${/===\__/===\/\/\_} = $Parent.FindAll( ${/==\/=\/=\/\/====}, $condition )
         }
      }  
   }
   
   Write-Verbose "Element Count: $(@(${/===\__/===\/\/\_}).Count)"
   if(${/===\__/===\/\/\_}) {
      foreach(${__/=\___/=\/=====} in ${/===\__/===\/\/\_}) {
         if($Bare) {
            echo ${__/=\___/=\/=====}
         } else {
            ${/===\_/=\/=\/==\_} = New-Object PSObject ${__/=\___/=\/=====}
            foreach(${/==\_/=\__/\_/\__} in ${/===\_/=\/=\/==\_}.GetSupportedProperties() | Sort ProgrammaticName)
            {
               
               ${/==\___/=\/==\_/\} = [System.Windows.Automation.Automation]::PropertyName(${/==\_/=\__/\_/\__})
               Add-Member -InputObject ${/===\_/=\/=\/==\_} -Type ScriptProperty -Name ${/==\___/=\/==\_/\} -Value ([ScriptBlock]::Create( "`$this.GetCurrentPropertyValue( [System.Windows.Automation.AutomationProperty]::LookupById( $(${/==\_/=\__/\_/\__}.Id) ))" )) -EA 0
            }
            foreach(${/=\_/\/====\_/\__} in ${/===\_/=\/=\/==\_}.GetSupportedPatterns()| Sort ProgrammaticName)
            {
               Add-Member -InputObject ${/===\_/=\/=\/==\_} -Type ScriptProperty -Name (${/=\_/\/====\_/\__}.ProgrammaticName.Replace("PatternIdentifiers.Pattern","") + "Pattern") -Value ([ScriptBlock]::Create( "`$this.GetCurrentPattern( [System.Windows.Automation.AutomationPattern]::LookupById( '$(${/=\_/\/====\_/\__}.Id)' ) )" )) -EA 0
            }
            echo ${/===\_/=\/=\/==\_}
         }
      }
   }
}

}

Export-ModuleMember -cmdlet * -Function * -Alias *





































