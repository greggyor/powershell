﻿function New-Struct {
#.Synopsis
#   Creates Struct types from a list of types and properties
#.Description
#   A wrapper for Add-Type to create struct types.
#.Example
#   New-Struct Song { 
#   [string]$Artist
#   [string]$Album
#   [string]$Name
#   [TimeSpan]$Length
#   } -CreateConstructorFunction
#
#   Description
#   -----------
#   Creates a "Song" type with strongly typed Artist, Album, Name, and Length properties, with a simple constructor and a constructor function
#.Example
#   New-Struct @{
#   >> Product  = { [string]$Name; [double]$Price; }
#   >> Order    = { [Guid]$Id; [Product]$Product; [int]$Quantity }
#   >> Customer = { 
#   >>   [string]$FirstName
#   >>   [string]$LastName
#   >>   [int]$Age
#   >>   [Order[]]$OrderHistory
#   >> }
#   >> }
#   >>
#
#   Description
#   -----------
#   To create a series of related struct types (where one type is a property of another type), you need to use the -Types hashtable parameter set.  That way, all of the types will compiled together at once, so the compiler will be able to find them all.
#
[CmdletBinding(DefaultParameterSetName="Multiple")]
param(
    # The name of the TYPE you are creating. Must be unique per PowerShell session.
    [ValidateScript({
        if($_ -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBbAGEALQB6AF0AWwBhAC0AegAxAC0AOQBfAF0AKgAkAA==')))) {
            throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JwAkAF8AJwAgAGkAcwAgAGkAbgB2AGEAbABpAGQALgAgAEEAIAB2AGEAbABpAGQAIABuAGEAbQBlACAAaQBkAGUAbgB0AGkAZgBpAGUAcgAgAG0AdQBzAHQAIABzAHQAYQByAHQAIAB3AGkAdABoACAAYQAgAGwAZQB0AHQAZQByACwAIABhAG4AZAAgAGMAbwBuAHQAYQBpAG4AIABvAG4AbAB5ACAAYQBsAHAAaABhAC0AbgB1AG0AZQByAGkAYwAgAG8AcgAgAHQAaABlACAAdQBuAGQAZQByAHMAYwBvAHIAZQAgACgAXwApAC4A')))
        }
        return $true             
    })]
    [Parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ParameterSetName = "Single")]
    [string]$Name
,
    # A Scriptblock full of "[Type]$Name" definitions to show what properties you want on your Struct type
    [Parameter(Position=1, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ParameterSetName = "Single")]
    [ScriptBlock]$Property
,
    # A Hashtable in the form @{Name={Properties}} with multiple Names and Property Scriptblocks to define related structs (see example 2).
    [Parameter(Position=0, Mandatory=$true, ParameterSetName = "Multiple")]
    [HashTable]$Types
,
    # Generate a New-StructName shortcut function for each New-Object StructName
    [Alias("CTorFunction","ConstructorFunction")]
    [Switch]$CreateConstructorFunction
,
    # Output the defined type(s)
    [Switch]$PassThru
)
begin {
    if($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB1AGwAdABpAHAAbABlAA==')))) {
        ${15} = foreach(${16} in $Types.Keys) {
            New-Object PSObject -Property @{Name=${16};Property=$Types.${16}}
        }
        Write-Verbose (${15} | Out-String)
        ${15} | New-Struct -Passthru:$Passthru -CreateConstructorFunction:$CreateConstructorFunction
    } else {
        ${2} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGkAbgBnACAAUwB5AHMAdABlAG0AOwAKAHUAcwBpAG4AZwAgAFMAeQBzAHQAZQBtAC4AQwBvAGwAbABlAGMAdABpAG8AbgBzADsACgB1AHMAaQBuAGcAIABTAHkAcwB0AGUAbQAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBBAHUAdABvAG0AYQB0AGkAbwBuADsACgA=')))
        ${1} = ""
    }
}
process {
if($PSCmdlet.ParameterSetName -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB1AGwAdABpAHAAbABlAA==')))) {
${14} = $null
${13} = [System.Management.Automation.PSParser]::Tokenize( $Property, [ref]${14} ) | ? { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcAbABpAG4AZQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAdABlAG0AZQBuAHQAUwBlAHAAYQByAGEAdABvAHIA'))) -notcontains $_.Type }

# CODE GENERATION MAGIKS!
$Name = $Name.ToUpper()[0] + $Name.SubString(1)
${8} = @()
${7} = @()
${9} = @()
${3} = @()
${5} = @()
${6} = @()
${4} = @()

$(while(${13}.Count -gt 0) {
    $typeToken,$varToken,${13} = ${13}
    if($typeToken.Type -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB5AHAAZQA=')))) {
        throw "Syntax error on line $($typeToken.StartLine) Column $($typeToken.Start). Missing Type. The Struct Properties block must contain only statements of the form: [Type]`$Name, see Get-Help New-Struct -Parameter Properties.`n$($typeToken | Out-String)"
    } elseif($varToken.Type -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBhAHIAaQBhAGIAbABlAA==')))) {
        throw "Syntax error on line $($varToken.StartLine) Column $($varToken.Start). Missing Name. The Struct Properties block must contain only statements of the form: [Type]`$Name, see Get-Help New-Struct -Parameter Properties.`n$($typeToken | Out-String)"
    }

    ${10} = $varToken.Content.ToUpper()[0] + $varToken.Content.SubString(1)
    ${12} = ${10}.ToLower()[0] + ${10}.SubString(1)
    try {
        Write-Verbose "TypeToken: $($typeToken.Content) ${10}"
        if($PSVersionTable.PSVersion.Major -lt 3) {
            ${11} = iex "[$($typeToken.Content)].FullName"
        } else {
            ${11} = iex "$($typeToken.Content).FullName"
        }            
    } catch {
        ## It's probably a reference to another struct, so just put the name in
        if($PSVersionTable.PSVersion.Major -lt 3) {
            ${11} = $typeToken.Content
        } else {
            ${11} = $typeToken.Content -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAFsAKAAuACoAKQBcAFwAXQA='))),'$1'
        }
    }
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB5AHAAZQAgAE4AYQBtAGUAOgAgACQAewAxADEAfQAgACQAewAxADAAfQA=')))
    
    ${9} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAcAB1AGIAbABpAGMAIAB7ADAAfQAgAHsAMQB9ADsA'))) -f ${11},${10}
    ${7} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAewAwAH0AIAA9ACAAewAxAH0AOwA='))) -f ${10},${12}
    ${8} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AIAB7ADEAfQA='))) -f ${11},${12}
    ${5} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAaQBmACgAaQBuAHAAdQB0AC4AUAByAG8AcABlAHIAdABpAGUAcwBbACIAewAwAH0AIgBdACAAIQA9ACAAbgB1AGwAbAApAHsAewAgAG8AdQB0AHAAdQB0AC4AewAwAH0AIAA9ACAAKAB7ADEAfQApAGkAbgBwAHUAdAAuAFAAcgBvAHAAZQByAHQAaQBlAHMAWwAiAHsAMAB9ACIAXQAuAFYAYQBsAHUAZQA7ACAAfQB9AA=='))) -f ${10},${11}
    ${6} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAaQBmACgAaABhAHMAaAAuAEMAbwBuAHQAYQBpAG4AcwBLAGUAeQAoACIAewAwAH0AIgApACkAewB7ACAAbwB1AHQAcAB1AHQALgB7ADAAfQAgAD0AIAAoAHsAMQB9ACkAaABhAHMAaABbACIAewAwAH0AIgBdADsAIAB9AH0A'))) -f ${10},${11}
    ${4} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IgB7ADAAfQAgAD0AIABbAHsAMQB9AF0AXABcACIAIgAgACsAIAB7ADAAfQAuAFQAbwBTAHQAcgBpAG4AZwAoACkAIAArACAAIgBcAFwAIgAiAA=='))) -f ${10}, ${11}
    if($CreateConstructorFunction) {
        ${3} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB7ADAAfQBdACQAewAxAH0A'))) -f ${11},${10}
    }
})

${2} += @"
public struct $Name {
$(${9} -join "`n")
   public $Name ($( ${8} -join ","))
   {
$(${7} -join "`n")
   }
   public static implicit operator $Name(Hashtable hash)
   {
      $Name output = new $Name();
$(${6} -join "`n")
      return output;
   }
   public static implicit operator $Name(PSObject input)
   {
      $Name output = new $Name();
$(${5} -join "`n")
      return output;
   }
   
   public override string ToString()
   {
      return "@{" + $(${4} -join $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAArACAAIgA7ACAAIgAgACsAIAA=')))) + "}";
   }
}

"@

if($CreateConstructorFunction) {
${1} += @"
Function global:New-$Name {
[CmdletBinding()]
param(
$( ${3} -join ",`n" )
)
New-Object $Name -Property `$PSBoundParameters
}

"@
}

}}
end {
if($PSCmdlet.ParameterSetName -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB1AGwAdABpAHAAbABlAA==')))) {
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwAjACAAQwBvAGQAZQA6AAoAJAB7ADIAfQA=')))
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAHcAZQByAFMAaABlAGwAbAAgAEMAbwBkAGUAOgAKACQAewAxAH0A')))

    Add-Type -TypeDefinition ${2} -PassThru:$Passthru -ErrorAction Stop
    if($CreateConstructorFunction) {
        iex ${1}
    }
}}}

