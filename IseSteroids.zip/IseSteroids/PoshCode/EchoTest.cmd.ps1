﻿@Echo 00: %0 
@Echo 01: %1 
@Echo 02: %2 
@Echo 03: %3 
@Echo 04: %4 
@Echo 05: %5 
@Echo 06: %6 
@Echo 07: %7 
@Echo 08: %8 
@Echo 09: %9 
@Echo All together, it looked like this to DOS:
@Echo %0 %*
