﻿
[CmdletBinding()]
PARAM (
	[Parameter(Mandatory=$true,ValueFromPipeline=$true)][string]$bounceAddress
)
BEGIN
{
	Add-Type -AssemblyName System.Web|Out-Null
}
PROCESS
{
	if($_) {$bounceAddress = $_}
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQAyAEIA'))),"%" 
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQAzAEQA'))),"="
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACsA'))),"%"
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBPAD0A'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBPAD0A')))
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBPAFUAPQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBPAFUAPQA=')))
	$bounceAddress = $bounceAddress -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBDAE4APQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBDAE4APQA=')))
	if([Web.HttpUtility]::UrlDecode($bounceAddress) -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAAvAG8APQAuACoAKQBAAFsAXABcAHcAXABcAGQALgBdACsAJAA=')))){$matches[1]}
}
