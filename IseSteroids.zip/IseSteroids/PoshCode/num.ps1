﻿## SVN STAT colorizer - http://www.overset.com/2008/11/18/colorized-subversion-svn-stat-powershell-function/
function ss () {
	${_/===\/=\/=\/\___} = @{ "A"="Magenta"; "D"="Red"; "C"="Yellow"; "G"="Blue"; "M"="Cyan"; "U"="Green"; "?"="DarkGray"; "!"="DarkRed" }
	foreach ( ${___/\/\_/\_/\_/\/} in svn stat ) {  
		if ( ${_/===\/=\/=\/\___}.ContainsKey(${___/\/\_/\_/\_/\/}.ToString().SubString(0,1).ToUpper()) ) { 
			write-host ${___/\/\_/\_/\_/\/} -Fore ${_/===\/=\/=\/\___}.Get_Item(${___/\/\_/\_/\_/\/}.ToString().SubString(0,1).ToUpper()).ToString()
		} else { 
			write-host ${___/\/\_/\_/\_/\/}
		}
	}
}
