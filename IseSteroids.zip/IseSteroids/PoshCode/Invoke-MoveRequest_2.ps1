﻿





















Add-PSSnapin Quest.ActiveRoles.ADManagement
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010


${____/=\/\/\/=\/==} = "Mailbox Database A"
${_/\/=\___/\_/\_/\} = "domain.com"
${__/==\/\/\___/\/=}="DomainA.local"
${/==\/=\_/==\_/\/=}="domainB.local"
${/=\__/=\/\/====\/} = "dc-01.domainB.local"
${____/\/\/\/===\/=} = Get-Credential -Credential "Domain\\SourceForestAdministrator"


Connect-QADService -Service ${/==\/=\_/==\_/\/=} | Out-Null
${/=\_/\/\/\__/\__/} = Get-QADUser -SearchRoot "DomainA.local/Department A/Users"


foreach (${___/====\/=\____/} in ${/=\_/\/\/\__/\__/}) {

Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AYwBlAHMAcwBpAG4AZwAgAHUAcwBlAHIAIAAkAHsAXwBfAF8ALwA9AD0APQA9AFwALwA9AFwAXwBfAF8AXwAvAH0A'))) -ForegroundColor Yellow


Connect-QADService -Service ${/==\/=\_/==\_/\/=} | Out-Null
${_____/\/\/\/=\_/=}=${___/====\/=\____/}.samaccountname
${/=\_/\_/=\/\/\_/\}=Get-QADUser ${_____/\/\/\/=\_/=} -IncludeAllProperties
${__/\_/===\_/\/=\/}=${/=\_/\_/=\/\/\_/\}.Mail
${/====\______/\/\_}=${/=\_/\_/=\/\/\_/\}.mailNickname
[byte[]]${____/=\_/\/\_/=\/}=(Get-QADuser ${/=\_/\_/=\/\/\_/\} -IncludedProperties msExchMailboxGUID -DontConvertValuesToFriendlyRepresentation).msExchMailboxGUID
${/\______/\/===\/=}="-2147483642"
${/==\__/\/\_/\_/==}="128"
${__/\/\__/\__/=\_/}=${/=\_/\_/=\/\/\_/\}.msExchUserCulture
${/===\_/\/\/\_/\/\}="44220983382016"
${_/==\_/\__/=\/=\_}=${/=\_/\_/=\/\/\_/\}.proxyAddresses
${__/=\/\/\/===\__/}=${/=\_/\_/=\/\/\_/\}.Mail
${__/\/\/==\__/=\/=}=514


Connect-QADService -Service ${__/==\/\/\___/\/=} | Out-Null
Set-QADUser -Identity ${_____/\/\/\/=\_/=} -ObjectAttributes @{mail=${__/\_/===\_/\/=\/};mailNickname=${/====\______/\/\_};msExchMailboxGUID=${____/=\_/\/\_/=\/};msExchRecipientDisplayType=${/\______/\/===\/=};msExchRecipientTypeDetails=${/==\__/\/\_/\_/==};msExchUserCulture=${__/\/\__/\__/=\_/};msExchVersion=${/===\_/\/\/\_/\/\};proxyAddresses=${_/==\_/\__/=\/=\_};targetAddress=${__/=\/\/\/===\__/};userAccountControl=${__/\/\/==\__/=\/=}} | Out-Null


Get-MailUser ${_____/\/\/\/=\_/=} | Update-Recipient


New-MoveRequest -Identity ${_____/\/\/\/=\_/=} -RemoteLegacy -TargetDatabase ${____/=\/\/\/=\/==} -RemoteGlobalCatalog ${/=\__/=\/\/====\/} -RemoteCredential ${____/\/\/\/===\/=} -TargetDeliveryDomain ${_/\/=\___/\_/\_/\}


Enable-QADUser -Identity ${_____/\/\/\/=\_/=} | Out-Null
Set-QADUser -Identity ${_____/\/\/\/=\_/=} -UserMustChangePassword $false | Out-Null
}
