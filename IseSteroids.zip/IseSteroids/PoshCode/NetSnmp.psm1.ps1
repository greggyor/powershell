﻿#requires -version 2
${/===\/==\/===\_/\} = Join-Path $env:programfiles $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHQALQBTAE4ATQBQAFwAXABiAGkAbgA=')))
	if ( -not ( Test-Path "${/===\/==\/===\_/\}\\snmpwalk.exe" ) ) {
		Throw "Net-SNMP binaries not found in ${/===\/==\/===\_/\}. Please install to this folder `
			or edit the NetSnmp variable as appropriate."
	}

# Modeled after SNMPWALK http://www.net-snmp.org/docs/man/snmpwalk.html
function Get-SnmpValue {
	param (
		[Parameter( Position = 0, Mandatory = $true )] $Agent,
		[Parameter( Position = 1, Mandatory = $true )] $OID,
		$Port = 161,
		$Community = "public",
		$Version = "2c"
	)
	&"${/===\/==\/===\_/\}\\snmpwalk.exe" "-v$Version" "-c$Community" "${Agent}:$Port" "$OID"
}
