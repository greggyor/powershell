﻿
#Check if PowerShell version 3 or higher is installed
if($host.Version.Major -lt 3)
{
 Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAHcAZQByAFMAaABlAGwAbAAgAFYAZQByAHMAaQBvAG4AIAAzACAAbwByACAAaABpAGcAaABlAHIAIABuAGUAZQBkAHMAIAB0AG8AIABiAGUAIABpAG4AcwB0AGEAbABsAGUAZAA=')))  -ForegroundColor Red
 Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgAE0AYQBuAGEAZwBlAG0AZQBuAHQAIABGAHIAYQBtAGUAdwBvAHIAawAgADMALgAwACAALQAgAFIAQwA=')))  -ForegroundColor Magenta
 Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB3AHcAdwAuAG0AaQBjAHIAbwBzAG8AZgB0AC4AYwBvAG0ALwBlAG4ALQB1AHMALwBkAG8AdwBuAGwAbwBhAGQALwBkAGUAdABhAGkAbABzAC4AYQBzAHAAeAA/AGkAZAA9ADIAOQA5ADMAOQA=')))  -ForegroundColor Magenta
 Break
}

