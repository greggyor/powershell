﻿













function New-CodeSigningCertificate {
[CmdletBinding()]
	param(
		[Security.Cryptography.X509Certificates.X500DistinguishedName]$Subject = "CN=PowerGUI User",
		[ValidateSet(1024,2048)]
		[int]$KeyLength = 2048,
		[DateTime]$ValidFrom = [datetime]::Now,
		[DateTime]$ValidTo = [datetime]::Now.AddYears(1)
	)
${01010100000011000} = @"
[DllImport("advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptAcquireContext(
   ref IntPtr phProv,
   string pszContainer,
   string pszProvider,
   uint dwProvType,
   Int64 dwFlags
);
[DllImport("advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptReleaseContext(
	IntPtr phProv,
	int flags
);
[DllImport("advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptGenKey(
	IntPtr phProv,
	int Algid,
	int dwFlags,
	ref IntPtr phKey
);
[DllImport("Crypt32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptExportPublicKeyInfo(
	IntPtr phProv,
	int dwKeySpec,
	int dwCertEncodingType,
	IntPtr pbInfo,
	ref int pcbInfo
);
[DllImport("Crypt32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptHashPublicKeyInfo(
	IntPtr phProv,
	int Algid,
	int dwFlags,
	int dwCertEncodingType,
	IntPtr pInfo,
	IntPtr pbComputedHash,
	ref int pcbComputedHash
);
[DllImport("Crypt32.dll", SetLastError=true)]
public static extern bool CryptEncodeObject(
	int dwCertEncodingType,
	[MarshalAs(UnmanagedType.LPStr)]string lpszStructType,
	ref CRYPTOAPI_BLOB pvStructInfo,
	byte[] pbEncoded,
	ref int pcbEncoded
);

[DllImport("Crypt32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern IntPtr CertCreateSelfSignCertificate(
	IntPtr phProv,
	CRYPTOAPI_BLOB pSubjectIssuerBlob,
	int flags,
	CRYPT_KEY_PROV_INFO pKeyProvInfo,
	IntPtr pSignatureAlgorithm,
	SystemTime pStartTime,
	SystemTime pEndTime,
	CERT_EXTENSIONS pExtensions
);
[DllImport("advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool CryptDestroyKey(
	IntPtr cryptKeyHandle
);
[DllImport("kernel32.dll", CharSet=CharSet.Auto, SetLastError=true)]
public static extern bool FileTimeToSystemTime(
	[In] ref long fileTime,
	out SystemTime SystemTime
);

[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CRYPT_KEY_PROV_INFO {
	public string pwszContainerName;
	public string pwszProvName;
	public int dwProvType;
	public int dwFlags;
	public int cProvParam;
	public IntPtr rgProvParam;
	public int dwKeySpec;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CERT_EXTENSIONS {
	public int cExtension;
	public IntPtr rgExtension;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CERT_EXTENSION {
	[MarshalAs(UnmanagedType.LPStr)]public String pszObjId;
	public Boolean fCritical;
	public CRYPTOAPI_BLOB Value;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CERT_BASIC_CONSTRAINTS2_INFO {
	public Boolean fCA;
	public Boolean fPathLenConstraint;
	public int dwPathLenConstraint;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CRYPTOAPI_BLOB {
	public int cbData;
	public IntPtr pbData;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CRYPT_BIT_BLOB {
	public uint cbData;
	public IntPtr pbData;
	public uint cUnusedBits;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CERT_PUBLIC_KEY_INFO {
	public CRYPT_ALGORITHM_IDENTIFIER Algorithm;
	public CRYPT_BIT_BLOB PublicKey;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct CRYPT_ALGORITHM_IDENTIFIER {
	[MarshalAs(UnmanagedType.LPStr)]public String pszObjId;
	public CRYPTOAPI_BLOB Parameters;
}
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
public struct SystemTime {
	public short Year;
	public short Month;
	public short DayOfWeek;
	public short Day;
	public short Hour;
	public short Minute;
	public short Second;
	public short Milliseconds;
}
"@
	Add-Type -MemberDefinition ${01010100000011000} -Namespace Quest -Name PowerGUI
	${10000100010111011} = [Guid]::NewGuid().ToString()
	[IntPtr]${00010001110110101} = [IntPtr]::Zero
	${10011110101000101} = "Microsoft Base Cryptographic Provider v1.0"
	${01100100001010011} = [Quest.PowerGUI]::CryptAcquireContext([ref]${00010001110110101},${10000100010111011},${10011110101000101},0x1,0x8)
	if (!${01100100001010011}) {Write-Warning "Unable to create provider context!"; return}
	[IntPtr]${00111011101110101} = [IntPtr]::Zero
	if ($KeyLength -eq 2048) {
		${01100100001010011} = [Quest.PowerGUI]::CryptGenKey(${00010001110110101},2,0x08000001,[ref]${00111011101110101})
	} else {
		${01100100001010011} = [Quest.PowerGUI]::CryptGenKey(${00010001110110101},2,0x04000001,[ref]${00111011101110101})
	}
	if (!${01100100001010011}) {Write-Warning "Unable to create key context!"; return}
	${01101011000111001} = [Runtime.InteropServices.GCHandle]::Alloc($Subject.RawData,"pinned")
	${10001011011111010} = New-Object Quest.PowerGUI+CRYPTOAPI_BLOB -Property @{
		cbData = $Subject.RawData.Count;
		pbData = ${01101011000111001}.AddrOfPinnedObject()
	}
	${10100101100101110} = New-Object Quest.PowerGUI+CRYPT_KEY_PROV_INFO -Property @{
		pwszContainerName = ${10000100010111011};
		pwszProvName = ${10011110101000101};
		dwProvType = 1;
		dwKeySpec = 2
	}
	${01011110101110011} = New-Object Security.Cryptography.X509Certificates.X509ExtensionCollection
	
	[void]${01011110101110011}.Add((New-Object Security.Cryptography.X509Certificates.X509BasicConstraintsExtension $false,$false,0,$false))
	
	${10111111110011001} = New-Object Security.Cryptography.OidCollection
	[void]${10111111110011001}.Add("code signing")
	[void]${01011110101110011}.Add((New-Object Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension -ArgumentList ${10111111110011001}, $false))
	
	${00100111100000010} = 0
	if (([Quest.PowerGUI]::CryptExportPublicKeyInfo(${00010001110110101},2,1,[IntPtr]::Zero,[ref]${00100111100000010}))) {
		${00000100011111111} = [Runtime.InteropServices.Marshal]::AllocHGlobal(${00100111100000010})
		${01001011111110000} = [Quest.PowerGUI]::CryptExportPublicKeyInfo(${00010001110110101},2,1,${00000100011111111},[ref]${00100111100000010})
		${01001111111101110} = 0
		if (([Quest.PowerGUI]::CryptHashPublicKeyInfo([IntPtr]::Zero,0x00008004,0,1,${00000100011111111},[IntPtr]::Zero,[ref]${01001111111101110}))) {
			${10001101011101101} = [Runtime.InteropServices.Marshal]::AllocHGlobal(${01001111111101110})
			[void][Quest.PowerGUI]::CryptHashPublicKeyInfo([IntPtr]::Zero,0x00008004,0,1,${00000100011111111},${10001101011101101},[ref]${01001111111101110})
			${10001101010010100} = 0
			${00111000001010000} = New-Object Quest.PowerGUI+CRYPTOAPI_BLOB -Property @{
				cbData = ${01001111111101110};
				pbData = ${10001101011101101}
			}
			${10001101010010100} = 0
			if (([Quest.PowerGUI]::CryptEncodeObject(1,"2.5.29.14",[ref]${00111000001010000},$null,[ref]${10001101010010100}))) {
				${10010100110000111} = New-Object byte[] -ArgumentList ${10001101010010100}
				${01001011111110000} = [Quest.PowerGUI]::CryptEncodeObject(1,"2.5.29.14",[ref]${00111000001010000},${10010100110000111},[ref]${10001101010010100})
				${01101000011001101} = New-Object Security.Cryptography.AsnEncodedData -ArgumentList "2.5.29.14", ${10010100110000111}
				[void]${01011110101110011}.Add((New-Object Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension -ArgumentList ${01101000011001101}, $false))
			}
		}
	}
	
	[void]${01011110101110011}.Add((New-Object Security.Cryptography.X509Certificates.X509KeyUsageExtension -ArgumentList "DigitalSignature", $true))
	
	${00111100010010101} = @()
	foreach (${10000101011010000} in ${01011110101110011}) {
		${00111000010001000} = New-Object Quest.PowerGUI+CERT_EXTENSION
		${00111000010001000}.pszObjId = ${10000101011010000}.Oid.Value
		${00111000010001000}.fCritical = ${10000101011010000}.Critical
		${01111100101111010} = New-Object Quest.PowerGUI+CRYPTOAPI_BLOB
		${01111100101111010}.cbData = ${10000101011010000}.RawData.Length
		${01111100101111010}.pbData = [Runtime.InteropServices.Marshal]::AllocHGlobal(${01111100101111010}.cbData)
		[Runtime.InteropServices.Marshal]::Copy(${10000101011010000}.RawData,0,${01111100101111010}.pbData,${01111100101111010}.cbData)
		${00111000010001000}.Value = ${01111100101111010}
		${00111100010010101} += ${00111000010001000}
	}
	${10011000001000101} = New-Object Quest.PowerGUI+CERT_EXTENSIONS
	${01100110011010001} = [Runtime.InteropServices.Marshal]::SizeOf([Quest.PowerGUI+CERT_EXTENSION]) * ${01011110101110011}.Count
	${10011000001000101}.cExtension = ${01011110101110011}.Count
	${10011000001000101}.rgExtension = [Runtime.InteropServices.Marshal]::AllocHGlobal(${01100110011010001})
	for (${00000100011000110} = 0; ${00000100011000110} -lt ${01011110101110011}.Count; ++${00000100011000110}) {
		${01110111010010100} = ${00000100011000110} * [Runtime.InteropServices.Marshal]::SizeOf([Quest.PowerGUI+CERT_EXTENSION])
		${01010101000011001} = ${01110111010010100} + ${10011000001000101}.rgExtension.ToInt64()
		[IntPtr]${10111101000010100} = New-Object IntPtr ${01010101000011001}
		[Runtime.InteropServices.Marshal]::StructureToPtr(${00111100010010101}[${00000100011000110}],${10111101000010100},$false)
	}
	${01001011111001101} = New-Object Quest.PowerGUI+SystemTime
	[void][Quest.PowerGUI]::FileTimeToSystemTime([ref]$ValidFrom.ToFileTime(),[ref]${01001011111001101})
	${01111100100111001} = New-Object Quest.PowerGUI+SystemTime
	[void][Quest.PowerGUI]::FileTimeToSystemTime([ref]$ValidTo.ToFileTime(),[ref]${01111100100111001})
	${01101111000001110} = [Quest.PowerGUI]::CertCreateSelfSignCertificate(${00010001110110101},${10001011011111010},0,${10100101100101110},[IntPtr]::Zero,${01001011111001101},${01111100100111001},${10011000001000101})
	if (!${01101111000001110}.Equals([IntPtr]::Zero)) {
		New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList ${01101111000001110}
	}
	
	foreach (${10011001000000011} in ${00111100010010101}) {
		[void][Runtime.InteropServices.Marshal]::FreeHGlobal(${10011001000000011}.Value.pbData)
	}
	[void][Runtime.InteropServices.Marshal]::FreeHGlobal(${10011000001000101}.rgExtension)
	[void][Runtime.InteropServices.Marshal]::FreeHGlobal(${00000100011111111})
	[void][Runtime.InteropServices.Marshal]::FreeHGlobal(${10001101011101101})
	[void]${01101011000111001}.Free()
	[void][Quest.PowerGUI]::CryptDestroyKey(${00111011101110101})
	[void][Quest.PowerGUI]::CryptReleaseContext(${00010001110110101},0)
}
