﻿ 


$VC = "vc.domain.local" 
$SMTPServer = "192.168.1.100" 
$SendersAddress = "noreply@domain.com" 
$SavedCredentialsFile = "C:\\path\\file.txt" 
$CompanyLogo = "http://placehold.it/150x50"

function Out-LogFile {
	
	[CmdletBinding(DefaultParameterSetName='Message')]
	param(
		[Parameter(ParameterSetName='Message',
		Position=0,
		ValueFromPipeline=$true)]				
		[object[]]$Message,
		[Parameter(ParameterSetName='Message')]
		[string]$LogFile = $global:DefaultLogPath,
		[Parameter(ParameterSetName='Message')]
		[int]$BlankLine = 0,		
		[switch]$WriteHost = $global:WriteHostPreference,
		[string]$Severity = "I",
		[Parameter(ParameterSetName='Message')]
		[switch]$DontFormat,		
		[Parameter(ParameterSetName='Message')]
		[string]$DateFormat = "dd-MM-yyyy HH:mm:ss",		
		
		[string]$Title,		
		[System.ConsoleColor]$ForegroundColor = $host.UI.RawUI.ForegroundColor,		
		[System.ConsoleColor]$BackgroundColor = $host.UI.RawUI.BackgroundColor,
		[ValidateSet('unicode', 'utf7', 'utf8', 'utf32', 'ascii', 'bigendianunicode', 'default', 'oem')]		
		[string]$Encoding = 'Unicode',
		[switch]$Force
	)
	
	begin { 		
		Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAIABGAGkAbABlADoAIAAkAEwAbwBnAEYAaQBsAGUA')))
		if ( -not $LogFile ) { Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAAtAEwAbwBnAEYAaQBsAGUAIABwAGEAcgBhAG0AZQB0AGUAcgAgAG0AdQBzAHQAIABiAGUAIABkAGUAZgBpAG4AZQBkACAAbwByACAAJABnAGwAbwBiAGEAbAA6AEwAbwBnAEYAaQBsAGUAIABtAHUAcwB0ACAAYgBlACAAcwBlAHQALgA='))); break}		
		if ( -not (Test-Path $LogFile) ) { New-Item -Path $LogFile -ItemType File -Force | Out-Null }
		if ( -not (Test-Path $LogFile) ) { Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAIABmAGkAbABlACAAYwBhAG4AIABuAG8AdAAgAGIAZQAgAGYAbwB1AG4AZAA6ACAAJABMAG8AZwBGAGkAbABlAC4A'))); break}
		
		if ( $Title ) {			
			$text = $Title
			$Title = $null
			Out-LogFile -BlankLine 1 -LogFile $LogFile -WriteHost:$WriteHost -Force:$Force -Encoding $Encoding
			Out-LogFile -Message $text -BlankLine 1 -DontFormat -LogFile $LogFile -WriteHost:$WriteHost -Force:$Force -Encoding $Encoding 									
		}
	}
	process {
		
		if ( $Message ) { 	
			$text = $Message
			foreach ( $text in $Message ) {
				if ( -not $DontFormat ) { $text = "$(($Severity).ToUpper()): $(Get-Date -Format $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABEAGEAdABlAEYAbwByAG0AYQB0AA=='))))" + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgAgACQAdABlAHgAdAA='))) }									
				if ($WriteHost) { Write-Host $text -BackgroundColor $BackgroundColor -ForegroundColor $ForegroundColor}
				$text | Out-File -FilePath $LogFile -Force:$Force -Encoding $Encoding -Append
			}		
		}
		
		if ( $BlankLine -gt 0 ){
			for ($i = 0; $i -lt $BlankLine; $i++ ) { 
				"" | Out-File -FilePath $LogFile -Force:$Force -Encoding $Encoding -Append
				if ($WriteHost) { Write-Host "" -BackgroundColor $BackgroundColor -ForegroundColor $ForegroundColor }
			}
		}
	}
	end {
	}
}



$nl = [Environment]::NewLine



$key = [byte]57,86,59,11,72,75,18,52,73,46,0,21,56,76,47,12 
$VCCred = Import-Csv $SavedCredentialsFile 
$VCCred.Password = ($VCCred.Password| ConvertTo-SecureString -Key $key)
$VCCred = (New-Object -typename System.Management.Automation.PSCredential -ArgumentList $VCCred.Username,$VCCred.Password)




if ($args[0] -eq $null) 
	{ Throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZABhAHQAYQBmAGkAbABlACAAcwB1AHAAcABsAGkAZQBkACwAIABzAHUAcABwAGwAeQAgAHAAYQB0AGgAIAB0AG8AIABkAGEAdABhAGYAaQBsAGUAIABhAHMAIABhAG4AIABhAHIAZwB1AG0AZQBuAHQAIAB0AG8AIAB0AGgAZQAgAHMAYwByAGkAcAB0ACEAIABlAC4AZwAgAC4AXABcAFMAQwBSAEkAUABUAC4AcABzADEAIABEAEEAVABBAEYASQBMAEUALgB0AHgAdAAgACQAbgBsACAAVABvACAAYwByAGUAYQB0AGUAIABhACAAZABhAHQAYQBmAGkAbABlACwAIAB0AGgAZQAgAGYAaQByAHMAdAAgAGwAaQBuAGUAIABvAGYAIAB0AGgAZQAgAGQAYQB0AGEAZgBpAGwAZQAgAHMAaABvAHUAbABkACAAYgBlACAAYQBuACAAZQBtAGEAaQBsACAAYQBkAGQAcgBlAHMAcwAsACAAZQBhAGMAaAAgAHMAdQBiAHMAZQBxAGUAbgBlAHQAIABsAGkAbgBlACAAcwBoAG8AdQBsAGQAIABiAGUAIABhACAAVgBNACAAKABvAG4AZQAgAHAAZQByACAAbABpAG4AZQApAA==')))
	  
	} 
else
	{ $Datafile = $args[0] }


$LogFile = (($DataFile).SubString(0,(($Datafile).length - 3))) + "log"
$Outfile = (($DataFile).SubString(0,(($Datafile).length - 3))) + "htm"
$global:WriteHostPreference = $true
$global:DefaultLogPath =  $LogFile

Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAcwBjAHIAaQBwAHQAIAB3AGkAdABoACAAJABkAGEAdABhAGYAaQBsAGUA')))


if ( (Get-PSSnapin -Name VMware.VimAutomation.Core -ErrorAction SilentlyContinue) -eq $null )
	{ Add-PsSnapin VMware.VimAutomation.Core }

If (!(Get-PSSnapin -Name VMware.VimAutomation.Core))
	{Out-LogFile -Message "Failed to load PowerCLI Snap-in. Check PowerCLI is installed." -Severity "E"
	 Exit(1)
	}


$HTMLPreString=@"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="http://current.bootstrapcdn.com/bootstrap-v204/css/bootstrap-combined.min.css">
    <style type="text/css">
        body {
            padding: 20px;
        }
		
		h2 {
            color: #3A87AD;
        }
		
		.mytable {
        	width: 776px;
        	margin: 12px;
   
        }
		
		.alert-info {
			color: #3A87AD;
			background-color: #D9EDF7;
			border-color: #BCE8F1;
			padding: 8px 8px 8px 14px;
			margin-top: 12px;
			margin-left: 12px;
			margin-right: 12px;
			margin-bottom: 12px;
			border: 1px solid;
			border-radius: 4px;
		}
		
		.chart_wrap {
			width: 800px;
			border-style:solid;
			border-width:1px;
			border-color: #DDDDDD;
      		margin: 0px 0px 10px 0px;
		}
			
		.chart {
		 	text-align: center;
		 	width: 800px;
		 	height: 400px;
		}
    </style>
	<title>
      Virtual Machine Performance statistics
    </title>
    <script type="text/javascript" src="http://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load('visualization', '1', {packages: ['corechart']});
    </script>

"@
$HTMLPreString += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABuAGwA')))
$HTMLBodyBegin  =$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABiAG8AZAB5ACAAcwB0AHkAbABlAD0AIgBmAG8AbgB0AC0AZgBhAG0AaQBsAHkAOgAgAEEAcgBpAGEAbAA7AGIAbwByAGQAZQByADoAIAAwACAAbgBvAG4AZQA7ACIAPgAgACQAbgBsAA=='))) 
$HTMLBodyBegin  += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABpAG0AZwAgAHMAcgBjAD0AIgAkAEMAbwBtAHAAYQBuAHkATABvAGcAbwAiACAAYQBsAHQAPQAiAEMAbwBtAHAAYQBuAHkAIABMAG8AZwBvACIAIAAvAD4AIAAkAG4AbAA=')))
$HTMLBodyBegin  += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABoADIAPgBQAGUAcgBmAG8AcgBtAGEAbgBjAGUAIABTAHQAYQB0AGkAcwB0AGkAYwBzADwALwBoADIAPgAkAG4AbAA=')))

$HTMLPostString=@"
    <script src= "https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script src="http://current.bootstrapcdn.com/bootstrap-v204/js/bootstrap.min.js"</script>
	<script src="http://current.bootstrapcdn.com/bootstrap-v204/js/bootstrap-tab.js"</script>
  </body>
</html>
"@


Function Get-DataTable ($Statistics, $UID, $Summation = $false, $Title) 
{

$mystring = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABzAGMAcgBpAHAAdAAgAHQAeQBwAGUAPQAiAHQAZQB4AHQALwBqAGEAdgBhAHMAYwByAGkAcAB0ACIAPgAkAG4AbAA=')))
$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgB1AG4AYwB0AGkAbwBuACAAZAByAGEAdwBWAGkAcwB1AGEAbABpAHoAYQB0AGkAbwBuACQAVQBJAEQAKAApACAAewAkAG4AbAA=')))
$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwAvACAAQwByAGUAYQB0AGUAIABhAG4AZAAgAHAAbwBwAHUAbABhAHQAZQAgAHQAaABlACAAZABhAHQAYQAgAHQAYQBiAGwAZQAuACAAJABuAGwA')))
$mystring += "var " + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAgAD0AIABuAGUAdwAgAGcAbwBvAGcAbABlAC4AdgBpAHMAdQBhAGwAaQB6AGEAdABpAG8AbgAuAEQAYQB0AGEAVABhAGIAbABlACgAKQA7ACQAbgBsAA==')))
$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAuAGEAZABkAEMAbwBsAHUAbQBuACgAJwBkAGEAdABlAHQAaQBtAGUAJwAsACAAJwBUAGkAbQBlACcAKQA7ACQAbgBsAA==')))
$VMs | % {$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAuAGEAZABkAEMAbwBsAHUAbQBuACgAJwBuAHUAbQBiAGUAcgAnACwAIAAnACQAXwAnACkAOwAkAG4AbAA=')))}
$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + "data.addRows(" + $Statistics.Count + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KQA7ACQAbgBsAA==')))
$ColumnCount = 0
$RowCount = 0
$Statistics | % {
	 $ColumnCount = 0


@@	 $formatteddate = [datetime]::ParseExact(([string]$_.Name),"M/d/yyyy h:mm:ss tt",$null)
	 $JSMonth = (($formatteddate.ToString("MM"))-1) 
	 $formatteddate = $formatteddate.ToString($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQB5AHkAeQAsACAAJABKAFMATQBvAG4AdABoACwAIABkAGQALAAgAEgASAAsACAAbQBtAA=='))))
	 $formatteddate = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBlAHcAIABEAGEAdABlACgAJABmAG8AcgBtAGEAdAB0AGUAZABkAGEAdABlACkA')))
	 $mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAuAHMAZQB0AEMAZQBsAGwAKAAkAFIAbwB3AEMAbwB1AG4AdAAsACAAJABDAG8AbAB1AG0AbgBDAG8AdQBuAHQALAAgACQAZgBvAHIAbQBhAHQAdABlAGQAZABhAHQAZQApADsAJABuAGwA')))
	 $_.Group |
		%  {
			$ColumnCount = 0
			foreach ($VM in $VMs)
				{
				 $ColumnCount += 1
				 If ($_.Entity.Name -eq $VM )
					{ if ($Summation -eq $true)
						{ $strPercent =  (( $_.Value / ( $_.IntervalSecs * 1000)) * 100) 
						  $strPercent =  [system.math]::round($strPercent,2)
						  $mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAuAHMAZQB0AEMAZQBsAGwAKAAkAFIAbwB3AEMAbwB1AG4AdAAsACAAJABDAG8AbAB1AG0AbgBDAG8AdQBuAHQALAAgAA=='))) + $strPercent + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KQA7ACQAbgBsAA==')))
						}
					  else
						{ $mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAuAHMAZQB0AEMAZQBsAGwAKAAkAFIAbwB3AEMAbwB1AG4AdAAsACAAJABDAG8AbAB1AG0AbgBDAG8AdQBuAHQALAAgAA=='))) + $_.Value + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KQA7ACQAbgBsAA=='))) }
					}
				}

		  	}
	 $RowCount += 1
	}
	$mystring += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABuAGwAIABuAGUAdwAgAGcAbwBvAGcAbABlAC4AdgBpAHMAdQBhAGwAaQB6AGEAdABpAG8AbgAuAEwAaQBuAGUAQwBoAGEAcgB0ACgAZABvAGMAdQBtAGUAbgB0AC4AZwBlAHQARQBsAGUAbQBlAG4AdABCAHkASQBkACgAJwB2AGkAcwB1AGEAbABpAHoAYQB0AGkAbwBuAA=='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) +$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JwApACkALgAkAG4AbAA=')))
	
	$VisParam = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKAAkAewAgAA0ACgAJAAkAbABlAGcAZQBuAGQAOgAgAHsAcABvAHMAaQB0AGkAbwBuADoAIAAnAGkAbgAnACwAYQBsAGkAZwBuAG0AZQBuAHQAOgAiAGMAZQBuAHQAZQByACIAfQAsACAADQAKAAkACQBsAGkAbgBlAFcAaQBkAHQAaAA6ACIAMgAiACwAIAANAAoACQAJAGMAdQByAHYAZQBUAHkAcABlADoAIAAiAG4AbwBuAGUAIgAsAA0ACgAJAAkAYwBoAGEAcgB0AEEAcgBlAGEAOgB7AGwAZQBmAHQAOgA2ADAALAB0AG8AcAA6ADQAMAAsAHcAaQBkAHQAaAA6ACIAOQAwACUAIgAsAGgAZQBpAGcAaAB0ADoAIgA3ADUAJQAiAH0ALAANAAoACQAJAGYAbwBjAHUAcwBUAGEAcgBnAGUAdAA6ACIAYwBhAHQAZQBnAG8AcgB5ACIALAAgAA0ACgAJAAkAaABBAHgAaQBzADoAIAB7AHMAbABhAG4AdABlAGQAVABlAHgAdAA6ACIAdAByAHUAZQAiACwAIABmAG8AcgBtAGEAdAA6ACIARQAsACAAZAAgAE0ATQBNACIAfQAsAA0ACgAJAAkAdgBBAHgAaQBzADoAIAB7AHQAZQB4AHQAUABvAHMAaQB0AGkAbwBuADoAIgBvAHUAdAAiAH0ALAANAAoACQAJAHcAaQBkAHQAaAA6ACAAOAAwADAALAAgAA0ACgAJAAkAaABlAGkAZwBoAHQAOgAgADQAMAAwACwAIAANAAoACQAJAHQAaQB0AGwAZQA6ACIAJABUAGkAdABsAGUAIgB9AA==')))
	
	$mystring +=  "draw(" + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAsACAAJABWAGkAcwBQAGEAcgBhAG0AKQA7ACQAbgBsAA==')))

	
	
	$mystring +=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fQAkAG4AbAA=')))
	$mystring +=  "google.setOnLoadCallback(drawVisualization" + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KQA7ACQAbgBsADwALwBzAGMAcgBpAHAAdAA+ACQAbgBsAA==')))
	return $mystring
}

function Get-DivHTML ($UID, $Notes)
	{
	$tempHTML = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABkAGkAdgAgAGMAbABhAHMAcwA9ACIAdABhAGIALQBwAGEAbgBlACAAZgBhAGQAZQAiACAAaQBkAD0AIgAkAFUASQBEACIAPgAkAG4AbAA=')))
	$tempHTML += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQA8AGQAaQB2ACAAYwBsAGEAcwBzAD0AIgBjAGgAYQByAHQAXwB3AHIAYQBwACIAPgAkAG4AbAA=')))
	$tempHTML += "		<div id=`"visualization" + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABVAEkARAA='))) + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IgAgAGMAbABhAHMAcwA9ACIAYwBoAGEAcgB0ACIAPgA8AC8AZABpAHYAPgAkAG4AbAA=')))
	$tempHTML += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJADwAZABpAHYAIABjAGwAYQBzAHMAPQAiAGEAbABlAHIAdAAgAGEAbABlAHIAdAAtAGkAbgBmAG8AIgA+ADwAcwB0AHIAbwBuAGcAPgBJAG4AZgBvAHIAbQBhAHQAaQBvAG4AOgAgADwALwBzAHQAcgBvAG4AZwA+ACQATgBvAHQAZQBzADwALwBkAGkAdgA+ACQAbgBsAA==')))
	$tempHTML += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQA8AC8AZABpAHYAPgAkAG4AbAA=')))
	$tempHTML += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAGQAaQB2AD4AJABuAGwA')))
	return $tempHTML
	}





$DataTable = @(Get-Content $Datafile)
$email =  $DataTable[0] 
$VMs = @($DataTable[1..($DataTable.Count)])

Set-PowerCLIConfiguration -InvalidCertificateAction:Ignore -DefaultVIServerMode:Single -Confirm:$false|Out-Null
if ((Connect-VIServer $VC -Credential $VCCred) -eq $null) 
	{ Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIABjAG8AbgBuAGUAYwB0ACAAdABvACAAdgBDAGUAbgB0AGUAcgAgACgAJABWAEMAKQA='))) -Severity "E" -WriteHost
	  Exit (1)
	}
else
	{Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AbgBlAGMAdABlAGQAIAB0AG8AIAB2AEMAZQBuAHQAZQByACAAKAAkAFYAQwApAA==')))}


$VCVMs = (get-vm -name $VMs -ErrorAction SilentlyContinue) 
$VMs | % {
		$tmpvm = $_
		$Exists = $false
		$VCVMs | % { if ($_.Name -eq $tmpvm) {$Exists = $true}}
		If ($Exists){
     		 Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfACAAZgBvAHUAbgBkACAAaQBuACAAdgBDAGUAbgB0AGUAcgAgAGkAbgB2AGUAbgB0AG8AcgB5AA==')))
			}
		Else {
     		  Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfACAAbgBvAHQAIABmAG8AdQBuAGQAIABpAG4AIAB2AEMAZQBuAHQAZQByACAAaQBuAHYAZQBuAHQAbwByAHkA'))) -Severity "W"
			  $VMs = $VMs |? {$_ -ne $tmpvm}
			 }
		}










$todayMidnight = (Get-Date -Hour 0 -Minute 0 -Second 0).AddMinutes(-1)
$metrics = "cpu.usagemhz.average","mem.usage.average","disk.usage.average","net.usage.average","cpu.ready.summation","mem.vmmemctl.average"
$start = $todayMidnight.AddDays(-7) 
$finish = $todayMidnight
$startstring = $start.ToString("dddd, dd MMMM yyyy HH:mm")
$finishstring = $finish.ToString("dddd, dd MMMM yyyy HH:mm")
Out-LogFile -Message "Getting stats from vCenter"

$Stats = Get-Stat -Entity $vms -Stat $metrics -Start $start -Instance "" -Finish $finish -IntervalSecs "1800" 
Out-LogFile -Message "Got stats from vCenter"
Out-LogFile -Message "Sorting and filtering stats"

$CPU = ($Stats | Where-Object {$_.MetricId -eq $metrics[0]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)
$Memory = ($Stats | Where-Object {$_.MetricId -eq $metrics[1]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)
$Disk = ($Stats | Where-Object {$_.MetricId -eq $metrics[2]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)
$Net =  ($Stats | Where-Object {$_.MetricId -eq $metrics[3]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)
$Ready = ($Stats | Where-Object {$_.MetricId -eq $metrics[4]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)
$Balloon = ($Stats | Where-Object {$_.MetricId -eq $metrics[5]} | Sort-Object TimeStamp |Group-Object -Property Timestamp)


Out-LogFile -Message "Creating HTML"
$HTMLOut = $HTMLPreString + (Get-DataTable -Statistics $CPU -UID "CPU" -Title "CPU (MHz)")
$HTMLOut += (Get-DataTable -Statistics $Memory -UID "Memory" -Title "Memory (%)")
$HTMLOut += (Get-DataTable -Statistics $Disk -UID "Disk" -Title "Disk Activity (KBps)")
$HTMLOut += (Get-DataTable -Statistics $Net -UID "Net" -Title "Network I/O (KBps)")
$HTMLOut += (Get-DataTable -Statistics $Ready -UID "Ready" -Summation $true -Title "CPU Wait Time (%)")
$HTMLOut += (Get-DataTable -Statistics $Balloon -UID "Balloon" -Summation $true -Title "Memory allocated to the balloon driver (KB)")
$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAGgAZQBhAGQAPgAkAG4AbAA=')))
$HTMLOut += $HTMLBodyBegin + $nl




$HTMLOut += @"

    <div id="content">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#Info" data-toggle="tab">Information</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">CPU<b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#CPU" data-toggle="tab">CPU Usage</a></li>
                    <li><a href="#Ready" data-toggle="tab">CPU Wait Time</a></li>
                </ul>
            </li>
			<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Memory<b class="caret"></b></a>
                <ul class="dropdown-menu">
                   	<li><a href="#Memory" data-toggle="tab">Memory Usage</a></li>
                    <li><a href="#Balloon" data-toggle="tab">Memory Balloon</a></li>
                </ul>
			<li>
            <li><a href="#Disk" data-toggle="tab">Disk</a></li>
            <li><a href="#Net" data-toggle="tab">Network</a></li>
        </ul>
        <div id="my-tab-content" class="tab-content">
			<div class="tab-pane fade in active" id="Info">
				<div class="chart_wrap">
					<div class="alert alert-info">
					<strong>Information: </strong>
"@

$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBhAGMAaAAgAGQAYQB0AGEAcABvAGkAbgB0ACAAcgBlAHAAcgBlAHMAZQBuAHQAcwAgAHIAZQBzAG8AdQByAGMAZQAgAGMAbwBuAHMAdQBtAHAAdABpAG8AbgAgAHMAaQBuAGMAZQAgAHQAaABlACAAbABhAHMAdAAgAGQAYQB0AGEAcABvAGkAbgB0ACAADQAKAAkAYQBuAGQAIABpAHQAcwAgAHYAYQBsAHUAZQAgAGkAcwAgAGUAaQB0AGgAZQByACAAYQBuACAAYQB2AGUAcgBhAGcAZQAsACAAbQBhAHgAaQBtAHUAbQAsACAAbwByACAAcwB1AG0AbQBhAHQAaQBvAG4AIABvAGYAIABhAGwAbAAgAHUAcwBhAGcAZQAgAGkAbgAgAHQAaABhAHQAIABpAG4AdABlAHIAdgBhAGwALgAgAA0ACgAJAEEAbgB5ACAAdgBhAGwAdQBlAHMAIAB0AGgAYQB0ACAAYQByAGUAIAB6AGUAcgBvACAAbQBhAHkAIABhAGMAdAB1AGEAbABsAHkAIABiAGUAIAB6AGUAcgBvACwAIABvAHIAIABtAGEAeQAgAGkAbgBkAGkAYwBhAHQAZQAgAHMAdABhAHQAaQBzAHQAaQBjAHMAIAB3AGUAcgBlACAAbgBvAHQAIAANAAoACQBjAG8AbABsAGUAYwB0AGUAZAAgAG8AdgBlAHIAIAB0AGgAYQB0ACAAcABlAHIAaQBvAGQAIAAoAGYAbwByACAAZQB4AGEAbQBwAGwAZQAsACAAaQBmACAAYQAgAHYAaQByAHQAdQBhAGwAIABtAGEAYwBoAGkAbgBlACAAdwBhAHMAIABwAG8AdwBlAHIAZQBkACAAbwBmAGYAKQAuACAAJABuAGwAIAANAAoACQBUAGgAZQAgAHMAdABhAHQAaQBzAHQAaQBjAHMAIABkAGkAcwBwAGwAYQB5AGUAZAAgAGEAcgBlACAAZgByAG8AbQAgACQAcwB0AGEAcgB0AHMAdAByAGkAbgBnACAAdABvACAAJABmAGkAbgBpAHMAaABzAHQAcgBpAG4AZwA8AC8AZABpAHYAPgAkAG4AbAA=')))

$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAB0AGEAYgBsAGUAIABjAGwAYQBzAHMAPQAiAG0AeQB0AGEAYgBsAGUAIAB0AGEAYgBsAGUAIAB0AGEAYgBsAGUALQBzAHQAcgBpAHAAZQBkACAAdABhAGIAbABlAC0AYgBvAHIAZABlAHIAZQBkACIAPgA8AHQAaABlAGEAZAA+ADwAdAByAD4APAB0AGQAPgBWAE0AIABOAGEAbQBlADwALwB0AGQAPgA8AHQAZAA+AE4AdQBtAGIAZQByACAAbwBmACAAQwBQAFUAJwBzADwALwB0AGQAPgA8AHQAZAA+AE0AZQBtAG8AcgB5ACAAKABNAEIAKQA8AC8AdABkAD4APAB0AGQAPgBDAFAAVQAgAEwAaQBtAGkAdAA8AC8AdABkAD4APAB0AGQAPgBNAGUAbQBvAHIAeQAgAEwAaQBtAGkAdAA8AC8AdABkAD4APAAvAHQAcgA+ADwALwB0AGgAZQBhAGQAPgAkAG4AbAA8AHQAYgBvAGQAeQA+ACQAbgBsAA==')))
$VCVMs | % { 
			$tmpname =$_.Name
			$tmpNumCpu = $_.NumCpu
			$TmpMemoryMB = $_.MemoryMB
			$tmpCPULimit = $_.VMResourceConfiguration.CPULimitMhz.ToString().Replace("-1","None")
			$tmpMemLimit = $_.VMResourceConfiguration.MemLimitMB.ToString().Replace("-1","None")
			$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgADwAdAByAD4APAB0AGQAPgAkAHQAbQBwAG4AYQBtAGUAPAAvAHQAZAA+ADwAdABkAD4AJAB0AG0AcABOAHUAbQBDAHAAdQA8AC8AdABkAD4APAB0AGQAPgAkAFQAbQBwAE0AZQBtAG8AcgB5AE0AQgA8AC8AdABkAD4APAB0AGQAPgAkAHQAbQBwAE0AZQBtAEwAaQBtAGkAdAA8AC8AdABkAD4APAB0AGQAPgAkAHQAbQBwAEMAUABVAEwAaQBtAGkAdAA8AC8AdABkAD4APAAvAHQAcgA+ACQAbgBsAA==')))
}
$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAHQAYgBvAGQAeQA+ADwALwB0AGEAYgBsAGUAPgAkAG4AbAA=')))
$HTMLOut +=@"
		</div>
	</div>
			
"@

$HTMLOut += (Get-DivHTML -UID "CPU" -Notes "Average CPU usage, as measured in megahertz, during the interval")
$HTMLOut += (Get-DivHTML -UID "Memory" -Notes "Average memory usage as percentage of total configured or available memory")
$HTMLOut += (Get-DivHTML -UID "Disk" -Notes "Average disk activity (combinded read & write) in KBps")
$HTMLOut += (Get-DivHTML -UID "Net" -Notes "Average network utilization (combined transmit and receive rates) during the interval")
$HTMLOut += (Get-DivHTML -UID "Ready" -Notes "The percentage of time that the virtual machine was ready, but could not get scheduled to run on the physical CPU. Values of less than 10% are considered normal")
$HTMLOut += (Get-DivHTML -UID "Balloon" -Notes "Amount of memory allocated by the virtual machine memory control driver (vmmemctl), which is installed with VMware Tools. This value should remain at 0 or close to 0")
$HTMLOut += @"
			</div>
		</div>
    </div>

"@
$datenow = Get-Date -Format "F"
$HTMLOut += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABoADYAPgBSAGUAcABvAHIAdAAgAGcAZQBuAGUAcgBhAHQAZQBkACAAYQB0ACAAJABkAGEAdABlAG4AbwB3ADwAaAA2AD4AJABuAGwA')))
$HTMLOut += $HTMLPostString

Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAG4AaQBzAGgAZQBkACAAYgB1AGkAbABkAGkAbgBnACAASABUAE0ATAAsACAAdwByAGkAdABpAG4AZwAgAHQAbwAgACQATwB1AHQAZgBpAGwAZQA=')))
$HTMLOut | Out-File -FilePath $Outfile -Encoding "UTF8"


$body =@"
<P>Performance statistics for the Virtual Machines listed below are attached</p>
"@
$body += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABwAD4AUwB0AGEAdABpAHMAdABpAGMAcwAgAGEAcgBlACAAZgByAG8AbQAgACQAcwB0AGEAcgB0AHMAdAByAGkAbgBnACAAdABvACAAJABmAGkAbgBpAHMAaABzAHQAcgBpAG4AZwA8AHAAPgA=')))
$VMs | % {$body+= $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABsAGkAPgAkAF8APAAvAGwAaQA+AA=='))) }
Out-LogFile -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAG4AZABpAG4AZwAgAGUAbQBhAGkAbAAuACAARQBtAGEAaQBsADoAJABlAG0AYQBpAGwALgAgAFMATQBUAFAAIABTAGUAcgB2AGUAcgA6ACQAUwBNAFQAUABTAGUAcgB2AGUAcgA=')))

Send-MailMessage -Attachments $Outfile -Body $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAG8AZAB5AA==')))  -BodyAsHtml:$true -Subject "Performance Statistics" -To $email -From $SendersAddress -SmtpServer $SMTPServer
Disconnect-VIServer -Confirm:$false
Out-LogFile -Message "Disconnected from vCenter"
Out-LogFile -Message "Finished"
