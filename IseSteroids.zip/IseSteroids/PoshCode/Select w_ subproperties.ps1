﻿

function Select-Object {
[CmdletBinding(DefaultParameterSetName='DefaultParameter')]
param(
  [Parameter(ValueFromPipeline=$true)]
  [System.Management.Automation.PSObject]
  ${InputObject},

  [Parameter(ParameterSetName='DefaultParameter', Position=0)]
  [System.Object[]]
  ${Property},

  [Parameter(ParameterSetName='DefaultParameter')]
  [System.String[]]
  ${ExcludeProperty},

  [Parameter(ParameterSetName='DefaultParameter')]
  [System.String]
  ${ExpandProperty},

  [Switch]
  ${Unique},

  [Parameter(ParameterSetName='DefaultParameter')]
  [ValidateRange(0, 2147483647)]
  [System.Int32]
  ${Last},

  [Parameter(ParameterSetName='DefaultParameter')]
  [ValidateRange(0, 2147483647)]
  [System.Int32]
  ${First},

  [Parameter(ParameterSetName='DefaultParameter')]
  [ValidateRange(0, 2147483647)]
  [System.Int32]
  ${Skip},

  [Parameter(ParameterSetName='IndexParameter')]
  [ValidateRange(0, 2147483647)]
  [System.Int32[]]
  ${Index})

begin
{
 try {
     ${7} = $null
     if ($PSBoundParameters.TryGetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQAQgB1AGYAZgBlAHIA'))), [ref]${7}))
     {
         $PSBoundParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQAQgB1AGYAZgBlAHIA')))] = 1
     }
     
     
     if ($Property -ne $null) {
      
      ${4} = @()
      foreach ( ${5} in $Property ) {
       if (${5}.GetType().Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AHIAaQBuAGcA')))) {
        if (${5}.Contains('.')) {
         [String] ${6} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAC4A'))) + ${5}
         ${5} = @{Name=${5}; Expression = {Invoke-Expression (${6})}}
        }
       }
       ${4} += ${5}
      }
      $PSBoundParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AcABlAHIAdAB5AA==')))] = ${4}
     }
     
     
     ${3} = $ExecutionContext.InvokeCommand.GetCommand($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBPAGIAagBlAGMAdAA='))), 
         [System.Management.Automation.CommandTypes]::Cmdlet)
     ${2} = {& ${3} @PSBoundParameters }
     ${1} = 
         ${2}.GetSteppablePipeline($myInvocation.CommandOrigin)
     ${1}.Begin($PSCmdlet)
 } catch {
     throw
 }
}

process
{
    try {
        ${1}.Process($_)
    } catch {
        throw
    }
}

end
{
    try {
        ${1}.End()
    } catch {
        throw
    }
}

}
