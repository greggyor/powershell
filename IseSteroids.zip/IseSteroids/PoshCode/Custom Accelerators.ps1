﻿
${2} = [type]::gettype("System.Management.Automation.TypeAccelerators")  
function Add-Accelerator {
[CmdletBinding()]
PARAM(
   [Parameter(Position=0)]
   [Alias("Key")]
   [string[]]$Accelerator
,
   [Parameter(Position=1)]
   [Alias("Value")]
   [type]$Type
)
PROCESS {
   foreach(${3} in $Accelerator) { 
      ${2}::Add( ${3}, $Type) 
      trap [System.Management.Automation.MethodInvocationException] {
         if(${2}::get.keys -contains ${3}) {
            Write-Error "Cannot add accelerator [${3}] for [$($Type.FullName)]`n                  [${3}] is already defined as [$(${2}::get[${3}].FullName)]"
            Continue;
         } 
         throw
      }
   }
}
}
function Get-Accelerator {
[CmdletBinding(DefaultParameterSetName="ByType")]
PARAM(
   [Parameter(Position=0, ParameterSetName="ByAccelerator", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
   [Alias("Key")]
   [string[]]$Accelerator
,
   [Parameter(Position=0, ParameterSetName="ByType", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
   [Alias("Value")]
   [type[]]$Type
)
PROCESS {
   switch($PSCmdlet.ParameterSetName) {
      "ByAccelerator" { 
         ${2}::get.GetEnumerator() | % {
            foreach(${3} in $Accelerator) {
               if($_.Key -like ${3}) { $_ }
            }
         }
         break
      }
      "ByType" { 
         if($Type -and $Type.Count) {
            ${2}::get.GetEnumerator() | ? { $Type -contains $_.Value }
         }
         else {
            ${2}::get.GetEnumerator() | %{ $_ }
         }
         break
      }
   }
}
}
function Remove-Accelerator {
[CmdletBinding(SupportsShouldProcess=$true)]
PARAM(
   [Parameter(Position=0, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
   [Alias("Key")]
   [string[]]$Accelerator
)
PROCESS {
   foreach(${3} in $Accelerator) {
      foreach(${1} in ${2}::Get.Keys -like ${3}) { 
         if($PSCmdlet.ShouldProcess( "Removes the alias [$(${1})] for type [$(${2}::Get[${1}].FullName)]",
                                     "Remove the alias [$(${1})] for type [$(${2}::Get[${1}].FullName)]?",
                                     "Removing Type Accelerator" )) {
            ${2}::remove(${1})   
         }
      }
   }
}
}
