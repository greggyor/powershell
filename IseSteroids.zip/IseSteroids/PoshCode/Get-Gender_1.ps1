﻿








param([string]$name)          
   
function global:get-gender {  
   param([string]$name)       
   
   if($name.Length -lt 2) { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIABuAGUAZQBkACAAYQB0ACAAbABlAGEAcwB0ACAAdAB3AG8AIABsAGUAdAB0AGUAcgBzACAAaQBuACAAdABoAGUAIABuAGEAbQBlAA=='))) }
   $name = "$($name[0])".ToUpper()  + $name.SubString(1).ToLower()

   
   
   switch(
      Invoke-Http GET $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB3AHcAdwAuAGIAYQBiAHkAbgBhAG0AZQBhAGQAZABpAGMAdABzAC4AYwBvAG0ALwBjAGcAaQAtAGIAaQBuAC8AcwBlAGEAcgBjAGgALgBwAGwA'))) @{
         gender=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBMAEwA')));searchfield=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQBzAA==')));origins=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBMAEwA')));searchtype=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBhAHQAYwBoAGkAbgBnAA==')));searchtext=$name
      } | Receive-Http Text "//font[b/font/text()='$name']/@color" )
   { 
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgB1AGMAcwBoAGkAYQA='))) { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBlAG0AZQBuAGkAbgBlAA=='))) }
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAwADgAOABkAGQAMAA='))) { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAHMAYwB1AGwAaQBuAGUA'))) } 
   }
}

get-gender $name              




