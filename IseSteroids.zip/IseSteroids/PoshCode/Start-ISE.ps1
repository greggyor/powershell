﻿function Start-ISE ()
{
     param(
        [Parameter(Position = 0, Mandatory=$false, ValueFromPipeline=$True)]
        $fileObjOrFileName
    )
    PROCESS {
        if ($fileObjOrFileName -ne $null){
            if ($fileObjOrFileName.gettype().Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AHIAaQBuAGcA')))){
                $fileObject = Get-item $fileObjOrFileName
            }
            else {
                $fileObject = $fileObjOrFileName
            }
         }
         & "$PSHome/powershell_ise.exe" $fileObject.Fullname
      }
}
