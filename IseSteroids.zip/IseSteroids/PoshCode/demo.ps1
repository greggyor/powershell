﻿\n[45]: [IO.File]::ReadAllLines( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXABVAHMAZQByAHMAXABcAEoAbwBlAGwAXABcAFMAaQB0AGUAcwBcAFwAdwBlAGIAYQBsAGkAegBlAHIALgBjAHUAcgByAGUAbgB0AA=='))) ).Length
31873
[46]: (gc C:\\Users\\Joel\\Sites\\webalizer.current).Length
31873
[47]: gph 2

Duration Average Lines Words Chars Type    Commmand
-------- ------- ----- ----- ----- ----    --------
 0.07910 0.07910     1     3    73 Command [IO.File]::ReadAllLines( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXABVAHMAZQByAHMAXABcAEoAbwBlAGwAXABcAFMAaQB0AGUAcwBcAFwAdwBlAGIAYQBsAGkAegBlAHIALgBjAHUAcgByAGUAbgB0AA=='))) ).Length
 0.88080 0.88080     1     2    49 Command (gc C:\\Users\\Joel\\Sites\\webalizer.current).Length

