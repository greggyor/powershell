﻿
function Add-PrinterDriver {

 [CmdletBinding()]
     	Param(
              [Parameter(Mandatory=$true)]
              [string] $PrintServer,
			  [switch] $Clean
             )


$allprinters = @(Get-WmiObject win32_printer -ComputerName $PrintServer -Filter 'shared=true')

$drivers = @($allprinters | Select-Object drivername -Unique)

$printers = @()
foreach ($item in $drivers){
$printers += @($allprinters | Where-Object {$_.drivername -eq $item.drivername})[0]
}


$localdrivers = @()
foreach ($driver in (Get-WmiObject Win32_PrinterDriver)){
$localdrivers += @(($driver.name -split ",")[0])
}


$CurrentPrinter = 1


foreach ($printer in $printers) {

Write-Progress -Activity "Installing printers..." -Status "Current printer: $($printer.name)" -Id 1 -PercentComplete (($CurrentPrinter/$printers.count) * 100)


$outputobject = @{}
$outputobject.drivername = $printer.drivername

$locallyinstalled = $localdrivers | Where-Object {$_ -eq $printer.drivername}
if (-not $locallyinstalled) {
Write-Verbose "$($printer.drivername) is not installed locally"
$AddPrinterConnection = Invoke-WmiMethod -Path Win32_Printer -Name AddPrinterConnection -ArgumentList ([string]::Concat('\\\\', $printer.__SERVER, '\\', $printer.ShareName)) -EnableAllPrivileges
$outputobject.returncode = $AddPrinterConnection.ReturnValue
}
else
{
Write-Verbose "$($printer.drivername) is already installed locally"
$outputobject.returncode = "Already installed"
}


New-Object -TypeName PSObject -Property $outputobject

$CurrentPrinter ++

}


if ($clean) {
$printers = Get-WmiObject Win32_Printer -EnableAllPrivileges -Filter network=true
if ($printers) {
foreach ($printer in $printers) {
$printer.Delete()
}
}
}
}
