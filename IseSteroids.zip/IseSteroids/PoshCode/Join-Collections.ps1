﻿#requires -version 2.0


#.Note
#  Depends on ConvertFrom-HashTable http://poshcode.org/1118
#.Synopsis
#  Performs an inner join on two collections of objects based on a common key column.
#.Description
#  Takes two sets of objects where there are multiple "rows" and where each set has a shared column where the values match, and generates new objects with all the values from each.
#.Parameter GroupOnColumn
#  The name of the property to merge on. Items with the same value in this column will be combined.
#.Parameter FirstCollection
#  The first set of data
#.Parameter FirstJoinColumn
#  The name of the key id column in the first set
#.Parameter SecondCollection
#  The second set of data
#.Parameter SecondJoinColumn
#  The name of the matching key id column in the second set
#  OPTIONAL. Defaults to the same as FirstJoinColum
#.Example
#  Import-CSV data.csv | Pivot-Objects SamAccountName Attribute Value
#
#  Imports csv data containing multiple rows per-record such that a pair of columns named "Attribute" and "Value" are actually different in each row, and contain a name and value pair for attributes you want to add to the output objects.
#
#.Example
# $FirstCollection = @"
#  FirstName,  LastName,   MailingAddress,    EmployeeID
#  John,       Doe,        123 First Ave,     J8329029
#  Susan Q.,   Public,     3025 South Street, K4367143
#"@.Split("`n") | ConvertFrom-Csv                               
#
# $SecondCollection = @"
#  ID,    Week, HrsWorked,   PayRate,  EmployeeID
#  12276, 12,   40,          55,       J8329029
#  12277, 13,   40,          55,       J8329029
#  12278, 14,   42,          55,       J8329029
#  12279, 12,   35,          40,       K4367143
#  12280, 13,   32,          40,       K4367143
#  12281, 14,   48,          40,       K4367143
#"@.Split("`n") | ConvertFrom-Csv                               
#
# Join-Collections $FirstCollection EmployeeID $SecondCollection | ft            
#
#.Notes
#  Author: Joel Bennett

# function Join-Collections {
PARAM(
   $FirstCollection
,  [string]$FirstJoinColumn
,  $SecondCollection
,  [string]$SecondJoinColumn=$FirstJoinColumn
)
PROCESS {
   ${4}  = $FirstCollection[0] | gm -type Properties
   ${4} += $SecondCollection[0] | gm -type Properties | 
      Where { $_.Name -ne $SecondJoinColumn } | ForEach { if(${4} -contains $_) { "__$_" } else { $_ } }
   
   foreach(${3} in $FirstCollection) {
      foreach(${2} in $SecondCollection | Where{ $_."$SecondJoinColumn" -eq ${3}."$FirstJoinColumn" } ) {
        [string]${1} = ${3} | gm -type Properties | select -expand Definition | %{($_ -split " ",2)[1]}
        ${1} += ${2} | gm -type Properties | select -expand Definition | %{($_ -split " ",2)[1]}
        ConvertFrom-StringData ${1} | ConvertFrom-Hashtable
      }
   }
}
#}
