﻿
${3} = New-PSSession -ConfigurationName Microsoft.Exchange -Name ExchMgmt -ConnectionUri http://ex14.domain.local/PowerShell/ -Authentication Kerberos
Import-PSSession ${3}
${2} = Get-CASMailbox -Filter {HasActivesyncDevicePartnership -eq $true} -ResultSize Unlimited
${1} = ${2} | Select-Object PrimarySmtpAddress,@{N=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHYAaQBjAGUASQBEAA==')));E={Get-ActiveSyncDeviceStatistics -Mailbox $_.Identity | Select-Object –ExpandProperty DeviceID}}
${1} | foreach {Set-CASMailbox $_.PrimarySmtpAddress -ActiveSyncAllowedDeviceIDs $_.DeviceID}
