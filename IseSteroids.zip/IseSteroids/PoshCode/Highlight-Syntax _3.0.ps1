﻿#requires -version 2.0

# Highlight-Syntax.ps1
# version 2.0
# by Jeff Hillman
#
# this script uses the System.Management.Automation.PsParser class
# to highlight PowerShell syntax with HTML.

param( [string] $code, [switch] $LineNumbers )

if ( Test-Path $code -ErrorAction SilentlyContinue )
{
    $code = Get-Content $code | Out-String
}

${_/\__/\___/\_/\_/} = "#DDDDDD"
${_____/=\/\/=\/=\_} = "#000000"
${____/\__/=\/===\_} = "#404040"

${___/\/=====\__/==} = [System.Management.Automation.PSTokenType]

${/=\__/=\____/==\_} = @{ 
#    $PSTokenType::Unknown            = $foregroundColor; 
    ${___/\/=====\__/==}::Command            = "#C86400";
#    $PSTokenType::CommandParameter   = $foregroundColor;
#    $PSTokenType::CommandArgument    = $foregroundColor;
    ${___/\/=====\__/==}::Number             = "#800000";
    ${___/\/=====\__/==}::String             = "#800000";
    ${___/\/=====\__/==}::Variable           = "#000080";
#    $PSTokenType::Member             = $foregroundColor;
#    $PSTokenType::LoopLabel          = $foregroundColor;
#    $PSTokenType::Attribute          = $foregroundColor;
    ${___/\/=====\__/==}::Type               = "#404040";
    ${___/\/=====\__/==}::Operator           = "#C86400";
#    $PSTokenType::GroupStart         = $foregroundColor;
#    $PSTokenType::GroupEnd           = $foregroundColor;
    ${___/\/=====\__/==}::Keyword            = "#C86400";
    ${___/\/=====\__/==}::Comment            = "#008000";
    ${___/\/=====\__/==}::StatementSeparator = "#C86400";
#    $PSTokenType::NewLine            = $foregroundColor;
    ${___/\/=====\__/==}::LineContinuation   = "#C86400";
#    $PSTokenType::Position           = $foregroundColor;
    
}

filter Html-Encode
{
    $_ = $_ -replace "&", "&amp;"
    $_ = $_ -replace " ", "&nbsp;"
    $_ = $_ -replace "<", "&lt;"
    $_ = $_ -replace ">", "&gt;"

    $_
}

# replace the tabs with spaces
$code = $code -replace "\\t", ( " " * 4 )

if ( $LineNumbers )
{
    ${__/=\/=\_/===\___} = "<li style='color: ${____/\__/=\/===\_}; padding-left: 5px'>"
}
else
{
    ${__/=\/=\_/===\___} = ""
}

${/===\/==\/\/=\/\_} = [System.Management.Automation.PsParser]
${_/==\_/\/\/\_/\/=} = 1
${/=\/=\_/=====\/\/} = 1

foreach ( ${/=\/\/\/\/\_/=\_/} in ${/===\/==\/\/=\/\_}::Tokenize( $code, [ref] $null ) | Sort-Object StartLine, StartColumn )
{
    # get the color based on the type of the token
    ${____/=======\__/=} = ${/=\__/=\____/==\_}[ ${/=\/\/\/\/\_/=\_/}.Type ]
    
    if ( ${____/=======\__/=} -eq $null ) 
    { 
        ${____/=======\__/=} = ${_____/=\/\/=\/=\_}
    }

    # add whitespace
    if ( ${_/==\_/\/\/\_/\/=} -lt ${/=\/\/\/\/\_/=\_/}.StartColumn )
    {
        ${__/=\/=\_/===\___} += ( "&nbsp;" * ( ${/=\/\/\/\/\_/=\_/}.StartColumn - ${_/==\_/\/\/\_/\/=} ) )
    }
@@    ${_/==\_/\/\/\_/\/=} = ${/=\/\/\/\/\_/=\_/}.EndColumn
    switch ( ${/=\/\/\/\/\_/=\_/}.Type )
    {
        ${___/\/=====\__/==}::String {
            ${/=\/=\__/=\__/=\/} = "<span style='color: {0}'>{1}</span>" -f ${____/=======\__/=}, 
                ( $code.SubString( ${/=\/\/\/\/\_/=\_/}.Start, ${/=\/\/\/\/\_/=\_/}.Length ) | Html-Encode )

            # we have to highlight each piece of multi-line strings
            if ( ${/=\/=\__/=\__/=\/} -match "\\r\\n" )
            {
                # highlight any line continuation characters as operators
                ${/=\/=\__/=\__/=\/} = ${/=\/=\__/=\__/=\/} -replace "(``)(?=\\r\\n)", 
                    ( "<span style='color: {0}'>``</span>" -f ${/=\__/=\____/==\_}[ ${___/\/=====\__/==}::Operator ] )

                ${__/\/===\/=\/=\/\} = "</span><br />`r`n"
                
                if ( $LineNumbers )
                {
                     ${__/\/===\/=\/=\/\} += "<li style='color: ${____/\__/=\/===\_}; padding-left: 5px'>"
                }

                ${__/\/===\/=\/=\/\} += "<span style='color: ${____/=======\__/=}'>"

                ${/=\/=\__/=\__/=\/} = ${/=\/=\__/=\__/=\/} -replace "\\r\\n", ${__/\/===\/=\/=\/\}
            }

            ${__/=\/=\_/===\___} += ${/=\/=\__/=\__/=\/}
            break
        }

        ${___/\/=====\__/==}::NewLine {
            ${__/=\/=\_/===\___} += "<br />`r`n"
            
            if ( $LineNumbers )
            {
                ${__/=\/=\_/===\___} += "<li style='color: ${____/\__/=\/===\_}; padding-left: 5px'>"
            }
            
            ${_/==\_/\/\/\_/\/=} = 1
            ++${/=\/=\_/=====\/\/}
            break
        }

        default {
            if ( ${/=\/\/\/\/\_/=\_/}.Type -eq ${___/\/=====\__/==}::LineContinuation )
            {
                ${_/==\_/\/\/\_/\/=} = 1
                ++${/=\/=\_/=====\/\/}
            }

            ${__/=\/=\_/===\___} += "<span style='color: {0}'>{1}</span>" -f ${____/=======\__/=}, 
                ( $code.SubString( ${/=\/\/\/\/\_/=\_/}.Start, ${/=\/\/\/\/\_/=\_/}.Length ) | Html-Encode )
        }
    }
@@    #$lastColumn = $token.EndColumn
}

# put the highlighted code in the pipeline
"<div style='width: 100%; " + 
            "/*height: 100%;*/ " +
            "overflow: auto; " +
            "font-family: Consolas, `"Courier New`", Courier, mono; " +
            "font-size: 12px; " +
            "background-color: ${_/\__/\___/\_/\_/}; " +
            "color: ${_____/=\/\/=\/=\_}; " + 
            "padding: 2px 2px 2px 2px; white-space: nowrap'>"

if ( $LineNumbers )
{
    ${/======\/=====\/\} =  ${/=\/=\_/=====\/\/}.ToString().Length

    "<ol start='1' style='border-left: " +
                         "solid 1px ${____/\__/=\/===\_}; " +
                         "margin-left: $( ( ${/======\/=====\/\} * 10 ) + 15 )px; " +
                         "padding: 0px;'>"
}

${__/=\/=\_/===\___}

if ( $LineNumbers )
{
    "</ol>"
}

"</div>"
