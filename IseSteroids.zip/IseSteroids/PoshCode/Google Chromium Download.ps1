﻿
Set-StrictMode -Version Latest
Import-Module bitstransfer
$VerbosePreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdABpAG4AdQBlAA==')))
${01001101100111100} = "$Env:temp\\latestChromiumVersion.txt"
${00001101100100110} = 0
trap [Exception] { 
      write-host
      write-error $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABSAEEAUABQAEUARAA6ACAA'))) + $_.Exception.GetType().FullName); 
      write-error $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABSAEEAUABQAEUARAA6ACAA'))) + $_.Exception.Message); 
      [string](${00001101100100110}) > ${01001101100111100}
      exit; 
}
if (Test-Path ${01001101100111100})
{ ${00001101100100110} = [int32] (cat ${01001101100111100}) }
${00011110000101110} =$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBiAHUAaQBsAGQALgBjAGgAcgBvAG0AaQB1AG0ALgBvAHIAZwAvAGYALwBjAGgAcgBvAG0AaQB1AG0ALwBzAG4AYQBwAHMAaABvAHQAcwAvAGMAaAByAG8AbQBpAHUAbQAtAHIAZQBsAC0AeABwAA==')))
Start-BitsTransfer "${00011110000101110}/LATEST" ${01001101100111100}
${00010110000000111} = [int32] (cat ${01001101100111100})
if (${00001101100100110} -eq ${00010110000000111})
{ 
    Write-Verbose "Exiting... Version ${00001101100100110} is the latest."
    return
}
${00011100101010110} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBpAG4AaQBfAGkAbgBzAHQAYQBsAGwAZQByAA==')))
${00001001100101000} = "$Env:temp\\${00011100101010110}.exe"
Write-Verbose "Initiating download of new version ${00010110000000111}"
Start-BitsTransfer "${00011110000101110}/${00010110000000111}/mini_installer.exe" ${00001001100101000}
Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAG4AZQB3ACAAdgBlAHIAcwBpAG8AbgAgAG8AZgAgAEMAaAByAG8AbQBpAHUAbQA=')))
Invoke-Item ${00001001100101000}
${01101111111101110} = 1
while (!(${01101111111101110} -eq $null))
{ 
    sleep 5
    ${01101111111101110} = ( Get-Process | ? {$_.ProcessName -match "${00011100101010110}"} )
}
Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcAIABDAGgAcgBvAG0AaQB1AG0AIABJAG4AcwB0AGEAbABsAGUAZAAhACAAUABsAGUAYQBzAGUAIAByAGUAcwB0AGEAcgB0ACAAdABoAGUAIABDAGgAcgBvAG0AaQB1AG0AIABiAHIAbwB3AHMAZQByAA==')))
