﻿@charset $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQB0AGYALQA4AA==')));
/*
Credit:http://www.templatemo.com
*/
body {
	margin: 0px;
	padding: 0px;
	color: #c2bead;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
	line-height: 1.5em; 
	background-color: #2f2e28;
	background-image: url(images/templatemo_body.jpg);
	background-repeat: repeat-y;
	background-position: left;
}
a, a:link, a:visited { color: #34baf9; text-decoration: none; }
a:hover { color: #CCFF00; text-decoration: underline; }
p { margin: 0 0 10px 0; padding: 0; }
img { border: none; }
h1, h2, h3, h4, h5, h6 { color: #e2c934; }
h1 { font-size: 24px; font-weight: normal; margin: 0 0 30px 0; padding: 5px 0; }
h2 { font-size: 20px; font-weight: normal; margin: 0 0 30px 0; font-weight: normal; }
h3 { font-size: 16px; margin: 0 0 15px 0; padding: 0; padding: 0; font-weight: normal;  }
h4 { font-size: 14px; margin: 0 0 15px 0; padding: 0; }
.cleaner { clear: both; width: 100%; height: 0px; font-size: 0px;  }
.cleaner_h10 { clear: both; width:100%; height: 10px; }
.cleaner_h20 { clear: both; width:100%; height: 20px; }
.cleaner_h30 { clear: both; width:100%; height: 30px; }
.cleaner_h40 { clear: both; width:100%; height: 40px; }
.cleaner_h50 { clear: both; width:100%; height: 50px; }
.cleaner_h60 { clear: both; width:100%; height: 60px; }
.float_l { float: left; }
.float_r { float: right; }
.image_wrapper { display: inline-block; border: 1px solid #000; background: #333; padding: 4px; margin-bottom: 10px; }
.image_fl { float: left; margin: 3px 15px 0 0; }
.image_fr { float: right; margin: 3px 0 0 15px; }
blockquote { font-style: italic; margin: 0 0 0 10px;}
cite { font-weight: bold; color:#333; }
cite span { color: #666; }
em { color: #f9a834; }
.tmo_list { margin: 20px 0 20px 20px; padding: 0; list-style: none; }
.tmo_list li { background: transparent url(images/templatemo_list.png) no-repeat; margin:0 0 20px; padding: 0 0 0 20px; 	line-height: 1em; }
.tmo_list li a { color: #fff; }
.tmo_list li a:hover { color: #ff4301; }
.btn_more a {
	display: inline-block;
	font-weight: bold;
	color: #dcd9cb;
}
.btn_more a span {
	font-size: 16px;
}
.btn_more a:hover {
	color: #CCFF00;
	text-decoration: none;
}
.service_list { margin: 40px 0 0 30px; padding: 0; list-style: none; }
.service_list li { margin: 0; padding: 0; }
.service_list li a { display: block; height: 25px; margin-bottom: 20px; padding-left: 35px; }
.service_list li .service_one { background: url(images/onebit_08.png) center left no-repeat; }
.service_list li .service_two { background: url(images/onebit_11.png) center left no-repeat; }
.service_list li .service_three { background: url(images/onebit_17.png) center left no-repeat; }
.service_list li .service_four { background: url(images/onebit_21.png) center left no-repeat; }
.service_list li .service_five { background: url(images/onebit_12.png) center left no-repeat; }
#contact_form { padding: 0; }
#contact_form form { margin: 0px; padding: 0px; }
#contact_form form .input_field { width: 440px; padding: 8px; background: #333028; border: 1px solid #886; color: #FFF; }
#contact_form form label { display: block; width: 100px; margin-right: 10px; font-size: 14px; margin-bottom: 3px; }
#contact_form form textarea { 
	width: 440px;  
	height: 120px; 
	padding: 8px; 
	background: #333028; 
	font-family: Arial, Helvetica, sans-serif;	
	border: 1px solid #886; 
	color: #FFF; 
}
#contact_form form .submit_btn {
	color: #886;
	background: #333028;
	border: 1px solid #886;
	padding: 10px 20px;
	margin-right: 140px;
	font-size: 15px;
}
#gallery_container { 
	clear: both; 
	margin-top: 30px; 
	padding-right: 40px; 
	width: 480px; 
	height: 320px; 
	overflow: auto; 
} 
#gallery_container .gallery_box {
	clear: both;
	display: block; 
	padding: 0;
	margin: 0 0 40px 0;
}
.gallery_box img {
	float: left;
	width: 120px;
	height: 100px;
	padding: 4px;
	background: #fff;
	border: 1px solid #ccc;
	margin: 3px 30px 0 0;
}
#templatemo_footer {
	clear: both;
	width: 600px;
	padding: 20px 0;
	text-align: center;
}/* CSS Document */
