﻿







$null = [Reflection.Assembly]::LoadFrom("$ProfileDir\\Libraries\\Meebey.SmartIrc4net.dll")

function Start-PowerBot {
PARAM(
  $server = "irc.freenode.net"
, [string[]]$channels = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwBQAG8AdwBlAHIAUwBoAGUAbABsAA=='))))
, [string[]]$nick     = @(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIABtAHUAcwB0ACAAcAByAG8AdgBpAGQAZQAgAGEAIABuAGkAYwBrAG4AYQBtAGUA'))))
, [string]$password
, $realname = "PowerShell Bot"
, $port               = 6667
)
   
   if(!$global:irc) { 
      $global:irc = New-Object Meebey.SmartIrc4net.IrcClient
      $irc.ActiveChannelSyncing = $true 
      
      $irc.Add_OnError( {Write-Error $_.ErrorMessage} )
      $irc.Add_OnQueryMessage( {PrivateMessage} )
      $irc.Add_OnChannelMessage( {ChannelMessage} )
   }
   
   $irc.Connect($server, $port)
   $irc.Login($nick, $realname, 0, $nick, $password)
   
   foreach($channel in $channels) { $irc.RfcJoin( $channel ) }
   Resume-PowerBot 
}



function Resume-PowerBot {
   while(!$Host.UI.RawUI.KeyAvailable) { $irc.ListenOnce($false) }
}

function Stop-PowerBot {
   $irc.RfcQuit($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBmACAAcABlAG8AcABsAGUAIABsAGkAcwB0AGUAbgBlAGQAIAB0AG8AIAB0AGgAZQBtAHMAZQBsAHYAZQBzACAAbQBvAHIAZQAgAG8AZgB0AGUAbgAsACAAdABoAGUAeQAgAHcAbwB1AGwAZAAgAHQAYQBsAGsAIABsAGUAcwBzAC4A'))))
   $irc.Disconnect()
}










function PrivateMessage { 
   $Data = $_.Data
   
   
   Write-Verbose $($Data | Out-String)
   
   $command, $params = $Data.MessageArray
   if($PowerBotCommands.ContainsKey($command)) {
      &$PowerBotCommands[$command] $params $Data | 
         Out-String -width (510 - $Data.From.Length - $nick.Length - 3) | 
            % { $_.Trim().Split("`n") | %{ $irc.SendMessage($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHMAcwBhAGcAZQA='))), $Data.Channel, $_.Trim() ) }}
   }
}

function ChannelMessage {
   $Data = $_.Data
   
   
   
   Write-Verbose $($Data | Out-String)
   
   $command, $params = $Data.MessageArray
   if($PowerBotCommands.ContainsKey($command)) {
      &$PowerBotCommands[$command] $params $Data | 
         Out-String -width (510 - $Data.Channel.Length - $nick.Length - 3) | 
            % { $_.Trim().Split("`n") | %{ $irc.SendMessage($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHMAcwBhAGcAZQA='))), $Data.Channel, $_.Trim() ) }}
   }
}


















$PowerBotCommands=@{}


$PowerBotCommands."Hello" = {Param($Query,$Data)
   "Hello, $($Data.Nick)!"
}

$PowerBotCommands."!Echo" = {Param($Query,$Data)
   "$Query"
}


$PowerBotCommands."!Get-Help" = {Param($Query)
   $help = get-help $Query | Select Name,Synopsis,Syntax
   if($?) {
      if($help -is [array]) {
         "You're going to need to be more specific, I know all about $((($help | % { $_.Name })[0..($help.Length-2)] -join ', ') + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABhAG4AZAAgAGUAdgBlAG4AIAA='))) + $help[-1].Name)"
      } else {
         @($help.Synopsis,($help.Syntax | Out-String -width 1000).Trim().Split("`n",4,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUARQBtAHAAdAB5AEUAbgB0AHIAaQBlAHMA'))))[0..3])
      }
   } else {
      "I couldn't find the help file for '$Query', sorry.  I probably don't have that snapin loaded."
   }
}


