﻿function Write-ScriptVariables {
   $globalVars = get-variable -scope Global | % { $_.Name }
   gv -scope Script | ? { $globalVars -notcontains $_.Name } | ? { $_.Name -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwBsAG8AYgBhAGwAVgBhAHIAcwA='))) } | Out-String	
}
