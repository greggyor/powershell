﻿function Test-Help {
    <#
    .Synopsis
        Test-Help -Function Get-USB
    .Description
        Test-Help was written to get information why that !@##$%#$%# help is not working ;)
        For now works only if v2 comments are used (starting with < # and ending with # > )
        Using fancy regex that probably could be shorter, more elegant and so long and so forth... ;)
    .Example
        Test-Help -Function Test-Help
        If you want to find mistakes made by other - try to find yours first. ;)
    .Link
        Not yet implemented
    .Parameter Function
        Name of the function to be tested.
    #>
    param ([string]$Function)
    try {
        ${/=\__/=\/\/\_/\/\} = (Get-Command -CommandType function -Name $function -ErrorAction Stop).definition -split $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAG4A')))
        ${_/\/=\/\/=\/=\/\_} = [regex]$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAcwAqAFwAXAAuACgAPwA8AEsARQBZAD4AXABcAHcAKwApACgAJAB8AFwAXABzACoAKAAkAHwAKAA/ADwAUABBAFIAQQBNAD4AWwBcAFwAdwAtAF0AKwApACkAKAAkAHwAXABcAHMAKgAoAD8APABFAFIAUgBPAFIAPgBcAFwAUwAqACkAJAApACkA')))
        ${/====\___/\__/=\_} = [regex]$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAcwAqADwAIwBcAFwAcwAqACQA')))
        ${______/=\/=\/=\__} = [regex]$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAcwAqACMAPgBcAFwAcwAqACQA')))
        ${_/\__/\/\______/\} = $false
        ${___/\/\__/\___/==} = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBZAE4ATwBQAFMASQBTAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABFAFMAQwBSAEkAUABUAEkATwBOAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBYAEEATQBQAEwARQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBOAFAAVQBUAFMA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBVAFQAUABVAFQAUwA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBPAFQARQBTAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABJAE4ASwA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBPAE0AUABPAE4ARQBOAFQA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBPAEwARQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBVAE4AQwBUAEkATwBOAEEATABJAFQAWQA='))))
        ${__/\___/\/\_/==\/} = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFIAQQBNAEUAVABFAFIA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBPAFIAVwBBAFIARABIAEUATABQAFQAQQBSAEcARQBUAE4AQQBNAEUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBPAFIAVwBBAFIARABIAEUATABQAEMAQQBUAEUARwBPAFIAWQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBFAE0ATwBUAEUASABFAEwAUABSAFUATgBTAFAAQQBDAEUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBYAFQARQBSAE4AQQBMAEgARQBMAFAA'))))
        foreach (${_/==\/\_/\/==\/=\} in ${/=\__/=\/\/\_/\/\}) {
            ${_/==\/\_/\/==\/=\} = ${_/==\/\_/\/==\/=\} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHIA'))), ''
            ${_/\_/=\/===\_/\_/} = "Line : ${_/==\/\_/\/==\/=\} Function : $function"
            if (${_/\__/\/\______/\}) {
                if (${_/\/=\/\/=\/=\/\_}.IsMatch(${_/==\/\_/\/==\/=\})) {
                    # should contain keyword
                    ${_/\/=\/\/=\/=\/\_}.Match(${_/==\/\_/\/==\/=\}) | ForEach-Object {
                        ${___/\/===\/\/\___} = $_.Groups[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SwBFAFkA')))].Value
                        ${/===\__/\/==\/=\_} = $_.Groups[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFIAQQBNAA==')))].Value
                        ${_/====\/\/\__/\/=} = $_.Groups[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSAA==')))].Value
                    }
                    if (![string]::IsNullOrEmpty(${_/====\/\/\__/\/=})) {
                        Write-Host -ForegroundColor Cyan "Unexpected token - not more than two: ${_/====\/\/\__/\/=} ${_/\_/=\/===\_/\_/}"
                        continue
                    }
                    if (${___/\/\__/\___/==} -contains ${___/\/===\/\/\___}) {
                        if (![string]::IsNullOrEmpty(${/===\__/\/==\/=\_})) {
                            Write-Host -ForegroundColor Yellow "Unexpected token - keyword without additional parameters: ${/===\__/\/==\/=\_} ${_/\_/=\/===\_/\_/}"
                            continue
                        }
                    } else {
                        if (${__/\___/\/\_/==\/} -contains ${___/\/===\/\/\___}) {
                            if ([string]::IsNullOrEmpty(${/===\__/\/==\/=\_})) {
                                Write-Host -ForegroundColor Magenta "Missing token - ${___/\/===\/\/\___} should be followed by something, ${_/\_/=\/===\_/\_/}"
                            }
                        } else {
                            # Looks like spelling mistake...
                            Write-Host -ForegroundColor Green "Key probably with spelling mistake: ${___/\/===\/\/\___} ${_/\_/=\/===\_/\_/}"
                        }
                    } 
                } else {
                    if (${______/=\/=\/=\__}.IsMatch(${_/==\/\_/\/==\/=\})) {
                        ${_/\__/\/\______/\} = $false
                    }
                }
            } else {
                if (${/====\___/\__/=\_}.IsMatch(${_/==\/\_/\/==\/=\})) {
                    ${_/\__/\/\______/\} = $true
                }
            }
        }
    } catch {
        Write-Host -ForegroundColor Red "Error: $_ "
    }
}
