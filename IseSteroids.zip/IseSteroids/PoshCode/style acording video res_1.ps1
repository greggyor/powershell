﻿---------------------------------------------------------------------------------------------------------------------------
 this code is copied from http://www.ti4fun.com/myouikar/JavaScript/rotina.aspx?r=JJiKNeLQlIA[[ti&l=STN[ti]5tehuTA[[ti
---------------------------------------------------------------------------------------------------------------------------
<script> 
	document.write($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABkAGkAdgAgAGkAZAA9ACIAZABpAHYAXwBwAGEAbgBlAGwAIgAgAHMAdAB5AGwAZQA9ACIAdwBpAGQAdABoADoAMQAwADAAJQA7ACAAaABlAGkAZwBoAHQAOgA=')))+ (screen.height > 768 ? $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwA4ADAAcAB4AA=='))) : (screen.height > 600 ? $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADAAcAB4AA=='))) : $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA3ADUAcAB4AA=='))))) +$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwAgAG8AdgBlAHIAZgBsAG8AdwA6AGEAdQB0AG8AOwAiAD4A'))));

</script>
--------------------------------------------------
 See more codes in http://www.ti4fun.com/myouikar
--------------------------------------------------
