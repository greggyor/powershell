﻿function Combine-CSV{
param(
	[Parameter(Position=0,Mandatory=$true,HelpMessage="Please provide the folder which contains your .CSV files.")]
	$SourceFolder,
	[Parameter(Position=1,Mandatory=$false,HelpMessage="Please provide any Get-ChildItem filter you would like to apply")]
	[String]$Filter,
	[Parameter(Position=2,Mandatory=$false,HelpMessage="Please provide exported CSV filename")]
	[String]$ExportFileName
	)
Begin{
If ($SourceFolder.EndsWith("\\") -eq $false){
	$SourceFolder = $SourceFolder + "\\"
}
Write-Verbose "Source Folder is $SourceFolder"
If ((Test-Path $SourceFolder) -eq $True){
	${01111110100011010} = Get-childitem -Path $SourceFolder -Filter $Filter | Sort
	${10110111001010011} = (${01111110100011010}).Count
	Write-Verbose "Combining ${10110111001010011} .CSV files"
	${00001111001011011} = gc (${01111110100011010} | Select -First 1).FullName
}Else{
	echo "Path $SourceFolder does not exist"
}
}
Process{
	foreach(${01010001110000011} in (${01111110100011010} | Select -Skip 1)){
		${00001111001011011} = ${00001111001011011} + (gc ${01010001110000011}.FullName | Select -Skip 1)
	}
}
End{
	If($ExportFileName -ne ""){
		${10111011111101101} = $SourceFolder + $ExportFileName
		Write-Verbose "Writing output to file ${10111011111101101}"
		sc -Path ${10111011111101101} -Value (${00001111001011011})
	} Else {
	return ${00001111001011011}
	}
}
}
