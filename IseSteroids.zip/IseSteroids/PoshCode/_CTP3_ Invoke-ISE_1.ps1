﻿Set-Alias ISE Invoke-ISE  
function Invoke-ISE ()

       
{
    param (     
        [Parameter(Position = 0, 
                    Mandatory=$false, 
                    ValueFromPipeline=$True, 
                    ValueFromRemainingArguments = $true)]
        [string[]]$file    
    )     
    begin {
        $path="$pshome\\powershell_ise.exe"
        if ($file -eq $null){
            & $path
        }
    }  
    PROCESS {
            foreach($f in $file){
                
                
                
                & $path ( ([system.IO.FileInfo]$f).FullName)     
            }    
    }
}
