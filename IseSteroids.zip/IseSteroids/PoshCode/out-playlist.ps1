﻿
param( 
	[parameter(Mandatory=$true)]
	[string]
	$name,
	[parameter(Mandatory=$true,ValueFromPipeline=$true)]
	$file
)
begin
{
	$script:files = @();
}
process
{
	$script:files += $file.fullname;
}
end
{
	$count = $script:files.length;
	$mediaElements = $script:files | foreach{
		$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABtAGUAZABpAGEAIABzAHIAYwA9ACcAJABfACcAIAAvAD4A')))
	};
[xml]$playlist = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAA/AHcAcABsACAAdgBlAHIAcwBpAG8AbgA9ACIAMQAuADAAIgA/AD4ADQAKADwAcwBtAGkAbAA+AA0ACgAgACAAIAAgADwAaABlAGEAZAA+AA0ACgAgACAAIAAgACAAIAAgACAAPABtAGUAdABhACAAbgBhAG0AZQA9ACIARwBlAG4AZQByAGEAdABvAHIAIgAgAGMAbwBuAHQAZQBuAHQAPQAiAG8AdQB0AC0AcABsAGEAeQBsAGkAcwB0AC4AcABzADEAIgAvAD4ADQAKACAAIAAgACAAIAAgACAAIAA8AG0AZQB0AGEAIABuAGEAbQBlAD0AIgBJAHMATgBlAHQAdwBvAHIAawBGAGUAZQBkACIAIABjAG8AbgB0AGUAbgB0AD0AIgAwACIALwA+AA0ACgAgACAAIAAgACAAIAAgACAAPABtAGUAdABhACAAbgBhAG0AZQA9ACIASQB0AGUAbQBDAG8AdQBuAHQAIgAgAGMAbwBuAHQAZQBuAHQAPQAiACQAYwBvAHUAbgB0ACIALwA+AA0ACgAgACAAIAAgACAAIAAgACAAPAB0AGkAdABsAGUAPgAkAG4AYQBtAGUAPAAvAHQAaQB0AGwAZQA+AA0ACgAgACAAIAAgADwALwBoAGUAYQBkAD4ADQAKACAAIAAgACAAPABiAG8AZAB5AD4ADQAKACAAIAAgACAAIAAgACAAIAA8AHMAZQBxAD4ADQAKAAkACQAJACQAbQBlAGQAaQBhAEUAbABlAG0AZQBuAHQAcwANAAoAIAAgACAAIAAgACAAIAAgADwALwBzAGUAcQA+AA0ACgAgACAAIAAgADwALwBiAG8AZAB5AD4ADQAKADwALwBzAG0AaQBsAD4A')));
	new-item $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fgBcAFwAZABvAGMAdQBtAGUAbgB0AHMAXABcAG0AeQAgAG0AdQBzAGkAYwBcAFwAcABsAGEAeQBsAGkAcwB0AHMAXABcACQAbgBhAG0AZQAuAHcAcABsAA=='))) -value '' -type file -force | out-null;
	$playlist.save( ($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fgBcAFwAZABvAGMAdQBtAGUAbgB0AHMAXABcAG0AeQAgAG0AdQBzAGkAYwBcAFwAcABsAGEAeQBsAGkAcwB0AHMAXABcACQAbgBhAG0AZQAuAHcAcABsAA=='))) | resolve-path) );
}
