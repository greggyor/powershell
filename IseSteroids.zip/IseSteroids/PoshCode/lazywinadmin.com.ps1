﻿Get-WmiObject Win32_Service -ComputerName . |`
	where 	{($_.startmode -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBhAHUAdABvACoA')))) -and `
		($_.state -notlike $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgByAHUAbgBuAGkAbgBnACoA'))))}|`
	select DisplayName,Name,StartMode,State|ft -AutoSize
