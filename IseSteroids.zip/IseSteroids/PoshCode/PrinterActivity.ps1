﻿
${3} = Get-Date -UFormat %Y%m%d
Write-Host "What server do you want to get the eventlog from?"
${4} = Read-Host
Write-Host "Getting eventlog from remote server "${4}". Please wait..."
Write-Host "Please wait... (this might take a few minutes)"
${9} = gwmi -ComputerName ${4} -query "select * from win32_ntlogevent where logfile='system' and eventcode='10' and sourcename='print'" | Select-Object EventCode, Timegenerated, Message | sort Timegenerated
${2} = Get-WmiObject -computername ${4} Win32_Printer | Select-Object Portname, DeviceID, __server, name
${10} = [System.Management.ManagementDateTimeConverter]::ToDateTime(${9}[0].TimeGenerated)
Write-Host "Oldest logentry is from:" ${10}
Write-Host "How many months back do you want to check?"
${7} = Read-Host
if ((Test-Path -path ${4}) -ne $True)
{
	New-Item -type directory -path ${4}
}
${1} = 0
while (${1} -ne (${2}.count-1))
{
	${5} = 0
	foreach (${6} in ${9})
	{
		${8} = ([System.Management.ManagementDateTimeConverter]::ToDateTime(${6}.TimeGenerated)) 
		if (${8} -gt $(Get-Date).AddMonths(-${7}) -and (${6}.message -match ${2}[${1}].name ))
		{
			${5} = 1
		}
	}
	if (${5}) 
	{
		write-host -ForegroundColor Green ${2}[${1}].name"is in use!" 
		add-content -path ${4}\\Validprinters_${3}.txt -Value ${2}[${1}].name
	}
	else 
	{
		write-host -ForegroundColor red ${2}[${1}].name "is not in use!"
		add-content -path ${4}\\Invalidprinters_${3}.txt -Value ${2}[${1}].name
	}
	${1}=${1}+1
}
