﻿#Change these settings as needed
#MS Access 2007 Data Components required
${_/=\__/=\/==\/====} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AdgBpAGQAZQByAD0ATQBpAGMAcgBvAHMAbwBmAHQALgBBAEMARQAuAE8ATABFAEQAQgAuADEAMgAuADAAOwBXAFMAUwA7AEkATQBFAFgAPQAyADsAUgBlAHQAcgBpAGUAdgBlAEkAZABzAD0AWQBlAHMAOwAgAEQAQQBUAEEAQgBBAFMARQA9AGgAdAB0AHAAOgAvAC8AcwBoAGEAcgBlAHAAbwBpAG4AdAAuAGEAYwBtAGUALgBjAG8AbQAvADsATABJAFMAVAA9AHsAOQA2ADgAMAAxADQAMwAyAC0AMgBkADAAMwAtADQAMgBiADgALQA4ADIAYgAwAC0AYQBjADkANgBjAGEAOQBmAGUAYQA4AGEAfQA7AA==')))
#See http://chadwickmiller.spaces.live.com/blog/cns!EA42395138308430!275.entry for instructions on obtaining list GUID
${______/=====\/\/=\} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQAIABUAGkAdABsAGUALABOAG8AdABlAHMALABDAHIAZQBhAHQAZQBEAGEAdABlACwAIABNAG8AZABpAGYAaQBlAGQALAAgAEMAcgBlAGEAdABlAGQAIABmAHIAbwBtACAAbABpAHMAdAA=')))
#Create a table in destination database with the with referenced columns and table name.
${/==\_/=\/==\/\/\/} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WgAwADAAMgBcAFwAUwBRAEwAMgBLADgA')))
${_/\/=\__/==\__/=\} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBRAEwAUABTAFgA')))
${_/\__/==\/\__/\__} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBwAGwAaQBzAHQAXwBmAGkAbABsAA==')))
#######################
function ____/\/===\/\____/
{
    param(${_/=\__/=\/==\/====}, ${______/=====\/\/=\}='select * from list')
    ${__/\/\/=\____/=\_} = new-object System.Data.OleDb.OleDbConnection(${_/=\__/=\/==\/====})
    ${__/\/\/=\____/=\_}.open()
    ${/===\__/\__/==\_/} = new-object System.Data.OleDb.OleDbCommand(${______/=====\/\/=\},${__/\/\/=\____/=\_}) 
    ${_/\______/==\__/=} = new-object System.Data.OleDb.OleDbDataAdapter(${/===\__/\__/==\_/}) 
    ${/=\/\______/=\/\/} = new-object System.Data.dataTable 
    ${_/\______/==\__/=}.fill(${/=\/\______/=\/\/}) > $null
    ${/=\/\______/=\/\/}
} #Get-SPList
#######################
function __/\_/=\/=\/==\/=\
{ 
    param(${_/=\_/\/==\__/\/\/},${_/===\__/\/======\},${___/====\/\/===\__})
    process
    {
        ${/===\_/\/====\/\_} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQAgAFMAbwB1AHIAYwBlAD0AJAB7AF8ALwA9AFwAXwAvAFwALwA9AD0AXABfAF8ALwBcAC8AXAAvAH0AOwBJAG4AdABlAGcAcgBhAHQAZQBkACAAUwBlAGMAdQByAGkAdAB5AD0AdAByAHUAZQA7AEkAbgBpAHQAaQBhAGwAIABDAGEAdABhAGwAbwBnAD0AJAB7AF8ALwA9AD0APQBcAF8AXwAvAFwALwA9AD0APQA9AD0APQBcAH0AOwA=')))
        ${_/=\__/\__/=\/==\} = new-object ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQAuAFMAcQBsAEMAbABpAGUAbgB0AC4AUwBxAGwAQgB1AGwAawBDAG8AcAB5AA==')))) ${/===\_/\/====\/\_}
        ${_/=\__/\__/=\/==\}.DestinationTableName = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwBfAC8APQA9AD0APQBcAC8AXAAvAD0APQA9AFwAXwBfAH0A')))
        ${_/=\__/\__/=\/==\}.WriteToServer($_)
    }
}# Write-DataTableToDatabase
#######################
____/\/===\/\____/ ${_/=\__/=\/==\/====} ${______/=====\/\/=\} | __/\_/=\/=\/==\/=\ ${/==\_/=\/==\/\/\/} ${_/\/=\__/==\__/=\} ${_/\__/==\/\__/\__}
