﻿
Set-Variable -name 11 -value 25 -option constant
Set-Variable -name 10 -value 80 -option constant
Set-Variable -name 9 -value 389 -option constant
Set-Variable -name 8 -value 410 -option constant
Set-Variable -name 7 -value 443 -option constant
Set-Variable -name 12 -value 1352 -option constant 
${2} = @{}
${1} = @{}
${6} = @{}
${5} = @{}
${5}["SERVER01"] = @{Notes=$True;}
${5}["SERVER02"] = @{SMTP=$True; WWW=$True; Notes=$True;}
${5}["SERVER03"] = @{SMTP=$True; WWW=$True; Notes=$True;}
${5}["SERVER04"] = @{WWW=$True; Notes=$True;}
${5}["SERVER05"] = @{WWW=$True; Notes=$True;}
${5}["SERVER06"] = @{Notes=$True;}
${5}["SERVER07"] = @{Notes=$True;}
${5}["SERVER08"] = @{Notes=$True;}
${5}["SERVER09"] = @{Notes=$True;}
${5}["SERVER10"] = @{Notes=$True;}
${5}["SERVER11"] = @{Notes=$True;}
${5}["SERVER12"] = @{Notes=$True;}
${5}["SERVER13"] = @{Notes=$True;}
${5}["SERVER14"] = @{Notes=$True;}
${5}["SERVER15"] = @{Notes=$True;}
${5}["SERVER16"] = @{Notes=$True;}
${5}["SERVER17"] = @{Notes=$True;}
${5}["SERVER18"] = @{Notes=$True;}
${5}["SERVER19"] = @{Notes=$True;}
${5}["SERVER20"] = @{SMTP=$True; Notes=$True;}
${5}["SERVER21"] = @{SMTP=$True; Notes=$True;}
${5}["SERVER22"] = @{SMTP=$True; Notes=$True;}
${5}["SERVER23"] = @{SMTP=$True; Notes=$True;}
${5}["SERVER24"] = @{WWW=$True; SSL=$True; Notes=$True;}
${5}["SERVER25"] = @{Notes=$True;}
${5}["SERVER26"] = @{WWW=$True; Notes=$True; SameTime=$True;}
${4} = 1516, 1533, 8081, 8082, 1503, 554
function f1([string]$server, [int]$port)
{
${14} = New-Object System.Net.Sockets.TcpClient
trap { 
	$False
	continue;
}
${14}.Connect($server,$port)
if (${14}.Connected) {$True}           
}
function f2([string]$server) 
{
${13} = New-Object System.Net.NetworkInformation.Ping
  trap { 
   $False
    continue;
  }
If (${13}.send($server).status -eq "Success") {$True}
${13} = $null
}
${5}.Keys | ForEach-Object {
 If (f2 $_) {
 			Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfACAAcgBlAHMAcABvAG4AZABlAGQALgA='))) -ForeGroundColor Green
 			${6}[$_] += @{HOST=$True;}
 			If (${5}[$_].notes) { 
 				If (f1 $_ ${12}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABMAG8AdAB1AHMAIABOAG8AdABlAHMAIABQAG8AcgB0ACAAKAAkAHsAMQAyAH0AKQAgAFIAZQBzAHAAbwBuAGQAaQBuAGcA'))) -ForeGroundColor Green
 					${6}[$_] += @{NOTES=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAE4AbwB0AGUAcwAgACgAJAB7ADEAMgB9ACkAIABiAHUAdAAgAGkAdAAgAGkAcwAgAG4AbwB0ACAAcgBlAHMAcABvAG4AZABpAG4AZwAuAA=='))) -ForeGroundColor Red
 					${2}[$_] += @{NOTES=$True;} 				
 					}
 				}
 			If (${5}[$_].smtp) { 
 				If (f1 $_ ${11}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABTAE0AVABQACAAKAAkAHsAMQAxAH0AKQAgAFIAZQBzAHAAbwBuAGQAaQBuAGcA'))) -Foregroundcolor green	
 					${6}[$_] += @{SMTP=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAFMATQBUAFAALAAgAGIAdQB0ACAAaQB0ACAAaQBzACAAbgBvAHQAIAByAGUAcwBwAG8AbgBkAGkAbgBnAC4A'))) -Foregroundcolor red
 					${2}[$_] += @{SMTP=$True;}
 					}
 				}
 			If (${5}[$_].www) { 
 				If (f1 $_ ${10}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABXAFcAVwAgACgAJAB7ADEAMAB9ACkAIABSAGUAcwBwAG8AbgBkAGkAbgBnAA=='))) -foregroundcolor green
 					${6}[$_] += @{WWW=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAFcAVwBXACwAIABiAHUAdAAgAGkAdAAgAGkAcwAgAG4AbwB0ACAAcgBlAHMAcABvAG4AZABpAG4AZwAuAA=='))) -foregroundcolor red
 					${2}[$_] += @{WWW=$True;}
 					}
 				}
 			If (${5}[$_].ldap) { 
 				If (f1 $_ ${9}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABMAEQAQQBQACAAKAAkAHsAOQB9ACkAIABSAGUAcwBwAG8AbgBkAGkAbgBnAA=='))) -foregroundcolor green
 					${6}[$_] += @{LDAP=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAEwARABBAFAALAAgAGIAdQB0ACAAaQB0ACAAaQBzACAAbgBvAHQAIAByAGUAcwBwAG8AbgBkAGkAbgBnAC4A'))) -foregroundcolor red
 					${2}[$_] += @{LDAP=$True;}
 					}
 				}
 			If (${5}[$_].port410) { 
 				If (f1 $_ ${8}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABQAG8AcgB0ACAANAAxADAAIAAoACQAewA4AH0AKQAgAFIAZQBzAHAAbwBuAGQAaQBuAGcA'))) -foregroundcolor green
 					${6}[$_] += @{Port410=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAHAAbwByAHQAIAA0ADEAMAAsACAAYgB1AHQAIABpAHQAIABpAHMAIABuAG8AdAAgAHIAZQBzAHAAbwBuAGQAaQBuAGcALgA='))) -foregroundcolor red
 					${2}[$_] += @{Port410=$True;}
 					}
 				} 		
 			If (${5}[$_].ssl) { 
 				If (f1 $_ ${7}) { 
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABTAFMATAAgACgAJAB7ADcAfQApACAAUgBlAHMAcABvAG4AZABpAG4AZwA='))) -foregroundcolor green
 					${6}[$_] += @{SSL=$True;}
 					} else {
 					Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfADoAIABIAG8AcwB0ACAAaQBzACAAcgBlAHAAbwByAHQAZQBkACAAdABvACAAaABhAHYAZQAgAFMAUwBMACwAIABiAHUAdAAgAGkAdAAgAGkAcwAgAG4AbwB0ACAAcgBlAHMAcABvAG4AZABpAG4AZwAuAA=='))) -foregroundcolor red
 					${2}[$_] += @{SSL=$True;}
 					}
 				}
 			If (${5}[$_].sametime) { 
 			  ${3} = $_
 			  ${4} | ForEach-Object { 
 			  	If (f1 ${3} $_) {
 			  		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABzAHQAOgAgAFMAYQBtAGUAVABpAG0AZQAgAFAAbwByAHQAIAAkAF8AIABTAHUAYwBjAGUAcwBzAC4A'))) -foregroundcolor green
 			  		} else {
 			  		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABzAHQAOgAgAFMAYQBtAGUAVABpAG0AZQAgAFAAbwByAHQAIAAkAF8AIABOAG8AdAAgAFIAZQBzAHAAbwBuAGQAaQBuAGcALgA='))) -foregroundcolor red
 			  		${1}[${3}] += @{$_=$True;}
 			  		}
 			  	}
 			  }
 			} else {
 			Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABvAHMAdAAgACQAXwAgAGkAcwAgAG4AbwB0ACAAcgBlAHMAcABvAG4AZABpAG4AZwAuAA=='))) -ForeGroundColor Red
 			${2}[$_] += @{HOST=$True;}
 			}
 }
If (${2}.count -gt 0) {
	Write-Host "`n`nCompleted - Errors reported - the following ping tests failed:" -ForeGroundColor Magenta
	Write-Host "`nServer `t`tFailed Ports" -Foregroundcolor Magenta
	Write-Host "----------------------------------------" -ForegroundColor Magenta
	${2}.Keys | ForEach-Object {
			Write-host "$($_): `t$(${2}[$_].Keys)" -ForeGroundColor Magenta
			}
    } else {
    Write-Host "`n`nCompleted - All ports are responding." -ForegroundColor Green
}
If (${1}.count -gt 0) {
	Write-Host "Errors reported within the SameTime environment" -Foregroundcolor Magents
	} else {
	Write-Host "SameTime Environment is fully responsive." -ForegroundColor Green 
}
