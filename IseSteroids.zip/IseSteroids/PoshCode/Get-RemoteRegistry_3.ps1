﻿#.SYNOPSIS
#  Query the registry on a remote machine
#.NOTE
#  You have to have access, and the remote registry service has to be running
#
# Version History:
#   3.0
#       + updated to PowerShell 2 
#       + support pipeline parameter for path
#   2.1
#       + Fixed a pasting bug 
#       + I added the "Properties" parameter so you can select specific redgistry values
# ######################################################################################
#.EXAMPLE
#      (Get-RemoteRegistry ${Env:ComputerName} HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\).Subkeys | 
#         Get-RemoteRegistry ${Env:ComputerName} `
#         -Path { "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\$_" } `
#         -Properties DisplayName, DisplayVersion, Publisher, InstallDate, HelpLink, UninstallString
#.EXAMPLE
#   Get-RemoteRegistry $RemotePC "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP"
#     * Returns a list of subkeys (because this key has no properties)
#.EXAMPLE
#   Get-RemoteRegistry $RemotePC "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v2.0.50727"
#     * Returns a list of subkeys and all the other "properties" of the key
#.EXAMPLE
#   Get-RemoteRegistry $RemotePC "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v2.0.50727\\Version"
#     * Returns JUST the full version of the .Net SP2 as a STRING (to preserve prior behavior)
#.EXAMPLE
#   Get-RemoteRegistry $RemotePC "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v2.0.50727" Version
#     * Returns a custom object with the property "Version" = "2.0.50727.3053" (your version)
#.EXAMPLE
#   Get-RemoteRegistry $RemotePC "HKLM\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v2.0.50727" Version,SP
#     * Returns a custom object with "Version" and "SP" (Service Pack) properties
#
#  For fun, get all .Net Framework versions (2.0 and greater) 
#  and return version + service pack with this one command line:
#
#    Get-RemoteRegistry $RemotePC "HKLM:\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP" | 
#    Select -Expand Subkeys | ForEach-Object { 
#      Get-RemoteRegistry $RemotePC "HKLM:\\SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\$_" Version,SP 
#    }
param(
    [Parameter(Position=0, Mandatory=$true)]
    [string]$computer = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB0AGUAIABDAG8AbQBwAHUAdABlAHIAIABOAGEAbQBlAA=='))))
,
    [Parameter(Position=1, ValueFromPipelineByPropertyName=$true,ValueFromPipeline=$true, Mandatory=$true)]
    [string]${_/\/====\__/=\/==}     = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB0AGUAIABSAGUAZwBpAHMAdAByAHkAIABQAGEAdABoACAAKABtAHUAcwB0ACAAcwB0AGEAcgB0ACAAdwBpAHQAaAAgAEgASwBMAE0ALABIAEsAQwBVACwAZQB0AGMAKQA='))))
,
    [Parameter(Position=2)]
    [string[]]$Properties
)
process {
   ${____/==\___/===\_}, ${___/=\___/===\/\/} = ${_/\/====\__/=\/==}.Split("\\")
   ${___/=\___/===\/\/} = ${___/=\___/===\/\/}[-1]
   ${_/\/====\__/=\/==} = ${_/\/====\__/=\/==}.Substring(${____/==\___/===\_}.Length + 1,${_/\/====\__/=\/==}.Length - ( ${___/=\___/===\/\/}.Length + ${____/==\___/===\_}.Length + 2))
   ${____/==\___/===\_} = ${____/==\___/===\_}.TrimEnd(":")
   #split the path to get a list of subkeys that we will need to access
   # ClassesRoot, CurrentUser, LocalMachine, Users, PerformanceData, CurrentConfig, DynData
   switch(${____/==\___/===\_}) {
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAUgA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAGEAcwBzAGUAcwBSAG8AbwB0AA==')))}
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB1AHIAcgBlAG4AdABVAHMAZQByAA=='))) }
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGMAYQBsAE0AYQBjAGgAaQBuAGUA'))) }
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAFUA')))   { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBzAA=='))) }
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAFAARAA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAZgBvAHIAbQBhAG4AYwBlAEQAYQB0AGEA')))}
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAQwA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB1AHIAcgBlAG4AdABDAG8AbgBmAGkAZwA=')))}
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEQARAA=')))  { ${____/==\___/===\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAB5AG4ARABhAHQAYQA=')))}
      default { return $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHQAaAAgAGEAcgBnAHUAbQBlAG4AdAAgAGkAcwAgAG4AbwB0ACAAdgBhAGwAaQBkAA=='))) }
   }
   #Access Remote Registry Key using the static OpenRemoteBaseKey method.
   Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAGMAZQBzAHMAaQBuAGcAIAAkAHsAXwBfAF8AXwAvAD0APQBcAF8AXwBfAC8APQA9AD0AXABfAH0AIABmAHIAbwBtACAAJABjAG8AbQBwAHUAdABlAHIA')))
   ${/====\_/======\/\} = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(${____/==\___/===\_},$computer)
   if(-not ${/====\_/======\/\}) { Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBhAG4AJwB0ACAAbwBwAGUAbgAgAHQAaABlACAAcgBlAG0AbwB0AGUAIAAkAHsAXwBfAF8AXwAvAD0APQBcAF8AXwBfAC8APQA9AD0AXABfAH0AIAByAGUAZwBpAHMAdAByAHkAIABoAGkAdgBlAA=='))) }
   Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgBpAG4AZwAgACQAewBfAC8AXAAvAD0APQA9AD0AXABfAF8ALwA9AFwALwA9AD0AfQA=')))
   ${/====\/=\_/==\/\_} = ${/====\_/======\/\}.OpenSubKey( ${_/\/====\__/=\/==} )
   if(-not ${/====\/=\_/==\/\_}) { Write-Error "Can't open $(${____/==\___/===\_} + '\\' + ${_/\/====\__/=\/==}) on $computer" }
   ${/=\_/\_/\/\__/\__} = ${/====\/=\_/==\/\_}.OpenSubKey( ${___/=\___/===\/\/} )
   ${_/=\_/=\__/=\_/\_} = new-object object
   if(${/=\_/\_/\/\__/\__} -and $Properties -and $Properties.Count) {
      foreach(${_/=\__/\___/=\_/\} in $Properties) {
         Add-Member -InputObject ${_/=\_/=\__/=\_/\_} -Type NoteProperty -Name ${_/=\__/\___/=\_/\} -Value ${/=\_/\_/\/\__/\__}.GetValue(${_/=\__/\___/=\_/\})
      }
      echo ${_/=\_/=\__/=\_/\_}
   } elseif(${/=\_/\_/\/\__/\__}) {
      Add-Member -InputObject ${_/=\_/=\__/=\_/\_} -Type NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGIAawBlAHkAcwA='))) -Value @(${/=\_/\_/\/\__/\__}.GetSubKeyNames())
      foreach(${_/=\__/\___/=\_/\} in ${/=\_/\_/\/\__/\__}.GetValueNames()) {
         Add-Member -InputObject ${_/=\_/=\__/=\_/\_} -Type NoteProperty -Name ${_/=\__/\___/=\_/\} -Value ${/=\_/\_/\/\__/\__}.GetValue(${_/=\__/\___/=\_/\})
      }
      echo ${_/=\_/=\__/=\_/\_}
   }
   else
   {
      ${/====\/=\_/==\/\_}.GetValue(${___/=\___/===\/\/})
   }
}
