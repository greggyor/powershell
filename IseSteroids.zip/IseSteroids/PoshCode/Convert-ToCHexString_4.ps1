﻿function Convert-ToCHexString {
[CmdletBinding()]
param (
    [Parameter(ValueFromPipeline=$true,Mandatory=$true)][string]$str
)    
   process { ($str.ToCharArray() | %{ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAB4AHsAMAA6AFgAMgB9AA=='))) -f [int]$_  }) -join ',' }
}
