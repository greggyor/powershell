﻿function Get-LocalGroupMembers {
	param($groupname)

	${_/=\/==\__/\__/\/} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBOAGEAbQBlAD0AIgAkAGcAcgBvAHUAcABuAGEAbQBlACIA')))
	${_/\/\_/\_/\/\/\/=} = gwmi Win32_GroupUser | Where { $_.GroupComponent -like ${_/=\/==\__/\__/\/} }

	
	foreach (${_/\/\/\/\/\/\/\_/} in ${_/\/\_/\_/\/\/\/=}) {
		if (${_/\/\/\/\/\/\/\_/}.PartComponent -match 'Name="([^"]+)') {
			Write-Output $matches[1]
		}
	}
}




