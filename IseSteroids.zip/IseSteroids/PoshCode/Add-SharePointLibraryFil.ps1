﻿Add-SharePointLibraryFile
{
	param
	(
		[System.IO.FileInfo] $File, 
		[System.Uri] $DocumentLibraryUrl = $(throw "Parameter -DocumentLibraryUrl [System.Uri] is required.")
	)

	Begin
	{ }
	
	Process
	{
		if($_)
		{
			$File = [System.IO.FileInfo] $_
		}
		
		if (!$File.Exists)
		{
			Write-Error ($File.ToString() + " does not exist.")
			return $null
		}
		
		trap
		{
			Write-Error $_.Exception.Message
			break
		}
	
		[string]${9} = $DocumentLibraryUrl
		if (-not ${9}.EndsWith("/")) {
			${9} += "/";
		}
		${9} += $File.Name
	
		#Create a PUT Web request to upload the file.
		${3} = [System.Net.WebRequest]::Create(${9})
	
		#Set credentials of the current security context
		${3}.Credentials = [System.Net.CredentialCache]::DefaultCredentials
		${3}.Method = "PUT";
	
		# Create buffer to transfer file		
		${6} = New-Object byte[] 1024
	
		# Write the contents of the local file to the request stream.
		${4} = ${3}.GetRequestStream()
		
		${7} = $file.OpenRead()
		
		#Get the start point
		${8} = ${7}.Read(${6}, 0, ${6}.Length);
		
		for (${5} = ${8}; ${5} -gt 0; ${5} = ${7}.Read(${6}, 0, ${6}.Length))
		{
			${4}.Write(${6}, 0, ${5});
		}
		
		${4}.Close()
	
		# Perform the PUT request
		${2} = ${3}.GetResponse();
	
		#Close response
		${2}.Close();
	}
	
	End
	{ }
}


${1} = "http://sharepoint/sites/andy/files"

gi 'C:\\Documents and Settings\\andy\\Desktop\\doc.pdf' | Add-SharePointLibraryFile -DocumentLibraryUrl ${1}

