﻿[CmdletBinding()]
param(
	[string]$Path = 'C:\\',
	[string]$User1 = "$Env:USERDOMAIN\\$Env:UserName",
	[string]$User2 = "BuiltIn\\Administrators",
	[switch]$recurse
)
foreach(${1} in ls $path -recurse:$recurse) { 
	${2} = @(get-acl ${1}.FullName | select -expand Access | Where IdentityReference -in $user1,$user2) 
	if(${2}.Count -eq 1) { 
		Write-Warning "Only $(${2}[0].IdentityReference) has access to $(${1}.FullName)"
	} elseif(${2}.Count -eq 2) { 
		if(compare-object ${2}[0] ${2}[1] -Property FileSystemRights, AccessControlType) { 
			Write-Warning "Different rights to $(${1}.FullName)" 
		}
	} # if acl.count -eq 0 they're the same
}
