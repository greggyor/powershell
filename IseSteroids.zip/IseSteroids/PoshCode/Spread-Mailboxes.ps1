﻿
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue
foreach (${__/\/\__/\__/\___} in (Get-Mailbox -ResultSize unlimited)) {
${_/\____/=\/=\____} = ${__/\/\__/\__/\___}.Displayname
switch -regex (${_/\____/=\/=\____}.substring(0,1)) 
    { 
       "[A-F]" {${/======\_/=\/\/=\} = "MDB A-F"} 
       "[G-L]" {${/======\_/=\/\/=\} = "MDB G-L"} 
       "[M-R]" {${/======\_/=\/\/=\} = "MDB M-R"} 
       "[S-X]" {${/======\_/=\/\/=\} = "MDB S-X" } 
       "[Y-Z]" {${/======\_/=\/\/=\} = "MDB Y-Z" } 
        default {${/======\_/=\/\/=\} = "MDB Y-Z" }
    }
if ((${__/\/\__/\__/\___}.database.name) -ne ${/======\_/=\/\/=\}) {New-MoveRequest -Identity ${__/\/\__/\__/\___} -TargetDatabase ${/======\_/=\/\/=\};Write-Host "Moving ${_/\____/=\/=\____} to ${/======\_/=\/\/=\}" -ForegroundColor Green}
}
