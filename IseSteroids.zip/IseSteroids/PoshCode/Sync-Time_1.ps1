﻿function sync-time(
[string] $server = "clock.psu.edu",
[int] $port = 37)
{
  ${1} = get-time -server $server -port $port -set
  
  write-host "Server time:" ${1} 
  write-host "Local time :" $(date)
}
