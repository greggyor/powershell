﻿#Params is file or folder
param([string] $PSUnitTestFile, [string] $Category ="All", [switch] $ShowReportInBrowser)

Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQALgBSAHUAbgAuAHAAcwAxADoAIABQAGEAcgBhAG0AZQB0AGUAcgAgACQAUABTAFUAbgBpAHQAVABlAHMAdABGAGkAbABlAD0AIgAkAFAAUwBVAG4AaQB0AFQAZQBzAHQARgBpAGwAZQAiAA==')))
Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQALgBSAHUAbgAuAHAAcwAxADoAIABQAGEAcgBhAG0AZQB0AGUAcgAgACQAQwBhAHQAZQBnAG8AcgB5AD0AIgAkAEMAYQB0AGUAZwBvAHIAeQAiAA==')))

#Don't run the script with an empty path to test file
if ([String]::IsNullOrEmpty($PSUnitTestFile))
{
    Throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAAkAFAAUwBVAG4AaQB0AFQAZQBzAHQARgBpAGwAZQAgAHAAYQByAGEAbQBlAHQAZQByACAAaQBzACAAcgBlAHEAdQBpAHIAZQBkACEA')))
}

#Make sure the test file exists
if( ! (Test-Path -Path $PSUnitTestFile) )
{
    Throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABQAFMAVQBuAGkAdABUAGUAcwB0AEYAaQBsAGUAOgAgACQAUABTAFUAbgBpAHQAVABlAHMAdABGAGkAbABlACAAaQBzACAAbgBvAHQAIABhACAAdgBhAGwAaQBkACAAZgBpAGwAZQAhAA==')))
}

#This is there to prevent this script from running itself as a test
$PSUnitTestFileInfo = gi -Path $PSUnitTestFile
if ($PSUnitTestFileInfo.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQALgBSAHUAbgAuAHAAcwAxAA=='))))
{
    Throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGkAcwAgAHMAYwByAGkAcAB0ACAAYwBhAG4AJwB0ACAAcgB1AG4AIABpAHQAcwBlAGwAZgAgAGEAcwAgAGEAIAB0AGUAcwB0ACEA')))
}



#Data Model for the test result report
$TestEnvironment = @{}
$TestStatistics = @{}
$TestResults = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBDAG8AbABsAGUAYwB0AGkAbwBuAHMALgBBAHIAcgBhAHkATABpAHMAdAA=')))
$Statistics = @{}
$TestStartTime = [DateTime]::Now
$TestEndTime = [DateTime]::Now

#Deleting test functions from global scope
$TestFunctions = gi function:Test.*
If ($TestFunctions)
{
  Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQALgBSAHUAbgAuAHAAcwAxADoAIABEAGUAbABlAHQAaQBuAGcAIAB0AGUAcwB0ACAAZgB1AG4AYwB0AGkAbwBuAHMAIABmAHIAbwBtACAAZwBsAG8AYgBhAGwAIABzAGMAbwBwAGUAIQA=')))
  $TestFunctions | rd
}

#Loading test functions into global scope
$ScriptLines = gc -Path $PSUnitTestFile -Encoding $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBUAEYAOAA=')))
$ScriptText = [String]::Join("`n`r", $ScriptLines)
iex $ScriptText 

#Make sure that the $PSTestScript has tests defined
if (! (Test-Path -Path function:Test.*))
{
    Throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQAIAAiACQAUABTAFUAbgBpAHQAVABlAHMAdABGAGkAbABlACIAIABkAG8AZQBzAG4AJwB0ACAAaABhAHYAZQAgAGEAbgB5ACAAdABlAHMAdAAgAGYAdQBuAGMAdABpAG8AbgBzACAAZABlAGYAaQBuAGUAZAAhAA==')))
}

#Get all Test. functions. This will get every function in global scope, even the ones that we didn't explicitly load
$TestFunctions = gi function:Test.*

function ___/==\__/\__/=\/\([System.Management.Automation.FunctionInfo] $Test)
{
  Try
  {
    Write-Debug "Execute-Test: Executing: $($Test.Name)"
    & $Test
  }
  Catch
  {
    Write-Debug "Execute-Test: Caught exception: $($_.Exception.GetType().FullName)"
    Throw $_ 
  }
}

function __/\_/==\/===\/===([System.Management.Automation.FunctionInfo] $Test, [string] $Result, [System.Management.Automation.ErrorRecord] $Reason)
{
    #Creating test results object collection
    $TestResult = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBNAGEAbgBhAGcAZQBtAGUAbgB0AC4AQQB1AHQAbwBtAGEAdABpAG8AbgAuAFAAUwBPAGIAagBlAGMAdAA=')))
    $TestResult = Add-Member -passthru -InputObject $TestResult -MemberType NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHMAdAA='))) -Value $Test
    $TestResult = Add-Member -passthru -InputObject $TestResult -MemberType NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdQBsAHQA'))) -Value $Result
    $TestResult = Add-Member -passthru -InputObject $TestResult -MemberType NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGEAcwBvAG4A'))) -Value $Reason
    $null = $TestResults.Add($TestResult);
  
    #Writing Console output
    if($Test.Name.Length -ge 99)
    {
        $TestNameString = $Test.Name.Substring(0, 95) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
    }
    else
    {
        $TestNameString = $Test.Name
    }
    
    switch ($Result)
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFMAUwA='))) 
        {
            Write-Host "$($TestNameString.PadRight(100, ' '))" -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAHUAZQA='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA=='))) -nonewline
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFMAUwA='))) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAGEAYwBrAA=='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAGUAZQBuAA=='))) -nonewline
            Write-Host $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAE4ALwBBAA=='))).PadRight(100, ' ')) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAHUAZQA='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA==')))
        }
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATAA=')))
        {
            if($Reason.ToString().Length -ge 99)
            {
                $ReasonString = $Reason.ToString().Substring(0, 95) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
            }
            else
            {
                $ReasonString = $Reason.ToString()
            }
            Write-Host "$($TestNameString.PadRight(100, ' '))" -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAHUAZQA='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA=='))) -nonewline
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATAA='))) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA=='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGQA'))) -nonewline
            Write-Host $($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACQAUgBlAGEAcwBvAG4AUwB0AHIAaQBuAGcA'))).PadRight(100, ' ')) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGQA'))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA==')))
        }
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBLAEkAUAA=')))
        {
            Write-Host "$($TestNameString.PadRight(100, ' '))" -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAHUAZQA='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA=='))) -nonewline
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBLAEkAUAA='))) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAGEAYwBrAA=='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQBlAGwAbABvAHcA'))) -nonewline
            Write-Host $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAE4ALwBBAA=='))).PadRight(100, ' ')) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBsAHUAZQA='))) -backgroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBoAGkAdABlAA==')))
        }
    }
}

function ____/\__/\___/\_/\([System.Management.Automation.FunctionInfo] $Test)
{    
    $ExpectedExceptionTypeName = "ExpectedException Parameter is not defined in function $($Test.Name)"
    $ExpectedExceptionParameter = $Test.Parameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAZQBjAHQAZQBkAEUAeABjAGUAcAB0AGkAbwBuAA==')))]
    if( $ExpectedExceptionParameter -ne $Null)
    {
      $ExpectedExceptionTypeName = $ExpectedExceptionParameter.ParameterType.FullName
    }
    else
    {
      Write-Debug "Get-ExpectedExceptionTypeName: $($Test.Name) doesn't use ExpectedException parameter"
    }
    return $ExpectedExceptionTypeName
}

function _/===\/=\/=\___/\/([System.Management.Automation.FunctionInfo] $Test)
{    
    $TestFunctionCategory = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwA')))
    $Test.Parameters.GetEnumerator() | % `
    { 
        if($_.Key -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBDAGEAdABlAGcAbwByAHkAXwAoAD8APABDAEEAVABFAEcATwBSAFkAPgAuACoAKQAkAA==')))) 
        {   
            $TestFunctionCategory = $Matches[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFQARQBHAE8AUgBZAA==')))]
        }
    }
    Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBUAGUAcwB0AEYAdQBuAGMAdABpAG8AbgBDAGEAdABlAGcAbwByAHkAOgAgAEYAbwB1AG4AZAAgAEMAYQB0AGUAZwBvAHIAeQA9ACIAJABUAGUAcwB0AEYAdQBuAGMAdABpAG8AbgBDAGEAdABlAGcAbwByAHkAIgA=')))
    return $TestFunctionCategory
}

function _/=\/=\/\_/\_/\___([System.Management.Automation.FunctionInfo] $Test)
{    
    $IsSkipSet = $false
    $SkipParameter = $Test.Parameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBrAGkAcAA=')))]
    if( $SkipParameter -ne $Null)
    {
      $IsSkipSet = $true
      Write-Debug "Get-TestFunctionSkip: $($Test.Name) uses Skip parameter"

    }
    else
    {
      Write-Debug "Get-TestFunctionSkip: $($Test.Name) doesn't use Skip parameter"
    }
    return $IsSkipSet
}

if ($TestFunctions -eq $Null)
{
    Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgB1AG4AYwB0AGkAbwBuACAAdABoAGEAdAAgAHMAdABhAHIAdABzACAAdwBpAHQAaAAgAHQAZQBzAHQALgAqACAAdwBhAHMAIABmAG8AdQBuAGQAIABpAG4AIABmAHUAbgBjAHQAaQBvAG4AOgAgAGQAcgBpAHYAZQAuACAATQBhAGsAZQAgAHMAdQByAGUAIAB0AGgAYQB0ACAAJABQAFMAVQBuAGkAdABUAGUAcwB0AEYAaQBsAGUAIABpAHMAIABpAG4AIAB0AGgAZQAgAGMAbwByAHIAZQBjAHQAIABwAGEAdABoAC4A')))
}
else
{
  $TestStartTime = [DateTime]::Now
  
  #Execute each function
  $TestFunctions | % `
  { 
    $CurrentFunction = $_
    $ExpectedExceptionTypeName = ____/\__/\___/\_/\ -Test $CurrentFunction
    $TestFunctionCategory = _/===\/=\/=\___/\/ -Test $CurrentFunction
    $TestFunctionSkip = _/=\/=\/\_/\_/\___ -Test $CurrentFunction
    
    if ($TestFunctionSkip)
    {
        __/\_/==\/===\/=== -Test $CurrentFunction -Result $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBLAEkAUAA=')))
        return
    }
    
    if (($TestFunctionCategory -ne $Category) -and ($Category -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwA')))))
    {
        Write-Debug "PSUnit.Run.ps1: Not running `"$($CurrentFunction.Name)`". Its category is `"$TestFunctionCategory`", but the required category is `"$Category`""
        return
    }

    Try
    {
      $FunctionOutput = ___/==\__/\__/=\/\ $_
      __/\_/==\/===\/=== -Test $CurrentFunction -Result $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFMAUwA=')))
    }
    Catch
    {            
      $ActualExceptionTypeName = $_.Exception.GetType().FullName
      Write-Debug "PSUnit.Run.ps1: Execution of `"$CurrentFunction`" caused following Exception `"$($_.Exception.GetType().FullName)`""
      Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQALgBSAHUAbgAuAHAAcwAxADoAIABFAHgAcABlAGMAdABlAGQARQB4AGMAZQBwAHQAaQBvAG4AIAA9ACAAIgAkAEUAeABwAGUAYwB0AGUAZABFAHgAYwBlAHAAdABpAG8AbgBUAHkAcABlAE4AYQBtAGUAIgA=')))
      
      if ($ActualExceptionTypeName -eq $ExpectedExceptionTypeName)
      {
        __/\_/==\/===\/=== -Test $CurrentFunction -Result $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFMAUwA=')))
      }
      else
      {
        __/\_/==\/===\/=== -Test $CurrentFunction -Result $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATAA='))) -Reason $_
      }
    }
  }
  $TestEndTime = [DateTime]::Now
}


function ___/=\/=\_/\/\/=\/([System.Collections.ArrayList] $Results)
{
    $Stats = @{}
    $Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHQAYQBsAA==')))] =0
    $Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHMAcwBlAGQA')))] = 0
    $Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQA')))] = 0
    $Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBrAGkAcABwAGUAZAA=')))] = 0
    
    if(!$Results -or $Results.Count -eq 0)
    {
        return $Stats
    }
    
    $Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHQAYQBsAA==')))] = $Results.Count
    
    $Results | Foreach-Object `
    {
        switch ( $_.Result )
        {
            $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABBAFMAUwA='))) {$Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHMAcwBlAGQA')))]++} 
            $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATAA='))) {$Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQA')))]++}
            $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBLAEkAUAA='))) {$Stats[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBrAGkAcABwAGUAZAA=')))]++}
        }
    }
    return $Stats
}

function _/=\______/=\/====([System.Collections.HashTable] $EnvironmentData, [System.Collections.HashTable] $Stats )
{
    $StatsTotal = 0
    $StatsPassed = 0
    $StatsFailed = 0
    $StatsSkipped = 0
    If($Stats.Total) {$StatsTotal = $Stats.Total}
    If($Stats.Passed) {$StatsPassed = $Stats.Passed}
    If($Stats.Failed) {$StatsFailed = $Stats.Failed}
    If($Stats.Skipped) {$StatsSkipped = $Stats.Skipped}

    $StatsFileNamePart = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB7ADAAfQBQAHsAMQB9AEYAewAyAH0AUwB7ADMAfQA='))) -f $StatsTotal, $StatsPassed, $StatsFailed, $StatsSkipped
    
    $StartDateString = $EnvironmentData.StartTime.ToString($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQB5AHkAeQAtAE0ATQAtAGQAZAAtAEgASAAtAG0AbQAtAHMAcwA='))))
    $TestFile = dir $($EnvironmentData.TestFilename)
    $FileName = $TestFile.Name
    $TestReportFileName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQAVABlAHMAdABSAGUAcABvAHIAdABfAHsAMAB9AF8AewAxAH0AXwB7ADIAfQAuAGgAdABtAGwA'))) -f $FileName, $StartDateString, $StatsFileNamePart
    Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBUAGUAcwB0AFIAZQBwAG8AcgB0AEYAaQBsAGUATgBhAG0AZQA6ACAAJABUAGUAcwB0AFIAZQBwAG8AcgB0AEYAaQBsAGUATgBhAG0AZQAgAD0AIAAkAFQAZQBzAHQAUgBlAHAAbwByAHQARgBpAGwAZQBOAGEAbQBlAA==')))

    return $TestReportFileName
}

function __/==\_/==\/=====\([System.Collections.HashTable] $EnvironmentData)
{
    $TestReportTitle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUAbgBpAHQAIABUAGUAcwB0ACAAUgBlAHAAbwByAHQAIAAtACAAewAwAH0AIAAtACAAewAxAH0A'))) -f $EnvironmentData.TestFilename, $EnvironmentData.StartTime
    $TestReportTitle = Encode-Html -StringToEncode $TestReportTitle
    return $TestReportTitle
}

function ___/\_______/=\/=\()
{
    $TestFile = dir $PSUnitTestFile
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHMAdABGAGkAbABlAE4AYQBtAGUA')))] = $TestFile.FullName
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHUAcgBjAGUAQwBvAGQAZQBSAGUAdgBpAHMAaQBvAG4A')))] = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAIAB5AGUAdAAgAGkAbQBwAGwAZQBtAGUAdABlAGQAIQA=')))
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBhAHQAZQBnAG8AcgB5AA==')))] = $Category
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AFQAaQBtAGUA')))] = $TestEndTime
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGQAVABpAG0AZQA=')))] = $TestEndTime
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAB1AHIAYQB0AGkAbwBuAA==')))] = ($TestEnvironment.EndTime - $TestEnvironment.StartTime).TotalSeconds
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBOAGEAbQBlAA==')))] = $env:username
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGMAaABpAG4AZQBOAGEAbQBlAA==')))] = $env:computername
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAHcAZQByAFMAaABlAGwAbABWAGUAcgBzAGkAbwBuAA==')))] = $host.version.ToString()
    $OSProperties = get-wmiobject -class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AMwAyAF8ATwBwAGUAcgBhAHQAaQBuAGcAUwB5AHMAdABlAG0A'))) -namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAFwAQwBJAE0AVgAyAA=='))) -computername $env:computername
    $OperatingSystem = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AIAB7ADEAfQAgAEIAdQBpAGwAZAAgAHsAMgB9AA=='))) -f $OSProperties.Caption, $OSProperties.CSDVersion, $OSProperties.BuildNumber
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAcgBhAHQAaQBuAGcAUwB5AHMAdABlAG0A')))] = $OperatingSystem 
    
    
    
    $Statistics = ___/=\/=\_/\/\/=\/ -Results $TestResults
    
    $TestReportFileName = _/=\______/=\/==== -EnvironmentData $TestEnvironment -Stats $Statistics
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHMAdABSAGUAcABvAHIAdABGAGkAbABlAE4AYQBtAGUA')))] = $TestReportFileName
    
    $TestReportTitle = __/==\_/==\/=====\ -EnvironmentData $TestEnvironment
    $TestEnvironment[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHMAdABSAGUAcABvAHIAdABUAGkAdABsAGUA')))] = $TestReportTitle
    
    $ReportHtml = Render-TestResultReport -Results $TestResults -HeaderData $TestEnvironment -Statistics $Statistics
            
    #Get PSUNIT_HOME folder
    $PSUnitHome = dir env:PSUNIT_HOME
    Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFUATgBJAFQAXwBIAE8ATQBFADoAIAAkAFAAUwBVAG4AaQB0AEgAbwBtAGUA')))
    
    $TestReportFile = Join-Path -Path $($PSUnitHome.Value) -ChildPath $TestReportFileName
    
    #Save report as file in PSUnit Home folder
    $ReportHtml > $TestReportFile
    
    if ($ShowReportInBrowser)
    {#Open Report File
        & ($TestReportFile)
    }
}

___/\_______/=\/=\

