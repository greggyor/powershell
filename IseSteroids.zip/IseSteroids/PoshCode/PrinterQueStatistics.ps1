﻿










$date = Get-Date -UFormat %Y%m%d


Write-Host "What server do you want to get the eventlog from?"
$hostname = Read-Host

Write-Host "Getting the eventlog from server"$hostname"."
Write-Host "Please wait... (this might take a few minutes)"


$events = gwmi -ComputerName $hostname -query "select * from win32_ntlogevent where logfile='system' and eventcode='10' and sourcename='print'" | Select-Object EventCode, Timegenerated, Message | sort Timegenerated


$printerports = gwmi -computername $hostname Win32_Printer | Select-Object Portname, name


$newest = [System.Management.ManagementDateTimeConverter]::ToDateTime($events[0].TimeGenerated)
Write-Host "Oldest logentry is from:" $newest

Write-Host "How many months back do you want to check?"
$months = Read-Host


if ((Test-Path -path $hostname) -ne $True)
{
	New-Item -type directory -path $hostname
}

$counter = 0
$eventcounter = 0


while ($counter -ne ($printerports.count-1))
{
		
		$quecounter = 0
		
		
		foreach ($line in $events)
			{
				
				$current = ([System.Management.ManagementDateTimeConverter]::ToDateTime($line.TimeGenerated))
				
				if ($current -gt $(Get-Date).AddMonths(-$months) -and $line.message -match $printerports[$counter].name)
				{
					
					$quecounter = $quecounter + 1
					
				}
				else
				{
					
					$eventcounter = $eventcounter + 1
				}
				
			}
		
		Write-Host -ForegroundColor Green $printerports[$counter].name "has been used $($quecounter) times!"
		
		
		add-content -path $hostname\\Statistics_$date.txt -Value "Printerque name: $($printerports[$counter].name)"
		add-content -path $hostname\\Statistics_$date.txt -Value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgB1AG0AYgBlAHIAIABvAGYAIAB0AGkAbQBlAHMAIAB1AHMAZQBkADoAIAAkAHEAdQBlAGMAbwB1AG4AdABlAHIA')))
		Add-content -path $hostname\\Statistics_$date.txt -Value " "
	
	
	$counter = $counter + 1
}
