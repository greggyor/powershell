﻿## Tab-Completion
#################
## Please dot souce this script file.
## In first loading, it may take a several minutes, in order to generate ProgIDs and TypeNames list.
## What this can do is:
##
## [datetime]::n<tab>
## [datetime]::now.d<tab>
## $a = New-Object "Int32[,]" 2,3; $b = "PowerShell","PowerShell"
## $c = [ref]$a; $d = [ref]$b,$c
## $d[0].V<tab>[0][0].Get<tab>
## $d[1].V<tab>[0,0].tos<tab>
## $function:a<tab>
## $env:a<tab>
## [System.Type].a<tab>
## [datetime].Assembly.a<tab>
## ).a<tab> # shows System.Type properties and methods...
## #native command name expansion
## fsu<tab>
## #command option name expansion (for fsutil ipconfig net powershell only)
## fsutil <tab>
## ipconfig <tab>
## net <tab>
## powershell <tab>
## #TypeNames expansion
## [Dec<tab>
## [Microsoft.PowerShell.Com<tab>
## New-Object -TypeName IO.Dir<tab>
## New-Object System.Management.Auto<tab>
## #ProgIDs expansion
## New-Object -Com shel<tab>
## #Enum option expansion
## Set-ExecutionPolicy <tab>
## Set-ExecutionPolicy All<tab>
## Set-ExcusionPolisy -ex <tab>
## Get-TraceSource@Inte<tab>
## iex -Err <tab> -wa Sil<tab>
## #WmiClasses expansion
## Get-WmiObject -class Win32_<tab>
## gwmi __Instance<tab>
## #Encoding expansion
## [Out-File | Export-CSV | Select-String | Export-Clixml] -enc <tab>
## [Add-Content | Get-Content | Set-Content} -Encoding Big<tab>
## #PSProvider name expansion
## [Get-Location | Get-PSDrive | Get-PSProvider | New-PSDrive | Remove-PSDrive] [-PSProvider] <tab>
## Get-PSProvider <tab>
## pwd -psp al<tab>
## #PSDrive name expansion
## [Get-PSDrive | New-PSDrive | Remove-PSDrive] [-Name] <tab>
## Get-PSDrive <tab>
## pwd -psd <tab>
## #PSSnapin name expansion
## [Add-PSSnapin | Get-PSSnapin | Remove-PSSnapin ] [-Name] <tab>
## Get-Command -PSSnapin <tab>
## Remove-PSSnapin <tab>
## Get-PSSnapin M<tab>
## #Eventlog name and expansion
## Get-Eventlog -Log <tab>
## Get-Eventlog w<tab>
## #Eventlog's entrytype expansion
## Get-EventLog -EntryType <tab>
## Get-EventLog -EntryType Er<tab>
## Get-EventLog -Ent <tab>
## #Service name expansion
## [Get-Service | Restart-Service | Resume-Service | Start-Service | Stop-Service | Suspend-Service] [-Name] <tab>
## New-Service -DependsOn <tab>
## New-Service -Dep e<tab>
## Get-Service -n <tab>
## Get-Service <tab>,a<tab>,p<tab>
## gsv <tab>
## #Service display name expansion
## [Get-Service | Restart-Service | Resume-Service | Start-Service | Stop-Service | Suspend-Service] [-DisplayName] <tab>
## Get-Service -Dis <tab>
## gsv -Dis <tab>,w<tab>,b<tab>
## #Cmdlet and Topic name expansion
## Get-Help [-Name] about_<tab>
## Get-Help <tab>
## #Category name expansion
## Get-Help -Category c<tab>,<tab>
## #Command name expansion
## Get-Command [-Name] <tab>
## Get-Command -Name <tab>
## gcm a<tab>,<tab>
## #Scope expansion
## [Clear-Variable | Export-Alias | Get-Alias | Get-PSDrive | Get-Variable | Import-Alias
## New-Alias | New-PSDrive | New-Variable | Remove-Variable | Set-Alias | Set-Variable] -Scope <tab>
## Clear-Variable -Scope G<tab>
## Set-Alias  -s <tab>
## #Process name expansion
## [Get-Process | Stop-Process] [-Name] <tab>
## Stop-Process -Name <tab>
## Stop-Process -N pow<tab>
## Get-Process <tab>
## ps power<tab>
## #Trace sources expansion
## [Trace-Command | Get-TraceSource | Set-TraceSource] [-Name] <tab>,a<tab>,p<tab>
## #Trace -ListenerOption expansion
## [Set-TraceSource | Trace-Command] -ListenerOption <tab>
## Set-TraceSource -Lis <tab>,n<tab>
## #Trace -Option expansion
## [Set-TraceSource | Trace-Command] -Option <tab>
## Set-TraceSource -op <tab>,con<tab>
## #ItemType expansion
## New-Item -Item <tab>
## ni -ItemType d<tab>
## #ErrorAction and WarningAction option expansion
## CMDLET [-ErrorAction | -WarningAction] <tab>
## CMDLET -Error s<tab>
## CMDLET -ea con<tab>
## CMDLET -wa <tab>
## #Continuous expansion with comma when parameter can treat multiple option
## # if there are spaces, occur display bug in the line
## # if strings contains '$' or '-', not work
## Get-Command -CommandType <tab>,<tab><tab>,cm<tab>
## pwd -psp <tab>,f<tab>,va<tab>
## Get-EventLog -EntryType <tab>,i<tab>,s<tab>
## #Enum expansion in method call expression
## # this needs one or more spaces after left parenthesis or comma
## $str = "day   night"
## $str.Split( " ",<space>rem<tab>
## >>> $str.Split( " ", "RemoveEmptyEntries" ) <Enter> ERROR
## $str.Split( " ", "RemoveEmptyEntries" -as<space><tab>
## >>> $str.Split( " ", "RemoveEmptyEntries" -as [System.StringSplitOptions] ) <Enter> Success
## $type = [System.Type]
## $type.GetMembers(<space>Def<tab>
## [IO.Directory]::GetFiles( "C:\\", "*",<space>All<tab>
## # this can do continuous enum expansion with comma and no spaces
## $type.GetMembers( "IgnoreCase<comma>Dec<tab><comma>In<tab>"
## [IO.Directory]::GetAccessControl( "C:\\",<space>au<tab><comma>ac<tab><comma>G<tab>
## #Better '$_.' expansion when cmdlet output objects or method return objects
## ls |group { $_.Cr<tab>.Tost<tab>"y")} | tee -var foo| ? { $_.G<tab>.c<tab> -gt 5 } | % { md $_.N<tab> ; copy $_.G<tab> $_.N<tab>  }
## [IO.DriveInfo]::GetDrives() | ? { $_.A<tab> -gt 1GB }
## $Host.UI.RawUI.GetBufferContents($rect) | % { $str += $_.c<tab> }
## gcm Add-Content |select -exp Par<tab>|select -exp <tab> |
##  select -ExpandProperty Par<tab>| | ? { $_.Par<tab>.N<tab> -eq "string" }
## #when Get-PipeLineObject failed, '$_.' shows methods and properties name of FileInfo and String and Type
## #Property name expansion
## [ Format-List | Format-Custom | Format-Table | Format-Wide | Compare-Object |
##  ConvertTo-Html | Measure-Object | Select-Object | Group-Object | Sort-Object ] [-Property] <tab>
## Select-Object -ExcludeProperty <tab>
## Select-Object -ExpandProperty <tab>
## gcm Get-Acl|select -exp Par<tab>
## ps |group na<tab>
## ls | ft A<tab>,M<tab>,L<tab>
## #Hashtable key expansion in the variable name and '.<tab>'
## Get-Process | Get-Unique | % { $hash += @{$_.ProcessName=$_} }
## $hash.pow<tab>.pro<tab>
### Generate ProgIDs list...
if (${12} -eq $null) {
    ${45} = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBMAFMASQBEAFwAXAA='))))
    [Object[]] ${12} = $null
    foreach ( ${44} in ${45}.GetSubKeyNames() )
    {
        foreach ( ${43} in [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey("CLSID\\${44}\\ProgID") )
        {
            if (${43} -ne $null)
            {
                ${12} += ${43}.GetValue("")
            }
        }
    }
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAFAAcgBvAGcASQBEACAAdwBhAHMAIAB1AHAAZABhAHQAZQBkAC4ALgAuAA=='))) | oh
    ${12} = ${12}|sort -Unique
    sc -Value ${12} -Path $PSHOME\\ProgIDs.txt
    ac -Path $PSHOME\\profile.ps1 -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwAkAF8AUAByAG8AZwBJAEQAIAA9ACAARwBlAHQALQBDAG8AbgB0AGUAbgB0ACAALQBQAGEAdABoACAAQwA6AFwAXABXAEkATgBEAE8AVwBTAFwAXABzAHkAcwB0AGUAbQAzADIAXABcAHcAaQBuAGQAbwB3AHMAcABvAHcAZQByAHMAaABlAGwAbABcAFwAdgAxAC4AMABcAFwAUAByAG8AZwBJAEQAcwAuAHQAeAB0ADsA')))
}
### Generate TypeNames list...
if ( ${10} -eq $null ) {
    [Object[]] ${10} = $null
    foreach ( ${42} in [AppDomain]::CurrentDomain.GetAssemblies() )
    {
        foreach ( ${41} in ${42}.GetTypes() )
        {
            ${10} += ${41}.FullName
        }
    }
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAFQAeQBwAGUATgBhAG0AZQBzACAAdwBhAHMAIAB1AHAAZABhAHQAZQBkAC4ALgAuAA=='))) | oh
    ${10} = ${10} | sort -Unique
    sc -Value ${10} -Path $PSHOME\\TypeNames.txt
    ac -Path $PSHOME\\profile.ps1 -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwAkAF8AVAB5AHAAZQBOAGEAbQBlAHMAIAA9ACAARwBlAHQALQBDAG8AbgB0AGUAbgB0ACAALQBQAGEAdABoACAAJABQAFMASABPAE0ARQBcAFwAVAB5AHAAZQBOAGEAbQBlAHMALgB0AHgAdAA7AA==')))
}
if ( ${11} -eq $null ) {
    [Object[]] ${11} = $null
    foreach ( ${41} in ${10} -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgAqAA=='))) )
    {
        ${11} += ${41}.Substring(7)
    }
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAFQAeQBwAGUATgBhAG0AZQBzAF8AUwB5AHMAdABlAG0AIAB3AGEAcwAgAHUAcABkAGEAdABlAGQALgAuAC4A'))) | oh
    sc -Value ${11} -Path $PSHOME\\TypeNames_System.txt
    ac -Path $PSHOME\\profile.ps1 -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwAkAF8AVAB5AHAAZQBOAGEAbQBlAHMAXwBTAHkAcwB0AGUAbQAgAD0AIABHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAtAFAAYQB0AGgAIAAkAFAAUwBIAE8ATQBFAFwAXABUAHkAcABlAE4AYQBtAGUAcwBfAFMAeQBzAHQAZQBtAC4AdAB4AHQAOwA=')))
}
### Generate WMIClasses list...
if ( ${8} -eq $null ) {
    [Object[]] ${8} = $null
    foreach ( ${40} in gwmi -List )
    {
        ${8} += ${40}.Name
    }
    ${8} = ${8} | sort -Unique
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAFcATQBJAEMAbABhAHMAcwBlAHMAIAB3AGEAcwAgAHUAcABkAGEAdABlAGQALgAuAC4A'))) | oh
    sc -Value ${8} -Path $PSHOME\\WMIClasses.txt
    ac -Path $PSHOME\\profile.ps1 -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwAkAF8AVwBNAEkAQwBsAGEAcwBzAGUAcwAgAD0AIABHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAtAFAAYQB0AGgAIAAkAFAAUwBIAE8ATQBFAFwAXABXAE0ASQBDAGwAYQBzAHMAZQBzAC4AdAB4AHQAOwA=')))
}
${global:9} = $null
# Load Get-PipeLineObject function for $_ and property name expansion.
${39} = gi $MyInvocation.MyCommand.Path
iex (". " + (Join-Path ${39}.DirectoryName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAGkAcABlAEwAaQBuAGUATwBiAGoAZQBjAHQALgBwAHMAMQA=')))))
function TabExpansion {
            # This is the default function to use for tab expansion. It handles simple
            # member expansion on variables, variable name expansion and parameter completion
            # on commands. It doesn't understand strings so strings containing ; | ( or { may
            # cause expansion to fail.
            param($line, $lastWord)
            & {
                # Helper function to write out the matching set of members. It depends
                # on dynamic scoping to get $_base, _$expression and $_pat
                function f1 ($sep='.')
                {
                    # evaluate the expression to get the object to examine...
                    iex ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABfAHYAYQBsAD0A'))) + ${29})
                    if ( ${29} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA=='))) )
                    {
                        ${35} = ${29} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5ACgALgAqACkA'))),'$1'
                        ${29} = '$_' + ${35}
                    }
                    ${23} = [Management.Automation.PSMemberTypes] `
                        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHQAaABvAGQALABDAG8AZABlAE0AZQB0AGgAbwBkACwAUwBjAHIAaQBwAHQATQBlAHQAaABvAGQALABQAGEAcgBhAG0AZQB0AGUAcgBpAHoAZQBkAFAAcgBvAHAAZQByAHQAeQA=')))
                    if ($sep -eq '.')
                    {
                        ${36} = 
                            (
                                [Object[]](gm -InputObject $_val.PSextended ${26}) + 
                                [Object[]](gm -InputObject $_val.PSadapted ${26}) + 
                                [Object[]](gm -InputObject $_val.PSbase ${26})
                            )
                        if ( $_val -is [Hashtable] )
                        {
                            [Microsoft.PowerShell.Commands.MemberDefinition[]]${37} = $null
                            foreach ( ${38} in $_val.Keys )
                            {
                                ${37} += `
                                New-Object Microsoft.PowerShell.Commands.MemberDefinition `
                                [int],${38},$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AcABlAHIAdAB5AA=='))),0
                            }
                            ${36} += [Object[]]${37} | ? { $_.Name -like ${26} }
                        }
                        foreach (${34} in ${36} | sort membertype,name -Unique)
                            {
                                if (${34}.MemberType -band ${23})
                                {
                                    # Return a method...
                                    ${1} + ${29} + $sep + ${34}.name + '('
                                }
                                else {
                                    # Return a property...
                                    ${1} + ${29} + $sep + ${34}.name
                                }
                            }
                        }
                    else
                    {
                    foreach (${34} in gm -Static -InputObject $_val ${26} |
                        sort membertype,name)
                       {
                           if (${34}.MemberType -band ${23})
                           {
                               # Return a method...
                               ${1} + ${29} + $sep + ${34}.name + '('
                           }
                           else {
                               # Return a property...
                               ${1} + ${29} + $sep + ${34}.name
                           }
                        }
                    }
                }
                switch -regex ($lastWord)
                {
                    # Handle property and method expansion at '$_'
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgApACgAXABcACQAXwBcAFwALgApACgAXABcAHcAKgApACQA'))) {
                        ${1} = $matches[1]
                        ${29} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA==')))
                        ${26} = $matches[3] + '*'
                        ${global:7} = $null
                        Get-PipeLineObject
                        if ( ${global:7} -eq $null )
                        {
                            if ( ${global:27} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJAAuACoAXABcACgALgAqACQA'))) )
                            {
                                ${18} = ( iex ${27}.Split("(")[0] ).OverloadDefinitions[0].Split(" ")[0] -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAFsAWwBeAFwAXABbAFwAXABdAF0AKgBcAFwAXQAkAA=='))) -as [type]
                                if ( ${29} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA=='))) )
                                {
                                    ${35} = ${29} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5ACgALgAqACkA'))),'$1'
                                    ${29} = '$_' + ${35}
                                }
                                foreach ( ${34} in ${18}.GetMembers() | sort membertype,name | group name | ? { $_.Name -like ${26} } | % { $_.Group[0] } )
                                {
                                   if (${34}.MemberType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHQAaABvAGQA'))))
                                   {
                                       ${1} + ${29} + '.' + ${34}.name + '('
                                   }
                                   else {
                                       ${1} + ${29} + '.' + ${34}.name
                                   }
                                }
                                break;
                            }
                            elseif ( ${global:27} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAWwAuACoAXABcADoAXABcADoALgAqAFwAXAAoAC4AKgAkAA=='))) )
                            {
                                $tname, $mname = ${27}.Split(":(", $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUARQBtAHAAdAB5AEUAbgB0AHIAaQBlAHMA')))-as [System.StringSplitOptions])[0,1]
                                ${18} = @(iex ($tname + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBHAGUAdABNAGUAbQBiAGUAcgAoACIA'))) + $mname + '")'))[0].ReturnType.FullName -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAFsAWwBeAFwAXABbAFwAXABdAF0AKgBcAFwAXQAkAA=='))) -as [type]
                                if ( ${29} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA=='))) )
                                {
                                    ${35} = ${29} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5ACgALgAqACkA'))),'$1'
                                    ${29} = '$_' + ${35}
                                }
                                foreach ( ${34} in ${18}.GetMembers() | sort membertype,name | group name | ? { $_.Name -like ${26} } | % { $_.Group[0] } )
                                {
                                   if (${34}.MemberType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHQAaABvAGQA'))))
                                   {
                                       ${1} + ${29} + '.' + ${34}.name + '('
                                   }
                                   else {
                                       ${1} + ${29} + '.' + ${34}.name
                                   }
                                }
                                break;
                            }
                            else
                            {
                                ${global:7} =  $global:_mix
                            }
                        }
                        f1
                        break;
                    }
                    # Handle property and method expansion rooted at variables...
                    # e.g. $a.b.<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgApACgAXABcACQAKABcAFwAdwB8AFwAXAAuACkAKwApAFwAXAAuACgAXABcAHcAKgApACQA'))) {
                        ${1} = $matches[1]
                        ${29} = $matches[2]
                        [void] ( iex "${29}.IsDataLanguageOnly" ) # for [ScriptBlock]
                        ${26} = $matches[4] + '*'
                        if ( ${29} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABfAFwAXAAuAA=='))) )
                        {
                            ${29} = ${29} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABfACgALgAqACkA'))),($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA=='))) + '$1')
                        }
                        f1
                        break;
                    }
                    # Handle simple property and method expansion on static members...
                    # e.g. [datetime]::n<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgApACgAXABcAFsAKABcAFwAdwB8AFwAXAAuACkAKwBcAFwAXQApAFwAXAA6AFwAXAA6ACgAXABcAHcAKgApACQA'))) {
                        ${1} = $matches[1]
                        ${29} = $matches[2]
                        ${26} = $matches[4] + '*'
                        f1 '::'
                        break;
                    }
                    # Handle complex property and method expansion on static members
                    # where there are intermediate properties...
                    # e.g. [datetime]::now.d<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgApACgAXABcAFsAKABcAFwAdwB8AFwAXAAuACkAKwBcAFwAXQBcAFwAOgBcAFwAOgAoAFwAXAB3ACsAXABcAC4AKQArACkAKABcAFwAdwAqACkAJAA='))) {
                        ${1} = $matches[1]  # everything before the expression
                        ${29} = $matches[2].TrimEnd('.') # expression less trailing '.'
                        ${26} = $matches[5] + '*'  # the member to look for...
                        f1
                        break;
                    }
                    # Handle variable name expansion...
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgBcAFwAJAApACgAXABcAHcAKwApACQA'))) {
                        ${32} = $matches[1]
                        ${33} = $matches[2]
                        foreach (${30} in ls ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBhAHIAaQBhAGIAbABlADoA'))) + ${33} + '*'))
                        {
                            ${32} + ${30}.name
                        }
                        break;
                    }
                    # Handle env&function drives variable name expansion...
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgBcAFwAJAApACgALgAqAFwAXAA6ACkAKABcAFwAdwArACkAJAA='))) {
                        ${32} = $matches[1]
                        ${31} = $matches[2]
                        ${33} = $matches[3]
                        if (${31} -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBuAHYAOgA='))) -or ${31} -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgB1AG4AYwB0AGkAbwBuADoA'))))
                        {
                            foreach (${30} in ls (${31} + ${33} + '*'))
                            {
                                ${32} + ${31} + ${30}.name
                            }
                        }
                        break;
                    }
                    # Handle array's element property and method expansion
                    # where there are intermediate properties...
                    # e.g. foo[0].n.b<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAC4AKgApACgAXABcACQAKAAoAFwAXAB3ACsAXABcAC4AKQB8ACgAXABcAHcAKwAoAFwAXABbACgAXABcAHcAfAAsACkAKwBcAFwAXQApACsAXABcAC4AKQApACsAKQAoAFwAXAB3ACoAKQAkAA==')))
                    {
                        ${1} = $matches[1]
                        ${29} = $matches[2].TrimEnd('.')
                        ${26} = $Matches[8] + '*'
                        [void] ( iex "${29}.IsDataLanguageOnly" ) # for [ScriptBlock]
                        if ( ${29} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABfAFwAXAAuAA=='))) )
                        {
                            ${29} = ${29} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAJABfACgALgAqACkA'))),($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABnAGwAbwBiAGEAbAA6AF8AZAB1AG0AbQB5AA=='))) + '$1')
                        }
                        f1
                        break;
                    }
                    # Handle property and method expansion rooted at type object...
                    # e.g. [System.Type].a<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAFwAXABbACgAXABcAHcAfABcAFwALgApACsAXABcAF0AKQBcAFwALgAoAFwAXAB3ACoAKQAkAA==')))
                    {
                        if ( $(iex $Matches[1]) -isnot [System.Type] ) { break; }
                        ${29} = $Matches[1]
                        ${26} = $Matches[$matches.Count-1] + '*'
                        f1
                        break;
                    }
                    # Handle complex property and method expansion on type object members
                    # where there are intermediate properties...
                    # e.g. [datetime].Assembly.a<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFwAXABbACgAXABcAHcAfABcAFwALgApACsAXABcAF0AXABcAC4AKABcAFwAdwArAFwAXAAuACkAKwApACgAXABcAHcAKgApACQA'))) {
                        ${29} = $matches[1].TrimEnd('.') # expression less trailing '.'
                        ${26} = $matches[4] + '*'  # the member to look for...
                        if ( $(iex ${29}) -eq $null ) { break; }
                        f1
                        break;
                    }
                    # Handle property and method expansion rooted at close parenthes...
                    # e.g. (123).a<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAC4AKgApAFwAXAApACgAKABcAFwAdwB8AFwAXAAuACkAKgApAFwAXAAuACgAXABcAHcAKgApACQA'))) {
                        ${1} = $Matches[1] + ")"
                        if ( $matches[3] -eq $null) { ${29} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBTAHkAcwB0AGUAbQAuAFQAeQBwAGUAXQA='))) }
                        else { ${29} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBTAHkAcwB0AGUAbQAuAFQAeQBwAGUAXQA='))) + $Matches[2] }
                        ${26} = $matches[4] + '*'
                        iex "${29} | Get-Member ${26} | sort MemberType,Name" |
                        % {
                            if ( $_.MemberType -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBNAGUAdABoAG8AZAAqAA=='))) -or $_.MemberType -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBQAGEAcgBhAG0AZQB0AGUAcgBpAHoAZQBkACoA'))) ) { ${28} = "(" }
                            if ( $Matches[2] -eq "" ) { ${1} + "." + $_.Name + ${28} }
                            else { ${1} + $Matches[2] + "." + $_.Name + ${28} }
                          }
                        break;
                    }
                    # Handle .NET type name expansion ...
                    # e.g. [Microsoft.PowerShell.Com<tab>
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAWwAoACgAXABcAHcAKwBcAFwALgA/ACkAKwApACQA'))) {
                        ${4} = $matches[1] + '*'
                        foreach ( ${27} in ${11} -like ${4} )
                        {
                            '[' + ${27}
                        }
                        foreach ( ${27} in ${10} -like ${4} )
                        {
                            '[' + ${27}
                        }
                        break;
                    }
                    # Do completion on parameters...
                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAtACgAWwBcAFwAdwAwAC0AOQBdACoAKQA='))) {
                        ${26} = $matches[1] + '*'
                        # extract the command name from the string
                        # first split the string into statements and pipeline elements
                        # This doesn't handle strings however.
                        ${6} = [regex]::Split($line, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB8ADsAPQBdAA=='))))[-1]
                        #  Extract the trailing unclosed block e.g. ls | foreach { cp
                        if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHsAKABbAF4AXABcAHsAXABcAH0AXQAqACkAJAA='))))
                        {
                            ${6} = $matches[1]
                        }
                        # Extract the longest unclosed parenthetical expression...
                        if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACgAKABbAF4AKAApAF0AKgApACQA'))))
                        {
                            ${6} = $matches[1]
                        }
                        # take the first space separated token of the remaining string
                        # as the command to look up. Trim any leading or trailing spaces
                        # so you don't get leading empty elements.
                        ${6} = ${6}.Trim().Split()[0]
                        # now get the info object for it...
                        ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6})[0]
                        # loop resolving aliases...
                        while (${6}.CommandType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGkAYQBzAA=='))))
                        {
                            ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6}.Definition)[0]
                        }
                        # expand the parameter sets and emit the matching elements
                        foreach (${25} in ${6}.ParameterSets |
                            select -expand parameters | sort -Unique name)
                        {
                            ${25} = ${25}.name
                            if (${25} -like ${26}) { '-' + ${25} }
                        }
                        break;
                    }
                    # try to find a matching command...
                    default {
                        ${24} =  [regex]::Split($line, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB8ADsAPQBdAA=='))))[-1]
                        if (${24}  -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBbACQAXQAuACoAXABcAHcAKwBcAFwAKAAuACoALQBhAHMAXABcAHMAKgAkAA=='))))
                        {
                            '['+ ${global:15} + ']'
                        }
                        elseif ( ${24} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABbAFsAJABdAC4AKgAoAFwAXAB3ACsAKQApAFwAXAAoACgALgAqACkAJAA='))) )
                        #elseif ( $lastex -match '([[$].*(\\w+))\\(([^)]*)$' )
                        {
                            ${23} = $Matches[1]
                            if ( $Matches[3] -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAAuACoAKQAoACgAIgB8ACcAKQAoAFwAXAB3ACsALAApACsAKABcAFwAdwAqACkAKQAkAA=='))) )
                            {
                                ${16} = $true
                                ${4} =  $Matches[5] + '*'
                                ${1} =  $Matches[2].TrimStart('"') -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAAuACoALAApAFwAXAB3ACsAJAA='))),'$1'
                                ${20} = $Matches[1].Split(",").Length
                            }
                            else
                            {
                                ${16} = $false
                                ${4} = ($Matches[3].Split(',')[-1] -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAFwAcwAqAA=='))),'') + "*"
                                ${20} = $Matches[3].Split(",").Length
                            }
                            if ( (${22} = iex (${23} + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBPAHYAZQByAGwAbwBhAGQARABlAGYAaQBuAGkAdABpAG8AbgBzAA=='))))) -eq $null )
                            {
                                $tname, $mname = ${23}.Split(":", $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUARQBtAHAAdAB5AEUAbgB0AHIAaQBlAHMA'))) -as [System.StringSplitOptions])
                                ${22} = iex ($tname + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBHAGUAdABNAGUAbQBiAGUAcgAoACIA'))) + $mname + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IgApACAAfAAgACUAIAB7ACAAJABfAC4AVABvAFMAdAByAGkAbgBnACgAKQAgAH0A'))))
                            }
                            foreach ( ${21} in ${22} )
                            {
                                [void] (${21} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACgAKAAuACoAKQBcAFwAKQA='))))
                                foreach ( ${19} in [regex]::Split($Matches[1], ', ')[${20}-1] )
                                {
                                    if (${19} -eq $null -or ${19} -eq "")
                                    {
                                        continue;
                                    }
                                    ${18} = ${19}.split()[0]
                                    if ( ${18} -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBgAFsAKgA='))) -or ${18} -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHIAYQBtAHMA'))) -or ${18} -eq "" )
                                    {
                                        continue;
                                    }
                                    ${17}  = @(${10} -like "*${18}*")
                                    foreach ( ${14} in ${17} )
                                    {
                                        if ( ${16} -eq $true -and ( ${14}  -as [System.Type] ).IsEnum )
                                        {
                                            ${13} = [Enum]::GetValues(${14}) -like ${4} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAC4AKgApACQA'))),(${1} + '$1')
                                            ${13} | sort
                                        }
                                        elseif ( ( ${14}  -as [System.Type] ).IsEnum ) 
                                        {
                                            ${global:15} = ${14}
                                            ${13} = [Enum]::GetValues(${14}) -like ${4} -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAC4AKgApACQA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IgAkADEAIgA=')))
                                            ${13} | sort
                                        }
                                    }
                                }
                            }
                            if ( ${13} -ne $null )
                            {
                                break;
                            }
                        }
                        if ( $line[-1] -eq " " )
                        {
                            ${6} = $line.TrimEnd(" ").Split($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAB8ACgAOwA9AHsA'))))[-1]
                            # now get the info object for it...
                            ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6})[0]
                            # loop resolving aliases...
                            while (${6}.CommandType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGkAYQBzAA=='))))
                            {
                                ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6}.Definition)[0]
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBFAHgAZQBjAHUAdABpAG8AbgBQAG8AbABpAGMAeQA='))) -eq ${6}.Name )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAHIAZQBzAHQAcgBpAGMAdABlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB0AGUAUwBpAGcAbgBlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAUwBpAGcAbgBlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdAByAGkAYwB0AGUAZAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA='))) | sort
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGEAYwBlAC0AQwBvAG0AbQBhAG4AZAA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))) -contains ${6}.Name )
                            {
                               Get-TraceSource | % { $_.Name } | sort -Unique
                               break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBPAGIAagBlAGMAdAA='))) -eq ${6}.Name )
                            {
                                 ${11}
                                 ${10}
                                 break;
                            }
                            if ( ${6}.Noun -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBXAE0ASQAqAA=='))) )
                            {
                                ${8}
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAHIAbwBjAGUAcwBzAA=='))) -eq ${6}.Name )
                            {
                                 ps | % { $_.Name } | sort
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMAUwBuAGEAcABpAG4A'))) -contains ${6}.Name )
                            {
                                if ( ${global:9} -ne $null )
                                {
                                    ${global:9}
                                    break;
                                }
                                else
                                {
                                    ${global:9} = $(gsnp -Registered;gsnp)| sort Name -Unique;
                                    ${global:9}
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMARAByAGkAdgBlAA=='))) `
                                 -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) )
                            {
                                gdr | sort
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBFAHYAZQBuAHQAbABvAGcA'))) -eq ${6}.Name )
                            {
                                 Get-EventLog -List | % { ${1} + ($_.Log -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBIAGUAbABwAA=='))) -eq ${6}.Name )
                            {
                                Get-Help -Category all | % { $_.Name } | sort -Unique
                                     break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBTAGUAcgB2AGkAYwBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABhAHIAdAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdQBtAGUALQBTAGUAcgB2AGkAYwBlAA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AC0AUwBlAHIAdgBpAGMAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AHMAcABlAG4AZAAtAFMAZQByAHYAaQBjAGUA'))) `
                                 -contains ${6}.Name )
                            {
                                gsv | sort Name  | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBDAG8AbQBtAGEAbgBkAA=='))) -eq ${6}.Name )
                            {
                                 gcm -CommandType All | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBMAGkAcwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBDAHUAcwB0AG8AbQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBUAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBXAGkAZABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABhAHIAZQAtAE8AYgBqAGUAYwB0AA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdgBlAHIAdABUAG8ALQBIAHQAbQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAGEAcwB1AHIAZQAtAE8AYgBqAGUAYwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBPAGIAagBlAGMAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAG8AdQBwAC0ATwBiAGoAZQBjAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHIAdAAtAE8AYgBqAGUAYwB0AA=='))) `
                                  -contains ${6}.Name )
                            {
                                 Get-PipeLineObject
                                 ${7} | gm -MemberType Properties,ParameterizedProperty | sort membertype | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                        }
                        if ( $line[-1] -eq " " )
                        {
                            # extract the command name from the string
                            # first split the string into statements and pipeline elements
                            # This doesn't handle strings however.
                            ${6} = [regex]::Split($line, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB8ADsAPQBdAA=='))))[-1]
                            #  Extract the trailing unclosed block e.g. ls | foreach { cp
                            if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHsAKABbAF4AXABcAHsAXABcAH0AXQAqACkAJAA='))))
                            {
                                ${6} = $matches[1]
                            }
                            # Extract the longest unclosed parenthetical expression...
                            if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACgAKABbAF4AKAApAF0AKgApACQA'))))
                            {
                                ${6} = $matches[1]
                            }
                            # take the first space separated token of the remaining string
                            # as the command to look up. Trim any leading or trailing spaces
                            # so you don't get leading empty elements.
                            ${6} = ${6}.Trim().Split()[0]
                            # now get the info object for it...
                            ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuAA=='))) ${6})[0]
                            if ( ${6}.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABvAHcAZQByAHMAaABlAGwAbAAuAGUAeABlAA=='))) )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBQAFMAQwBvAG4AcwBvAGwAZQBGAGkAbABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBWAGUAcgBzAGkAbwBuAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBOAG8ATABvAGcAbwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBOAG8ARQB4AGkAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBTAHQAYQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBOAG8AUAByAG8AZgBpAGwAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBOAG8AbgBJAG4AdABlAHIAYQBjAHQAaQB2AGUA'))),
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBJAG4AcAB1AHQARgBvAHIAbQBhAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBPAHUAdABwAHUAdABGAG8AcgBtAGEAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBFAG4AYwBvAGQAZQBkAEMAbwBtAG0AYQBuAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBGAGkAbABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBDAG8AbQBtAGEAbgBkAA=='))) | sort
                                break;
                            }
                            if ( ${6}.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAHUAdABpAGwALgBlAHgAZQA='))) )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBlAGgAYQB2AGkAbwByACAAcQB1AGUAcgB5AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBlAGgAYQB2AGkAbwByACAAcwBlAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABpAHIAdAB5ACAAcQB1AGUAcgB5AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABpAHIAdAB5ACAAcwBlAHQA'))), 
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAGYAaQBuAGQAYgB5AHMAaQBkAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAHEAdQBlAHIAeQBhAGwAbABvAGMAcgBhAG4AZwBlAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAHMAZQB0AHMAaABvAHIAdABuAGEAbQBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAHMAZQB0AHYAYQBsAGkAZABkAGEAdABhAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAHMAZQB0AHoAZQByAG8AZABhAHQAYQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQAgAGMAcgBlAGEAdABlAG4AZQB3AA=='))), 
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAGkAbgBmAG8AIABkAHIAaQB2AGUAcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAGkAbgBmAG8AIABkAHIAaQB2AGUAdAB5AHAAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAGkAbgBmAG8AIAB2AG8AbAB1AG0AZQBpAG4AZgBvAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAGkAbgBmAG8AIABuAHQAZgBzAGkAbgBmAG8A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzAGkAbgBmAG8AIABzAHQAYQB0AGkAcwB0AGkAYwBzAA=='))), 
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aABhAHIAZABsAGkAbgBrACAAYwByAGUAYQB0AGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwBiAGoAZQBjAHQAaQBkACAAcQB1AGUAcgB5AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwBiAGoAZQBjAHQAaQBkACAAcwBlAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwBiAGoAZQBjAHQAaQBkACAAZABlAGwAZQB0AGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwBiAGoAZQBjAHQAaQBkACAAYwByAGUAYQB0AGUA'))),
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAZABpAHMAYQBiAGwAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAdAByAGEAYwBrAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAZQBuAGYAbwByAGMAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAdgBpAG8AbABhAHQAaQBvAG4AcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAbQBvAGQAaQBmAHkA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AG8AdABhACAAcQB1AGUAcgB5AA=='))),
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAHAAYQByAHMAZQBwAG8AaQBuAHQAIABxAHUAZQByAHkA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAHAAYQByAHMAZQBwAG8AaQBuAHQAIABkAGUAbABlAHQAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBwAGEAcgBzAGUAIABzAGUAdABmAGwAYQBnAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBwAGEAcgBzAGUAIABxAHUAZQByAHkAZgBsAGEAZwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBwAGEAcgBzAGUAIABxAHUAZQByAHkAcgBhAG4AZwBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBwAGEAcgBzAGUAIABzAGUAdAByAGEAbgBnAGUA'))),
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAG4AIABjAHIAZQBhAHQAZQBqAG8AdQByAG4AYQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAG4AIABkAGUAbABlAHQAZQBqAG8AdQByAG4AYQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAG4AIABlAG4AdQBtAGQAYQB0AGEA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAG4AIABxAHUAZQByAHkAagBvAHUAcgBuAGEAbAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAG4AIAByAGUAYQBkAGQAYQB0AGEA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBvAGwAdQBtAGUAIABkAGkAcwBtAG8AdQBuAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBvAGwAdQBtAGUAIABkAGkAcwBrAGYAcgBlAGUA'))) | sort
                                break;
                            }
                            if ( ${6}.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBlAHQALgBlAHgAZQA='))) )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBDAEMATwBVAE4AVABTACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABDAE8ATQBQAFUAVABFAFIAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABDAE8ATgBGAEkARwAgAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABDAE8ATgBUAEkATgBVAEUAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABGAEkATABFACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABHAFIATwBVAFAAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABIAEUATABQACAA'))), 
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABFAEwAUABNAFMARwAgAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABMAE8AQwBBAEwARwBSAE8AVQBQACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABOAEEATQBFACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABQAEEAVQBTAEUAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABQAFIASQBOAFQAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABTAEUATgBEACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABTAEUAUwBTAEkATwBOACAA'))), 
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBIAEEAUgBFACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABTAFQAQQBSAFQAIAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABTAFQAQQBUAEkAUwBUAEkAQwBTACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABTAFQATwBQACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABUAEkATQBFACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABVAFMARQAgAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABVAFMARQBSACAA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABWAEkARQBXAA=='))) | sort
                                break;
                            }
                            if ( ${6}.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBwAGMAbwBuAGYAaQBnAC4AZQB4AGUA'))) )
                            {
                                "/?", $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBhAGwAbAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwByAGUAbgBlAHcA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwByAGUAbABlAGEAcwBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBmAGwAdQBzAGgAZABuAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBkAGkAcwBwAGwAYQB5AGQAbgBzAA=='))),
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwByAGUAZwBpAHMAdABlAHIAZABuAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBzAGgAbwB3AGMAbABhAHMAcwBpAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBzAGUAdABjAGwAYQBzAHMAaQBkAA==')))
                                break;
                            }
                        }
                        if ( $line -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHcAKwBcAFwAcwArACgAXABcAHcAKwAoAFwAXAAuAHwAWwBeAFwAXABzAFwAXAAuAF0AKQAqACkAJAA='))) )
                        {
                            #$_opt = $Matches[1] + '*'
                            ${6} = $line.TrimEnd(" ").Split($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAB8ACgAOwA9AHsA'))))[-2]
                            ${4} = $Matches[1].Split(" ,")[-1] + '*'
                            ${1} = $Matches[1].Substring(0,$Matches[1].Length-$Matches[1].Split(" ,")[-1].length)
                            # now get the info object for it...
                            ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6})[0]
                            # loop resolving aliases...
                            while (${6}.CommandType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGkAYQBzAA=='))))
                            {
                                ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6}.Definition)[0]
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBFAHgAZQBjAHUAdABpAG8AbgBQAG8AbABpAGMAeQA='))) -eq ${6}.Name )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAHIAZQBzAHQAcgBpAGMAdABlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB0AGUAUwBpAGcAbgBlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAUwBpAGcAbgBlAGQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdAByAGkAYwB0AGUAZAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA='))) -like ${4} | sort
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGEAYwBlAC0AQwBvAG0AbQBhAG4AZAA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))) -contains ${6}.Name )
                            {
                               Get-TraceSource -Name ${4} | % { $_.Name } | sort -Unique | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                               break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBPAGIAagBlAGMAdAA='))) -eq ${6}.Name )
                            {
                                 ${11} -like ${4}
                                 ${10} -like ${4}
                                 break;
                            }
                            if ( ${6}.Name -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBXAE0ASQAqAA=='))) )
                            {
                                ${8} -like ${4}
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAHIAbwBjAGUAcwBzAA=='))) -eq ${6}.Name )
                            {
                                 ps ${4} | % { $_.Name } | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMAUwBuAGEAcABpAG4A'))) -contains ${6}.Name )
                            {
                                if ( ${global:9} -ne $null )
                                {
                                    ${global:9} -like ${4} | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                    break;
                                }
                                else
                                {
                                    ${global:9} = $(gsnp -Registered;gsnp)| sort Name -Unique;
                                    ${global:9} -like ${4} | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMARAByAGkAdgBlAA=='))) `
                                 -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) )
                            {
                                gdr -Name ${4} | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMAUAByAG8AdgBpAGQAZQByAA=='))) -eq ${6}.Name )
                            {
                                Get-PSProvider -PSProvider ${4} | % { $_.Name } | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBFAHYAZQBuAHQAbABvAGcA'))) -eq ${6}.Name )
                            {
                                 Get-EventLog -List | ? { $_.Log -like ${4} } | % { ${1} + ($_.Log -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBIAGUAbABwAA=='))) -eq ${6}.Name )
                            {
                                Get-Help -Category all -Name ${4} | % { $_.Name } | sort -Unique
                                     break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBTAGUAcgB2AGkAYwBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABhAHIAdAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdQBtAGUALQBTAGUAcgB2AGkAYwBlAA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AC0AUwBlAHIAdgBpAGMAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AHMAcABlAG4AZAAtAFMAZQByAHYAaQBjAGUA'))) `
                                 -contains ${6}.Name )
                            {
                                gsv -Name ${4} | sort Name  | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBDAG8AbQBtAGEAbgBkAA=='))) -eq ${6}.Name )
                            {
                                 gcm -CommandType All -Name ${4} | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBMAGkAcwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBDAHUAcwB0AG8AbQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBUAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBXAGkAZABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABhAHIAZQAtAE8AYgBqAGUAYwB0AA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdgBlAHIAdABUAG8ALQBIAHQAbQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAGEAcwB1AHIAZQAtAE8AYgBqAGUAYwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBPAGIAagBlAGMAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAG8AdQBwAC0ATwBiAGoAZQBjAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHIAdAAtAE8AYgBqAGUAYwB0AA=='))) `
                                  -contains ${6}.Name )
                            {
                                 Get-PipeLineObject
                                 ${7} | gm -Name ${4} -MemberType Properties,ParameterizedProperty | sort membertype | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                        }
                        if ( $line -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAAtACgAXABcAHcAKwApACkAXABcAHMAKwAoAFsAXgAtAF0AKgAkACkA'))) )
                        {
                            ${5} = $matches[2] + '*'
                            ${4} = $Matches[3].Split(" ,")[-1] + '*'
                            ${1} = $Matches[3].Substring(0,$Matches[3].Length-$Matches[3].Split(" ,")[-1].length)
                            #$_opt = ($Matches[3] -replace '(^.*\\s*,?\\s*)\\w*$','$1') + '*'
                            # extract the command name from the string
                            # first split the string into statements and pipeline elements
                            # This doesn't handle strings however.
                            ${6} = [regex]::Split($line, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB8ADsAPQBdAA=='))))[-1]
                            #  Extract the trailing unclosed block e.g. ls | foreach { cp
                            if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHsAKABbAF4AXABcAHsAXABcAH0AXQAqACkAJAA='))))
                            {
                                ${6} = $matches[1]
                            }
                            # Extract the longest unclosed parenthetical expression...
                            if (${6} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACgAKABbAF4AKAApAF0AKgApACQA'))))
                            {
                                ${6} = $matches[1]
                            }
                            # take the first space separated token of the remaining string
                            # as the command to look up. Trim any leading or trailing spaces
                            # so you don't get leading empty elements.
                            ${6} = ${6}.Trim().Split()[0]
                            # now get the info object for it...
                            ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6})[0]
                            # loop resolving aliases...
                            while (${6}.CommandType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGkAYQBzAA=='))))
                            {
                                ${6} = @(gcm -type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBtAGQAbABlAHQALABhAGwAaQBhAHMA'))) ${6}.Definition)[0]
                            }
                            if ( ${5}.TrimEnd("*") -eq "ea" -or ${5}.TrimEnd("*") -eq "wa" )
                            {
                               $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdABpAG4AdQBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHEAdQBpAHIAZQA='))) |
                               ? { $_ -like ${4} } | sort -Unique
                               break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQALQBGAGkAbABlAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAbwByAHQALQBDAFMAVgA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBTAHQAcgBpAG4AZwA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAbwByAHQALQBDAGwAaQB4AG0AbAA='))) -contains ${6}.Name `
                                 -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGMAbwBkAGkAbgBnAA=='))) -like ${5})
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGkAYwBvAGQAZQA='))),  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBUAEYANwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBUAEYAOAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBTAEMASQBJAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBUAEYAMwAyAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBpAGcARQBuAGQAaQBhAG4AVQBuAGkAYwBvAGQAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBFAE0A'))) |
                                ? { $_ -like ${4} } | sort -Unique
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGEAYwBlAC0AQwBvAG0AbQBhAG4AZAA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBUAHIAYQBjAGUAUwBvAHUAcgBjAGUA'))) -contains ${6}.Name `
                                -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5})
                            {
                               Get-TraceSource -Name ${4} | % { $_.Name } | sort -Unique | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                               break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBPAGIAagBlAGMAdAA='))) -like ${6}.Name )
                            {
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0ATwBiAGoAZQBjAHQA'))) -like ${5} )
                                {
                                    ${12} -like ${4}  | % { $_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ' }
                                    break;
                                }
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB5AHAAZQBOAGEAbQBlAA=='))) -like ${5} )
                                {
                                    ${11} -like ${4}
                                    ${10} -like ${4}
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBJAHQAZQBtAA=='))) -eq ${6}.Name )
                            {
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQB0AGUAbQBUAHkAcABlAA=='))) -like ${5} )
                                {
                                    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABpAHIAZQBjAHQAbwByAHkA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBpAGwAZQA='))) -like ${4}
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBMAG8AYwBhAHQAaQBvAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMAUAByAG8AdgBpAGQAZQByAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMARAByAGkAdgBlAA=='))) `
                                 -contains ${6}.Name `
                                 -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFAAcgBvAHYAaQBkAGUAcgA='))) -like ${5} )
                            {
                                Get-PSProvider -PSProvider ${4} | % { $_.Name } | sort  | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBMAG8AYwBhAHQAaQBvAG4A'))) -eq ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAEQAcgBpAHYAZQA='))) -like ${5} )
                            {
                                gdr -Name ${4} | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMARAByAGkAdgBlAA=='))) `
                                 -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                            {
                                gdr -Name ${4} | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBDAG8AbQBtAGEAbgBkAA=='))) -eq ${6}.Name -and  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAFMAbgBhAHAAaQBuAA=='))) -like ${5})
                            {
                                if ( ${global:9} -ne $null )
                                {
                                    ${global:9} -like ${4}  | % { ${1} + $_ }
                                    break;
                                }
                                else
                                {
                                    ${global:9} = $(gsnp -Registered;gsnp)| sort Name -Unique;
                                    ${global:9} -like ${4}  | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMAUwBuAGEAcABpAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBQAFMAUwBuAGEAcABpAG4A'))) `
                                 -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                            {
                                if ( ${global:9} -ne $null )
                                {
                                    ${global:9} -like ${4} | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                    break;
                                }
                                else
                                {
                                    ${global:9} = $(gsnp -Registered;gsnp)| sort Name -Unique;
                                    ${global:9} -like ${4} | % { ${1} + $_ }
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAGUAYQByAC0AVgBhAHIAaQBhAGIAbABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAbwByAHQALQBBAGwAaQBhAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBBAGwAaQBhAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBWAGEAcgBpAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQALQBBAGwAaQBhAHMA'))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABOAGUAdwAtAEEAbABpAGEAcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBQAFMARAByAGkAdgBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBWAGEAcgBpAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUALQBWAGEAcgBpAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBBAGwAaQBhAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQALQBWAGEAcgBpAGEAYgBsAGUA'))) `
                                 -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlAA=='))) -like ${5} )
                            {
                                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBsAG8AYgBhAGwA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGMAYQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQA'))) -like ${4}
                                break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBQAHIAbwBjAGUAcwBzAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAAtAFAAcgBvAGMAZQBzAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdAAtAFAAcgBvAGMAZQBzAHMA'))) -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                            {
                                 ps ${4} | % { $_.Name } | sort | % { ${1} + ($_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBFAHYAZQBuAHQAbABvAGcA'))) -eq ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcATgBhAG0AZQA='))) -like ${5} )
                            {
                                 Get-EventLog -List | ? { $_.Log -like ${4} } | % { ${1} + ($_.Log -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBIAGUAbABwAA=='))) -eq ${6}.Name )
                            {
                                 if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                                 {
                                     Get-Help -Category all -Name ${4} | % { $_.Name } | sort -Unique
                                     break;
                                 }
                                 if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBhAHQAZQBnAG8AcgB5AA=='))) -like ${5} )
                                 {
                                     $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGkAYQBzAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBtAGQAbABlAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AdgBpAGQAZQByAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAG4AZQByAGEAbAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAFEA'))),
                                     $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBsAG8AcwBzAGEAcgB5AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABlAGwAcABGAGkAbABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwA'))) -like ${4} | sort | % { ${1} + $_ }
                                     break;
                                 }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBTAGUAcgB2AGkAYwBlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABhAHIAdAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdQBtAGUALQBTAGUAcgB2AGkAYwBlAA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AC0AUwBlAHIAdgBpAGMAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAAtAFMAZQByAHYAaQBjAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AHMAcABlAG4AZAAtAFMAZQByAHYAaQBjAGUA'))) `
                                 -contains ${6}.Name )
                            {
                                 if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                                 {
                                     gsv -Name ${4} | sort Name  | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                     break;
                                 }
                                 if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAcABsAGEAeQBOAGEAbQBlAA=='))) -like ${5} )
                                 {
                                     gsv -Name ${4} | sort DisplayName | % { ${1} + ($_.DisplayName -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                     break;
                                 }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcALQBTAGUAcgB2AGkAYwBlAA=='))) -eq ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAHAAZQBuAGQAcwBPAG4A'))) -like ${5} )
                            {
                                 gsv -Name ${4} | sort Name | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBFAHYAZQBuAHQATABvAGcA'))) -eq ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAcgB5AFQAeQBwAGUA'))) -like ${5} )
                            {
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwByAG0AYQB0AGkAbwBuAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbAB1AHIAZQBBAHUAZABpAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGMAYwBlAHMAcwBBAHUAZABpAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwA='))) -like ${4} | sort | % { ${1} + $_ }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBDAG8AbQBtAGEAbgBkAA=='))) -eq ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA='))) -like ${5} )
                            {
                                 gcm -CommandType All -Name ${4} | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( ${6}.Noun -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBXAE0ASQAqAA=='))) )
                            {
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAGEAcwBzAA=='))) -like ${5} )
                                {
                                    ${8} -like ${4}
                                    break;
                                }
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBMAGkAcwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBDAHUAcwB0AG8AbQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBUAGEAYgBsAGUA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAbQBhAHQALQBXAGkAZABlAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABhAHIAZQAtAE8AYgBqAGUAYwB0AA=='))),
                                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdgBlAHIAdABUAG8ALQBIAHQAbQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAGEAcwB1AHIAZQAtAE8AYgBqAGUAYwB0AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBPAGIAagBlAGMAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAG8AdQBwAC0ATwBiAGoAZQBjAHQA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHIAdAAtAE8AYgBqAGUAYwB0AA=='))) `
                                  -contains ${6}.Name -and $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AcABlAHIAdAB5AA=='))) -like ${5} )
                            {
                                 Get-PipeLineObject
                                 ${7} | gm -Name ${4} -MemberType Properties,ParameterizedProperty | sort membertype | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                            }
                            if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQALQBPAGIAagBlAGMAdAA='))) -eq ${6}.Name )
                            {
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAbAB1AGQAZQBQAHIAbwBwAGUAcgB0AHkA'))) -like ${5} )
                                {
                                 Get-PipeLineObject
                                 ${7} | gm -Name ${4} -MemberType Properties,ParameterizedProperty | sort membertype | % { ${1} + ($_.Name -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))),'` ') }
                                 break;
                                }
                                if ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAYQBuAGQAUAByAG8AcABlAHIAdAB5AA=='))) -like ${5} )
                                {
                                 Get-PipeLineObject
                                 ${7} | gm -Name ${4} -MemberType Properties,ParameterizedProperty | sort membertype | % { $_.Name }
                                 break;
                                }
                            }
                            select -InputObject ${6} -ExpandProperty ParameterSets | select -ExpandProperty Parameters |
                            ? { $_.Name -like ${5} } | ? { $_.ParameterType.IsEnum } |
                            % { [Enum]::GetNames($_.ParameterType) } | ? { $_ -like ${4} } | sort -Unique | % { ${1} + $_ }
                        }
                               if ( $line[-1] -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMA'))) ) { break; }
                               if ( $lastWord -ne $null -and $lastWord.IndexOfAny($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBcAFwA')))) -eq -1 ) {
                                  ${3} = $lastWord.Substring( ($lastWord -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABbAF4AXABcAHwAXABcACgAOwA9AHsAXQAqACkAJAA=')))).Length )
                                  ${1} = $lastWord.Substring( 0, ($lastWord -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABbAF4AXABcAHwAXABcACgAOwA9AHsAXQAqACkAJAA=')))).Length )
                                  ${2} = ${3} + "*"
                                  gcm -Name ${2} -CommandType All | % { ${1} + $_.Name } | sort -Unique
                               }
                    }
                }
            }
}
