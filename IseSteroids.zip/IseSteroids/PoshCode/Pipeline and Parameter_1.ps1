﻿param(
    [Parameter(ValueFromPipeline=$true, Mandatory=$true, Position=0)]
    [string[]]
    $ComputerName
)
Process {
    foreach (${__/\__/\/===\_/==} in $ComputerName) {
        Write-Host "Processing ${__/\__/\/===\_/==}"
    }
}
