﻿param
(
    [Parameter(Mandatory = $true)]
    [ScriptBlock] $Scriptblock,
    [Parameter(ValueFromPipeline = $true)]
    $InputObject,
    [switch] $EnableProfile
)
begin
{
    Set-StrictMode -Version Latest
    ${9} = New-Object System.Collections.ArrayList
}
process
{
    $null = ${9}.Add($inputObject)
}
end
{
    ${3} = [IO.Path]::GetTempFileName()	
    ${2} = [IO.Path]::GetTempFileName()
	${1} = [IO.Path]::GetTempFileName()
    ${9}.ToArray() | Export-CliXml -Depth 1 ${2}
    ${5} = ""
    if(-not $EnableProfile) { ${5} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBOAG8AUAByAG8AZgBpAGwAZQAgAA=='))) }
    ${8} = "Set-Location '$($pwd.Path)'; " +
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABvAHUAdABwAHUAdAAgAD0AIABJAG0AcABvAHIAdAAtAEMAbABpAFgAbQBsACAAJwAkAHsAMgB9ACcAIAB8ACAA'))) +
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgAgAHsA'))) + $scriptblock.ToString() + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fQAgADIAPgAmADEAIAA7ACAA'))) +
@@		$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQALQBGAGkAbABlACAALQBmAGkAbABlAHAAYQB0AGgAIAAkAGUAcgByAG8AcgBGAGkAbABlACAALQBpAG4AcAB1AHQAbwBiAGoAZQBjAHQAIAAkAGUAcgByAG8AcgA7AA=='))) +
		$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAbwByAHQALQBDAGwAaQBYAG0AbAAgAC0ARABlAHAAdABoACAAMQAgAC0ASQBuACAAJABvAHUAdABwAHUAdAAgACcAJAB7ADMAfQAnADsA')))
    ${7} = [System.Text.Encoding]::Unicode.GetBytes(${8})
    ${6} = [Convert]::ToBase64String(${7})
    ${5} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBFAG4AYwBvAGQAZQBkAEMAbwBtAG0AYQBuAGQAIAAkAHsANgB9AA==')))
    ${4} = Start-Process -FilePath (Get-Command powershell).Definition `
        -ArgumentList ${5} -Verb RunAs `
        -Passthru `
        -WindowStyle Hidden
    ${4}.WaitForExit()
@@	if(${4}.ExitCode -eq 0)
	{
		if((Get-Item ${3}).Length -gt 0)
		{
			Import-CliXml ${3}
		}
	}
	else
	{
@@		Write-Error -Message $(gc ${1} | Out-String)
	}
    Remove-Item ${3}
    Remove-Item ${2}
@@    Remove-Item ${1}
}
