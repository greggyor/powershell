﻿function Rotate-Right {


    [CmdletBinding(DefaultParameterSetName = '32bit')] Param (
        
        [Parameter(Mandatory = $True, Position = 0, ParameterSetName = '32bit')] [UInt32] $Value32,
        
        [Parameter(Mandatory = $True, Position = 0, ParameterSetName = '64bit')] [UInt64] $Value64,
        
        [Parameter(Mandatory = $True, Position = 1)] [Int32] $Offset
    )
    
    ${2} = 'NonPublic, Static'
    
    switch ($PsCmdlet.ParameterSetName) {
        '32bit' {
            ${1} = [System.Security.Cryptography.SHA256Managed].GetMethod('RotateRight', ${2}, $null, @([UInt32], [Int32]), $null)
            ${1}.Invoke($null, @($Value32, $Offset))
        }
        '64bit' {
            ${1} = [System.Security.Cryptography.SHA512Managed].GetMethod('RotateRight', ${2}, $null, @([UInt64], [Int32]), $null)
            ${1}.Invoke($null, @($Value64, $Offset))
        }
    }
}
