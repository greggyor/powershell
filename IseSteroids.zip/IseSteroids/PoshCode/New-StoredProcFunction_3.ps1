﻿# New-StoredProcFunction.ps1
# Steven Murawski
# http://blog.usepowershell.com
# 04/08/2009
# Replaced the parsing of the stored procedure text and use Information_Schema.Parameters to get the parameter information
# Thanks to Chad Miller for the idea.
 
# Example: ./New-StoredProcFunction.ps1 'Data Source=MySqlServer;Database=Northwind;User=AnythingButSa;Password=abc123' sp_createnewcustomer
# Example 'sp_createnewcustomer | ./New-StoredProcFunction.ps1 'Data Source=MySqlServer;Database=Northwind;User=AnythingButSa;Password=abc123'
 
param($ConnectionString, [String[]]$StoredProc= $null)
BEGIN
{
	if ($StoredProc.count -gt 0)
	{
		$StoredProc | ./New-StoredProcFunction $ConnectionString
	}
	function f2()
	{
		param ($ConnectionString, $Query)
		${15} = New-Object System.Data.SqlClient.SqlConnection $connectionString
		${17} = New-Object System.Data.SqlClient.SqlCommand $query,${15}
		${15}.Open()
		${16} = New-Object System.Data.SqlClient.SqlDataAdapter ${17}
		${14} = New-Object System.Data.DataSet
		[void] ${16}.Fill(${14})
		${15}.Close()
		${14}.Tables | ForEach-Object {$_.Rows} 
	}
	
	function f1()
	{
		param($FunctionName, $ConnectionString)
		$query = @"
SELECT parameter_Name, data_type, character_maximum_length, parameter_mode
FROM INFORMATION_SCHEMA.Parameters
WHERE specific_NAME LIKE '$FunctionName'
"@
		${13} = f2 $ConnectionString $Query 

		foreach (${12} in ${13})
		{
			${11} = "" | Select-Object Name, DataType, Length, IsOutput
			${11}.Name = ${12}.parameter_Name
			${11}.DataType = ${12}.data_type
			${11}.Length = ${12}.character_maximum_length
			${11}.IsOutput = if (${12}.parameter_mode -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBOAE8AVQBUAA==')))){$true} else {$false}
			${11}
		}
	}
}
PROCESS
{
	if ($_ -ne $null)
	{
		$FunctionName = $_
		${6} = f1 $FunctionName $ConnectionString
		
		[String[]]${10} = ${6} | where {-not $_.IsOutput} | ForEach-Object {$_.Name -replace '@' }
		[String[]]${3} = ${6} | Where-Object {$_.IsOutput} | ForEach-Object {$_.Name -replace '@'}
		
		${1} = ' '
		
		if (${10}.count -gt 0)
		{
			${9} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LAAgACQA')))
			${1} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABhAHIAYQBtACAAKAAkAHsAMAB9ACkA'))) -f ${10}
			${1} += "`n" 
			${9} = ', '
		}
		
		${8} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbgBuAGUAYwB0AGkAbwBuACAAPQAgAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAEQAYQB0AGEALgBTAHEAbABDAGwAaQBlAG4AdAAuAFMAcQBsAEMAbwBuAG4AZQBjAHQAaQBvAG4AKAAnAHsAMAB9ACcAKQANAAoAJABjAG8AbQBtAGEAbgBkACAAPQAgAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAEQAYQB0AGEALgBTAHEAbABDAGwAaQBlAG4AdAAuAFMAcQBsAEMAbwBtAG0AYQBuAGQAKAAnAHsAMQB9ACcALAAgACQAYwBvAG4AbgBlAGMAdABpAG8AbgApAA0ACgAkAGMAbwBtAG0AYQBuAGQALgBDAG8AbQBtAGEAbgBkAFQAeQBwAGUAIAA9ACAAWwBTAHkAcwB0AGUAbQAuAEQAYQB0AGEALgBDAG8AbQBtAGEAbgBkAFQAeQBwAGUAXQA6ADoAUwB0AG8AcgBlAGQAUAByAG8AYwBlAGQAdQByAGUADQAKAA==')))
		${1} += ${8} -f $ConnectionString, $FunctionName
		if ( (${6} -ne $null) -or (${6}.count -gt 1) )
		{
			
			if (${3}.count -gt 0)
			{
				${2} = "" 
				${7} = "" | select ${3}
			}
			#Add the parameters	
			foreach (${4} in ${6})
			{
				if (${4}.length -isnot [DBNull])
				{
					${5} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbQBtAGEAbgBkAC4AUABhAHIAYQBtAGUAdABlAHIAcwAuAEEAZABkACgAIgB7ADAAfQAiACwAIAAiAHsAMQB9ACIALAAgAHsAMgB9ACkAIAAgAHwAIABvAHUAdAAtAG4AdQBsAGwAIAA='))) 
					${1} += "`n" 
					${1} += ${5} -f ${4}.name, ${4}.datatype, ${4}.length
				}
				else
				{
					${5} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbQBtAGEAbgBkAC4AUABhAHIAYQBtAGUAdABlAHIAcwAuAEEAZABkACgAIgB7ADAAfQAiACwAIAAiAHsAMQB9ACIAKQAgACAAfAAgAG8AdQB0AC0AbgB1AGwAbAAgAA==')))
					${1} += "`n" 
					${1} += ${5} -f ${4}.name, ${4}.datatype
				}
				
				if (${4}.IsOutput)
				{
					${1} += "`n" 
					${1} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbQBtAGEAbgBkAC4AUABhAHIAYQBtAGUAdABlAHIAcwBbACIAewAwAH0AIgBdAC4ARABpAHIAZQBjAHQAaQBvAG4AIAA9ACAAWwBTAHkAcwB0AGUAbQAuAEQAYQB0AGEALgBQAGEAcgBhAG0AZQB0AGUAcgBEAGkAcgBlAGMAdABpAG8AbgBdADoAOgBPAHUAdABwAHUAdAAgAA=='))) -f ${4}.Name
					${2} += "`n"
					${2} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABDAG8AbQBtAGEAbgBkAE8AdQB0AHAAdQB0AC4AewAxAH0AIAA9ACAAJABjAG8AbQBtAGEAbgBkAC4AUABhAHIAYQBtAGUAdABlAHIAcwBbACIAewAwAH0AIgBdAC4AVgBhAGwAdQBlAA=='))) -f ${4}.name, (${4}.name -replace '@')
				}
				else
				{
					${1} += "`n" 
					${1} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbQBtAGEAbgBkAC4AUABhAHIAYQBtAGUAdABlAHIAcwBbACIAewAwAH0AIgBdAC4AVgBhAGwAdQBlACAAPQAgACQAewAxAH0AIAA='))) -f ${4}.name, (${4}.name -replace '@')
				}
			}				
		}
		
		${1} += "`n"
		${1} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbgBuAGUAYwB0AGkAbwBuAC4ATwBwAGUAbgAoACkAIAAgAHwAIABvAHUAdAAtAG4AdQBsAGwADQAKACQAYwBvAG0AbQBhAG4AZAAuAEUAeABlAGMAdQB0AGUATgBvAG4AUQB1AGUAcgB5ACgAKQAgAHwAIABvAHUAdAAtAG4AdQBsAGwADQAKAA==')))	
		if (${3}.count -gt 0)
		{
			${1} += ${2}
		}
		
		${1} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAA0ACgAkAGMAbwBuAG4AZQBjAHQAaQBvAG4ALgBDAGwAbwBzAGUAKAApACAAfAAgAG8AdQB0AC0AbgB1AGwAbAANAAoAcgBlAHQAdQByAG4AIAAkAEMAbwBtAG0AYQBuAGQATwB1AHQAcAB1AHQAIAA=')))
		
		#$ScriptText
		Set-Item -Path function:global:$FunctionName -Value ${1}
	}
}
