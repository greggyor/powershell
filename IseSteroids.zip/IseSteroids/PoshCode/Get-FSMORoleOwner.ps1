﻿Function Get-FSMORoleOwner {

[cmdletbinding()] 
Try {
    ${4} = [system.directoryservices.activedirectory.Forest]::GetCurrentForest() 
    ForEach (${3} in ${4}.domains) {
        ${2} = @{
            Forest = ${4}.name
            Domain = ${3}.name
            SchemaMaster = ${4}.SchemaRoleOwner
            DomainNamingMaster = ${4}.NamingRoleOwner
            RIDOwner = ${3}.RidRoleOwner
            PDCOwner = ${3}.PdcRoleOwner
            InfrastructureOwner = ${3}.InfrastructureRoleOwner
            }
        ${1} = New-Object PSObject -Property ${2}
        ${1}.PSTypeNames.Insert(0,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQAUgBvAGwAZQBzAA=='))))
        ${1}
        }
    }
Catch {
    Write-Warning "$($Error)"
    }
}
