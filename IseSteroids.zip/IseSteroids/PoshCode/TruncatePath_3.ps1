﻿
$maxPathLength = 40
$showFullPath = $false
Function Prompt
{
    $currentPath = (gl).Path
    if ( ($currentPath.Length -gt $maxPathLength) -and ($showFullPath -ne $true) `
      -and (($currentPath.Split("\\")).Count -gt 3) )
    {
        $currentPathSplit = $currentPath.Split("\\")
        $truncatedPath = $currentPathSplit[0] + "\\" + $currentPathSplit[1] + "\\" `
           + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A'))) + "\\" + $currentPathSplit[$currentPathSplit.Length - 1]
        if ($truncatedPath.Length -lt $currentPath.Length)
        {
            $displayPath = $truncatedPath
        }
        else
        {
            $displayPath = get-location
        }
    }
    else
    {
        $displayPath = get-location
    }
    Write-Host ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTACAA')))) -NoNewLine -ForegroundColor DarkYellow ; Write-Host ("" + `
       $displayPath + ">") -NoNewLine
    return " "
}
