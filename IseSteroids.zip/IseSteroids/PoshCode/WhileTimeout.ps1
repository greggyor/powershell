﻿function WhileTimeout ( [int]$interval, [int]$maxTries, [scriptblock]$condition )
{
	${/=\/\_/=\/=\/====} = 0
	${___/\___/=\/\/\/\} = Get-Date
	while ( &$condition ) {
		${/=\/\_/=\/=\/====}++
		if ( ${/=\/\_/=\/=\/====} -lt $maxTries ) {
			Start-Sleep -seconds $interval
		} else {
			Throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAcgBhAHQAaQBvAG4AIABlAHgAYwBlAGUAZABlAGQAIAB0AGkAbQBlAG8AdQB0AA==')))
		}
	}
	${/=\__/==\_/\/\___} = Get-Date
	${/==\/=\_/=\/\_/=\} = ( ${/=\__/==\_/\/\___} - ${___/\___/=\/\/\/\} ).TotalSeconds
	Write-Verbose "Operation elapsed time: ${/==\/=\_/=\/\_/=\} seconds"
}
