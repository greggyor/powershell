﻿Param (
	$viServer,
	$bakVM,
	$lxDest,
)

#region check
if (!$viServer) { $viServer = Read-Host -Prompt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBJACAAUwBlAHIAdgBlAHIAIAA='))) }
if (!$bakVM) { $bakVM = Read-Host -Prompt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBNACAAdABvACAAQgBhAGMAawB1AHAAIAA='))) }
if (!$lxDest) { $lxDest = Read-Host -Prompt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawB1AHAAIABQAGEAdABoACAAKABlAHgALgAgAC8AcwByAHYALwBiAGEAYwBrAHUAcAApACAA'))) }
#endregion

#region globalvars
$encoding = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBFAE0A')))
$version = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAuADQA')))
$scriptout = @()
#endregion

#region stkmvars
$viUser = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBtAHcAYQByAGUA')))
$viPass = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBtAHcAYQByAGUA')))
#endregion

Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBpAEIAYQBjAGsAdQBwACAAUwBjAHIAaQBwAHQAIABHAGUAbgBlAHIAYQB0AG8AcgAgAC0AIAA='))) $version
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))

if (($vmCon = Connect-VIServer -Protocol https $viServer) -eq "") { exit }
$vm = Get-VM $bakVM -Server $vmCon -ErrorAction SilentlyContinue

if (!$vm) {
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAVgBNACAAZgBvAHUAbgBkAC4A')))
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAdABoAGUAIABEAGkAcwBwAGwAYQB5ACAATgBhAG0AZQAgAGYAcgBvAG0AIAB0AGgAZQAgAFYASQAgAEMAZQBuAHQAZQByADoA'))) -NoNewline
	$tvm = Read-Host
	if (!($vm=Get-VM $tvm -ErrorAction SilentlyContinue)) {
		return $false
		exit
	}
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIABoAGEAdgBlACAAZQBuAHQAZQByAGUAZAAgADIAIABkAGkAZgBmAGUAcgBlAG4AdAAgAE4AYQBtAGUAcwAuACAAUABsAGUAYQBzAGUAIABjAGgAZQBjAGsAIAB0AGgAYQB0ACAAdABoAGUAIABWAE0AWAAgAGEAbgBkACAAdABoAGUAIABWAE0AIABOAGEAbQBlACAAYQByAGUAIAB0AGgAZQAgAHMAYQBtAGUAIQA=')))
	Write-Host -ForegroundColor yellow "Entered VMX Name: {$bakVM}"
	Write-Host -ForegroundColor yellow "Entered VM Name: {$tvm}"
	Write-Host -ForegroundColor yellow "Returned VM Name: {$vm}"
	Write-Host -ForegroundColor yellow $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBTACAAVABIAEkAUwAgAEMATwBSAFIARQBDAFQAIAAoAFkAZQBzAC8ATgBvACkAPwA6AA=='))) -NoNewline
	$sure = Read-Host
	if ($sure -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQBlAHMA')))) { exit }
}

#check Snapshots
if ((Get-Snapshot -VM $vm -Server $vmCon | Measure-Object | select count).Count -ne "0") {
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBNACAAaABhAHMAIABTAG4AYQBwAHMAaABvAHQAcwAuACAATgBvACAAQgBhAGMAawB1AHAAIABwAG8AcwBzAGkAYgBsAGUALgA=')))
	return $false
	exit
}

#write script
$scriptname = $vm.name + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBzAGgA')))
$vmname = $vm.Name
$vmhost = $vm.Host

#generate Text

$header = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAhAC8AYgBpAG4ALwBiAGEAcwBoAA==')))
$user = "USER=`"${viUser}`""
$pass = "PASS=`"${viPass}`""
$dest = "DEST=`"${lxDest}`""
$lxVM = "VM=`"${vmname}`""

#region writefile

$scriptout += $header 
$scriptout += $user 
$scriptout += $pass 
$scriptout += $dest 
$scriptout += $lxvm 
$scriptout += "" 
$scriptout += "BKUP=``vmrun -h https://${viserver}/sdk -u `${USER} -p `${PASS} list | grep `${VM}`` " 
$scriptout += "SNAPCHECK=``vmware-cmd -H ${viserver} -T ${vmhost} -U `${USER} -P `${PASS} `"`${BKUP}`" hassnapshot`` "
$scriptout += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBmACAAWwAgACIAJABTAE4AQQBQAEMASABFAEMASwAiACAAIQA9ACAAIgBoAGEAcwBzAG4AYQBwAHMAaABvAHQAIAAoACkAIAA9ACIAIABdADsAIAB0AGgAZQBuACAACgAgAGUAYwBoAG8AIAAnAFYATQAgAGgAYQBzACAAYQAgAFMAbgBhAHAAcwBoAG8AdAAuACAAQQByAGIAbwByAHQAaQBuAGcALgAuAC4AJwAgAAoAIABlAHgAaQB0ACAACgAgAGYAaQA='))) 
$scriptout += "vmrun -T esx -h https://${viserver}/sdk -u `${USER} -p `${PASS} snapshot `"`${BKUP}`" vmBackup"

# Hard Disk
foreach ($hd in $vm.Harddisks) {
	$hdname = $hd.Filename
	$vifs = "vifs --server ${viserver} --dc 'KM' --username `${USER} --password `${PASS}  --get `"``echo $hdname | sed 's/.vmdk/-flat.vmdk/g'```" `${DEST}/`${VM}.vmdk "
	$scriptout += $vifs
}

$scriptout += "vmrun -T esx -h https://${viserver}/sdk -u `${USER} -p `${PASS} deleteSnapshot `"`${BKUP}`" vmBackup" 

$scriptout | Out-File $scriptname -Encoding $encoding
#endregion

Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAG4AaQBzAGgAZQBkAA==')))
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AJwB0ACAAZgBvAHIAZwBlAHQAIAB0AG8AIABjAG8AbgB2AGUAcgB0ACAAdABoAGUAIABzAGMAcgBpAHAAdAAgAHUAbgBkAGUAcgAgACoAbgBpAHgALwBMAGkAbgB1AHgAIAB3AGkAdABoACAAZABvAHMAMgB1AG4AaQB4ACEA')))

