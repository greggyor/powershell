﻿Function Get-DiskSizeInfo {
        <#
        .DESCRIPTION
        Check the Disk(s) Size and remaining freespace.

        .PARAMETER ComputerName
        Specify the computername(s)

        .INPUTS
        System.String

        .OUTPUTS
        System.Management.Automation.PSObject

        .EXAMPLE
        Get-DiskSizeInfo
        
        Get the drive(s), Disk(s) space, and the FreeSpace (GB and Percentage)

        .EXAMPLE
        Get-DiskSizeInfo -ComputerName SERVER01,SERVER02

        Get the drive(s), Disk(s) space, and the FreeSpace (GB and Percentage) on the Computers SERVER01 and SERVER02

		.EXAMPLE
        Get-Content Computers.txt | Get-DiskSizeInfo

        Get the drive(s), Disk(s) space, and the FreeSpace (GB and Percentage) for each computers listed in Computers.txt

        .NOTES
    	NAME  : Get-DiskSizeInfo
	AUTHOR: Francois-Xavier Cat
	EMAIL : fxcat@LazyWinAdmin.com
	DATE  : 2013/02/05 
	
	.LINK
	http://lazywinadmin.com

        #>
	[CmdletBinding()]
	param(
		[Parameter(ValueFromPipeline=$True)]
		[string[]]$ComputerName = $env:COMPUTERNAME
	)
	BEGIN {# Setup
		}
	PROCESS {
		Foreach (${00100010011110010} in $ComputerName) {
			Write-Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcAB1AHQAZQByAE4AYQBtAGUAOgAgACQAewAwADAAMQAwADAAMAAxADAAMAAxADEAMQAxADAAMAAxADAAfQAgAC0AIABHAGUAdAB0AGkAbgBnACAARABpAHMAawAoAHMAKQAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgAuAC4ALgA=')))
			try {
	            # Set all the parameters required for our query
				${01100011001010000} = @{'ComputerName'=${00100010011110010};
	            			'Class'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AMwAyAF8ATABvAGcAaQBjAGEAbABEAGkAcwBrAA==')));
							'Filter'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAByAGkAdgBlAFQAeQBwAGUAPQAzAA==')));
							'ErrorAction'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQA=')))}
				${01010101000011011} = $True
				# Run the query against the current $Computer	
				${01000111010111001} = Get-WmiObject @01100011001010000
			}#Try
			Catch {
            	$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADAAMAAwADEAMAAwADEAMQAxADEAMAAwADEAMAB9AA=='))) | Out-File -Append -FilePath c:\\Errors.txt
            	${01010101000011011} = $False
        	}#Catch
			if (${01010101000011011}) {
				Write-Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcAB1AHQAZQByAE4AYQBtAGUAOgAgACQAewAwADAAMQAwADAAMAAxADAAMAAxADEAMQAxADAAMAAxADAAfQAgAC0AIABGAG8AcgBtAGEAdABpAG4AZwAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgAgAGYAbwByACAAZQBhAGMAaAAgAGQAaQBzAGsAKABzACkA')))
            	foreach (${10011000011000110} in ${01000111010111001}) {
                	# Prepare the Information output
					Write-Verbose -Message "ComputerName: ${00100010011110010} - $(${10011000011000110}.deviceid)"
					${10101110001001001} =	 	@{'ComputerName'=${00100010011110010};
                    				'Drive'=${10011000011000110}.deviceid;
									'FreeSpace(GB)'=($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgAyAH0A'))) -f(${10011000011000110}.freespace/1GB));
									'Size(GB)'=($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgAyAH0A'))) -f(${10011000011000110}.size/1GB));
									'PercentFree'=($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAUAAyAH0A'))) -f((${10011000011000110}.Freespace/1GB) / (${10011000011000110}.Size/1GB)))}
					# Create a new PowerShell object for the output
					${00011111100110011} = New-Object -TypeName PSObject -Property ${10101110001001001}
                	${00011111100110011}.PSObject.TypeNames.Insert(0,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHAAbwByAHQALgBEAGkAcwBrAFMAaQB6AGUASQBuAGYAbwA='))))
                	# Output the disk information
					Write-Output -InputObject ${00011111100110011}
            	}#foreach ($disk in $disks)
        	}#if ($TryIsOK)
    	}#Foreach ($Computer in $ComputerName)
	}#PROCESS
    END {# Cleanup
		}
}#Function Get-DiskSizeInfo
