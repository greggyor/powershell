﻿function Monitor-FileSize
{
param
(
[Parameter(mandatory=$true,position=0)]
[string[]]$FilePath
,
[Parameter(mandatory=$true,position=1)]
[int]$Size
,
[Parameter(mandatory=$false)]
[int]$Interval=5
)
if((Test-Path $FilePath))
{
   While(${2} -le $Size)
   {
      Start-Sleep -Seconds $Interval
      ${1} = get-childitem $FilePath -Recurse -Include *.* | foreach-object -Process { $_.length / 1024 } | Measure-Object -Sum | Select-Object -Property Sum
      ${2} = ${1}.Sum
   }
} 
else{$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQAgAGQAbwBlAHMAIABuAG8AdAAgAGUAeABpAHMAdAAhAA==')))}
Write-Output "The files at location, $FilePath , have exceeded $Size kb and are now $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgA0AH0A'))) -f ${1}.Sum) kb in size."
}
