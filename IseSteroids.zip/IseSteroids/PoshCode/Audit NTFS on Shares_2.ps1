﻿${9} = New-Object -Com Excel.Application
${9}.visible = $True
${9} = ${9}.Workbooks.Add()

${4} = ${9}.Worksheets.Item(1)
${4}.Cells.item(1,1) = "Folder Path:" 
${4}.Cells.Item(1,2) = "Users/Groups:"
${4}.Cells.Item(1,3) = "Permissions:"
${4}.Cells.Item(1,4) = "Permissions Inherited:"

${1} = ${4}.UsedRange
${1}.Interior.ColorIndex = 8
${1}.Font.ColorIndex = 11
${1}.Font.Bold = $True


${8} = ls -Path "c:\\inetpub" -recurse | Where {$_.psIsContainer -eq $true}

${2} = 1
foreach (${6} in ${8})
{
	${7} = Get-Acl -Path ${6}.FullName

	foreach (${3} in ${7})
		{
			${2}++
			${4}.Cells.Item(${2},1) = ${6}.FullName
			
				foreach (${5} in ${3}.Access)
					{
						${4}.Cells.Item(${2},2) = "$(${5}.IdentityReference)"
				    	${4}.Cells.Item(${2},3) = "$(${5}.FileSystemRights)"
						${4}.Cells.Item(${2},4) = ${3}.AreAccessRulesProtected
						${2}++
					}
		}
	
}
${1}.EntireColumn.AutoFit()
