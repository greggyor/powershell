﻿

if (-not(test-path variable:script:_helpcache))
{
    ${SCRIPT:35} = @{}
}

function Select-EnumeratedType
{

    [cmdletbinding()]
    param(
        [parameter(position=0, mandatory=$true)]
        [validatescript({ $_.isenum })]
        [validatenotnull()]
        [type]$EnumeratedType,
        
        [parameter()]
        [switch]$IncludeHelp
    )
    
    dynamicparam {
    
        
        if ($PSCmdlet.MyInvocation.BoundParameters["EnumeratedType"]) {
        
            write-verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAaQBuAGcAIABEAGUAZgBhAHUAbAB0AFYAYQBsAHUAZQAgACgAJABlAG4AdQBtAGUAcgBhAHQAZQBkAFQAeQBwAGUAKQAgAHAAYQByAGEAbQBlAHQAZQByAC4A')))
            
            
            ${32} = new-object management.automation.RuntimeDefinedParameterDictionary
            ${33} = new-object System.Management.Automation.RuntimeDefinedParameter
            ${33}.Name = "DefaultValue"
            ${33}.ParameterType = $enumeratedType
            
            
            ${34} = new-object System.Management.Automation.ParameterAttribute
            ${34}.ParameterSetName = $PSCmdlet.ParameterSetName
            ${34}.ValueFromRemainingArguments = $true
            ${34}.Position = 1
            ${34}.Mandatory = $false
            ${33}.Attributes.Add(${34})
            
            ${32}.Add("DefaultValue", ${33})
            ${32}
        }
    }
    
    end {                
        
        ${14} = $pscmdlet.MyInvocation.BoundParameters["DefaultValue"]               
        

        ${28} = @{}

        if ($IncludeHelp) {

            ${31} = f1 -type $enumeratedType        

            if (${31}) {

                
                ${30} = [xml][io.file]::readAllLines(${31})

                $selector = "F:$($enumeratedType.fullName)"

                foreach (${29} in ${30}.doc.members.selectnodes($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBlAG0AYgBlAHIAWwBzAHQAYQByAHQAcwAtAHcAaQB0AGgAKABAAG4AYQBtAGUALAAnACQAcwBlAGwAZQBjAHQAbwByACcAKQBdAA=='))))) {
                    if (${29}.summary) {
                        ${28}[${29}.name] = ${29}.summary.trim()
                    }
                }
            }
        }

        ${15} = new-object collections.generic.list[System.Management.Automation.Host.ChoiceDescription]

        $names = [enum]::getnames($enumeratedType)
        [double[]]${18} = [enum]::getvalues($enumeratedType)|%{[double]$_}
        
        
        ${6} = f2 $names

        
        $names | % {
            
            ${9} = $_.indexof([string]${6}[$_], [stringcomparison]::ordinalignorecase)
            
            if (${9} -ne -1) {
            
                
                ${26} = $_.insert(${9}, "&") 
            
            } else {
            
                
                ${26} = "$_ (&$(${6}[$_]))"
            }

            ${27} = "F:$($enumeratedType.fullname).$_"
            
            if ($includehelp -and ${28}[${27}]) {
            
                
                ${25} =  @(${26}, ${28}[${27}])
            
            } else {
            
                ${25} = ${26}
            }
            
            ${15}.add((new-object Management.Automation.Host.ChoiceDescription -Args ${25}))
        }

        
        ${23} = $enumeratedType.GetCustomAttributes([FlagsAttribute], $false)
        
        
        ${24} = $host.ui -is [Management.Automation.Host.IHostUISupportsMultipleChoiceSelection]
        
        if (${23} -and (-not ${24})) {
            
            throw ("{0} enum is flags decorated and this host ({1}) does not support multiple choice selections. Sorry!" -f $enumeratedType.name, $host.name)
        
        }
        
        ${17} = $enumeratedType.name               

        if (${23}) {
        
            if (-not ${14}) {
        
                
                ${14} = [int[]]@()
        
            } else {
        
                
                [int[]]${19} = @()
                ${22} = [math]::log([enum]::GetUnderlyingType($enumeratedType)::maxvalue + 1, 2)
                
                
                
                for (${21} = [int]${22}; ${21} -ge 0; ${21}--) {
        
                    ${20} = [math]::pow(2,${21}) 
        
                    if (([int]${14}) -band ${20}) {
                        ${19} += [array]::indexof(${18}, ${20})
                    }
                }
                ${14} = ${19}
            }
            
            ${16} = "Choose one or more values for mask:"
            ${17} += " (Flags)"

        } else {
        
            if (-not ${14}) {
        
                
                ${14} = -1
        
            } else {
        
                
                ${14} = [array]::indexof(${18}, [double]${14})
            }
            ${16} = "Choose single value:"
        }
        
        ${13} = @()
        
        
        $host.ui.promptforchoice(${17}, ${16}, ${15}, ${14}) | % {
            ${13} += $names[$_]
        }
        
        
        ${13} -as $enumeratedtype
    }
}

function Get-HelpSummary
{
        [CmdletBinding()]
        param
        (        
            [string]$file,
            [reflection.assembly]$assembly,
            [string]$selector
        )
        
        if ($helpCache.ContainsKey($assembly))
        {
            ${12} = $helpCache[$assembly]            
        }
        else
        {
            
            Write-Progress -id 1 "Caching Help Documentation" $assembly.getname().name

            
            ${12} = [xml](gc $file)
            
            $helpCache.Add($assembly, ${12})
            
            Write-Progress -id 1 "Caching Help Documentation" $assembly.getname().name -completed
        }

        
        ${11} = ${12}.doc.members.SelectSingleNode($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBlAG0AYgBlAHIAWwBAAG4AYQBtAGUAPQAnACQAcwBlAGwAZQBjAHQAbwByACcAIABvAHIAIABzAHQAYQByAHQAcwAtAHcAaQB0AGgAKABAAG4AYQBtAGUALAAnACQAcwBlAGwAZQBjAHQAbwByACgAJwApAF0A')))).summary
        
        ${11}
}

function f2 {
    param([string[]]$names)
    
    ${6} = @{}

    
    $names | % {
        
        ${8} = [char]::toupper($_[0])
        
        
        if (-not ${6}.containsvalue(${8})) {
            ${6}[$_] = ${8}
            write-debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQApACAAYQBzAHMAaQBnAG4AZQBkACAAJAB7ADgAfQAgAHQAbwAgACQAXwA=')))
        }
    }

    $names | ? {

        
        -not ${6}.containskey($_)

    } | % {
        
        
        for (${9}=1; ${9} -lt $_.length; ${9}++) {
            
            ${8} = $_[${9}]
            
            if ([char]::IsUpper(${8}) -and (-not ${6}.containsvalue(${8}))) {
                ${6}[$_] = ${8}
                write-debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgApACAAYQBzAHMAaQBnAG4AZQBkACAAJAB7ADgAfQAgAHQAbwAgACQAXwA=')))
                break
            }
        }
    }

    $names | ? {

        
        -not ${6}.containskey($_)

    } | % {

        
        for (${9}=1; ${9} -lt $_.length; ${9}++) {
            
            ${8} = [char]::toupper($_[${9}])
            
            
            if (-not ${6}.containsvalue(${8})) {
                ${6}[$_] = ${8}
                write-debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwApACAAYQBzAHMAaQBnAG4AZQBkACAAJAB7ADgAfQAgAHQAbwAgACQAXwA=')))
                break
            }
        }
    }

    
    $names | ? {

        
        -not ${6}.containskey($_)

    } | % { 

        ${7} = $_
        write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAByAG8AYwBlAHMAcwBpAG4AZwAgACQAewA3AH0A')))

        ${10} = [int]"A"[0]
        
        for (${9} = ${10}; ${9} -lt (${10} + 26); ${9}++) {

            ${8} = [char]${9}
            
            if (-not ${6}.containsvalue(${8})) {
                ${6}[${7}] = ${8}
                write-debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAApACAAYQBzAHMAaQBnAG4AZQBkACAAJAB7ADgAfQAgAHQAbwAgACQAewA3AH0A')))
                break
            }
        }
    }
    
    
    ${6}
}

function f1 {
    [cmdletbinding()]
    param([type]$type)
    
    ${1} = [io.path]::changeextension([io.path]::getfilename($type.assembly.location), ".xml")
    ${3} = [io.path]::getdirectoryname($type.assembly.location)
    ${2} = (new-object uri $type.assembly.codebase).localpath
            
    
    ${4} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AGUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAFwATQBpAGMAcgBvAHMAbwBmAHQALgBOAEUAVABcAFwAZgByAGEAbQBlAHcAbwByAGsAXABcAHYAMgAuADAALgA1ADAANwAyADcA')))
    ${5} = [system.globalization.cultureinfo]::CurrentUICulture.parent.name

    switch
        (
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQBcAFwAJAB7ADUAfQBcAFwAJAB7ADEAfQA='))),
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQBcAFwAJAB7ADEAfQA='))),
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADMAfQBcAFwAJAB7ADEAfQA='))),
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADIAfQBcAFwAJAB7ADEAfQA=')))
        )
    {
        { test-path $_ } { $_; return; }
        
        default
        {
            
            continue;
        }        
    }
}

