﻿get-vc virtualCenterServerName
get-vmhost | Get-VirtualSwitch -Name SwitchName | New-VirtualPortGroup -Name VLAN_12 -VLANID 12
