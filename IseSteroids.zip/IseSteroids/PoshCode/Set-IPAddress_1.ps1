﻿function Set-IPAddress {
		param(		[string]$networkinterface =$(read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAdABoAGUAIABuAGEAbQBlACAAbwBmACAAdABoAGUAIABOAEkAQwAgACgAaQBlACAATABvAGMAYQBsACAAQQByAGUAYQAgAEMAbwBuAG4AZQBjAHQAaQBvAG4AKQA=')))),
				[string]$ip = $(read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAYQBuACAASQBQACAAQQBkAGQAcgBlAHMAcwAgACgAaQBlACAAMQAwAC4AMQAwAC4AMQAwAC4AMQAwACkA')))),
				[string]$mask = $(read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAdABoAGUAIABzAHUAYgBuAGUAdAAgAG0AYQBzAGsAIAAoAGkAZQAgADIANQA1AC4AMgA1ADUALgAyADUANQAuADAAKQA=')))),
				[string]$gateway = $(read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAdABoAGUAIABjAHUAcgByAGUAbgB0ACAAbgBhAG0AZQAgAG8AZgAgAHQAaABlACAATgBJAEMAIAB5AG8AdQAgAHcAYQBuAHQAIAB0AG8AIAByAGUAbgBhAG0AZQA=')))),
				[string]$dns1 = $(read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAdABoAGUAIABmAGkAcgBzAHQAIABEAE4AUwAgAFMAZQByAHYAZQByACAAKABpAGUAIAAxADAALgAyAC4AMAAuADIAOAApAA==')))),
				[string]$dns2,
				[string]$registerDns = "TRUE"
		 )
		$dns = $dns1
		if($dns2){$dns =$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABkAG4AcwAxACwAJABkAG4AcwAyAA==')))}
		$index = (gwmi Win32_NetworkAdapter | where {$_.netconnectionid -eq $networkinterface}).InterfaceIndex
		$NetInterface = Get-WmiObject Win32_NetworkAdapterConfiguration | where {$_.InterfaceIndex -eq $index}
		$NetInterface.EnableStatic($ip, $subnetmask)
		$NetInterface.SetGateways($gateway)
		$NetInterface.SetDNSServerSearchOrder($dns)
		$NetInterface.SetDynamicDNSRegistration($registerDns)
}
