﻿<#
  Author:   Matt Schmitt
  Date:     11/29/12 
  Version:  1.0 
  From:     USA 
  Email:    ithink2020@gmail.com 
  Website:  http://about.me/schmittmatt
  Twitter:  @MatthewASchmitt
  
  Description
  A script for checking the status of a service on a group of servers, from a list in a file.  
#>


${___/\_/\___/=\___} = Import-Csv $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABzAGUAcgB2AGUAcgBMAGkAcwB0AC4AYwBzAHYA')))

$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIA'))) +"`t" + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAdAB1AHMA'))) | Out-File c:\\ServerService.csv


foreach (${_____/==\/===\__/} in ${___/\_/\___/=\___}) 
{
    
    ${_/=\_/=\/\_/=\/==} = get-service -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBQAFMAVgBTAA=='))) | Select-Object -expand Status

    ${_/\/==\/=\_/=\/==} = ${_____/==\/===\__/} | Select-Object -expand Server

    ${_/\/==\/=\_/=\/==} + "`t" + ${_/=\_/=\/\_/=\/==} | Out-File -append c:\\ServerServiceStatus.csv

} 


Send-MailMessage -From donotreply@test.com -To recipient@domain.com -subject $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBwAG8AbwBsAGUAcgAgAFMAZQByAHYAaQBjAGUAIABSAGUAcABvAHIAdAA='))) -Body $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAYQBjAGgAZQBkACAAaQBzACAAUwBlAHIAdgBlAHIAIABTAGUAcgB2AGkAYwBlACAAcgBlAHAAbwByAHQALgA='))) -Attachments $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABTAGUAcgB2AGUAcgBTAGUAcgB2AGkAYwBlAFMAdABhAHQAdQBzAC4AYwBzAHYA'))) -SmtpServer $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eAB4AHgALgB4AHgAeAAuAHgAeAB4AC4AeAB4AHgA')))
