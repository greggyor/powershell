﻿# calculate SHA512 of file.

function _00010111110000100([System.IO.FileInfo] ${_10111101110001110} = $(throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGEAZwBlADoAIABHAGUAdAAtAE0ARAA1ACAAWwBTAHkAcwB0AGUAbQAuAEkATwAuAEYAaQBsAGUASQBuAGYAbwBdAA==')))))
{
  	${10001001111010111} = $null;
  	${01100101111011111} = [System.Security.Cryptography.SHA512CryptoServiceProvider];
  	${00111100010001111} = new-object ${01100101111011111}
  	${10001001111010111} = ${_10111101110001110}.OpenRead();
  	${10011111110000011} = ${00111100010001111}.ComputeHash(${10001001111010111});
  	${10001001111010111}.Close();

  	## We have to be sure that we close the file stream if any exceptions are thrown.

  	trap
  	{
   		if (${10001001111010111} -ne $null)
    		{
			${10001001111010111}.Close();
		}
  		break;
	}	

 	foreach (${00100110001001101} in ${10011111110000011}) { if (${00100110001001101} -lt 16) {${10111110100101111} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAB7ADAAOgBYAH0A'))) -f ${00100110001001101} } else { ${10111110100101111} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAWAB9AA=='))) -f ${00100110001001101} }}
	return [string]${10111110100101111};
}

function _00100100111101111 ( ${_00011110000111111}, ${_00001110111001011})
{
    if (!(${_00001110111001011}) -or ${_00001110111001011} -eq "") {return $true}
    ${_00011110000111111}=join-path ${_00011110000111111} "\\"
    foreach(${01101011111010111} in ${_00001110111001011})
    {
        if (${_00011110000111111}.tolower().startswith(${01101011111010111}.tolower())) {return $false}
    }
    return $true
}

#   chkhash.ps1 [file(s)/dir #1] [file(s)/dir #2] ... [file(s)/dir #3] [-u] [-h [path of .xml database]]
#   -u updates the XML file database and exits
#   otherwise, all files are checked against the XML file database.
#   -h specifies location of xml hash database


${10000111100110100}=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFwAaABhAHMAaABlAHMALgB4AG0AbAA=')))
del variable:\\args3 -ea 0
del variable:\\args2 -ea 0
del variable:\\xfiles -ea 0
del variable:\\files -ea 0
del variable:\\exclude -ea 0
${10010110110000100}=@()
${11000000000111011}=@($args)
${10001000100111110} = 0
${00010000001010001} = 0
${10001110001111010} = 0
${00001101001010001} = 0
${10110100011001100} = $false
${00001101100001100} = $false

for(${10101100111011001}=0;${10101100111011001} -lt ${11000000000111011}.count; ${10101100111011001}++)
{
    if (${11000000000111011}[${10101100111011001}] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBoACoA'))))                                             # -help specified?
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGEAZwBlADoAIAAgACAAIAAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABbAC0AaABdACAAWwAtAHUAXQAgAFsALQBjAF0AIABbAC0AeAAgADwAZgBpAGwAZQAgAHAAYQB0AGgAIABvAGYAIABoAGEAcwBoAGUAcwAgAC4AeABtAGwAIABkAGEAdABhAGIAYQBzAGUAPgBdACAAWwBmAGkAbABlACgAcwApAC8AZABpAHIAIAAjADEAXQAgAFsAZgBpAGwAZQAoAHMAKQAvAGQAaQByACAAIwAyAF0AIAAuAC4ALgAgAFsAZgBpAGwAZQAoAHMAKQAvAGQAaQByACAAIwBuAF0AIABbAC0AZQAgADwARABpAHIAcwA+AF0A')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAHQAaQBvAG4AcwA6ACAAIAAtAGgAIAAtACAASABlAGwAcAAgAGQAaQBzAHAAbABhAHkALgA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAGMAIAAtACAAQwByAGUAYQB0AGUAIABoAGEAcwBoACAAZABhAHQAYQBiAGEAcwBlAC4AIABJAGYAIAAuAHgAbQBsACAAaABhAHMAaAAgAGQAYQB0AGEAYgBhAHMAZQAgAGQAbwBlAHMAIABuAG8AdAAgAGUAeABpAHMAdAAsACAALQBjACAAdwBpAGwAbAAgAGIAZQAgAGEAcwBzAHUAbQBlAGQALgA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAHUAIAAtACAAVQBwAGQAYQB0AGUAIABjAGgAYQBuAGcAZQBkACAAZgBpAGwAZQBzACAAYQBuAGQAIABhAGQAZAAgAG4AZQB3ACAAZgBpAGwAZQBzACAAdABvACAAZQB4AGkAcwB0AGkAbgBnACAAZABhAHQAYQBiAGEAcwBlAC4A')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAHgAIAAtACAAcwBwAGUAYwBpAGYAaQBlAHMAIAAuAHgAbQBsACAAZABhAHQAYQBiAGEAcwBlACAAZgBpAGwAZQAgAHAAYQB0AGgAIAB0AG8AIAB1AHMAZQAuACAARABlAGYAYQB1AGwAdAAgAGkAcwAgAC4AXABcAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAtAGUAIAAtACAAZQB4AGMAbAB1AGQAZQAgAGQAaQByAHMALgAgAFAAdQB0ACAAdABoAGkAcwAgAGEAZgB0AGUAcgAgAHQAaABlACAAZgBpAGwAZQBzAC8AZABpAHIAcwAgAHkAbwB1ACAAdwBhAG4AdAAgAHQAbwAgAGMAaABlAGMAawAgAHcAaQB0AGgAIABTAEgAQQA1ADEAMgAgAGEAbgBkACAAbgBlAGUAZABzACAAdABvACAAYgBlACAAZgB1AGwAbABwAGEAdABoACAAKABlAC4AZwAuACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGIAbwBiACAAbgBvAHQAIAAuAC4AXABcAGIAbwBiACkALgA=')))
        ""
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGEAbQBwAGwAZQBzADoAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcACAAZAA6AFwAXAAgAC0AYwAgAC0AeAAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABiAG8AYgBcAFwAaABhAHMAaABlAHMAXABcAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAGgAYQBzAGgAIABhAGwAbAAgAGYAaQBsAGUAcwAgAG8AbgAgAGMAOgBcAFwAIABhAG4AZAAgAGQAOgBcAFwAIABhAG4AZAAgAHMAdQBiAGQAaQByAHMALAAgAGMAcgBlAGEAdABlACAAYQBuAGQAIABzAHQAbwByAGUAIABoAGEAcwBoAGUAcwAgAGkAbgAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABiAG8AYgBcAFwAaABhAHMAaABlAHMAXABcAGgAYQBzAGgAZQBzAC4AeABtAGwAXQA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABwAGkAYwB0AHUAcgBlAHMAXABcAHMAdQBuAHMAZQB0AC4AagBwAGcAIAAtAHUAIAAtAHgAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcABpAGMAdAB1AHIAZQBzAGgAYQBzAGgAZQBzAC4AeABtAGwAXQA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAGgAYQBzAGgAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABwAGkAYwB0AHUAcgBlAHMAXABcAHMAdQBuAHMAZQB0AC4AagBwAGcAIABhAG4AZAAgAGEAZABkACAAbwByACAAdQBwAGQAYQB0AGUAIAB0AGgAZQAgAGgAYQBzAGgAIAB0AG8AIABjADoAXABcAHUAcwBlAHIAcwBcAFwAYQBsAGkAYwBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcABpAGMAdAB1AHIAZQBoAGEAcwBoAGUAcwAuAHgAbQBsAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGQAbwBjAHUAbQBlAG4AdABzACAAZAA6AFwAXABtAGUAZABpAGEAXABcAG0AbwB2AGkAZQBzACAALQB4ACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGUAdgBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcAByAGkAdgBhAHQAZQAuAHgAbQBsAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAGgAYQBzAGgAIABhAGwAbAAgAGYAaQBsAGUAcwAgAGkAbgAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABlAHYAZQBcAFwAZABvAGMAdQBtAGUAbgB0AHMAIABhAG4AZAAgAGQAOgBcAFwAbQBlAGQAaQBhAFwAXABtAG8AdgBpAGUAcwAsACAAYwBoAGUAYwBrACAAYQBnAGEAaQBuAHMAdAAgAGgAYQBzAGgAZQBzACAAcwB0AG8AcgBlAGQAIABpAG4AIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGgAYQBzAGgAZQBzAFwAXABwAHIAaQB2AGEAdABlAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG8AcgAgAGMAcgBlAGEAdABlACAAaQB0ACAAYQBuAGQAIABzAHQAbwByAGUAIABoAGEAcwBoAGUAcwAgAHQAaABlAHIAZQAgAGkAZgAgAG4AbwB0ACAAcAByAGUAcwBlAG4AdABdAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcABzADEAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAIAAtAHgAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGgAYQBzAGgAZQBzAFwAXABwAHIAaQB2AGEAdABlAC4AeABtAGwAIAAtAGUAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAZQB2AGUAXABcAGgAYQBzAGgAZQBzAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAGgAYQBzAGgAIABhAGwAbAAgAGYAaQBsAGUAcwAgAGkAbgAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABlAHYAZQAgAGEAbgBkACAAcwB1AGIAZABpAHIAcwAsACAAYwBoAGUAYwBrACAAaABhAHMAaABlAHMAIABhAGcAYQBpAG4AcwB0ACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGUAdgBlAFwAXABoAGEAcwBoAGUAcwBcAFwAcAByAGkAdgBhAHQAZQAuAHgAbQBsACAAbwByACAAcwB0AG8AcgBlACAAaQBmACAAbgBvAHQAIABwAHIAZQBzAGUAbgB0ACwAIABlAHgAYwBsAHUAZABlACAA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXABlAHYAZQBcAFwAaABhAHMAaABlAHMAIABkAGkAcgBlAGMAdABvAHIAeQAgAGEAbgBkACAAcwB1AGIAZABpAHIAcwBdAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoAC4AcAAxAHMAIABjADoAXABcAHUAcwBlAHIAcwBcAFwAdABlAGQAXABcAGQAbwBjAHUAbQBlAG4AdABzAFwAXABmACoAIABkADoAXABcAGQAYQB0AGEAIAAtAHgAIABkADoAXABcAGgAYQBzAGgAZQBzAC4AeABtAGwAIAAtAGUAIABkADoAXABcAGQAYQB0AGEAXABcAHQAZQBzAHQAIABkADoAXABcAGQAYQB0AGEAXABcAGYAYQB2AG8AcgBpAHQAZQBzACAALQB1AA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAGgAYQBzAGgAIABhAGwAbAAgAGYAaQBsAGUAcwAgAHMAdABhAHIAdABpAG4AZwAgAHcAaQB0AGgAIAAnAGYAJwAgAGkAbgAgAGMAOgBcAFwAdQBzAGUAcgBzAFwAXAB0AGUAZABcAFwAZABvAGMAdQBtAGUAbgB0AHMALAAgAGEAbgBkACAAYQBsAGwAIABmAGkAbABlAHMAIABpAG4AIABkADoAXABcAGQAYQB0AGEALAAgAGEAZABkACAAbwByACAAdQBwAGQAYQB0AGUAIABoAGEAcwBoAGUAcwAgAHQAbwA=')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGUAeABpAHMAdABpAG4AZwAgAGQAOgBcAFwAaABhAHMAaABlAHMALgB4AG0AbAAsACAAZQB4AGMAbAB1AGQAZQAgAGQAOgBcAFwAZABhAHQAYQBcAFwAdABlAHMAdAAgAGEAbgBkACAAZAA6AFwAXABkAGEAdABhAFwAXABmAGEAdgBvAHIAaQB0AGUAcwAgAGEAbgBkACAAcwB1AGIAZABpAHIAcwBdAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABQAFMAPgAuAFwAXABjAGgAawBoAGEAcwBoACAALQB4ACAAYwA6AFwAXAB1AHMAZQByAHMAXABcAGEAbABpAGMAZQBcAFwAaABhAHMAaABlAHMAXABcAGgAYQBzAGgAZQBzAC4AeABtAGwA')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAAIABbAEwAbwBhAGQAIABoAGEAcwBoAGUAcwAuAHgAbQBsACAAYQBuAGQAIABjAGgAZQBjAGsAIABoAGEAcwBoAGUAcwAgAG8AZgAgAGEAbABsACAAZgBpAGwAZQBzACAAYwBvAG4AdABhAGkAbgBlAGQAIAB3AGkAdABoAGkAbgAuAF0A')))
        ""
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAZQA6ACAAIAAgACAAIABmAGkAbABlAHMAIABpAG4AIABzAHUAYgBkAGkAcgBlAGMAdABvAHIAaQBlAHMAIABvAGYAIABhAG4AeQAgAHMAcABlAGMAaQBmAGkAZQBkACAAZABpAHIAZQBjAHQAbwByAHkAIABhAHIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABwAHIAbwBjAGUAcwBzAGUAZAAuAA==')))
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIABpAGYAIAB5AG8AdQAgAHMAcABlAGMAaQBmAHkAIABvAG4AbAB5ACAAYQBuACAALQB4ACAAbwBwAHQAaQBvAG4ALAAgAG8AcgAgAG4AbwAgAG8AcAB0AGkAbwBuACAAYQBuAGQAIAAuAFwAXABoAGEAcwBoAC4AeABtAGwAIABlAHgAaQBzAHQAcwAsACAAbwBuAGwAeQAgAGYAaQBsAGUAcwAgAGkAbgAgAHQAaABlACAAZABhAHQAYQBiAGEAcwBlACAAdwBpAGwAbAAgAGIAZQAgAGMAaABlAGMAawBlAGQALgA=')))
        exit
    }
    if (${11000000000111011}[${10101100111011001}] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQB1ACoA')))) {${10110100011001100}=$true;continue}                       # Update and Add new files to database?
    if (${11000000000111011}[${10101100111011001}] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBjACoA')))) {${00001101100001100}=$true;continue}                    # Create database specified?
    if (${11000000000111011}[${10101100111011001}] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQB4ACoA')))) 
    {
        ${10101100111011001}++                                                                # Get hashes xml database path    
        if (${10101100111011001} -ge ${11000000000111011}.count) 
        {
            write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBYACAAcwBwAGUAYwBpAGYAaQBlAGQAIABiAHUAdAAgAG4AbwAgAGYAaQBsAGUAIABwAGEAdABoACAAbwBmACAALgB4AG0AbAAgAGQAYQB0AGEAYgBhAHMAZQAgAHMAcABlAGMAaQBmAGkAZQBkAC4AIABFAHgAaQB0AGkAbgBnAC4A')))
            exit
        }
        ${10000111100110100}=${11000000000111011}[${10101100111011001}]
        continue
    }
    if (${11000000000111011}[${10101100111011001}] -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBlACoA'))))                                             # Exclude files, dirs
    {
        while ((${10101100111011001}+1) -lt ${11000000000111011}.count)
        {
            ${10101100111011001}++
            if (${11000000000111011}[${10101100111011001}] -like "-*") {break}            
            ${01101110100110111}+=@(join-path ${11000000000111011}[${10101100111011001}] "\\")                           # collect array of excluded directories.            
        }
        continue
    }        
    ${10010110110000100}+=@(${11000000000111011}[${10101100111011001}])                                                   # Add files/dirs
}

$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGsASABhAHMAaAAuAHAAcwAxACAALQAgAC4AXABcAGMAaABrAGgAYQBzAGgALgBwAHMAMQAgAC0AaAAgAGYAbwByACAAdQBzAGEAZwBlAC4A')))
""

if (${10010110110000100}.count -ne 0) 
{
    # Get list of files and SHA512 hash them.
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHUAbQBlAHIAYQB0AGkAbgBnACAAZgBpAGwAZQBzACAAZgByAG8AbQAgAHMAcABlAGMAaQBmAGkAZQBkACAAbABvAGMAYQB0AGkAbwBuAHMALgAuAC4A')))

    ${01011110100001101}=@(dir ${10010110110000100} -recurse -ea 0 | ?{$_.mode -notmatch "d"} | ?{_00100100111101111 $_.directoryname ${01101110100110111}})              # Get list of files

    if (${01011110100001101}.count -eq 0) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQBzACAAZgBvAHUAbgBkAC4AIABFAHgAaQB0AGkAbgBnAC4A'))); exit}

    if (${00001101100001100} -eq $true -or !(test-path ${10000111100110100}))                        # Create database?
    {       
        # Create SHA512 hashes of files and write to new database
    
        ${01011110100001101} = ${01011110100001101} | %{write-host "SHA-512 Hashing `"$($_.fullname)`" ...";add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(_00010111110000100 $_.fullname) -passthru}
        ${01011110100001101} |export-clixml ${10000111100110100}    
        "Created ${10000111100110100}"
        "$(${01011110100001101}.count) file hash(es) saved. Exiting."
        exit
    }
    ${00001001000111011}=@(import-clixml ${10000111100110100}|?{_00100100111101111 $_.directoryname ${01101110100110111}})  # Load database
}
else
{
    if (!(test-path ${10000111100110100})) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZABhAHQAYQBiAGEAcwBlACAAZgBvAHUAbgBkACAAbwByACAAcwBwAGUAYwBpAGYAaQBlAGQALAAgAGUAeABpAHQAaQBuAGcALgA='))); exit}
    ${00001001000111011}=@(import-clixml ${10000111100110100}|?{_00100100111101111 $_.directoryname ${01101110100110111}}) # Load database and check it
    if (${00001001000111011}.count -eq 0) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQBzACAAcwBwAGUAYwBpAGYAaQBlAGQAIABhAG4AZAAgAG4AbwAgAGYAaQBsAGUAcwAgAGkAbgAgAEQAYQB0AGEAYgBhAHMAZQAuACAARQB4AGkAdABpAG4AZwAuAA==')));Exit}
    ${01011110100001101}=${00001001000111011}
}

"Loaded $(${00001001000111011}.count) file hash(es) from ${10000111100110100}"
    
${00010110110011100}=@{}
for(${10111000010101100}=0;${10111000010101100} -lt ${00001001000111011}.count; ${10111000010101100}++)                                    # Build dictionary (hash) of filenames and indexes into file array
{
    if (${00010110110011100}.contains(${00001001000111011}[${10111000010101100}].fullname)) {continue}
    ${00010110110011100}.Add(${00001001000111011}[${10111000010101100}].fullname,${10111000010101100})   
}
     
foreach(${01000100000010100} in ${01011110100001101})
{
    if ((get-item -ea 0 ${01000100000010100}.fullname) -eq $null) {continue}              # skip if file no longer exists.
    
    ${00101010000011011}=(${00010110110011100}.(${01000100000010100}.fullname))
    if (${00101010000011011} -eq $null)
    {    
        ${10001000100111110}++                                           # increment needs/needed updating count
        if (${10110100011001100} -eq $false) {"Needs to be added: `"$(${01000100000010100}.fullname)`"";continue}                 # if not updating, then  continue
    
        "SHA-512 Hashing `"$(${01000100000010100}.fullname)`" ..."
        
        # Create SHA512 hash of file
        
        ${01000100000010100}=${01000100000010100} |%{add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(_00010111110000100 $_.fullname) -passthru -force}
        
        ${00001001000111011}+=@(${01000100000010100})                                  # then add file + hash to list
        continue
    }
    
    ${01000100000010100}=${01000100000010100} |%{add-member -inputobject $_ -name SHA512 -membertype noteproperty -value $(_00010111110000100 $_.fullname) -passthru -force}
    
    ${10001110001111010}++                                               # File checked increment.                                                                  
    if (${00001001000111011}[${00101010000011011}].SHA512 -eq ${01000100000010100}.SHA512)               # Check SHA512 for mixmatch.
    {${00001101001010001}++;continue}                                    # if matched, increment file matches and continue loop
        
    ${00010000001010001}++                                             # increment mixmatches
    if (${10110100011001100} -eq $true) { ${00001001000111011}[${00101010000011011}]=${01000100000010100}; "Updated `"$(${01000100000010100}.fullname)`"";continue}                                                   
    "Bad SHA-512 found: `"$(${01000100000010100}.fullname)`""
}

if (${10110100011001100} -eq $true)                                     # if database updated
{
    ${00001001000111011}|export-clixml ${10000111100110100}                   # write xml database
    "Updated ${10000111100110100}"
    "${10001000100111110} file hash(es) added to database."
    "${00010000001010001} file hash(es) updated in database."
    exit
}

"${00010000001010001} SHA-512 mixmatch(es) found."
"${00001101001010001} file(s) SHA512 matched." 
"${10001110001111010} file(s) checked total."
if (${10001000100111110} -ne 0) {"${10001000100111110} file(s) need to be added [run with -u option to Add file hashes to database]."}    
