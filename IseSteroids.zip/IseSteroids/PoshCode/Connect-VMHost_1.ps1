﻿#requires -version 2 
#requires -pssnapin VMware.VimAutomation.Core 
Function Connect-VMHost {
    <#
    .Summary
        Used to Connect a disconnected host to vCenter.
    .Parameter VMHost
        VMHost to reconnect to virtual center
    .Example
        Get-VMHost | Where-Object {$_.state -eq "Disconnected"} | Connect-VMHost
        
        Will Attempt to reconnect any host that are currently disconnected.
    .Example
        Connect-VMHost -Name ESX1.get-admin.local
        
        Will reconnect ESX1 to vCenter
    #>
    [CmdletBinding(
        SupportsShouldProcess=$True,
	    SupportsTransactions=$False,
	    ConfirmImpact="low",
	    DefaultParameterSetName="ByString"
	)]
    Param(
        [Parameter(
            Mandatory=$True,
            Valuefrompipeline=$true,
            ParameterSetName="ByObj"
        )]
        [VMware.VimAutomation.Client20.VMHostImpl[]]
        $VMHost,
        
        [Parameter(
            Mandatory=$True,
            Position=0,
            ParameterSetName="ByString"
        )]
        [string[]]
        $Name
    )
    Begin {
        IF ($Name) {
            $VMHost = $Name|%{ Get-VMHost -Name $_ }
        }
    }
    process {
        Foreach (${00100000000101001} in ($VMHost|Get-View)) {
            ${00101100100010000} = New-Object VMware.Vim.HostConnectSpec
            ${00101100100010000}.HostName = ${00100000000101001}.Summary.Config.Name
            ${00101100100010000}.Port = ${00100000000101001}.Summary.Config.Port
            ${00101100100010000}.Force = $true
            if ($pscmdlet.ShouldProcess(${00100000000101001}.name)) {
                ${00100000000101001}.ReconnectHost_Task(${00101100100010000})
            }
        }
    }
}
