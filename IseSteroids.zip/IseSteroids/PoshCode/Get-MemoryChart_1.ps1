﻿#.Synopsis
#  Draw pie charts of server memory usage by process
#.Description
#  Uses PowerBoots to draw a pipe-chart of each computer's memory use. While you wait for that information 
#  to be gathered, it shows you the latest xkcd comic.   ##DEPEND-ON -Function Get-Comic http://poshcode.org/1003
#  Uses the Transitionals library for nice transitions   ##DEPEND-ON -Assembly Transitionals http://www.codeplex.com/transitionals
#  Uses the Visifire libraries for the charts, of course ##DEPEND-ON -Assembly Transitionals http://visifire.com
#  Whoops, it's also dependent on Set-AttachedProperty   ##DEPEND-ON -Function Set-AttachedProperty http://poshcode.org/1017
#  which for some reason isn't in PowerBoots yet!
#  
#.Parameter hosts
#  The hostnames of the computers you want memory charts for
#.Example
#  Get-MemoryChart localhost
#
#  Returns a pie-chart of the memory on your local PC
#.Example
#  Get-MemoryChart Server01,Server02
#
#  Returns a pie-chart of the memory on Server01, and Server02
#  Note that this requires WMI and authorization...
#
Param([string[]]$hosts = "localhost")
ipmo PowerBoots
if(!(gcm Chart -EA SilentlyContinue)) {
   Add-BootsContentProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBQAG8AaQBuAHQAcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAaQBlAHMA')))
   Add-BootsFunction -Assembly $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fgBcAFwARABvAGMAdQBtAGUAbgB0AHMAXABcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAHMAaABlAGwAbABcAFwATABpAGIAcgBhAHIAaQBlAHMAXABcAFcAUABGAFYAaQBzAGkAZgBpAHIAZQAuAEMAaABhAHIAdABzAC4AZABsAGwA'))) 2>$Null
   Add-BootsFunction -Assembly $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('fgBcAFwARABvAGMAdQBtAGUAbgB0AHMAXABcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAHMAaABlAGwAbABcAFwATABpAGIAcgBhAHIAaQBlAHMAXABcAFQAcgBhAG4AcwBpAHQAaQBvAG4AYQBsAHMALgBkAGwAbAA=')))
}
## And this is how you use a script which might not be there...
${10111010000001010} = gcm Get-Comic -EA SilentlyContinue
if(${10111010000001010}) {
   ${script:10001000000010101} = Get-Comic xkcd
   ${01011111101110111} = [system.drawing.image]::fromfile( ${10001000000010101}.FullName )
   ${script:00110000010001101} = ${01011111101110111}.Width
   ${01011111101110111}.Dispose()
}
#$window = Boots { Image -Source $xkcd -MinHeight 100 } -Popup -Async
${10001001001000001} = 10mb
${01100111001111101} = 15mb
${00011011001011110} = Boots { 
   DockPanel {
      # ListBox -DisplayMember Name -Ov global:list  `  # -width 0 
      #        -On_SelectionChanged { $global:container[0].Content = $global:list[0].SelectedItem } 
      # TransitionElement -Transition $(RotateTransition -Angle 45) `
      Frame `
                        -Name TransitionBox -Ov global:container   `
                        -MinWidth 400 -MinHeight 400 -MaxHeight 600 `
                        -Content {
                           StackPanel {
                              Label -FontSize 42 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAC4ALgAuAA==')))
                              if(${10111010000001010}) {
                                 Image -Source ${10001000000010101}.FullName -MaxWidth ${00110000010001101}
                              }
                           } | 
         Set-AttachedProperty ([System.Windows.Navigation.JournalEntry]::NameProperty) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WABLAEMARAAgAEMAbwBtAGkAYwA=')))
      }
   } -LastChildFill $true  
} -MinHeight 400 -Async -Popup -Passthru
sleep 2;
${10101110101111010} = @()
ForEach(${01011101011100011} in $hosts) {
   ${10101110101111010} += gwmi Win32_Process -ComputerName ${01011101011100011} -AsJob;
}
while(${10101110101111010}) {
   ${01101011011000111} = wjb -Any ${10101110101111010} 
   Invoke-BootsWindow ${00011011001011110} {
      # if($list -is [System.Collections.ArrayList]) {
      #    $list = $list[0];
      #    $list.Padding = "2,2,5,2"
      # }
      ${00110111100111001} = $(${01101011011000111}.Location -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBeAGEALQB6AEEALQBaAF8AMAAtADkAXQA='))) -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABeAFsAMAAtADkAXQApAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwAkADEA'))))
      # $null = $list.Items.Add( 
      $global:container[0].Content = `
         $(
            Chart {
               DataSeries -LabelText ${01101011011000111}.Location {
                  ForEach(${10010111110110111} in (rcjb ${01101011011000111} | Sort WorkingSetSize)) {
                     if(${10010111110110111}.WorkingSetSize -gt ${10001001001000001}) {
                        DataPoint -YValue ${10010111110110111}.WorkingSetSize -LabelText ${10010111110110111}.Name `
                                  -LabelEnabled $(${10010111110110111}.WorkingSetSize -gt ${01100111001111101}) `
                                  -ToolTipText "$(${10010111110110111}.Name): #YValue (#Percentage%)"
                     }
                  }
               } -RenderAs Pie -ShowInLegend $false
            } -Watermark $false -AnimationEnabled $true -Name ${00110111100111001} | 
            Set-AttachedProperty ([System.Windows.Navigation.JournalEntry]::NameProperty) ${00110111100111001}
         )
      # $list.SelectedIndex = $list.Items.Count - 1
   }
   ${10101110101111010} = ${10101110101111010} -ne ${01101011011000111}
   rjb ${01101011011000111}.Id
   Sleep 5
}
