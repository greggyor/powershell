﻿

















param( 
   $Server = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBRAEwAIABTAGUAcgB2AGUAcgAgAE4AYQBtAGUA')))), 
   $Database = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAAgAEQAYQB0AGEAYgBhAHMAZQA=')))),  
   $UserName, $Password, $Query )







function global:Set-SqlConnection( $Server = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBRAEwAIABTAGUAcgB2AGUAcgAgAE4AYQBtAGUA')))), $Database = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAAgAEQAYQB0AGEAYgBhAHMAZQA=')))),  $UserName , $Password  ) {

  if( ($UserName -gt $null) -and ($Password -gt $null)) {
    ${5} = "User Id = $UserName; Password = $Password"
  } else {
    ${5} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQBnAHIAYQB0AGUAZAAgAFMAZQBjAHUAcgBpAHQAeQAgAD0AIABUAHIAdQBlAA==')))
  }
  $SqlConnection.ConnectionString = "Server = $Server; Database = $Database; ${5}"
}




function global:Get-SqlDataTable( $Query = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAUwBRAEwAIABRAHUAZQByAHkA'))))) {
  if (-not ($SqlConnection.State -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgA='))))) { $SqlConnection.Open() }
  ${2} = New-Object System.Data.SqlClient.SqlCommand $Query, $SqlConnection

  ${4} = New-Object System.Data.SqlClient.SqlDataAdapter
  ${4}.SelectCommand = ${2}

  ${3} = New-Object System.Data.DataSet
  ${4}.Fill(${3}) | Out-Null

  $SqlConnection.Close()
  
  return ${3}.Tables[0]
}





function global:Get-SQLQuery($Query = $(Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAUwBRAEwAIABRAHUAZQByAHkA')))), $type = "string")
{
  if (-not ($SqlConnection.State -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgA='))))) { $SqlConnection.Open() }
  ${2} = New-Object System.Data.SqlClient.SqlCommand $Query, $SqlConnection

  

  
  
    
    
  
  
  ${1} = ${2}.ExecuteReader()
  while(${1}.Read())
  {
    
    ${1}.GetValue(0) -as $type 
  }
  ${1}.Close()
  ${1}.Dispose()

  
}


sv SqlConnection (New-Object System.Data.SqlClient.SqlConnection) -Scope Global -Option AllScope -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAcwBvAG4AYQBsACAAdgBhAHIAaQBhAGIAbABlACAAZgBvAHIAIABTAHEAbAAgAFEAdQBlAHIAeQAgAGYAdQBuAGMAdABpAG8AbgBzAA==')))


Set-SqlConnection $Server $Database


if( $query -gt $null ) {
  Get-SqlDataTable $Query
}


sal gdt Get-SqlDataTable  -Option AllScope -scope Global -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAcwBvAG4AYQBsACAARgB1AG4AYwB0AGkAbwBuACAAYQBsAGkAYQBzACAAZgByAG8AbQAgAEcAZQB0AC0AUwBxAGwALgBwAHMAMQA=')))
sal sql Set-SqlConnection -Option AllScope -scope Global -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAcwBvAG4AYQBsACAARgB1AG4AYwB0AGkAbwBuACAAYQBsAGkAYQBzACAAZgByAG8AbQAgAEcAZQB0AC0AUwBxAGwALgBwAHMAMQA=')))
sal gq  Get-SqlQuery      -Option AllScope -scope Global -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAcwBvAG4AYQBsACAARgB1AG4AYwB0AGkAbwBuACAAYQBsAGkAYQBzACAAZgByAG8AbQAgAEcAZQB0AC0AUwBxAGwALgBwAHMAMQA=')))


