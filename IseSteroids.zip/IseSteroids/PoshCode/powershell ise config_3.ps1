﻿<configuration>
   <startup useLegacyV2RuntimeActivationPolicy="true">
      <supportedRuntime version="v4.0" />
   </startup>
   <runtime>
      <loadFromRemoteSources enabled="true"/>
   </runtime>
</configuration>
