﻿function Get-BogonList {

	
	[CmdletBinding()]
	param (
		[switch]$Aggregated
	)
	
	
	$webClient = New-Object System.Net.WebClient
	
	
	$version = $webClient.DownloadString('http://www.team-cymru.org/Services/Bogons/') -split "`n" |
		? {$_ -match 'Bogons Last Updated:' -or $_ -match 'Current version:'} |
		% {$_.ToString().Replace('<strong>',"").Replace('</strong><br />',"").Trim()}
	
	
	Write-Host "Team Cymru Bogon List" ; $version
	
	
	if ($Aggregated) {
		foreach ($bogon in $webClient.DownloadString('http://www.team-cymru.org/Services/Bogons/bogon-bn-agg.txt') -split "`n") {
			New-Object PSObject -Property @{'Aggregated Bogons' = $bogon}
		}

	
	} else {
		foreach ($bogon in $webClient.DownloadString('http://www.team-cymru.org/Services/Bogons/bogon-bn-nonagg.txt') -split "`n") {
			New-Object PSObject -Property @{'Unaggregated Bogons' = $bogon}
		}
	}
}
