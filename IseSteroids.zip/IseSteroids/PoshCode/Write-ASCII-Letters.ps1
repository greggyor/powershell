﻿







































param(
    [string[]] $InputText,
    [switch] $NoPrependChar,
    [string] $TextColor = 'Default'
    
    )

Set-StrictMode -Version Latest
$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA=')))


Function Parse-LetterXML {
    
    $LetterFile = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFwAbABlAHQAdABlAHIAcwAuAHgAbQBsAA==')))
    $Xml = [xml] (gc $LetterFile)
    
    $Xml.Letters.Letter | % {
        
        $Letters.($_.Name) = New-Object PSObject -Property @{
            
            'Lines' = $_.Lines
            'ASCII' = $_.Data
            'Width' = $_.Width
        }
        
    }
    
}


function Create-ASCII-Text {
    
    param([string] $Text)
    
    $LetterArray = [char[]] $Text.ToLower()
    
    
    
    
    $MaxLines = 0
    $LetterArray | % { if ($Letters.([string] $_).Lines -gt $MaxLines ) { $MaxLines = $Letters.([string] $_).Lines } }
    
    $LetterWidthArray = $LetterArray | % { $Letter = [string] $_; $Letters.$Letter.Width }
    $LetterLinesArray = $LetterArray | % { $Letter = [string] $_; $Letters.$Letter.Lines }
    
    
    
    $Lines = @{
        '1' = ''
        '2' = ''
        '3' = ''
        '4' = ''
        '5' = ''
        '6' = ''
    }
    
    
        
    $LetterPos = 0
    foreach ($Letter in $LetterArray) {
        
        
        $Letter = [string] $Letter
        
        
        
        
        if ($LetterLinesArray[$LetterPos] -eq 6) {
            
            foreach ($Num in 1..6) {
                
                $StringNum = [string] $Num
                
                $LineFragment = [string](($Letters.$Letter.ASCII).Split("`n"))[$Num-1]
                
                if ($LineFragment.Length -lt $Letters.$Letter.Width) {
                    $LineFragment += ' ' * ($Letters.$Letter.Width - $LineFragment.Length)
                }
                
                $Lines.$StringNum += $LineFragment
                
            }
            
        }
        
        
        elseif ($LetterLinesArray[$LetterPos] -eq 5) {
            
            $Padding = ' ' * $LetterWidthArray[$LetterPos]
            $Lines.'1' += $Padding
            
            foreach ($Num in 2..6) {
                
                $StringNum = [string] $Num
                
                $LineFragment = [string](($Letters.$Letter.ASCII).Split("`n"))[$Num-2]
                
                if ($LineFragment.Length -lt $Letters.$Letter.Width) {
                    $LineFragment += ' ' * ($Letters.$Letter.Width - $LineFragment.Length)
                }
                    
                $Lines.$StringNum += $LineFragment
                
            }
        
            
        }
        
        
        
        
        else {
            
            
            $StartRange, $EndRange, $IndexSubtract = 3, 6, 3
            $Padding = ' ' * $LetterWidthArray[$LetterPos]
            
            
            if ($MaxLines -lt 6) {
                
                $Lines.'2' += $Padding
                
            }
           
            
            else {
                
                $Lines.'1' += $Padding
                $Lines.'6' += $Padding
                $StartRange, $EndRange, $IndexSubtract = 2, 5, 2
                
            }
            
            
            foreach ($Num in $StartRange..$EndRange) {
                
                $StringNum = [string] $Num
                
                $LineFragment = [string](($Letters.$Letter.ASCII).Split("`n"))[$Num-$IndexSubtract]
               
                if ($LineFragment.Length -lt $Letters.$Letter.Width) {
                    $LineFragment += ' ' * ($Letters.$Letter.Width - $LineFragment.Length)
                }
                
                $Lines.$StringNum += $LineFragment
                
            }
                
        }
                    
        $LetterPos++
        
    } 
    
    
    $Lines.GetEnumerator() | Sort Name | Select -ExpandProperty Value | ?{ $_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAFMA'))) } | %{ if ($NoPrependChar) { $_ } else { "'" + $_ } }
    
}


$Letters = @{}
Parse-LetterXML


$Text = ''
$InputText | % { $Text += "$_ " }


$MaxChars = 30
if ($Text.Length -gt $MaxChars) { "Too long text. There's a maximum of $MaxChars characters."; exit }


$Text = $Text -replace ' ', '_'


$AcceptedChars = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBeAGEALQB6ADAALQA5ACAAXwAsACEAPwAuAC8AOwA6ADwAPgAoACkAewB9AFwAXABbAFwAXABdACcAXABcAC0AXABcAFwAXAAiAOYA+ADlAF0A'))) 
if ($Text -match $AcceptedChars) { "Unsupported character, using this 'accepted chars' regex: $AcceptedChars."; exit }




$Lines = @()
$ASCII = Create-ASCII-Text $Text

if ($TextColor -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA=')))) { Write-Host -ForegroundColor $TextColor ($ASCII -join "`n") }
else { $ASCII }
