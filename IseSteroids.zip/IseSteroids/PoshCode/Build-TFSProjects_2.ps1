﻿




Param(
    [switch]
    $CSRWEB,
    [switch]
    $CSRWS,
    [switch]
    $CSRServices,
    [string]
    $LogPath,
    [String]
    $Outdir = "C:\\Application\\CSR"
)
Begin 
{

    ${_/\_/=\/==\_/\_/=}=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABXAEkATgBEAE8AVwBTAFwAXABNAGkAYwByAG8AcwBvAGYAdAAuAE4ARQBUAFwAXABGAHIAYQBtAGUAdwBvAHIAawBcAFwAdgAzAC4ANQBcAFwATQBzAEIAdQBpAGwAZAA=')))
    ${/==\/\/\/\/\/\/=\}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAFUAVABEAEkAUgBcAFwAQwBTAFIAVwBlAGIA')))
    ${script:_/==\/=\/\_/\/=\_}=@()
    
    
    Function SetTFS
    {
        ${SCRIPT:_/===\/\___/==\__} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA3ADIALgAyADkALgA0AC4AMQA3ADkA')))
        ${script:__/\/\/\/\/\_/\__} = [system.environment]::UserName; 
        ${script:__/==\/\/\/\/====} = [system.environment]::machinename
        ${script:/=\_/==\___/\/=\_} = ${__/==\/\/\/\/====} + "_" + ${__/\/\/\/\/\_/\__} +$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBXAFMA')))   
        ${script:___/\__/\/\___/=\} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXABCAHIAYQBzAHMAcgBpAG4AZwAyAFwAXABBAHAAcABsAGkAYwBhAHQAaQBvAG4AXABcAA=='))); 
        ${script:/==\/\/\/\/\/\/=\}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAVwBlAGIA')))
        ${script:__/=\/==\_/\__/\/}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAVwBTAA==')))
        ${script:/===\/\_/====\/==}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAUwBlAHIAdgBpAGMAZQBzAA==')))
        ${script:_/==\_/\/=\_/\_/\}=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGYAZQByAGUAbgBjAGUAVABvAEEAbABsAEEAcwBzAGUAbQBiAGkAZQBzAFUAcwBlAGQASQBuAFQAaABlAFAAcgBvAGoAZQBjAHQAUwBlAHAAZQByAGEAdABlAGQAYgB5AFMAZQBtAGkAQwBvAGwAbwBuAA==')))
        ${script:_/\_/=\/==\_/\_/=}=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAXABXAEkATgBEAE8AVwBTAFwAXABNAGkAYwByAG8AcwBvAGYAdAAuAE4ARQBUAFwAXABGAHIAYQBtAGUAdwBvAHIAawBcAFwAdgAzAC4ANQBcAFwATQBzAEIAdQBpAGwAZAA=')))
        ${script:_____/\_/\____/==} = $false

        


        
        ${/====\/====\____/} = Get-ItemProperty HKLM:\\SOFTWARE\\Microsoft\\VisualStudio\\9.0
        ${___/\/=\_____/\__} = [string] (Get-ItemProperty ${/====\/====\____/}.InstallDir)
        ${script:/==\/=\/==\/=\__/} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwBfAC8AXAAvAD0AXABfAF8AXwBfAF8ALwBcAF8AXwB9AFwAXAB0AGYALgBlAHgAZQA=')))
    } 

    
    Function CreateWorkspace
    {
        Begin 
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAQwByAGUAYQB0AGUAVwBvAHIAawBzAHAAYQBjAGUA')))
            
            Function DeleteWorkspace
            {
                
                Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGkAbgBnACAAdwBvAHIAawBzAHAAYQBjAGUAIAAoAGkAZgAgAGUAeABpAHMAdABzACkAOgAgACQAewAvAD0AXABfAC8APQA9AFwAXwBfAF8ALwBcAC8APQBcAF8AfQA='))) 
                ${_/==\/=\/\_/\/=\_} +=  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGkAbgBnACAAdwBvAHIAawBzAHAAYQBjAGUAIAAoAGkAZgAgAGUAeABpAHMAdABzACkAOgAgACQAewAvAD0AXABfAC8APQA9AFwAXwBfAF8ALwBcAC8APQBcAF8AfQA='))) 
                
                &${/==\/=\/==\/=\__/} workspace /delete  ${/=\_/==\___/\/=\_}  /noprompt | out-null

                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAGQAZQBsAGUAdABpAG4AZwAgAHcAbwByAGsAcwBwAGEAYwBlAC4A')))
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAGQAZQBsAGUAdABpAG4AZwAgAHcAbwByAGsAcwBwAGEAYwBlAC4A')))
            } 
        }
        Process 
        {
            DeleteWorkspace
        
            
            if (! (Test-Path ${___/\__/\/\___/=\})) 
            {
                Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAZgBvAGwAZABlAHIAOgAgACQAewBfAF8AXwAvAFwAXwBfAC8AXAAvAFwAXwBfAF8ALwA9AFwAfQA=')))
                ${_/==\/=\/\_/\/=\_} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAZgBvAGwAZABlAHIAOgAgACQAewBfAF8AXwAvAFwAXwBfAC8AXAAvAFwAXwBfAF8ALwA9AFwAfQA=')))
                new-item -itemtype directory -path ${___/\__/\/\___/=\} -force | out-null
                Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAGQAIABDAHIAZQBhAHQAaQBuAGcAIABmAG8AbABkAGUAcgA6ACAAJAB7AF8AXwBfAC8AXABfAF8ALwBcAC8AXABfAF8AXwAvAD0AXAB9AA=='))) 
                ${_/==\/=\/\_/\/=\_} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAGQAIABDAHIAZQBhAHQAaQBuAGcAIABmAG8AbABkAGUAcgA6ACAAJAB7AF8AXwBfAC8AXABfAF8ALwBcAC8AXABfAF8AXwAvAD0AXAB9AA=='))) 
            }
            
            cd ${___/\__/\/\___/=\}

            
            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAdwBvAHIAawBzAHAAYQBjAGUAOgAgACQAewAvAD0AXABfAC8APQA9AFwAXwBfAF8ALwBcAC8APQBcAF8AfQA=')))
            ${_/==\/=\/\_/\/=\_} +=  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAdwBvAHIAawBzAHAAYQBjAGUAOgAgACQAewAvAD0AXABfAC8APQA9AFwAXwBfAF8ALwBcAC8APQBcAF8AfQA=')))

            &${/==\/=\/==\/=\__/} workspace /new /computer:${__/==\/\/\/\/====} /server:${_/===\/\___/==\__} /noprompt ${/=\_/==\___/\/=\_}

            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAEMAcgBlAGEAdABpAG4AZwAgAHcAbwByAGsAcwBwAGEAYwBlADoAIAAkAHsALwA9AFwAXwAvAD0APQBcAF8AXwBfAC8AXAAvAD0AXABfAH0A'))) 
            ${_/==\/=\/\_/\/=\_} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAEMAcgBlAGEAdABpAG4AZwAgAHcAbwByAGsAcwBwAGEAYwBlADoAIAAkAHsALwA9AFwAXwAvAD0APQBcAF8AXwBfAC8AXAAvAD0AXABfAH0A'))) 

            
            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAHQAaABlACAAbABhAHQAZQBzAHQAIABjAG8AZABlACAAZgByAG8AbQA6ACAAJAB7AF8ALwA9AD0APQBcAC8AXABfAF8AXwAvAD0APQBcAF8AXwB9AC4AIABUAGgAaQBzACAAYwBvAHUAbABkACAAdABhAGsAZQAgAGEAdwBoAGkAbABlAC4ALgAuAA==')))
            ${_/==\/=\/\_/\/=\_} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAHQAaABlACAAbABhAHQAZQBzAHQAIABjAG8AZABlACAAZgByAG8AbQA6ACAAJAB7AF8ALwA9AD0APQBcAC8AXABfAF8AXwAvAD0APQBcAF8AXwB9AC4AIABUAGgAaQBzACAAYwBvAHUAbABkACAAdABhAGsAZQAgAGEAdwBoAGkAbABlAC4ALgAuAA==')))
            &${/==\/=\/==\/=\__/} get $/CSR/CSR /recursive

            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAGcAZQB0AHQAaQBuAGcAIABsAGEAdABlAHMAdAAuAA==')))
            ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAgAGcAZQB0AHQAaQBuAGcAIABsAGEAdABlAHMAdAAuAA==')))

            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGUAZQAgAGkAbgBpAHQAaQBhAGwAaQB6AGEAdABpAG8AbgAgAGkAcwAgAGMAbwBtAHAAbABlAHQAZQAuAA==')))
            ${_/==\/=\/\_/\/=\_} +=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGUAZQAgAGkAbgBpAHQAaQBhAGwAaQB6AGEAdABpAG8AbgAgAGkAcwAgAGMAbwBtAHAAbABlAHQAZQAuAA==')))
        }
        End 
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAVwBvAHIAawBzAHAAYQBjAGUAIABDAG8AbQBwAGwAZQB0AGUA')))
        } 
    } 
   
   
    
    
    
    
    
    
    
    Function GetNextLabel()
    {
        Begin 
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAARwBlAHQATgBlAHgAdABMAGEAYgBlAGwA')))
        }
        Process
        {
            ${__/=\/\/\_/\/=\/\} = 1
            ${/==\/====\/====\_} = 1
           
            ${/=\_/\_/\__/====\} = (&${/==\/=\/==\/=\__/} labels /format:brief |? { $_ -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAuACsA'))) -and $_ -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABhAGIAZQBsAC4AKwBPAHcAbgBlAHIALgArAEQAYQB0AGUA')))})
            
            if (${/=\_/\_/\__/====\} -ne $null) {
               
                
                ${__/=\/\/\_/\/=\/\},[int]${/==\/====\/====\_}= ((${/=\_/\_/\__/====\} | Select-Object -last 1).split()).split(".")
            
                
                ${/==\/====\/====\_}++
                
                
                [int]${__/=\/\/\_/\/=\/\} = ${__/=\/\/\_/\/=\/\}.substring(2)
                
                
                if (${/==\/====\/====\_} -gt 999) {
                    ${__/=\/\/\_/\/=\/\}++
                    ${/==\/====\/====\_} = 1
                }
            }
            
            
            ${_/==\__/==\___/\/} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBMAHsAMAB9AC4AewAxADoAMAAwADAAfQA='))) -f ${__/=\/\/\_/\/=\/\}, ${/==\/====\/====\_}
            
            write-output ${_/==\__/==\___/\/}
        }
        End
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQATgBlAHgAdABMAGEAYgBlAGwAIABDAG8AbQBwAGwAZQB0AGUAZAA=')))
        }
    }
    
    
    Function MSBuild($outputdir, $webproject, $project, $ref)
    {
        Begin 
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAATQBTAEIAdQBpAGwAZAA=')))
            Write-Debug $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwB1AHQAcAB1AHQAZABpAHIAOgAgACQAbwB1AHQAcAB1AHQAZABpAHIAIAB3AGUAYgBwAHIAbwBqAGUAYwB0ADoAIAAkAHcAZQBiAHAAcgBvAGoAZQBjAHQAIABwAHIAbwBqAGUAYwB0ADoAIAAkAHAAcgBvAGoAZQBjAHQAIAByAGUAZgA6ACAAJAByAGUAZgA=')))
        }
        Process
        {
            
            ${_____/\_/\____/==} = $false
            &${_/\_/=\/==\_/\_/=} /p:Configuration=Release  /p:OutDir=$Outputdir /p:WebProjectOutputDir=$webproject $project |% {
                    if ($_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAARgBBAEkATABFAEQA')))) { ${_____/\_/\____/==} = $true } ; $_ 
                }
            if (${_____/\_/\____/==}) { throw (new-object NullReferenceException) }    
            
            ${_____/\_/\____/==} = $false
            &${_/\_/=\/==\_/\_/=} /p:Configuration=Release /t:ResolveReferences /p:OutDir=$Outputdir\\bin\\ /p:ReferencePath=$ref $project  |% {
                    if ($_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAARgBBAEkATABFAEQA')))) { ${_____/\_/\____/==} = $true } ; $_ 
                }
            if (${_____/\_/\____/==}) { throw (new-object NullReferenceException) }    
        }
        End
        {
            Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBTAEIAdQBpAGwAZAAgAEMAbwBtAHAAbABlAHQAZQBkAA==')))
        }
    }

    
    
    
    Function ApplyLabel()
    {
        Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIAB0AGgAZQAgAEwAYQBiAGUAbAA='))) 
        ${_/==\/=\/\_/\/=\_} +=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIAB0AGgAZQAgAEwAYQBiAGUAbAA='))) 

        ${_/==\__/==\___/\/} = GetNextLabel
            
        &${/==\/=\/==\/=\__/} label  ${_/==\__/==\___/\/}  $/CSR/CSR /recursive

        &${/==\/=\/==\/=\__/} get /version:L$(${_/==\__/==\___/\/})

        Write-verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGUAZAAgAGwAYQBiAGUAbAAgACQAewBfAC8APQA9AFwAXwBfAC8APQA9AFwAXwBfAF8ALwBcAC8AfQA='))) 
        ${_/==\/=\/\_/\/=\_} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGUAZAAgAGwAYQBiAGUAbAAgACQAewBfAC8APQA9AFwAXwBfAC8APQA9AFwAXwBfAF8ALwBcAC8AfQA='))) 

        return ${_/==\__/==\___/\/}    
    } 
} 
Process 
{
    trap [Exception] 
    {
        write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAARgBhAGkAbABlAGQA'))) 
        ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAARgBhAGkAbABlAGQA'))) 
        exit 1;
    }
    . SetTFS
    . CreateWorkspace
    . ApplyLabel
    
    IF (!$CSRWS -AND !$CSRWEB -AND !$CSRServices)
    {
        Write-Debug $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAATwBwAHQAaQBvAG4AcwAgAEYAbwB1AG4AZAAgAFMAZQB0AHQAaQBuAGcAIABBAEwATAA=')))
        $CSRWS = $TRUE
        $CSRWEB = $TRUE
        $CSRServices = $TRUE
    }
    
    Switch ("") 
    {
        {$CSRWEB}
            {
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAVwBFAEIA'))) 
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAVwBFAEIA'))) 
                
                . MsBuild $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAVwBlAGIAXABcAA=='))) ${/==\/\/\/\/\/\/=\} $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwBfAC8AXABfAF8ALwBcAC8AXABfAF8AXwAvAD0AXAB9AFwAXABDAFMAUgBcAFwAQwBTAFIAXABcAEMAUwBSAFcAZQBiAFwAXABDAFMAUgBXAGUAYgBcAFwAQwBTAFIAVwBlAGIALgBjAHMAcAByAG8AagA='))) ${_/==\_/\/=\_/\_/\}
                
                
                
                

                rm  $Outdir\\CSRWeb\\*.config -recurse
                rm  $Outdir\\CSRWeb\\*.pdb -recurse
                rm  $Outdir\\CSRWeb\\*.dll -recurse
                rm  $Outdir\\CSRWeb\\*.xml -recurse
                rm  $Outdir\\CSRWeb\\bin\\*.pdb -recurse
                rm  $Outdir\\CSRWeb\\bin\\*.config -recurse
                rm  $Outdir\\CSRWeb\\bin\\*.xml -recurse
                
                Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAVwBFAEIAIABTAHUAYwBjAGUAcwBzAGYAdQBsAA==')))  
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAVwBFAEIAIABTAHUAYwBjAGUAcwBzAGYAdQBsAA==')))  
            }
        {$CSRWS}
            {
                Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAVwBTAA=='))) 
                ${_/==\/=\/\_/\/=\_} +=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAVwBTAA=='))) 
        
                . MsBuild $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAVwBTAFwAXAA='))) ${__/=\/==\_/\__/\/} $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwBfAC8AXABfAF8ALwBcAC8AXABfAF8AXwAvAD0AXAB9AFwAXABDAFMAUgBcAFwAQwBTAFIAXABcAEMAUwBSAFcAUwBcAFwAQwBTAFIAVwBTAFwAXABDAFMAUgBXAFMALgBjAHMAcAByAG8AagA='))) ${_/==\_/\/=\_/\_/\}
                
                
                
                

                rm  $Outdir\\CSRWS\\*.config -recurse
                rm  $Outdir\\CSRWS\\*.pdb -recurse
                rm  $Outdir\\CSRWS\\*.dll -recurse
                rm  $Outdir\\CSRWS\\*.xml -recurse
                rm  $Outdir\\CSRWS\\bin\\*.pdb -recurse
                rm  $Outdir\\CSRWS\\bin\\*.config -recurse
                rm  $Outdir\\CSRWS\\bin\\*.xml -recurse
               
                Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAVwBTACAAUwB1AGMAYwBlAHMAcwBmAHUAbAA='))) 
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAVwBTACAAUwB1AGMAYwBlAHMAcwBmAHUAbAA='))) 
            }
        {$CSRServices}
            {
                Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAIABTAGUAcgB2AGkAYwBlAHMA')))
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkAGkAbgBnACAAQwBTAFIAIABTAGUAcgB2AGkAYwBlAHMA')))
            
                . MsBuild $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABPAHUAdABkAGkAcgBcAFwAQwBTAFIAUwBFAFIAVgBJAEMARQBTAFwAXAA='))) ${/===\/\_/====\/==} $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwBfAC8AXABfAF8ALwBcAC8AXABfAF8AXwAvAD0AXAB9AFwAXABDAFMAUgBcAFwAQwBTAFIAXABcAEMAUwBSAFMARQBSAFYASQBDAEUAUwBcAFwAQwBTAFIAUwBFAFIAVgBJAEMARQBTAFwAXABDAFMAUgBTAEUAUgBWAEkAQwBFAFMALgBjAHMAcAByAG8AagA='))) ${_/==\_/\/=\_/\_/\}
                
                
                
                

                rm  $Outdir\\CSRSERVICES\\*.config -recurse
                rm  $Outdir\\CSRSERVICES\\*.pdb -recurse
                rm  $Outdir\\CSRSERVICES\\*.dll -recurse
                rm  $Outdir\\CSRSERVICES\\*.xml -recurse
                rm  $Outdir\\CSRSERVICES\\bin\\*.pdb -recurse
                rm  $Outdir\\CSRSERVICES\\bin\\*.config -recurse
                rm  $Outdir\\CSRSERVICES\\bin\\*.xml -recurse
                
                Write-verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAIABTAGUAcgB2AGkAYwBlAHMAIABTAHUAYwBjAGUAcwBzAGYAdQBsAA==')))
                ${_/==\/=\/\_/\/=\_} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB1AGkAbABkACAAQwBTAFIAIABTAGUAcgB2AGkAYwBlAHMAIABTAHUAYwBjAGUAcwBzAGYAdQBsAA==')))
            }
    } 
} 
End 
{
    IF ($LogPath) 
    {
        ${_/==\/=\/\_/\/=\_} | Out-file -FilePath $LogPath -Encoding ascii -Append
    }
} 
