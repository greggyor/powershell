﻿param ([String] $ScreenName)
${__/===\_/===\_/==} = New-Object System.Net.WebClient
${____/\/===\__/\__} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvAGEAcABpAC4AdAB3AGkAdAB0AGUAcgAuAGMAbwBtAC8AMQAvAHUAcwBlAHIAcwAvAHMAaABvAHcALgBqAHMAbwBuAD8AcwBjAHIAZQBlAG4AXwBuAGEAbQBlAD0AJABTAGMAcgBlAGUAbgBOAGEAbQBlAA==')))
${_/====\/=\_/=\/\/} = ${__/===\_/===\_/==}.DownloadString(${____/\/===\__/\__})
${__/\/\/\/\/\_/=\_} = 0
${____/==\/=\/\/=\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IgBpAGQAIgA6AA==')))
do {
    ${__/\/\/\/\/\_/=\_} = ${_/====\/=\_/=\/\/}.IndexOf(${____/==\/=\/\/=\_}, ${__/\/\/\/\/\_/=\_} + 1)
    if (${__/\/\/\/\/\_/=\_} -gt 0) {
        ${__/\/\/\/\/\_/=\_} += ${____/==\/=\/\/=\_}.Length
        ${___/\/\/=\____/==} = ${_/====\/=\_/=\/\/}.IndexOf(',', ${__/\/\/\/\/\_/=\_})
        ${_/=\__/=\_/\_/\__} = ${_/====\/=\_/=\/\/}.SubString(${__/\/\/\/\/\_/=\_}, ${___/\/\/=\____/==}-${__/\/\/\/\/\_/=\_})
    }
} while (${__/\/\/\/\/\_/=\_} -le ${_/====\/=\_/=\/\/}.Length -and ${__/\/\/\/\/\_/=\_} -gt 0)
${/=\/=\/\_/\/=\_/=} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB0AHcAaQB0AHQAZQByAC4AYwBvAG0ALwBzAHQAYQB0AHUAcwBlAHMALwB1AHMAZQByAF8AdABpAG0AZQBsAGkAbgBlAC8AJAB7AF8ALwA9AFwAXwBfAC8APQBcAF8ALwBcAF8ALwBcAF8AXwB9AC4AcgBzAHMA')))
${/=\/=\/\_/\/=\_/=}
