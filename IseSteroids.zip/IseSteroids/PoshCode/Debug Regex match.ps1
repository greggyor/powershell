﻿


function Debug-Regex {
   param ([Parameter(mandatory=$true)][regex]$regex,
          [Parameter(mandatory=$true)][string]$string,
          [switch]$first)
   ${1} = $regex.match($string)
   if (!${1}.Success) {
      Write-Host "No Match using Regex '$regex'" -Fore Yellow
      return
   }
   ${2} = 1
   Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBBAFQAQwBIAEUAUwAgACAALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0APAA='))) -Fore Yellow -NoNewLine
   Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBhAHQAYwBoAA==')))                     -Fore White  -NoNewLine
   Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PgAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0A')))     -Fore Yellow
   while (${1}.Success) {
      Write-Host "${2} $(${1}.result($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwAkAGAAPAA=')))))" -Fore Yellow -NoNewLine 
      Write-Host "$(${1}.result('$&'))"          -Fore White  -NoNewLine 
      Write-Host "$(${1}.result($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PgAkACcAXQA=')))))"       -Fore Yellow 
      if ($first) {
         return
      }
      ${2}++
      ${1} = ${1}.NextMatch()
   }
}
