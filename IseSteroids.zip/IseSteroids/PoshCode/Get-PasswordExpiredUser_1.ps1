﻿Param($ou)
if($ou){${01000000111110011} = [ADSI]"LDAP://$ou"}else{${01000000111110011}=[adsi]""}
${00000100001001110} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAAmACgAbwBiAGoAZQBjAHQAQwBhAHQAZQBnAG8AcgB5AD0AdQBzAGUAcgApACgAdQBzAGUAcgBBAGMAYwBvAHUAbgB0AEMAbwBuAHQAcgBvAGwAOgAxAC4AMgAuADgANAAwAC4AMQAxADMANQA1ADYALgAxAC4ANAAuADgAMAAzADoAPQA2ADUANQAzADYAKQApAA==')))
${10010101100111111} = new-object directoryservices.directorysearcher(${01000000111110011},${00000100001001110})
${00011011111110110} = ${10010101100111111}.findall()
${00011011111110110} | format-table @{l=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgA=')));e={$_.properties.item('cn')}},
                      @{l=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBBAE0AQQBjAGMAbwB1AG4AdABOAGEAbQBlAA==')));e={$_.properties.item($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBBAE0AQQBjAGMAbwB1AG4AdABOAGEAbQBlAA=='))))}},
                      @{l=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHQAaAA=')));e={$_.path}}
