﻿function Write-Log {

	
	
		[cmdletbinding()]
		Param(
			[Parameter(ValueFromPipeline=$true,Mandatory=$true)] [ValidateNotNullOrEmpty()]
			[string] $Message,

			[Parameter()] [ValidateSet(“Error”, “Warn”, “Info”)]
			[string] $Level = “Info”,
			
			[Parameter()]
			[Switch] $NoConsoleOut,
			
			[Parameter()]
			[String] $ConsoleForeground = 'White',
			
			[Parameter()] [ValidateRange(1,30)]
			[Int16] $Indent = 0,

			[Parameter()]
			[IO.FileInfo] $Path = ”$env:temp\\PowerShellLog.txt”,
			
			[Parameter()]
			[Switch] $Clobber,
			
			[Parameter()]
			[String] $EventLogName,
			
			[Parameter()]
			[String] $EventSource,
			
			[Parameter()]
			[Int32] $EventID = 1,

			[Parameter()]
			[String] $LogEncoding = "ASCII"
		)
		
	

	Begin {}

	Process {
		try {			
			$msg = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AewAxAH0AIAA6ACAAewAyAH0AIAA6ACAAewAzAH0A'))) -f (" " * $Indent), (Get-Date -Format $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQB5AHkAeQAtAE0ATQAtAGQAZAAgAEgASAA6AG0AbQA6AHMAcwA=')))), $Level.ToUpper(), $Message
			
			if ($NoConsoleOut -eq $false) {
				switch ($Level) {
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))) { Write-Error $Message }
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgA='))) { Write-Warning $Message }
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwA='))) { Write-Host ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AewAxAH0A'))) -f (" " * $Indent), $Message) -ForegroundColor $ConsoleForeground}
				}
			}

			if (-not $Path.Exists) {
				ni -Path $Path.FullName -ItemType File -Force
			}
			
			if ($Clobber) {
				$msg | Out-File -FilePath $Path -Encoding $LogEncoding -Force
			} else {
				$msg | Out-File -FilePath $Path -Encoding $LogEncoding -Append
			}
			
			if ($EventLogName) {
			
				if (-not $EventSource) {
					$EventSource = ([IO.FileInfo] $MyInvocation.ScriptName).Name
				}
			
				if(-not [Diagnostics.EventLog]::SourceExists($EventSource)) { 
					[Diagnostics.EventLog]::CreateEventSource($EventSource, $EventLogName) 
		        } 

				$log = New-Object System.Diagnostics.EventLog  
			    $log.set_log($EventLogName)  
			    $log.set_source($EventSource) 
				
				switch ($Level) {
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))) { $log.WriteEntry($Message, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))), $EventID) }
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgA=')))  { $log.WriteEntry($Message, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwA='))), $EventID) }
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwA=')))  { $log.WriteEntry($Message, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwByAG0AYQB0AGkAbwBuAA=='))), $EventID) }
				}
			}

		} catch {
			throw “Failed to create log entry in: ‘$Path’. The error was: ‘$_’.”
		}
	}

	End {}

	
}
