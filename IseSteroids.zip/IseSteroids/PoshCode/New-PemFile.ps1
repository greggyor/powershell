﻿function New-PemFile {
	[CmdletBinding()]
	param (
		[Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
		[ValidateScript({
			foreach (${1} in $_) {
				if (Test-Path -LiteralPath ${1}) {$true} else {
					throw "The argument '$_' is not a valid file."
				}
			}
		})]
		[Alias('FullName')]
		[string[]]$Path,
		[Parameter(Position=1, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
		[ValidatePattern('\\.pem$')]
		[string]$Target
	)
	begin {
		ni $Target -ItemType File -Force | Out-Null
	}
	process {
		[PSObject[]]${2} += $Path
	}
	end {
		foreach (${1} in ${2}) {
			gc ${1} | Out-File $Target -Encoding ASCII -Append
		}
	}
} 
