﻿<#
Copyright 2014 Michael Herndon

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
#>


# Backtick or How to escape characters in strings. 
# --------------------------------------------------
# linebreak, tab
echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACAAIAAJACAA')))  

# its worth nothing this can often break syntax editors 
# that use regular expressions to parse language grammer. 
echo "`""


# Bound Parameters
# ---------------------------------------------------

# use bound parameter
./script1.ps1 -Debug

# detect and use as boolean flag
$debug = $PSCmdlet.MyInvocation.BoundParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGIAdQBnAA==')))].IsPresent;

if($debug)
{
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGIAdQBnAGcAaQBuACcAIABUAGkAbQBlACEA')))
}


# Quick 'Exists' check for file or folders
# --------------------------------------------

$file = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAbwBwAHQAXABpAG4AZgBvAC4AYwBzAHYA')))

if(! (Test-Path $file))
{
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABmAGkAbABlACAAZABvAGUAcwAgAG4AbwB0ACAAZQB4AGkAcwB0ACAAYQB0ACAAJABwAGEAdABoAC4A')))
}


# Execute a string value as a command or executable
# ----------------------------------------------

$location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAFcAaQBuAGQAbwB3AHMAIABLAGkAdABzAFwAOAAuADEAXABiAGkAbgBcAHgANgA0AA==')))
$makecert = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABsAG8AYwBhAHQAaQBvAG4AXABtAGEAawBlAGMAZQByAHQALgBlAHgAZQA=')));

# special folder 'Desktop' for the current user
$desktop = [Environment]::GetFolderPath($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHMAawB0AG8AcAA='))));
$cert = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABkAGUAcwBrAHQAbwBwAFwAVABlAHMAdAAuAGMAZQByAA==')));

# use the '&' symbol to invoke a string as a command or executable.
&$makecert  -r -pe -n CN=Test -ss my -sr localmachine -eku 1.3.6.1.5.5.7.3.2 -len 2048 -e 01/01/2016 $cert


