﻿${00101001110110000} = New-Object System.Net.Mail.SmtpClient("smtp.geusnet.com", 25) 
${00101001110110000}.Send("aggieben@gmail.com", "bcollins@praecoemailtest.cloudap...", "testing kato", "blah")