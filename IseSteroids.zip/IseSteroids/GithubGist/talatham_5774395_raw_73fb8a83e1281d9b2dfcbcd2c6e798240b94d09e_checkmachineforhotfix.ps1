﻿






Function Get-FileName(${_10001111010011101})
{   
    [void][System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms")

    ${00011101101000100} = New-Object System.Windows.Forms.OpenFileDialog
    ${00011101101000100}.initialDirectory = ${_10001111010011101}
    ${00011101101000100}.filter = "Text Files (*.txt)| *.txt" 
    
    ${00011101101000100}.ShowDialog() | Out-Null
    ${00011101101000100}.filename
}


Function Get-Input
{
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

    ${10011111101001111} = New-Object System.Windows.Forms.Form 
    ${10011111101001111}.Text = "Enter KB Number"
    ${10011111101001111}.Size = New-Object System.Drawing.Size(300,200) 
    ${10011111101001111}.StartPosition = "CenterScreen"

    ${10011111101001111}.KeyPreview = $True
    ${10011111101001111}.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
        {${10111111110111011}=${10100011010000110}.Text;${10011111101001111}.Close()}})
    ${10011111101001111}.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
        {${10011111101001111}.Close()}})

    ${01111110001110101} = New-Object System.Windows.Forms.Button
    ${01111110001110101}.Location = New-Object System.Drawing.Size(75,120)
    ${01111110001110101}.Size = New-Object System.Drawing.Size(75,23)
    ${01111110001110101}.Text = "OK"
    ${01111110001110101}.Add_Click({${10111111110111011}=${10100011010000110}.Text;${10011111101001111}.Close()})
    ${10011111101001111}.Controls.Add(${01111110001110101})

    ${10110111100011011} = New-Object System.Windows.Forms.Button
    ${10110111100011011}.Location = New-Object System.Drawing.Size(150,120)
    ${10110111100011011}.Size = New-Object System.Drawing.Size(75,23)
    ${10110111100011011}.Text = "Cancel"
    ${10110111100011011}.Add_Click({${10011111101001111}.Close()})
    ${10011111101001111}.Controls.Add(${10110111100011011})

    ${10101011101000010} = New-Object System.Windows.Forms.Label
    ${10101011101000010}.Location = New-Object System.Drawing.Size(10,20) 
    ${10101011101000010}.Size = New-Object System.Drawing.Size(280,20) 
    ${10101011101000010}.Text = "Please enter the KB number below (kbxxxxxx):"
    ${10011111101001111}.Controls.Add(${10101011101000010}) 

    ${10100011010000110} = New-Object System.Windows.Forms.TextBox 
    ${10100011010000110}.Location = New-Object System.Drawing.Size(10,40) 
    ${10100011010000110}.Size = New-Object System.Drawing.Size(260,20) 
    ${10011111101001111}.Controls.Add(${10100011010000110}) 

    ${10011111101001111}.Topmost = $True

    ${10011111101001111}.Add_Shown({${10011111101001111}.Activate()})
    [void] ${10011111101001111}.ShowDialog()

    ${10111111110111011}
}




$erroractionpreference = "SilentlyContinue"


clear-host


${00111000010111010} = get-credential




${10110110100000010} = Get-FileName -_10001111010011101 "c:"


${10000101000001010} = split-path ${10110110100000010}


if (test-path ${10000101000001010}\kbresults.txt)
{ remove-item ${10000101000001010}\kbresults.txt }


${01100000101010001} = Get-Input


${00000101011001011} = get-content ${10110110100000010}


foreach (${10101110010000110} in ${00000101011001011})
{
    
    ${00000001010011001} = "select * from win32_pingstatus where address = '" + ${10101110010000110} + "'"
    
    
    ${10010110010110110} = gwmi -query ${00000001010011001}
    
    
    if (${10010110010110110}.statuscode -eq 0)
    {
        
        
        
        ${01111001111011011} = gwmi win32_QuickFixEngineering -computer ${10101110010000110} -credential ${00111000010111010} | where {$_.hotfixid -eq ${01100000101010001}} | select-object hotfixid, description
        
        switch -regex ($Error[ 0 ].Exception)
        {
            "The RPC server is unavailable"
            {
                write-host -f blue ${10101110010000110} "`t" $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBQAEMAIABVAG4AYQB2AGEAaQBsAGEAYgBsAGUAIABvAG4AIAAkAHsAMQAwADEAMAAxADEAMQAwADAAMQAwADAAMAAwADEAMQAwAH0A'))) "`r"
                $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAFIAUABDACAAVQBuAGEAdgBhAGkAbABhAGIAbABlAC4A'))) | out-file ${10000101000001010}\kbresults.txt -append
                continue
            }
            "Access denied"
            {
                write-host -f blue ${10101110010000110} "`t" "Access Denied" "`r"
                $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAEEAYwBjAGUAcwBzACAARABlAG4AaQBlAGQALgA='))) | out-file ${10000101000001010}\kbresults.txt -append
                continue
            }
            "Access is denied"
            {
                write-host -f blue ${10101110010000110} "`t" "Access Denied" "`r"
                $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAEEAYwBjAGUAcwBzACAARABlAG4AaQBlAGQALgA='))) | out-file ${10000101000001010}\kbresults.txt -append
                continue
            }
            
            $null
            {
                
                if (${01111001111011011}.hotfixid -eq ${01100000101010001})
                {
                    
            
                    
                    ${00001111100010000} = [Microsoft.Win32.RegistryHive]"LocalMachine"; 
                    ${00100010110011010} = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(${00001111100010000},${10101110010000110}); 
            
                    
                    ${00101001000110010} = ${00100010110011010}.OpenSubKey("SOFTWARE\Microsoft\Updates\UpdateExeVolatile"); 
                    
                    if (!${00101001000110010}) 
                    {
                        
                        write-host -f green ${10101110010000110} "`t" ${01111001111011011}.description "`r"
                        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAEkAbgBzAHQAYQBsAGwAZQBkAC4A'))) | out-file ${10000101000001010}\kbresults.txt -append
                    }
                    else 
                    {
                        
                        write-host -f green ${10101110010000110} "`t" ${01111001111011011}.description "`r"
                        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAFIAZQBiAG8AbwB0ACAAUgBlAHEAdQBpAHIAZQBkAA=='))) | out-file ${10000101000001010}\kbresults.txt -append
                    }
                }
                else
                {
                    
                    write-host -f red ${10101110010000110} "`t" "Not Found" "`r"
                    $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAE4AbwB0ACAASQBuAHMAdABhAGwAbABlAGQALgA='))) | out-file ${10000101000001010}\kbresults.txt -append
                }            
             }
        }
        
        $Error.clear()
    }
    else 
    { 
        
        write-host ${10101110010000110} "`t" "Cannot ping." "`r"
        $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAAxADAAMQAxADEAMAAwADEAMAAwADAAMAAxADEAMAB9ACAACQAgAFAAaQBuAGcAIABmAGEAaQBsAGUAZAAuAA=='))) | out-file ${10000101000001010}\kbresults.txt -append
    }
}

