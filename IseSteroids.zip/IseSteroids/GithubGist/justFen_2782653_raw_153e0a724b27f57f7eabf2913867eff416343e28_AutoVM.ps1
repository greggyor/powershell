﻿param (
    [string]$vmName = (Read-Host "Provide VM Name"),
    [string]$Template = (Read-Host "What Template do you want Vanilla/Web/Gravis?")
    [string]$Template = (Read-Host "Disk size 40/80?")
)

# Import Configuration
. (Join-Path -Path (Split-Path -parent $MyInvocation.MyCommand.Definition) -ChildPath "configuration.ps1")
# Load VMware Module
if ((Get-PSSnapin | Where-Object { $_.Name -eq "VMware.VimAutomation.Core" }) -eq $null) { Add-PSSnapin VMware.VimAutomation.Core }

# Connect to vCenter
Connect-VMHost

### Variables ###

${/==\/==\/\_/=\__/} = "hihihih.justfen.co.uk"
${__/=\/==\/=\_/=\/} = $vmName.${/==\/==\/\_/=\__/}

# Highest amount of disk space required for VM 
${_/=\__/==\_/\__/\} = 80000


${__/=\/=\__/======} = Get-ResourcePool "TRON"
# Will calculate Datastore with most free space, useful until Storage DRS setup
${/==\_/\_____/==\/} = Get-Datastore | Where { $_.FreespaceMB -gt ${_/=\__/==\_/\__/\} } | Sort-Object FreeSpaceMB -Descending | Select -First 1
if (!${/==\_/\_____/==\/}) { throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAARABhAHQAYQBzAHQAbwByAGUAIABjAG8AdQBsAGQAIABiAGUAIABmAG8AdQBuAGQAIAB3AGkAdABoACAAJAB7AF8ALwA9AFwAXwBfAC8APQA9AFwAXwAvAFwAXwBfAC8AXAB9ACAATQBCACAAZgByAGUAZQAgAHMAcABhAGMAZQAuAA=='))) }
# Will chose ESX host with least CPU utilization, maybe RAM would be a better choice
${/=======\/==\/==\} = Get-VMHost | Sort $_.CPuUsageMhz | Select -First 1

${/==\/\/===\_/\__/} = get-OSCustomizationSpec "Windows"
if (!${/==\/\/===\_/\__/}) { throw "OSCustomizationSpec Windows was not found"}

New-VM -vmhost ${/=======\/==\/==\} `
	-Name $vmName `
	-Template $Template `
	-ResourcePool ${__/=\/=\__/======} `
	-Datastore ${/==\_/\_____/==\/} `
	-OSCustomizationSpec ${/==\/\/===\_/\__/}
	Start-VM -VM $vmName


