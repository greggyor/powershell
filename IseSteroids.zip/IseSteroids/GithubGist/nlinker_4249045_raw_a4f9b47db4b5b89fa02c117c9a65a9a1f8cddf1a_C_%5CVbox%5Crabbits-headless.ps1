﻿




${01001010001011001} = @( 'vagrant-rabbitmq-cluster_1351840619', 'vagrant-rabbitmq-cluster_1351840685', 'vagrant-rabbitmq-cluster_1351840745', 'vagrant-rabbitmq-cluster_1351840804' )

Foreach (${00111010001010001} in ${01001010001011001}) {
	${01000001010001100} = '-s ' + ${00111010001010001}
	start-process 'C:\ProgramsX\Oracle\VirtualBox\VBoxHeadless.exe' ${01000001010001100} -WindowStyle Hidden
}

write-host "All systems go" -foregroundcolor "magenta" -backgroundcolor "blue"


