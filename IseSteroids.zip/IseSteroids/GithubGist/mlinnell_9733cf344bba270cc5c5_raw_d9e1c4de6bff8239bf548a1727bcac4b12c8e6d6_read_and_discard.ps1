﻿$env:_CLUSTER_NETWORK_NAME_ = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBsAHUAcwB0AGUAcgBuAGEAbQBlAA==')))
[Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBNAGUAcwBzAGEAZwBpAG4AZwA='))))
$q = new-object System.Messaging.MessageQueue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAHAAcgBpAHYAYQB0AGUAJABcAHEAdQBlAHUAZQBfAG4AYQBtAGUA'))))
$q.peek()
for($i = 1; $i -le 10000;$i++){ $q.Receive() | out-null}
 



