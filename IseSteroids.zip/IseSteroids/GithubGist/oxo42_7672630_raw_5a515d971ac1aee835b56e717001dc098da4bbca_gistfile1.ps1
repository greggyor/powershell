﻿${___/\/=\_/\/==\__} = @{"640x960" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgA0ADAAeAA5ADYAMAA='))); "640x1136" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgA0ADAAeAAxADEAMwA2AA=='))); "960x544" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA2ADAAeAA1ADQANAA='))); "1024x1024" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADIANAB4ADEAMAAyADQA'))); "2048x2048" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgAwADQAOAB4ADIAMAA0ADgA'))); "1080x1920" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADgAMAB4ADEAOQAyADAA'))); "1920x1080" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADgAMABwAA=='))) }

${/\______/========} = $args[0]
${_/==\____/\__/\/=} = $args[1]
${__/=\/=\____/\/=\_} = $args[2]

${_/\/\_/==\/\_/===} = ${__/=\/=\____/\/=\_} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQA9ACgALgArACkAJAA=')))

if(!${_/\/\_/==\/\_/===})
{
    exit
}

${_____/==\/=\___/\_} = $Matches[1]

Function ____/\_/=\_____/=\([string]${_____/==\/=\___/\_}, [string]${_/==\/\/\_/\_/=\/=}) {
    
    $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAGkAZwBpAHQAYQBsAGIAbABhAHMAcABoAGUAbQB5AC4AYwBvAG0ALwBjAG8AbgB0AGUAbgB0AC8AagBwAGcAcwAvACQAewBfAC8APQA9AFwALwBcAC8AXABfAC8AXABfAC8APQBcAC8APQB9AC8AJAB7AF8AXwBfAF8AXwAvAD0APQBcAC8APQBcAF8AXwBfAC8AXABfAH0AJAB7AF8ALwA9AD0AXAAvAFwALwBcAF8ALwBcAF8ALwA9AFwALwA9AH0ALgBqAHAAZwA=')));
}

function _____/\/=\/\__/\_/(${__/=\/=\____/\/=\_}, ${__/\/\__/\/=\___/=})
{ 
    $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAHcAbgBsAG8AYQBkAGkAbgBnACAAJAB7AF8AXwAvAD0AXAAvAD0AXABfAF8AXwBfAC8AXAAvAD0AXABfAH0A'))) 
    ${/=\_/=====\/=\__/} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBVAHIAaQA='))) $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8AXwAvAD0AXAAvAD0AXABfAF8AXwBfAC8AXAAvAD0AXABfAH0A'))) 
    ${/======\/\/=\__/\} = [System.Net.HttpWebRequest]::Create(${/=\_/=====\/=\__/}) 
    ${/======\/\/=\__/\}.Credentials = New-Object System.Net.NetworkCredential(${/\______/========}, ${_/==\____/\__/\/=})
    ${/======\/\/=\__/\}.set_Timeout(15000) 
    ${__/\_/\/\_/===\/=} = ${/======\/\/=\__/\}.GetResponse() 
    ${__/\/\__/===\_/\/} = [System.Math]::Floor(${__/\_/\/\_/===\/=}.get_ContentLength()/1024) 
    ${___/\/\_/=\/==\__} = ${__/\_/\/\_/===\/=}.GetResponseStream() 
    ${___/==\/======\/=} = New-Object -TypeName System.IO.FileStream -ArgumentList "$($(pwd).Path)/${__/\/\__/\/=\___/=}", Create 
    ${_/\/===\_/==\/\__} = New-Object byte[] 10KB 
    ${/\____/=\_/\/\___} = ${___/\/\_/=\/==\__}.Read(${_/\/===\_/==\/\__},0,${_/\/===\_/==\/\__}.length) 
    ${____/==========\/} = ${/\____/=\_/\/\___} 
    while (${/\____/=\_/\/\___} -gt 0) 
    { 
        ${/===\_/\__/=\/\_/} = [System.Math]::Floor(${____/==========\/}/1024)
        Write-Host -NoNewline "`rDownloaded $(${/===\_/\__/=\/\_/})K of $(${__/\/\__/===\_/\/})K" 
        ${___/==\/======\/=}.Write(${_/\/===\_/==\/\__}, 0, ${/\____/=\_/\/\___}) 
        ${/\____/=\_/\/\___} = ${___/\/\_/=\/==\__}.Read(${_/\/===\_/==\/\__},0,${_/\/===\_/==\/\__}.length) 
        ${____/==========\/} = ${____/==========\/} + ${/\____/=\_/\/\___} 
    } 
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBGAGkAbgBpAHMAaABlAGQAIABEAG8AdwBuAGwAbwBhAGQA'))) 
    ${___/==\/======\/=}.Flush()
    ${___/==\/======\/=}.Close() 
    ${___/==\/======\/=}.Dispose() 
    ${___/\/\_/=\/==\__}.Dispose() 
}

foreach(${_/\/\/\/=\/\_/==\} in $(${___/\/=\_/\/==\__}.Keys)) {
    ${_/==\/\/\_/\_/=\/=} = ${___/\/=\_/\/==\__}[${_/\/\/\/=\/\_/==\}]
    ${/\______/==\/==\/} = ____/\_/=\_____/=\ ${_____/==\/=\___/\_} ${_/==\/\/\_/\_/=\/=}
    echo ${/\______/==\/==\/}
    if(!(Test-Path -Path ${_/\/\/\/=\/\_/==\} )){
        New-Item -ItemType directory -Path ${_/\/\/\/=\/\_/==\}
    }
    _____/\/=\/\__/\_/ ${/\______/==\/==\/} $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8ALwBcAC8AXAAvAFwALwA9AFwALwBcAF8ALwA9AD0AXAB9AC8AJAB7AF8AXwBfAF8AXwAvAD0APQBcAC8APQBcAF8AXwBfAC8AXABfAH0AJAB7AF8ALwA9AD0AXAAvAFwALwBcAF8ALwBcAF8ALwA9AFwALwA9AH0ALgBqAHAAZwA=')))
}



