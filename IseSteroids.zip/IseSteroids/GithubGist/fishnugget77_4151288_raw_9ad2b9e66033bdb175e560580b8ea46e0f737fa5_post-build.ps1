﻿md "%USERPROFILE%\RightNowDev"
md "%USERPROFILE%\RightNowDev\AddIns"
md "%USERPROFILE%\RightNowDev\AddIns\$(TargetName)"
copy /Y "$(TargetDir)$(TargetName).*" "%USERPROFILE%\RightNowDev\AddIns\$(TargetName)\"

