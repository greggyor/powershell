﻿<#
.SYNOPSIS
    The go function allows you to prepopulate a list of common destinations accessed by a short key.
.DESCRIPTION
    The go function allows you to prepopulate a list of common destinations accessed by a short key
    such as 'h' for your home directory.
.PARAMETER Key
    Specifies the short name for your destination. If you do not specify the key, the command will
    list the valid key/destination pairs.
.PARAMETER Destination
    Specifies a path when using the -Add parameter to add a key/destination path pair.
.PARAMETER Add
    Specifies the specified Key and Destination parameters should be added. The pairings are saved
    to $home\Documents\WindowsPowerShell\gopaths.xml so they are available in new PowerShell sessions.
.PARAMETER Remove
    Specifies the specified Key and its corresponding destination should be removed.
.PARAMETER List
    Lists the available key/destination pairs.
.PARAMETER Loads
    Loads from the data file and lists the available key/destination pairs. This is useful if you
    add a key/destination pair in a different PowerShell session and you want to use it in this
    session without having to exit and reload PowerShell.
.EXAMPLE
    C:\PS> go
    Lists available key/destination combinations.
.EXAMPLE
    C:\PS> go -Key h -Dest $home -Add
    Adds h as a key for your home directory.
.EXAMPLE
    C:\PS> go h
    Goes to the directory paired to h.
.EXAMPLE
    C:\PS> go h -Remove
    Removes the key h and the corresponding destination.
#>
function go {
    [CmdletBinding(DefaultParameterSetName='Navigate')]
    param(
        [Parameter(Position = 0, ParameterSetName='Navigate')]
        [Parameter(Mandatory, Position = 0, ParameterSetName='Add')]
        [Parameter(Mandatory, Position = 0, ParameterSetName='Remove')]
        [ValidateNotNullOrEmpty()]
        [string]
        $Key,
        [Parameter(Mandatory, Position = 1, ParameterSetName='Add')]
        [ValidateNotNullOrEmpty()]
        [string]
        $Destination,
        [Parameter(ParameterSetName='Add')]
        [switch]
        $Add,
        [Parameter(ParameterSetName='Remove')]
        [switch]
        $Remove,
        [Parameter(ParameterSetName='List')]
        [switch]
        $List,
        [Parameter(ParameterSetName='Load')]
        [switch]
        $Load
    )
    begin {
        Set-StrictMode -Version Latest
        $dataFile = Join-Path (Split-Path $profile.CurrentUserAllHosts -Parent) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwBvAHAAYQB0AGgAcwAuAHgAbQBsAA==')))
        if (Test-Path $dataFile) {
            $ht = Import-Clixml $dataFile    
        }
        else {
            $ht = @{}
        }
        function ShowValidKeywords {
            if ($ht.Count -gt 0) {
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBhAGwAaQBkACAAawBlAHkAdwBvAHIAZABzACAAYQByAGUAOgA=')))
                $ht.Keys | Sort | Select @{n=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SwBlAHkA')));e={$_}},@{n=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHMAdABpAG4AYQB0AGkAbwBuAA==')));e={$ht.$_}} | Format-Table -AutoSize
            }
            else {
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAawBlAHkALwBkAGUAcwB0AGkAbgBhAHQAaQBvAG4AIABwAGEAaQByAHMAIABoAGEAdgBlACAAZABlAGYAaQBuAGUAZAAuACAAIABVAHMAZQAgAHQAaABlACAALQBBAGQAZAAgAHAAYQByAGEAbQBlAHQAZQByACAAdABvACAAYQBkAGQAIABrAGUAeQAvAGQAZQBzAHQAaQBuAGEAdABpAG8AbgAgAHAAYQBpAHIAcwAuAA==')))
            }
        }
    }
    end {
        if ($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQA')))) {
            if (!(Test-Path $Destination)) {
                throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABwAGEAdABoACAAJwAkAEQAZQBzAHQAaQBuAGEAdABpAG8AbgAnACAAbQB1AHMAdAAgAGUAeABpAHMAdAA=')))
            }
            $ht.$key = $Destination
            $ht | Export-Clixml $dataFile
        }
        elseif ($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUA')))) {
            if (!$ht.ContainsKey($Key)) {
                Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JwAkAEsAZQB5ACcAIABpAHMAIABuAG8AdAAgAGEAIAB2AGEAbABpAGQAIABkAGUAcwB0AGkAbgBhAHQAaQBvAG4AIABrAGUAeQA=')))
            }
            $ht.Remove($Key)
            $ht | Export-Clixml $dataFile
        }
        elseif ($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABpAHMAdAA=')))) {
            ShowValidKeywords
        }
        elseif ($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZAA=')))) {
            $ht | Export-Clixml $dataFile
            ShowValidKeywords
        }
        elseif ($PSCmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAHYAaQBnAGEAdABlAA==')))) {
            if (!$Key) {
                ShowValidKeywords
            }
            elseif ($ht.ContainsKey($Key)) {
                cd $ht[$Key]
            }
            else {
                Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JwAkAEsAZQB5ACcAIABpAHMAIABuAG8AdAAgAGEAIAB2AGEAbABpAGQAIABkAGUAcwB0AGkAbgBhAHQAaQBvAG4AIABrAGUAeQA=')))
                ShowValidKeywords
            }
        }
    }
}