﻿Write-Host "START [$($MyInvocation.MyCommand.Name)] $(get-date -f yyyyMMdd.HHmmss.ff)"
# cd to the first directory in the path that contains a program, script, or file
filter gowhere { where.exe $args | select -first 1 | Split-Path -Parent | cd }
sal w where.exe # powershell pre-defines where to be 'SQL-like' where for filtering sets or streams, 
sal which where.exe # *nix-friendly
Write-Host "END   [$($MyInvocation.MyCommand.Name)] $(get-date -f yyyyMMdd.HHmmss.ff)"
return 
# $PSScriptRoot