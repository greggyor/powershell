﻿${__/=\____/\_/\/\_} = @()
foreach (${_/=\/=\/\_/=\/\/\} in $DataSet1.Tables[0].Rows)
{
	${__/=\____/\_/\/\_} = ${__/=\____/\_/\/\_} + (,(${_/=\/=\/\_/=\/\/\}["ApplicationName"],${_/=\/=\/\_/=\/\/\}["InstanceID"]))
	# Use format: $arrInstancesSuspended [0][0]
}
# Sort Array
${__/=\____/\_/\/\_} = ${__/=\____/\_/\/\_} | Sort-Object @{Expression={$_[0]};Ascending=$true}
# Get unique apps
${/==\___/==\/\_/==} = ${__/=\____/\_/\/\_} | foreach {$_[0]} | sort-object -unique
# Ready to push out needed values
foreach (${______/=\/\/\/=\/} in ${/==\___/==\/\_/==}) 
{
	${/=\/=\/=\_/=\/\_/} = (${__/=\____/\_/\/\_} -match ${______/=\/\/\/=\/}) | where {$_[0].Length -eq ${______/=\/\/\/=\/}.Length}
	${_/\____/\_/===\_/} = ${/=\/=\/=\_/=\/\_/}.count
	Write-Host ${______/=\/\/\/=\/}  ${_/\____/\_/===\_/}
}