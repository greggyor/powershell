﻿param ($help,$VServer,$VVault,$VUser,$VPass,$VOut)
$WebServicesPath2014=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAEEAdQB0AG8AZABlAHMAawBcAEEAdQB0AG8AZABlAHMAawAgAFYAYQB1AGwAdAAgADIAMAAxADQAIABTAEQASwBcAGIAaQBuAFwAQQB1AHQAbwBkAGUAcwBrAC4AQwBvAG4AbgBlAGMAdABpAHYAaQB0AHkALgBXAGUAYgBTAGUAcgB2AGkAYwBlAHMALgBkAGwAbAA=')))
if ($help)
{
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAaQBuACAAVgBhAHUAbAB0ACAAdwBpAHQAaAAgAHIAZQBhAGQALQBvAG4AbAB5ACAAYwBvAG4AbgBlAGMAdABpAG8AbgAKAA==')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGEAZwBlADoA')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAEwAbwBnAGkAbgAtAFYAYQB1AGwAdABTAGUAcgB2AGUAcgAuAHAAcwAxACAALQBWAHMAZQByAHYAZQByACAAPABzAGUAcgB2AGUAcgAgAGEAZABkAHIAZQBzAHMAPgAgAC0AVgBWAGEAdQBsAHQAIAA8AHYAYQB1AGwAdAAgAG4AYQBtAGUAPgAgAC0AVgBVAHMAZQByACAAPAB1AHMAZQByAG4AYQBtAGUAPgAgAFsALQBWAFAAYQBzAHMAIAA8AHAAYQBzAHMAdwBvAHIAZAA+AF0ACgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAGcAdQBtAGUAbgB0AHMAOgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAC0AVgBzAGUAcgB2AGUAcgAJAAkAQQB1AHQAbwBkAGUAcwBrACAAVgBhAHUAbAB0ACAAcwBlAHIAdgBlAHIAIABuAGEAbQBlAC4AIABJAG4AIABhAG4AeQAgAGYAbwByAG0AYQB0ADoAIABJAFAALAAgAEQATgBTACwAIABJAFAAOgBwAG8AcgB0ACwAIABEAE4AUwA6AHAAbwByAHQALgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAC0AVgBWAGEAdQBsAHQACQAJAFYAYQB1AGwAdAAgAG4AYQBtAGUALgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAC0AVgBVAHMAZQByAAkACQBSAGUAZwBpAHMAdABlAHIAZQBkACAAdQBzAGUAcgAgAG4AYQBtAGUALgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAC0AVgBQAGEAcwBzAAkACQBQAGEAcwBzAHcAbwByAGQALgA=')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBFAHgAYQBtAHAAbABlADoA')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgAHAAbwB3AGUAcgBzAGgAZQBsAGwAIAAuAFwARQB4AHAAbwByAHQALQBGAGkAbABlAEMAYQB0AGUAZwBvAHIAaQBlAHMALgBwAHMAMQAgAC0AVgBzAGUAcgB2AGUAcgAgAGwAbwBjAGEAbABoAG8AcwB0ACAALQBWAFYAYQB1AGwAdAAgAFYAYQB1AGwAdAAgAC0AVgBVAHMAZQByACAAQQBkAG0AaQBuAGkAcwB0AHIAYQB0AG8AcgAgAC0AVgBQAGEAcwBzACAAcABhAHMAcwAKAA==')))
exit
}
else{
	if (!$VServer -or !$VVault -or !$VUser){$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAGEAcgBnAHUAbQBlAG4AdABzAC4AIABVAHMAZQAgACcAaABlAGwAcAAnACAAYQByAGcAdQBtAGUAbgB0ACAAZgBvAHIAIABtAG8AcgBlACAAaABlAGwAcAA=')))
	exit}
}
try
	{
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHkAaQBuAGcAIAB0AG8AIABmAGkAbgBkACAAVgBhAHUAbAB0ACAAMgAwADEANAAgAGQAbABsAA==')))
	Add-Type -Path $WebServicesPath2014 #Vault 2014
	}
Catch
	{
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZABsAGwAcwAgAHcAZQByAGUAIABmAG8AdQBuAGQALgAgAEUAZABpAHQAIABzAGMAcgBpAHAAdAAgAG8AcgAgAGMAbwBuAHQAYQBjAHQAIABhAHUAdABoAG8AcgAuAA==')))
	exit
	}	
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkACAALQAgAGUAeABlAGMAdQB0AGkAbgBnAA==')))
try{
$cred = New-Object Autodesk.Connectivity.WebServicesTools.UserPasswordCredentials ($VServer,$VVault,$VUser,$VPass,$true)
$webSvc = New-Object Autodesk.Connectivity.WebServicesTools.WebServiceManager ($cred)
Write-Output $webSvc
}
Catch
{$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAaQBuACAAZgBhAGkAbABlAGQA')))
exit}