﻿
${00111010011110110} = "7"
$ErrorActionPreference = "Stop"
${01010100100000111} = @()
${00001000111000001} = Get-Credential

 ${01011011011111110} = @"
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
    <html><head><title>My Systems Report</title>
    <style type="text/css">
    <!--
    body {
    font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
    }

        #report { width: 835px; }

        table{
           border-collapse: collapse;
           border: none;
           font: 10pt Verdana, Geneva, Arial, Helvetica, sans-serif;
           color: black;
           margin-bottom: 10px;
    }

        table td{
           font-size: 12px;
           padding-left: 0px;
           padding-right: 20px;
           text-align: left;
    }

        table th {
           font-size: 12px;
           font-weight: bold;
           padding-left: 0px;
           padding-right: 20px;
           text-align: left;
    }

    h2{ clear: both; font-size: 130%; }

    h3{
           clear: both;
           font-size: 115%;
           margin-left: 20px;
           margin-top: 30px;
    }

    p{ margin-left: 20px; font-size: 12px; }

    table.list{ float: left; }

        table.list td:nth-child(1){
           font-weight: bold;
           border-right: 1px grey solid;
           text-align: right;
    }

    table.list td:nth-child(2){ padding-left: 7px; }
    table tr:nth-child(even) td:nth-child(even){ background: #CCCCCC; }
    table tr:nth-child(odd) td:nth-child(odd){ background: #F2F2F2; }
    table tr:nth-child(even) td:nth-child(odd){ background: #DDDDDD; }
    table tr:nth-child(odd) td:nth-child(even){ background: #E5E5E5; }
    div.column { width: 320px; float: left; }
    div.first{ padding-right: 20px; border-right: 1px  grey solid; }
    div.second{ margin-left: 30px; }
    table{ margin-left: 20px; }
    -->
    </style>
    </head>
    <body>

"@

${00111000011000111} = @"
</div><hr noshade size=3 width="100%"></body></html>
"@

foreach (${01010111101000001} in $VIServers) {

   if (!(get-pssnapin -name VMware.VimAutomation.Core -erroraction silentlycontinue)) {
	    add-pssnapin VMware.VimAutomation.Core
    }

    ${00100100101011001} = $global:DefaultVIServers | where { $_.Name -eq ${01010111101000001} }
        if(${00100100101011001}.IsConnected) {
	        ${10010011100101110} = ${00100100101011001}
            write-output "Reusing open connection to ${01010111101000001}"
        } 
        else {
	        ${10010011100101110} = Connect-VIServer ${01010111101000001} -Credential ${00001000111000001}
            write-output "Connecting to ${01010111101000001}"
        }
    Connect-VIServer ${01010111101000001} -Credential ${00001000111000001}

    write-output "Collecting VM information"
    ${10000110110101000} = Get-VM | Sort Name
    write-output "Collecting Host information"
    ${01100100010101001} = Get-VMHost | Sort Name
    write-output "Collecting Cluster information"
    ${10100011100001000} = Get-Cluster | Sort Name
    write-output "Collecting Datastore information"
    ${01000001001101001} = Get-Datastore | Sort Name | Where-Object {$_.Name -notmatch "local" }
    write-output "Collecting detailed VM information"
    ${00010101101001010} = Get-View -ViewType VirtualMachine | Where {-not $_.Config.Template}
    write-output "Collecting Template information"
    ${01010110011111110} = Get-Template
    write-output "Collecting detailed Host information"
    ${00000010100100101} = Get-View -ViewType hostsystem
    write-output "Collecting detailed Cluster information"
    ${01000100111000101} = Get-View -ViewType ClusterComputeResource
    write-output "Collecting detailed Datastore information"
    ${00000111110111101} = Get-View -ViewType Datastore
    write-output "Collecting vCenter Event Data"
    ${01110100101001000} = Get-VIEvent -maxsamples ([int]::MaxValue) -Start $(get-date).AddDays(-${00111010011110110})

    Function _00010100010100111() {
        
        ${10100110111011000} = @{ }
        ${00010101101001010} | % {
          
          if ($_.Config.AlternateGuestName) { ${01110001101111010} = $_.Config.AlternateGuestName }
          if ($_.Guest.GuestFullName) { ${01110001101111010} = $_.Guest.GuestFullName }
          
          if (!(${01110001101111010})) {
            
            if (!($_.Guest.ToolsStatus.Value__ )) {
              ${01110001101111010} = "Unknown â€“ no VMTools"
            } else {
              # Still no 'version', must be old tools
              $toolsversion = $_.Config.Tools.ToolsVersion
              ${01110001101111010} = "Unknown â€“ tools version $toolsversion"
            }
          }
          ${10100110111011000}.${01110001101111010}++
        }

        ${10010010000110010} = @()
        foreach ( ${10100111101000110} in ${10100110111011000}.Keys | sort) {
          ${01110011110011110} = "" | select OS, Count
          ${01110011110011110}.OS = ${10100111101000110}
          ${01110011110011110}.Count = ${10100110111011000}.${10100111101000110}
          ${10010010000110010} += ${01110011110011110}
        }

        ${10101100000000010} = ${10010010000110010} | sort Count -desc

        If ((${10101100000000010} | Measure-Object).count -gt 0) {
          ${10110110111010100} = "VMs by Operating System : $(${10101100000000010}.count)"
          ${10101100000000010}
        }
        ${10101100000000010} = $null
    }

    
    ${11000001111011100} = New-Object -TypeName PSObject -Property @{
	    "Number of Hosts" = (@(${01100100010101001}).Count)
	    "Number of VMs" = (@(${10000110110101000}).Count)
	    "Number of Templates" = (@(${01010110011111110}).Count)
	    "Number of Clusters" = (@(${10100011100001000}).Count)
	    "Number of Datastores" = (@(${01000001001101001}).Count)
	    "Active VMs" = (@(${00010101101001010} | Where { $_.Runtime.PowerState -eq "poweredOn" }).Count) 
	    "In-active VMs" = (@(${00010101101001010} | Where { $_.Runtime.PowerState -eq "poweredOff" }).Count)
    }

    ${10000000110000111} = @(${01100100010101001} | where {$_.ConnectionState -ne "Connected" -and $_.ConnectionState -ne "Maintenance"} | Select name, @{N="Connection State";E={$_.ExtensionData.Runtime.ConnectionState}}, @{N="Power State";E={$_.ExtensionData.Runtime.PowerState}})
    ${01000000001111000}= @(${00000111110111101} | where { $_.Name -notmatch "Datastore" -and $_.Name -notmatch "swap" } | Select Name, @{N="NumVM";E={($_.vm).Count}} | Sort NumVM -Descending)
    ${00000100100000100} = Get-VMHost | Select Name, @{N=â€œNumVMâ€œ;E={($_ | Get-VM).Count}} | Sort NumVM -Descending
    ${10001011111100111} = @(${01110100101001000} | where {$_.Gettype().Name -eq "VmCreatedEvent" -or $_.Gettype().Name -eq "VmBeingClonedEvent" -or $_.Gettype().Name -eq "VmBeingDeployedEvent"} | Select createdTime, UserName, fullFormattedMessage)
    ${00101101000100110} = @(${01110100101001000} | where {$_.Gettype().Name -eq "VmRemovedEvent"}| Select CreatedTime, UserName, fullFormattedMessage)
    ${01001101111010010} = @(${00010101101001010} | ?{$_.runtime.powerState -eq "PoweredOn" | ?{$_ -is [VMware.Vim.VirtualCdrom] -And $_.connectable.connected}} | Select Name)
    ${10101101111110010} = @(${10000110110101000} | Where { $_.PowerState -eq "PoweredOff"} | Select Name)
    ${10111010001111100} = @(${01110100101001000} | where {$_.Gettype().Name -eq "VmResettingEvent"}| Select createdTime, UserName, fullFormattedMessage)
    ${10100110111011000} = _00010100010100111

    ${01010100100000111} += "General Information about ${01010111101000001}"
    ${01010100100000111} += ${11000001111011100} | ConvertTo-Html -Fragment
    ${01010100100000111} += ${10100110111011000} | convertto-html -fragment

    if (${10000000110000111} -gt "") {
        ${01010100100000111} += "ProblemHosts"
        ${01010100100000111} += ${10000000110000111} | ConvertTo-Html -Fragment
        }

    ${01010100100000111} += "VMsPerDS"
    ${01010100100000111} += ${01000000001111000} | ConvertTo-Html -Fragment
    ${01010100100000111} += "Created VMs"
    ${01010100100000111} += ${10001011111100111} | ConvertTo-Html -Fragment
    ${01010100100000111} += "Removed VMs"
    ${01010100100000111} += ${00101101000100110} | ConvertTo-Html -Fragment

    if (${01001101111010010} -gt "") {
        ${01010100100000111} += "CD Connected"
        ${01010100100000111} += ${01001101111010010} | ConvertTo-Html -Fragment
        }
    
    if (${10000000110000111} -gt "") {
        ${01010100100000111} += "Powered Off"
        ${01010100100000111} += ${10101101111110010} | ConvertTo-Html -Fragment
        }
    ${01010100100000111} += "Reset VMs"
    ${01010100100000111} += ${10111010001111100} | ConvertTo-Html -Fragment
    ${01010100100000111} += "VMsPerHost"
    ${01010100100000111} += ${00000100100000100} | ConvertTo-Html -Fragment

    ${10001111011101101} = ${01011011011111110} + ${01010100100000111} + ${00111000011000111}

    write-output "sending message for ${01010111101000001}"
    Disconnect-VIServer ${01010111101000001} -Force -Confirm:$false
    Send-MailMessage -To $EmailTo -From $EmailFrom -SmtpServer $SMTPSRV -Subject "Weekly Report for ${01010111101000001}" -BodyAsHtml -Body ${10001111011101101}
}

