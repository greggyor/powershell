﻿
mv ~/.config/openbox ~/git/openbox


ln -s ~/git/openbox/openbox ~/.config/openbox



