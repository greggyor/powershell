﻿





${4} = @("GoogleChrome", "thunderbird", "skype", "vlc", "quicktime", "flashplayerplugin", "javaruntime", "DotNet4.5", "utorrent", "dropbox", "Teracopy", "7zip.install", "python", "eclipse-java-juno", "notepadplusplus.install", "git.install", "ccleaner", "evernote", "GitHub", "keepass.install", "line", "nmap", "procexp", "tortoisesvn", "avgantivirusfree", "windirstat", "rufus.portable", "Volume2")
 
 
 



${2} = '<?xml version="1.0" encoding="utf-8"?>'+ "`n" +'<packages>' + "`n"
foreach (${3} in ${4})
{
  ${2} += "`t" +'<package id="' + ${3} + '"/>' + "`n"
}
${2} += '</packages>'
 
${1} = ([system.environment]::getenvironmentvariable("userprofile") + "\packages.config")
${2} | out-File ${1}
 




iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
 
 



 
cinst ${1}
 
 


Remove-Item ${1}

