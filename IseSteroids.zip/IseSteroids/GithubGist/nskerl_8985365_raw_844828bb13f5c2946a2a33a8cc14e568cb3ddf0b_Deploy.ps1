﻿
${/\_____/\____/\/\} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AEMAbwBtAHAAYQBuAHkALgBNAHkAUwBlAHIAdgBpAGMAZQA=')))
${/=\__/\_/\_/\/\__}  = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AFMAZQByAHYAaQBjAGUALgBlAHgAZQA=')))

${___/\/==\_/====\_} = Join-Path -Path $OctopusPackageDirectoryPath -ChildPath ${/=\__/\_/\_/\/\__}


${/===\/\/\___/\/\/} = Get-Service MyCompany.MyService -ErrorAction SilentlyContinue

if (! ${/===\/\/\___/\/\/})
{
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAGEAcwAgAGEAIABuAGUAdwAgAHMAZQByAHYAaQBjAGUALgAuAC4A')))
	& ${___/\/==\_/====\_} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBuAHMAdABhAGwAbAA='))) | Write-Host
}
else
{
    	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcABwAGkAbgBnACAAcwBlAHIAdgBpAGMAZQAuAC4ALgA=')))
    	Stop-Service ${/===\/\/\___/\/\/}.Name -Force     

	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGMAbwBuAGYAaQBnAHUAcgBpAG4AZwAgAHMAZQByAHYAaQBjAGUALgAuAC4A')))
	& $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBjAC4AZQB4AGUA'))) config ${/===\/\/\___/\/\/}.Name binPath= ${___/\/==\_/====\_} start= demand | Write-Host

	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABhAHIAdABpAG4AZwAgAHMAZQByAHYAaQBjAGUALgAuAC4A')))
	Start-Service ${/===\/\/\___/\/\/}.Name
}






