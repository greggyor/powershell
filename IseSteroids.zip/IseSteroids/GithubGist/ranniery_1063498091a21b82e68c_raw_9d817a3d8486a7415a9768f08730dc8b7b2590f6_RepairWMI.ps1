﻿ ###########################
 #  Ranniery Holanda       #
 #  email@ranniery.com.br  #
 #  @_ranniery             #
 #  23/07/2014             #
 ###########################
 #  RepairWMI.ps1          #
 ###########################

 #  Parando e desativando o serviÃ§o do WMI #
(Get-service Winmgmt).stop()
Set-Service -Name Winmgmt -StartupType Disabled -Status Stopped

 #  Acessando o diretÃ³rio do WMI  #
Set-Location $env:windir\system32\wbem

 #  Resetando o repositorio  #
winmgmt /resetrepository

 # Iniciando o Registro das Dlls, Mofs e Mfls  #
regsvr32.exe /s %systemroot%\system32\scecli.dll
regsvr32.exe /s %systemroot%\system32\userenv.dll

mofcomp.exe cimwin32.mof
mofcomp.exe cimwin32.mfl
mofcomp.exe rsop.mof
mofcomp.exe rsop.mfl

$dlls = get-childitem | where {$_.extension -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBkAGwAbAA=')))}
foreach($dll in $dlls)
    {
        Write-Host "registrando $dll..."
        regsvr32.exe /s $dll
    }

$mofs = get-childitem | where {$_.extension -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBtAG8AZgA=')))}
foreach($mof in $mofs)
    {
        Write-Host "registrando $mof..."
        mofcomp.exe $mof
    }

$mfls = get-childitem | where {$_.extension -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBtAGYAbAA=')))}
foreach($mfl in $mfls)
    {
        Write-Host "registrando $mfl..."
        mofcomp.exe $mfl
    }
 
 #  Startando o serviÃ§o do WMI e mudando para automatico  #
Set-Service -Name Winmgmt -StartupType Automatic -Status Running

