﻿# Original Author: Lee Holmes, http://www.leeholmes.com/blog/MorePowerShellSyntaxHighlighting.aspx
# Modified by: Helge Klein, http://blogs.sepago.de/helge/
#           (http://blogs.sepago.de/e/helge/2010/01/18/syntax-highlighting-powershell-code-in-html-with-a-powershell-script)
# Modified again by: David Wise, http://blog.davidjwise.com

# Syntax highlights a PowerShell script.
#
# Usage: Supply the script to syntax hightligh as first and only parameter
#
# Output: Copy of original script with extension ".html"
#
# Example: .\Highlight-Syntax.ps1 .\Get-AppVPackageDependencies.ps1
#
# Version history:
#
# 1.2: David Wise
#     - Converted to use CSS Classes instead of fixed color values
#
# 1.1:
#    - Loading the required assembly System.Web now. This was missing earlier.
#
# 1.0: Initial version


[CmdletBinding()]
param($path)

# Load required assemblies
[void] [System.Reflection.Assembly]::Load("System.Web, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")

# define the CSS Classes for the various elements.  the prefix of 'pshs' is to hopefully make the class names unique in almost any 
# environment.  It is short for "PowerShell Highlight Syntax"
${7} = "
    <style type=""text/css"">
        .pshs-Body {
            font-size: 12px;
            font-family: ""Courier New"",Courier,monospace;
            line-height:12px;
        }
        .pshs-Attribute { color: #ADD8E6; }
        .pshs-Command { color: #0000FF; font-weight:bold; }
        .pshs-CommandArgument { color: #8A2BE2; }
        .pshs-CommandParameter { color: #000080; }
        .pshs-Comment { color: #006400; font-style:italic; }
        .pshs-GroupEnd { color: #000000; }
        .pshs-GroupStart { color: #000000; }
        .pshs-Keyword { color: #00008B; }
        .pshs-LineContinuation { color: #000000; }
        .pshs-LoopLabel { color: #00008B; }
        .pshs-Member { color: #000000; }
        .pshs-NewLine { color: #000000; }
        .pshs-Number { color: #800080; }
        .pshs-Operator { color: #A9A9A9; }
        .pshs-Position { color: #000000; }
        .pshs-StatementSeparator { color: #000000; }
        .pshs-String { color: #8B0000; background-color:ECECEC; }
        .pshs-Type { color: #008080; }
        
        .pshs-Unknown { color: #000000; }
        .pshs-Variable { color: #FF4500; }
    </style>
"

# Generate an HTML span and append it to HTML string builder
${13} = 1
function f2 ($block, $tokenColor)
{
	if (($tokenColor -eq 'NewLine') -or ($tokenColor -eq 'LineContinuation'))
	{
		if($tokenColor -eq 'LineContinuation')
		{
			$null = ${2}.Append('`')
		}

		$null = ${2}.Append("<br />`r`n")
	}
	else
	{
		$block = [System.Web.HttpUtility]::HtmlEncode($block)
		if (-not $block.Trim())
		{
			$block = $block.Replace(' ', '&nbsp;')
		}


		if($tokenColor -eq 'String')
		{
			${12} = $block -split "`r`n"
			$block = ""

			${9} = $false
			foreach(${11} in ${12})
			{
				if(${9})
				{
					$block += "<BR />`r`n"
				}

				${10} = ${11}.TrimStart()
				${10} = "&nbsp;" * (${11}.Length - ${10}.Length) + ${10}
				$block += ${10}
				${9} = $true
			}
		}

		$null = ${2}.Append("<span class=""pshs-$tokenColor"">$block</span>")
	}
}

function f1
{
	${5} = $null

	if($path)
	{
		${5} = (Get-Content $path) -join "`r`n"
	}
	else
	{
		Write-Error 'Please supply the path to the PowerShell script to syntax highlight as first (and only) parameter.'
		return
	}

	trap { break }

	# Do syntax parsing.
	${8} = $null
	${6} = [system.management.automation.psparser]::Tokenize(${5}, [ref] ${8})

	# Initialize HTML builder.
	${2} = new-object system.text.stringbuilder
    
	$null = ${2}.Append(${7})
    
	$null = ${2}.Append("<span class=""pshs-Body"">")

	# Iterate over the tokens and set the colors appropriately.
	${4} = 0
	foreach (${3} in ${6})
	{
		if (${4} -lt ${3}.Start)
		{
			$block = ${5}.Substring(${4}, (${3}.Start - ${4}))
			$tokenColor = 'Unknown'
			f2 $block $tokenColor
		}

		$block = ${5}.Substring(${3}.Start, ${3}.Length)
		$tokenColor = ${3}.Type.ToString()
		f2 $block $tokenColor

		${4} = ${3}.Start + ${3}.Length
	}
    
	$null = ${2}.Append("</span>");

	# Build the entire syntax-highlighted script
	${1} = ${2}.ToString()
	
	# Replace tabs with three blanks
	${1}	= ${1} -replace "\t","&nbsp;&nbsp;&nbsp;"

	# Write the HTML to a file
	${1} | set-content -path "$path.html"
}

. f1


