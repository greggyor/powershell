﻿function Get-SqlServiceStatus ($serviceName)
{
    # Get a reference to the service
    $sqlService = gsv $serviceName
    # Return the service status
    return $sqlService.status
}