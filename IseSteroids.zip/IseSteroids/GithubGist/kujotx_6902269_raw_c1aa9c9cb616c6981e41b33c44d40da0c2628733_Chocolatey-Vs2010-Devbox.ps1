﻿choco windowsfeatures MSMQ-Container
choco windowsfeatures MSMQ-Server

choco install Firefox
choco install Google.Chrome

choco install webpicommandline
choco webpi msdeploy
choco webpi iisexpress

choco install TeraCopy
choco install windbg
choco install windowstelnet
choco install wireshark
choco install winsplit
choco install ferventcoder.utilities
choco install winmerge
choco install lockhunter
choco install ack
choco install autohotkey
choco install camstudio

choco install msysgit
choco install git.install
choco install gitextensions
choco install git-credential-winstore
choco install git.alias.standup
choco install gittfs
choco install Devbox-GitFlow
choco install TortoiseGit
choco install poshgit
choco install SourceTree

choco install tfpt
choco install tfsSidekicks2010
choco install Growl
choco install Wix35
choco install papercut
choco install warmup
choco install ilmerge
choco install NuGet.CommandLine
choco install Nuget.Core
choco install NuGet.Server
choco install resharper
choco install dotPeek
choco install ruby

choco install Machine.Specifications.tools.resharper80
choco install Microsoft.Web.Infrastructure
choco install mspeclivetemplates


