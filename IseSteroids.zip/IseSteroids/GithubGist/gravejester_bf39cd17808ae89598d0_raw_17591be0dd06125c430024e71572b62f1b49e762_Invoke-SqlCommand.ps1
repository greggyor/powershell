﻿function Invoke-SqlCommand{
    <#
        .SYNOPSIS
            Invoke SQL command(s) to a database server.
        .DESCRIPTION
            This function will take a SQL query and a database connection and rund the SQL query/commands and optionally return data as a DataTable object.
        .EXAMPLES
            Invoke-SqlCommand -Query $myQuery -DBConnection $myDbConnection
            This will run the query in $myQuery using the connection object in $myDbConnection. No data will be retuned.
        .EXAMPLES
            $myData = Invoke-SqlCommand -Query $myQuery -DBConnection $myDBConnection -GetResults
            This will run the query in $myQuery using the connection object in $myDbConnection and save the returned data in $myData.
        .NOTES
            Author: Ã˜yvind Kallstad
            Date: 05.02.2015
            Version: 1.0
    #>
    param(
        [Parameter(Position = 0, Mandatory = $true)]
        [string]$Query,
 
        [Parameter(Position = 1, Mandatory = $true, ValueFromPipeline = $true)]
        [System.Data.Common.DBConnection]$DbConnection,
 
        [Parameter()]
        [int]$Timeout = 30,
 
        [Parameter()]
        [switch]$GetResults = $false
    )
 
    try{
        $command = $DbConnection.CreateCommand()
        $command.CommandText = $Query
        $command.CommandTimeout = $Timeout
 
        if ($GetResults){
            $dbData = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhAC4ARABhAHQAYQBUAGEAYgBsAGUA')))
 
            switch($DbConnection.GetType().Name){
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwByAGEAYwBsAGUAQwBvAG4AbgBlAGMAdABpAG8AbgA='))) {$dataAdapter = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwByAGEAYwBsAGUALgBEAGEAdABhAEEAYwBjAGUAcwBzAC4AQwBsAGkAZQBuAHQALgBPAHIAYQBjAGwAZQBEAGEAdABhAEEAZABhAHAAdABlAHIA'))) -ArgumentList $command}
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBxAGwAQwBvAG4AbgBlAGMAdABpAG8AbgA=')))    {$dataAdapter = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhAC4AUwBxAGwAQwBsAGkAZQBuAHQALgBTAHEAbABEAGEAdABhAEEAZABhAHAAdABlAHIA'))) -ArgumentList $command}
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBkAGIAYwBDAG8AbgBuAGUAYwB0AGkAbwBuAA==')))   {$dataAdapter = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhAC4ATwBkAGIAYwAuAE8AZABiAGMARABhAHQAYQBBAGQAYQBwAHQAZQByAA=='))) -ArgumentList $command}
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AFMAcQBsAEMAbwBuAG4AZQBjAHQAaQBvAG4A')))  {$dataAdapter = New-Object -TypeName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AFMAcQBsAC4ARABhAHQAYQAuAE0AeQBTAHEAbABDAGwAaQBlAG4AdAAuAE0AeQBTAHEAbABEAGEAdABhAEEAZABhAHAAdABlAHIA'))) -ArgumentList $command}
                default {
                    $dataAdapter = $null
                    Write-Warning -Message "Database connection type '$($DbConnection.GetType().Name)' is not supported by this function"
                }
            }
 
            if ($dataAdapter){
                [void]$dataAdapter.Fill($dbData)
                Write-Output (,($dbData))
            }
        }
        else{
            [void]$command.ExecuteNonQuery()
        }
    }
    catch{
        Write-Warning "At line:$($_.InvocationInfo.ScriptLineNumber) char:$($_.InvocationInfo.OffsetInLine) Command:$($_.InvocationInfo.InvocationName), Exception: '$($_.Exception.Message.Trim())'"
    }
}

