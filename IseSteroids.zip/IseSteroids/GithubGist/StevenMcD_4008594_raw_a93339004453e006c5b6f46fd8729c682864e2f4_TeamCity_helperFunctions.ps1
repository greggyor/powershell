﻿#############################
# Mercilessly copied from https://github.com/kvarv/Continuous-Delivery
#############################
function TeamCity-TestSuiteStarted([string]$name) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQAUwB1AGkAdABlAFMAdABhAHIAdABlAGQAIABuAGEAbQBlAD0AJwAkAG4AYQBtAGUAJwBdAA==')))
}
function TeamCity-TestSuiteFinished([string]$name) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQAUwB1AGkAdABlAEYAaQBuAGkAcwBoAGUAZAAgAG4AYQBtAGUAPQAnACQAbgBhAG0AZQAnAF0A')))
}
function TeamCity-TestStarted([string]$name) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQAUwB0AGEAcgB0AGUAZAAgAG4AYQBtAGUAPQAnACQAbgBhAG0AZQAnAF0A')))
}
function TeamCity-TestFinished([string]$name) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQARgBpAG4AaQBzAGgAZQBkACAAbgBhAG0AZQA9ACcAJABuAGEAbQBlACcAXQA=')))
}
function TeamCity-TestIgnored([string]$name, [string]$message='') {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQASQBnAG4AbwByAGUAZAAgAG4AYQBtAGUAPQAnACQAbgBhAG0AZQAnACAAbQBlAHMAcwBhAGcAZQA9ACcAJABtAGUAcwBzAGEAZwBlACcAXQA=')))
}
function TeamCity-TestOutput([string]$name, [string]$output) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQAUwB0AGQATwB1AHQAIABuAGEAbQBlAD0AJwAkAG4AYQBtAGUAJwAgAG8AdQB0AD0AJwAkAG8AdQB0AHAAdQB0ACcAXQA=')))
}
function TeamCity-TestError([string]$name, [string]$output) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQAUwB0AGQARQByAHIAIABuAGEAbQBlAD0AJwAkAG4AYQBtAGUAJwAgAG8AdQB0AD0AJwAkAG8AdQB0AHAAdQB0ACcAXQA=')))
}
function TeamCity-TestFailed([string]$name, [string]$message, [string]$details='', [string]$type='', [string]$expected='', [string]$actual='') {
	$output=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHQAZQBzAHQARgBhAGkAbABlAGQAIAA=')));
	if (![string]::IsNullOrEmpty($type)) {
		$output += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAB0AHkAcABlAD0AJwAkAHQAeQBwAGUAJwA=')))
	}
	$output += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABuAGEAbQBlAD0AJwAkAG4AYQBtAGUAJwAgAG0AZQBzAHMAYQBnAGUAPQAnACQAbQBlAHMAcwBhAGcAZQAnACAAZABlAHQAYQBpAGwAcwA9ACcAJABkAGUAdABhAGkAbABzACcA')))
	if (![string]::IsNullOrEmpty($expected)) {
		$output += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABlAHgAcABlAGMAdABlAGQAPQAnACQAZQB4AHAAZQBjAHQAZQBkACcA')))
	}
	if (![string]::IsNullOrEmpty($actual)) {
		$output += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABhAGMAdAB1AGEAbAA9ACcAJABhAGMAdAB1AGEAbAAnAA==')))
	}
	$output += ']'
	Write-Output $output
}
function TeamCity-PublishArtifact([string]$path) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHAAdQBiAGwAaQBzAGgAQQByAHQAaQBmAGEAYwB0AHMAIAAnACQAcABhAHQAaAAnAF0A')))
}
function TeamCity-ReportBuildStart([string]$message) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHAAcgBvAGcAZQBzAHMAUwB0AGEAcgB0ACAAJwAkAG0AZQBzAHMAYQBnAGUAJwBdAA==')))
}
function TeamCity-ReportBuildProgress([string]$message) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHAAcgBvAGcAZQBzAHMATQBlAHMAcwBhAGcAZQAgACcAJABtAGUAcwBzAGEAZwBlACcAXQA=')))
}
function TeamCity-ReportBuildFinish([string]$message) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAHAAcgBvAGcAZQBzAHMARgBpAG4AaQBzAGgAIAAnACQAbQBlAHMAcwBhAGcAZQAnAF0A')))
}
function TeamCity-ReportBuildStatus([string]$status, [string]$text='') {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAGIAdQBpAGwAZABTAHQAYQB0AHUAcwAgACcAJABzAHQAYQB0AHUAcwAnACAAdABlAHgAdAA9ACcAJAB0AGUAeAB0ACcAXQA=')))
}
function TeamCity-SetBuildNumber([string]$buildNumber) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAGIAdQBpAGwAZABOAHUAbQBiAGUAcgAgACcAJABiAHUAaQBsAGQATgB1AG0AYgBlAHIAJwBdAA==')))
}
function TeamCity-SetBuildStatistic([string]$key, [string]$value) {
	Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjAHQAZQBhAG0AYwBpAHQAeQBbAGIAdQBpAGwAZABTAHQAYQB0AGkAcwB0AGkAYwBWAGEAbAB1AGUAIABrAGUAeQA9ACcAJABrAGUAeQAnACAAdgBhAGwAdQBlAD0AJwAkAHYAYQBsAHUAZQAnAF0A')))
}
function TeamCity-CreateInfoDocument([string]$buildNumber='', [boolean]$status=$true, [string[]]$statusText=$null, [System.Collections.IDictionary]$statistics=$null) {
	$doc=New-Object xml;
	${_/\/\/\_/\_/\/==\}=$doc.CreateElement($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB1AGkAbABkAA=='))));
	if (![string]::IsNullOrEmpty($buildNumber)) {
		${_/\/\/\_/\_/\/==\}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgB1AG0AYgBlAHIA'))), $buildNumber);
	}
	${_/\/\/\_/\_/\/==\}=$doc.AppendChild(${_/\/\/\_/\_/\/==\});
	${_/======\_/=\_/\/}=$doc.CreateElement($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AGEAdAB1AHMASQBuAGYAbwA='))));
	if ($status) {
		${_/======\_/=\_/\/}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AGEAdAB1AHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBVAEMAQwBFAFMAUwA='))));
	} else {
		${_/======\_/=\_/\/}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AGEAdAB1AHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATABVAFIARQA='))));
	}
	if ($statusText -ne $null) {
		foreach ($text in $statusText) {
			${___/\_/\_/=\/\__/}=$doc.CreateElement($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAHgAdAA='))));
			${___/\_/\_/=\/\__/}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBjAHQAaQBvAG4A'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBwAHAAZQBuAGQA'))));
			${___/\_/\_/=\/\__/}.set_InnerText($text);
			${___/\_/\_/=\/\__/}=${_/======\_/=\_/\/}.AppendChild(${___/\_/\_/=\/\__/});
		}
	}	
	${_/======\_/=\_/\/}=${_/\/\/\_/\_/\/==\}.AppendChild(${_/======\_/=\_/\/});
	if ($statistics -ne $null) {
		foreach ($key in $statistics.Keys) {
			${/=\/==\/======\_/}=$statistics.$key
			if (${/=\/==\/======\_/} -eq $null) {
				${/=\/==\/======\_/}=''
			}
			${_/\_/\_/\__/=\__/}=$doc.CreateElement($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AGEAdABpAHMAdABpAGMAcwBWAGEAbAB1AGUA'))));
			${_/\_/\_/\__/=\__/}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('awBlAHkA'))), $key);
			${_/\_/\_/\__/=\__/}.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBhAGwAdQBlAA=='))), ${/=\/==\/======\_/}.ToString());
			${_/\_/\_/\__/=\__/}=${_/\/\/\_/\_/\/==\}.AppendChild(${_/\_/\_/\__/=\__/});
		}
	}
	return $doc;
}
function TeamCity-WriteInfoDocument([xml]$doc) {
	${_/\_/\/=\/\______}=(Split-Path $buildFile)
	$path=(Join-Path ${_/\_/\/=\/\______} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAGEAbQBjAGkAdAB5AC0AaQBuAGYAbwAuAHgAbQBsAA=='))))
	$doc.Save($path);
}