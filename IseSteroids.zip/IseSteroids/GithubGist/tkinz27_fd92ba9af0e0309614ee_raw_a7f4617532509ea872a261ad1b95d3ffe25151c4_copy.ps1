﻿#!powershell
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible.  If not, see <http://www.gnu.org/licenses/>.

# WANT_JSON
# POWERSHELL_COMMON

${10011010100000011} = Parse-Args $args;

${00111101111101011}= Get-Attr ${10011010100000011} "src" $FALSE;
If (${00111101111101011} -eq $FALSE)
{
    Fail-Json (New-Object psobject) "missing required argument: src";
}

${10100010111011010}= Get-Attr ${10011010100000011} "dest" $FALSE;
If (${10100010111011010} -eq $FALSE)
{
    Fail-Json (New-Object psobject) "missing required argument: dest";
}

${10100100111101100} = New-Object psobject @{
    changed = $FALSE
};

If (Test-Path ${10100010111011010})
{
    ${10011000101101010} = (Get-FileHash -Path ${10100010111011010} -Algorithm MD5).Hash.ToLower();
    ${01011100110101010} = (Get-FileHash -Path ${00111101111101011} -Algorithm MD5).Hash.ToLower();

    If ( ${01011100110101010} -ne ${10011000101101010})
    {
        cp -Path ${00111101111101011} -Destination ${10100010111011010} -Force;
    }
    ${10011000101101010} = (Get-FileHash -Path ${10100010111011010} -Algorithm MD5).Hash.ToLower();
    If ( ${01011100110101010} -eq ${10011000101101010})
    {
        ${10100100111101100}.changed = $TRUE;
    }
    Else
    {
        Fail-Json (New-Object psobject) "Failed to place file";
    }
}
Else
{
    cp -Path ${00111101111101011} -Destination ${10100010111011010};
    ${10100100111101100}.changed = $TRUE;
}

Exit-Json ${10100100111101100};

