﻿


param(
    [Parameter(Mandatory=$false,Position=0)]
    [string]$logsrc = "Andi Solr Update"
)

$triggerUrl = "http://localhost:8983/solr/core1/dataimport?command=full-import&clean=true&optimize=true&wt=xml"
$statusUrl = "http://localhost:8983/solr/core1/dataimport?command=status&wt=xml&indent=on"
[int]$interval = 5


function f1([string]$msg) {
    
    Write-EventLog -LogName Application -Source $logsrc -EventId 500 -EntryType Error -Message $msg -Category 0
    Write-Host ("ERROR {0}" -f $msg)
}

function f3([string]$msg) {
    
    Write-EventLog -LogName Application -Source $logsrc -EventId 200 -EntryType Information -Message $msg -Category 0
    Write-Host ("INFO {0}" -f $msg)
}

function f2([string]$msg) {
    Write-EventLog -LogName Application -Source $logsrc -EventId 400 -EntryType Warning -Message $msg -Category 0
    Write-Host ("WARNING {0}" -f $msg)
}



try {

    $triggerReply = (new-object System.Net.WebClient).DownloadString($triggerUrl)
    Write-Host ("Triggered Solr [{0}]:" -f $triggerUrl)

    
    $status = "busy"
    $statusReply
    $xml
    while ($status -eq "busy") {
        
        Start-Sleep -Seconds $interval
        
        $statusReply = (new-object System.Net.WebClient).DownloadString($statusUrl)
        
        $xml = [xml]$statusReply
        $status = ($xml.response.str | where { $_.name -eq "status"}).InnerText
        
        if ($status -eq "busy") {
            $docsFetched = $xml.SelectSingleNode("response/lst[@name = ""statusMessages""]/str[@name = ""Total Rows Fetched""]").InnerText
            $docsProcessed = $xml.SelectSingleNode("response/lst[@name = ""statusMessages""]/str[@name = ""Total Documents Processed""]").InnerText
            $docsSkipped = $xml.SelectSingleNode("response/lst[@name = ""statusMessages""]/str[@name = ""Total Documents Skipped""]").InnerText
            Write-Host ("Reply from Solr: fetched={0} processed={1} skipped={2}" -f $docsFetched, $docsProcessed, $docsSkipped)
        }
    }
   
    
    if ($status -eq "idle") {
        $statusMsg = $xml.SelectSingleNode("response/lst[@name = ""statusMessages""]/str[@name = """"]").InnerText
        if ($statusMsg.StartsWith("Indexing failed")) {
            f1(("{0}`r`n`r`n{1}" -f $statusMsg, $statusReply))
        }
        elseif ($statusMsg.StartsWith("Indexing completed")) {
            [int]$docsFailed = $xml.SelectSingleNode("response/lst[@name = ""statusMessages""]/str[@name = ""Total Documents Failed""]").InnerText
            if ($docsFailed -eq 0) {
                f3(("{0}`r`n`r`n{1}" -f $statusMsg, $statusReply))
            }
            else {
                f2(("{0}`r`n`r`n{1}" -f $statusMsg, $statusReply))
            }
        }
        else {
            f2(("Unable to read Solr status message. Indexing success is unknown. Review the included reply for more info.`r`n`r`n{0}" -f $statusReply))
        }
    }
    else {
        f2(("Unable to read Solr status. Indexing may or may not have finished. Review the included reply for more info.`r`n`r`n{0}" -f $statusReply))
    }

    exit 0

}
catch [Exception] {
    f1($_.Exception)
    exit 1
}


