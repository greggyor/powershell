﻿# sets the folder creation date to the specified date variable
# version 0.0.1
# author: Patrick Magee
#######################
${00100100100001010} = ""
${00101000000111011} = ""
${10110111001011010} = [datetime]::Today
while (${00100100100001010} -notmatch "[y|n]") {
    ${00100100100001010} = Read-Host "Set creation date? (Y/N)"
    if(${00100100100001010} -eq "y") {
        while(-not [System.IO.Directory]::Exists(${00101000000111011})) {
            ${00101000000111011} = Read-Host "Enter valid directory. e.g 'D:\videos\Movies'"        
        }
        Write-Host "Listing directories created in the past..." -ForegroundColor Green
        ${01101100100000100} = (ls ${00101000000111011} | ? { $_.CreationTime -lt ${10110111001011010} }).Count
        ls ${00101000000111011} | ? { 
                $_.CreationTime -lt ${10110111001011010} 
        } | % {         
            Write-Host ('{0} ({1})' -f $_.Name, $_.CreationTime) -ForegroundColor Red 
        }
        ${00100100100001010} = ""
        While (${00100100100001010} -notmatch "[y|n]") {
            ${00100100100001010} = read-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAGUAIAB5AG8AdQAgAHMAdQByAGUAIAB5AG8AdQAgAHcAYQBuAHQAIAB0AG8AIABzAGUAdAAgAHQAaABlACAAYwByAGUAYQB0AGkAbwBuACAAZABhAHQAZQAgAG8AbgAgACQAewAwADEAMQAwADEAMQAwADAAMQAwADAAMAAwADAAMQAwADAAfQAgAGkAdABlAG0AcwAgAHQAbwAgACQAewAxADAAMQAxADAAMQAxADEAMAAwADEAMAAxADEAMAAxADAAfQA='))) + "? (Y/N)"
        }
        if(${00100100100001010} -eq "y"){ 
            ls ${00101000000111011} | where { $_.CreationTime -lt ${10110111001011010} } | % { $_.CreationTime = ${10110111001011010} }
            Write-Host 'Complete.' -ForegroundColor Red
        } 
        else {
            Write-Host "Cancelled." -ForegroundColor Red
        }
    } 
    else { 
       Write-Host "Cancelled." -ForegroundColor Red
    }
}    
