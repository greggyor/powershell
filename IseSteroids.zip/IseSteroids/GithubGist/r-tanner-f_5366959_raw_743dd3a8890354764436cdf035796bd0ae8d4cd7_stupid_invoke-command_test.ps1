﻿$remoteservices = invoke-command -computer eaglexa1 -scriptblock {
    $a = gsv
    $b = ps
    return $a
}

$remoteservices | ft -Property Name,Status

