﻿ipmo .\charting.psm1 -Force


${10010100010010111} = @{
    "Microsoft" = 800
    "Apple" = 250
    "Google" = 400
    "RIM" = 0
}


New-Chart -Dataset ${10010100010010111} | Show-Chart




${00100011101000001} = [ordered]@{}


[xml]${00000110011100100} = (iwr -Uri http://www.yr.no/place/Norway/Oslo/Oslo/Oslo/varsel.xml).Content
${00000110011100100}.weatherdata.forecast.tabular.time | foreach {
    ${00100011101000001}[$_.from] = $_.temperature.value   
}


New-Chart -Title $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAG0AcABlAHIAYQB0AHUAcgBlACAAaQBuACAATwBzAGwAbwA='))) -XInterval 4 -YInterval 2 -Width 1200 | 
    Add-ChartDataset -Dataset ${00100011101000001} -DatasetName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAG0AcABlAHIAYQB0AHUAcgBlAA=='))) -SeriesChartType Spline -OutVariable tempChart |
    Show-Chart


$tempChart.SaveImage($Env:USERPROFILE + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABEAGUAcwBrAHQAbwBwAFwAQwBoAGEAcgB0AC4AcABuAGcA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABOAEcA'))))

