﻿[Environment]::CurrentDirectory=(Get-Location -PSProvider FileSystem).ProviderPath 
foreach ($day in 2..4){
    foreach ($number in 000..200 ) {
        $url =  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB2AGkAZABlAG8ALgBjAGgAOQAuAG0AcwAvAHMAZQBzAHMAaQBvAG4AcwAvAGIAdQBpAGwAZAAvADIAMAAxADIALwA='))) + $day + '-' + ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoARAAzAH0A'))) -f [int]$number) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBwAHAAdAB4AA==')))
        $uri = New-Object System.Uri($url) 
        $file = '' + $day + '-' + ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoARAAzAH0A'))) -f [int]$number) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBwAHAAdAB4AA==')))
        if (!(test-path $file)) 
        { 
            $wc = (New-Object System.Net.WebClient)
            #Set the username for windows auth proxy
            #$wc.proxy.credentials=[system.net.credentialcache]::defaultnetworkcredentials
            $wc.DownloadFile($uri, $file) 
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHkAIAB0AG8AIABkAG8AdwBuAGwAbwBhAGQAIAA='))) + $url
        } 
    }
}