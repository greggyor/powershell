﻿#Get Boxstarter on RemotePC
CINST Boxstarter.Chocolatey
ipmo Boxstarter.Chocolatey
#Create minimal nuspec and chocolateyInstall
New-BoxstarterPackage MyPackage
#Edit Install script
Notepad Join-Path $Boxstarter.LocalRepo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABvAG8AbABzAFwAQwBoAG8AYwBvAGwAYQB0AGUAeQBJAG4AcwB0AGEAbABsAC4AcABzADEA')))
#Pack nupkg
Invoke-BoxstarterBuild MyPackage
#share Repo
Set-BoxstarterShare
#on new bare os
\\RemotePC\Boxstarter\Boxstarter Mypackage
#Enter password when prompted and come back later to new box