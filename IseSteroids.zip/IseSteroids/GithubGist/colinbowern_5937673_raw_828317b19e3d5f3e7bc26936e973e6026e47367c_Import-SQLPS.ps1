﻿$CurrentFolder = $(Get-Location).Path
Import-Module SQLPS -DisableNameChecking
Set-Location $CurrentFolder