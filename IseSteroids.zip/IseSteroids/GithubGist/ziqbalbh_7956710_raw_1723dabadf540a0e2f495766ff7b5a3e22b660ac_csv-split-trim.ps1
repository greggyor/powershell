﻿$CSVData = @("One       ,   Two ,   Three    ")


$Data = $CSVData -split (",")


$Data = $CSVData -split ',' | foreach {$_.Trim()}


$CSVData.Split(",").Trim()


$Data = $CSVData -split '\s*,\s*'

