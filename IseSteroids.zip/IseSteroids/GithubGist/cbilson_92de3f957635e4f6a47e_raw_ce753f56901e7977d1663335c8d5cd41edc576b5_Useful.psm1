﻿
function __/=====\/==\/=\__($Path, $Name, $ChocolateyPackageName) {
  if (!$Path) {
    $commandFromEnvPath = Get-Command $Name
    if ($commandFromEnvPath -ne $null) {
      return $commandFromEnvPath.Definition
    }
    
    if (!(Test-Path env:ChocolateyInstall)) {
      throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAG8AYwBvAGwAYQB0AGUAbAB5ACAAbgBvAHQAIABpAG4AcwB0AGEAbABsAGUAZAAuACAAUABsAGUAYQBzAGUAIAB0AGUAbABsACAAbQBlACAAdwBoAGUAcgBlACAAJABOAGEAbQBlACAAaQBzAC4A')))
    }
    
    $Path = Join-Path $env:ChocolateyInstall $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBpAG4AXAAkAE4AYQBtAGUA')))
    if (!(Test-Path $Path)) {
      throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABOAGEAbQBlACAAbgBvAHQAIABpAG4AcwB0AGEAbABsAGUAZAAgAG8AcgAgAG4AbwB0ACAAaQBuAHMAdABhAGwAbABlAGQAIAB2AGkAYQAgAGMAaABvAGMAbwBsAGEAdABlAHkALgAgAA=='))) `
        + $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABsAGUAYQBzAGUAIABgAGMAaABvAGMAbwAgAGkAbgBzAHQAYQBsAGwAIAAkAEMAaABvAGMAbwBsAGEAdABlAHkAUABhAGMAawBhAGcAZQBOAGEAbQBlAGAAIABvAHIAIAB0AGUAbABsACAAbQBlACAAdwBoAGUAcgBlACAAJABOAGEAbQBlACAAaQBzAC4A')))
    }
  } elseif (!(Test-Path $Path)) {
    throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABOAGEAbQBlACAAbgBvAHQAIABmAG8AdQBuAGQAIABhAHQAIAAkAFAAYQB0AGgALgAgAFAAbABlAGEAcwBlACAAYwBoAGUAYwBrACAAcABhAHQAaAAgAG8AcgAgAGkAbgBzAHQAYQBsAGwAIAAkAE4AYQBtAGUALgA=')))
  } else {
    $Path
  }
}

function Install-EmacsExplorerIntegration(
  $EmacsPath,
  $Extensions=('.asm',
               '.c', '.clj', '.cljs', '.cljx', '.config', '.cpp', '.cs', '.csproj',
               '.d',
               '.el',
               '.fs', '.fsi',
               '.h', '.hpp', '.hs',
               '.java',
               '.log', '.lisp',
               '.markdown', '.md', '.ml',
               '.org',
               '.pl', '.proj', '.ps1', '.psd1', '.psm1', '.py',
               '.rb',
               '.tex', '.txt',
               '.xml'),
  [switch] $NoDiredHere)
{
  $EmacsPath = __/=====\/==\/=\__ $EmacsPath 'emacsclient.exe' 'emacs'

  if (!$NoDiredHere) {
    $diredHerePath = 'Registry::HKEY_CLASSES_ROOT\Directory\shell\DiredHere'
    New-Item $diredHerePath -Force
    Set-Item $diredHerePath 'Open Emacs Dired Here'

    $commandPath = Join-Path $diredHerePath 'command'
    New-Item $commandPath -Force
    Set-Item $commandPath -Value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABFAG0AYQBjAHMAUABhAHQAaAAgACcAJQBMACcA')))
  }

  foreach ($ext in $Extensions) {
    $diredHerePath = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFwAQwB1AHIAcgBlAG4AdABWAGUAcgBzAGkAbwBuAFwARQB4AHAAbABvAHIAZQByAFwARgBpAGwAZQBFAHgAdABzAFwAJABlAHgAdABcAFUAcwBlAHIAQwBoAG8AaQBjAGUA')))
    
    
  }
}


