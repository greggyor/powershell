﻿# ------------------------------------------------------------------
# ãƒ‡ãƒãƒƒã‚°ãƒ­ã‚°ã‚’ãƒ•ã‚¡ã‚¤ãƒ«ã«å‡ºåŠ›ã™ã‚‹
# é–¢æ•°åï¼šWrite-DebugLog
# å¼•æ•°  ï¼šValue ãƒ­ã‚°ã¨ã—ã¦å‡ºåŠ›ã™ã‚‹æ–‡å­—åˆ—
# æˆ»ã‚Šå€¤ï¼šãªã—
# ------------------------------------------------------------------
function Write-DebugLog([String]$VALUE){
  if($LogLevel-le 0){
    Out-LogFile -LogFilePath $LogFilePath -Value $Value -LogType 0 -LogEncoding $LogEncoding
  }
}
# ------------------------------------------------------------------
# æƒ…å ±ãƒ­ã‚°ã‚’ãƒ•ã‚¡ã‚¤ãƒ«ã«å‡ºåŠ›ã™ã‚‹
# é–¢æ•°åï¼šWrite-InfoLog
# å¼•æ•°  ï¼šValue ãƒ­ã‚°ã¨ã—ã¦å‡ºåŠ›ã™ã‚‹æ–‡å­—åˆ—
# æˆ»ã‚Šå€¤ï¼šãªã—
# ------------------------------------------------------------------
function Write-InfoLog([String]$VALUE){
  if($LogLevel -le 1){
    Out-LogFile -LogFilePath $LogFilePath -Value $Value -LogType 1 -LogEncoding $LogEncoding
  }
}
# ------------------------------------------------------------------
# è­¦å‘Šãƒ­ã‚°ã‚’ãƒ•ã‚¡ã‚¤ãƒ«ã«å‡ºåŠ›ã™ã‚‹
# é–¢æ•°åï¼šWrite-WarnLog
# å¼•æ•°  ï¼šValue ãƒ­ã‚°ã¨ã—ã¦å‡ºåŠ›ã™ã‚‹æ–‡å­—åˆ—
# æˆ»ã‚Šå€¤ï¼šãªã—
# ------------------------------------------------------------------
function Write-WarnLog([String]$VALUE){
  if($LogLevel -le 2){
    Out-LogFile -LogFilePath $LogFilePath -Value $Value -LogType 2 -LogEncoding $LogEncoding
  }
}
# ------------------------------------------------------------------
# ã‚¨ãƒ©ãƒ¼ãƒ­ã‚°ã‚’ãƒ•ã‚¡ã‚¤ãƒ«ã«å‡ºåŠ›ã™ã‚‹
# é–¢æ•°åï¼šWrite-ErrorLog
# å¼•æ•°  ï¼šValue ãƒ­ã‚°ã¨ã—ã¦å‡ºåŠ›ã™ã‚‹æ–‡å­—åˆ—
# æˆ»ã‚Šå€¤ï¼šãªã—
# ------------------------------------------------------------------
function Write-ErrorLog([String]$VALUE){
  if($LogLevel -le 3){
    Out-LogFile -LogFilePath $LogFilePath -Value $Value -LogType 3 -LogEncoding $LogEncoding
  }
}