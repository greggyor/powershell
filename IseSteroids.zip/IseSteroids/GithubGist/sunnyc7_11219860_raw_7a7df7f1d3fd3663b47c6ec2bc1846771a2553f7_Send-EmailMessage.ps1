﻿Function Send-EMailMessage {
[CmdletBinding()]
    param(
    [Parameter(Position=1, Mandatory=$true)]
    [String[]]
    $To,
    [Parameter(Position=2, Mandatory=$false)]
    [String[]]
    $CcRecipients,
    [Parameter(Position=3, Mandatory=$false)]
    [String[]]
    $BccRecipients,  
    [Parameter(Position=4, Mandatory=$true)]
    [String]
    $Subject,
    [Parameter(Position=5, Mandatory=$true)]
    [String]
    $Body,
    [Parameter(Position=6, Mandatory=$false)]
    [Switch]
    $BodyAsHtml,   
    [Parameter(Position=7, Mandatory=$true)]
    [System.Management.Automation.PSCredential]
    $Credential,
    [Parameter(Position=8, Mandatory=$false)]
    [String]$Attachment
)
begin {
    $EwsLocalPath = "C:\Program Files\Microsoft\Exchange\Web Services\1.0"
    if (!(Test-Path -Path $EwsLocalPath)) {
        New-Item -ItemType Directory -Path $EwsLocalPath
        Copy $EWSSharePath\*.* $EwsLocalPath
        }
    else {
        Copy $EWSSharePath\*.* $EwsLocalPath
        }
    Add-Type -Path $EwsLocalPath\Microsoft.Exchange.WebServices.dll
}
process {
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService -ArgumentList Exchange2010_SP1
$service.Credentials = New-Object Microsoft.Exchange.WebServices.Data.WebCredentials -ArgumentList $Credential.UserName, $Credential.GetNetworkCredential().Password
$tmpUsername = ($Credential.UserName).Split("\")[1]
$query = "SELECT * FROM ds_user where ds_sAMAccountName='$tmpUsername'"
$user = Get-WmiObject -Query $query -Namespace "root\Directory\LDAP"
$service.AutodiscoverUrl($user.DS_mail)
$MailboxName = "first.lastname@companydomain.com"
$service.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $MailboxName) 
$message = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage -ArgumentList $service
$message.Subject = $Subject
$message.Body = $Body
if(!$BodyAsHtml) {
    $message.Body.BodyType = 'Text'
    }    
if (Test-Path $Attachment) {
    $message.Attachments.AddFileAttachment("$Attachment");
    } 
$To | ForEach-Object{
    $null = $message.ToRecipients.Add($_)
    }
if($CcRecipients) {
    $CcRecipients | ForEach-Object{
    $null = $message.CcRecipients.Add($_)
    }
}
if($BccRecipients) {
    $BccRecipients | ForEach-Object{
    $null = $message.BccRecipients.Add($_)
    }
}
$message.SendAndSaveCopy()
} 
} 
$AttachmentPath = "C:\temp\myattachmentfile.csv"
$to = "sunnyc7@gmail.com"
$Subject = "Test email via Web Serices"
$Body = @"
    This is the message Body.
    You can include anything here alongwith notifications.
    Adding more stuff here.
    You can also use the body variable as parameter.
    
    Time:: $(Get-date)
    Sent from computer:: $env:computername
    Sent by User:: $env:username

    Thank You.
    Sunny.
"@
$Splat = @{
        To = $To
        Subject = $Subject
        Body =$Body
        Credential = $cred2
        Attachment = $AttachmentPath
}
Send-AAMEMailMessage @Splat 