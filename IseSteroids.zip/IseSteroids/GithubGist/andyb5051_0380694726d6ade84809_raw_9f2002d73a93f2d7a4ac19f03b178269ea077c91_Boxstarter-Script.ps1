﻿# http://boxstarter.org/package/url?
 
    # It's nice to be able to browse NuGet files if necessary
    cinstm NugetPackageExplorer
 
    # If we're doing web development, we need a few browsers
    cinstm google-chrome-x64
    cinstm Firefox
 
    # Don't quite know why this is important, but I'll install silverlight and java runtime anyways
    cinstm Silverlight
    cinstm javaruntime
    
    # Gotta have Fiddler
    cinstm fiddler4
 
    # Editors and merge tools
    cinstm notepadplusplus.install
    cinstm nano
    cinst sublimetext3
    
    # Without Git, we might as well go home.
    cinstm poshgit
    cinstm git-credential-winstore -Version 1.2.0.0
 
    # Life sux without Visual Studio and the awesome extensions
    cinstm visualstudio2013expressweb
    
    # Get rid of upper case menu in Visual Studio
    Set-ItemProperty -Path HKCU:\Software\Microsoft\VisualStudio\11.0\General -Name SuppressUppercaseConversion -Type DWord -Value 1 
 
    # Run Visual Studio Update
    if((Get-Item "$($Boxstarter.programFiles86)\Microsoft Visual Studio 11.0\Common7\IDE\devenv.exe").VersionInfo.ProductVersion -lt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAxAC4AMAAuADYAMAAxADEANQAuADEA')))) {
        if(Test-PendingReboot){Invoke-Reboot}
        Install-ChocolateyPackage $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBzACAAdQBwAGQAYQB0AGUAIAAyACAAYwB0AHAAMgA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB4AGUA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBwAGEAcwBzAGkAdgBlACAALwBuAG8AcgBlAHMAdABhAHIAdAA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AOAAvADkALwAzAC8AOAA5ADMANwAyAEQAMgA0AC0ANgA3ADAANwAtADQANQA4ADcALQBBADcARgAwAC0AMQAwAEEAMgA5AEUARQBDAEEAMwAxADcALwB2AHMAdQBwAGQAYQB0AGUAXwBLAEIAMgA3ADAANwAyADUAMAAuAGUAeABlAA==')))
    }
 
    # Fix SSH-Agent error by adding the bin directory to the `Path` environment variable
    $env:PSModulePath = $env:PSModulePath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwBDADoAXABQAHIAbwBnAHIAYQBtACAARgBpAGwAZQBzACAAKAB4ADgANgApAFwARwBpAHQAXABiAGkAbgA=')))
 
    # Markdown is how documentation becomes awesomenes
    # Unfortunately I'm installing this at the end because it doesn't seem to work unattended... it requires the user to press "ok"
    cinstm MarkdownPad2 -installargs $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBlAHgAZQBsAGEAbgBnACAAMQAwADMAMwA=')))
    
    # VPN Client 
    # cinstm ShrewSoftVpn
    
    # Sql Server
    cinst SqlServer2012Express

    #optional packages    
    cinstm chocolateygui
    cinstm paint.net
    cinstm nodejs.install
    cinstm virtualbox
    cinstm putty
    cinstm git.install
    cinstm wireshark
    cinstm vagrant
    cinstm puppet
    cinstm linqpad4
    cinstm java.jdk
    cinstm php
    cinstm google-chrome-x64
    cinstm virtualbox.extensionpack
    cinstm adblockpluschrom
    