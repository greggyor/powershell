﻿
Get-ADUser -Filter { LockoutTime -gt 0 -and BadPwdCount -ge 5 } -Properties * | sort lockouttime -descending | % {
    $lockouttime = [DateTime]::FromFileTimeUtc($_.lockoutTime)
    $bptime = [DateTime]::FromFileTimeUtc($_.badPasswordTime)
    Write-Host "================================================================================="
    Write-Host "$($_.SAMAccountName) ($($_.Name)) locked out on $lockouttime"
    Write-Host "Bad Password Time - $($bptime)"
    Write-Host "================================================================================="
}