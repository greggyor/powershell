﻿import-csv .usuarios.csv | foreach-object{
    ## ---> primera variable del dominio para crear las ou en primer nivel (si es necesario)
    $dominio = [ADSI]$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwBEAEMAPQBkAG8AbQBpAG4AaQBvACwARABDAD0AbwByAGcA')))
    ## ---> segunda variable de dominio para crear los objetos dentro de la OU que sea necesaria
    $dominiog = [ADSI]"LDAP://OU=$($_.UO),DC=dominio,DC=org"
    $busqueda = New-Object System.DirectoryServices.DirectorySearcher($dominio)
 
     
    ## ---> Buscamos la UO entre el DA
    ## ---> Si la UO no existe se crearÃ¡
    $busqueda.Filter=`(objectcategory=organizationalUnit)`
    $busqueda.Filter="(OU=$($_.UO))"
    $buscar = $busqueda.FindAll()
        if ($buscar.count -eq 0){
            $ou = $dominio.Create($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwByAGcAYQBuAGkAegBhAHQAaQBvAG4AYQBsAFUAbgBpAHQA'))),"ou=$($_.UO)")
            $ou.SetInfo()
        }else{
            echo "YA EXISTE LA UO $($_.UO)";
        }
         
    ## ---> Buscamos el grupo dentro de la UO
    ## ---> Si el grupo no existe se crearÃ¡
    $busqueda.Filter=`(objectclass=group)`
    $busqueda.Filter="(OU=$($_.UO))"
    $busqueda.Filter="(CN=$($_.grupo))"
    $buscar = $busqueda.FindAll()
        if ($buscar.count -eq 0){
            $grupo = $dominiog.Create($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAG8AdQBwAA=='))),"CN=$($_.grupo)")
            $grupo.SetInfo()
        }else{
            echo "YA EXISTE EL GRUPO $($_.grupo) EN LA UO $($_.UO)"
        }
         
    ## ---> Buscamos el usuario dentro de la UO
    ## ---> Si el usuario no existe se crearÃ¡
    $busqueda.Filter=`(&(objectclass=user)(objectcategory=person))`
    $busqueda.Filter="(OU=$($_.UO))"
    $busqueda.Filter="(CN=$($_.usuario))"
    $buscar = $busqueda.FindAll()
        if ($buscar.count -eq 0){
            $usuario = $dominiog.Create($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgA='))), "CN=$($_.usuario)")
            $usuario.Put($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBhAG0AQQBjAGMAbwB1AG4AdABOAGEAbQBlAA=='))),"$($_.usuario)")
            $usuario.Put($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBQAHIAaQBuAGMAaQBwAGEAbABOAGEAbQBlAA=='))),"$($_.usuario)@dominio.org")
            $usuario.SetInfo()
            $usuario = [ADSI]"LDAP://CN=$($_.usuario), OU=$($_.UO), DC=dominio, DC=org"
            $usuario.psbase.InvokeSet($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAGMAbwB1AG4AdABEAGkAcwBhAGIAbABlAGQA'))),$False)
            $usuario.SetPassword("$($_.password)")
            $usuario.SetInfo()
            ## ---> Mover los usuarios al grupo que pertenecen
            $grupo = [ADSI]"LDAP://CN=$($_.grupo), OU=$($_.UO), DC=dominio, DC=org"
            $grupo.Add("LDAP://CN=$($_.usuario), OU=$($_.UO), DC=dominio, DC=org")
        }else{
            echo "YA EXISTE EL USUARIO $($_.usuario)"
        }
}

