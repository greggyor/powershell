﻿
${1} = "Cluster Network 1" 
${3} = "IP Address 10.0.1.0" 
${2} = "23.100.xxx.xxx" 
ipmo FailoverClusters
Get-ClusterResource ${3} | Set-ClusterParameter -Multiple @{"Address"="${2}";"ProbePort"="59999";SubnetMask="255.255.255.128";"Network"="${1}";"OverrideAddressMatch"=1;"EnableDhcp"=0}
${1} = "Cluster Network 2" 
${3} = "IP Address 192.168.1.0" 
${2} = "23.100.xxx.xxx" 
ipmo FailoverClusters
Get-ClusterResource ${3} | Set-ClusterParameter -Multiple @{"Address"="${2}";"ProbePort"="59999";SubnetMask="255.255.255.128";"Network"="${1}";"OverrideAddressMatch"=1;"EnableDhcp"=0}
