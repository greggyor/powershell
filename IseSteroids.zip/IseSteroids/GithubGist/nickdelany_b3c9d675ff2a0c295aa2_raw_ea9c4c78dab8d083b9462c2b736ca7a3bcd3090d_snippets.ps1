﻿
$PSVersionTable.psversion
get-childitem -recurse -include *pattern* | format-table Fullname
get-childitem -recurse -include *pattern* | select Fullname, length
select-string *file pattern* -pattern "text" [-CaseSensitive]
get-content *file pattern* | measure-object -line