﻿#set permissions for the event log; read and write to the EventLog key and its subkeys and values.
$acl= get-acl -path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog"
$inherit = [system.security.accesscontrol.InheritanceFlags]"ContainerInherit, ObjectInherit"
$propagation = [system.security.accesscontrol.PropagationFlags]"None"
$rule=new-object system.security.accesscontrol.registryaccessrule "Authenticated Users","FullControl",$inherit,$propagation,"Allow"
$acl.addaccessrule($rule)
$acl|set-acl
#create the Event Log
$EventLogName = "FooBar"
$EventLogExists = Get-EventLog -list | Where-Object {$_.logdisplayname -eq $EventLogName}
if (! $EventLogExists) {
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAJwAkAEUAdgBlAG4AdABMAG8AZwBOAGEAbQBlACcAIABlAHYAZQBuAHQAIABsAG8AZwA=')))
    New-EventLog -LogName $EventLogName -Source $EventLogName -ErrorAction Ignore| Out-Null    
    Write-EventLog -LogName $EventLogName -Source $EventLogName -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAARQB2AGUAbgB0ACAATABvAGcAIAAkAEUAdgBlAG4AdABMAG8AZwBOAGEAbQBlAA=='))) -EventId 0 -EntryType information    
    Write-Host "If you have Event Viewer open, you should probably close and reopen it."
    Get-EventLog -list
}
else{
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAcgBlACAAaQBzACAAYQBsAHIAZQBhAGQAeQAgAGEAbgAgACcAJABFAHYAZQBuAHQATABvAGcATgBhAG0AZQAnACAAZQB2AGUAbgB0ACAAbABvAGcA')))
    Write-EventLog -LogName $EventLogName -Source $EventLogName -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABlAGwAbABvACAARQB2AGUAbgB0ACAATABvAGcAIAAkAEUAdgBlAG4AdABMAG8AZwBOAGEAbQBlAA=='))) -EventId 0 -EntryType information    
}
