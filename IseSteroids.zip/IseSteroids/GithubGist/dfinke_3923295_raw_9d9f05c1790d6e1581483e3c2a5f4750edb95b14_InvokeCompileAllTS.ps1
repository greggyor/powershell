﻿function Invoke-CompileAllTS {
   <#
    .Synopsis
        Recursively searches for TypeScript files and invokes the compiler on the target
    .Example
        Invoke-CompileAllTS
    #>
   
    ls . -Recurse *.ts | ForEach {tsc $_.fullname}
}

