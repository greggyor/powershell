﻿# la recherche Ã  effectuer :
${10001101100000001} = '*sip*'


# si vous Ãªtes sur un poste avec vos identifiants sauvegardÃ©s
Connect-e_session

# dans le cas contraire, vous devrez prÃ©ciser les paramÃ¨tres
# ServerUrl : l'url racine de votre gestion commerciale
# Username : l'adresse e-mail de connexion Ã  utiliser
# Password : le mot de passe associÃ©
# Connect-e_session -serverurl 'http://e-gestcom' -Username test@test.com -password test123#

Get-e_mediationtype ${10001101100000001}

