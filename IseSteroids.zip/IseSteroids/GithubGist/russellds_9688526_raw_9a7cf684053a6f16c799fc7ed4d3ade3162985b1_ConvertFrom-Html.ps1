﻿function ConvertFrom-Html {
   #.Synopsis
   #   Convert a table from an HTML document to a PSObject
   #.Example
   #   Get-ChildItem | Where { !$_.PSIsContainer } | ConvertTo-Html | ConvertFrom-Html -TypeName Deserialized.System.IO.FileInfo
   #   Demonstrates round-triping files through HTML
   param(
      # The HTML content
      [Parameter(ValueFromPipeline=$true)]
      [string]$Html,
      # A TypeName to inject to PSTypeNames 
      [string]$TypeName
   )
   begin { ${01100101100111110} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABoAHQAbQBsAA=='))) }
   process { ${01100101100111110} += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABoAHQAbQBsAA=='))) }
   end {
      [xml]${00111100111101010} = ${01100101100111110} -replace '(?s).*<table[^>]*>(.*)</table>.*','<table>$1</table>'
      ${01100001000011111} = ${00111100111101010}.table.tr[0]  
      ${01010100110101011} = ${00111100111101010}.table.tr[1..${00111100111101010}.table.tr.Count]
      foreach(${01111001110100001} in ${01010100110101011}){ 
         ${00101101110010101} = @{}
         ${10101111110101010} = "th"
         if(!${01100001000011111}.th) {
            ${10101111110101010} = "td"
         }
         for(${11000000101000110}=0; ${11000000101000110} -lt ${01100001000011111}.(${10101111110101010}).Count; ${11000000101000110}++){
            if(${01100001000011111}.(${10101111110101010})[${11000000101000110}] -is [string]) {
               ${00101101110010101}.(${01100001000011111}.(${10101111110101010})[${11000000101000110}]) = ${01111001110100001}.td[${11000000101000110}]
            } else {
               ${00101101110010101}.(${01100001000011111}.(${10101111110101010})[${11000000101000110}].InnerText) = ${01111001110100001}.td[${11000000101000110}]
            }
         }
         Write-Verbose (${00101101110010101} | Out-String)
         ${00001000010110001} = New-Object PSCustomObject -Property ${00101101110010101} 
         if($TypeName) {
            ${00001000010110001}.PSTypeNames.Insert(0,$TypeName)
         }
         Write-Output ${00001000010110001}
      }
   }
}