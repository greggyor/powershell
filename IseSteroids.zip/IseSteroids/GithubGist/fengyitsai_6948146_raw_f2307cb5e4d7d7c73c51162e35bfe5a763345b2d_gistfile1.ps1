﻿#!/bin/bash
# if else
if [ 2 = 1 ] ;
then
	echo "2=1"
elif [ 2 = 3 ] ;
then
	echo "2=3"
else
	echo "else"
fi
# for loop
for word in "aaa" "bbb" "ccc" "ddd"
do
	echo $word
done
# while loop 
i=0
while [ $i -lt 5 ] ;
do
	echo $i
	((i++))
done
# until loop 
i=0
until [ $i -gt 4 ] ;
do
	echo $i
	((i++))
done
# switch
echo "press a key"
read key
case $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABrAGUAeQA='))) in
	[A-Z]) echo "Upper";;
	[a-z]) echo "Lower";;
	[0-9]) echo "Number";;
	*) echo "others"
esac
# list all file
for i in *
do
	if [ -f "$i" ] ; then
    	echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABpACAAaQBzACAAYQAgAHIAZQBnAHUAbABhAHIAIABmAGkAbABlAA==')))
    elif [ -d "$i" ] ; then
    	echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABpACAAaQBzACAAYQAgAGQAaQByAGUAYwB0AG8AcgB5AA==')))
	fi
done
function check() {
	if [ -f "$1" ] ; then
    	echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABpACAAaQBzACAAYQAgAHIAZQBnAHUAbABhAHIAIABmAGkAbABlAA==')))
    elif [ -d "$1" ] ; then
    	echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABpACAAaQBzACAAYQAgAGQAaQByAGUAYwB0AG8AcgB5AA==')))
	fi
}
for i in *
do
	check $i
done