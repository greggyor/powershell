﻿Param(
[string] $url = $(Read-Host -prompt "Enter Site Collection URL: ")
)
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin Microsoft.SharePoint.PowerShell
}
Write-Host " "
Write-Host "   Script provided by Summit 7 Systems for information/educational purposes only. Use at your own risk."
Write-Host "   http://s7sys.biz/restsearch         http://www.Summit7Systems.com"
Write-Host " "
$farmID=(Get-SPFarm).Id
$spSite=Get-SPSite $url
$siteColId=$spSite.Id
$topLevelSiteID=$spSite.RootWeb.Id
$rootWeb=$spSite.RootWeb
if($null -ne $rootWeb)
{
    $list=$rootWeb.Lists["QueryPropertiesTemplate"]
        if($null -eq $list)
        {
            $template=$rootWeb.ListTemplates["Document Library"]
            $list=$rootWeb.Lists[$rootWeb.Lists.Add("QueryPropertiesTemplate","QueryPropertiesTemplate",$template)]
        }
    $scriptFile = $MyInvocation.MyCommand.Definition
    [string]$currentSource = gc $scriptFile
    [int]$startScript=$currentSource.LastIndexOf("<QueryPropertiesTemplate");
    [int]$closeComment=$currentSource.LastIndexOf("#>");
    $xmlFile=[xml]($currentSource.Substring($startScript,$closeComment-$startScript))
    $xmlFile.QueryPropertiesTemplate.QueryProperties.FarmId=$farmID.ToString()
    $xmlFile.QueryPropertiesTemplate.QueryProperties.SiteId=$siteColId.ToString()
    $xmlFile.QueryPropertiesTemplate.QueryProperties.WebId=$topLevelSiteID.ToString()
    $xmlFile.OuterXml | Out-File queryparametertemplate.xml
    $tempFile=gi -LiteralPath "queryparametertemplate.xml"
    $folder = $list.RootFolder
    $stream=$tempFile.OpenRead()
    $file = $folder.Files.Add($folder.Url+"/queryparametertemplate.xml",$stream,$true, "created by script",$false)
    $stream.Close()
    if($null -ne $file)
    {
        Write-Host ("File Created At " + $rootWeb.Url + "/" + $file.Url)
    }
    Write-Host " "
}
