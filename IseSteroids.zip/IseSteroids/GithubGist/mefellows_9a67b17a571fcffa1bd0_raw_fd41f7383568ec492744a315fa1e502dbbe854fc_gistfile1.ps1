﻿

set-executionpolicy unrestricted
new-item alias:subl -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwBcAFMAdQBiAGwAaQBtAGUAIABUAGUAeAB0ACAAMwBcAHMAdQBiAGwAaQBtAGUAXwB0AGUAeAB0AC4AZQB4AGUA')))
new-item alias:ll -value 'ls'

