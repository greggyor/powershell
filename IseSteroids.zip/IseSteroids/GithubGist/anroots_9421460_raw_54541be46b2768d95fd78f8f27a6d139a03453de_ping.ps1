﻿








$NodeList = 11,12,13,14,15,16,17,18,24


$PingCount = 2


$TTL = 5



echo ""
date
echo "NODE status check started"
echo ""

$Percent = 10
$SuccessCounter = 0

foreach ($Node in $NodeList) {

    
    $IP = "10.54."+$Node+".62"

    
    write-progress -activity "Testing NODE Links..." -status "$Percent% complete" -percentcomplete $Percent -currentOperation "connecting to N$Node..."
    
    
    $IsOnline = test-connection ($IP) -count $PingCount -Quiet -TimeToLive $TTL
    
    if ($IsOnline) {
        echo "N$Node is UP"
        $SuccessCounter += 1
    } else {
        echo "N$Node is DOWN!"
    }
    
    $Percent += 10
}

echo "-----------------"


$NodeCount = $NodeList.length
$UPPercent = $SuccessCounter*100/$NodeList.length
echo "$SuccessCounter of $NodeCount UP ($UPPercent%)"