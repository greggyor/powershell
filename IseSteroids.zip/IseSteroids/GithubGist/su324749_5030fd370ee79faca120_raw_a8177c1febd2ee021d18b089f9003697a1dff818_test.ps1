﻿
# % gal -def foreach-object
# 
# CommandType     Name                               Definition
# -----------     ----                               ----------
# Alias           %                                  ForEach-Object
# Alias           foreach                            ForEach-Object
foreach (${10111110100110011} in 1..9) {
    foreach (${00000110111010011} in 1..9 ) {
      write-host ("{0:00}" -f (${10111110100110011}*${00000110111010011})).padright(3, " ") -nonewline
    }
    write-host
}
1..9 | % {
  ${10111110100110011} = $_; "$( 1..9 | % { "{0:000}" -f ($_*${10111110100110011}) } )"
}
1..9 | % {
  ${10111110100110011} = $_; "$( 1..9 | % { ("{0:000}" -f ($_ * ${10111110100110011})).padleft(4, "+") })"
}
