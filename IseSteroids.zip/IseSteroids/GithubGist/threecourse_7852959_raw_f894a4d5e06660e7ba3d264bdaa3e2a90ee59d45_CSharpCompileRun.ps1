﻿# ---------------------------------------------------------------------
# Powershellã‹ã‚‰C#ã‚³ãƒ¼ãƒ‰ã‚’ã‚³ãƒ³ãƒ‘ã‚¤ãƒ«ãƒ»å®Ÿè¡Œã™ã‚‹ã‚µãƒ³ãƒ—ãƒ« 
# 
# ï¼ˆå‚è€ƒï¼‰
# http://codezine.jp/article/detail/5007
#
# ï¼ˆæ³¨æ„ç‚¹ï¼‰
# .NET Frameworkã®åˆ¶ç´„ä¸Šã€Add-Typeã«ã‚ˆã‚‹åž‹ã®è¿½åŠ ã‚’å†å®Ÿè¡Œã™ã‚‹ã«ã¯ã€Powershellã®ã‚»ãƒƒã‚·ãƒ§ãƒ³ã‚’åˆ‡ã‚‹å¿…è¦ãŒã‚ã‚‹ã€‚
# ãã®ãŸã‚ã€Powershellã®ãƒ—ãƒ­ã‚»ã‚¹ã‚’ç«‹ã¡ä¸Šã’ã€ãã®ä¸­ã§ã‚³ãƒ³ãƒ‘ã‚¤ãƒ«ãƒ»å®Ÿè¡Œã™ã‚‹ã‚ˆã†ã«ã—ã¦ã„ã‚‹ã€‚
# ---------------------------------------------------------------------
# å¼•æ•°ã®å–å¾—
# Pythoné¢¨ã«ã€ãƒˆãƒƒãƒ—ãƒ¬ãƒ™ãƒ«ã§ã‚ã‚Œã°$moduleã«"__main__"ãŒå…¥ã‚‹ã‚ˆã†ã«ã—ã¦ã„ã‚‹ã€‚
# ä»–ã®Powershellãƒ—ãƒ­ã‚»ã‚¹ã‚’ç«‹ã¡ä¸Šã’ã‚‹ã¨ãã«ã¯ã€$moduleã«"called"ã‚’å…¥ã‚Œã‚‹ã‚ˆã†ã«ã™ã‚‹ã€‚
param([string]$module)
if($module -eq ""){ $module = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAG0AYQBpAG4AXwBfAA==')))}
# ã‚³ãƒ³ãƒ‘ã‚¤ãƒ«ãƒ»å®Ÿè¡Œã‚’è¡Œã†é–¢æ•°ã®å®šç¾©
function ComplieAndRun(){
  # CSharpã‚³ãƒ¼ãƒ‰ã®ã‚½ãƒ¼ã‚¹
$source=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGIAbABpAGMAIABjAGwAYQBzAHMAIABTAGEAbQBwAGwAZQBDAGwAYQBzAHMAewANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdABhAHQAaQBjACAAcwB0AHIAaQBuAGcAIABTAGEAeQBIAGUAbABsAG8AKABzAHQAcgBpAG4AZwAgAE4AYQBtAGUAKQANAAoAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAcgBlAHQAdQByAG4AIAAiAEgAZQBsAGwAbwAgACIAIAArACAATgBhAG0AZQA7AA0ACgAgACAAIAAgAH0ADQAKAH0A')))
  # CSharpã‚³ãƒ¼ãƒ‰ã®ã‚³ãƒ³ãƒ‘ã‚¤ãƒ«
  Add-Type -Language CSharpVersion3 -TypeDefinition $Source
  # CSharpã‚³ãƒ¼ãƒ‰ã®å®Ÿè¡Œ
  [SampleClass]::SayHello($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHIAbABkAA=='))))
}
# ãƒˆãƒƒãƒ—ãƒ¬ãƒ™ãƒ«ã§ãªã„å ´åˆã®ã¿ã€ã‚³ãƒ³ãƒ‘ã‚¤ãƒ«ãƒ»å®Ÿè¡Œã‚’è¡Œã†ã€‚
if($module -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAG0AYQBpAG4AXwBfAA==')))){
  ComplieAndRun
  [Console]::ReadKey() | Out-Null # å®Ÿè¡Œå¾Œå…¥åŠ›ã‚’å¾…ã¤
}
# ãƒˆãƒƒãƒ—ãƒ¬ãƒ™ãƒ«ã®å ´åˆã¯ã€åˆ¥ã®Powershellãƒ—ãƒ­ã‚»ã‚¹ã‚’ç«‹ã¡ä¸Šã’ã€è‡ªèº«ã®ã‚¹ã‚¯ãƒªãƒ—ãƒˆã‚’å‘¼ã³å‡ºã™ã€‚
if($module -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAG0AYQBpAG4AXwBfAA==')))){
  $path = '"' + $Script:MyInvocation.MyCommand.Path + '"'
  start-process powershell.exe -ArgumentList @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBGAGkAbABlAA=='))), $path, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBhAGwAbABlAGQA'))))
}
