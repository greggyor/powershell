﻿<# 
A more complete function can be found in my PowerCLI 'prod' repo at: 
https://github.com/vMotioned/PowerCLI/blob/master/Get-VMToolsBuildToVersionMapping.ps1
#>
Invoke-RestMethod -Method Get -Uri 'http://packages.vmware.com/tools/versions'