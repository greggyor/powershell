﻿
$id = 0;
ls -name |% {
  $old_filename = $_;
  $trailing = $($old_filename.Substring(0, 10));
  $leading = $_.Substring(11);
  $new_filename = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AXwB7ADEAOgAwADAAMAAwAH0AXwB7ADIAfQA='))) -f $trailing, $id, $leading
  move $old_filename $new_filename;
  $id += 1;
}