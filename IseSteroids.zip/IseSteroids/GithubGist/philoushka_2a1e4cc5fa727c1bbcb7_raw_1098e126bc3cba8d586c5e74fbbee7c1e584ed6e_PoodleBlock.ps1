﻿${3} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABDAG8AbgB0AHIAbwBsAFwAUwBlAGMAdQByAGkAdAB5AFAAcgBvAHYAaQBkAGUAcgBzAFwAUwBDAEgAQQBOAE4ARQBMAFwAUAByAG8AdABvAGMAbwBsAHMA')))
${5} = 2,3

ForEach (${2}  in ${5})
{
  ${4} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADMAfQBcAFMAUwBMACAAJAB7ADIAfQAuADAAXABTAGUAcgB2AGUAcgA=')))
  Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAJAB7ADQAfQA=')))
  New-Item -Path ${4} -ItemType Key -Force
  New-ItemProperty ${4} -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGEAYgBsAGUAZAA='))) -Value 0 -PropertyType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABXAG8AcgBkAA==')))

  ${1} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADMAfQBcAFMAUwBMACAAJAB7ADIAfQAuADAAXABDAGwAaQBlAG4AdAA=')))
  New-Item -Path ${1} -ItemType Key -Force
  New-ItemProperty ${1} -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAYQBiAGwAZQBkAEIAeQBEAGUAZgBhAHUAbAB0AA=='))) -Value 1 -PropertyType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABXAG8AcgBkAA==')))    
}


