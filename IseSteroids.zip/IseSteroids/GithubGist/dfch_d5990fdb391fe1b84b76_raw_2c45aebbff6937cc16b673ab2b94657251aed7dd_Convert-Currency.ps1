﻿

Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string] $From
	,
	[Parameter(Mandatory = $true, Position = 1)]
	[string] $To
	,
	[Parameter(Mandatory = $false, Position = 2)]
	[Alias("Amount")]
	[double] $Value = 1
	,
	[Parameter(Mandatory = $false, Position = 3)]
	[Alias("When")]
	[DateTime] $Date = [datetime]::Now
) 

${5} = 'http://www.oanda.com/currency/converter/update?base_currency_0={0}&quote_currency={1}&end_date={2}&view=details&id=1&action=C&';
[Uri] ${4} = ${5} -f $From, $To, $Date.ToString('yyyy-MM-dd');
${2} = irm -Uri ${4};
if($PSBoundParameters.ContainsKey('Value')) {
	(${2}.data.bid_ask_data | gm -Type Properties).Name | % { ${2}.data.bid_ask_data.$_ *= $Value; };
	for(${3} = 0; ${3} -lt ${2}.data.chart_data.Count; ${3}++) { ${2}.data.chart_data[${3}][-1] *= $Value; };
} 
${1} = [Ordered] @{};
(${2}.data.bid_ask_data | gm -Type Properties).Name | % { ${1}.Add($_, ${2}.data.bid_ask_data.$_); };

	
	

return ${1};


