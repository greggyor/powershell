﻿#Requires -Version 4
<#
.NOTES
    Created on:            	10/8/2014
    Created by:             Adam Bertram
    Filename:               Start-ModPollMonitor.ps1
	Requirements:			Share permissions for Everyone on destination share
							The source computer account Modify NTFS rights on destination folder
.DESCRIPTION
      
.EXAMPLE
    PS> .\Start-ModPollMonitor.ps1 

.PARAMETER SourceFolderPath
    This is the folder path on the local computer that will be monitored for 
	new files.
.PARAMETER DestinationHost
	The destination host that the file will be copied to
.PARAMETER DestinationFileShare
    The share name on the destination host where the file will be copied to
.PARAMETER FileExtension
    This is the file extension that, when placed into SourceFolderPath path
	will kick off the Modbus process.  This defaults to PDF.
.PARAMETER ModPollFilePath
	The file path where the modpoll.exe file is located
.PARAMETER FailureSourceFolderPath
	The path to the local folder that all failed modpoll files will be placed.
	This is only used if the file copy is unsuccessful.
.PARAMETER MonitorIntervalSecs
	The number of seconds between script runs.
.PARAMETER LogFilePath
	The file path to the log file that's generated with the progress of the
	script.  This defaults to C:\Windows\Temp\Start-ModPollMonitor.log
#>
[CmdletBinding(SupportsShouldProcess)]
param (
	[Parameter()]
	[ValidateScript({
		if (!(Test-Path -Path $_ -PathType Container)) {
			throw "The source folder path '$($_)' cannot be found"
		} else {
			$true
		}
	})]
	[string]$SourceFolderPath = 'C:\TestSourceFolder\folder',
	[Parameter()]
	[ValidateScript({
		if (!(Test-Connection -ComputerName $_ -Quiet -Count 1)) {
			throw "The destination host '$($_)' does not appear to be online"
		} else {
			$true
		}
	})]
	[string]$DestinationHost = 'labdc.lab.local',
	[Parameter()]
	[string]$DestinationFileShare = 'plcscript',
	[Parameter()]
	[ValidatePattern('^\w{3}$')]
	[string]$FileExtension = 'pdf',
	[ValidateScript({
		if (!(Test-Path -Path $_ -PathType Leaf)) {
			throw "Modpoll.exe cannot be found at '$($_)'"
		} else {
			$true
		}
	})]
	[string]$ModPollFilePath = 'C:\Users\administrator.LAB\Dropbox\Side Business\GitHubRepos\MiscScripts\PLCScript\Source\modpoll.exe',
	[ValidateScript({
		if (!(Test-Path -Path $_ -PathType Container)) {
			throw "The failure source folder path '$($_)' cannot be found"
		} else {
			$true
		}
	})]
	[string]$FailureSourceFolderPath = 'C:\FailureSourceFolder',
	[Parameter()]
	[int]$MonitorIntervalSecs = 10,
	[Parameter()]
	[string]$LogFilePath = "$([environment]::GetEnvironmentVariable($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABFAE0AUAA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGMAaABpAG4AZQA=')))))\Start-ModPollMonitor.log"
)
begin {
	function _01100001100101011 {
		<#
		.SYNOPSIS
			This function creates or appends a line to a log file

		.DESCRIPTION
			This function writes a log line to a log file
		.PARAMETER  Message
			The message parameter is the log message you'd like to record to the log file
		.PARAMETER  LogLevel
			The logging level is the severity rating for the message you're recording. 
			You have 3 severity levels available; 1, 2 and 3 from informational messages
			for FYI to critical messages. This defaults to 1.

		.EXAMPLE
			PS C:\> Write-Log -Message 'Value1' -LogLevel 'Value2'
			
			This example shows how to call the Write-Log function with named parameters.
		#>
		[CmdletBinding()]
		param (
			[Parameter(
					   Mandatory = $true)]
			[string]$Message,
			[Parameter()]
			[ValidateSet(1, 2, 3)]
			[int]$LogLevel = 1
		)
		try {
			${10110110100110011} = "$(Get-Date -Format HH:mm:ss).$((Get-Date).Millisecond)+000"
			## Build the line which will be recorded to the log file
			${01000111010101010} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAyAH0AIAB7ADEAfQA6ACAAewAwAH0A')))
			${00101011111011111} = $Message, ${10110110100110011}, (Get-Date -Format MM-dd-yyyy)
			${01000111010101010} = ${01000111010101010} -f ${00101011111011111}
			ac -Value ${01000111010101010} -Path $LogFilePath
		} catch {
			Write-Error $_.Exception.Message
		}
	}
	function Convert-ToUncPath($LocalFolderPath, $Computername) {
		${10011000110011100} = ($LocalFolderPath | Split-Path -Qualifier).TrimEnd(':')
		"\\$Computername\${10011000110011100}`$$($LocalFolderPath | Split-Path -NoQualifier)"
	}
	function _01100110010010011 ($PollNumber,$RegisterNumber) {
		_01100001100101011 -Message "Polling the Modbus slave with poll number $PollNumber"
		${00110110000010100} = saps -FilePath $ModPollFilePath -ArgumentList "-r$RegisterNumber localhost $PollNumber" -Wait -NoNewWindow -PassThru
		sleep -Seconds 2
		if (${00110110000010100}.ExitCode -ne 0) {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAGwAbAAgAHQAbwAgAG0AbwBkAGIAdQBzACAAcwBsAGEAdgBlACAAZgBhAGkAbABlAGQA'))) -LogLevel '3'
			$false
		} else {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAGwAbAAgAHQAbwAgAG0AbwBkAGIAdQBzACAAcwBsAGEAdgBlACAAcwB1AGMAYwBlAGUAZABlAGQA')))
			$true	
		}
	}
	function _10110001101000101 {
		_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBhAGwAaQBkAGEAdABpAG4AZwAgAHQAaABlACAATQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIABpAHMAIAByAHUAbgBuAGkAbgBnAA==')))
		${00110110000010100} = saps -FilePath $ModPollFilePath -ArgumentList "-r1 localhost $((get-date).Second)" -Wait -NoNewWindow -PassThru
		sleep -Seconds 2
		if (${00110110000010100}.ExitCode -ne 0) {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIABpAHMAIABuAG8AdAAgAHIAdQBuAG4AaQBuAGcA'))) -LogLevel '2'
			$false
		} else {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIABpAHMAIAByAHUAbgBuAGkAbgBnAA==')))
			$true	
		}
	}
	function _01000101001011110 {
		if (Test-Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAEUAdgBlAHIAZQBzAHQAXABUAG8AbwBsAHMAXABQAGUAYQBrAEgAbQBpAE0AQgBUAEMAUABTAGwAYQB2AGUALgBlAHgAZQA=')))) {
			saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAEUAdgBlAHIAZQBzAHQAXABUAG8AbwBsAHMAXABQAGUAYQBrAEgAbQBpAE0AQgBUAEMAUABTAGwAYQB2AGUALgBlAHgAZQA='))) -NoNewWindow
		} elseif (Test-Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwBcAEUAdgBlAHIAZQBzAHQAXABUAG8AbwBsAHMAXABQAGUAYQBrAEgAbQBpAE0AQgBUAEMAUABTAGwAYQB2AGUALgBlAHgAZQA=')))) {
			saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwBcAEUAdgBlAHIAZQBzAHQAXABUAG8AbwBsAHMAXABQAGUAYQBrAEgAbQBpAE0AQgBUAEMAUABTAGwAYQB2AGUALgBlAHgAZQA='))) -NoNewWindow
		}
		_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIABzAHQAYQByAHQAZQBkAA==')))
		if (!(_10110001101000101)) {
			throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAZQBtAHAAdABlAGQAIAB0AG8AIABzAHQAYQByAHQAIABNAG8AZABiAHUAcwAgAHMAbABhAHYAZQAgAGIAdQB0ACAAZgBhAGkAbABlAGQALgA=')))	
		} else {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGMAYwBlAHMAcwBmAHUAbABsAHkAIABzAHQAYQByAHQAZQBkACAAbQBvAGQAYgB1AHMAIABzAGwAYQB2AGUA')))
			$true
		}
	}
	function _10001011001110100 ($FilePath, $DestUncFolderPath) {
		_01100001100101011 -Message "Starting file copy of '$FilePath' to '$DestUncFolderPath'"
		${01110111000011010} = (Get-FileHash $FilePath).Hash
		_01100001100101011 -Message "Source hash for '$FilePath' is '${01110111000011010}'"
		cp -Path $FilePath -Destination $DestUncFolderPath
		${00110110110101000} = "$DestUncFolderPath\$($FilePath | Split-Path -Leaf)"
		${01100100101100000} = (Get-FileHash ${00110110110101000}).Hash
		_01100001100101011 -Message "Dest hash for '${00110110110101000}' is '${01100100101100000}'"
		if (${01110111000011010} -ne ${01100100101100000}) {
			_01100001100101011 -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHUAcgBjAGUAIABhAG4AZAAgAGQAZQBzAHQAaQBuAGEAdABpAG8AbgAgAGYAaQBsAGUAIABoAGEAcwBoACAAZABpAGYAZgBlAHIAIABwAG8AcwB0ACAAZgBpAGwAZQAtAGMAbwBwAHkALgAgACAAQwBvAHAAeQAgAGYAYQBpAGwAZQBkAC4A'))) -LogLevel '2'
			_01100001100101011 -Message "Moving $FilePath to $FailureSourceFolderPath" -LogLevel '2'
			mi -Path $FilePath -Destination $FailureSourceFolderPath -Force
		} else {
			_01100001100101011 -Message "Successfully copied file '$FilePath' to '$DestUncFolderPath' after 1 try"
			_01100110010010011 -PollNumber 2 -RegisterNumber 1
			_01100001100101011 -Message "Removing the file '$FilePath'"
			rd $FilePath -Force
		}
	}
	function _00101101110011011 {
		${00010111001111010} = "
 			SELECT * FROM __InstanceCreationEvent WITHIN $MonitorIntervalSecs 
 			WHERE targetInstance ISA 'CIM_DataFile' 
 			AND targetInstance.Drive = `"${10111000110010000}`"
			AND targetInstance.Path = `"$(${01100011000111011}.Replace('\','\\'))`"
			AND targetInstance.Extension = `"$FileExtension`""
		${01111101011100101} = @{
			'Class' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAEUAdgBlAG4AdABGAGkAbAB0AGUAcgA=')))
			'Namespace' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAHMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAA==')))
			'Arguments' = @{ Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcARgBpAGwAZQA='))); EventNameSpace = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAGMAaQBtAHYAMgA='))); QueryLanguage = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBRAEwA'))); Query = ${00010111001111010} }
		}
		${10110111001101001} = Set-WmiInstance @01111101011100101
		${00101011010011011} = @{
			'Class' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAHQAaQB2AGUAUwBjAHIAaQBwAHQARQB2AGUAbgB0AEMAbwBuAHMAdQBtAGUAcgA=')))
			'Namespace' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAHMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAA==')))
			'Arguments' = @{ Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHAAeQBGAGkAbABlAA=='))); ScriptFileName = ${01100011111000000}; ScriptingEngine = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBCAHMAYwByAGkAcAB0AA=='))) }
		}
		${00111111000000101} = Set-WmiInstance @00101011010011011
		${01001110010110001} = @{
			'Class' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBfAEYAaQBsAHQAZQByAFQAbwBDAG8AbgBzAHUAbQBlAHIAQgBpAG4AZABpAG4AZwA=')))
			'Namespace' = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAHMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAA==')))
			'Arguments' = @{ Filter = ${10110111001101001}; Consumer = ${00111111000000101} }
		}
		Set-WmiInstance @01001110010110001 | Out-Null
	}
	function _01011001011101110 {
		gwmi -Namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAHMAdQBiAHMAYwByAGkAcAB0AGkAbwBuAA=='))) -Class __FilterToConsumerBinding -Filter { Consumer = 'ActiveScriptEventConsumer.Name="CopyFile"' }
	}
	try {
		${10011000100101011} = $MyInvocation.MyCommand.Path | Split-Path -Parent
		${01100011111000000} = ls ${10011000100101011} -Filter *.vbs | select -ExpandProperty fullname
		${01100011000111011} = "$($SourceFolderPath | Split-Path -NoQualifier)\"
		${10111000110010000} = $SourceFolderPath | Split-Path -Qualifier
		if (${01100011111000000} -is [array]) {
			throw "Multiple VBS files located in '${10011000100101011}'. Only a single launch VBS should exist"
		}
	} catch {
		_01100001100101011 -Message "Error: $($_.Exception.Message) - Line Number: $($_.InvocationInfo.ScriptLineNumber)" -LogLevel '3'
		exit	
	}
}
process {
	try {
		if (!(_10110001101000101)) {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIABuAG8AdAAgAHIAdQBuAG4AaQBuAGcALgAgACAAQQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAHMAdABhAHIAdAA=')))
			_01000101001011110
		}
		if (!(_01011001011101110)) {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABmAGkAbABlACAAYwBvAHAAeQAgAG0AbwBuAGkAdABvAHIAIABoAGEAcwAgAG4AbwB0ACAAYgBlAGUAbgAgAGMAcgBlAGEAdABlAGQAIAB5AGUAdAAuACAAIABDAHIAZQBhAHQAaQBuAGcAIABuAG8AdwA=')))
			_00101101110011011
		#} elseif () {
		#	Write-Warning 'The file copy process is still running.  Skipping this time'
		#	exit
		}
		_01100110010010011 -PollNumber (Get-Date).Seconds -RegisterNumber 2
		${10000100010000100} = ls $SourceFolderPath -Filter "*.$FileExtension" -File
		if (${10000100010000100}) {
			_01100001100101011 -Message "Found $(${10000100010000100}.Count) files to attempt to copy."
			$DestUncFolderPath = "\\$DestinationHost\$DestinationFileShare"
			_01100001100101011 -Message "Destination folder path is '$DestUncFolderPath'"
			if (!(Test-Path $DestUncFolderPath)) {
				throw "Destination folder path '$DestUncFolderPath' does not exist on remote computer"
			}
			if (!(_01100110010010011 -PollNumber 1 -RegisterNumber 1)) {
				throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIABwAG8AbABsACAAbQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIAB3AGkAdABoACAAcABvAGwAbAAgAG4AdQBtAGIAZQByACAAMQA=')))
			}
			${10000100010000100} | foreach {
				_10001011001110100 -DestUncFolderPath $DestUncFolderPath -FilePath $_.FullName
			}
		} else {
			_01100001100101011 -Message "No $FileExtension files to process yet"
		}
		${01101110100000010} = ls $FailureSourceFolderPath -File
		if (${01101110100000010}) {
			_01100001100101011 -Message "Found $(${01101110100000010}.Count) failed file to attempt to copy."
			foreach (${01100010010100100} in ${01101110100000010}) {
				_10001011001110100 -DestUncFolderPath $DestUncFolderPath -FilePath ${01100010010100100}.FullName
			}
			${01101110100000010} = ls $FailureSourceFolderPath -File
			if (!${01101110100000010}) {
				_01100001100101011 -Message "Successfully copied all failed files from '$FailureSourceFolderPath'"
				if (!(_01100110010010011 -PollNumber 2 -RegisterNumber 1)) {
					throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIABwAG8AbABsACAAbQBvAGQAYgB1AHMAIABzAGwAYQB2AGUAIAB3AGkAdABoACAAcABvAGwAbAAgAG4AdQBtAGIAZQByACAAMgA=')))
				}
			} else {
				throw "Failed to copy all failed files from '$FailureSourceFolderPath'"
			}
		} else {
			_01100001100101011 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAcAByAGUAdgBpAG8AdQBzAGwAeQAgAGYAYQBpAGwAZQBkACAAZgBpAGwAZQAgAGMAbwBwAGkAZQBzACAAdABvACAAcAByAG8AYwBlAHMAcwA=')))
		}
	} catch {
		_01100001100101011 -Message "Error: $($_.Exception.Message) - Line Number: $($_.InvocationInfo.ScriptLineNumber)" -LogLevel '3'
	}
}