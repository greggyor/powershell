﻿# [int] ã‚«ãƒ¬ãƒ³ãƒˆãƒ‘ã‚¹ã®ãƒ•ã‚©ãƒ«ãƒ€ã‚µã‚¤ã‚º
(ls -Recurse -Force | measure -Sum Length).Sum
# [string, int][] ã‚«ãƒ¬ãƒ³ãƒˆãƒ‘ã‚¹é…ä¸‹ã«å­˜åœ¨ã™ã‚‹å„ãƒ•ã‚©ãƒ«ãƒ€ã®ã‚µã‚¤ã‚º
ls | select Name,@{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHoAZQA=')));expression={(ls $_.FullName -Recurse -Force | measure Length -Sum).Sum}}