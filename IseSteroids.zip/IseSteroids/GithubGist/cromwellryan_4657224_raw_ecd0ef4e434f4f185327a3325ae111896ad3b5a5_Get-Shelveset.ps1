﻿[Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client")
[Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Common")
$script:tpcUrl "your tpc"
function Get-ShelvsetUrl {
<# 
  .Synopsis
    Determines the url for a TFS Shelveset.

  .Description
    Determine the url for a TFS Shelveset and, optionally, copy or open the result.

  .Parameter Name
    The name of the Shelvset.

  .Parameter Owner
    The username of the Shelveset Owner.

  .Parameter Launch
    When true, the shelveset url will be opened in the default browser.  Default: False.

  .Parameter Copy
    When true, the shelveset url will be placed in clipboard.  Default: True.

  .Example
    get-shelveseturl -Shelveset "RDS - Profiling" -Owner "dev\\rcromwell"
    Gets the shelvset url and places it in the clipboard.

  .Example
    get-shelveset "RDS - Profiling" "dev\\rcromwell" -Launch -Copy $false
    Gets the shelvset url and places it in the clipboard.  Uses position relative parameters for -Name and -Owner
    Publishing a public Gist
#>
  Param(
    [Parameter(Position=0)]
    $Name = (read-host "Shelveset"), 
    [Parameter(Position=1)]
    $Owner = (read-host "Owner"), 
    [switch]$Launch = $false, 
    [switch]$Copy = $true
  ) 
  PROCESS {
    ${_/====\/\_/===\_/} = New-Object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $tpcUrl
    ${____/==\_/===\/\_} = ${_/====\/\_/===\_/}.GetService([Microsoft.TeamFoundation.Client.TswaClientHyperlinkService])
    ${_____/\_/==\_/\__} = ${____/==\_/===\/\_}.GetShelvesetDetailsUrl($Name, $Owner)
    ${_/\/\_____/\/\/\_} = ${_____/\_/==\_/\__}.AbsoluteUri
    if($Launch) { start ${_/\/\_____/\/\/\_} }
    if($Copy) { ${_/\/\_____/\/\/\_} | clip }
    ${_/\/\_____/\/\/\_}
  }
}
