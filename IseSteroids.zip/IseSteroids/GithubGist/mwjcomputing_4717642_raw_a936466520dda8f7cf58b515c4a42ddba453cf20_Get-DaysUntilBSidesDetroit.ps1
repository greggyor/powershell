﻿function Get-DaysUntilBSidesDetroit {
  Write-Host "There are $((New-Timespan -end $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAvADcALwAyADAAMQAzACAAOQA6ADAAMAA6ADAAMABBAE0A')))).Days) days until BSidesDetroit."
}

