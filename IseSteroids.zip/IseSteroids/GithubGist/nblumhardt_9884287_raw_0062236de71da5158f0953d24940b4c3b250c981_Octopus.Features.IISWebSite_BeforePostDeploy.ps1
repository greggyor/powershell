﻿## --------------------------------------------------------------------------------------
## Configuration
## --------------------------------------------------------------------------------------

$ConfirmPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAG4AZQA=')))

${34} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEMAcgBlAGEAdABlAE8AcgBVAHAAZABhAHQAZQBXAGUAYgBTAGkAdABlAA==')))]
if (!${34} -or ![Bool]::Parse(${34}))
{
   exit 0
}

${1} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAFcAZQBiAFMAaQB0AGUATgBhAG0AZQA=')))]
${3} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgBQAG8AbwBsAE4AYQBtAGUA')))]
${29} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEIAaQBuAGQAaQBuAGcAcwA=')))]
${14} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgBQAG8AbwBsAEYAcgBhAG0AZQB3AG8AcgBrAFYAZQByAHMAaQBvAG4A')))]
${10} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAFcAZQBiAFIAbwBvAHQA')))]
${4} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEUAbgBhAGIAbABlAFcAaQBuAGQAbwB3AHMAQQB1AHQAaABlAG4AdABpAGMAYQB0AGkAbwBuAA==')))]
${5} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEUAbgBhAGIAbABlAEIAYQBzAGkAYwBBAHUAdABoAGUAbgB0AGkAYwBhAHQAaQBvAG4A')))]
${6} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEUAbgBhAGIAbABlAEEAbgBvAG4AeQBtAG8AdQBzAEEAdQB0AGgAZQBuAHQAaQBjAGEAdABpAG8AbgA=')))]
${16} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgBQAG8AbwBsAEkAZABlAG4AdABpAHQAeQBUAHkAcABlAA==')))]
${18} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgBQAG8AbwBsAFUAcwBlAHIAbgBhAG0AZQA=')))]
${17} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAEEAcABwAGwAaQBjAGEAdABpAG8AbgBQAG8AbwBsAFAAYQBzAHMAdwBvAHIAZAA=')))]

if (! ${10}) {
	${10} = "."
}

${30} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAE0AYQB4AFIAZQB0AHIAeQBGAGEAaQBsAHUAcgBlAHMA')))]
if (${30} -Match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAGQAKwAkAA==')))) {
    ${30} = [int]${30}
} else {
    ${30} = 5
}

${33} = $OctopusParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBjAHQAbwBwAHUAcwAuAEEAYwB0AGkAbwBuAC4ASQBJAFMAVwBlAGIAUwBpAHQAZQAuAFMAbABlAGUAcABCAGUAdAB3AGUAZQBuAFIAZQB0AHIAeQBGAGEAaQBsAHUAcgBlAHMASQBuAFMAZQBjAG8AbgBkAHMA')))]
if (${33} -Match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgBcAGQAKwAkAA==')))) {
    ${33} = [int]${33}
} else {
    ${33} = Get-Random -minimum 1 -maximum 4
}

if (${33} -gt 60) {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAFMAbABlAGUAcAAgAHQAaQBtAGUAIABiAGUAdAB3AGUAZQBuACAAZgBhAGkAbAB1AHIAZQBzAC4AIAAgAFMAZQB0AHQAaQBuAGcAIAB0AG8AIABtAGEAeAAgAG8AZgAgADYAMAAgAHMAZQBjAG8AbgBkAHMA')))
    ${33} = 60
}

# Helper to run a block with a retry if things go wrong
function Execute-WithRetry([ScriptBlock] ${f1}) {
	${31} = 0
	${32} = $true

	while (${32} -and ${31} -lt ${30}) {
		${31} = (${31} + 1)

		if (${31} -ge 2) {
			echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAJAB7ADMAMwB9ACAAcwBlAGMAbwBuAGQAcwAgAGIAZQBmAG8AcgBlACAAcgBlAHQAcgB5AGkAbgBnAC4ALgAuAA==')))
			sleep -s ${33}
			echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHQAcgB5AGkAbgBnAC4ALgAuAA==')))
		}

		try {
			& ${f1}

			${32} = $false
		} catch [System.Exception] {
			if (${31} -lt (${30})) {
				echo ($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAZQBtAHAAdAAgACQAewAzADEAfQAgAG8AZgAgACQAewAzADAAfQAgAGYAYQBpAGwAZQBkADoAIAA='))) + $_.Exception.Message)
			} else {
				throw
			}
		}
	}
}

${10} = (resolve-path ${10})

${8} = new-object System.Collections.ArrayList

# Each binding string consists of a protocol/binding information (IP, port, hostname)/SSL thumbprint/enabled
# Binding strings are pipe (|) separated to allow multiple to be specified
${29}.Split("|") | foreach-object {
    ${25} = $_.split("/")
	${28} = $false
	if (${25}.Length -ge 4) {
		if (![String]::IsNullOrEmpty(${25}[3]) -and [Bool]::Parse(${25}[3]) -eq $false) {
			${28} = $true
		}
	}

	if (${28} -eq $false) {
	    ${8}.Add(@{ protocol=${25}[0];bindingInformation=${25}[1];thumbprint=${25}[2] }) | Out-Null
	} else {
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBnAG4AbwByAGUAIABiAGkAbgBkAGkAbgBnADoAIAAkAF8A')))
	}
}

ipmo WebAdministration

# For any HTTPS bindings, ensure the certificate is configured for the IP/port combination
${8} | where-object { $_.protocol -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzAA=='))) } | foreach-object {
    ${27} = $_.thumbprint.Trim()
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAG4AZABpAG4AZwAgAFMAUwBMACAAYwBlAHIAdABpAGYAaQBjAGEAdABlACAAdwBpAHQAaAAgAHQAaAB1AG0AYgBwAHIAaQBuAHQAIAAkAHsAMgA3AH0A')))
    
    ${20} = ls Cert:\LocalMachine -Recurse | ? { $_.Thumbprint -eq ${27} -and $_.HasPrivateKey -eq $true } | select -first 1
    if (! ${20}) 
    {
        throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABmAGkAbgBkACAAYwBlAHIAdABpAGYAaQBjAGEAdABlACAAdQBuAGQAZQByACAAQwBlAHIAdAA6AFwATABvAGMAYQBsAE0AYQBjAGgAaQBuAGUAIAB3AGkAdABoACAAdABoAHUAbQBiAHAAcgBpAG4AdAAgACQAewAyADcAfQAuACAATQBhAGsAZQAgAHMAdQByAGUAIAB0AGgAYQB0ACAAdABoAGUAIABjAGUAcgB0AGkAZgBpAGMAYQB0AGUAIABpAHMAIABpAG4AcwB0AGEAbABsAGUAZAAgAHQAbwAgAHQAaABlACAATABvAGMAYQBsACAATQBhAGMAaABpAG4AZQAgAGMAbwBuAHQAZQB4AHQAIABhAG4AZAAgAHQAaABhAHQAIAB0AGgAZQAgAHAAcgBpAHYAYQB0AGUAIABrAGUAeQAgAGkAcwAgAGEAdgBhAGkAbABhAGIAbABlAC4A')))
    }

    Write-Host ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkACAAYwBlAHIAdABpAGYAaQBjAGEAdABlADoAIAA='))) + ${20}.Subject)

    ${26} = $_.bindingInformation
    ${25} = ${26}.split(':')
    ${24} = ${25}[0]
    if ((! ${24}) -or (${24} -eq '*')) {
        ${24} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAuADAALgAwAC4AMAA=')))
    }
    ${23} = ${25}[1]

    ${21} = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAFMAcwBsAEIAaQBuAGQAaQBuAGcAcwBcAA=='))) + ${24} + "!" + ${23})

	Execute-WithRetry { 
		${22} = get-item ${21} -ErrorAction SilentlyContinue
		if (! ${22}) {
			ni ${21} -Value ${20} -confirm:$false -Force | Out-Null
		} else {
			si ${21} -Value ${20} | Out-Null
		}		
	}
}

## --------------------------------------------------------------------------------------
## Run
## --------------------------------------------------------------------------------------

pushd IIS:\

${15} = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAEEAcABwAFAAbwBvAGwAcwBcAA=='))) + ${3})

Execute-WithRetry { 
	${19} = gi ${15} -ErrorAction SilentlyContinue
	if (!${19}) { 
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuACAAcABvAG8AbAAgACIAJAB7ADMAfQAiACAAZABvAGUAcwAgAG4AbwB0ACAAZQB4AGkAcwB0ACwAIABjAHIAZQBhAHQAaQBuAGcALgAuAC4A'))) 
		new-item ${15} -confirm:$false -Force
		${19} = gi ${15}
	} else {
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuACAAcABvAG8AbAAgACIAJAB7ADMAfQAiACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdABzAA==')))
	}
}

Execute-WithRetry { 
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAIABhAHAAcABsAGkAYwBhAHQAaQBvAG4AIABwAG8AbwBsACAAaQBkAGUAbgB0AGkAdAB5ADoAIAAkAHsAMQA2AH0A')))
	if (${16} -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBwAGUAYwBpAGYAaQBjAFUAcwBlAHIA')))) {
		sp ${15} -name processModel -value @{identitytype=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBwAGUAYwBpAGYAaQBjAFUAcwBlAHIA'))); username=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAOAB9AA=='))); password=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEANwB9AA==')))}
	} else {
		sp ${15} -name processModel -value @{identitytype=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEANgB9AA==')))}
	}
}

Execute-WithRetry { 
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAIAAuAE4ARQBUACAAZgByAGEAbQBlAHcAbwByAGsAIAB2AGUAcgBzAGkAbwBuADoAIAAkAHsAMQA0AH0A'))) 
	sp ${15} managedRuntimeVersion ${14}
}

${9} = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAFMAaQB0AGUAcwBcAA=='))) + ${1})

Execute-WithRetry { 
	${13} = gi ${9} -ErrorAction SilentlyContinue
	if (!${13}) { 
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQAgACIAJAB7ADEAfQAiACAAZABvAGUAcwAgAG4AbwB0ACAAZQB4AGkAcwB0ACwAIABjAHIAZQBhAHQAaQBuAGcALgAuAC4A'))) 
		${12} = (dir iis:\sites | foreach {$_.id} | sort -Descending | select -first 1) + 1
		new-item ${9} -bindings @{protocol=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA=')));bindingInformation=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgA4ADEAOgBvAGQALQB0AGUAbQBwAC4AZQB4AGEAbQBwAGwAZQAuAGMAbwBtAA==')))} -id ${12} -physicalPath ${10} -confirm:$false -Force
	} else {
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQAgACIAJAB7ADEAfQAiACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdABzAA==')))
	}
}

${11} = { 
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBzAHMAaQBnAG4AaQBuAGcAIAB3AGUAYgBzAGkAdABlACAAdABvACAAYQBwAHAAbABpAGMAYQB0AGkAbwBuACAAcABvAG8AbAAuAC4ALgA=')))
	sp ${9} -name applicationPool -value ${3}
}
Execute-WithRetry -f1 ${11}

Execute-WithRetry { 
	Write-Host ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABvAG0AZQAgAGQAaQByAGUAYwB0AG8AcgB5ADoAIAA='))) + ${10})
	sp ${9} -name physicalPath -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAMAB9AA==')))
}

Execute-WithRetry { 
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBzAHMAaQBnAG4AaQBuAGcAIABiAGkAbgBkAGkAbgBnAHMAIAB0AG8AIAB3AGUAYgBzAGkAdABlAC4ALgAuAA==')))
	clp ${9} -name bindings
	for (${7} = 0; ${7} -lt ${8}.Count; ${7} = ${7}+1) {
		Write-Host ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBpAG4AZABpAG4AZwA6ACAA'))) + (${8}[${7}].protocol + " " + ${8}[${7}].bindingInformation + " " + ${8}[${7}].thumbprint))
		New-ItemProperty ${9} -name bindings -value (${8}[${7}]) -Force
	}
}

try {
	Execute-WithRetry { 
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBuAG8AbgB5AG0AbwB1AHMAIABhAHUAdABoAGUAbgB0AGkAYwBhAHQAaQBvAG4AIABlAG4AYQBiAGwAZQBkADoAIAAkAHsANgB9AA==')))
		Set-WebConfigurationProperty -filter /system.webServer/security/authentication/anonymousAuthentication -name enabled -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADYAfQA='))) -location ${1} -PSPath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAA==')))
	}

	Execute-WithRetry { 
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAHMAaQBjACAAYQB1AHQAaABlAG4AdABpAGMAYQB0AGkAbwBuACAAZQBuAGEAYgBsAGUAZAA6ACAAJAB7ADUAfQA=')))
		Set-WebConfigurationProperty -filter /system.webServer/security/authentication/basicAuthentication -name enabled -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADUAfQA='))) -location ${1} -PSPath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAA==')))
	}

	Execute-WithRetry { 
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgAGEAdQB0AGgAZQBuAHQAaQBjAGEAdABpAG8AbgAgAGUAbgBhAGIAbABlAGQAOgAgACQAewA0AH0A')))
		Set-WebConfigurationProperty -filter /system.webServer/security/authentication/windowsAuthentication -name enabled -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQA='))) -location ${1} -PSPath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAOgBcAA==')))
	}
} catch [System.Exception] {
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB1AHQAaABlAG4AdABpAGMAYQB0AGkAbwBuACAAbwBwAHQAaQBvAG4AcwAgAGMAbwB1AGwAZAAgAG4AbwB0ACAAYgBlACAAcwBlAHQALgAgAFQAaABpAHMAIABjAGEAbgAgAGgAYQBwAHAAZQBuACAAdwBoAGUAbgAgAHQAaABlAHIAZQAgAGkAcwAgAGEAIABwAHIAbwBiAGwAZQBtACAAdwBpAHQAaAAgAHkAbwB1AHIAIABhAHAAcABsAGkAYwBhAHQAaQBvAG4AJwBzACAAdwBlAGIALgBjAG8AbgBmAGkAZwAuACAARgBvAHIAIABlAHgAYQBtAHAAbABlACwAIAB5AG8AdQAgAG0AaQBnAGgAdAAgAGIAZQAgAHUAcwBpAG4AZwAgAGEAIABzAGUAYwB0AGkAbwBuACAAdABoAGEAdAAgAHIAZQBxAHUAaQByAGUAcwAgAGEAbgAgAGUAeAB0AGUAbgBzAGkAbwBuACAAdABoAGEAdAAgAGkAcwAgAG4AbwB0ACAAaQBuAHMAdABhAGwAbABlAGQAIABvAG4AIAB0AGgAaQBzACAAdwBlAGIAIABzAGUAcgB2AGUAcgAgACgAcwB1AGMAaAAgAGEAcwAgAFUAUgBMACAAUgBlAHcAcgB0AGkAdABpAG4AZwApAC4AIABJAHQAIABjAGEAbgAgAGEAbABzAG8AIABoAGEAcABwAGUAbgAgAHcAaABlAG4AIAB5AG8AdQAgAGgAYQB2AGUAIABzAGUAbABlAGMAdABlAGQAIABhAG4AIABhAHUAdABoAGUAbgB0AGkAYwBhAHQAaQBvAG4AIABvAHAAdABpAG8AbgAgAGEAbgBkACAAdABoAGUAIABhAHAAcAByAG8AcAByAGkAYQB0AGUAIABJAEkAUwAgAG0AbwBkAHUAbABlACAAaQBzACAAbgBvAHQAIABpAG4AcwB0AGEAbABsAGUAZAAgACgAZgBvAHIAIABlAHgAYQBtAHAAbABlACwAIABmAG8AcgAgAFcAaQBuAGQAbwB3AHMAIABhAHUAdABoAGUAbgB0AGkAYwBhAHQAaQBvAG4ALAAgAHkAbwB1ACAAbgBlAGUAZAAgAHQAbwAgAGUAbgBhAGIAbABlACAAdABoAGUAIABXAGkAbgBkAG8AdwBzACAAQQB1AHQAaABlAG4AdABpAGMAYQB0AGkAbwBuACAAbQBvAGQAdQBsAGUAIABpAG4AIABJAEkAUwAvAFcAaQBuAGQAbwB3AHMAIABmAGkAcgBzAHQAKQA=')))
	throw
}

# It can take a while for the App Pool to come to life (#490)
sleep -s 1

Execute-WithRetry { 
	${2} = Get-WebAppPoolState ${3}
	if (${2}.Value -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcABwAGUAZAA=')))) {
		Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuACAAcABvAG8AbAAgAGkAcwAgAHMAdABvAHAAcABlAGQALgAgAEEAdAB0AGUAbQBwAHQAaQBuAGcAIAB0AG8AIABzAHQAYQByAHQALgAuAC4A')))
		Start-WebAppPool ${3}
	}
}

Execute-WithRetry { 
	${2} = Get-WebsiteState ${1}
	if (${2}.Value -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcABwAGUAZAA=')))) {
		Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBlAGIAIABzAGkAdABlACAAaQBzACAAcwB0AG8AcABwAGUAZAAuACAAQQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAHMAdABhAHIAdAAuAC4ALgA=')))
		Start-Website ${1}
	}
}

popd

Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBJAFMAIABjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuACAAYwBvAG0AcABsAGUAdABlAA==')))


