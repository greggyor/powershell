﻿
Import-Module WebAdministration
${10000011110000010} = Get-WebAppPoolState $appPoolName
if (${10000011110000010}.Value -eq "Stopped")
{
    Write-Host "Service is already stopped"
}
else
{
    Stop-WebAppPool $appPoolName
    Write-Host "Application pool is stopped"
}
