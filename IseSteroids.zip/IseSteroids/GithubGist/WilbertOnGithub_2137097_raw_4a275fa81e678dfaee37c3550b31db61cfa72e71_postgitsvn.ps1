﻿# Script that cleans up an entire directory with Git repositories 
# that have been imported from Subversion using the 'git svn clone'
# command.
# It does the following:
# - Recurses through all subdirectory in the directory you specify.
# For each git repository in a subdirectory:
# - Parses all tags from the remote branches and creates explicit 
#   git tags.
# - Parses all other remote branches and creates local branches
#   from them.
# Basically, it follows the workflow as described here on StackOverflow 
# http://stackoverflow.com/a/3972103/33671
# This script assumes that git is in your path.
Param
(
	[Parameter(Mandatory = $True)]
	[string]$DirectoryWithGitRepositories
)
# Strip all leading whitespace from the 'git branch -r' command.
function f8([array]${f1})
{
	${6}=@()
	foreach (${3} in ${f1})
	{
		${3} = ${3} -replace "^\s*", ""
		${6} = ${6} + ${3}
	}
	return ${6}
}
# Retrieve all branches that should become tags.
function f6 ([array]${f1})
{
	${f2} = @{}
	foreach (${3} in ${f1})
	{
		if (${3} -match "tags/(.*)")
		{
			# Remove %20 characters and make everything lowercase
			${5} = $matches[1] -replace "%20", "-"
			${f2}[${3}] = ${5}.ToLower()
		}
	}
	return ${f2}
}
# Retrieve all branches that are *not* tags.
# Discard default 'trunk' branch
function f4 ([array]${f1})
{
	${f3} = @{}
	foreach (${3} in ${f1})
	{
		if (${3} -match "^tags/" -or ${3} -eq "trunk") 
		{
			# Nothing
		}
		else
		{
			${4} = "remotes/" + ${3}
			${f3}[${4}] = ${3}
		}
	}
	return ${f3}
}
# Actually create the local branches
function f5(${f3})
{
	Write-Host "Found" ${f3}.Count "branches in remote."
	if (${f3}.Count -gt 0)
	{
		Write-Host "Creating local branches..."
		${f3}.GetEnumerator() | Foreach-Object { 
			Write-Host "git branch" $_.Value $_.Key
			git branch $_.Value $_.Key
			Write-Host
		}
	}
	Write-Host
}
# Actually create the local tags
function f7 (${f2})
{
	Write-Host "Found" ${f2}.Count "tagbranches in remote"
	if (${f2}.Count -gt 0)
	{
		Write-Host "Creating local tags..."
		${f2}.GetEnumerator() | Foreach-Object {		
			Write-Host "git branch" $_.Value $_.Key
			git branch $_.Value $_.Key
			Write-Host "git tag" $_.Value $_.Value
			git tag $_.Value $_.Value
			Write-Host "git branch -D" $_.Value
			git branch -D $_.Value
			Write-Host
		}
	}
}
# The fun starts here...
${2} = ls -Path $DirectoryWithGitRepositories
foreach (${1} in ${2})
{
	if (${1}.Attributes -eq "Directory")
	{
		Write-Host "Switching to" ${1}.FullName
		pushd ${1}.FullName
		[array]${f1} = git branch -r
		${f1} = f8 (${f1})
		f7 (f6 (${f1}))
		f5 (f4 (${f1}))
		popd
	}
}
Write-Host "Done."
