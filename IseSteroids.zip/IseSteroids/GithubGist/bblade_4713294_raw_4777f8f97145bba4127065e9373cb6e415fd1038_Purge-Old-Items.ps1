﻿
$HomeFolder = "C:\TEMP"
$KeepDays = "-1"
$Date = Get-Date
$PurgeDays = $Date.AddDays($KeepDays)


Get-ChildItem $HomeFolder -Recurse | `
Where-Object { $_.CreatedTime -lt $PurgeDays } | `
Remove-Item -Recurse


