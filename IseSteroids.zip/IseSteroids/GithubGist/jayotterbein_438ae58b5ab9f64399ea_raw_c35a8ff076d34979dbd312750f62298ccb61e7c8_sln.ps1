﻿Function sln
{
    [string[]]${00111010111101000} = @(gci HKLM:\Software\Microsoft\VisualStudio\) |% { $_.Name } |% { Split-Path $_ -Leaf }
    ${00010100111100000} = @()
    foreach (${00100010000110010} in ${00111010111101000})
    {
        [Version]${00001110111101101} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAuADAA')))
        if ([Version]::TryParse(${00100010000110010}, [ref]${00001110111101101}))
        {
            ${00010100111100000} += ${00001110111101101}
        }
    }
    ${00010100111100000} = ${00010100111100000} | sort -Descending
    ${10111011000101011} = ${00010100111100000}[0]
    ${00101001110111100} = (Join-Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwATQBpAGMAcgBvAHMAbwBmAHQAXABWAGkAcwB1AGEAbABTAHQAdQBkAGkAbwBcAA=='))) (${10111011000101011}.ToString()))
    ${10101010101111110} = (gp ${00101001110111100}).InstallDir
    ${00001101001001010} = (Join-Path ${10101010101111110} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAHYAZQBuAHYALgBlAHgAZQA='))))
    if (!(Test-Path ${00001101001001010}))
    {
        Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGEAYgBsAGUAIAB0AG8AIABsAG8AYwBhAHQAZQAgAGQAZQB2AGUAbgB2ADoAIAAkAHsAMAAwADAAMAAxADEAMAAxADAAMAAxADAAMAAxADAAMQAwAH0A')))
    }
    else
    {
        ${10101101101010111} = rvpa '.'
        if (gcm $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQALQBHAGkAdABEAGkAcgBlAGMAdABvAHIAeQA='))) -ErrorAction SilentlyContinue)
        {
            ${00001011110100000} = Get-GitDirectory
            if ((-not [string]::IsNullOrEmpty(${00001011110100000})) -and (Test-Path ${00001011110100000}))
            {
                ${10101101101010111} = rvpa (Split-Path (${00001011110100000}))
            }
        }

        ${01001111001111001} = @(gci ${10101101101010111} *.sln -Recurse)
        if (${01001111001111001}.Count -eq 0)
        {
            Write-Error $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGEAYgBsAGUAIAB0AG8AIABmAGkAbgBkACAAYQBuAHkAIABzAG8AbAB1AHQAaQBvAG4AIABmAGkAbABlAHMAIABpAG4AIAAkAHsAMQAwADEAMAAxADEAMAAxADEAMAAxADAAMQAwADEAMQAxAH0A')))
        }
        else
        {
            ${01100011101101010} = rvpa ${01001111001111001}[0].FullName
            Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgBpAG4AZwAgAGYAaQByAHMAdAAgAHMAbwBsAHUAdABpAG8AbgAgAGYAaQBsAGUAOgAgACQAewAwADEAMQAwADAAMAAxADEAMQAwADEAMQAwADEAMAAxADAAfQA=')))
            pushd (Split-Path ${01100011101101010})
            & ${00001101001001010} ${01100011101101010}
            popd
        }
    }
}

