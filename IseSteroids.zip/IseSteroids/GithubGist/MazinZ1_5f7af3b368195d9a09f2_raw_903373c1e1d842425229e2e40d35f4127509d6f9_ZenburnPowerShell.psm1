﻿
function New-ZenburnPowerShell {
    param (
        [string]$Name = $(throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQAgAHIAZQBxAHUAaQByAGUAZAAuAA=='))))
    )
    ${_/===\___/=\_/\__} = Join-Path $home "Desktop\$Name.lnk"
    ${/===\_/\/=\/=\___} = Join-Path HKCU:\Console $Name
    if (Test-Path ${_/===\___/=\_/\__}) {
        rd ${_/===\___/=\_/\__}
    }
    if (Test-Path ${/===\_/\/=\/=\___}) {
        rd ${/===\_/\/=\/=\___}
    }
    __/=\__/=\_/\_/=\/ ${_/===\___/=\_/\__}
    ___/==\__/==\___/\ ${/===\_/\/=\/=\___}
    if (-not ${script:_/\______/==\/=\/}) {
        ${script:_/\______/==\/=\/} = @()
    }
    ${script:_/\______/==\/=\/} += ${/===\_/\/=\/=\___}
    "Change properties on `"$Name`" to internalise the registry values."
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAbgAgAGMAYQBsAGwAIABSAGUAcwBlAHQALQBSAGUAZwBpAHMAdAByAHkAIAB0AG8AIABwAGUAcgBmAG8AcgBtACAAdABoAGUAIABmAGkAbgBhAGwAIABjAGwAZQBhAG4AdQBwAC4A')))
}
function Reset-Registry {
    foreach (${/===\_/\/=\/=\___} in ${script:_/\______/==\/=\/}) {
        if (Test-Path ${/===\_/\/=\/=\___}) {
            rd ${/===\_/\/=\/=\___}
            "Removed `"${/===\_/\/=\/=\___}`""
        }
    }
}
function __/=\__/=\_/\_/=\/ {
    param (
        [string]$Path
    )
    ${_____/=\___/\/===} = New-Object -ComObject wscript.shell
    ${_/\/====\/\/====\} = ${_____/=\___/\/===}.CreateShortcut($Path)
    ${_/\/====\/\/====\}.TargetPath = Join-Path $Env:windir System32\WindowsPowerShell\v1.0\powershell.exe
    ${_/\/====\/\/====\}.WorkingDirectory = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQBIAE8ATQBFAEQAUgBJAFYARQAlACUASABPAE0ARQBQAEEAVABIACUA')))
    ${_/\/====\/\/====\}.Save()
    "Created `"$Path`""
}
function ___/==\__/==\___/\ {
    param (
        [string]$Path
    )
    ${_/\/====\/\__/=\/} = ni $Path
    ${__/\/\/\_/\/\/\_/} = @(
        0x003f3f3f, 0x00af6464, 0x00008000, 0x00808000,
        0x00232333, 0x00aa50aa, 0x0000dcdc, 0x00ccdcdc,
        0x008080c0, 0x00ffafaf, 0x007f9f7f, 0x00d3d08c,
        0x007071e3, 0x00c880c8, 0x00afdff0, 0x00ffffff
    )
    for (${_/\/\/=====\/==\/} = 0; ${_/\/\/=====\/==\/} -lt ${__/\/\/\_/\/\/\_/}.Length; ${_/\/\/=====\/==\/}++) {
        ${_/\/====\/\__/=\/} = New-ItemProperty $Path -Name ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAGwAbwByAFQAYQBiAGwAZQA='))) + ${_/\/\/=====\/==\/}.ToString("00")) -PropertyType DWORD -Value ${__/\/\/\_/\/\/\_/}[${_/\/\/=====\/==\/}]
    }
    "Created `"$Path`""
}
Export-ModuleMember New-ZenburnPowerShell, Reset-Registry