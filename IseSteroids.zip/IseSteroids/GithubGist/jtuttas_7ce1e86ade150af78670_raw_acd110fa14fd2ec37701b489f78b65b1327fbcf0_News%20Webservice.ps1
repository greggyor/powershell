﻿# Login
iwr "http://192.168.178.29/mmbbsapp/news.php?user=mmbbs&password=mmbbs" -SessionVariable s
# Logout
iwr "http://192.168.178.29/mmbbsapp/news.php?cmd=logout" -WebSession $s
# Abfrage letzte News
iwr http://192.168.178.29/mmbbsapp/news.php -WebSession $s
# Abfragen News ab ID
iwr http://192.168.178.29/mmbbsapp/news.php?id=2 -WebSession $s
# Eintragen einer News
iwr "http://192.168.178.29/mmbbsapp/news.php?Headline=Ãœberschrift&Text=Dies ist ein Text mit Ã¶Ã¤Ã¼" -WebSession $s 



