﻿
Import-Module $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHQAaABcAFQAbwBcAHAAbwBzAGgALQBoAGcA')))
$global:HgPromptSettings.BeforeText = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABvAG4AIAA=')))
$global:HgPromptSettings.BeforeForegroundColor = [ConsoleColor]::White
$global:HgPromptSettings.AfterText = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAKAGgAZwA=')))
$global:HgPromptSettings.BeforeTagText = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABhAHQAIAA=')))
function prompt {    
  write-host "$pwd" -NoNewLine -foregroundcolor green
  Write-HgStatus
  write-host "Â»" -NoNewLine -ForegroundColor green
  $Host.UI.RawUI.WindowTitle = $pwd
  return ' '
}
if(-not (Test-Path Function:\DefaultTabExpansion)) {
    Rename-Item Function:\TabExpansion DefaultTabExpansion
}
function TabExpansion($line, $lastWord) {
  $LineBlocks = [regex]::Split($line, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwB8ADsAXQA='))))
  $lastBlock = $LineBlocks[-1] 
  switch -regex ($lastBlock) {
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABoAGcAfABoAGcAdABrACkAIAAoAC4AKgApAA=='))) { HgTabExpansion($lastBlock) }
     default { DefaultTabExpansion $line $lastWord }
  }
}
