﻿# ä¾‹
${2} = @{hoge = "hoge"}
${1} = "fuga"