﻿
$Folder = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAHMAZQByAHYAZQByAFwAcABhAHQAaAA=')))
$Files = ls -Path $Folder -Recurse
$OldestDate = New-Object System.DateTime(1,1,1970)
$NewestDate = $(Get-Date).AddDays(1)
$CurrentDate = Get-Date

foreach($File in $Files) 
{
	if($File.CreationTime -lt $OldestDate -or $File.CreationTime -gt $NewestDate) {
		$File.CreationTime = $CurrentDate
	}
	
	if($File.LastWriteTime -lt $OldestDate -or $File.LastWriteTime -gt $NewestDate -or $File.LastWriteTime -lt $File.CreationTime) {
		$File.LastWriteTime = $CurrentDate
	}
	
	if($File.LastAccessTime -lt $OldestDate -or $File.LastAccessTime -gt $NewestDate -or $File.LastAccessTime -lt $File.CreationTime) {
		$File.LastAccessTime = $CurrentDate
	}
}

