﻿${00110010110010100} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AGUAbgB2ADoAUAByAG8AZwByAGEAbQBGAGkAbABlAHMAKAB4ADgANgApAH0AXABKAGUAbgBrAGkAbgBzAFwAcABsAHUAZwBpAG4AcwA=')))
${10111000110101010} = New-Object Net.WebClient
${10111000110101010}.DownloadFile('http://updates.jenkins-ci.org/download/plugins/git-client/1.4.6/git-client.hpi', $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADEAMAAwADEAMAAxADEAMAAwADEAMAAxADAAMAB9AFwAZwBpAHQALQBjAGwAaQBlAG4AdAAuAGgAcABpAA=='))))
${10111000110101010}.DownloadFile('http://updates.jenkins-ci.org/download/plugins/scm-api/0.2/scm-api.hpi', $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADEAMAAwADEAMAAxADEAMAAwADEAMAAxADAAMAB9AFwAcwBjAG0ALQBhAHAAaQAuAGgAcABpAA=='))))
${10111000110101010}.DownloadFile('http://updates.jenkins-ci.org/download/plugins/git/2.0/git.hpi', $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADEAMAAwADEAMAAxADEAMAAwADEAMAAxADAAMAB9AFwAZwBpAHQALgBoAHAAaQA='))))

Restart-Service Jenkins


