﻿param(
	[String] $domain,
	[String] $username,
	[String] $password,
	[ScriptBlock] $scriptBlock
)
<#
    .SYNOPSIS 
          Impersonates a user and executes a script block as that user. This is an interactive script
        and a window will open in order to securely capture credentials.
    .EXAMPLE
        Use-Impersonation.ps1 mydomain.com testuser testpassword {Get-ChildItem 'C:\' | Foreach { Write-Host $_.Name }}
        This writes the contents of 'C:\' impersonating the user that is entered.
#>
$logonUserSignature =
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBEAGwAbABJAG0AcABvAHIAdAAoACAAIgBhAGQAdgBhAHAAaQAzADIALgBkAGwAbAAiACwAIABTAGUAdABMAGEAcwB0AEUAcgByAG8AcgA9AHQAcgB1AGUAIAApAF0ADQAKAHAAdQBiAGwAaQBjACAAcwB0AGEAdABpAGMAIABlAHgAdABlAHIAbgAgAGIAbwBvAGwAIABMAG8AZwBvAG4AVQBzAGUAcgAoACAAUwB0AHIAaQBuAGcAIABsAHAAcwB6AFUAcwBlAHIATgBhAG0AZQAsAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFMAdAByAGkAbgBnACAAbABwAHMAegBEAG8AbQBhAGkAbgAsAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFMAdAByAGkAbgBnACAAbABwAHMAegBQAGEAcwBzAHcAbwByAGQALAANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABpAG4AdAAgAGQAdwBMAG8AZwBvAG4AVAB5AHAAZQAsAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGkAbgB0ACAAZAB3AEwAbwBnAG8AbgBQAHIAbwB2AGkAZABlAHIALAANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAByAGUAZgAgAEkAbgB0AFAAdAByACAAcABoAFQAbwBrAGUAbgAgACkAOwA=')))
$AdvApi32 = Add-Type -MemberDefinition $logonUserSignature -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAHYAQQBwAGkAMwAyAA=='))) -Namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABzAEkAbgB2AG8AawBlAC4ATgBhAHQAaQB2AGUATQBlAHQAaABvAGQAcwA='))) -PassThru
$closeHandleSignature =
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBEAGwAbABJAG0AcABvAHIAdAAoACAAIgBrAGUAcgBuAGUAbAAzADIALgBkAGwAbAAiACwAIABDAGgAYQByAFMAZQB0ACAAPQAgAEMAaABhAHIAUwBlAHQALgBBAHUAdABvACAAKQBdAA0ACgBwAHUAYgBsAGkAYwAgAHMAdABhAHQAaQBjACAAZQB4AHQAZQByAG4AIABiAG8AbwBsACAAQwBsAG8AcwBlAEgAYQBuAGQAbABlACgAIABJAG4AdABQAHQAcgAgAGgAYQBuAGQAbABlACAAKQA7AA==')))
$Kernel32 = Add-Type -MemberDefinition $closeHandleSignature -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SwBlAHIAbgBlAGwAMwAyAA=='))) -Namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABzAEkAbgB2AG8AawBlAC4ATgBhAHQAaQB2AGUATQBlAHQAaABvAGQAcwA='))) -PassThru
try
{
    $Logon32ProviderDefault = 0
    $Logon32LogonInteractive = 2
    $tokenHandle = [IntPtr]::Zero
    $success = $false
    try
    {
        $success = $AdvApi32::LogonUser($userName, $domain, $password, $Logon32LogonInteractive, $Logon32ProviderDefault, [Ref] $tokenHandle)
    }
    finally
    {
    }
    if (!$success )
    {
        $retVal = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
        Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAbwBuAFUAcwBlAHIAIAB3AGEAcwAgAHUAbgBzAHUAYwBjAGUAcwBzAGYAdQBsAC4AIABFAHIAcgBvAHIAIABjAG8AZABlADoAIAAkAHIAZQB0AFYAYQBsAA==')))
        return
    }
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAbwBuAFUAcwBlAHIAIAB3AGEAcwAgAHMAdQBjAGMAZQBzAHMAZgB1AGwALgA=')))
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBhAGwAdQBlACAAbwBmACAAVwBpAG4AZABvAHcAcwAgAE4AVAAgAHQAbwBrAGUAbgA6ACAAJAB0AG8AawBlAG4ASABhAG4AZABsAGUA')))
    $identityName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB1AHIAcgBlAG4AdAAgAEkAZABlAG4AdABpAHQAeQA6ACAAJABpAGQAZQBuAHQAaQB0AHkATgBhAG0AZQA=')))
    $newIdentity = New-Object System.Security.Principal.WindowsIdentity( $tokenHandle )
    $context = $newIdentity.Impersonate()
    $identityName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAZQByAHMAbwBuAGEAdABpAG4AZwA6ACAAJABpAGQAZQBuAHQAaQB0AHkATgBhAG0AZQA=')))
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGUAYwB1AHQAaQBuAGcAIABjAHUAcwB0AG8AbQAgAHMAYwByAGkAcAB0AA==')))
    & $scriptBlock
}
catch [System.Exception]
{
    Write-Host $_.Exception.ToString()
}
finally
{
    if ( $context -ne $null )
    {
        $context.Undo()
    }
    if ( $tokenHandle -ne [System.IntPtr]::Zero )
    {
        $Kernel32::CloseHandle( $tokenHandle )
    }
}