﻿
param(
    [switch]$rdp,
    [switch]$mssql,
    [switch]$mysql,
    [switch]$ssh,
    [switch]$all,
    [switch]$revoke,
    [switch]$setAws,
    [string]$accessKey,
    [string]$secretKey,
    [string]$region)
Import-module $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAEEAVwBTACAAVABvAG8AbABzAFwAUABvAHcAZQByAFMAaABlAGwAbABcAEEAVwBTAFAAbwB3AGUAcgBTAGgAZQBsAGwAXABBAFcAUwBQAG8AdwBlAHIAUwBoAGUAbABsAC4AcABzAGQAMQA=')))
if($setAws){
    Set-AWSCredentials -AccessKey $accessKey -SecretKey $secretKey
    Set-DefaultAWSRegion -Region $region
}
$myipRequest = Invoke-WebRequest $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB3AHcAdwAuAHcAaABhAHQAaQBzAG0AeQBpAHAALgBjAG8AbQA=')))
$myip = $myipRequest.AllElements | WHERE Class -ieq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABoAGUALQBpAHAA'))) | SELECT -First 1 -ExpandProperty innerText
$myipCidr = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABtAHkAaQBwAC8AMwAyAA==')))
$rdpPermission = New-Object Amazon.EC2.Model.IpPermission -Property @{IpProtocol=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABjAHAA')));FromPort=3389;ToPort=3389;IpRanges=$myipCidr}
$mssqlPermission = New-Object Amazon.EC2.Model.IpPermission -Property @{IpProtocol=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABjAHAA')));FromPort=1433;ToPort=1433;IpRanges=$myipCidr}
$mysqlPermission = New-Object Amazon.EC2.Model.IpPermission -Property @{IpProtocol=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABjAHAA')));FromPort=3306;ToPort=3306;IpRanges=$myipCidr}
$sshPermission = New-Object Amazon.EC2.Model.IpPermission -Property @{IpProtocol=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABjAHAA')));FromPort=22;ToPort=22;IpRanges=$myipCidr}
$permissionSet = New-Object System.Collections.ArrayList
if($all){
    $rdp = $mssql = $mysql = $ssh = $true    
}
if($rdp){ [void]$permissionSet.Add($rdpPermission) }
if($mssql){ [void]$permissionSet.Add($mssqlPermission) }
if($mysql){ [void]$permissionSet.Add($mysqlPermission) }
if($ssh){ [void]$permissionSet.Add($sshPermission) }
if($permissionSet.Count -gt 0){
    $secGroupList = Get-EC2SecurityGroup | SELECT GroupId, GroupName
    foreach($secGroup in $secGroupList){
        try{
            if(!$revoke){
                "Granting to $($secGroup.GroupName)"
                Grant-EC2SecurityGroupIngress -GroupId $secGroup.GroupId -IpPermissions $permissionSet 
            }else{
                "Revoking to $($secGroup.GroupName)"
                Revoke-EC2SecurityGroupIngress -GroupId $secGroup.GroupId -IpPermissions $permissionSet
            }
        }catch{
            if($revoke){
                Write-Warning "Could not revoke permission to $($secGroup.GroupName)"
             }else{
                Write-Warning "Could not grant permission to $($secGroup.GroupName)"
             }
        }
    }
}