﻿	
function Import-HVConfigOnlyVM {
	[OutputType([System.Object])]
	[CmdletBinding(
		SupportsShouldProcess=$true,
		ConfirmImpact="Medium"
	)]
    Param
    (
        [parameter(Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    HelpMessage="Enter path to exported VM directory (containing config.xml)")]
        [ValidateScript({ 
                            (Test-Path (Join-Path $_ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG4AZgBpAGcALgB4AG0AbAA=')))) -PathType Leaf) -and 
                            (Test-Path (Join-Path $_ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBpAHIAdAB1AGEAbAAgAE0AYQBjAGgAaQBuAGUAcwA=')))) -PathType Container)
                       })]
		[alias("FullName", "Path")]
        [string[]]$ExportDirectory
    )
	BEGIN 
	{
		$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA=')))
	    $hyperv_namespace = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdAAvAHYAaQByAHQAdQBhAGwAaQB6AGEAdABpAG8AbgA=')))
	    $vsms = Get-WmiObject -Namespace $hyperv_namespace -Class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBzAFYATQBfAHYAaQByAHQAdQBhAGwAUwB5AHMAdABlAG0ATQBhAG4AYQBnAGUAbQBlAG4AdABTAGUAcgB2AGkAYwBlAA==')))
	    $hyperv_config = Get-WmiObject -NameSpace $hyperv_namespace -Class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBzAFYATQBfAFYAaQByAHQAdQBhAGwAUwB5AHMAdABlAG0ATQBhAG4AYQBnAGUAbQBlAG4AdABTAGUAcgB2AGkAYwBlAFMAZQB0AHQAaQBuAGcARABhAHQAYQA=')))
		[String[]]$vswitches = Get-WmiObject -NameSpace $hyperv_namespace -Class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBzAFYATQBfAFYAaQByAHQAdQBhAGwAUwB3AGkAdABjAGgA'))) | 
										foreach( $_.ElementName.toString())
		[System.Object[]]$statusdataset = @()
	}
	PROCESS 
	{
	    write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQAaQBuAGcAIABjAG8AbgBmAGkAZwAtAG8AbgBsAHkAIABWAGkAcgB0AHUAYQBsACAAbQBhAGMAaABpAG4AZQAgAGkAbgA='))), $ExportDirectory
		$importstatus = New-Object System.Object
	    $newroot = Join-Path (Join-Path $hyperv_config.DefaultExternalDataRoot $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBpAHIAdAB1AGEAbAAgAE0AYQBjAGgAaQBuAGUAcwA=')))) (get-item $ExportDirectory).Name
		if (Test-Path $newroot -PathType Container) {
			$err = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABkAGUAcwB0AGkAbgBhAHQAaQBvAG4AIABwAGEAdABoACAAJABuAGUAdwByAG8AbwB0ACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdABzACEACgA='))),
						$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBiAG8AcgB0AGkAbgBnAC4ALgAuAA==')))
			throw $err
		}
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHAAeQBpAG4AZwAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4AIAB0AG8AIAAkAG4AZQB3AHIAbwBvAHQALgAuAC4A')))
		if($PSCmdlet.ShouldProcess) {
	    	Copy-Item $ExportDirectory -Destination $newroot -Container -Recurse
		}
	    $importconfig = $vsms.GetVirtualSystemImportSettingData($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABuAGUAdwByAG8AbwB0AA==')))).ImportSettingData
		Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AYwBlAHMAcwBpAG4AZwAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4AIABmAG8AcgA='))), $importconfig.Name
		$importstatus | Add-Member
	    $importconfig.CreateCopy = $false
	    $importconfig.GenerateNewId = $false
	    $importconfig.SourceSnapshotDataRoot = $hyperv_config.DefaultVirtualHardDiskPath
	    $importconfig.SourceResourcePaths = $importconfig.CurrentResourcePaths
	    $importconfig.TargetNetworkConnections = $importconfig.SourceNetworkConnections
		foreach ($path in $importconfig.SourceResourcePaths) {
			if(Test-Path -Path $path -PathType Leaf) {
				Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkACAAUgBlAHMAbwB1AHIAYwBlACAAJABwAGEAdABoACAALgA=')))
			} else {
				Write-Warning ($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwAsACAAbQBpAHMAcwBpAG4AZwAgAHIAZQBzAHMAbwB1AHIAYwBlADoAIAAkAHAAYQB0AGgAIQAKAA=='))),
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIAB3AGkAbABsACAAYgBlACAAYQBiAGwAZQAgAHQAbwAgAGMAbwBuAHQAaQBuAHUAZQAgAGIAdQB0ACAAeQBvAHUAIAB3AGkAbABsACAAaABhAHYAZQAgAHQAbwAgAHIAZQBhAHQAdABhAGMAaAA='))),
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABoAGUAIABtAGkAcwBzAGkAbgBnACAAdgBvAGwAdQBtAGUAcwAgAHQAbwAgAHQAaABlACAAdgBpAHIAdAB1AGEAbAAgAG0AYQBjAGgAaQBuAGUAcwAgAGEAZgB0AGUAcgAgAHQAaABlACAAaQBtAHAAbwByAHQALgA='))) -join " ")
			}
		}
	    $result = $vsms.ImportVirtualSystemEx($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABuAGUAdwByAG8AbwB0AA=='))), $importconfig.PSBase.GetText(1))
	    if ($result.ReturnValue -eq 4096) {
	        $job = [WMI]$result.Job
			while ($job.JobState -eq 2 -or $job.JobState -eq 3 -or $job.JobState -eq 4) {
	            Write-Progress $job.Caption -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQAaQBuAGcAIABWAE0A'))) -PercentComplete $job.PercentComplete
				start-sleep 1
	            $job = [WMI]$result.Job
	        }
	        Write-Progress $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQAaQBuAGcAIABWAGkAcgB0AHUAYQBsACAATQBhAGMAaABpAG4AZQA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG4AZQAuAA=='))) -PercentComplete 100
	        if($job.JobState -eq 7) {
	            Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0AIABpAG4AIAAkAEUAeABwAG8AcgB0AEQAaQByAGUAYwB0AG8AcgB5ACAAcwB1AGMAYwBlAHMAcwBmAHUAbABsAHkAIABpAG0AcABvAHIAdABlAGQAIABpAG4AIAAkAG4AZQB3AHIAbwBvAHQALgA=')))
	        } else {
	            Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0AIABmAGEAaQBsAGUAZAAgAHQAbwAgAGkAbQBwAG8AcgB0AC4AIABFAHIAcgBvAHIAIAB2AGEAbAB1AGUAOgA='))), $job.Errorcode, $job.ErrorDescription
	    	}
	    } else {
			$msg = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQAVgBpAHIAdAB1AGEAbABTAHkAcwB0AGUAbQBFAHgAKAApACAAcgBlAHQAdQByAG4AZQBkACAAcAByAGUAbQBhAHQAdQByAGUAbAB5ACAAdwBpAHQAaAAgAHMAdABhAHQAdQBzAA==')))
			if($result.ReturnValue -eq 0) {
				Write-Warning $msg, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAgACgAUwB1AGMAYwBlAHMAcwApAA==')))
			} else {
				Write-Error $msg, $result.ReturnValue
			}
		}
	}
}
