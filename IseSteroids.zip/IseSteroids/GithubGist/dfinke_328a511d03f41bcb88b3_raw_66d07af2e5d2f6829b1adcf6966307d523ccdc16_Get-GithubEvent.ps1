﻿function Get-GithubEvent {
    
    param($userId,$Password)
    
    function f1 {
        
        param($userId,$Password)
        
        ${4} = "$($userId):$($Password)" 
        ${4} = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(${4}))
    
        @{
            "Authorization" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAHMAaQBjACAA'))) + ${4}
            "Content-Type"  = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBwAHAAbABpAGMAYQB0AGkAbwBuAC8AagBzAG8AbgA=')))
        }                   
    }

    ${3} = f1 $userId $Password
    ${2}     = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvAGEAcABpAC4AZwBpAHQAaAB1AGIALgBjAG8AbQAvAHUAcwBlAHIAcwAvACQAdQBzAGUAcgBJAGQALwByAGUAYwBlAGkAdgBlAGQAXwBlAHYAZQBuAHQAcwA=')))

    ForEach(${1} in (irm -Headers ${3} -Uri ${2} )) {
        [PSCustomObject]@{
            Action  = ${1}.payload.action
            Type    = ${1}.type
            Who     = ${1}.actor.login
            Details = ${1}
        }        
    }
}

