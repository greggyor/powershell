﻿<#
	In which I prove that that the terser [int][Math]::Floor($a/$b) gives the
	same results as the technet recommended [Math]::Floor([int]$a / [int]$b)
	Said technet recomendation is available at:
	http://technet.microsoft.com/en-us/library/ee176879.aspx
	One extra cast is probably slower too.
#>
1.. 1000 | % {
	Foreach (${3} in 2,3,5,7) {
		${2} = [int][Math]::Floor($_ / ${3})
		${1} = [Math]::Floor([int]$_ / [int]${3})
		if (${2} -ne ${1}) {
			"$(${2}) <> $(${1}) : $(${2})/$(${1})"
		}
	}
}