﻿



cls;

$scanDir = "BuildingSystems"
$normalizeEOL = $FALSE


$curPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$scanPath = $curPath + "\" + $scanDir


$textFiles = ls -Recurse $scanPath -include *.h,*.mo,*.mos,*.order,*.txt -exclude *.csv,*.dat,*.md


ForEach ($file In $textFiles){
    
    $fileContent = gc $file
    
    $fileLineNumber = $fileContent.Count

    
    if($fileLineNumber -eq 1){$fileContent = $fileContent.trimEnd()}
    else{
        
        if($normalizeEOL){ 
            for($i=0; $i -lt $fileLineNumber; $i++){$fileContent[$i] = $fileContent[$i].trimEnd()} 
        }
        
        while([string]::IsNullOrWhitespace($fileContent[$fileLineNumber-1])){ 
            $fileLineNumber--
            $fileContent = $fileContent[0..($fileLineNumber-1)] 
        }
    }
    
    sc $file $fileContent
}

