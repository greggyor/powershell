﻿
param ([string] $equipo = 'localhost',
		[string] ${_/===\/=======\_/} = $(if ($help -eq $false) {Throw "Es necesario indicar una ruta"}),
		[int] $nivel = 0,
		[string] $ambito = 'administrador', 
		[switch] $help = $false,
		[switch] $debug = $false
	)
if ($help) {
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwBcAA0ACgDCALcACQBTAGMAcgBpAHAAdAAgAGQAZQAgAHIAZQBjAG8AcABpAGwAYQBjAGkAwwCzAG4AIABkAGUAIABsAGEAIABsAGkAcwB0AGEAIABkAGUAIABjAG8AbgB0AHIAbwBsACAAZABlACAAYQBjAGMAZQBzAG8AIABwAG8AcgAgAGQAaQByAGUAYwB0AG8AcgBpAG8ACQDCALcADQAKAFwAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcAwgC3AMIAtwDCALcALwANAAoADQAKAFUAUwBPADoAIAAuAC8AbABpAHMAdABBAEMATAAgAC0AZQBxAHUAaQBwAG8AIAA8AG4AbwBtAGIAcgBlACAAZABlACAAbQDDAKEAcQB1AGkAbgBhACAAbwAgAEkAUAA+ACAADQAKAAkACQAJAAkACQAJACAALQBwAGEAdABoACAAPAByAHUAdABhAD4ADQAKAAkACQAJAAkACQAJACAALQBuAGkAdgBlAGwAIAA8ADAALQAxADAAPgANAAoACQAJAAkACQAJAAkAIAAtAGgAZQBsAHAAOgA8ACQAdAByAHUAZQB8ACQAZgBhAGwAcwBlAD4ADQAKAAkADQAKAFAAQQBSAMMAgQBNAEUAVABSAE8AUwA6AA0ACgAJAGUAcQB1AGkAcABvACAAWwBPAFAAQwBJAE8ATgBBAEwAXQAJAAkALQAJAE4AbwBtAGIAcgBlACAAbwAgAGQAaQByAGUAYwBjAGkAwwCzAG4AIABJAFAAIABkAGUAbAAgAGUAcQB1AGkAcABvACAAZABvAG4AZABlACAAcwBlACAAZQBuAGMAdQBlAG4AdAByAGEAIABsAGEAIAByAHUAdABhACAAZABlACAAbABhACAAcQB1AGUAIABzAGUAIABkAGUAcwBlAGEAIABvAGIAdABlAG4AZQByACAAZQBsACAAbABpAHMAdABhAGQAbwAgAGQAZQAgAEEAQwBMAHMAIAAoAFAAbwByACAAZABlAGYAZQBjAHQAbwA6ACAAbABvAGMAYQBsAGgAbwBzAHQAKQANAAoACQBwAGEAdABoACAAWwBPAEIATABJAEcAQQBUAE8AUgBJAE8AXQAgAAkACQAtAAkAUgB1AHQAYQAgAGQAZQAgAGQAaQByAGUAYwB0AG8AcgBpAG8AcwAgAHEAdQBlACAAcwBlACAAcQB1AGkAZQByAGUAIABjAG8AbgBzAHUAbAB0AGEAcgAuAA0ACgAJAG4AaQB2AGUAbAAgAFsATwBQAEMASQBPAE4AQQBMAF0ACQAJAC0ACQBOAGkAdgBlAGwAIABkAGUAIABkAGkAcgBlAGMAdABvAHIAaQBvAHMAIABxAHUAZQAgAHMAZQAgAGQAZQBzAGUAYQAgAGQAZQBzAGMAZQBuAGQAZQByACAAcABhAHIAYQAgAHIAZQBhAGwAaQB6AGEAcgAgAGwAYQAgAGMAbwBuAHMAdQBsAHQAYQAuACAATABvAHMAIAB2AGEAbABvAHIAZQBzACAAdgDDAKEAbABpAGQAbwBzACAAYwBvAG0AcAByAGUAbgBkAGUAIABkAGUAIAAwACAAYQAgACQAewBfAF8AXwBfAF8AXwBfAF8AXwAvAD0AXAAvAD0APQBcAF8AfQAuAA0ACgAJAAkACQAJAAkACQAJAAkARQBsACAAdgBhAGwAbwByACAAMAAgAGkAbgBkAGkAYwBhACAAcQB1AGUAIABuAG8AIABzAGUAIABlAHMAdABhAGIAbABlAGMAZQAgAGwAwwCtAG0AaQB0AGUAIABwAGEAcgBhACAAZQBsACAAZABlAHMAYwBlAG4AcwBvACAAZABlACAAbgBpAHYAZQBsAGUAcwAgACgAUABvAHIAIABkAGUAZgBlAGMAdABvADoAIAAwACkADQAKAAkAYQBtAGIAaQB0AG8AIABbAE8AUABDAEkATwBOAEEATABdAAkACQAtAAkASQBuAGQAaQBjAGEAIABsAGEAIABjAGEAbgB0AGkAZABhAGQAIABkAGUAIABpAG4AZgBvAHIAbQBhAGMAaQDDALMAbgAgAHEAdQBlACAAcwBlACAAbQB1AGUAcwB0AHIAYQAgAGUAbgAgAGUAbAAgAGkAbgBmAG8AcgBtAGUAIABnAGUAbgBlAHIAYQBkAG8ALgAgAEwAbwBzACAAdgBhAGwAbwByAGUAcwAgAHAAbwBzAGkAYgBsAGUAcwAgAHMAbwBuADoAIAANAAoACQAJAAkACQAJAAkACQAJAAkAwgC3ACAAdQBzAHUAYQByAGkAbwAsACAATQB1AGUAcwB0AHIAYQAgAGkAbgBmAG8AcgBtAGEAYwBpAMMAswBuACAAcgBlAGwAZQB2AGEAbgB0AGUAIABwAGEAcgBhACAAZQBsACAAdQBzAHUAYQByAGkAbwAuAA0ACgAJAAkACQAJAAkACQAJAAkACQDCALcAIABtAGkAYwByAG8ALAAgAE0AdQBlAHMAdAByAGEAIABsAGEAIABpAG4AZgBvAHIAbQBhAGMAaQDDALMAbgAgAGQAZQBsACAAYQBtAGIAaQB0AG8AIAB1AHMAdQBhAHIAaQBvACAAbQDDAKEAcwAgAGkAbgBmAG8AcgBtAGEAYwBpAMMAswBuACAAcgBlAGwAZQB2AGEAbgB0AGUAIAANAAoACQAJAAkACQAJAAkACQAJAAkACQAJACAAcABhAHIAYQAgAGUAbAAgAGQAZQBwAGEAcgB0AGEAbQBlAG4AdABvACAAZABlACAAbQBpAGMAcgBvAGkAbgBmAG8AcgBtAGEAdABpAGMAYQAuAA0ACgAJAAkACQAJAAkACQAJAAkACQDCALcAIABhAGQAbQBpAG4AaQBzAHQAcgBhAGQAbwByACwAIABNAHUAZQBzAHQAcgBhACAAdABvAGQAYQAgAGwAYQAgAGkAbgBmAG8AcgBtAGEAYwBpAMMAswBuAC4ADQAKAAkAaABlAGwAcAAgAFsATwBQAEMASQBPAE4AQQBMAF0ACQAJAAkALQAJAEUAcwB0AGEAIABhAHkAdQBkAGEA')))
	exit 0
}
${_________/=\/==\_} = 10
${_/\____/\__/\/==\} = get-date -uformat "%Y%m%d"
${____/\_/\_/\_/===} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABQAFcARABcACQAZQBxAHUAaQBwAG8ALgBoAHQAbQBsAA==')))
${/===\_____/======} = ""
${/==\/\/\___/\_/=\} = "\\" + $equipo + "\" + ${_/===\/=======\_/} + "\"
if ($nivel -gt ${_________/=\/==\_} -or $nivel -lt 0) {Throw "Nivel fuera del intervalo vÃ¡lido."}
if ($equipo -eq 'localhost' -or $equipo -ieq $env:COMPUTERNAME) {
	${/==\/\/\___/\_/=\} = ${_/===\/=======\_/} 
	if (-not $(Test-Path ${_/===\/=======\_/})) {Throw "El directorio especificado no existe"}
}
switch ($ambito) {
	micro {
		${/===\_____/======} = '($acl -notlike "*Administrador*" -and $acl -notlike "*BUILTIN*" -and $acl -notlike "*NT AUTHORITY*")'
	}
	usuario {
		${/===\_____/======} = '($acl -notlike "*Administrador*" -and $acl -notlike "*BUILTIN*" -and $acl -notlike "*Microinformatica*" -and $acl -notlike "*NT AUTHORITY*" -and $acl -notlike "*Todos*")'
	}
}
function dibujarDirectorio([ref] ${__/\/====\__/\/=\/}) {
	${/====\_/=\_/=\_/\} = '
	<div class="'
		if (${__/\/====\__/\/=\/}.value.nivel -eq 0) { ${/====\_/=\_/=\_/\} += 'he0' } else { ${/====\_/=\_/=\_/\} += 'he' + ${__/\/====\__/\/=\/}.value.nivel } 
		${/====\_/=\_/=\_/\} += '"><span class="sectionTitle">Directorio ' + `
		(${__/\/====\__/\/=\/}.value.Folder.FullName -replace("Ã¡" ,"&aacute;") `
											-replace("Ã©","&eacute;") `
											-replace("Ã­","&iacute;") `
											-replace("Ã³","&oacute;") `
											-replace("Ãº","&uacute;")).toLower() `
		+ '</span></div>
		<div class="container"><div class="he' + (${__/\/====\__/\/=\/}.value.nivel + 1) + '"><span class="sectionTitle">Lista de Control de Acceso</span></div>
			<div class="container">
				<div class="heACL">
					<table class="info3" cellpadding="0" cellspacing="0">
						<thead>
							<tr><th style="width:25%"><b>Propietario</b></th>
							<th style="width:75%"><b>Permisos</b></th></tr>
						</thead>
						<tbody>'
		foreach (${___/=\__/\/==\/==} in ${__/\/====\__/\/=\/}.value.ACL) {
			${___/=\/==\_/=\/\_} = $null
			if (${___/=\__/\/==\/==}.AccessToString -ne $null) {
				${___/=\/==\_/=\/\_} = ${___/=\__/\/==\/==}.AccessToString.split("`n")
			}
			${/====\_/=\_/=\_/\} += '<tr><td>' + ${___/=\__/\/==\/==}.Owner + '</td>
			<td>
			<table class="info4">
				<thead>
					<tr><th>Usuario</th>
					<th>Control</th>
					<th>Permisos</th></tr>
				</thead>
				<tbody>'
			foreach (${/=\______/=\/\/==} in ${___/=\/==\_/=\/\_}) {
				${_/\_/=\/=\/=\/==\} = [regex]::split(${/=\______/=\/\/==}, "(Allow|Deny)")
				if ($debug) {
					write-host "ACL(" ${_/\_/=\/=\/=\/==\}.gettype().name ")[" ${_/\_/=\/=\/=\/==\}.length "]: " ${_/\_/=\/=\/=\/==\}
				}
				if (${_/\_/=\/=\/=\/==\}.count -eq 1) {
					continue
				}
				${_/\_/=\/=\/=\/==\}[1] = ${_/\_/=\/=\/=\/==\}[1] -replace("Allow", "Permitir") `
									-replace("Deny", "Denegar")
				${_/\_/=\/=\/=\/==\}[2] = ${_/\_/=\/=\/=\/==\}[2] -replace("FullControl", "Control Total") `
									-replace("ReadAndExecute", "Lectura y Ejecuci&oacute;n") `
									-replace("Read", "Lectura") `
									-replace("Write", "Escritura") `
									-replace("Synchronize", "Sincronizar") `
									-replace("Modify", "Modificar") `
									-replace("TakeOwnerShip", "Tomar posesi&oacute;n")
				if ($ambito -ne 'administrador') {
					if ( iex ${/===\_____/======} ) {
						${/====\_/=\_/=\_/\} += "<tr><td>" + ${_/\_/=\/=\/=\/==\}[0].trim() + "</td><td>" + ${_/\_/=\/=\/=\/==\}[1].trim() + "</td><td>" + ${_/\_/=\/=\/=\/==\}[2].trim() + "</td></tr>"
					}
				} else {
					${/====\_/=\_/=\_/\} += "<tr><td>" + ${_/\_/=\/=\/=\/==\}[0].trim() + "</td><td>" + ${_/\_/=\/=\/=\/==\}[1].trim() + "</td><td>" + ${_/\_/=\/=\/=\/==\}[2].trim() + "</td></tr>"
				}
			}
			${/====\_/=\_/=\_/\} += '</tbody>
						</table>
						</td>
						</tr>'
		}
${/====\_/=\_/=\_/\} += '
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="filler"></div>'
	return ${/====\_/=\_/=\_/\}
}
function dibujarContenedor(${__/===\_/\/=\__/\_}, ${__/\/\/=\/\/=\/\__}) {
	function dibujarDirectorio([ref] ${__/\/====\__/\/=\/}) {
		${/====\_/=\_/=\_/\} = '
		<div class="'
			if (${__/\/====\__/\/=\/}.value.nivel -eq 0) { ${/====\_/=\_/=\_/\} += 'he0_expanded' } else { ${/====\_/=\_/=\_/\} += 'he' + ${__/\/====\__/\/=\/}.value.nivel } 
			${/====\_/=\_/=\_/\} += '"><span class="sectionTitle">Directorio o Fichero ' + ${__/\/====\__/\/=\/}.value.Folder.FullName + '</span></div>
			<div class="container"><div class="he' + (${__/\/====\__/\/=\/}.value.nivel + 1) + '"><span class="sectionTitle">Lista de Control de Acceso</span></div>
				<div class="container">
					<div class="heACL">
						<table class="info3" cellpadding="0" cellspacing="0">
							<thead>
								<tr><th><b>Usuario</b></th></tr>
								<tr><th><b>Permisos</b></th></tr>
							</thead>
							<tbody>'
			foreach (${___/=\__/\/==\/==} in ${__/\/====\__/\/=\/}.value.ACL) {
				${/====\_/=\_/=\_/\} += '<tr><td>' + ${___/=\__/\/==\/==}.Owner + '</td>
				<td>' + ${___/=\__/\/==\/==}.AccessToString + '</td></tr>'
			}
	${/====\_/=\_/=\_/\} += '						</tbody>
						</table>
					</div>
				</div>
			</div>'
		return ${/====\_/=\_/=\_/\}
	}
	if ($debug) {
		Write-Host "Directorio: " ${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}].Folder
		Write-Host "Indice: " ${__/\/\/=\/\/=\/\__}
		Write-Host "Nivel Actual: " ${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}].Nivel
		Write-Host "Nivel Siguiente: " ${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__} + 1].Nivel
		Write-Host "================================================================================================================="
	}
	'<div class="container">' | ac ${____/\_/\_/\_/===}
	if (${__/\/\/=\/\/=\/\__} -eq ${__/===\_/\/=\__/\_}.count) {
		dibujarDirectorio ([ref]${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}]) + '</div><div class="filler"></div>' | ac ${____/\_/\_/\_/===}
	} else {
		(dibujarDirectorio ([ref]${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}])) | ac ${____/\_/\_/\_/===}
		if ((${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}].Nivel -eq ${_________/=\/==\_}) -or (${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}].nivel -ge ${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__} + 1].nivel))  {
			dibujarDirectorio ([ref]${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}]) + '</div><div class="filler"></div>' | ac ${____/\_/\_/\_/===}
		} elseif (${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__}].nivel -lt ${__/===\_/\/=\__/\_}[${__/\/\/=\/\/=\/\__} + 1].nivel) {
			${__/\/\/=\/\/=\/\__} = dibujarContenedor ${__/===\_/\/=\__/\_} (${__/\/\/=\/\/=\/\__} + 1)
			'</div><div class="filler"></div>' | ac ${____/\_/\_/\_/===}
		}
	}
	return ${__/\/\/=\/\/=\/\__} + 1
}
if (Test-Path ${____/\_/\_/\_/===})
 {
  Remove-item ${____/\_/\_/\_/===}
 }
if (${_/===\/=======\_/}.Substring(${_/===\/=======\_/}.Length - 1,1) -eq "\") { ${_/===\/=======\_/} = ${_/===\/=======\_/}.Substring(0,${_/===\/=======\_/}.Length - 1) }
@"
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-16" />
<title>Lista de control de acceso para ${_/===\/=======\_/} en $equipo</title>
<!-- Styles -->
<style type="text/css">
	body{ background-color:#FFFFFF; 
		border:1px solid #666666; 
		color:#000000;
		font-size:68%;	
		font-family:MS Shell Dlg; 
		margin:0px 0px 10px 0px; }
			
	table{ font-size:100%; 
			table-layout:fixed; 
			}
			
	.title{ background:#FFFFFF; 
			border:none; 
			color:#333333; 
			display:block; 
			height:24px; 
			margin:0px 0px 2px 0px; 
			padding-top:4px; 
			padding-bottom:2px; 
			position:relative; 
			table-layout:fixed; 
			z-index:5; }
			
	.filler{ background:transparent; 
			border:none; 
			color:#FFFFFF; 
			display:block; 
			font:100% MS Shell Dlg; 
			line-height:8px; 
			margin-bottom:-1px;
			margin-left:43px; 
			margin-right:0px; 
			padding-top:4px; 
			position:relative; }
				
	.container{ display:block; 
			position:relative; }

	.he0{ background-color:#FEF7D6; 
		border:1px solid #BBBBBB; 
		color:#3333CC; 
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg; 
		font-size:100%; 
		font-weight:bold; 
		height:2.25em; 
		margin-bottom:-1px; 
		margin-left:0px; 
		margin-right:0px; 
		padding-left:8px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative;
		}
			
	.heACL { background-color:#ECFFD7; 
			border:1px solid #BBBBBB; 
			color:#000000; 
			display:block; 
			font-family:MS Shell Dlg; 
			font-size:100%; 
			font-weight:bold; 
			margin-bottom:-1px; 
			margin-left:90px; 
			margin-right:0px; 
			padding-left:11px; 
			padding-right:5em; 
			padding-top:4px; 
			position:relative;  
			}

	.he1{ background-color:#A0BACB; 
		border:1px solid #BBBBBB;
		color:#000000;
		cursor:pointer; 
		display:block;
		font-family:MS Shell Dlg;
		font-size:100%; 
		font-weight:bold;
		margin-bottom:-1px;
		margin-left:10px; 
		margin-right:0px; 
		padding-left:8px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative; 
		}
		
	.he2{ background-color:#C0D2DE; 
		border:1px solid #BBBBBB; 
		color:#000000;
		cursor:pointer;
		display:block; 
		font-family:MS Shell Dlg;
		font-size:100%; 
		font-weight:bold;
		margin-bottom:-1px;
		margin-left:20px; 
		margin-right:0px;
		padding-left:8px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative; 
		}

    .he3{ background-color:#D9E3EA;
		border:1px solid #BBBBBB; 
		color:#000000; 
		cursor:pointer; 
		display:block;
		font-family:MS Shell Dlg;
		font-size:100%; 
		font-weight:bold;
		margin-bottom:-1px;
		margin-left:30px;
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative; 
		}

	.he4{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000;
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg;
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px; 
		margin-left:40px; 
		margin-right:0px;
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative;
		}
		
	.he5{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000; 
		cursor:pointer;
		display:block;
		font-family:MS Shell Dlg;
		font-size:100%;
		font-weight:bold; 
		margin-bottom:-1px; 
		margin-left:50px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px;
		position:relative;
		}

	.he6{ background-color:#E8E8E8;
		border:1px solid #BBBBBB;
		color:#000000; 
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg; 
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px;
		margin-left:55px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em;
		padding-top:4px; 
		position:relative; 
		}

	.he7{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000;
		cursor:pointer; 
		display:block;
		font-family:MS Shell Dlg; 
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px; 
		margin-left:60px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative; 
		}
				
	.he8{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB;
		color:#000000; 
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg; 
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px;
		margin-left:65px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative; 
		}
				
	.he9{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000; 
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg; 
		font-size:100%;
		font-weight:bold; 
		margin-bottom:-1px;
		margin-left:70px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative;
		}
			
	.he10{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000; 
		cursor:pointer; 
		display:block; 
		font-family:MS Shell Dlg; 
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px; 
		margin-left:75px; 
		margin-right:0px; 
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative;
		}
				
	.he11{ background-color:#E8E8E8; 
		border:1px solid #BBBBBB; 
		color:#000000; 
		cursor:pointer;
		display:block; 
		font-family:MS Shell Dlg;
		font-size:100%; 
		font-weight:bold; 
		margin-bottom:-1px; 
		margin-left:80px;
		margin-right:0px;
		padding-left:11px; 
		padding-right:5em; 
		padding-top:4px; 
		position:relative;
		}
		
	.info4 {
		border-width: thin;
		border-style: solid;
		border-color: black;
		width: 100%;
		}
		
	.info, .info3, .info4, .disalign{ line-height:1.6em; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px; }
	
	#dtstamp{ color:#333333; font-family:MS Shell Dlg; font-size:100%; padding-left:11px; text-align:left; width:30%; }
	#gposummary { display:block; }
	
</style>
</head>
<body>
<table class="title" cellpadding="0" cellspacing="0">
<tr><td colspan="2" class="gponame">Lista de control de acceso para ${_/===\/=======\_/} en la m&aacute;quina $equipo</td></tr>
<tr>
    <td id="dtstamp">Datos recopilados en: $(Get-Date)</td>
    <td><div id="objshowhide"></div></td>
</tr>
</table>
<div class="filler"></div>
"@ | sc ${____/\_/\_/\_/===}
${/=\/===\/\___/\__} = ls -path ${/==\/\/\___/\_/=\} -Filter *. -Recurse -force -Verbose | sort FullName
${____/\/\_/\_/\___} = @()
foreach(${/=====\/=====\/\/} in ${/=\/===\/\___/\__})
{
${_/\/\_/\/\/==\/=\} = (([regex]"\\").matches(${/=====\/=====\/\/}.FullName.substring(${_/===\/=======\_/}.length, ${/=====\/=====\/\/}.FullName.length - ${_/===\/=======\_/}.length))).count
if ($nivel -ne 0 -and (${_/\/\_/\/\/==\/=\} - 1) -gt $nivel) {
	continue
}
if ($debug) {
	Write-Host ${/=====\/=====\/\/}.FullName "->" ${/=====\/=====\/\/}.Mode 
}
if (${/=====\/=====\/\/}.Mode -notlike "d*") {
	continue
}
${_____/\/\_/\/\/\/} = "" | select Folder,ACL,Nivel
${_____/\/\_/\/\/\/}.Folder = ${/=====\/=====\/\/}
${_____/\/\_/\/\/\/}.ACL = Get-Acl ${/=====\/=====\/\/}.FullName
${_____/\/\_/\/\/\/}.Nivel = ${_/\/\_/\/\/==\/=\} - 1
${____/\/\_/\_/\___} += ${_____/\/\_/\/\/\/}
}
	'<div class="gposummary">' | ac ${____/\_/\_/\_/===}
	${_/\_/=\/=\/=\/==\} = ""
	for (${/====\_/=\_/\__/\} = 0; ${/====\_/=\_/\__/\} -lt ${____/\/\_/\_/\___}.count; ${/====\_/=\_/\__/\}++) {
		try {
			${_/\_/=\/=\/=\/==\} += dibujarDirectorio ([ref] ${____/\/\_/\_/\___}[${/====\_/=\_/\__/\}])
		}
		catch {
			Write-Error dibujarDirectorio ([ref] ${____/\/\_/\_/\___}[${/====\_/=\_/\__/\}])
		}
	}
	${_/\_/=\/=\/=\/==\} + '</div></body></html>' | ac ${____/\_/\_/\_/===}
