﻿${3} = new-object -com "Shell.Application"
${2} = ${3}.Namespace("C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE")
${1} = ${2}.ParseName("devenv.exe")
${1}.InvokeVerb('taskbarpin')

