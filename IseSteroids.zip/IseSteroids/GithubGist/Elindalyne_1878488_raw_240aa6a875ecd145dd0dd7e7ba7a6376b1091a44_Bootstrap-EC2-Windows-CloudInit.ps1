﻿# Windows AMIs don't have WinRM enabled by default -- this script will enable WinRM
# AND install the CloudInit.NET service, 7-zip, curl and .NET 4 if its missing.
# Then use the EC2 tools to create a new AMI from the result, and you have a system 
# that will execute user-data as a PowerShell script after the instance fires up!
# This has been tested on Windows 2008 R2 Core x64 and Windows 2008 SP2 x86 AMIs provided
# by Amazon
# 
# To run the script, open up a PowerShell prompt as admin
# PS> Set-ExecutionPolicy Unrestricted
# PS> icm $executioncontext.InvokeCommand.NewScriptBlock((New-Object Net.WebClient).DownloadString('https://raw.github.com/gist/1672426/Bootstrap-EC2-Windows-CloudInit.ps1'))
# Alternatively pass the new admin password and encryption password in the argument list (in that order)
# PS> icm $executioncontext.InvokeCommand.NewScriptBlock((New-Object Net.WebClient).DownloadString('https://raw.github.com/gist/1672426/Bootstrap-EC2-Windows-CloudInit.ps1')) -ArgumentList "adminPassword cloudIntEncryptionPassword"
# The script will prompt for a a new admin password and CloudInit password to use for encryption
param(
	[Parameter(Mandatory=$true)]
	[string]
	${15},

	[Parameter(Mandatory=$true)]
	[string]
	${3}
)

Start-Transcript -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAYgBvAG8AdABzAHQAcgBhAHAALQB0AHIAYQBuAHMAYwByAGkAcAB0AC4AdAB4AHQA'))) -Force
Set-StrictMode -Version Latest
Set-ExecutionPolicy Unrestricted

${1} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAQgBvAG8AdABzAHQAcgBhAHAALgB0AHgAdAA=')))

while ((${15} -eq $null) -or (${15} -eq ''))
{
	${15} = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAYQAgAG4AbwBuAC0AbgB1AGwAbAAgAC8AIABuAG8AbgAtAGUAbQBwAHQAeQAgAEEAZABtAGkAbgBpAHMAdAByAGEAdABvAHIAIABwAGEAcwBzAHcAbwByAGQA'))) -AsSecureString)))
}

while ((${3} -eq $null) -or (${3} -eq ''))
{
	${3}= [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAYQAgAG4AbwBuAC0AbgB1AGwAbAAgAC8AIABuAG8AbgAtAGUAbQBwAHQAeQAgAHAAYQBzAHMAdwBvAHIAZAAgAHQAbwAgAHUAcwBlACAAZgBvAHIAIABlAG4AYwByAHkAcAB0AGkAbgBnACAAQwBsAG8AdQBkAEkAbgBpAHQALgBOAEUAVAAgAHMAYwByAGkAcAB0AHMA'))) -AsSecureString)))
}

ipmo BitsTransfer

${18} = [Environment]::GetFolderPath([Environment+SpecialFolder]::System)
${17} = [IO.Path]::Combine($env:windir, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB5AHMAbgBhAHQAaQB2AGUA'))))
#http://blogs.msdn.com/b/david.wang/archive/2006/03/26/howto-detect-process-bitness.aspx
${10} = (($Env:PROCESSOR_ARCHITECTURE -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eAA4ADYA')))) -and ($Env:PROCESSOR_ARCHITEW6432 -eq $null))
ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBzACAAMwAyAC0AYgBpAHQAIABbACQAewAxADAAfQBdAA==')))

#http://msdn.microsoft.com/en-us/library/ms724358.aspx
${16} = @(0x0c,0x27,0x0e,0x29,0x2a,0x0d,0x28,0x1d)
${8} = ${16} -contains (gwmi -Query $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGwAZQBjAHQAIABPAHAAZQByAGEAdABpAG4AZwBTAHkAcwB0AGUAbQBTAEsAVQAgAGYAcgBvAG0AIABXAGkAbgAzADIAXwBPAHAAZQByAGEAdABpAG4AZwBTAHkAcwB0AGUAbQA='))) | Select -ExpandProperty OperatingSystemSKU)
ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBzACAAQwBvAHIAZQAgAFsAJAB7ADgAfQBdAA==')))

cd $Env:USERPROFILE

#change admin password
net user Administrator ${15}
ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGEAbgBnAGUAZAAgAEEAZABtAGkAbgBpAHMAdAByAGEAdABvAHIAIABwAGEAcwBzAHcAbwByAGQA')))

#.net 4
if ((Test-Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAE0AaQBjAHIAbwBzAG8AZgB0AC4ATgBFAFQAXABGAHIAYQBtAGUAdwBvAHIAawBcAHYANAAuADAALgAzADAAMwAxADkA')))) -eq $false)
{
    ${14} = if (${8}) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AMwAvADYALwAxAC8AMwA2ADEARABBAEUANABFAC0ARQA1AEIAOQAtADQAOAAyADQALQBCADQANwBGAC0ANgA0ADIAMQBBADYAQwA1ADkAMgAyADcALwBkAG8AdABOAGUAdABGAHgANAAwAF8ARgB1AGwAbABfAHgAOAA2AF8AeAA2ADQAXwBTAEMALgBlAHgAZQA='))) } `
    else { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AOQAvADUALwBBAC8AOQA1AEEAOQA2ADEANgBCAC0ANwBBADMANwAtADQAQQBGADYALQBCAEMAMwA2AC0ARAA2AEUAQQA5ADYAQwA4AEQAQQBBAEUALwBkAG8AdABOAGUAdABGAHgANAAwAF8ARgB1AGwAbABfAHgAOAA2AF8AeAA2ADQALgBlAHgAZQA='))) }

    Start-BitsTransfer ${14} dotNetFx40_Full.exe
    saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABvAHQATgBlAHQARgB4ADQAMABfAEYAdQBsAGwALgBlAHgAZQA='))) -ArgumentList $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBuAG8AcgBlAHMAdABhAHIAdAAgAC8AcQAgACAALwBDAGgAYQBpAG4AaQBuAGcAUABhAGMAawBhAGcAZQAgAEEARABNAEkATgBEAEUAUABMAE8AWQBNAEUATgBUAA=='))) -Wait -NoNewWindow
    del dotNetFx40_Full.exe
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkACAAdABoAGEAdAAgAC4ATgBFAFQANAAgAHcAYQBzACAAbgBvAHQAIABpAG4AcwB0AGEAbABsAGUAZAAgAGEAbgBkACAAZABvAHcAbgBsAG8AYQBkAGUAZAAgAC8AIABpAG4AcwB0AGEAbABsAGUAZAA=')))
}

#configure powershell to use .net 4
${13} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAA/AHgAbQBsACAAdgBlAHIAcwBpAG8AbgA9ACIAMQAuADAAIgAgAGUAbgBjAG8AZABpAG4AZwA9ACIAdQB0AGYALQA4ACIAIAA/AD4ADQAKADwAYwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgA+AA0ACgAgACAAPAAhAC0ALQAgAGgAdAB0AHAAOgAvAC8AbQBzAGQAbgAuAG0AaQBjAHIAbwBzAG8AZgB0AC4AYwBvAG0ALwBlAG4ALQB1AHMALwBsAGkAYgByAGEAcgB5AC8AdwA0AGEAdAB0AHkANgA4AC4AYQBzAHAAeAAgAC0ALQA+AA0ACgAgACAAPABzAHQAYQByAHQAdQBwACAAdQBzAGUATABlAGcAYQBjAHkAVgAyAFIAdQBuAHQAaQBtAGUAQQBjAHQAaQB2AGEAdABpAG8AbgBQAG8AbABpAGMAeQA9ACIAdAByAHUAZQAiAD4ADQAKACAAIAAgACAAPABzAHUAcABwAG8AcgB0AGUAZABSAHUAbgB0AGkAbQBlACAAdgBlAHIAcwBpAG8AbgA9ACIAdgA0AC4AMAAiACAALwA+AA0ACgAgACAAIAAgADwAcwB1AHAAcABvAHIAdABlAGQAUgB1AG4AdABpAG0AZQAgAHYAZQByAHMAaQBvAG4APQAiAHYAMgAuADAALgA1ADAANwAyADcAIgAgAC8APgANAAoAIAAgADwALwBzAHQAYQByAHQAdQBwAD4ADQAKADwALwBjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuAD4A')))

if (Test-Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAFMAeQBzAFcATwBXADYANABcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUA'))))
{
    ${13} | sc $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAFMAeQBzAFcATwBXADYANABcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUALgBjAG8AbgBmAGkAZwA=')))
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGUAZAAgADMAMgAtAGIAaQB0ACAAUABvAHcAZQByAHMAaABlAGwAbAAgAG8AbgAgAHgANgA0ACAATwBTACAAdABvACAAdQBzAGUAIAAuAE4ARQBUACAANAA=')))
}
if (Test-Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAHMAeQBzAHQAZQBtADMAMgBcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUA'))))
{
    ${13} | sc $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAHMAeQBzAHQAZQBtADMAMgBcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUALgBjAG8AbgBmAGkAZwA=')))
    ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGUAZAAgAGgAbwBzAHQAIABPAFMAIABzAHAAZQBjAGkAZgBpAGMAIABQAG8AdwBlAHIAcwBoAGUAbABsACAAYQB0ACAAJAB7AEUAbgB2ADoAdwBpAG4AZABpAHIAfQBcAHMAeQBzAHQAZQBtADMAMgBcACAAdABvACAAdQBzAGUAIAAuAE4ARQBUACAANAA=')))
}

#winrm
if (${10})
{
    #this really only applies to oses older than 2008 SP2 or 2008 R2 or Win7
    #this uri is Windows 2008 x86 - powershell 2.0 and winrm 2.0
    #Start-BitsTransfer 'http://www.microsoft.com/downloads/info.aspx?na=41&srcfamilyid=863e7d01-fb1b-4d3e-b07d-766a0a2def0b&srcdisplaylang=en&u=http%3a%2f%2fdownload.microsoft.com%2fdownload%2fF%2f9%2fE%2fF9EF6ACB-2BA8-4845-9C10-85FC4A69B207%2fWindows6.0-KB968930-x86.msu' Windows6.0-KB968930-x86.msu 
    #Start-Process -FilePath "wusa.exe" -ArgumentList 'Windows6.0-KB968930-x86.msu /norestart /quiet' -Wait
    #Add-Content $log -value ""
}

#check winrm id, if it's not valid and LocalAccountTokenFilterPolicy isn't established, do it
${12} = &winrm id
if ((${12} -eq $null) -and (gp -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -name LocalAccountTokenFilterPolicy -ErrorAction SilentlyContinue) -eq $null)
{
    New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -name LocalAccountTokenFilterPolicy -value 1 -propertyType dword
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAZQBkACAATABvAGMAYQBsAEEAYwBjAG8AdQBuAHQAVABvAGsAZQBuAEYAaQBsAHQAZQByAFAAbwBsAGkAYwB5ACAAcwBpAG4AYwBlACAAdwBpAG4AcgBtACAAaQBkACAAYwBvAHUAbABkACAAbgBvAHQAIABiAGUAIABlAHgAZQBjAHUAdABlAGQA')))
}

#enable powershell servermanager cmdlets (only for 2008 r2 + above)
if (${8})
{
    DISM /Online /Enable-Feature /FeatureName:MicrosoftWindowsPowerShell /FeatureName:ServerManager-PSH-Cmdlets /FeatureName:BestPractices-PSH-Cmdlets
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGEAYgBsAGUAZAAgAFMAZQByAHYAZQByAE0AYQBuAGEAZwBlAHIAIABhAG4AZAAgAEIAZQBzAHQAUAByAGEAYwB0AGkAYwBlAHMAIABDAG0AZABsAGUAdABzAA==')))

    #enable .NET flavors - on server core only -- errors on regular 2008
    DISM /Online /Enable-Feature /FeatureName:NetFx2-ServerCore /FeatureName:NetFx2-ServerCore-WOW64 /FeatureName:NetFx3-ServerCore /FeatureName:NetFx3-ServerCore-WOW64
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGEAYgBsAGUAZAAgAC4ATgBFAFQAIABmAHIAYQBtAGUAdwBvAHIAawBzACAAMgAgAGEAbgBkACAAMwAgAGYAbwByACAAeAA4ADYAIABhAG4AZAAgAHgANgA0AA==')))
}

#7zip
${11} = if (${10}) { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBzAG8AdQByAGMAZQBmAG8AcgBnAGUALgBuAGUAdAAvAHAAcgBvAGoAZQBjAHQAcwAvAHMAZQB2AGUAbgB6AGkAcAAvAGYAaQBsAGUAcwAvADcALQBaAGkAcAAvADkALgAyADIALwA3AHoAOQAyADIALgBtAHMAaQAvAGQAbwB3AG4AbABvAGEAZAA='))) } `
    else { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBzAG8AdQByAGMAZQBmAG8AcgBnAGUALgBuAGUAdAAvAHAAcgBvAGoAZQBjAHQAcwAvAHMAZQB2AGUAbgB6AGkAcAAvAGYAaQBsAGUAcwAvADcALQBaAGkAcAAvADkALgAyADIALwA3AHoAOQAyADIALQB4ADYANAAuAG0AcwBpAC8AZABvAHcAbgBsAG8AYQBkAA=='))) }

Start-BitsTransfer ${11} 7z922.msi
saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGkAZQB4AGUAYwAuAGUAeABlAA=='))) -ArgumentList $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBpACAANwB6ADkAMgAyAC4AbQBzAGkAIAAvAG4AbwByAGUAcwB0AGEAcgB0ACAALwBxACAASQBOAFMAVABBAEwATABEAEkAUgA9ACIAYwA6AFwAcAByAG8AZwByAGEAbQAgAGYAaQBsAGUAcwBcADcALQB6AGkAcAAiAA=='))) -Wait
SetX Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AEUAbgB2ADoANAB9ADsAQwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwBcADcALQB6AGkAcAA='))) /m
${Env:4} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OwBDADoAXABQAHIAbwBnAHIAYQBtACAARgBpAGwAZQBzAFwANwAtAFoAaQBwAA==')))
del 7z922.msi
ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQAIAA3AC0AegBpAHAAIABmAHIAbwBtACAAJAB7ADEAMQB9ACAAYQBuAGQAIAB1AHAAZABhAHQAZQBkACAAcABhAHQAaAA=')))

#vc 2010 redstributable
${9} = if (${10}) { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8ANQAvAEIALwBDAC8ANQBCAEMANQBEAEIAQgAzAC0ANgA1ADIARAAtADQARABDAEUALQBCADEANABBAC0ANAA3ADUAQQBCADgANQBFAEUARgA2AEUALwB2AGMAcgBlAGQAaQBzAHQAXwB4ADgANgAuAGUAeABlAA==')))} `
    else { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AMwAvADIALwAyAC8AMwAyADIANABCADgANwBGAC0AQwBGAEEAMAAtADQARQA3ADAALQBCAEQAQQAzAC0AMwBEAEUANgA1ADAARQBGAEUAQgBBADUALwB2AGMAcgBlAGQAaQBzAHQAXwB4ADYANAAuAGUAeABlAA=='))) }

Start-BitsTransfer ${9} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBjAHIAZQBkAGkAcwB0AC4AZQB4AGUA')))
saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBjAHIAZQBkAGkAcwB0AC4AZQB4AGUA'))) -ArgumentList $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBuAG8AcgBlAHMAdABhAHIAdAAgAC8AcQA='))) -Wait
del vcredist.exe
ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQAIABWAEMAKwArACAAMgAwADEAMAAgAFIAZQBkAGkAcwB0AHIAaQBiAHUAdABhAGIAbABlACAAZgByAG8AbQAgACQAewA5AH0AIABhAG4AZAAgAHUAcABkAGEAdABlAGQAIABwAGEAdABoAA==')))

#vc 2008 redstributable
${9} = if (${10}) { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AZAAvAGQALwA5AC8AZABkADkAYQA4ADIAZAAwAC0ANQAyAGUAZgAtADQAMABkAGIALQA4AGQAYQBiAC0ANwA5ADUAMwA3ADYAOQA4ADkAYwAwADMALwB2AGMAcgBlAGQAaQBzAHQAXwB4ADgANgAuAGUAeABlAA==')))} `
    else { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBkAG8AdwBuAGwAbwBhAGQALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AZABvAHcAbgBsAG8AYQBkAC8AZAAvADIALwA0AC8AZAAyADQAMgBjADMAZgBiAC0AZABhADUAYQAtADQANQA0ADIALQBhAGQANgA2AC0AZgA5ADYANgAxAGQAMABhADgAZAAxADkALwB2AGMAcgBlAGQAaQBzAHQAXwB4ADYANAAuAGUAeABlAA=='))) }

Start-BitsTransfer ${9} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBjAHIAZQBkAGkAcwB0AC4AZQB4AGUA')))
saps -FilePath $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBjAHIAZQBkAGkAcwB0AC4AZQB4AGUA'))) -ArgumentList $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBuAG8AcgBlAHMAdABhAHIAdAAgAC8AcQA='))) -Wait
del vcredist.exe
ac ${1} -value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQAIABWAEMAKwArACAAMgAwADAAOAAgAFIAZQBkAGkAcwB0AHIAaQBiAHUAdABhAGIAbABlACAAZgByAG8AbQAgACQAewA5AH0AIABhAG4AZAAgAHUAcABkAGEAdABlAGQAIABwAGEAdABoAA==')))


#chocolatey - standard one line installer doesn't work on Core b/c Shell.Application can't unzip
if (-not ${8})
{
    iex ((new-object net.webclient).DownloadString($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBiAGkAdAAuAGwAeQAvAHAAcwBDAGgAbwBjAEkAbgBzAHQAYQBsAGwA')))))
}
else
{
    ${6} = Join-Path $env:TEMP $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAG8AYwBJAG4AcwB0AGEAbABsAA==')))
    if (![System.IO.Directory]::Exists(${6})) {[System.IO.Directory]::CreateDirectory(${6})}
    ${7} = Join-Path ${6} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAG8AYwBvAGwAYQB0AGUAeQAuAHoAaQBwAA==')))
    (new-object System.Net.WebClient).DownloadFile($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBjAGgAbwBjAG8AbABhAHQAZQB5AC4AbwByAGcALwBhAHAAaQAvAHYAMQAvAHAAYQBjAGsAYQBnAGUALwBjAGgAbwBjAG8AbABhAHQAZQB5AA=='))), ${7})

    &7z x ${7} `-o`"${6}`"
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAcgBhAGMAdABlAGQAIABDAGgAbwBjAG8AbABhAHQAZQB5AA==')))
    ${5} = Join-Path (Join-Path ${6} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABvAG8AbABzAA==')))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAG8AYwBvAGwAYQB0AGUAeQBJAG4AcwB0AGEAbABsAC4AcABzADEA')))

    & ${5}

    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQAIABDAGgAbwBjAG8AbABhAHQAZQB5ACAALwAgAFYAZQByAGkAZgB5AGkAbgBnACAAUABhAHQAaABzAA==')))
    [Environment]::SetEnvironmentVariable($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAG8AYwBvAGwAYQB0AGUAeQBJAG4AcwB0AGEAbABsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAbgB1AGcAZQB0AA=='))), [System.EnvironmentVariableTarget]::User)

    if ($(${env:4}).ToLower().Contains($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAbgB1AGcAZQB0AFwAYgBpAG4A')))) -eq $false) {
      ${env:4} = [Environment]::GetEnvironmentVariable($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHQAaAA='))), [System.EnvironmentVariableTarget]::Machine);
    }


    ipmo -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAbgB1AGcAZQB0AFwAYwBoAG8AYwBvAGwAYQB0AGUAeQBJAG4AcwB0AGEAbABsAFwAaABlAGwAcABlAHIAcwBcAGMAaABvAGMAbwBsAGEAdABlAHkAaQBuAHMAdABhAGwAbABlAHIALgBwAHMAbQAxAA==')))
    & C:\NuGet\chocolateyInstall\chocolatey.ps1 update
    ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBwAGQAYQB0AGUAZAAgAGMAaABvAGMAbwBsAGEAdABlAHkAIAB0AG8AIAB0AGgAZQAgAGwAYQB0AGUAcwB0ACAAdgBlAHIAcwBpAG8AbgA=')))
}

ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQAIABDAGgAbwBjAG8AbABhAHQAZQB5AA==')))
cinst curl

#cloudinit.net
curl http://cloudinitnet.codeplex.com/releases/80468/download/335000 `-L `-d `'`' `-o cloudinit.zip
&7z e cloudinit.zip `-o`"c:\program files\CloudInit.NET`"
del cloudinit.zip
ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAHcAbgBsAG8AYQBkAGUAZAAgAC8AIABlAHgAdAByAGEAYwB0AGUAZAAgAEMAbABvAHUAZABJAG4AaQB0AC4ATgBFAFQA')))

${2} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAcAByAG8AZwByAGEAbQAgAGYAaQBsAGUAcwBcAGMAbABvAHUAZABpAG4AaQB0AC4AbgBlAHQAXABpAG4AcwB0AGEAbABsAC0AcwBlAHIAdgBpAGMAZQAuAHAAcwAxAA==')))
(gc ${2}) | % { $_ -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwBlADMAZQAyAGQAMwA4ADQAOAAzADMANgBiADcAZAAzAGIANQA0ADcAYgAyAGIANQA1AA=='))),${3} } | sc ${2}
cd $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAcAByAG8AZwByAGEAbQAgAGYAaQBsAGUAcwBcAGMAbABvAHUAZABpAG4AaQB0AC4AbgBlAHQA')))
. .\install.ps1
sasv CloudInit
ac ${1} -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBwAGQAYQB0AGUAZAAgAGMAbwBuAGYAaQBnACAAZgBpAGwAZQAgAHcAaQB0AGgAIABDAGwAbwB1AGQASQBuAGkAdAAgAGUAbgBjAHIAeQBwAHQAaQBvAG4AIABwAGEAcwBzAHcAbwByAGQAIABhAG4AZAAgAHIAYQBuACAAaQBuAHMAdABhAGwAbABhAHQAaQBvAG4AIABzAGMAcgBwAGkAdAA=')))

#this script will be fired off after the reboot
#http://www.codeproject.com/Articles/223002/Reboot-and-Resume-PowerShell-Script
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABsAG8AZwAgAD0AIAAnAGMAOgBcAEIAbwBvAHQAcwB0AHIAYQBwAC4AdAB4AHQAJwANAAoAJABzAHkAcwB0AGUAbQBQAGEAdABoACAAPQAgAFsARQBuAHYAaQByAG8AbgBtAGUAbgB0AF0AOgA6AEcAZQB0AEYAbwBsAGQAZQByAFAAYQB0AGgAKABbAEUAbgB2AGkAcgBvAG4AbQBlAG4AdAArAFMAcABlAGMAaQBhAGwARgBvAGwAZABlAHIAXQA6ADoAUwB5AHMAdABlAG0AKQANAAoAUgBlAG0AbwB2AGUALQBJAHQAZQBtAFAAcgBvAHAAZQByAHQAeQAgAC0AcABhAHQAaAAgAEgASwBMAE0AOgBcAFMATwBGAFQAVwBBAFIARQBcAE0AaQBjAHIAbwBzAG8AZgB0AFwAVwBpAG4AZABvAHcAcwBcAEMAdQByAHIAZQBuAHQAVgBlAHIAcwBpAG8AbgBcAFIAdQBuACAALQBuAGEAbQBlACAAJwBSAGUAcwB0AGEAcgB0AC0AQQBuAGQALQBSAGUAcwB1AG0AZQAnAA0ACgANAAoAJgB3AGkAbgByAG0AIABxAHUAaQBjAGsAYwBvAG4AZgBpAGcAIABgAC0AcQANAAoAQQBkAGQALQBDAG8AbgB0AGUAbgB0ACAAJABsAG8AZwAgAC0AdgBhAGwAdQBlACAAIgBSAGEAbgAgAHEAdQBpAGMAawBjAG8AbgBmAGkAZwAgAGYAbwByACAAdwBpAG4AcgBtACIADQAKAA0ACgAjAHIAdQBuACAAUwBNAFIAZQBtAG8AdABpAG4AZwAgAHMAYwByAGkAcAB0ACAAdABvACAAZQBuAGEAYgBsAGUAIABlAHYAZQBuAHQAIABsAG8AZwAgAG0AYQBuAGEAZwBlAG0AZQBuAHQALAAgAGUAdABjACAALQAgAGEAdgBhAGkAbABhAGIAbABlACAAbwBuAGwAeQAgAG8AbgAgAFIAMgANAAoAJAByAGUAbQBvAHQAaQBuAGcAUwBjAHIAaQBwAHQAIAA9ACAAWwBJAE8ALgBQAGEAdABoAF0AOgA6AEMAbwBtAGIAaQBuAGUAKAAkAHMAeQBzAHQAZQBtAFAAYQB0AGgALAAgACcAQwBvAG4AZgBpAGcAdQByAGUALQBTAE0AUgBlAG0AbwB0AGkAbgBnAC4AcABzADEAJwApAA0ACgBpAGYAIAAoAC0AbgBvAHQAIAAoAFQAZQBzAHQALQBQAGEAdABoACAAJAByAGUAbQBvAHQAaQBuAGcAUwBjAHIAaQBwAHQAKQApACAAewAgACQAcgBlAG0AbwB0AGkAbgBnAFMAYwByAGkAcAB0ACAAPQAgAFsASQBPAC4AUABhAHQAaABdADoAOgBDAG8AbQBiAGkAbgBlACgAJABzAHkAcwBOAGEAdABpAHYAZQAsACAAJwBDAG8AbgBmAGkAZwB1AHIAZQAtAFMATQBSAGUAbQBvAHQAaQBuAGcALgBwAHMAMQAnACkAIAB9AA0ACgBBAGQAZAAtAEMAbwBuAHQAZQBuAHQAIAAkAGwAbwBnACAALQB2AGEAbAB1AGUAIAAiAEYAbwB1AG4AZAAgAFIAZQBtAG8AdABpAG4AZwAgAFMAYwByAGkAcAB0ADoAIABbACQAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAcgBlAG0AbwB0AGkAbgBnAFMAYwByAGkAcAB0ACkAXQAgAGEAdAAgACQAcgBlAG0AbwB0AGkAbgBnAFMAYwByAGkAcAB0ACIADQAKAGkAZgAgACgAVABlAHMAdAAtAFAAYQB0AGgAIAAkAHIAZQBtAG8AdABpAG4AZwBTAGMAcgBpAHAAdAApAA0ACgB7AA0ACgAgACAAIAAgAC4AIAAkAHIAZQBtAG8AdABpAG4AZwBTAGMAcgBpAHAAdAAgAC0AZgBvAHIAYwBlACAALQBlAG4AYQBiAGwAZQANAAoAIAAgACAAIABBAGQAZAAtAEMAbwBuAHQAZQBuAHQAIAAkAGwAbwBnACAALQB2AGEAbAB1AGUAIAAnAFIAYQBuACAAQwBvAG4AZgBpAGcAdQByAGUALQBTAE0AUgBlAG0AbwB0AGkAbgBnAC4AcABzADEAJwANAAoAfQANAAoADQAKACMAdwBhAGkAdAAgADEANQAgAHMAZQBjAG8AbgBkAHMAIABmAG8AcgAgAEMAbABvAHUAZABJAG4AaQB0ACAAUwBlAHIAdgBpAGMAZQAgAHQAbwAgAHMAdABhAHIAdAAgAC8AIABmAGEAaQBsAA0ACgBTAHQAYQByAHQALQBTAGwAZQBlAHAAIAAtAG0AIAAxADUAMAAwADAADQAKAA0ACgAjAGMAbABlAGEAcgAgAGUAdgBlAG4AdAAgAGwAbwBnACAAYQBuAGQAIABhAG4AeQAgAGMAbABvAHUAZABpAG4AaQB0ACAAbABvAGcAcwANAAoAdwBlAHYAdAB1AHQAaQBsACAAZQBsACAAfAAgACUAIAB7AFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAEMAbABlAGEAcgBpAG4AZwAgACQAXwAiADsAIAB3AGUAdgB0AHUAdABpAGwAIABjAGwAIAAiACQAXwAiAH0ADQAKAGQAZQBsACAAJwBjADoAXABjAGwAbwB1AGQAaQBuAGkAdAAuAGwAbwBnACcAIAAtAEUAcgByAG8AcgBBAGMAdABpAG8AbgAgAFMAaQBsAGUAbgB0AGwAeQBDAG8AbgB0AGkAbgB1AGUADQAKAGQAZQBsACAAJwBjADoAXABhAGYAdABlAHIAUgBlAGIAbwBvAHQAUwBjAHIAaQBwAHQALgBwAHMAMQAnACAALQBFAHIAcgBvAHIAQQBjAHQAaQBvAG4AIABTAGkAbABlAG4AdABsAHkAQwBvAG4AdABpAG4AdQBlAA=='))) | sc $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAYQBmAHQAZQByAFIAZQBiAG8AbwB0AFMAYwByAGkAcAB0AC4AcABzADEA')))

sp -path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABhAHIAdAAtAEEAbgBkAC0AUgBlAHMAdQBtAGUA'))) `
    -value "$(Join-Path $env:windir $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB5AHMAdABlAG0AMwAyAFwAVwBpAG4AZABvAHcAcwBQAG8AdwBlAHIAUwBoAGUAbABsAFwAdgAxAC4AMABcAHAAbwB3AGUAcgBzAGgAZQBsAGwALgBlAHgAZQA=')))) c:\afterRebootScript.ps1"

Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAGUAcwBzACAAYQBuAHkAIABrAGUAeQAgAHQAbwAgAHIAZQBiAG8AbwB0ACAAYQBuAGQAIABmAGkAbgBpAHMAaAAgAGkAbQBhAGcAZQAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4A')))
[void]$host.UI.RawUI.ReadKey($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAEUAYwBoAG8ALABJAG4AYwBsAHUAZABlAEsAZQB5AEQAbwB3AG4A'))))

Restart-Computer

