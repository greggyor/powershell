﻿function ConvertTo-PigLatin {
    param(
        [Parameter(ValueFromPipeline)]        
        [string[]]$string
    )
    Process {
        $r += $(foreach($s in $string) {    
            if(echo b c d f g h j k l m n p q r s t v w x y z -eq $s[0]) {
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwAH0AewAxAH0AYQB5AA=='))) -f ($s[1..($s.length)] -join ''), $s[0]
            } else {
                $s + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwBhAHkA')))
            }
        }) + ' '
    }
    End {$r.Trim()}
}
