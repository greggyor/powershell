﻿# PowerShell wget
# Version 1.0
[CmdletBinding()]
param(
  [Parameter(ValueFromPipeline = $true, Mandatory = $true)]
  $url,
  $dest = (Get-Location).Path
)
if(!$url){break}
$filesplit = $url.split("\/")
$file = $filesplit[($filesplit.length-1)]
$fulldest = $dest + "\" + $file
(New-Object System.Net.WebClient).DownloadFile($url,$fulldest)
