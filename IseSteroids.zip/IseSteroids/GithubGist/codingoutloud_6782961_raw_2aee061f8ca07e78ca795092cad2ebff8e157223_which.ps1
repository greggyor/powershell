﻿

function WhichOnes
{ 
   if ($args.Count -eq 0)
   {
      
      Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGEAZwBlADoAIAB3AGgAaQBjAGgAIABbAGMAbQBkADEAXQAgAFsAYwBtAGQAMgBdACAALgAuAC4A')))
   }
   else
   {
      gcm $args -All -ErrorAction SilentlyContinue | ft Definition
   }
}

nal which WhichOnes

