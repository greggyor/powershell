﻿Set-ExecutionPolicy -ExecutionPolicy Bypass -Confirm:$false
Disable-InternetExplorerESC
Enable-RemoteDesktop
Set-TaskbarOptions -UnLock
Set-WindowsExplorerOptions -EnableShowFileExtensions -EnableShowHiddenFilesFoldersDrives -EnableShowProtectedOSFiles -EnableShowFullPathInTitleBar
cinst notepadplusplus.install
cinst 7zip.install
cinst visualsubst	
cinst VirtualCloneDrive
cinst freefilesync 
cinst ChocolateyGUI
cinst adobeair
cinst adobereader
cinst dropbox
cinst googledrive
cinst fiddler
cinst Recuva
cinst LinkShellExtension
cinst putty.install
cinst treesizefree
cinst ccleaner
cinst filezilla
cinst IcoFx
cinst ccenhancer
cinst vcredist2005
cinst vcredist2008
cinst vcredist2010
cinst pscx
cinst git.install
cinst poshgit
cinst TeraCopy
cinst GoogleChrome
cinst javaruntime 
cinst WindowsLiveWriter
cinst Silverlight
cinst webpi
cinst webpicmd
cinst skype
cinst teamviewer
cinst flashplayerplugin
cinst lastpass
cinst NugetPackageExplorer
cinst NugetPackageManager
cinst calibre
cinst spotify
Install-WindowsUpdate -AcceptEula