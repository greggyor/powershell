﻿<#
.SYNOPSIS
Create a configuration transformation

.DESCRIPTION
This script runs an ASP.NET configuration transformation, given a source
configuration and transformation file.  MSBuild.exe is assumed to be in
the path, and Visual Studio 2012 should be installed.  Modify the path to
Microsoft.Web.Publishing.Tasks.dll if a different version of Visual Studio
is installed.

.PARAMETER SourceFile
The source file to use for transformations

.PARAMETER TransformFile
The transformations to apply to the source file

.PARAMETER OutputFile
Where to write the resulting output

.EXAMPLE
Create-WebConfigTransform -SourceFile C:\path\to\project\Web.config -TransformFile C:\path\to\project\Web.Debug.config -OutputFile c:\temp\transformed.xml

.LINK
http://msdn.microsoft.com/en-us/library/dd465326.aspx
#>
param(
    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]$SourceFile,

    [Parameter(Mandatory=$true)]
    [ValidateScript({Test-Path $_})]
    [string]$TransformFile,

    [Parameter(Mandatory=$true)]
    [string]$OutputFile
)

# set up output filenames
${1} = Join-Path ${env:temp} "work-${PID}"
${6} = Join-Path ${1} (Split-Path $SourceFile -Leaf)
${5} = Join-Path ${1} (Split-Path $TransformFile -Leaf)
${2} = Join-Path ${1} (Split-Path $OutputFile -Leaf)

# create a working directory and copy files into place
ni -Path ${1} -Type Directory
cp $SourceFile ${1}
cp $TransformFile ${1}

# write the project build file
${4} = @"
<Project ToolsVersion="4.0" DefaultTargets="TransformWebConfig" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <UsingTask TaskName="TransformXml"
             AssemblyFile="`$(MSBuildExtensionsPath)\Microsoft\VisualStudio\v11.0\Web\Microsoft.Web.Publishing.Tasks.dll"/>
  <Target Name="TransformWebConfig">
    <TransformXml Source="${6}"
                  Transform="${5}"
                  Destination="${2}"
                  StackTrace="true" />
  </Target>
</Project>
"@
${3} = Join-Path ${1} "build.xml"
${4} | Out-File ${3}

# call msbuild
& MSBuild.exe ${3}

# copy the output to the desired location
cp ${2} $OutputFile

# clean up
rd ${1} -Recurse -Force


