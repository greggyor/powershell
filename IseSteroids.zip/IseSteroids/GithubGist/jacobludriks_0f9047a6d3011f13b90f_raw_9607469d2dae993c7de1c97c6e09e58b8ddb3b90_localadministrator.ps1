﻿
$serverou = "OU=All Member Servers,DC=domain,DC=com"

$servers = Get-ADComputer -Filter * -SearchBase $serverou
$array = @()
foreach ($server in $servers) {
	$Error.Clear()
	$wmi = gwmi -ComputerName $server.name -Query "SELECT * FROM Win32_GroupUser WHERE GroupComponent=`"Win32_Group.Domain='$($server.name)',Name='Administrators'`"" -ErrorAction SilentlyContinue
	if ($wmi) {
		foreach ($item in $wmi) {
			$string = $item.partcomponent -split "\,"
			if ($string[0] -like "*Win32_UserAccount*") { $type = "User" }
			elseif ($string[0] -like "*Win32_Group*") { $type = "Group" }
			else { $type = "Unknown" }
			$domain = (($string[0] -split "=")[1]).Replace("""","")
			$user = (($string[1] -split "=")[1]).Replace("""","")
			$temp = @{"Server" = $($server.name); "Domain" = $domain; "User" = $user; "Type" = $type}
			$array += new-object psobject -property $temp
		}
		Write-Host "Successfully got list from $($server.name)"
	}
	else {
		$ErrorCode = $Error[0].Exception
		switch -regex ($ErrorCode) {
			("The RPC server is unavailable") {
				Write-Host "RPC Unavailable on $($server.name)"
				continue
			}
			("Access denied") { 
				Write-Host "Access Denied on $($server.name)"
				continue
			}
			("Access is denied") {
				Write-Host "Access Denied on $($server.name)"
				continue
			}
		}
	}
}
$array | ft

