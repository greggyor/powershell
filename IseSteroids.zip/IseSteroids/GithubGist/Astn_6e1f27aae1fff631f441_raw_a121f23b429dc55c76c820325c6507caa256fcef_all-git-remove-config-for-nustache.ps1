﻿
## remove all *.Config where there is a *.nustache.config in the same directory

## for any given n 
## f(n) = if exists n.nustache.config and exists n.config 
##         then remove n.config

# for each Git Repo below the current directory
ls -Directory | ? { (ls $_ -Directory -Hidden -Filter ".git")} | % {
        
        # go to that repo
        Pushd $_
        # list all *.nustache.config
        ls -Recurse -Filter "*.nustache.config" | % {
                $checkpath = $_.FullName.Replace($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBOAHUAcwB0AGEAYwBoAGUALgBjAG8AbgBmAGkAZwA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBjAG8AbgBmAGkAZwA=')))) 
                # if a file exists with the same name minus ".Nustache"
                if (test-path $checkpath){
                    Write-Warning "Removing $checkpath because we have $($_.FullName)"
                    # delete it and remove from git
                    git rm $checkpath
                }else{
                    Write-Host "Skipping $_.FullName does not have a cooresponding .config"
                }
            } 
        # go back to the root directory
        Popd
    }