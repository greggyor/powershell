﻿function New-Zip ( $zipFile, $file ) {
    if ($file -is [string]) {
        $file = Get-Item $file
    }
    set-content $zipFile ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
    $zipFile = Get-Item $zipFile
    $zipFile.IsReadOnly = $false
    $zip = (New-Object -ComObject shell.application).NameSpace($zipFile.FullName)
    if ($file.PSIsContainer) {
        $file | get-childitem -exclude $zipFile.Name | foreach-object { 
            if ($_.Name -ne $zipFile.Name) { 
                $zip.CopyHere($_.FullName)
                Start-Sleep -Milliseconds 200
            }
        }
    } else { $zip.CopyHere($file.FullName) }
}