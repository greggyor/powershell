﻿
${1}=$args[0]
ren .\project.vcxproj .\${1}.vcxproj
ren .\solution.sln .\${1}.sln
${3} = gc .\${1}.sln
${3} | %{ $_ -creplace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAByAG8AagBlAGMAdAA='))), ${1} }| sc .\${1}.sln
${2} = gc .\${1}.vcxproj
${2} | %{ $_ -creplace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAByAG8AagBlAGMAdAA='))), ${1} }| sc .\${1}.vcxproj
