﻿
param(
    [Parameter(Mandatory = $true)]
    [string] $sourceRoot,
    [Parameter(Mandatory = $true)]
    [string] $versionNumber
)
function CorrectPathBackslash {
  param([string] $path)
  if (![String]::IsNullOrEmpty($path)) {
    if (!$path.EndsWith("\")) {
      $path += "\"
    }
  }
  return $path
}
$sourceRoot = CorrectPathBackslash $sourceRoot
$sourceRoot = [IO.Path]::GetFullPath($sourceRoot)
${____/\/\/\/=\/==\} = Get-Date -format g
${_/==\/\____/\___/} = @{}
${__/=\/=\/==\__/==} = Get-ChildItem $sourceRoot -Filter *.csproj -Recurse
foreach(${_/\_/\/=\/====\/\} in ${__/=\/=\/==\__/==}) {
    Write-Verbose "Processing $(${_/\_/\/=\/====\/\}.Name)..."
    ${___/=\/=\/\/===\_} = New-Object XML
    ${___/=\/=\/\/===\_}.Load(${_/\_/\/=\/====\/\}.FullName)
    if (${___/=\/=\/\/===\_}.Project.PropertyGroup.Length -lt 1) {
        Write-Verbose "No default property group for $(${_/\_/\/=\/====\/\}.FullName)"
        continue  
    }
    ${_/\/=\/\/==\/===\} = ${___/=\/=\/\/===\_}.Project.PropertyGroup[0].AssemblyName
    ${__/\/\___/=\/\/==} = Get-ChildItem ${_/\_/\/=\/====\/\}.Directory -Filter *.cs -Recurse
    foreach(${/===\__/\____/\/=} in ${__/\/\___/=\/\/==}) {
        if (${_/==\/\____/\___/}.Contains(${/===\__/\____/\/=}.FullName)) {
            continue
        }
        ${_/==\/\____/\___/}[${/===\__/\____/\/=}.FullName]=1
        ${/=\_/\/\/\/==\___} = Get-Content ${/===\__/\____/\/=}.FullName
        Write-Verbose "Processing source file: ${/===\__/\____/\/=}.FullName"
        if(${/=\_/\/\/\/==\___}[0].StartsWith("// YourLibrary SDK")) {
            for(${_____/\___/\_/\_/} = 0; ${_____/\___/\_/\_/} -lt 8; ${_____/\___/\_/\_/}++) {
                ${/=\_/\/\/\/==\___}[${_____/\___/\_/\_/}] = $null
            }
        }
        ${_/==\_/\_/\__/\/=} = ${/===\__/\____/\/=}.FullName.Remove(0, $sourceRoot.Length)
        ${______/=\_/===\__} = "// YourLibrary SDK`n" + `
            "// ${_/==\_/\_/\__/\/=}`n" + `
            "// ${_/\/=\/\/==\/===\}, Version $versionNumber, Published ${____/\/\/\/=\/==\}`n" + `
            "// (c) Copyright YourCompany`n" + `
            "// --------------------------------------------------------------------------------`n" + `
            "`n" + `
            "`n"
        Set-Content ${/===\__/\____/\/=}.FullName -value ${______/=\_/===\__}, ${/=\_/\/\/\/==\___}
    }
}