﻿
$LOGPATH = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcAG4AaQBjAHMAcgB2ADEAMABcAG4AZQB0AHcAbwByAGsAXABJAG4AZgBvAFMAZQBjAFwAUwBJAE0AXABTAEMAQwBNACAAQwB1AHMAdABvAG0AIABDAG8AZABlACAAZgBvAHIAIABBAGcAZQBuAHQAcwBcAA==')))
$PROCESSCSV = $LOGPATH + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG4AbgBlAGMAdABvAHIAXwBzAHQAYQB0AGUALgBjAHMAdgA=')))


Function GetComputerStats{
  
  param(
    [Parameter(Mandatory=$true, Position=0, 
               ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
    [ValidateNotNull()]
    [string[]]$ComputerName
  )

  process {
    foreach ($computername in $ComputerName) {
        $average = Get-WmiObject win32_processor -computername $computername| 
                   Measure-Object -property LoadPercentage -Average | 
                   Foreach {$_.Average}
        $memory = Get-WmiObject win32_operatingsystem -ComputerName $computername|
                   Foreach {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgAyAH0A'))) -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize)}
        $free = Get-WmiObject Win32_Volume -ComputerName $computername -Filter "DriveLetter = 'E:'" |
                    Foreach {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgAyAH0A'))) -f (($_.FreeSpace / $_.Capacity)*100)}
        new-object psobject -prop @{
            ComputerName = $computername
            AverageCpu = $average
            MemoryUsage = $memory
            PercentFree = $free
        }
    }
  }
}


Function CheckRemoteConnectorState{
    
    param([string[]]$ComputerNameCSV)
    $count = 0
    $timestamp = $((get-date).ToString($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQB5AHkAeQBNAE0AZABkAFQAaABoAG0AbQBzAHMA')))))
    $uuid = Get-Random -minimum 1 -maximum 9999
    $username = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABPAE0AQQBJAE4AXABVAFMARQBSAE4AQQBNAEUA')))
    $secure_file = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAVABlAG0AcABcAHMAZQBjAHUAcgBlAHMAdAByAGkAbgBnAC4AdAB4AHQA')))
    $server_array = Import-Csv $ComputerNameCSV
    If(!(Test-Path $secure_file)){$create_password = (Get-Credential -Credential $username).Password | `
                                                      ConvertFrom-SecureString | Out-File $secure_file}
    $password = cat $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAVABlAG0AcABcAHMAZQBjAHUAcgBlAHMAdAByAGkAbgBnAC4AdAB4AHQA'))) | convertto-securestring
    $credential = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $password
    $QueryProcessTable = {(gwmi win32_service|?{$_.name -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBhAHIAYwBfACoA')))})}
    foreach ($server in $server_array.ComputerName) { 
        $ps_session = New-PSSession -ComputerName $server -Credential $credential
        foreach ($process in Invoke-Command -Session $ps_session -ScriptBlock $QueryProcessTable -AsJob | Wait-Job | Receive-Job){
            If ($process.State -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgB1AG4AbgBpAG4AZwA=')))){
                 $str_array = $process.pathname.split(' ')[0]
                 $pos = $str_array.IndexOf($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABjAHUAcgByAGUAbgB0AA=='))))
                 $processpath = $str_array.SubString(0, $pos) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABjAHUAcgByAGUAbgB0AFwA')))
                 $arc_home_path = $processpath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgBcAGEAZwBlAG4AdABcAA==')))
                 $path_hash = Invoke-Command -Session $ps_session -ScriptBlock {dir $args[0] *xml} -ArgumentList $arc_home_path
                 $xml_file = $arc_home_path + $path_hash[0].Name
                 [xml]$xml_content = Invoke-Command -Session $ps_session -ScriptBlock {Get-Content $args[0]} -ArgumentList $xml_file
                 $agentid = $xml_content.ExtendedConfig.AgentId
                 $agentlocation = $xml_content.ExtendedConfig.AgentLocation
                 $agentname = $xml_content.ExtendedConfig.AgentName
                 $agenttype = $xml_content.ExtendedConfig.AgentType
                 $agentversion = $xml_content.ExtendedConfig.AgentVersion
                 $devicelocation = $xml_content.ExtendedConfig.DeviceLocation
                 $stats = Invoke-Command -Session $ps_session -ScriptBlock ${function:GetComputerStats} -ArgumentList $server
                 $cpu_load = $stats.AverageCpu.ToString() + "%"
                 $mem_load = $stats.PercentFree.ToString() + "%"
                 $disk_free = $stats.MemoryUsage.ToString() + "%"
                 
                 
                 
                 $agent_properties = $processpath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgBcAGEAZwBlAG4AdABcAGEAZwBlAG4AdAAuAHAAcgBvAHAAZQByAHQAaQBlAHMA')))
                 
                 
                 
                 
                 $pshashobj = New-Object PsObject -Property @{DateTime = $timestamp; ComputerName = $process.PSComputerName; CpuLoad = $cpu_load; MemLoad = $mem_load; `
                                                              DiskFree = $disk_free; UUID = $uuid; ProcessName = $process.Name; `
                                                              ProcessState = $process.State; ProcessStatus = $process.Status; AgentPath = $agent_properties; `
                                                              AgentId = $agentid; AgentLocation = $agentlocation; AgentName = $agentname; AgentType = $agenttype; `
                                                              AgentVersion = $agentversion; DeviceLocation = $devicelocation}
                 $pshashobj | export-csv â€“Path $PROCESSCSV -Append 
            }
        Exit-PSSession
        }
   }
}
 
 
Function MainFunction{
    $ComputerNameCSV = "C:\Temp\systems.csv"
    CheckRemoteConnectorState $ComputerNameCSV
    }
 
 
MainFunction