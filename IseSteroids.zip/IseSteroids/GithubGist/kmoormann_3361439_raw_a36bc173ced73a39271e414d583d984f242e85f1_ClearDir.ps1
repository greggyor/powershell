﻿function Global:ClearDir([string] $PATH)
{
	$AllItemsInPath = $Path + "*"
	Remove-Item $AllItemsInPath -recurse -force
}