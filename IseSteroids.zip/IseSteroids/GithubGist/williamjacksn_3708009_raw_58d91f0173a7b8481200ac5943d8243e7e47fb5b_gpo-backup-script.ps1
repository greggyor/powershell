﻿ipmo GroupPolicy
Get-GPO -All | ? {$_.DisplayName -like "ops*"} | Backup-GPO -Path "\\server\share" -Comment "Backup Comment"
