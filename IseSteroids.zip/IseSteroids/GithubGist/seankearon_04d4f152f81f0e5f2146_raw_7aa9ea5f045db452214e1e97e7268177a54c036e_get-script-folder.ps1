﻿
function get_script_directory 
{
    ${3} = (gv MyInvocation -Scope 1).Value
    Split-Path ${3}.MyCommand.Path
}
${2} = get_script_directory
cd ${2}


Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAGUAcwBzACAAYQBuAHkAIABrAGUAeQAgAHQAbwAgAGMAbwBuAHQAaQBuAHUAZQAgAC4ALgAuAA==')))
${1} = $host.UI.RawUI.ReadKey($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAEUAYwBoAG8ALABJAG4AYwBsAHUAZABlAEsAZQB5AEQAbwB3AG4A'))))

