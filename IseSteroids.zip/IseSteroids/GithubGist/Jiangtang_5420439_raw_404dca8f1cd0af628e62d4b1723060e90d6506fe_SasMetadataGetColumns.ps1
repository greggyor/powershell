﻿
${_/===\/\______/=\}   = New-Object -ComObject SASObjectManager.ObjectFactoryMulti2
${/==\/\_/\_/\_/=\/} = New-Object -ComObject SASObjectManager.ServerDef
${/==\/\_/\_/\_/=\/}.MachineDNSName  = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQBvAHUAcgBuAG8AZABlAC4AYwBvAG0AcABhAG4AeQAuAGMAbwBtAA==')))
${/==\/\_/\_/\_/=\/}.Port            = 8561  
${/==\/\_/\_/\_/=\/}.Protocol        = 2     
${/==\/\_/\_/\_/=\/}.ClassIdentifier = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAyADEANwBFADIAMAAyAC0AQgA1ADYAMAAtADEAMQBEAEIALQBBAEQAOQAxAC0AMAAwADEAMAA4ADMARgBGADYAOAAzADYA')))
try
{
${_/=\__/=\______/\} = ${_/===\/\______/=\}.CreateObjectByServer(
        "", 
        $true, 
        ${/==\/\_/\_/\_/=\/}, 
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBhAHMAZABlAG0AbwA='))),  
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHMAcwB3AG8AcgBkADEA'))) 
        )
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AbgBlAGMAdABlAGQAIAB0AG8AIAA='))) ${/==\/\_/\_/\_/=\/}.MachineDNSName 
}
catch [system.exception]
{
  Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABjAG8AbgBuAGUAYwB0ACAAdABvACAAUwBBAFMAIABtAGUAdABhAGQAYQB0AGEAIABzAGUAcgB2AGUAcgA6ACAA'))) $_.Exception
  exit -1
}
${__/\__/\___/=====}="" 
${_/\___/===\_/\/\_} = ${_/=\__/=\______/\}.GetRepositories([ref]${__/\__/\___/=====},0,"")
[xml]${___/\/\/=\/\_/=\_} = ${__/\__/\___/=====}
${_/====\__________} = ${___/\/\/=\/\_/=\_}.Repositories.Repository | ? {$_.Name -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkAGEAdABpAG8AbgA=')))} 
${_/==\/\___/===\/\} = ${_/====\__________}.Id
Write-Host  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHUAbgBkAGEAdABpAG8AbgAgAEkARAAgAGkAcwAgACQAewBfAC8APQA9AFwALwBcAF8AXwBfAC8APQA9AD0AXAAvAFwAfQA=')))  
${_/\_/\/====\_/=\/} = 
     $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABUAGUAbQBwAGwAYQB0AGUAcwA+AA=='))) +
     $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABQAGgAeQBzAGkAYwBhAGwAVABhAGIAbABlAC8APgA='))) +
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABDAG8AbAB1AG0AbgAgAFMAQQBTAEMAbwBsAHUAbQBuAE4AYQBtAGUAPQAiACIAIABTAEEAUwBDAG8AbAB1AG0AbgBUAHkAcABlAD0AIgAiACAAUwBBAFMAQwBvAGwAdQBtAG4ATABlAG4AZwB0AGgAPQAiACIALwA+AA=='))) +
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABTAEEAUwBMAGkAYgByAGEAcgB5ACAATgBhAG0AZQA9ACIAIgAgAEUAbgBnAGkAbgBlAD0AIgAiACAATABpAGIAcgBlAGYAPQAiACIALwA+AA=='))) +
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAFQAZQBtAHAAbABhAHQAZQBzAD4A')))
${_/\_/=\_/==\____/}=""
${_/\___/===\_/\/\_} = ${_/=\__/=\______/\}.GetMetadataObjects(
      ${_/==\/\___/===\/\}, 
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABoAHkAcwBpAGMAYQBsAFQAYQBiAGwAZQA='))), 
      [ref]${_/\_/=\_/==\____/}, 
      $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBBAFMA'))),  
      2309,
      ${_/\_/\/====\_/=\/}
  )
[xml]${__/\/\_/====\/=\/} = ${_/\_/=\_/==\____/}
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHQAYQBsACAAdABhAGIAbABlAHMAIABkAGkAcwBjAG8AdgBlAHIAZQBkADoAIAA='))) ${__/\/\_/====\/=\/}.Objects.PhysicalTable.Count
for (${_/=\_/\_/\___/==\}=0; ${_/=\_/\_/\___/==\} -lt ${__/\/\_/====\/=\/}.Objects.PhysicalTable.Count; ${_/=\_/\_/\___/==\}++)
{
  ${/==\_/==\/\/\_/\_} = ${__/\/\_/====\/=\/}.Objects.PhysicalTable[${_/=\_/\_/\___/==\}]
  for (${__/\___/====\____}=0; ${__/\___/====\____} -lt ${/==\_/==\/\/\_/\_}.Columns.Column.Count ; ${__/\___/====\____}++)
  {
    ${/====\_/=========} = ${/==\_/==\/\/\_/\_}.Columns.Column[${__/\___/====\____}]
    ${_/=\____/\___/=\/} = New-Object psobject
    ${_/=\____/\___/=\/} | add-member noteproperty -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABpAGIAcgBlAGYA'))) -value ${/==\_/==\/\/\_/\_}.TablePackage.SASLibrary.Libref
    ${_/=\____/\___/=\/} | add-member noteproperty -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABhAGIAbABlAA=='))) -value ${/==\_/==\/\/\_/\_}.SASTableName
    ${_/=\____/\___/=\/} | add-member noteproperty -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAGwAdQBtAG4A'))) -value ${/====\_/=========}.SASColumnName
    ${_/=\____/\___/=\/} | add-member noteproperty -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB5AHAAZQA='))) -value ${/====\_/=========}.SASColumnType
    ${_/=\____/\___/=\/} | add-member noteproperty -name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAG4AZwB0AGgA'))) -value ${/====\_/=========}.SASColumnLength
    ${_/=\____/\___/=\/}
  }
}