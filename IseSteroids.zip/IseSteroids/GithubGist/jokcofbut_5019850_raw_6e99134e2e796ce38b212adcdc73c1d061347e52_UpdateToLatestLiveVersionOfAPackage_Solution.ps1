﻿Update-Package -Id MyPackage -Source $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AFIAZQBwAG8A')))

