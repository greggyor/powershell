﻿ <#
  .SYNOPSIS
  Check out a range of Subversion revisions and recommit them to Mercurial
  .DESCRIPTION
  In the case where you already have an svn and an hg repository and you are transferring commits from one to the other (this is relevant when slowly transitioning svn to hg) you might get in a situation where several commits are made to the svn repository but not to the hg one. In this case you might want to check these out of svn one by one and re-commit to mercurial. This script automates the process.
  This script requires an svn and an hg command to exist in your powershell environment. You can do this (assuming Tortoise) by adding 'C:\Program Files\TortoiseSVN\bin' and 'C:\Program Files\TortoiseHg' to your PATH or setting up the appropriate aliases.
  .PARAMETER FromRevision
  SVN revision to start checking out at.
  .PARAMETER FromRevision
  SVN revision to stop checking out at.
  .PARAMETER NoConfirm
  Do not ask for confirmation between each commit
  #>
  param(
    [Parameter(Mandatory=$true)][int]$FromRevision,
    [Parameter(Mandatory=$true)][int]$ToRevision,
    [switch]$NoConfirm
    )

if(-not (gcm svn)) { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAZQBjAHQAZQBkACAAYQAgAGcAbABvAGIAYQBsAGwAeQAgAGEAdgBhAGkAbABhAGIAbABlACAAcwB2AG4AIABjAG8AbQBtAGEAbgBkAA=='))) }
if(-not (gcm hg))  { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAZQBjAHQAZQBkACAAYQAgAGcAbABvAGIAYQBsAGwAeQAgAGEAdgBhAGkAbABhAGIAbABlACAAaABnACAAYwBvAG0AbQBhAG4AZAA='))) }

if(-not ($FromRevision -le $ToRevision) ) { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAG8AbQBSAGUAdgBpAHMAaQBvAG4AIABtAHUAcwB0ACAAYgBlACAAbABlAHMAcwAgAHQAaABhAG4AIABUAG8AUgBlAHYAaQBzAGkAbwBuAA=='))) }

$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGkAbgBnACAAYQBuAHkAIABtAHEAIABwAGEAdABjAGgAZQBzAA==')))
hg qpop -a

foreach($revision in $FromRevision..$ToRevision) {
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBtAHAAbwByAHQAaQBuAGcAIAAkAHIAZQB2AGkAcwBpAG8AbgA=')))
    if( (hg status) ) { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAcgBlACAAYQByAGUAIAB1AG4AYwBvAG0AbQBpAHQAZQBkACAAbQBlAHIAYwB1AHIAaQBhAGwAIABjAGgAYQBuAGcAZQBzAA=='))) }
    svn update --revision $revision
    $log = (svn log --revision $revision)
    $msg = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBtAHAAbwByAHQAIABmAHIAbwBtACAAcwB2AG4AIAByACQAcgBlAHYAaQBzAGkAbwBuACAALQAgACQAbABvAGcA'))).replace('"', "'")
    if( -not (hg status) ) { throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAYwBoAGEAbgBnAGUAcwAgAGQAZQB0AGUAYwB0AGUAZAA='))) }

    Write-Host $msg
    if(-not $NoConfirm) {
        $continue = Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AbQBpAHQAIABpAG4AdABvACAASABnAD8AIAAoAFkALwBOACkA')))
        if("Y" -ne $continue) { exit }
    }

    hg addremove
    hg commit -m $msg
}

