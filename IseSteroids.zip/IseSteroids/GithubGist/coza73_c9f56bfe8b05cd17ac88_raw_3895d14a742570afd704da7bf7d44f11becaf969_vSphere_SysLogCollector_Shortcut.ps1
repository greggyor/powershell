﻿########################################################################################################
#                                                                                                     
#                     Powershell Script for vSphere Syslog Collector
# 
# Uses IP address from directories created for each esxi host to do a DNS lookup and create shortcuts
# for for those folders based on the returned DNS of the esxi host
#
# http://vspherepowershellscripts.blogspot.com.au/2014/07/test.html
#                                                                                                
########################################################################################################


Function ReverseDNS
{
	$nslookup = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBzAGwAbwBvAGsAdQBwACAA'))) + $args[0] + " " + $ns + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAyAD4AIABuAHUAbABsAA==')))
	$result = iex ($nslookup) 
	$global:reverse_solved_ip = $result.SyncRoot[3]

	# If nslookup returns no result set variable to 'No record found'
	if ($result.count -lt 4) 
	{
		$global:reverse_solved_ip = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAcgBlAGMAbwByAGQAIABmAG8AdQBuAGQA')))
	}
	else
	{
		#Trim off the first 9 charactors from the start this removes the 'Name:' from the output
		$global:reverse_solved_ip = $global:reverse_solved_ip.Remove(0,9)
	}
}

# Name Server which will do name resolution
$ns = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABuAHMALgBzAGUAcgB2AGUAcgAuAGMAbwBtAA==')))

#Root path of log folders (always include the trailing backslash)
$folderpath = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQBEAGEAdABhAFwAVgBNAHcAYQByAGUAXABWAE0AdwBhAHIAZQAgAFMAeQBzAGwAbwBnACAAQwBvAGwAbABlAGMAdABvAHIAXABEAGEAdABhAFwA')))

# Create array of folder names to feed into ReverseDNS function
$foldername = ls $folderpath | ? {$_.PSIsContainer} | Foreach-Object {$_.Name}

# Loop through each folder name
Foreach ($ip in $foldername){
	
	
	# Feed IP address into ReverseDNS function
	ReverseDNS $ip
	
	#Write some output so you can see what is going on
	Write-Host $ip
	Write-Host $reverse_solved_ip
	Write-Host ""
	
	
	
	# For all records in array that do not contain 'No record found' 
	if ($reverse_solved_ip -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAcgBlAGMAbwByAGQAIABmAG8AdQBuAGQA')))) {
		
		#Create Shortcut
		$target = $folderpath + $ip
		$shortcut = $folderpath + $reverse_solved_ip + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBsAG4AawA=')))
		$wshshell = New-Object -ComObject WScript.Shell
		$link = $wshshell.CreateShortcut($shortcut)
		$link.TargetPath = $target
		$link.Save()
	}
}

