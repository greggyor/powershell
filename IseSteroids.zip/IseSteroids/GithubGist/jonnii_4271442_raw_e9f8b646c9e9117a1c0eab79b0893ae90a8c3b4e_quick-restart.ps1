﻿${00001101000011100} = $args[0]
${10010011000001111} = $args[1]
${00010100000000101} = $args[2]
${00111000010001010} = $args[3]
Set-Location ${00001101000011100}
# read the version file, which indicates which version we're going to deploy
${01011111111101001} = resolve-path ../Version
${10111110110011001} = Get-Content ${01011111111101001}
Write-Host "Deploying ${10111110110011001}"
# copy the files up into the share
${10010111011010111} = ${00111000010001010}[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBwAHAAbABpAGMAYQB0AGkAbwBuAE4AYQBtAGUA')))]
${10001001110100101} = "\\${10010011000001111}\${10010111011010111}\${00010100000000101}\ComponentName\${10111110110011001}"
robocopy .\..\targets\upload-location ${10001001110100101} /MIR /Z /MT:88
Write-Host "Copying ${10010111011010111}/${00010100000000101}/ComponentName/${10111110110011001} to ${10010011000001111}"
${01000000010100010} = "c:\${10010111011010111}\${00010100000000101}\ComponentName\${10111110110011001}"
${10111000100010000} = ${00111000010001010}[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBpAGMAZQBJAG4AcwB0AGEAbABsAGUAcgBFAHgAZQBjAHUAdABhAGIAbABlAA==')))]
function _00001111000000010 (${_10111101011100011},${_10101110000010110},${_01101111101000000},${_00011100100110001}) {
    ${01101100100011110} = "${_10111101011100011}\${_10101110000010110} stop --environment=${_01101111101000000}"
    ${10100101111101111} = "${_10111101011100011}\${_10101110000010110} uninstall --environment=${_01101111101000000}"
    ${10110000010100110} = "${_10111101011100011}\${_10101110000010110} install --environment=${_01101111101000000}"
    ${01101011111000100} = "${_10111101011100011}\${_10101110000010110} start --environment=${_01101111101000000}"
  ${01001100101010111} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAcgBBAHAAcAAuAFMAZQByAHYAaQBjAGUALgBOAGEAbQBlACQA'))) + ${_01101111101000000}
	${10111011101001010} = Get-WmiObject -Class Win32_Service -Filter "Name='${01001100101010111}'"
	if (${10111011101001010}) {
		stop-service ${01001100101010111}
		${10000011100110001} = "HKLM:\System\CurrentControlSet\services\YourApp.Service.Name`$${_01101111101000000}\"
		${00100011111011011} = "YourApp.Service.Name ${_01101111101000000} / ${_00011100100110001}"
		${00111111011101001} = "`"${_10111101011100011}\${_10101110000010110}`" -instance:${_01101111101000000} -displayname `"YourApp.Service.Name (Instance: ${_01101111101000000})`" -servicename:YourApp.Service.Name"
		Set-ItemProperty -path ${10000011100110001} -name Description -value "${00100011111011011}"
		Set-ItemProperty -path ${10000011100110001} -name ImagePath -value "${00111111011101001}"
		start-service ${01001100101010111}
	}
	else {
		invoke-expression ${10110000010100110}
		invoke-expression ${01101011111000100}
	}
}
if(${10010011000001111} -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABvAGMAYQBsAGgAbwBzAHQA')))) {
	_00001111000000010 ${01000000010100010} ${10111000100010000} ${00010100000000101} ${10111110110011001}
} else {
	invoke-command `
		-ScriptBlock ${function:InstallService} `
		-computername ${10010011000001111} `
		-ArgumentList ${01000000010100010}, ${10111000100010000}, ${00010100000000101}, ${10111110110011001}
}
#clean up any old deployed versions
${01101011001101100} = (ls \\${10010011000001111}\${10010111011010111}\${00010100000000101}\ComponentName).length
${10111101110110110} = ${00111000010001010}[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgB1AG0AUAByAGUAdgBpAG8AdQBzAEMAbwBwAGkAZQBzAFQAbwBLAGUAZQBwAA==')))]
if(${01101011001101100} -gt ${10111101110110110}){
	${00011011001110001} = ${01101011001101100} - ${10111101110110110}
	Write-Host "Cleaning up deployment directory, there are ${01101011001101100} versions available. Removing ${00011011001110001} versions."
	gci \\${10010011000001111}\${10010111011010111}\${00010100000000101}\ComponentName | where {$_.Name -ne ${10111110110011001} } | sort { $_.Name -as [Version] } | select -first ${00011011001110001} | ri -r
}