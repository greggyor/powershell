﻿${_/\_/\__/==\_/===} = (gl -PSProvider FileSystem).ProviderPath
function InstallSysInternalsComponent([System.String] ${__/\/\/=====\/\/\/}, [System.String] ${__/=====\_/\___/\_})
{
	${_/\/\____/\/=====} = (gl -PSProvider FileSystem).ProviderPath + [System.IO.Path]::DirectorySeparatorChar 
	${/===\_/\__/=\_/\/} = Test-Path -Path "HKCU:\Software\SysInternals"
	if (!${/===\_/\__/=\_/\/})
	{
		Write-Host "Create main key"
		${/==\/\_/===\___/\} = ni -Path "HKCU:\Software\SysInternals" -type Directory 
	}
	${/===\_/\__/=\_/\/} = Test-Path -Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwAUwB5AHMASQBuAHQAZQByAG4AYQBsAHMAXAAkAHsAXwBfAC8APQA9AD0APQA9AFwAXwAvAFwAXwBfAF8ALwBcAF8AfQA=')))
	if (!${/===\_/\__/=\_/\/})
	{
		Write-Host "Create sub key"
		${/==\/\_/===\___/\} = ni -Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwAUwB5AHMASQBuAHQAZQByAG4AYQBsAHMAXAAkAHsAXwBfAC8APQA9AD0APQA9AFwAXwAvAFwAXwBfAF8ALwBcAF8AfQA='))) -type Directory
	}
	${/==\/\_/===\___/\} = New-ItemProperty -Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwAUwB5AHMASQBuAHQAZQByAG4AYQBsAHMAXAAkAHsAXwBfAC8APQA9AD0APQA9AFwAXwAvAFwAXwBfAF8ALwBcAF8AfQA='))) -Name "EulaAccepted" -PropertyType DWord -Value 1 -Force
	${/===\_/\__/=\_/\/} = Test-Path ${__/\/\/=====\/\/\/}
	if (!${/===\_/\__/=\_/\/})
	{
		${__/\____/\___/\/\} = [System.String]::Format("http://live.sysinternals.com/{0}", ${__/\/\/=====\/\/\/})
		${/=\/=\___/\/=\___} = (New-Object System.Net.WebClient)
		${_/\__/\__/===\_/=} = [System.IO.Path]::Combine(${_/\/\____/\/=====}, ${__/\/\/=====\/\/\/})
		Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAHcAbgBsAG8AYQBkAGkAbgBnACAAYQBwAHAAbABpAGMAYQB0AGkAbwBuACAAJwAkAHsAXwBfAC8APQA9AD0APQA9AFwAXwAvAFwAXwBfAF8ALwBcAF8AfQAnACAAZgByAG8AbQAgACQAewBfAF8ALwBcAF8AXwBfAF8ALwBcAF8AXwBfAC8AXAAvAFwAfQAgAHQAbwAgACQAewBfAC8AXABfAF8ALwBcAF8AXwAvAD0APQA9AFwAXwAvAD0AfQA=')))
		${/=\/=\___/\/=\___}.DownloadFile(${__/\____/\___/\/\}, ${_/\__/\__/===\_/=})
		Write-Host "Done..."
	}
}
InstallSysInternalsComponent "accesschk.exe"  "AccessChk"
InstallSysInternalsComponent "accessenum.exe" "AccessEnum"
InstallSysInternalsComponent "psexec.exe"     "PsExec"
InstallSysInternalsComponent "procexp.exe"    "Process Explorer"
InstallSysInternalsComponent "procmon.exe"    "Process Monitor"
InstallSysInternalsComponent "Dbgview.exe"    "DbgView"
