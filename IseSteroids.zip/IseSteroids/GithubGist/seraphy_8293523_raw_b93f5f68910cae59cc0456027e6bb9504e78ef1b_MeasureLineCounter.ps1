﻿# ç¬¬ä¸€å¼•æ•°ã¨ã—ã¦ã€å¯¾è±¡ã¨ãªã‚‹ãƒ•ã‚¡ã‚¤ãƒ«ã¾ãŸã¯è¦ªãƒ‡ã‚£ãƒ¬ã‚¯ãƒˆãƒªã‚’æŒ‡å®šã™ã‚‹.
# çœç•¥æ™‚ã¯ã‚«ãƒ¬ãƒ³ãƒˆãƒ‡ã‚£ãƒ¬ã‚¯ãƒˆãƒªä»¥ä¸‹ã®ã™ã¹ã¦ã®ãƒ•ã‚¡ã‚¤ãƒ«ã‚’å¯¾è±¡ã¨ã™ã‚‹.
param($searchPath = $(pwd))
 
# æŒ‡å®šã—ãŸãƒ•ã‚©ãƒ«ãƒ€ä»¥ä¸‹ã®å…¨ã¦ã®ãƒ•ã‚¡ã‚¤ãƒ«ã‚’å–å¾—ã™ã‚‹.
# (ãƒ•ã‚¡ã‚¤ãƒ«ãŒæŒ‡å®šã•ã‚ŒãŸå ´åˆã¯ãƒ•ã‚¡ã‚¤ãƒ«è‡ªèº«ã‚’è¿”ã™)
function f3([string] ${f1})
{
    ls ${f1} -Recurse |
        ? -FilterScript {
            # ãƒ‡ã‚£ãƒ¬ã‚¯ãƒˆãƒªä»¥å¤–ã®ã¿ (ãƒ‡ã‚£ãƒ¬ã‚¯ãƒˆãƒªã®ãƒ“ãƒƒãƒˆãƒžã‚¹ã‚¯å€¤ã¯16)
            ($_.Attributes -band 16) -eq 0
        }
}

# ã‚¨ãƒ³ãƒˆãƒªã®åž‹ã®å®šç¾©
Add-Type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGIAbABpAGMAIABzAHQAcgB1AGMAdAAgAE0AZQBhAHMAdQByAGUATABpAG4AZQBFAG4AdAByAHkAIAB7AA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIABGAHUAbABsAE4AYQBtAGUAOwANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAARABpAHIAZQBjAHQAbwByAHkAOwANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAATgBhAG0AZQA7AA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIABFAHgAdABlAG4AcwBpAG8AbgA7AA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAbABvAG4AZwAgAEwAaQBuAGUAcwA7AA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAbABvAG4AZwAgAEMAaABhAHIAYQBjAHQAZQByAHMAOwANAAoAfQA=')))
 
function f2
{
    process {
        ${2} = (gc $_.FullName | measure -Line -Character)
        return New-Object MeasureLineEntry -Property @{
            FullName = $_.FullName;
            Directory = $_.Directory;
            Name = $_.Name;
            Extension = $_.Extension;
            Lines = ${2}.Lines;
            Characters = ${2}.Characters;
        }
    }
}
 
# æŒ‡å®šãƒ‡ã‚£ãƒ¬ã‚¯ãƒˆãƒªä¸‹ã®ä»¥ä¸‹ã®æ‹¡å¼µå­ã‚’ã‚‚ã¤ã€ã™ã¹ã¦ã®ãƒ•ã‚¡ã‚¤ãƒ«ã®LINEæ•°ã‚’ã‚«ã‚¦ãƒ³ãƒˆã™ã‚‹
# é †åºã¯åå‰é †ã€æ‹¡å¼µå­é †ã¨ã™ã‚‹ã€‚
${1} = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBmAHIAbQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBiAGEAcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgB2AGIAcwA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBqAHMA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBqAGEAdgBhAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBwAGwA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBwAHkA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgB2AGIA'))), ".c", $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBjAHAAcAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBjAHgAeAA='))), ".h")
f3 $searchPath |
    ? -FilterScript { ${1} -contains $_.Extension } |
    sort -Property Name |
    f2 |
    ogv -Title $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAGEAcwB1AHIAZQAgAEwAaQBuAGUAIABDAG8AdQBuAHQA')))
#    Format-Table -Property Directory, Name, Lines, Characters


