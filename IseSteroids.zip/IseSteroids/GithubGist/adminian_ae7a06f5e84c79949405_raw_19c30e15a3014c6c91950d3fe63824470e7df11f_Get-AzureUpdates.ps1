﻿

workflow Get-AzureUpdates {
    $cred = Get-AutomationPSCredential -Name "<Cred Asset Name>"
    
    inlineScript {
    	
	$url = "http://azure.microsoft.com/en-us/updates/feed/"
		
	
	$posts = @()
		
	
	$group = "<GroupName>+<NetworkName>@yammer.com" 
	$from = "<yammer email address>"
	$smtp = "<SMTP server>"
    	$cred = $using:cred
		
	
	irm $url | 
		% { if ((Get-Date).AddDays(-1).ToUniversalTime() -lt (get-date $_.pubDate)) {
        		$posts+=$_
    			}
		}
		
		
		if ($posts.Count -gt 0) {
    		$sb = New-Object -TypeName "System.Text.StringBuilder"
    		$title = ""
		
    		switch ($posts.Count) {
        		{$_ -eq 1} { $title = "There is {0} new update to Azure" -f ($posts | measure).Count }
        		{$_ -gt 1} { $title = "There are {0} new updates to Azure" -f ($posts | measure).Count }
    		}
		
    		$posts | % { [void]$sb.AppendLine("{0}" -f $_.title) }
    		[void]$sb.AppendLine(" ")
    		[void]$sb.AppendLine($url.Replace('/feed/', ""))
            	[void]$sb.AppendLine(" ")
            	[void]$sb.AppendLine("Posted from Azure Automation")
		
    		Send-MailMessage `
                	-To $group `
                	-From $from `
                	-Subject $title `
                	-Body $sb.ToString() `
                	-SmtpServer $smtp `
                	-Credential $cred `
                	-UseSsl
		}
	}
}