﻿$mydir = Split-Path -parent $MyInvocation.MyCommand.Path
$work_dir = [Environment]::GetFolderPath("MyDocuments")
function start_process () {
    $veracity = Join-Path $(Get-Item HKLM:\Software\Sourcegear\Veracity).GetValue("InstallPath") "vv.exe"
    $processStartInfo = New-Object System.Diagnostics.ProcessStartInfo
    $processStartInfo.FileName = $veracity
    $processStartInfo.WorkingDirectory = $work_dir
    $processStartInfo.UseShellExecute = $false
    $processStartInfo.WindowStyle = "Normal"
    $processStartInfo.Arguments = "serv"
    #return $processStartInfo
    $process = [System.Diagnostics.Process]::Start($processStartInfo)
    if ($process) {
        $global:veracity_pid = $process.Id
    }
}
start_process
