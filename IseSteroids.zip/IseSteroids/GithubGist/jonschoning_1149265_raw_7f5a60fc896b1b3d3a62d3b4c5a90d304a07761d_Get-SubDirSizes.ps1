﻿function Get-SubDirSizes {
  param([Parameter(Mandatory=$true)] [string] $path)
  dir $path -force | 
    ? { $_.PSIsContainer} |
    % { new-object PsObject -property @{
          Length = (dir $_.FullName -recurse -force | ? {! $_.PSIsContainer} |   measure-object -sum Length).Sum;
          Name = $_.Name
        }
    } | 
    sort Length -desc | ft Name,@{l=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHoAZQAgAGkAbgAgAE0AQgA='))); e={[int]($_.Length/1MB)}} -autosize
}