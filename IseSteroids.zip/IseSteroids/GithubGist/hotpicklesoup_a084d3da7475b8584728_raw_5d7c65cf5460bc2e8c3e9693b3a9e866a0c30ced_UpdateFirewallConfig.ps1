﻿function UpdateFirewallConfig {
	Param (
		$SRC_config,
		$DST_config
	)
	# Compare the sections to see if the are new, existing, or extraneous.
	$diff_sections = Compare-Object $dst_config.firewallconfiguration.layer3sections.section $src_config.firewallconfiguration.layer3sections.section -Property name -IncludeEqual
	# Compare the sections to see if the are new, existing, or extraneous.
	$diff_rules = Compare-Object $DST_config.firewallConfiguration.layer3Sections.section.rule $SRC_config.firewallConfiguration.layer3Sections.section.rule -Property name -IncludeEqual 
	# Loop through each Layer 3 section in the source firewall configuration
	Foreach ($section in $SRC_config.firewallConfiguration.layer3Sections.section) {
		# Replace the source ObjectIds with destination ObjectsIds using the objects we just pushed to the destination
		Foreach ($source in $section.rule.sources.source) {
			# Match against the Security Groups and IPSets we just pushed to the destination and update Objectids.
			Switch ($source.type) {
				SecurityGroup {
					$source.value = [string]($new_securitygroups | Where {$_.name -eq $source.name}).objectid
				}
				IPSet {
					$source.value = [string]($new_ipsets | Where {$_.name -eq $source.name}).objectid
				}
			}
		}
		# Loop through all the destinations for all the rules in the section
		Foreach ($source in $section.rule.destinations.destination) {
			# Match against the Security Groups and IPSets we just pushed to the destination and update the ObjectIds
			Switch ($source.type) {
				SecurityGroup {
					$source.value = [string]($new_securitygroups | Where {$_.name -eq $source.name}).objectid
				}
				IPSet {
					$source.value = [string]($new_ipsets | Where {$_.name -eq $source.name}).objectid
				}	
			}
		}
		# Loop through all the services for all the rules in the sections
		Foreach ($source in $section.rule.services.service) {
			# Match against the Services and Service Groups we just pushed to the destination and update the ObjectIds.
			Switch ($source.type) {
				ApplicationGroup {
					$source.value = [string]($new_servicegroups | Where {$_.name -eq $source.name}).objectid
				}
				Application {
					$source.value = [string]($new_services | Where {$_.name -eq $source.name}).objectid
				}	
			}
		}
		# Switch based on results of the compare-object
		Switch (($diff_sections | ? {$_.name -like $section.name}).sideindicator) {
			# If the section is existing in destination already then update the ObjectsIds of the rules and section and it will be updated when the new config is pushed
			"==" {
				# Update the id of each rule in the section with the Id from the destination
				Foreach ($rule in $section.rule) {
					if (-not ($DST_config.firewallConfiguration.layer3Sections.section.rule | Where {$_.name -eq $rule.name})){
						$rule.RemoveAttribute("id")
					}
					else {
						$rule.id = [string]($DST_config.firewallConfiguration.layer3Sections.section.rule | Where {$_.name -eq $rule.name}).id
					}
				}
				# Update the id of the section with the Id from the destination
				$section.id = ($DST_config.firewallConfiguration.layer3Sections.section | Where {$_.name -eq $section.name}).id
				Add-content $log -value "$(get-date -format u) Section $([string]$section.name) will be Updated on Destination"
			}
			# If the section exists in source but not destination then remove all section and rule Ids and it will be created when the new config is pushed
			"=>" {
				# Loop through all rules in the section and remove the Id attribute
				Foreach ($rule in $section.rule) {
					$rule.RemoveAttribute("id")
				}
				# Remove the Id attribute from the section
				$section.RemoveAttribute("id")
				Add-content $log -value "$(get-date -format u) Section $([string]$section.name) will be Created on Destination"
			}
			# If the section exists on destination but not source then it will be removed when the new config is pushed
			"<=" {
				Add-content $log -value "$(get-date -format u) Section $([string]$section.name) will be Deleted on Destination"
			}
		}
	}
	Foreach ($rule in $SRC_config.firewallConfiguration.layer3Sections.section.rule) {
		Switch (($diff_rules | ? {$_.name -like $rule.name}).sideindicator) {
			# If the rule is existing in destination already then it will be updated when the new config is pushed
			"==" {
				Add-content $log -value "$(get-date -format u) Rule $([string]$rule.name) will be Updated on Destination"
			}
			# If the section exists in source but not destination then it will be created when the new config is pushed
			"=>" {
				Add-content $log -value "$(get-date -format u) Rule $([string]$rule.name) will be Created on Destination"
			}
			# If the rule exists on destination but not source then it will be removed when the new config is pushed
			"<=" {
				Add-content $log -value "$(get-date -format u) Rule $([string]$rule.name) will be Deleted on Destination"
			}
		}
	}
	# Loop through each Layer 2 section in the source firewall configuration
	Foreach ($section in $SRC_config.firewallConfiguration.layer2Sections.section) {
		# Update the id of each rule in the section with the Id from the destination
		Foreach ($rule in $section.rule) {
			$rule.id = [string]($DST_config.firewallConfiguration.layer2Sections.section.rule | Where {$_.name -eq $rule.name}).id
		}
		# Update the id of the section with the Id from the destination
		$section.id = ($DST_config.firewallConfiguration.layer2Sections.section | Where {$_.name -eq $section.name}).id
	}
	# ETag is the generation number of the section, it needs to be in the header for firewall updates.
	[string]$ETag = $DST_fw_config.firewallConfiguration.generationNumber
	$fw_headers = @{"Authorization" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAHMAaQBjACAAWQBXAFIAdABhAFcANAA2AE4ARgBSAEIAVwBuAE4ATABRAGwAbABEAFcAawBWAHYA')));"Content-Type" = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBwAHAAbABpAGMAYQB0AGkAbwBuAC8AeABtAGwA')));"If-Match" = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABFAFQAYQBnAA==')))}
	Try {
		$response = Invoke-WebRequest -Uri $DST_fw_config_uri_PUT -Headers $fw_headers -TimeoutSec 120 -Method PUT -Body $src_config.outerxml
		Add-content $log -value "$(get-date -format u) $($response.StatusCode) $($response.statusdescription) Updating Destination Firewall Configuration with PUT on $DST_fw_config_uri_PUT"
	}
	Catch {
		$Error[0].exception
		$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABVAFQAIAAkAEQAUwBUAF8AZgB3AF8AYwBvAG4AZgBpAGcAXwB1AHIAaQBfAFAAVQBUAA==')))
		Add-content $log -value "$(get-date -format u) ERROR:$error[0].exception Deleting $([string]$member.name) with Updating Destination Firewall Configuration with PUT on $DST_fw_config_uri_PUT"
	}
}
