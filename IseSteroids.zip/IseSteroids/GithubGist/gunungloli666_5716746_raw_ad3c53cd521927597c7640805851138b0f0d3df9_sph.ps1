﻿# untuk mencari perintah tertentu pada isi suatu file program
# dan mencari tahu pada baris mana perintah tersebut berada
$a = dir ;# directory saat ini

# string yang akan dicari, dalam hal ini perintah tertentu pada fortran
$my_regex = [regex] "In+\spoute_2D" 

# iterasi untuk seluruh isi directory saat ini
foreach($item in $a ){
  # baca isi dari file masing-masing file
	$content = get-content $item; 
	# iterasi terhadap baris dalam file
	$i = 0 ; # untuk menentukan pada baris mana perintah tersebut berada
	foreach($line in $content){
		$hasilcari = $my_regex.matches($line) ; 
		$hasilcari = $hasilcari[0];
		# jika ditemukan setidaknya satu kali saja perintah tersebut
		if($hasilcari.success){
			$i++ 
			write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHAAYQB0ACAAZABpACAAZgBpAGwAZQAgACQAaQB0AGUAbQAsACAAIABwAGEAZABhACAAYgBhAHIAaQBzACAAJABpACwAIAAgAHAAYQBkAGEAIABwAGUAcgBpAG4AdABhAGgAOgAgACQAbABpAG4AZQA=')))
		}
	}
}

