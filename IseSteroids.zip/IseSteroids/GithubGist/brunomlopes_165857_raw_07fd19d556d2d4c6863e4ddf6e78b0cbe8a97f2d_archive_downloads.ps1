﻿${/=\/\/\/\/\_/\_/=} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwA6AFwAZABvAHcAbgBsAG8AYQBkAHMAXAA=')))
${_/\/==\_/\/=\_/\/} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwA6AFwAZABvAHcAbgBsAG8AYQBkAHMAXABhAHIAYwBoAGkAdgBlAA==')))

if(-not (Test-Path ${_/\/==\_/\/=\_/\/})) {
    [void] (mkdir ${_/\/==\_/\/=\_/\/})
}

${__/==\/=====\___/} = get-childitem ${/=\/\/\/\/\_/\_/=} | ? { $_.Name -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQByAGMAaABpAHYAZQA='))) -and $_.CreationTime -lt (Get-Date).AddDays(-1) }

foreach(${/==\_/\_/=\_/===\} in ${__/==\/=====\___/}){
    ${_/==\_/\/====\___} = ${/==\_/\_/=\_/===\}.Name
    ${/==\/===\_/=\_/\_} = 1
    while ( Test-Path "${_/\/==\_/\/=\_/\/}\$(${_/==\_/\/====\___})" ) {
        ${_/==\_/\/====\___} = "$(${/==\_/\_/=\_/===\}.BaseName) (${/==\/===\_/=\_/\_})$(${/==\_/\_/=\_/===\}.Extension)"
        ${/==\/===\_/=\_/\_}+=1;
    }
    echo "Moving $(${/==\_/\_/=\_/===\}.FullName) to ${_/\/==\_/\/=\_/\/}\${_/==\_/\/====\___}"
    Move-Item "$(${/==\_/\_/=\_/===\}.FullName)" "${_/\/==\_/\/=\_/\/}\${_/==\_/\/====\___}"
}

