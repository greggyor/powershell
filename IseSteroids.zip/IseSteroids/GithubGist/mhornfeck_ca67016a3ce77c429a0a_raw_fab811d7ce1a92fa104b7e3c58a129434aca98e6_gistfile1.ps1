﻿Set-WindowsExplorerOptions -EnableShowHiddenFilesFoldersDrives -EnableShowProtectedOSFiles -EnableShowFileExtensions
Enable-RemoteDesktop
cinst Microsoft-Hyper-V-All -source windowsFeatures
cinst IIS-WebServerRole -source windowsfeatures
# Browsers
cinstm GoogleChrome
cinstm Firefox
# Runtimes
cinstm Silverlight
cinstm javaruntime
# Desktop tools
cinst fiddler4
cinst evernote
cinst filezilla
cinst dropbox
cinst virtualclonedrive
# Fun stuff
cinst spotify
# Editors
cinstm nano
cinst sublimetext2
cinst brackets
# Git, merge
cinst git-credential-winstore
cinst poshgit
cinst p4merge
# Visual Studio
# cinst VisualStudio2013Professional -InstallArguments "/Features:'WebTools Win8SDK' /ProductKey:AB1CD-EF2GH-IJ3KL-MN4OP-QR5ST"
# VS related extras
cinst NugetPackageExplorer
cinst resharper
cinst dotpeek
cinst dotcover