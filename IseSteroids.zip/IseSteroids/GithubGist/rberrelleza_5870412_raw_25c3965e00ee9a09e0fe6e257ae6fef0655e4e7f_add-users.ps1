﻿${01100000111101111} = (get-addomain).distinguishedname
${01101101010111110} = "OU=Engineering,${01100000111101111}"
${10011111010010101} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eQBvAHUAcgBkAG8AbQBhAGkAbgAuAGMAbwBtAA==')))
${01111000101100111} = 0
Get-Content .\names.csv.txt | ForEach {
  ${01111000101100111}++
  ${01111110001100001} = $_.Split()
  ${01010000110011001} = ${01111110001100001}[0]
  ${00110000101001001} = ${01111110001100001}[1]
  ${00110000010111010} = "${01010000110011001}" + "." + "${00110000101001001}"
  ${10100000010100001} = "${00110000010111010}" + ${10011111010010101}
  ${01011100100110011} =  ConvertTo-SecureString -AsPlainText $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBvAG0AZQB0AGgAaQBuAGcARwAwADAARAAhAA=='))) -force
  ${01110110000011001} = ${01010000110011001} + '.' + ${00110000101001001}
  New-ADUser ${01110110000011001} -AccountPassword ${01011100100110011} -EmailAddress ${10100000010100001} -UserPrincipalName ${10100000010100001} -Enabled $true -GivenName ${01010000110011001} -Surname ${00110000101001001}
  ${10010000000110011}  = (Get-ADUser ${01110110000011001}).DistinguishedName 
  Move-ADObject -Identity ${10010000000110011} -TargetPath ${01101101010111110} 
  ${01111000101100111}.ToString() + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KQAgAE4AYQBtAGUAOgAgAA=='))) + ${10010000000110011} 
}