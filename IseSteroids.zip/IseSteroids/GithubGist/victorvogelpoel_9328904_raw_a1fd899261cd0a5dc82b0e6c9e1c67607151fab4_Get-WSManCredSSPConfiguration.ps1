﻿# Get-WSManCredSSPConfiguration.ps1
# Compile a WSManCredSSP configuration object for the local or remote computer
# Inspired by http://www.ravichaganti.com/blog/?p=1902
# http://blog.victorvogelpoel.nl/2014/03/03/powershell-get-wsmancredsspconfiguration-getting-credssp-configuration-for-local-or-remote-computers/
#
# Disclaimer
# This script is provided AS IS without warranty of any kind. I disclaim all implied
# warranties including, without limitation, any implied warranties of merchantability
# or of fitness for a particular purpose. The entire risk arising out of the use or 
# performance of the sample scripts and documentation remains with you. In no event 
# shall I be liable for any damages whatsoever (including, without limitation, damages 
# for loss of business profits, business interruption, loss of business information, 
# or other pecuniary loss) arising out of the use of or inability to use the script or 
# documentation.
#
# Oct 2013
# If this works, Ravikanth Chaganti and Victor Vogelpoel <victor.vogelpoel@macaw.nl> wrote this.
# If it doesn't, I don't know who wrote this.

#requires -version 3
Set-PSDebug -Strict
Set-StrictMode -Version Latest


# NOTE: if using credentials, make sure to use DOMAIN\ACCOUNT format for username!
function Get-WSManCredSSPConfiguration
{
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$false, position=0, ValueFromPipeLine=$true, ValueFromPipeLineByPropertyName=$true, HelpMessage="Computers to get the CredSSP configuration for")]
		[String[]]$computerName = "localhost",

		[Parameter(Mandatory=$false, Position=1, ValueFromPipelineByPropertyName=$true, HelpMessage="Credential to connect to the computers with")]
		[Management.Automation.PSCredential]$Credential
	)
	
	begin
	{
		function Test-ElevatedProcess
		{
			return (New-Object Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole( [Security.Principal.WindowsBuiltInRole]::Administrator )
		}
		
		function Resolve-FQDNHostName
		{
			[CmdletBinding()]
			param
			(
				[Parameter(Mandatory=$false, position=0, ValueFromPipeLine=$true, ValueFromPipeLineByPropertyName=$true, HelpMessage="TODO")]
				[Alias('CN','__SERVER', 'Server', 'Hostname')]
				[String[]]$ComputerName = "localhost"
			)
			
			process
			{
				foreach (${__/=\_/=\__/\/\/=} in $ComputerName)
				{
					try
					{
						if (${__/=\_/=\__/\/\/=} -eq ".") { ${__/=\_/=\__/\/\/=} = "localhost" }
				
						Write-Output ([System.Net.Dns]::GetHostByName(${__/=\_/=\__/\/\/=}).HostName)
					}
					catch
					{
						throw "ERROR while resolving server `"${__/=\_/=\__/\/\/=}`": $($_.Exception.Message)"
					}
				}
			}
		}
	
		if (!(Test-ElevatedProcess))
		{
			throw "ERROR: WSManCredSSPConfiguration can only be used in an elevated PowerShell session."
		}
		
		${_/\/====\_/===\__} 		= Resolve-FQDNHostName
	}

	process
	{
		foreach (${/=\_/\__/=\_/\___} in $computerName)
		{
			${/=\_/\__/=\_/\___} 		= Resolve-FQDNHostName -ComputerName ${/=\_/\__/=\_/\___}
			${__/=\_/\/\/=\/\_/} 	= $null
			
			if (${/=\_/\__/=\_/\___} -eq ${_/\/====\_/===\__})
			{
				${__/=\_/\/\/=\/\_/} = New-Object -TypeName PSObject
				${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "computerName"			-Value ${/=\_/\__/=\_/\___}
				${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "IsServer" 				-Value $false
				${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "IsClient" 				-Value $false
				${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "AllowFreshCredentials"	-Value "NA"
				${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "ClientDelegateComputer"	-Value ""
				
				if ($Credential)
				{
					${____/\__/=\____/=} = Test-WSMan -Credential $Credential -ErrorAction SilentlyContinue
				}
				else
				{
					${____/\__/=\____/=} = Test-WSMan -ErrorAction SilentlyContinue
				}
						
				if (${____/\__/=\____/=})
				{
					${/=\_/=\/\_/\__/=\} = ((Get-Item WSMan:\LocalHost\Service\Auth\CredSSP).Value -eq "true")
					${/===\/\/\_/\__/\_} = ((Get-Item WSMan:\LocalHost\Client\Auth\CredSSP).Value -eq "true")
				
					${__/=\_/\/\/=\/\_/}.IsServer = ${/=\_/=\/\_/\__/=\}
					${__/=\_/\/\/=\/\_/}.IsClient = ${/===\/\/\_/\__/\_}
					
					if (${/===\/\/\_/\__/\_} -and (Test-Path HKLM:\software\policies\microsoft\windows\CredentialsDelegation\AllowFreshCredentials))
					{
						${__/=\_/\/\/=\/\_/}.AllowFreshCredentials = (Get-ItemProperty HKLM:\software\policies\microsoft\windows\CredentialsDelegation).AllowFreshCredentials
						
						# Extract registry values for 1,2,3,... from HKLM:\software\policies\microsoft\windows\CredentialsDelegation\AllowFreshCredentials, which are the delegate computers from "Enable-WSMANCredSSP -role client -delegatecomputer"
						${/======\/\/=\/\/\} = @((Get-ItemProperty HKLM:\software\policies\microsoft\windows\CredentialsDelegation\AllowFreshCredentials).psobject.Properties | where { $_.Name -match "\d+"  } | select -expand value | foreach { if ($_ -like "wsman/*") { $_.substring(6) } else { $_ } })
						
						# Store delegatecomputers in the custom object 						
						${__/=\_/\/\/=\/\_/}.ClientDelegateComputer = ${/======\/\/=\/\/\}
					}
				}
				else
				{
					throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABjAG8AbgBuAGUAYwB0ACAAdABvACAAVwBTAE0AQQBOADsAIABpAHMAIAB0AGgAZQAgAFcAaQBuAFIATQAgAHMAZQByAHYAaQBjAGUAIAByAHUAbgBuAGkAbgBnACAAbwBuACAAIgAkAHsALwA9AFwAXwAvAFwAXwBfAC8APQBcAF8ALwBcAF8AXwBfAH0AIgA/ACAAUgB1AG4AIAAiAFcAaQBuAFIATQAgAHEAdQBpAGMAawBjAG8AbgBmAGkAZwAgAC0AZgBvAHIAYwBlACIAIQA=')))
				}
			}
			else
			{
				if (Test-WSMan -ComputerName ${/=\_/\__/=\_/\___} -ErrorAction SilentlyContinue)   # Note: does NOT take -Credential, otherwise error "flagged with no authentication"
				{
					${__/=\_/\/\/=\/\_/} = New-Object -TypeName PSObject
					${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "computerName" 			-Value ${/=\_/\__/=\_/\___}
					${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "IsServer" 				-Value $false
					${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "IsClient" 				-Value $false
					${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "AllowFreshCredentials" 	-Value "NA"
					${__/=\_/\/\/=\/\_/} | Add-Member -MemberType NoteProperty -Name "ClientDelegateComputer"	-Value ""
					
					try
					{
						${/=\/\/\/==\/\/=\_} = $false
					
						if ($Credential)
						{
							Connect-WSMan -ComputerName ${/=\_/\__/=\_/\___} -Credential $Credential -ErrorAction SilentlyContinue
						}
						else
						{
							Connect-WSMan -ComputerName ${/=\_/\__/=\_/\___} -ErrorAction SilentlyContinue
						}
					
						${/=\/\/\/==\/\/=\_} = $true
						${/=\_/=\/\_/\__/=\} 		= ((Get-Item "WSMan:\$(${/=\_/\__/=\_/\___})\Service\Auth\CredSSP").Value -eq "true")
						${/===\/\/\_/\__/\_}		= ((Get-Item "WSMan:\$(${/=\_/\__/=\_/\___})\Client\Auth\CredSSP").Value -eq "true")

						${__/=\_/\/\/=\/\_/}.IsServer = ${/=\_/=\/\_/\__/=\}
						${__/=\_/\/\/=\/\_/}.IsClient = ${/===\/\/\_/\__/\_}
												
						#Write-Verbose "WSMan:\$($computer)\Client\Auth\CredSSP"
						if (${/===\/\/\_/\__/\_})
						{
							# Start collecting the CredSSP client role configuration on the remote computer by querying the registry remotely (using WMI)
							
							${__/\/\__/=====\/\} = $null
							
							try
							{
								if ($Credential)
								{
									# Get the WMI registry provider using credentials
									${__/\/\__/=====\/\} = Get-WmiObject -List -Namespace root\default -ComputerName ${/=\_/\__/=\_/\___} -Credential $Credential | Where-Object {$_.Name -eq "StdRegProv"}
								}
								else
								{
									# Get the WMI registry provider using current credentials
									${__/\/\__/=====\/\} = Get-WmiObject -List -Namespace root\default -ComputerName ${/=\_/\__/=\_/\___} | Where-Object {$_.Name -eq "StdRegProv"}
								}
								
								${/=\_/\/===\__/===}					= 2147483650
								${__/\_/\/\/=\/\_/=} 	= ${__/\/\__/=====\/\}.GetDWORDValue(${/=\_/\/===\__/===}, "SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation", "AllowFreshCredentials").uValue
								if (${__/\_/\/\/=\/\_/=} -ne $null)
								{
									${__/=\_/\/\/=\/\_/}.AllowFreshCredentials = ${__/\_/\/\/=\/\_/=}
								
									# Query the delegate computers from the registry
									${/======\/\/=\/\/\} = ${__/\/\__/=====\/\}.EnumValues(${/=\_/\/===\__/===}, "SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentials").sNames | foreach {
															${/===\__/=\_/\____} = ${__/\/\__/=====\/\}.GetStringValue(${/=\_/\/===\__/===}, "SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentials", $_).sValue
															if (${/===\__/=\_/\____} -like "wsman/*") { ${/===\__/=\_/\____}.substring(6) } else { ${/===\__/=\_/\____} } 
														}
														
									# Add the found delegate computers to the configuration object!
									${__/=\_/\/\/=\/\_/}.ClientDelegateComputer = ${/======\/\/=\/\/\}
														
								}
							}
							catch
							{
								throw "ERROR while reading remote registry on computer `"${/=\_/\__/=\_/\___}`": $($_.Exception.Message)"

								${__/=\_/\/\/=\/\_/}.AllowFreshCredentials = "ERROR"
							}
						}
					}
					catch 
					{
						${/=\_/==\/\_/\/\/=}  = $_.Exception.Message
						${__/====\____/\/\/} 	= ""

						if (${/=\_/==\/\_/\/\/=} -like "Access is denied.*" -or ${/=\_/==\/\_/\/\/=} -like "The user name or password is incorrect*")
						{
							${__/====\____/\/\/} = "Please supply proper credentials."
						}

						throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSACAAdwBoAGkAbABlACAAYwBvAG4AbgBlAGMAdABpAG4AZwAgAHQAbwAgAFcAUwBNAEEATgAgAG8AbgAgACQAewAvAD0AXABfAC8AXABfAF8ALwA9AFwAXwAvAFwAXwBfAF8AfQAgAG8AcgAgAGcAYQB0AGgAZQByAGkAbgBnACAAQwByAGUAZABTAFMAUAAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgA6ACAAIgAkAHsALwA9AFwAXwAvAD0APQBcAC8AXABfAC8AXAAvAFwALwA9AH0AIgAuACAAJAB7AF8AXwAvAD0APQA9AD0AXABfAF8AXwBfAC8AXAAvAFwALwB9AA==')))
					}
					finally
					{
						if (${/=\/\/\/==\/\/=\_})
						{
							Disconnect-WSMan -ComputerName ${/=\_/\__/=\_/\___}
						}
					}
				}
				else
				{
					throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIABjAG8AdQBsAGQAIABuAG8AdAAgAGMAbwBuAG4AZQBjAHQAIAB0AG8AIABXAFMATQBBAE4AIABvAG4AIAAiACQAewAvAD0AXABfAC8AXABfAF8ALwA9AFwAXwAvAFwAXwBfAF8AfQAiAD8AIABJAHMAIABXAGkAbgBSAE0AIABzAGUAcgB2AGkAYwBlACAAcgB1AG4AbgBpAG4AZwA/ACAAUgB1AG4AIAAiAFcAaQBuAFIATQAgAHEAdQBpAGMAawBjAG8AbgBmAGkAZwAgAC0AZgBvAHIAYwBlACIAIABvAG4AIAB0AGgAaQBzACAAYwBvAG0AcAB1AHQAZQByACEA')))
				}
			}
			
			Write-Output ${__/=\_/\/\/=\/\_/}
		}
	}
	
<#
.SYNOPSIS
Retrieves the CredSSP configuration for the local or remote computers. 
   
.DESCRIPTION
Get-WSManCredSSPConfiguration retrieves CredSSP configuration for one
or more computers and returns the configuration as a custom PS object:

  computerName              computer for this configuration
  IsServer                  Has the computer the CredSSP server role?
  IsClient                  Has the computer the CredSSP client role?
  AllowFreshCredentials     Value of the Allow Fresh Credentials
  ClientDelegateComputer    If client role enabled, this holds the array 
                            of computers where the computer can delegate
							credentials to.

Get-WSManCredSSPConfiguration connects to other computers with either 
current credentials or the specified credentials. These credentials must 
have administrative privileges. WSMan must have been enabled on the
computers in order to connect.
   
.PARAMETER ComputerName
When specified, one or more computers to get the CredSSP configuration for.
(Get-WSManCredSSPConfiguration connects to other computers with either 
current credentials or the specified credentials.)
Wen not specified, the CredSSP configuration for the current computer
is returned.

.PARAMETER Credential
When specified, this is the credential that is used to connect to other computers.

.EXAMPLE
PS> Get-WSManCredSSPConfiguration

Gets the CredSSP configuration for the local computer, for example:

computerName           : laptop01.domain.com
IsServer               : False
IsClient               : True
AllowFreshCredentials  : 1
ClientDelegateComputer : {server01.domain.com, server02.domain.com}

.EXAMPLE
PS> Get-WSManCredSSPConfiguration -computername server01.domain.com 

Connects to server01.domain.com with current credentials and gets the
CredSSP configuration:

computerName           : server01.domain.com
IsServer               : True
IsClient               : false
AllowFreshCredentials  : NA
ClientDelegateComputer : 

.EXAMPLE
PS> Get-WSManCredSSPConfiguration -computername server01.domain.com -credential $admincred

Connects to server01.domain.com with the credentials $admincred and gets the
CredSSP configuration:

computerName           : server01.domain.com
IsServer               : True
IsClient               : false
AllowFreshCredentials  : NA
ClientDelegateComputer : 

.EXAMPLE
PS> Get-WSManCredSSPConfiguration | select -expand ClientDelegateComputer

Gets the CredSSP configuration for the local computer and returns the
array of computers for which the local computer may delegate credentials:

server01.domain.com
server02.domain.com


.NOTES
Author:      Victor Vogelpoel
Date:        Oct 2013
Inspired by: http://www.ravichaganti.com/blog/?p=1902

IMPORTANT: Get-WSManCredSSPConfiguration must be invoked in an elevated
PowerShell session. Start PowerShell session with "Run-as administrator"

.LINK
Get-WSManCredSSP

See Victor's blogpost about Get-WSManCredSSPConfiguration:
http://blog.victorvogelpoel.nl/2014/03/03/powershell-get-wsmancredsspconfiguration-getting-credssp-configuration-for-local-or-remote-computers/

Scripting guys about CredSSP:
http://blogs.technet.com/b/heyscriptingguy/archive/2012/11/14/enable-powershell-quot-second-hop-quot-functionality-with-credssp.aspx

#>
}


# Get-WSManCredSSPConfiguration -computerName server01.domain.com -Credential (Get-Credential) -Verbose
# Get-WSManCredSSPConfiguration $env:COMPUTERNAME
# Get-WSManCredSSPConfiguration -Verbose



