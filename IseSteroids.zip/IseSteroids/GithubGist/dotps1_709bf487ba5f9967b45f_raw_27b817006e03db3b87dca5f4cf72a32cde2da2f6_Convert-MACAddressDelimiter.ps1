﻿function Convert-MACAddressDelimiter
{
    [CmdletBinding()]
    [OutputType([String])]
    Param 
    (
        [Parameter(Position = 0, 
                   Mandatory = $true, 
                   ValueFromPipeline = $true, 
                   ValueFromPipelineByPropertyName = $true)]
        [ValidateScript({${_/\_/\/==\_/====\} = @(
                                           $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFsAMAAtADkAYQAtAGYAXQB7ADIAfQA6ACkAewA1AH0AKABbADAALQA5AGEALQBmAF0AewAyAH0AKQAkAA==')))
                                           $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFsAMAAtADkAYQAtAGYAXQB7ADIAfQAtACkAewA1AH0AKABbADAALQA5AGEALQBmAF0AewAyAH0AKQAkAA==')))
                                           $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFsAMAAtADkAYQAtAGYAXQB7ADQAfQAuACkAewAyAH0AKABbADAALQA5AGEALQBmAF0AewA0AH0AKQAkAA==')))
                                           $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFsAMAAtADkAYQAtAGYAXQB7ADEAMgB9ACkAJAA=')))
                                      )
                                      if ($_ -match (${_/\_/\/==\_/====\} -join '|')){ $true } else { throw "The argument '$_' does not match a valid MAC address format." } })]
        [string]
        $MacAddress,
        [Parameter(ValueFromPipelineByPropertyName=$true)]
        [ValidateSet(':', '-', '.', $null)]
        [string]
        $Delimiter = ':'
    )
    ${____/\___/\/=====} = $MacAddress -replace '\W'
    switch ($Delimiter) 
    {
        { $_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgB8AC0A'))) } { for (${_/\/\_/\___/=\/==} = 2; ${_/\/\_/\___/=\/==} -le 14; ${_/\/\_/\___/=\/==} += 3) { ${_/=\_/=\____/\/\_} = ${____/\___/\/=====} = ${____/\___/\/=====}.Insert(${_/\/\_/\___/=\/==}, $_) } break }
        '.'                 { for (${_/\/\_/\___/=\/==} = 4; ${_/\/\_/\___/=\/==} -le 9; ${_/\/\_/\___/=\/==} += 5)  {${_/=\_/=\____/\/\_} = ${____/\___/\/=====} = ${____/\___/\/=====}.Insert(${_/\/\_/\___/=\/==}, $_) } break }
        default             { ${_/=\_/=\____/\/\_} = ${____/\___/\/=====} }
    }
    return ${_/=\_/=\____/\/\_}
}