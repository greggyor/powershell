﻿$InitialStartMode = Get-CimInstance -ClassName Win32_Service -Filter "Name = 'RemoteRegistry'" | select -ExpandProperty StartMode
gsv RemoteRegistry | Set-Service -StartupType Manual | sasv
$CurrentStartMode = Get-CimInstance -ClassName Win32_Service -Filter "Name = 'RemoteRegistry'" | select -ExpandProperty StartMode
echo "Original Start Mode :   $InitialStartMode"
echo "Current Start Mode  :   $CurrentStartMode"
$srv = 'localhost'
$uninstallkey = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall"
$type = [Microsoft.Win32.RegistryHive]::LocalMachine
$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($type, $Srv)
$regkey = $reg.OpenSubKey($uninstallkey)
$subkeys = $regKey.GetSubKeyNames()
foreach ($key in $subkeys){
    $thisKey = $uninstallkey+"\\"+$key
    $thisSubKey = $reg.OpenSubKey($thiskey)
    $displayName = $thisSubKey.GetValue("DisplayName")
    Write-Host $displayName
}
gsv RemoteRegistry | spsv 
gsv RemoteRegistry | Set-Service -StartupType $InitialStartMode
$CurrentStartMode = Get-CimInstance -ClassName Win32_Service -Filter "Name = 'RemoteRegistry'" | select -ExpandProperty StartMode
echo "Original Start Mode :   $InitialStartMode"
echo "Current Start Mode  :   $CurrentStartMode"