﻿${00101010100100100} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
${10110001100100000} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
${00001011010101001} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))

${01111001001101111} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgAxADEALgAwAA==')))
${10000111011010001} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
${10000000110101110} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABhAHQAYQBiAGEAcwBlAHMA')))
${10000010001000000} = "${10000111011010001}"

${00001001001100111} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAG0AcAA=')))
${01111011001111000} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAG0AcAA=')))

sqllocaldb create ${00001001001100111} -s




${10001101111101011} = @"
CREATE DATABASE ${01111011001111000}
GO

RESTORE DATABASE ${01111011001111000}
FROM DISK = N'${00101010100100100}'
WITH REPLACE, RECOVERY,
MOVE N'${10110001100100000}' TO N'${10000000110101110}\${10000010001000000}.mdf',
MOVE N'${00001011010101001}' TO N'${10000000110101110}\${10000010001000000}.ldf',
NOUNLOAD, STATS = 5
"@

sqlcmd -S "(localdb)\${00001001001100111}" -Q ${10001101111101011}






sqllocaldb stop ${00001001001100111}
sqllocaldb delete ${00001001001100111}




${10001101111101011} = @"
CREATE DATABASE ${10000111011010001}
ON (Name = '${10110001100100000}', Filename ='${10000000110101110}\${10000010001000000}.mdf')
LOG ON (Name ='${00001011010101001}', Filename ='${10000000110101110}\${10000010001000000}.ldf')
FOR ATTACH;
GO
"@

sqlcmd -S "(localdb)\${01111001001101111}" -Q ${10001101111101011}

