﻿# Mapping Registry
${/==\/\___/\/\/\__} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEUAWQBfAEwATwBDAEEATABfAE0AQQBDAEgASQBOAEUAXABTAG8AZgB0AHcAYQByAGUAXABNAGkAYwByAG8AcwBvAGYAdABcAFcAaQBuAGQAbwB3AHMAXABDAHUAcgByAGUAbgB0AFYAZQByAHMAaQBvAG4AXABVAG4AaQBuAHMAdABhAGwAbAA=')))
ndr -Name Uninstall -PSProvider Registry -Root ${/==\/\___/\/\/\__}

ls Uninstall:

rdr -Name Uninstall # remove Uninstall:


