﻿function _____/\/\__/=\/\/= {
    [CmdletBinding(DefaultParameterSetName='Default')]
    param (
        [Parameter(Mandatory=$true, ParameterSetName='Default', Position=0)]
        $Default,

        [Parameter(Mandatory=$true, ParameterSetName='Alternate')]
        
        $Alternate,

        [Parameter(Position=10)]
        $Positional
    )

    Write-Output $PSBoundParameters
}

_____/\/\__/=\/\/= -?





