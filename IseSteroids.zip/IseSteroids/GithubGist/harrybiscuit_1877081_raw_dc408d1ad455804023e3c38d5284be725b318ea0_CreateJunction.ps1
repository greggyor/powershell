﻿$junctionPath = ".\junction.exe"
$toBeCreated = "c:\MyNewJunction";
if(!(Test-Path $junctionPath)){
    Write-Host "Expected Junction.exe to be in the same folder as this script file. This file is required to create the new junction."      
    Write-Host "Press any key to continue ..."
    $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}
Write-Host "Found junction.exe"
Write-Host "Enter the full path to the existing folder to which we will point the junction"
Write-Host "For example D:\My\Existing\Folder"
$existingPath = Read-Host "Path --> "

& $junctionPath $toBeCreated, $existingPath

Write-Host "Press any key to finish ..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

