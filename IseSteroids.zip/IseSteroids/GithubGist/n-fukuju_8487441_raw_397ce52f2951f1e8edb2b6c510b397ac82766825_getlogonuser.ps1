﻿${8} = "å¯¾è±¡ã®ãƒ›ã‚¹ãƒˆåã‹ã€IPã‚¢ãƒ‰ãƒ¬ã‚¹"
${6} = (Get-WmiObject Win32_ComputerSystem -ComputerName ${8}).UserName
# ãƒªãƒ¢ãƒ¼ãƒˆã‚¢ã‚¯ã‚»ã‚¹ã®è³‡æ ¼æƒ…å ±ã‚’æ˜Žç¤ºçš„ã«æŒ‡å®šã™ã‚‹å ´åˆ
${10} = "ãƒ¦ãƒ¼ã‚¶å"
${11} = "ãƒ‘ã‚¹ãƒ¯ãƒ¼ãƒ‰"
${9} = ConvertTo-SecureString -String ${11} -AsPlainText -Force
${7} = New-Object System.Management.Automation.PSCredential(${10}, ${9})
# ã‚³ãƒ³ã‚½ãƒ¼ãƒ«ã‹ã‚‰å…¥åŠ›ã™ã‚‹ãªã‚‰ã€PromptForCredentialã‚’ä½¿ã£ãŸæ–¹ãŒæ¥½
# $credential = $host.UI.PromptForCredential("è³‡æ ¼æƒ…å ±å…¥åŠ›", "","","")
${6} = (Get-WmiObject Win32_ComputerSystem -ComputerName ${8} -Credential ${7}).UserName
# ãƒ¦ãƒ¼ã‚¶åã‚’ActiveDirectoryã‹ã‚‰å–å¾—ã—ãŸã„å ´åˆ
${5} = "ãƒ‰ãƒ¡ã‚¤ãƒ³å"
${4} = ${6}
# å–å¾—ã—ãŸãƒ­ã‚°ã‚ªãƒ³ãƒ¦ãƒ¼ã‚¶ã«ã€ãƒ‰ãƒ¡ã‚¤ãƒ³åãŒä»˜ã„ã¦ã„ã‚‹å ´åˆã€å¤–ã—ã¦ãŠã
if(${6}.Contains("\")){
  ${4} = ${6}.Split("\")[1]
}
# .NETã®System.DirectoryServiceåå‰ç©ºé–“ã‚’ä½¿ç”¨ã™ã‚‹
# ãƒ­ãƒ¼ã‚«ãƒ«ç’°å¢ƒã«ActiveDirectoryå‘ã‘ã®PowerShellãƒ¢ã‚¸ãƒ¥ãƒ¼ãƒ«ãŒã‚ã‚‹ãªã‚‰ã€ãã¡ã‚‰ã§ã‚‚ã‚ˆã„ã‹ã‚‚
[void][Reflection.Assembly]::LoadWithPartialName("System.DirectoryServices")
${3} = "WinNT://{0}/{1}" -f ${5},${4}
${1} = New-Object System.DirectoryServices.DirectoryEntry(${3})
# å¿…è¦ãªã‚‰è³‡æ ¼æƒ…å ±ã‚’æŒ‡å®š
# $entry = New-Object System.DirectoryServices.DirectoryEntry($path, $admin, $pass)
${2} = ${1}.Properties["FullName"].Value.ToString()