﻿function GenerateFunction($functionName, $codeBlock)
{
	${11000001111001101} = ""
	foreach(${10101001101000100} in $args)
	{
		if(${11000001111001101}.Length -gt 0)
		{
			${11000001111001101} += ","
		}
		${11000001111001101} += "`$" + ${10101001101000100}
	}
	${10100110011000011} = 
$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAGYAdQBuAGMAdABpAG8AbgAgAGcAbABvAGIAYQBsADoAJABmAHUAbgBjAHQAaQBvAG4ATgBhAG0AZQAoACQAewAxADEAMAAwADAAMAAwADEAMQAxADEAMAAwADEAMQAwADEAfQApAA0ACgAJAAkAewANAAoACQAJAAkAJABjAG8AZABlAEIAbABvAGMAawANAAoACQAJAH0A')))
	Invoke-Expression ${10100110011000011}
}
GenerateFunction myfunc -codeBlock {echo "hello"}
GenerateFunction myAdd -codeBlock {$a + $b} a b
