﻿








Param(
    [String] $Folder = $PSScriptRoot 
)

${10010111100110111} = @(
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGEAdQB4AA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGIAYgBsAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGIAYwBmAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGIAbABnAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGIAcgBmAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGkAZAB4AA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGkAbABnAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGkAbgBkAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGwAbwBmAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGwAbwBnAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGwAbwBsAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGwAbwB0AA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGwAcAByAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAG4AbABvAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAG4AbABzAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAG8AdQB0AA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHAAeQBnAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHIAdQBuAC4AeABtAGwA'))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHMAeQBuAGMAdABlAHgA'))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHMAeQBuAGMAdABlAHgALgBnAHoA')))
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHQAZABvAA=='))),
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHQAbwBjAA==')))
)

${00111001110001001} = 0

Get-ChildItem $Folder -Recurse -Include ${10010111100110111} | foreach ($_) {
    Write-Host "Removing $($_ | Resolve-Path -Relative)"
    Remove-Item $_.FullName
    ${00111001110001001}++
}

if(${00111001110001001} -eq 0) {
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQBzACAAcgBlAG0AbwB2AGUAZAAgAGYAcgBvAG0AOgAgACQARgBvAGwAZABlAHIA')))
} else {
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADEAMQAwADAAMQAxADEAMAAwADAAMQAwADAAMQB9ACAAZgBpAGwAZQBzACAAcgBlAG0AbwB2AGUAZAAgAGYAcgBvAG0AOgAgACQARgBvAGwAZABlAHIA')))
}


