﻿
param(
    $prefix = 'TeamCity.',
    ${00011100011111100} = $env:TEAMCITY_BUILD_PROPERTIES_FILE + ".xml",
    [switch] $inTeamCity = (![String]::IsNullOrEmpty($env:TEAMCITY_VERSION))
)

if($inTeamCity){
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAFQAZQBhAG0AQwBpAHQAeQAgAHAAcgBvAHAAZQByAHQAaQBlAHMAIABmAHIAbwBtACAAJAB7ADAAMAAwADEAMQAxADAAMAAwADEAMQAxADEAMQAxADAAMAB9AA==')))
    ${00011100011111100} = (rvpa ${00011100011111100}).Path;

    ${01011110101100010} = New-Object System.Xml.XmlDocument
    ${01011110101100010}.XmlResolver = $null; 
    ${01011110101100010}.Load(${00011100011111100});
    ${00000100001010001} = @{};
    foreach(${00100101001110000} in ${01011110101100010}.SelectNodes("//entry")){
        ${10110101110101000} = ${00100101001110000}.key;
        ${01010100101101111} = ${00100101001110000}.'#text';
        ${00000100001010001}[${10110101110101000}] = ${01010100101101111};
        ${10110101110101000} = $prefix + ${10110101110101000};

        Write-Verbose ("[TeamCity] Set {0}={1}" -f ${10110101110101000},${01010100101101111});
        sv -Name:${10110101110101000} -Value:${01010100101101111} -Scope:1; 
    }
}


