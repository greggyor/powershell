﻿.\Get-SPOAccessToken.ps1


Function Invoke-SPORestMethod()
{
Param(
  [Uri]$Uri,
  [Object]$Body,
  [Hashtable]$Headers,
  [Microsoft.PowerShell.Commands.WebRequestMethod]$Method = [Microsoft.PowerShell.Commands.WebRequestMethod]::Get,
  [string]$AccessToken
)
    ${10010000010001000} = 'application/json;odata=verbose'
    if(-not $Headers) {
       $Headers = @{}    
    }
    $Headers["Accept"] = "application/json;odata=verbose"
    $Headers.Add('Authorization','Bearer ' + $AccessToken)
    irm -Method $Method -Uri $Uri -ContentType ${10010000010001000} -Headers $Headers -Body $Body 
}


