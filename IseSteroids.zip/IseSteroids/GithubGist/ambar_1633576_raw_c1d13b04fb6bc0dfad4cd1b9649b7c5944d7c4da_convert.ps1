﻿# mkdir
md output

# get-content , set-content -encoding
# æ‹¬å·æ˜¯å¿…é¡»çš„
ls *.txt | %{  gc $_ | sc -en utf8 ('output/'+$_.name) }