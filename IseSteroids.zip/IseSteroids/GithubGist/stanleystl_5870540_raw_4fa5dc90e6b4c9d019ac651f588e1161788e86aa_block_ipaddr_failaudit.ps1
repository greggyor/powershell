﻿${_________/=\_/=\/} = [DateTime]::Now.AddDays(-1) # check only last 24 hours

${__/\/=\_/=\___/==} = Get-EventLog -LogName 'Security' -InstanceId 4625 -After ${_________/=\_/=\/} | select @{n='IpAddress';e={$_.ReplacementStrings[-2]} } # select Ip addresses that has audit failure 
${__/\/=\/=\/\/\___} = ${__/\/=\_/=\___/==} | group-object -property IpAddress  | where {$_.Count -gt 20} | Select -property Name # get ip adresses, that have more than 20 wrong logins

${/==\__/\_/==\/\_/} = New-Object -ComObject hnetcfg.fwpolicy2 # get firewall object

${__/\_/\/\/=\_/===} = ${/==\__/\_/==\/\_/}.rules | where {$_.name -eq 'BlockAttackers'} # get firewall rule named 'BlockAttackers' (must be created manually)

${___/\____/\/\/=\/} = ${__/\_/\/\/=\_/===}.RemoteAddresses -split(',') #split the existing IPs into an array so we can easily search for existing IPs

${/=\/\/====\/\__/\} = ${__/\/=\/=\/\/\___} | where {$_.Name.Length -gt 1 -and  !(${___/\____/\/\/=\/} -contains $_.Name + '/255.255.255.255') } # get ip addresses that are not already in firewal rule. Include the subnet mask which is automatically added to the firewall remote IP declaration.

${/=\/\/====\/\__/\}| %{${__/\_/\/\/=\_/===}.remoteaddresses += ',' + $_.Name} # add IPs to firewall rule

