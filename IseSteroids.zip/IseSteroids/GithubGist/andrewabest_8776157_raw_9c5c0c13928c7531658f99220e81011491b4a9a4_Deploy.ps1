﻿Write-Host 'Copy the package payload over to the clickonce web application location'

${11} = ".\"
${8} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwATwBjAHQAbwBwAHUAcwBcAEEAcABwAGwAaQBjAGEAdABpAG8AbgBzAFwAJAB7AE8AYwB0AG8AcAB1AHMARQBuAHYAaQByAG8AbgBtAGUAbgB0AE4AYQBtAGUAfQBcAE4AZQB4AHQARwBlAG4ALgBDAGwAaQBjAGsATwBuAGMAZQBcACQAewBPAGMAdABvAHAAdQBzAFAAYQBjAGsAYQBnAGUAVgBlAHIAcwBpAG8AbgB9AFwAUABhAGMAawBhAGcAZQA=')))
${10} = @('*.pdb','mage.exe', '*.ps1', '*Build*', '*.pfx')

${12} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AE8AYwB0AG8AcAB1AHMAUABhAGMAawBhAGcAZQBOAGEAbQBlAH0ALgBlAHgAZQAuAG0AYQBuAGkAZgBlAHMAdAA=')))
${9} = Join-Path ${8} ${12}
${1} = Join-Path ${8} $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AE8AYwB0AG8AcAB1AHMAUABhAGMAawBhAGcAZQBOAGEAbQBlAH0ALgBhAHAAcABsAGkAYwBhAHQAaQBvAG4A')))

Write-Host 'Create package folder and copy everything'

New-Item -ItemType directory -Path ${8}
Get-ChildItem ${11} -Recurse -Exclude ${10} | Copy-Item -Destination ${8}

Write-Host 'Create app manifest'

& ".\Build\Mage.exe" -New Application -Name $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AE8AYwB0AG8AcAB1AHMAUABhAGMAawBhAGcAZQBOAGEAbQBlAH0AIAAkAHsATwBjAHQAbwBwAHUAcwBFAG4AdgBpAHIAbwBuAG0AZQBuAHQATgBhAG0AZQB9AA=='))) -ToFile ${9} -FromDirectory ${8} -Version $OctopusPackageVersion | Write-Host


Write-Host 'Create deploy manifest'

& ".\Build\Mage.exe" -New Deployment -AppManifest ${9} -Install true -Publisher "Andrew Best" -ProviderUrl $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBjAGkALwBBAHAAcABOAGEAbQBlAC4AJAB7AE8AYwB0AG8AcAB1AHMARQBuAHYAaQByAG8AbgBtAGUAbgB0AE4AYQBtAGUAfQAvAFAAYQBjAGsAYQBnAGUALwAkAHsATwBjAHQAbwBwAHUAcwBQAGEAYwBrAGEAZwBlAE4AYQBtAGUAfQAuAGEAcABwAGwAaQBjAGEAdABpAG8AbgA='))) -Version $OctopusPackageVersion -Name $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AE8AYwB0AG8AcAB1AHMAUABhAGMAawBhAGcAZQBOAGEAbQBlAH0AIAAkAHsATwBjAHQAbwBwAHUAcwBFAG4AdgBpAHIAbwBuAG0AZQBuAHQATgBhAG0AZQB9AA=='))) -ToFile ${1} | Write-Host

Write-Host 'Add deploy extension to files'

${7} = @('*.application', '*.manifest')
${6} = Get-ChildItem ${8} -Recurse -Exclude ${7}

foreach (${5} in ${6}) {
    ${4} = ${5}.name + ".deploy"
    Rename-Item -Path ${5} -NewName ${4}
}

Write-Host 'Add mapFileExtensions to deploy manifest so that it works with the *.deploy extension'

${2} = [xml](Get-Content $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAfQA='))))
${3} = ${2}.SelectSingleNode("//*[local-name() = 'deployment']")
${3}.SetAttribute("mapFileExtensions", "true")
${2}.Save($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEAfQA='))))








