﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ZipPath,
    [Parameter(Mandatory = $true)]
    [string]$TargetPath)
$ErrorActionPreference = 'Stop'
Add-Type -Assembly 'System.IO.Compression.FileSystem'
if (!(Test-Path -LiteralPath $TargetPath -PathType Container)) {
    $null = ni -Path $TargetPath -ItemType Directory
}
[System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $TargetPath)
