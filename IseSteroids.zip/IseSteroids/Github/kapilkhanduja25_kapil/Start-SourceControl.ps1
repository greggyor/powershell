﻿workflow Start-SourceControl
{



echo "Azure Automation Source Control via GitHub"
}
