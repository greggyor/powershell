﻿cd c:\vagrant
${2} = Get-Command choco -ErrorAction SilentlyContinue
if (!${2}) {
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAGkAbgBzAHQAYQBsAGwAIABDAGgAbwBjAG8AbABhAHQAZQB5AC4ALgAuAA==')))
	iex ((New-Object System.Net.WebClient).DownloadString($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvAGMAaABvAGMAbwBsAGEAdABlAHkALgBvAHIAZwAvAGkAbgBzAHQAYQBsAGwALgBwAHMAMQA=')))))
	refreshenv
}
else {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAG8AYwBvAGwAYQB0AGUAeQAgAGEAbAByAGUAYQBkAHkAIABpAG4AcwB0AGEAbABsAGUAZAA=')))
}
${1} = Get-Command git -ErrorAction SilentlyContinue
if (!${1}) {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAGkAbgBzAHQAYQBsAGwAIABHAGkAdAAuAC4ALgA=')))
    choco install git -params $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBHAGkAdABBAG4AZABVAG4AaQB4AFQAbwBvAGwAcwBPAG4AUABhAHQAaAA='))) --yes --limitoutput --no-progress
    refreshenv
}
else {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBpAHQAIABhAGwAcgBlAGEAZAB5ACAAaQBuAHMAdABhAGwAbABlAGQA')))
}
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAGkAbgBzAHQAYQBsAGwAIABDAG8AbABkAEYAdQBzAGkAbwBuACAAMQAxAC4ALgAuAA==')))
&.\ColdFusion_11_WWEJ_win64.exe -f silent.properties