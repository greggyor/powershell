﻿param(
    [string]$buildCorePowershellUrl = "https://opbuildstorageprod.blob.core.windows.net/opps1container/.openpublishing.buildcore.ps1",
    [string]$parameters
)

$errorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA=')))


echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABvAHcAbgBsAG8AYQBkACAAYgB1AGkAbABkACAAYwBvAHIAZQAgAHMAYwByAGkAcAB0ACAAdABvACAAbABvAGMAYQBsACAAdwBpAHQAaAAgAHMAbwB1AHIAYwBlACAAdQByAGwAOgAgACQAYgB1AGkAbABkAEMAbwByAGUAUABvAHcAZQByAHMAaABlAGwAbABVAHIAbAA=')))
${01001011011010001} = Split-Path -Parent $MyInvocation.MyCommand.Definition
${01100101011001111} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMQAwADAAMQAwADEAMQAwADEAMQAwADEAMAAwADAAMQB9AFwALgBvAHAAZQBuAHAAdQBiAGwAaQBzAGgAaQBuAGcALgBiAHUAaQBsAGQAYwBvAHIAZQAuAHAAcwAxAA==')))
iwr $buildCorePowershellUrl -OutFile $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMQAxADAAMAAxADAAMQAwADEAMQAwADAAMQAxADEAMQB9AA==')))


echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgB1AG4AIABiAHUAaQBsAGQAIABjAG8AcgBlACAAcwBjAHIAaQBwAHQAIAB3AGkAdABoACAAcABhAHIAYQBtAGUAdABlAHIAcwA6ACAAJABwAGEAcgBhAG0AZQB0AGUAcgBzAA==')))
& $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMQAxADAAMAAxADAAMQAwADEAMQAwADAAMQAxADEAMQB9AA=='))) $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABwAGEAcgBhAG0AZQB0AGUAcgBzAA==')))
exit $LASTEXITCODE
