﻿. $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAEEAcwBzAHUAbQBlAC4AcABzADEA')))
$fileRegions = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFIAZQBnAGkAbwBuAHMALgBqAHMAbwBuAA==')))
$fileAccountKeys = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAEEAYwBjAG8AdQBuAHQASwBlAHkAcwAuAGMAcwB2AA==')))
$fileKeyStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAEsAZQB5AFMAdABhAHQAdQBzAC4AYwBzAHYA')))
$regionData = (gc $fileRegions) -join "`n" | ConvertFrom-Json
$keys = @()
function GetKeyStatus($strAccount){
    $creds = GetCredentials($strAccount)
    foreach ($regionInfo in $regionData) {
        $keys += Get-KMSKeys -Region $regionInfo.Region -Credential $creds
    }
    foreach ($key in $keys){
        $region = $($key.KeyArn).split(":")[3].ToString()
        $acct = $($key.KeyArn).split(":")[4].ToString()
        $id = $($key.KeyId)
        try{
            $status = $(Get-KMSKeyRotationStatus -KeyId $id -Region $region -Credential $creds -ErrorAction Stop)
        } catch {
        }
        if($status){
            $acct + " " + $region + " " + $id + " " + $status
        } else {
            $acct + " " + $region + " " + $id + " " + $status
            $badKey = @{}
            $badKey.ID = $id
            $badKey.Acct = $acct
            $badKey.Region = $region
            $badKey.Creds = $creds
            EnableKeyRotation($badKey)
        }
    }
}
function EnableKeyRotation($badKey){
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvACAAZQBuAGEAYgBsAGUAIABsAG8AZwBpAGMAIABvAG4AOgA='))) $badKey.ID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgByAG8AbQAgAGEAYwBjAG8AdQBuAHQAOgA='))) $badKey.Acct $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBuACAAcgBlAGcAaQBvAG4AOgA='))) $badKey.Region
}
foreach ($acct in GetAccounts)
{
    GetKeyStatus($acct)
}