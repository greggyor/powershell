﻿function _/======\/=\/\_/== {
    ${__/==\/===\__/===} = @($env:PSModulePath -split ';')
    ${_/==\/=\/==\_/=\_} = Join-Path -Path ([Environment]::GetFolderPath('MyDocuments')) -ChildPath WindowsPowerShell\Modules
    ${___/\/\/\___/\_/\} = ${__/==\/===\__/===} | ? { $_ -eq ${_/==\/=\/==\_/=\_} }
    if (-not ${___/\/\/\___/\_/\}) {
        ${___/\/\/\___/\_/\} = ${__/==\/===\__/===} | select -Index 0
    }
    ${____/=\/===\/\/=\} = '1.4'
    ${_/==\__/\_/=\/===} = "https://github.com/willyd/PsUtils/archive/v$(${____/=\/===\/\/=\}).zip"
    ${__/===\/\/\______} = ${___/\/\/\___/\_/\} + "\PsUtilsv$(${____/=\/===\/\/=\}).zip"
    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAHcAbgBsAG8AYQBkAGkAbgBnACAAUABzAFUAdABpAGwAcwAgAGYAcgBvAG0AIAAkAHsAXwAvAD0APQBcAF8AXwAvAFwAXwAvAD0AXAAvAD0APQA9AH0A')))
    ${_/\_/\__/\/=\_/\/} = (New-Object Net.WebClient)
    ${_/\_/\__/\/=\_/\/}.Proxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    ${_/\_/\__/\/=\_/\/}.DownloadFile($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8ALwA9AD0AXABfAF8ALwBcAF8ALwA9AFwALwA9AD0APQB9AA=='))), ${__/===\/\/\______})
    Add-Type -assembly "system.io.compression.filesystem"
    [io.compression.zipfile]::ExtractToDirectory(${__/===\/\/\______}, ${___/\/\/\___/\_/\})
    mi (${___/\/\/\___/\_/\} + "PsUtils-$(${____/=\/===\/\/=\})")  (${___/\/\/\___/\_/\} + '\PsUtils')
}
_/======\/=\/\_/==