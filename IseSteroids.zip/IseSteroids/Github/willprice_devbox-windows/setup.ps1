﻿Import-Module Boxstarter.Chocolatey
${/=\_/====\__/=\/\} = "DevBox"
${_/=\______/===\/=} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AC8APQBcAF8ALwA9AD0APQA9AFwAXwBfAC8APQBcAC8AXAB9AC4AQgBvAHgAUwB0AGEAcgB0AGUAcgAuAHAAcwAxAA==')))
New-PackageFromScript -Source $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AF8ALwA9AFwAXwBfAF8AXwBfAF8ALwA9AD0APQBcAC8APQB9AA=='))) -PackageName $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AC8APQBcAF8ALwA9AD0APQA9AFwAXwBfAC8APQBcAC8AXAB9AA==')))
Invoke-BoxstarterBuild $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AC8APQBcAF8ALwA9AD0APQA9AFwAXwBfAC8APQBcAC8AXAB9AA==')))
${/==\/=\/\/\_/=\/\} = Get-Credential Administrator
Install-BoxstarterPackage -PackageName $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AC8APQBcAF8ALwA9AD0APQA9AFwAXwBfAC8APQBcAC8AXAB9AA=='))) -Credential ${/==\/=\/\/\_/=\/\}
