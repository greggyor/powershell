﻿param(
    [string]$buildCorePowershellUrl = "https://opbuildstoragesandbox2.blob.core.windows.net/opps1container/.openpublishing.buildcore.ps1",
    [string]$parameters
)
$errorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA=')))
echo "download build core script to local with source url: $buildCorePowershellUrl"
${01101011111101111} = Split-Path -Parent $MyInvocation.MyCommand.Definition
${01010101111010010} = "${01101011111101111}\.openpublishing.buildcore.ps1"
iwr $buildCorePowershellUrl -OutFile "${01010101111010010}"
echo "run build core script with parameters: $parameters"
& "${01010101111010010}" "$parameters"
exit $LASTEXITCODE
