﻿

param( [string[]] ${2}, [string] $Root = "$PSScriptRoot" )

if (Test-Path $PSScriptRoot/update_vars.ps1) { . $PSScriptRoot/update_vars.ps1 }
${global:8} = Resolve-Path $Root

if ((${2}.Length -gt 0) -and (${2}[0] -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgByAGEAbgBkAG8AbQAgACgALgArACkA'))))) {
    [array] ${6} = lsau

    ${7} = [int]$Matches[1]
    ${4} = (Get-Random -Maximum ${7})
    Write-Host "TESTING GROUP $(${4}+1) of ${7}"

    ${5} = [int](${6}.Count / ${7}) + 1
    ${2} = ${6} | select -First ${5} -Skip (${5}*${4}) | % { $_.Name }

    Write-Host (${2} -join ' ')
    Write-Host ('-'*80)
}

${1} = [ordered]@{
    Force = $true
    Push = $false

    Report = @{
        Type = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBhAHIAawBkAG8AdwBuAA==')))                                   
        Path = "$PSScriptRoot\Update-Force-Test-${4}.md"      
        Params= @{                                          
            Github_UserRepo = $Env:github_user_repo         
            NoAppVeyor  = $false                            
            Title       = "Update Force Test - Group ${4}"
            UserMessage = "[Update report](https://gist.github.com/$Env:gist_id) | **USING AU NEXT VERSION**"       
        }
    }

    Gist = @{
        Id     = $Env:gist_id_test                          
        ApiKey = $Env:github_api_key                        
        Path   = "$PSScriptRoot\Update-Force-Test-${4}.md"       
        Description = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBwAGQAYQB0AGUAIABGAG8AcgBjAGUAIABUAGUAcwB0ACAAUgBlAHAAbwByAHQAIAAjAHAAbwB3AGUAcgBzAGgAZQBsAGwAIAAjAGMAaABvAGMAbwBsAGEAdABlAHkA')))
    }
}


${global:3} = updateall -Name ${2} -Options ${1}
