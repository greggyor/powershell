﻿
Write-Error "Don't run this script file. Use the Powershell-ISE, RUN SELECTION (Just like in Sql Management Studio!)(F8 is the shortcut) to easily test commands" -ErrorAction Stop
$PSHOME
$host             
$host.Runspace
ipmo ServerManager; Add-WindowsFeature PowerShell-ISE  
[IntPtr]::Size
explorer.exe C:\Windows\SysWOW64\WindowsPowerShell\v1.0\
explorer.exe C:\Windows\System32\WindowsPowerShell\v1.0\
TOTALCMD.EXE C:\Windows\System32\WindowsPowerShell\v1.0\  
Add-PSSnapin Microsoft.SharePoint.PowerShell 
Get-ExecutionPolicy
Set-ExecutionPolicy 'RemoteSigned'
[Microsoft.PowerShell.ExecutionPolicy]::Restricted    
Get-Verb
Get-  
function Get-MntLocation { Write-Host "Utrecht, the Netherlands" }
Get-PSProvider
Get-PsDrive
D:
new-PSDrive -name font -PSProvider filesystem  -root(resolve-Path C:\Windows\Fonts\)
dir env:
dir hkcu:,  
function Foo {"Hey dude !"}
dir function:
$bar = "No problem !"
dir variable:
gl
explorer.exe .
cd font:
dir function:D:
function font: { cd font: }
gal dir
gal -Definition Get-ChildItem
gal
dir
(dir).GetType()
(dir)[0].tostring()
(dir)[0].GetType()
(dir)[0].FullName
dir cert: -Recurse -CodeSigningCert
psEdit $pshome\FileSystem.format.ps1xml 
$PWD.GetType()
$PWD.Path.GetType()
$PWD.tostring()
sp -path "HKLM:\Software\CompanyName\ApplicationName" -name "InstallLocation" -value "C:\Program Files\CompanyName"
notepad $profile
. $profile
psedit $profile.AllUsersAllHosts
