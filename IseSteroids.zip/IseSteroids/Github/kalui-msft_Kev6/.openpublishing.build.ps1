﻿param(
    [string]$buildCorePowershellUrl = "https://opbuildstoragesandbox2.blob.core.windows.net/opps1container/.openpublishing.buildcore.ps1",
    [string]$parameters
)
$errorActionPreference = 'Stop'
echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABvAHcAbgBsAG8AYQBkACAAYgB1AGkAbABkACAAYwBvAHIAZQAgAHMAYwByAGkAcAB0ACAAdABvACAAbABvAGMAYQBsACAAdwBpAHQAaAAgAHMAbwB1AHIAYwBlACAAdQByAGwAOgAgACQAYgB1AGkAbABkAEMAbwByAGUAUABvAHcAZQByAHMAaABlAGwAbABVAHIAbAA=')))
$repositoryRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$buildCorePowershellDestination = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAByAGUAcABvAHMAaQB0AG8AcgB5AFIAbwBvAHQAXAAuAG8AcABlAG4AcAB1AGIAbABpAHMAaABpAG4AZwAuAGIAdQBpAGwAZABjAG8AcgBlAC4AcABzADEA')))
Invoke-WebRequest $buildCorePowershellUrl -OutFile $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAHUAaQBsAGQAQwBvAHIAZQBQAG8AdwBlAHIAcwBoAGUAbABsAEQAZQBzAHQAaQBuAGEAdABpAG8AbgA=')))
echo $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgB1AG4AIABiAHUAaQBsAGQAIABjAG8AcgBlACAAcwBjAHIAaQBwAHQAIAB3AGkAdABoACAAcABhAHIAYQBtAGUAdABlAHIAcwA6ACAAJABwAGEAcgBhAG0AZQB0AGUAcgBzAA==')))
& $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAHUAaQBsAGQAQwBvAHIAZQBQAG8AdwBlAHIAcwBoAGUAbABsAEQAZQBzAHQAaQBuAGEAdABpAG8AbgA='))) $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABwAGEAcgBhAG0AZQB0AGUAcgBzAA==')))
exit $LASTEXITCODE
