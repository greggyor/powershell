﻿ 
$vhdxPath = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAA6AFwAVgBNAF8ARABzAFwASAB5AHAAZQByAFYAXwBEAGkAcwBrAHMAXABTAFAAMgAwADEANgBcAFMAUAAyADAAMQA2AC0AcwBpAG4AZwBsAGUALQBzAGUAcgB2AGUAcgAtAGQAbwBjAG8AXAB3AGkAbgAyADAAMQAyAFIAMgBTAHQAZABfAEcAcgBvAHcAaQBuAGcALgB2AGgAZAB4AA==')))
$VM = New-VM  -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBQADIAMAAxADYALQBTADEA')))  -MemoryStartUpBytes  8GB   -Path  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQBEAGEAdABhAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFwASAB5AHAAZQByAC0AVgA=')))   -VHDPath   $vhdxPath    -ErrorAction  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA='))) -Verbose  $True
# set static MAC address for the router to set the Static IP
Add-VMNetworkAdapter  $vm   -StaticMacAddress $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAAwADoAQwAwADoAOAAyADoAMAAxADoAMgAwADoAMQA2AA=='))) -SwitchName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBFAEUA'))) 
Set-VMProcessor  $VM.name  -Count 4  -Reserve 25 -Maximum 75 -RelativeWeight 200
