﻿Function _01001101001011100 {
   if(Test-Path -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMAXABzAGUAYwByAGUAdABzAC4AcABzADEA')))) {
      return $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMAXABzAGUAYwByAGUAdABzAC4AcABzADEA')))
   }
}
. (_01001101001011100)
if(Test-Path -Path $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAB1AGwAbABTAGUAcgB2AGUAcgBpAG4AZgBvAC4AcABzADEA'))) -join '\')) {
   . "$($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAB1AGwAbABTAGUAcgB2AGUAcgBpAG4AZgBvAC4AcABzADEA'))) -join '\')"
}
Function _00010011110101101 {
   return (_00001101111110001 -Retries 20 -TimeOut 15 -Uri $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvAGkAZABlAG4AdABpAHQAeQAuAGEAcABpAC4AcgBhAGMAawBzAHAAYQBjAGUAYwBsAG8AdQBkAC4AYwBvAG0ALwB2ADIALgAwAC8AdABvAGsAZQBuAHMA')))) -Method POST -Body $(@{"auth" = @{"RAX-KSKEY:apiKeyCredentials" = @{"username" = $($d.rs_username); "apiKey" = $($d.rs_apikey)}}} | convertTo-Json) -ContentType application/json)
}
Function _00001111000001011 {
   return @{"X-Auth-Token"=((_00010011110101101).access.token.id)}
}
Function _00010100001001001 {
   param (
      [string]$logSource
   )
   if($logSource -ne $null) {
      if([System.Diagnostics.EventLog]::SourceExists($logSource)) {
         return
      }
      else {
         New-EventLog -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHYATwBwAHMA'))) -Source $logSource
      }
   }
   else {
      Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUALQBFAHYAZQBuAHQATABvAGcAIAB3AGEAcwAgAHAAYQBzAHMAZQBkACAAYQAgAG4AdQBsAGwAIAB2AGEAbAB1AGUAIABmAG8AcgAgAGwAbwBnAHMAbwB1AHIAYwBlAA==')))
      return
   }
}
_00010100001001001 -logSource rsCommon
Function Get-rsDetailsServers
{
   $catalog = _00010011110101101
   $endpoints = ($catalog.access.serviceCatalog | ? name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBsAG8AdQBkAFMAZQByAHYAZQByAHMATwBwAGUAbgBTAHQAYQBjAGsA')))).endpoints.publicURL
   foreach( $endpoint in $endpoints )
   {
      $temp = (_00001101111110001 -Uri $($endpoint,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBlAHIAcwAvAGQAZQB0AGEAaQBsAA=='))) -join "/") -Method GET -Headers $(_00001111000001011) -ContentType application/json)
      $servers = $servers,$temp
   }
   return ( ($servers.servers | ? {@($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAZAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGsAbgBvAHcAbgA=')))) -notcontains $_.status}) )
}
Function _00001101111110001 {
   param (
      [string][ValidateNotNull()]$Uri,
      [string][ValidateSet('GET', 'PUT', 'POST', 'DELETE', ignorecase=$true)]$Method,
      [string]$Body,
      [hashtable]$Headers,
      [string][ValidateSet('application/json', 'application/xml', ignorecase=$true)]$ContentType = "application/json",
      [uint32]$Retries = 2,
      [uint32]$TimeOut = 10
   )
   $i = 0
   $ContentType = $ContentType.ToLower()
   do {
      if($i -ge $Retries) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIABzAGUAcgB2AGkAYwBlACAAYwBhAHQAYQBsAG8AZwAsACAAcgBlAGEAYwBoAGUAZAAgAG0AYQB4AGkAbQB1AG0AIAByAGUAdAByAGkAZQBzAA==')))
         return $null
      }
      if($Method.ToLower() -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABvAHMAdAA='))) -or $Method.ToLower() -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AHQA')))) {
         try {
            $Data =  (Invoke-RestMethod -Uri $Uri -Method $Method.ToUpper() -Body $Body -Headers $Headers -ContentType $ContentType -ErrorAction SilentlyContinue)
         }
         catch {
            if( (($error[0].Exception.Response.StatusCode.value__) -ge 500) -or ($Error[0].Exception.Message -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAbQBvAHQAZQAgAG4AYQBtAGUAIABjAG8AdQBsAGQAIABuAG8AdAAgAGIAZQAgAHIAZQBzAG8AbAB2AGUAZAA6ACoA')))) ) {
               Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "API call Failed `n $Method`: $Uri `n $Body `n $($_.Exception.Message) `n $($_.ErrorDetails.Message)"
            }
            else {
               Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "API call Failed `n $Method`: $Uri `n $Body `n $($_.Exception.Message) `n $($_.ErrorDetails.Message)"
               break
            }
         }
      }
      else {
         try {
            $Data =  (Invoke-RestMethod -Uri $Uri -Method $Method.ToUpper() -Headers $Headers -ContentType $ContentType -ErrorAction SilentlyContinue)
         }
         catch {
            if( (($error[0].Exception.Response.StatusCode.value__) -ge 500) -or ($Error[0].Exception.Message -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAbQBvAHQAZQAgAG4AYQBtAGUAIABjAG8AdQBsAGQAIABuAG8AdAAgAGIAZQAgAHIAZQBzAG8AbAB2AGUAZAA6ACoA')))) ) {
               Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "API call Failed `n $Method`: $Uri `n $Body `n $($_.Exception.Message) `n $($_.ErrorDetails.Message)"
            }
            else {
               Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "API call Failed `n $Method`: $Uri `n $Body `n $($_.Exception.Message) `n $($_.ErrorDetails.Message)"
               break
            }
         }
      }
      $i++
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 10002 -Message "Failed API call trying again in $TimeOut seconds`n $($_.Exception.Message)"
         if($i -ge $Retries) {
            return $null
         }
         else {
            Start-Sleep -Seconds $TimeOut
         }
      }
   }
   while($Data -eq $null)
   return $Data
}
Function _00010100001001001 {
   param (
      [string]$logSource
   )
   if($logSource -ne $null) {
      if([System.Diagnostics.EventLog]::SourceExists($logSource)) {
         return
      }
      else {
         New-EventLog -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHYATwBwAHMA'))) -Source $logSource
      }
   }
   else {
      Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUALQBFAHYAZQBuAHQATABvAGcAIAB3AGEAcwAgAHAAYQBzAHMAZQBkACAAYQAgAG4AdQBsAGwAIAB2AGEAbAB1AGUAIABmAG8AcgAgAGwAbwBnAHMAbwB1AHIAYwBlAA==')))
      return
   }
} 
Function _10101010101101000 {
   param([string] $value)
   $base = gwmi -n root\wmi -cl CitrixXenStoreBase
   $sid = $base.AddSession($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB5AE4AZQB3AFMAZQBzAHMAaQBvAG4A'))))
   $session = gwmi -n root\wmi -q "select * from CitrixXenStoreSession where SessionId=$($sid.SessionId)"
   $data = $session.GetValue($value).value -replace "`"", ""
   return $data
}
Function _10101100011100101 {
   . (_01001101001011100)
   if(Test-Path -Path $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAGQAaQBjAGEAdABlAGQALgBjAHMAdgA='))) -join '\')) {
      $Data = Import-Csv $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAGQAaQBjAGEAdABlAGQALgBjAHMAdgA='))) -join '\')
      if(($Data) -ne $null) {
         return $Data
      }
   }
   if((Test-Path -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMAXABkAGUAZABpAGMAYQB0AGUAZAAuAGMAcwB2AA=='))))  -and (!(Test-Path -Path $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAGQAaQBjAGEAdABlAGQALgBjAHMAdgA='))) -join '\')))) {
      $Data = Import-Csv $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMAXABkAGUAZABpAGMAYQB0AGUAZAAuAGMAcwB2AA==')))
      if(($Data) -ne $null) {
         return $Data
      }
   }
   return $null
}
Function _10100011101000001 {
   $base = gwmi -n root\wmi -cl CitrixXenStoreBase -ErrorAction SilentlyContinue
   if($base) {
      return $true
   }
   else {
      return $false
   }
}
Function _01101001110101001 {
   param (
      [string]$Value
   )
   if(_10100011101000001) {
      $Data = _10101010101101000 -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBtAC0AZABhAHQAYQAvAHUAcwBlAHIALQBtAGUAdABhAGQAYQB0AGEALwByAGEAeABfAGQAcwBjAF8AYwBvAG4AZgBpAGcA')))
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIAByAG8AbABlAA==')))
      }
      if($Data -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBzAFAAdQBsAGwAUwBlAHIAdgBlAHIALgBwAHMAMQA=')))) {
         return $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGwAbAA=')))
      }
      else {
         return $Data
      }
   }
   else {
      $Data = _10101100011100101
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIAByAG8AbABlAA==')))
      }
      if((($Data | ? {$_.name -eq $Value}).rax_dsc_config) -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBzAFAAdQBsAGwAUwBlAHIAdgBlAHIALgBwAHMAMQA=')))) {
         return $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGwAbAA=')))
      }
      else {
         return ($Data | ? {$_.name -eq $Value}).rax_dsc_config
      }
   }
}
Function _10010010011000001 {
   param (
      [string]$Value
   )
   if(_10100011101000001) {
      $Data = _10101010101101000 -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBtAC0AZABhAHQAYQAvAHAAcgBvAHYAaQBkAGUAcgBfAGQAYQB0AGEALwByAGUAZwBpAG8AbgA=')))
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIAByAGUAZwBpAG8AbgA=')))
      }
      return $Data
   }
   else {
      $Data = _10101100011100101
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIAByAGUAZwBpAG8AbgA=')))
      }
      return ($Data | ? { $_.name -eq $Value} ).region
   }
}
Function Get-rsPullServerName {
   if(_10100011101000001) {
      . "$($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAB1AGwAbABTAGUAcgB2AGUAcgBpAG4AZgBvAC4AcABzADEA'))) -join '\')"
      $Data = $pullServerInfo.pullServerName
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIABQAHUAbABsAFMAZQByAHYAZQByAE4AYQBtAGUA')))
      }
      return $Data
   }
   else {
      $Data = _10101100011100101
      if($Data -eq $null) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIAByAGUAdAByAGkAZQB2AGUAIAByAG8AbABlAA==')))
      }
      return ($Data | ? { $_.role -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGwAbAA=')))} ).name
   }
}
Function Get-rsFile {
   param ( 
      [string][ValidateNotNull()]$url, 
      [string][ValidateNotNull()]$path,
      [uint32]$retries = 2,
      [uint32]$timeOut = 10
   )
   $i = 0
   $webclient = New-Object System.Net.WebClient
   do {
      if($i -ge $retries) {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message "Failed to download file from $url retry threshold exceeded"
         return
      }
      try {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "Attempting to download $url."
         $webclient.DownloadFile($url,$path)
         if((Test-Path -Path $path) -eq $true) {
            $i = $retries
         }
      }
      catch {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "Failed to download $url sleeping for $timeOut seconds then trying again. `n $($_.Exception.Message)"
         $i++
         Start-Sleep -Seconds $timeOut
      }
   }
   while ($i -lt $retries)
   return
}
Function Get-rsAccessIPv4 {
   param (
      [uint32]$retries = 5,
      [uint32]$timeOut = 15
   )
   if(_10100011101000001) {
      $catalog = _00010011110101101
      $region = _10010010011000001 -Value $env:COMPUTERNAME
      $i = 0
      $uri = (($catalog.access.serviceCatalog | ? name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBsAG8AdQBkAFMAZQByAHYAZQByAHMATwBwAGUAbgBTAHQAYQBjAGsA')))).endpoints | ? region -eq $region).publicURL
      do {
         if($i -ge $retries) { 
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHQAcgB5ACAAdABoAHIAZQBzAGgAbwBsAGQAIAByAGUAYQBjAGgAZQBkACwAIABzAHQAbwBwAHAAaQBuAGcAIAByAGUAdAByAHkAIABsAG8AbwBwAC4A')))
            break 
         }
         try {
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "Retrieving Public address $accessIPv4"
            $Data = (((_00001101111110001 -Uri $($uri, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBlAHIAcwAvAGQAZQB0AGEAaQBsAA=='))) -join '/') -Retries $retries -TimeOut $timeOut -Method GET -Headers (_00001111000001011) -ContentType application/json).servers) | ? { $_.name -eq $env:COMPUTERNAME}).accessIPv4
            if($Data -ne $null) {
               return $Data
            }
         }
         catch {
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "Failed to retrieve Public address, sleeping for $timeOut seconds then trying again. `n $($_.Exception.Message)"
            $i++
            Start-Sleep -Seconds $timeOut
         }
      }
      while ($i -lt $retries)
      if($Data) {
         return $Data
      }
      else {
         Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "Failed to retrieve public ip address, sleeping for $timeOut seconds then trying again."
         return $Data
      }
   }
   else {
      if(Test-Path -Path $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAGQAaQBjAGEAdABlAGQALgBjAHMAdgA='))) -join '\')) {
         $Data = ((_10101100011100101) | ? { $_.name -eq $env:COMPUTERNAME} ).accessIPv4
      }
      return $Data
   }
   if($Data) {
      return $Data
   }
   else {
      Write-EventLog -LogName DevOps -Source rsCommon -EntryType Warning -EventId 1000 -Message "Failed to retrieve public ip address, sleeping for $timeOut seconds then trying again."
      return $Data
   }
}
Function _10000010001011110 {
   if(_10100011101000001) {
      $currentRegion = _10010010011000001 -Value $env:COMPUTERNAME
      if ((_01101001110101001 -value $env:COMPUTERNAME) -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGwAbAA=')))){
          $catalog = _00010011110101101
          if(($catalog.access.user.roles | ? name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBhAGMAawBfAGMAbwBuAG4AZQBjAHQA')))).id.count -gt 0) { $isRackConnect = $true } else { $isRackConnect = $false }
          if(($catalog.access.user.roles | ? name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBhAHgAXwBtAGEAbgBhAGcAZQBkAA==')))).id.count -gt 0) { $isManaged = $true } else { $isManaged = $false } 
          $defaultRegion = $catalog.access.user.'RAX-AUTH:defaultRegion'
      }
      else {
        $currentRegion = _10010010011000001 -Value $env:COMPUTERNAME
        $isRackConnect = $($pullServerInfo.isRackConnect)
        $isManaged = $($pullServerInfo.isManaged)
        $defaultRegion = $($pullServerInfo.defaultRegion)
      }
      return @{"currentRegion" = $currentRegion; "isRackConnect" = $isRackConnect; "isManaged" = $isManaged; "defaultRegion" = $defaultRegion}
   }
}
Function Test-rsRackConnect {
    if(_10100011101000001) {
        $Data = _10000010001011110
        if($Data.isRackConnect -and ($Data.currentRegion -eq $Data.defaultRegion)) {
        Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAGUAcgB2AGUAcgAgAGkAcwAgAFIAYQBjAGsAYwBvAG4AbgBlAGMAdAAgAGEAbgBkACAAaQBzACAAaQBuACAAdABoAGUAIABkAGUAZgBhAHUAbAB0ACAAcgBlAGcAaQBvAG4A')))
        $uri = $(($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcABzADoALwAvAA=='))), $Data.currentRegion -join ''), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBhAHAAaQAuAHIAYQBjAGsAYwBvAG4AbgBlAGMAdAAuAHIAYQBjAGsAcwBwAGEAYwBlAC4AYwBvAG0ALwB2ADEALwBhAHUAdABvAG0AYQB0AGkAbwBuAF8AcwB0AGEAdAB1AHMAPwBmAG8AcgBtAGEAdAA9AHQAZQB4AHQA'))) -join '')
        do {
            $rcStatus = _00001101111110001 -Uri $uri -Method GET -ContentType application/json
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "RackConnect status is: $rcStatus"
            Start-Sleep -Seconds 10
        }
        while(@($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABFAFAATABPAFkARQBEAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBBAEkATABFAEQA')))) -notcontains $rcStatus)
        Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "RackConnect status is: $rcStatus"
        }
    }
}
# Check if the cloud account is Managed and if so, confirm that server level automation (Servermill) has completed
#
Function Test-rsManaged 
{
    if(_10100011101000001) 
    {
        if ((_10000010001011110).isManaged) 
        {            
            $automationComlete = $false
            $Timeout = 1800 # Default timeout set to about 30 minutes
            do 
            {
                Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHMAdABpAG4AZwAgAGYAbwByACAAcgBhAHgAXwBzAGUAcgB2AGkAYwBlAF8AbABlAHYAZQBsAF8AYQB1AHQAbwBtAGEAdABpAG8AbgAuAA==')))
                if ((_10101010101101000 -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBtAC0AZABhAHQAYQAvAHUAcwBlAHIALQBtAGUAdABhAGQAYQB0AGEALwByAGEAeABfAHMAZQByAHYAaQBjAGUAXwBsAGUAdgBlAGwAXwBhAHUAdABvAG0AYQB0AGkAbwBuAA==')))) -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAA=='))))
                {
                    $automationComlete = $false
                    Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAcgBhAHgAXwBzAGUAcgB2AGkAYwBlAF8AbABlAHYAZQBsAF8AYQB1AHQAbwBtAGEAdABpAG8AbgAuAA==')))
                    Start-Sleep -Seconds 60
                    $Timeout = ($Timeout - 60)
                }
                else
                {
                    $automationComlete = $true
                    Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBhAHgAXwBzAGUAcgB2AGkAYwBlAF8AbABlAHYAZQBsAF8AYQB1AHQAbwBtAGEAdABpAG8AbgAgAGMAbwBtAHAAbABlAHQAZQAuAA==')))
                }
            } 
            while (($automationComlete -eq $false) -or ($Timeout -lt 0))
            if (($automationComlete -eq $false) -and ($Timeout -lt 0))
            {
                Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBhAHgAXwBzAGUAcgB2AGkAYwBlAF8AbABlAHYAZQBsAF8AYQB1AHQAbwBtAGEAdABpAG8AbgAgAHAAcgBvAGMAZQBzAHMAIAB0AGkAbQBlAGQAIABvAHUAdAAgAC0AIABzAG8AbQBlACAAbwByACAAYQBsAGwAIABSAGEAYwBrAHMAcABhAGMAZQAgAGMAbABvAHUAZAAgAGEAdQB0AG8AbQBhAHQAaQBvAG4AIABzAHQAZQBwAHMAIABkAGkAZAAgAG4AbwB0ACAAYwBvAG0AcABsAGUAdABlAC4A')))
            }
        }
        else
        {
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAGMAbwB1AG4AdAAgAGkAcwAgAG4AbwB0ACAAbQBhAG4AYQBnAGUAZAAsACAAcwBrAGkAcABwAGkAbgBnACAAdwBhAGkAdAAgAGYAbwByACAAcgBhAHgAXwBzAGUAcgB2AGkAYwBlAF8AbABlAHYAZQBsAF8AYQB1AHQAbwBtAGEAdABpAG8AbgA=')))
        }
    } 
}
Function Update-rsGitConfig {
   param (
      [string][ValidateSet('global', 'system')]$scope = 'system',
      [string]$attribute,
      [string]$value
   )
   try {
      start -Wait $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwAgACgAeAA4ADYAKQBcAEcAaQB0AFwAYgBpAG4AXABnAGkAdAAuAGUAeABlAA=='))) -ArgumentList "config $("--", $scope -join '') $attribute $value"
   }
   catch {
      Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message "Failed to update gitconfig file `n $($_.Exception.Message)"
   }
}
Function Get-rsCloudServersInfo
{
   $catalog = _00010011110101101
   $endpoints = ($catalog.access.serviceCatalog | ? name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBsAG8AdQBkAFMAZQByAHYAZQByAHMATwBwAGUAbgBTAHQAYQBjAGsA')))).endpoints.publicURL
   foreach( $endpoint in $endpoints )
   {
      $temp = (_00001101111110001 -Uri $($endpoint,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBlAHIAcwAvAGQAZQB0AGEAaQBsAA=='))) -join "/") -Method GET -Headers $(_00001111000001011) -ContentType application/json)
      $servers = $servers,$temp
   }
   return ( ($servers.servers | ? { @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAZAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGsAbgBvAHcAbgA=')))) -notcontains $_.status} ) )
} 
Function Unlock-Credentials
{
   param(
      [Parameter(Mandatory=$true)]
      [string]$DatabagName
   )
   . (_01001101001011100)
   $filePath = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, "$DatabagName.json" -join "\")
   If ( -not (Test-Path -Path $filePath))
   {
      return $null
   }
   $encryptedObjects = [System.IO.File]::ReadAllText($filePath) | ConvertFrom-Json
   $credHT = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBDAG8AbABsAGUAYwB0AGkAbwBuAHMALgBHAGUAbgBlAHIAaQBjAC4ARABpAGMAdABpAG8AbgBhAHIAeQBbAHMAdAByAGkAbgBnACwAcABzAGMAcgBlAGQAZQBuAHQAaQBhAGwAXQA=')))
   if($encryptedObjects -ne $null) {
      foreach ( $Name in ($encryptedObjects | Get-Member -MemberType Properties).Name )
      {
         $item = $encryptedObjects.$Name
         $decryptCert = Get-ChildItem Cert:\LocalMachine\My\ | Where-Object { $_.Thumbprint -eq [System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String($item.Thumbprint)) }
         If ( -not $decryptCert ) 
         { 
            Write-Host "Certificate with Thumbprint $Thumbprint could not be found. Skipping."
            Continue
         }
         try
         {
            $key = $decryptCert.PrivateKey.Decrypt([System.Convert]::FromBase64String($item.encrypted_key), $true)
            $secString = ConvertTo-SecureString -String $item.encrypted_data -Key $key
         }
         finally
         {
            if ($key) { [array]::Clear($key, 0, $key.Length) }
         }
         $credHT[$Name] = New-Object pscredential($Name, $secString)
      }
   }
   return $credHT
}
Function Test-rsHash
{
   param (
      [String] $file,
      [String] $hash
   )
   if ( !(Test-Path $hash) ){
      return $false
   }
   if( (Get-FileHash $file).hash -eq (Import-Csv $hash).hash){
      return $true
   }
   if( (Get-FileHash $file).hash -eq (Import-Csv $hash)){
      return $true
   }
   else {
      return $false
   }
}
Function Set-rsHash
{
   param (
      [String] $file,
      [String] $hash
   )
   Set-Content -Path $hash -Value (Get-FileHash -Path $file | ConvertTo-Csv)
}
Function Invoke-DSC
{
    do {
        Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "Installing DSC $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBzAFAAdQBsAGwAUwBlAHIAdgBlAHIALgBwAHMAMQA='))) -join '\')"
        taskkill /F /IM WmiPrvSE.exe
        try{
            $rstime = Measure-Command {Invoke-Expression $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwARABlAHYATwBwAHMA'))), $d.mR, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBzAFAAdQBsAGwAUwBlAHIAdgBlAHIALgBwAHMAMQA='))) -join '\')}
        }
        catch {
            Write-EventLog -LogName DevOps -Source rsCommon -EntryType Error -EventId 1002 -Message "Error in rsPullServer`n$($_.Exception.message)"
        }
    }
    while (!(Test-Path -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAVwBpAG4AZABvAHcAcwBcAFMAeQBzAHQAZQBtADMAMgBcAEMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4AXABDAHUAcgByAGUAbgB0AC4AbQBvAGYA')))))
    Write-EventLog -LogName DevOps -Source rsCommon -EntryType Information -EventId 1000 -Message "PullServer DSC installation completed in $($rstime.TotalSeconds) seconds" 
}