﻿Param(
    $computer = "localhost",
    $logPath = "C:\Windows\Temp",
    $sleepTime = 60,
    $appData = "D:\Projects\GitHub\battery-warrior\apps.data"
)
ipmo PSLogging
Start-Log -LogPath $logPath -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBhAHQAdABlAHIAeQAtAHcAYQByAHIAaQBvAHIALgBsAG8AZwA='))) -ScriptVersion $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAuADAA'))) | out-null
${_/\/==\/===\/\__/} = $logPath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBiAGEAdAB0AGUAcgB5AC0AdwBhAHIAcgBpAG8AcgAuAGwAbwBnAA=='))) 
Function _____/====\__/\__/
{
Param(
[string]$computer
)
${__/\____/\/\/\_/\} = (gwmi -Class BatteryStatus -Namespace root\wmi -ComputerName $computer)
[BOOL]${__/\____/\/\/\_/\}.PowerOnLine -or -not ${__/\____/\/\/\_/\}.PowerOnLine -and -not ${__/\____/\/\/\_/\}.Discharging
} 
Function ___/\_/\/=\__/\/\_
{
Param(
   [string]$filePath = $appData,
   [string]$mode = "1"
)
${_/\/\/\__/\__/\_/} = [System.IO.File]::OpenText($filePath)
try {
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAdABvACAAbQBhAG4AYQBnAGkAbgBnACAAdABoAGUAIABhAHAAcABsAGkAYwBhAHQAaQBvAG4AcwA='))) -TimeStamp
    for(;;) {
        ${_/\/==\_/\/=\_/\/} = ${_/\/\/\__/\__/\_/}.ReadLine()
        if (${_/\/==\_/\/=\_/\/} -eq $null) { break }
            Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Managing the application:  ${_/\/==\_/\/=\_/\/}" -TimeStamp
        if ($mode -eq "1"){
            ${_/=\/\/\_____/==\} = resolve-path ${_/\/==\_/\/=\_/\/}
            ${_/\/=\/==\_/\/===} = ps | ? {$_.Path -like ${_/=\/\/\_____/==\}}
            if(${_/\/=\/==\_/\/===}.Path -eq $null){
                Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Started process ${_/=\/\/\_____/==\}" -TimeStamp
                saps ${_/\/==\_/\/=\_/\/}
                Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGUAZAAgAHAAcgBvAGMAZQBzAHMA'))) -TimeStamp                 
            }
            else{
                Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Process ${_/=\/\/\_____/==\} is already running" -TimeStamp  
            }
        }
        else{
            ps | ? {$_.Path -like ${_/\/==\_/\/=\_/\/}} | kill
            Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAAgAHAAcgBvAGMAZQBzAHMA'))) -TimeStamp
        }
    }
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAG4AYQBnAGkAbgBnACAAdABoAGUAIABhAHAAcABsAGkAYwBhAHQAaQBvAG4AcwAgAGYAaQBuAGkAcwBoAGUAZAA='))) -TimeStamp
}
finally {
    ${_/\/\/\__/\__/\_/}.Close()
}
}
Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAdABoAGUAIABlAHgAZQBjAHUAdABpAG8AbgAgAG8AZgAgAHQAaABlACAAQgBhAHQAdABlAHIAeQBXAGEAcgByAGkAbwByAC4A'))) -TimeStamp
${/=\_/==========\/} = $true
${/==\/=\_/\_/==\_/} = "-1"
while (${/=\_/==========\/} -eq $true){    
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGkAbgBnACAAZgBvAHIAIABhACAAYwBoAGEAbgBnAGUAIABvAGYAIABzAHQAYQB0AGUAIABvAGYAIAB0AGgAZQAgAGwAYQBwAHQAbwBwAA==')))  -TimeStamp   
    ${/=\__/==\_/=\___/} = (_____/====\__/\__/ -computer $computer)
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "The laptop is currently under AC power: ${/=\__/==\_/=\___/}" -TimeStamp
    if(${/=\__/==\_/=\___/} -eq $true){
        Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Analyzing the ${/==\/=\_/\_/==\_/} and comparing to the laptop status" -TimeStamp
        if(-not (${/==\/=\_/\_/==\_/} -eq "1")) {
            Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABhAHUAbgBjAGgAaQBuAGcAIABIAGkAZwBoACAAUABvAHcAZQByACAAQwBvAG4AcwB1AG0AaQBuAGcAIABBAHAAcABzAA=='))) -TimeStamp
            ___/\_/\/=\__/\/\_ -mode "1" -filePath $appData
            ${/==\/=\_/\_/==\_/} = "1"
        }
    }else{
        Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "2 Analyzing the ${/==\/=\_/\_/==\_/} and comparing to the laptop status" -TimeStamp
        if(-not (${/==\/=\_/\_/==\_/} -eq "0")) {
            Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SwBpAGwAbABpAG4AZwAgAEgAaQBnAGgAIABQAG8AdwBlAHIAIABDAG8AbgBzAHUAbQBpAG4AZwAgAEEAcABwAHMA'))) -TimeStamp
            ___/\_/\/=\__/\/\_ -mode "0" -filePath $appData
            ${/==\/=\_/\_/==\_/} = "0"
        }
    }
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Current Mode: ${/==\/=\_/\_/==\_/}" -TimeStamp
    Write-LogInfo -LogPath ${_/\/==\/===\/\__/} -Message  "Sleeping for $leepTime seconds" -TimeStamp
    sleep $sleepTime    
}
Start-Log -LogPath ${_/\/==\/===\/\__/}
