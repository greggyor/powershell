﻿
Function Set-AlternatingRows {
    [CmdletBinding ()]
       Param(
            [Parameter(Mandatory ,ValueFromPipeline)][string] $Line,
            [Parameter(Mandatory)][string] $CSSEvenClass,
            [Parameter(Mandatory)][string] $CSSOddClass
       )
        Begin 
        {
               $ClassName = $CSSEvenClass
        }
        Process 
        {
            If ($Line.Contains($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAB0AHIAPgA8AHQAZAA+AA==')))))
            {       
                $Line = $Line.Replace($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAB0AHIAPgA='))), "<tr class=""$ClassName"">" )
                If ($CSSAlertClass -ne $null)
                { 
                    $ClassName = $CSSAlertClass
                }
                ElseIf ($ClassName -eq $CSSEvenClass)
                {       
                    $ClassName = $CSSOddClass
                }
                Else
                {       
                    $ClassName = $CSSEvenClass
                };
            };
            Return $Line;
        }
}
Function f1 {
	Param 
	(
		[Parameter(Mandatory=$true,Position=0)]$MailFromAddress,
		[Parameter(Mandatory=$true,Position=1)]$MailAddress,
		[Parameter(Mandatory=$true,Position=3)]$MailSubject,
		[Parameter(Mandatory=$true,Position=4)]$MailBody,
		[Parameter(Mandatory=$false,Position=5)]$MailAttachment
	)
	$SMTPServer = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBtAHQAcAByAGUAbABhAHkA'))) 
    $MailFromAddress = "$env:COMPUTERNAME@email.com"
	Write-Host -ForegroundColor Green " - Sending Email with Log file to $MailAddress ...$EmailSubject"
	Try
	{
		If ($MailAttachment -ne $null)
		{
			$SendLogs = Send-MailMessage -To $MailAddress -From $MailFromAddress -Subject $MailSubject -Body $MailBody -BodyAsHtml -SmtpServer $SMTPServer -Attachments $MailAttachment -ea stop
		}
		else
		{
			$SendLogs = Send-MailMessage -To $MailAddress -From $MailFromAddress -Subject $MailSubject -Body $MailBody -BodyAsHtml -SmtpServer $SMTPServer -ea stop
		}
	}
	Catch 
	{
		Write-Host -ForegroundColor Yellow "   * Exception Message: $($_.Exception.Message)"
	}
}
Function f2([String]$SQLServer, [String]$TSQL, [String]$ReportHeading){
	[String]$HTML = ""
	$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
	$SqlConnection.ConnectionString = "server=$SQLServer ; database=msdb; Integrated Security=true"
	try{
		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
		$SqlCmd.Connection =  
		$SqlCmd.CommandTimeout = 0
		$SqlCmd.Connection.Open()
		$SqlCmd.CommandText = $TSQL
		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
		$SqlAdapter.SelectCommand = $SqlCmd
		$DataSet = New-Object System.Data.DataSet
		$SqlAdapter.Fill($DataSet)
        if($DataSet.Tables[0].Rows.Count -ne 0 )
		{
            $HTML = "  <H2>$ReportHeading</H2><table>"
            foreach ($Table in $DataSet.Tables)
            { 
                $HTML += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAB0AHIAPgA=')))
                foreach ($field in $Table.Columns)
                {
                    if ($field.ToString().ToLower() -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGUAcgB0AA==')))) 
                    {
                        $HTML += "<th>$field</th>"
                    }
                }
                $HTML += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAHQAcgA+AA==')))
                [string]$ClassName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB2AGUAbgA=')))
                foreach ($Row in $Table.Rows)
                {
                    If ($ClassName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB2AGUAbgA=')))) {$ClassName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwBkAGQA')))} Else {$ClassName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB2AGUAbgA=')))}
                    $TD = ""
                    foreach ($field in $Table.Columns)
                    {
                        if (($field.ToString().ToLower() -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGUAcgB0AA==')))) -and ($row[$field].ToString().ToLower() -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGUAcgB0AA==')))))
                        {
                            $ClassName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGUAcgB0AA==')))
                        }
                        if ($field.ToString().ToLower() -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGUAcgB0AA==')))) 
                        {
                            $TD += "<td>$($Row[$field].Tostring())</td>"
                        }
                    }
                    $HTML += "<tr class=""$ClassName""> $TD</tr>";
                }
            } 
			$HTML += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAvAHQAYQBiAGwAZQA+AA==')))
		}
		return $HTML
	} catch [system.exception]{
		$sqlEx = "<b><font color=red>Caught exception, possibly can't connect to $svr. </font></b>"
		Write-Host "$svr - $sqlEx"
		Write-Host $_
		return $sqlEx
	} finally {
		$SqlConnection.Close()
	}
}
Function f4 {
	param ([string]$ComputerName)
	$Uptime = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $ComputerName
	$LastBootUpTime = $Uptime.ConvertToDateTime($Uptime.LastBootUpTime)
	$Time = (Get-Date) - $LastBootUpTime
	Return $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAMAAwAH0AIABEAGEAeQBzACwAIAB7ADEAOgAwADAAfQAgAEgAbwB1AHIAcwAsACAAewAyADoAMAAwAH0AIABNAGkAbgB1AHQAZQBzACwAIAB7ADMAOgAwADAAfQAgAFMAZQBjAG8AbgBkAHMA'))) -f $Time.Days, $Time.Hours, $Time.Minutes, $Time.Seconds
}
function f6 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,ValueFromPipeline=$True)]
        [string[]]$Server, 
        [Parameter(Mandatory=$True,ValueFromPipeline=$True)]
        [decimal]$DiskThreshold = 100
    )
    BEGIN {}
    PROCESS {
		$disks =Get-WMIObject -ComputerName $Server Win32_LogicalDisk | Where-Object {$_.DriveType -eq 3}
		foreach ($disk in $disks ) {
		   if ($disks.count -ge 1) {           
			   $Used= $disk.freespace / $disk.size * 100
			   $result =  @{'Server'=$computer.server;
						  'Server Description'=$computer.description;
						  'Volume'=$disk.VolumeName;
						  'Drive'=$disk.name;
						  'Size (gb)'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($disk.size / 1gb);
						  'Used (gb)'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f (($disk.size - $disk.freespace) / 1gb);
						  'Free (gb)'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($disk.freespace / 1gb);
						  '% free'=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($disk.freespace / $disk.size * 100)}                         
			   $obj = New-Object -TypeName PSObject -Property $result
					Write-Output $obj 
		   }
		}
    }
    END {}
} 
function f5([String]$Server){
    $fragments=@()
    [decimal]$thresholdspace = 10
    [string]$g=[char]9619 
    $Disks = f6 `
                -ErrorAction SilentlyContinue `
                -Server ($Server) `
                -DiskThreshold $thresholdspace
    $html= $Disks|select @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAByAGkAdgBlAA==')));expression={$_.Drive}},
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUA')));expression={$_.Volume}},
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHoAZQAgACgAZwBiACkA'))) ;expression={($_."size (gb)")}},
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAZAAgACgAZwBiACkA')));expression={$_."used (gb)"}},
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAGUAZQAgACgAZwBiACkA')));expression ={$_."free (gb)"}},
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQAgAGYAcgBlAGUA')));expression ={$_."% free"}},           
                  @{name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAawAgAHUAcwBhAGcAZQA=')));expression={
                        $UsedPer = (($_."Size (gb)" - $_."Free (gb)") / $_."Size (gb)") * 100
                        $UsedGraph = $g * ($UsedPer / 4)
                        $FreeGraph = $g * ((100 - $UsedPer) / 4)
                         $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eABvAHAAZQBuAEYAbwBuAHQAIABjAG8AbABvAHIAPQBSAGUAZAB4AGMAbABvAHMAZQB7ADAAfQB4AG8AcABlAG4ALwBGAG8AbgB0AHgAYwBsAG8AcwBlAHgAbwBwAGUAbgBGAG8AbgB0ACAAQwBvAGwAbwByAD0ARwByAGUAZQBuAHgAYwBsAG8AcwBlAHsAMQB9AHgAbwBwAGUAbgAvAGYAbwBuAHQAeABjAGwAbwBzAGUA'))) -f $usedGraph, $FreeGraph }}`
        | sort-Object {[string]$_."Drive"} `
        | ConvertTo-HTML -fragment
	$html=$html -replace $g, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgAjADkANgAwADgAOwA=')))
    $html=$html -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eABvAHAAZQBuAA=='))),"<"
    $html=$html -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eABjAGwAbwBzAGUA'))),">"
    $Fragments+=$html         
    return $Fragments
}
Function f3 {
	Param 
	(
		[Parameter(Mandatory=$true,Position=0)]$computer
	)
    $thresholdspace = 100
    [int]$EventNum = 3
    $ListOfAttachments = @()
    $Report = @()
    $CurrentTime = Get-Date
    $DiskInfo = f5 -Server $computer
	$OS = (Get-WmiObject Win32_OperatingSystem -computername $computer).caption
	$SystemInfo = Get-WmiObject -Class Win32_OperatingSystem -computername $computer | Select-Object Name, TotalVisibleMemorySize, FreePhysicalMemory
	$TotalRAM = $SystemInfo.TotalVisibleMemorySize/1MB
	$FreeRAM = $SystemInfo.FreePhysicalMemory/1MB
	$UsedRAM = $TotalRAM - $FreeRAM
	$RAMPercentFree = ($FreeRAM / $TotalRAM) * 100
	$TotalRAM = [Math]::Round($TotalRAM, 2)
	$FreeRAM = [Math]::Round($FreeRAM, 2)
	$UsedRAM = [Math]::Round($UsedRAM, 2)
	$RAMPercentFree = [Math]::Round($RAMPercentFree, 2)
	$SystemUptime = f4 -ComputerName $computer
    [String]$CurrentSystemHTML = @"
	    <table class="list" border=1>
            <tr><th colspan=2>System Info: $computer </th></tr>
            <tr>
	            <td>System Uptime</td>
	            <td>$SystemUptime</td>
	        </tr>
	        <tr>
	            <td>OS</td>
	            <td>$OS</td>
	        </tr>
	        <tr>
	            <td>Total RAM (GB)</td>
	            <td>$TotalRAM</td>
	        </tr>
	        <tr>
	            <td>Free RAM (GB)</td>
	            <td>$FreeRAM</td>
	        </tr>
	        <tr>
	            <td>Percent free RAM</td>
	            <td>$RAMPercentFree</td>
	        </tr>
	    </table>


	    <font size=3><b>Disk Info</b></font>
        $DiskInfo
"@
	If ($ServicesReport -ne $null){
		$CurrentSystemHTML += @"    
			<font size=3><b>System Services - Automatic Startup but not Running</b></font><br>
			<i>The following services are those which are set to Automatic startup type, yet are currently not running on $computer</i>
			$ServicesReport
"@
	}
	If ($SystemEventsReport -ne $null){
		$CurrentSystemHTML += @" 
			<font size=3><b>Events Report - The last $EventNum System/Application Log Events that were Warnings or Errors</b></font><br>
			<i>The following is a list of the last $EventNum <b>System log</b> events that had an Event Type of either Warning or Error on $computer</i>
			$SystemEventsReport
"@
	}
	If ($ApplicationEventsReport -ne $null){
	$CurrentSystemHTML += 
@" 
			<i>The following is a list of the last $EventNum <b>Application log</b> events that had an Event Type of either Warning or Error on $computer</i><br>
			$ApplicationEventsReport
"@
	}
    return $CurrentSystemHTML
}
try{
[string]$Results = "";
[string]$Heading = "";
[string]$sql = "";
[string]$MailHeader = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABzAHQAeQBsAGUAIAB0AHkAcABlAD0AIgB0AGUAeAB0AC8AYwBzAHMAIgA+AA0ACgAJAGIAbwBkAHkAIAB7AGYAbwBuAHQALQBmAGEAbQBpAGwAeQA6ACAAQQByAGkAYQBsACwAIABIAGUAbAB2AGUAdABpAGMAYQAsACAAcwBhAG4AcwAtAHMAZQByAGkAZgA7AH0ADQAKAAkAVABBAEIATABFACAAewBiAG8AcgBkAGUAcgAtAHcAaQBkAHQAaAA6ACAAMABwAHgAOwAgAGIAbwByAGQAZQByAC0AcwB0AHkAbABlADoAIABzAG8AbABpAGQAOwAgAGIAbwByAGQAZQByAC0AYwBvAGwAbwByADoAIABiAGwAYQBjAGsAOwAgAGIAbwByAGQAZQByAC0AYwBvAGwAbABhAHAAcwBlADoAIABjAG8AbABsAGEAcABzAGUAOwB9AA0ACgAJAFQASAAgAHsAYgBvAHIAZABlAHIALQB3AGkAZAB0AGgAOgAgADEAcAB4ADsAIABiAG8AcgBkAGUAcgAtAHMAdAB5AGwAZQA6ACAAcwBvAGwAaQBkADsAIABiAG8AcgBkAGUAcgAtAGMAbwBsAG8AcgA6ACAAIwAwADAAMAAwADAAMAA7ACAAYgBhAGMAawBnAHIAbwB1AG4AZAAtAGMAbwBsAG8AcgA6ACAAIwA3ADcAOAA4ADkAOQA7ACAAYwBvAGwAbwByADoAIAAjAEYARgBGAEYARgBGADsAIAB0AGUAeAB0AC0AYQBsAGkAZwBuADoAbABlAGYAdAA7AH0ADQAKAAkAVABEACAAewBmAG8AbgB0AC0AcwBpAHoAZQA6ADEAMgBwAHgAOwAgAGIAbwByAGQAZQByAC0AdwBpAGQAdABoADoAIAAxAHAAeAA7ACAAcABhAGQAZABpAG4AZwA6ACAAOABwAHgAOwBiAG8AcgBkAGUAcgAtAHMAdAB5AGwAZQA6ACAAcwBvAGwAaQBkADsAIABiAG8AcgBkAGUAcgAtAGMAbwBsAG8AcgA6ACAAYgBsAGEAYwBrADsAfQANAAoACQAuAG8AZABkACAAIAB7ACAAYgBhAGMAawBnAHIAbwB1AG4AZAAtAGMAbwBsAG8AcgA6ACMARgAwAEYAMABGADAAOwAgAH0ADQAKAAkALgBlAHYAZQBuACAAewAgAGIAYQBjAGsAZwByAG8AdQBuAGQALQBjAG8AbABvAHIAOgAjAGQAZABkAGQAZABkADsAIAB9AA0ACgAJAC4AYQBsAGUAcgB0ACAAewAgAGIAYQBjAGsAZwByAG8AdQBuAGQALQBjAG8AbABvAHIAOgAjAEYARgBDAEMAQwBDADsAIAB9AA0ACgAJAGgAMgB7ACAAYwBsAGUAYQByADoAIABiAG8AdABoADsAIABmAG8AbgB0AC0AcwBpAHoAZQA6ACAAMQAxADAAJQA7ACAAfQANAAoAPAAvAHMAdAB5AGwAZQA+AA==')));
[string]$MissingBackups = $null;
[String]$FailedAgentJobResults = $null;
[string]$SQLErrorsResults = $null;
[string]$emailTo = "${MailReportsTo}";
[xml]$XmlDocument = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAA/AHgAbQBsACAAdgBlAHIAcwBpAG8AbgA9ACIAMQAuADAAIgAgAGUAbgBjAG8AZABpAG4AZwA9ACIAdQB0AGYALQA4ACIAPwA+AA0ACgA8AEMAaABlAGMAawBzAD4ADQAKAAkAPABTAGUAcgB2AGUAcgAgAE4AYQBtAGUAPQAiAFAAUgBEADMAMAAwADIAUwBVAFAAUwBRAEwAIgA+AA0ACgAJAAkAPABDAGgAZQBjAGsAUwBRAEwARQByAHIAbwByAHMAPgB0AHIAdQBlADwALwBDAGgAZQBjAGsAUwBRAEwARQByAHIAbwByAHMAPgANAAoACQAJADwAQwBoAGUAYwBrAEEAZwBlAG4AdABKAG8AYgA+AGYAYQBsAHMAZQA8AC8AQwBoAGUAYwBrAEEAZwBlAG4AdABKAG8AYgA+AA0ACgAJAAkAPABDAGgAZQBjAGsATQBpAHMAcwBpAG4AZwBCAGEAYwBrAHUAcABzAD4AZgBhAGwAcwBlADwALwBDAGgAZQBjAGsATQBpAHMAcwBpAG4AZwBCAGEAYwBrAHUAcABzAD4ADQAKAAkAPAAvAFMAZQByAHYAZQByAD4ADQAKACAAPAAvAEMAaABlAGMAawBzAD4A')));
}
Catch 
{
	Write-Host -ForegroundColor Yellow "   * Exception Message: $($_.Exception.Message)"
    Exit
}
foreach($ServerName in $XmlDocument.Checks.Server){
	[string]$svr = $ServerName.Name
    [String]$SystemInfo = f3 $svr
    [String]$Heading = "SQL Server Errors for: $svr"
	If ($ServerName.CheckSQLErrors -eq $true)
	{
		[string]$sql = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAARABFAEMATABBAFIARQAgAEAAVABpAG0AZQBfAFMAdABhAHIAdAAgAEQAQQBUAEUAVABJAE0ARQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABEAEUAQwBMAEEAUgBFACAAQABUAGkAbQBlAF8ARQBuAGQAIABEAEEAVABFAFQASQBNAEUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAUwBFAFQAIABAAFQAaQBtAGUAXwBTAHQAYQByAHQAIAA9ACAARwBFAFQARABBAFQARQAoACkAIAAtACAAMgA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABTAEUAVAAgAEAAVABpAG0AZQBfAEUAbgBkACAAPQAgAEcARQBUAEQAQQBUAEUAKAApADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABEAEUAQwBMAEEAUgBFACAAQABFAHIAcgBvAHIATABvAGcAIABUAEEAQgBMAEUADQAKAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAKABsAG8AZwBkAGEAdABlACAARABBAFQARQBUAEkATQBFAA0ACgAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgACwAcAByAG8AYwBlAHMAcwBpAG4AZgBvACAAVgBBAFIAQwBIAEEAUgAoADIANQA1ACkADQAKAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAALABNAGUAcwBzAGEAZwBlACAAVgBBAFIAQwBIAEEAUgAoADUAMAAwACkAKQA7AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAASQBOAFMARQBSAFQAIABAAEUAcgByAG8AcgBMAG8AZwAgACgAbABvAGcAZABhAHQAZQAsAHAAcgBvAGMAZQBzAHMAaQBuAGYAbwAsAE0AZQBzAHMAYQBnAGUAKQANAAoACQAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEUAWABFAEMAIABtAGEAcwB0AGUAcgAuAGQAYgBvAC4AeABwAF8AcgBlAGEAZABlAHIAcgBvAHIAbABvAGcAIAAwACwAIAAxACwAIABOAFUATABMACwAIABOAFUATABMACwAIABAAFQAaQBtAGUAXwBTAHQAYQByAHQALAAgAEAAVABpAG0AZQBfAEUAbgBkACwAIABOACcAZABlAHMAYwAnADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABTAEUATABFAEMAVAAgAGwAbwBnAGQAYQB0AGUADQAKAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAALABNAGUAcwBzAGEAZwBlAA0ACgAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACwAQwBBAFMARQAgAFcASABFAE4AIABNAGUAcwBzAGEAZwBlACAATABJAEsARQAgACcAJQB3AGkAdABoAG8AdQB0ACAAZQByAHIAbwByAHMAJQAnACAAVABIAEUATgAgACcAbgBvAHIAbQBhAGwAJwANAAoACQAJAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABFAEwAUwBFACAAJwBhAGwAZQByAHQAJwANAAoACQAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEUATgBEACAAQQBTACAAQQBsAGUAcgB0AA0ACgAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEYAUgBPAE0ADQAKAAkACQAgACAAIAAgACAAIAAgACAAIAAgACAAIABAAEUAcgByAG8AcgBMAG8AZwANAAoACQAgACAAIAAgACAAIAAgACAAIAAgACAAIABXAEgARQBSAEUADQAKAAkACQAgACAAIAAgACAAIAAgACAAIAAgACAAIAAoAA0ACgAJAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAoAA0ACgAJAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAE0AZQBzAHMAYQBnAGUAIABMAEkASwBFACAAJwAlAGUAcgByAG8AcgAlACcAIABBAE4ARAAgACgATQBlAHMAcwBhAGcAZQAgAE4ATwBUACAATABJAEsARQAgACcAJQBmAG8AdQBuAGQAIAAwACAAZQByAHIAbwByAHMAJQAnACAAYQBuAGQAIABNAGUAcwBzAGEAZwBlACAATgBPAFQAIABMAEkASwBFACAAJwAlAHcAaQB0AGgAbwB1AHQAIABlAHIAcgBvAHIAcwAlACcAKQANAAoACQAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAKQAgAE8AUgANAAoACQAJACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAATQBlAHMAcwBhAGcAZQAgAEwASQBLAEUAIAAnACUAZgBhAGkAbABlAGQAJQAnAA0ACgAJAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAKQAgAEEATgBEAA0ACgAJAAkAIAAgACAAIAAgACAAIAAgACAAIAAgACAAcAByAG8AYwBlAHMAcwBpAG4AZgBvACAATgBPAFQAIABMAEkASwBFACAAJwBsAG8AZwBvAG4AJwANAAoACQAgACAAIAAgACAAIAAgACAAIAAgACAAIABPAFIARABFAFIAIABCAFkADQAKAAkACQAgACAAIAAgACAAIAAgACAAIAAgACAAIABsAG8AZwBkAGEAdABlACAARABFAFMAQwA7AA==')));
		[string]$SQLErrorsResults = f2 -SQLServer $svr -TSQL $sql -ReportHeading $Heading
    }
    [String]$Heading = "Agent Job - Failed to complete for: $svr"
	If ($ServerName.CheckAgentJob -eq $true)
	{
		[string]$sql = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJACAAIAAgACAAUwBFAEwARQBDAFQADQAKAAkACQAJACAAIAAgACAASgBvAGIAUwB0AGEAdAB1AHMAIAA9ACAAJwBGAEEASQBMAEUARAAnAA0ACgAJAAkAIAAgACAAIAAgACAAIAAsAEoAbwBiAE4AYQBtAGUAIAA9ACAAQwBBAFMAVAAoAHMAagAuAG4AYQBtAGUAIABBAFMAIABWAEEAUgBDAEgAQQBSACgAMQAwADAAKQApAA0ACgAJAAkAIAAgACAAIAAgACAAIAAsAFMAdABlAHAASQBEACAAPQAgAEMAQQBTAFQAKABzAGoAcwAuAHMAdABlAHAAXwBpAGQAIABBAFMAIABWAEEAUgBDAEgAQQBSACgANQApACkADQAKAAkACQAgACAAIAAgACAAIAAgACwAUwB0AGUAcABOAGEAbQBlACAAPQAgAEMAQQBTAFQAKABzAGoAcwAuAHMAdABlAHAAXwBuAGEAbQBlACAAQQBTACAAVgBBAFIAQwBIAEEAUgAoADMAMAApACkADQAKAAkACQAgACAAIAAgACAAIAAgACwAUwB0AGEAcgB0AEQAYQB0AGUAVABJAE0ARQAgAD0AIABDAEEAUwBUACgAUgBFAFAATABBAEMARQAoAEMATwBOAFYARQBSAFQAKABWAEEAUgBDAEgAQQBSACwAIABDAE8ATgBWAEUAUgBUACgARABBAFQARQBUAEkATQBFACwAIABDAE8ATgBWAEUAUgBUACgAVgBBAFIAQwBIAEEAUgAsACAAcwBqAGgALgByAHUAbgBfAGQAYQB0AGUAKQApACwAIAAxADAAMgApACwAIAAnAC4AJwAsACAAJwAtACcAKQAgACsAIAAnACAAJwAgACsADQAKAAkACQAJACAAIAAgACAAUwBVAEIAUwBUAFIASQBOAEcAKABSAEkARwBIAFQAKAAnADAAMAAwADAAMAAwACcAIAArACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAAgADYAKQAsACAAMQAsACAAMgApACAAKwAgACcAOgAnACAAKwAgAFMAVQBCAFMAVABSAEkATgBHACgAUgBJAEcASABUACgAJwAwADAAMAAwADAAMAAnACAAKwANAAoACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJACAAIAAgACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAA2ACkALAAgADMALAAgADIAKQAgACsAIAAnADoAJwAgACsADQAKAAkACQAJACAAIAAgACAAUwBVAEIAUwBUAFIASQBOAEcAKABSAEkARwBIAFQAKAAnADAAMAAwADAAMAAwACcAIAArACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAAgADYAKQAsACAANQAsACAAMgApACAAQQBTACAAVgBBAFIAQwBIAEEAUgAoADMAMAApACkADQAKAAkACQAgACAAIAAgACAAIAAgACwAWwBNAGUAcwBzAGEAZwBlAF0AIAA9ACAAcwBqAGgALgBtAGUAcwBzAGEAZwBlAA0ACgAJAAkACQAgACAAIAAgACwAQQBsAGUAcgB0ACAAPQAgACcAYQBsAGUAcgB0ACcADQAKAA0ACgAJAAkAIAAgACAAIABGAFIATwBNAA0ACgAJAAkACQAgACAAIAAgAG0AcwBkAGIALgBkAGIAbwAuAHMAeQBzAGoAbwBiAHMAIABzAGoADQAKAAkACQAJACAAIAAgACAASgBPAEkATgAgAG0AcwBkAGIALgBkAGIAbwAuAHMAeQBzAGoAbwBiAHMAdABlAHAAcwAgAHMAagBzAA0ACgAJAAkACQAJACAAIAAgACAATwBOACAAcwBqAC4AagBvAGIAXwBpAGQAIAA9ACAAcwBqAHMALgBqAG8AYgBfAGkAZAANAAoACQAJAAkAIAAgACAAIABKAE8ASQBOACAAbQBzAGQAYgAuAGQAYgBvAC4AcwB5AHMAagBvAGIAaABpAHMAdABvAHIAeQAgAHMAagBoAA0ACgAJAAkACQAJACAAIAAgACAATwBOACAAcwBqAC4AagBvAGIAXwBpAGQAIAA9ACAAcwBqAGgALgBqAG8AYgBfAGkAZAAgAEEATgBEAA0ACgAJAAkACQAJACAAIAAgACAAIAAgACAAcwBqAHMALgBzAHQAZQBwAF8AaQBkACAAPQAgAHMAagBoAC4AcwB0AGUAcABfAGkAZAANAAoACQAJACAAIAAgACAAVwBIAEUAUgBFAA0ACgAJAAkACQAgACAAIAAgAHMAagBoAC4AcgB1AG4AXwBzAHQAYQB0AHUAcwAgAEkATgAgACgAMAAsACAAMwApACAAQQBOAEQADQAKAAkACQAJACAAIAAgACAAQwBBAFMAVAAoAHMAagBoAC4AcgB1AG4AXwBkAGEAdABlACAAQQBTACAARgBMAE8AQQBUACkAIAAqACAAMQAwADAAMAAwADAAMAAgACsAIABzAGoAaAAuAHIAdQBuAF8AdABpAG0AZQAgAD4AIABDAEEAUwBUACgAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIAKAA4ACkALAAgAEcARQBUAEQAQQBUAEUAKAApACAALQAgADEALAAgADEAMQAyACkAIABBAFMAIABGAEwATwBBAFQAKQAgACoADQAKAAkACQAJACAAIAAgACAAMQAwADAAMAAwADAAMAAgACsAIAA3ADAAMAAwADAAIAAtAC0AeQBlAHMAdABlAHIAZABhAHkAIABhAHQAIAA3AGEAbQANAAoACQAgACAAIAAgAFUATgBJAE8ATgANAAoACQAgACAAIAAgAFMARQBMAEUAQwBUAA0ACgAJAAkACQAgACAAIAAgAEoAbwBiAFMAdABhAHQAdQBzACAAPQAgACcARgBBAEkATABFAEQAJwANAAoACQAJACAAIAAgACAAIAAgACAALABKAG8AYgBOAGEAbQBlACAAPQAgAEMAQQBTAFQAKABzAGoALgBuAGEAbQBlACAAQQBTACAAVgBBAFIAQwBIAEEAUgAoADEAMAAwACkAKQANAAoACQAJACAAIAAgACAAIAAgACAALABTAHQAZQBwAEkARAAgAD0AIAAnAE0AQQBJAE4AJwAgACAADQAKAAkACQAgACAAIAAgACAAIAAgACwAUwB0AGUAcABOAGEAbQBlACAAPQAgACcATQBBAEkATgAnACAADQAKAAkACQAgACAAIAAgACAAIAAgACwAUwB0AGEAcgB0AEQAYQB0AGUAVABJAE0ARQAgAD0AIABDAEEAUwBUACgAUgBFAFAATABBAEMARQAoAEMATwBOAFYARQBSAFQAKABWAEEAUgBDAEgAQQBSACwAIABDAE8ATgBWAEUAUgBUACgARABBAFQARQBUAEkATQBFACwAIABDAE8ATgBWAEUAUgBUACgAVgBBAFIAQwBIAEEAUgAsACAAcwBqAGgALgByAHUAbgBfAGQAYQB0AGUAKQApACwAIAAxADAAMgApACwAIAAnAC4AJwAsACAAJwAtACcAKQAgACsAIAAnACAAJwAgACsADQAKAAkACQAJACAAIAAgACAAUwBVAEIAUwBUAFIASQBOAEcAKABSAEkARwBIAFQAKAAnADAAMAAwADAAMAAwACcAIAArACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAAgADYAKQAsACAAMQAsACAAMgApACAAKwAgACcAOgAnACAAKwAgAFMAVQBCAFMAVABSAEkATgBHACgAUgBJAEcASABUACgAJwAwADAAMAAwADAAMAAnACAAKwANAAoACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJACAAIAAgACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAA2ACkALAAgADMALAAgADIAKQAgACsAIAAnADoAJwAgACsADQAKAAkACQAJACAAIAAgACAAUwBVAEIAUwBUAFIASQBOAEcAKABSAEkARwBIAFQAKAAnADAAMAAwADAAMAAwACcAIAArACAAQwBPAE4AVgBFAFIAVAAoAFYAQQBSAEMASABBAFIALAAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACkALAAgADYAKQAsACAANQAsACAAMgApACAAQQBTACAAVgBBAFIAQwBIAEEAUgAoADMAMAApACkADQAKAAkACQAgACAAIAAgACAAIAAgACwAWwBNAGUAcwBzAGEAZwBlAF0AIAA9ACAAcwBqAGgALgBtAGUAcwBzAGEAZwBlAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACwAQQBsAGUAcgB0ACAAPQAgACcAYQBsAGUAcgB0ACcADQAKAAkACQAgACAAIAAgAEYAUgBPAE0ADQAKAAkACQAJACAAIAAgACAAbQBzAGQAYgAuAGQAYgBvAC4AcwB5AHMAagBvAGIAcwAgAHMAagANAAoACQAJAAkAIAAgACAAIABKAE8ASQBOACAAbQBzAGQAYgAuAGQAYgBvAC4AcwB5AHMAagBvAGIAaABpAHMAdABvAHIAeQAgAHMAagBoAA0ACgAJAAkACQAJACAAIAAgACAATwBOACAAcwBqAC4AagBvAGIAXwBpAGQAIAA9ACAAcwBqAGgALgBqAG8AYgBfAGkAZAANAAoACQAJACAAIAAgACAAVwBIAEUAUgBFAA0ACgAJAAkACQAgACAAIAAgAHMAagBoAC4AcgB1AG4AXwBzAHQAYQB0AHUAcwAgAEkATgAgACgAMAAsACAAMwApACAAQQBOAEQADQAKAAkACQAJACAAIAAgACAAcwBqAGgALgBzAHQAZQBwAF8AaQBkACAAPQAgADAAIABBAE4ARAANAAoACQAJAAkAIAAgACAAIABDAEEAUwBUACgAcwBqAGgALgByAHUAbgBfAGQAYQB0AGUAIABBAFMAIABGAEwATwBBAFQAKQAgACoAIAAxADAAMAAwADAAMAAwACAAKwAgAHMAagBoAC4AcgB1AG4AXwB0AGkAbQBlACAAPgAgAEMAQQBTAFQAKABDAE8ATgBWAEUAUgBUACgAVgBBAFIAQwBIAEEAUgAoADgAKQAsACAARwBFAFQARABBAFQARQAoACkAIAAtACAAMQAsACAAMQAxADIAKQAgAEEAUwAgAEYATABPAEEAVAApACAAKgANAAoACQAJAAkAIAAgACAAIAAxADAAMAAwADAAMAAwACAAKwAgADcAMAAwADAAMAA7AA==')));
		[String]$FailedAgentJobResults = f2 -SQLServer $svr -TSQL $sql -ReportHeading $Heading
    }
    [String]$Heading = "Check Missing Backups: $svr"
	If ($ServerName.CheckMissingBackups -eq $true)
	{
		[string]$sql = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAgACAAIAAgAFMARQBMAEUAQwBUAA0ACgAJAAkAIAAgACAAIABEAGEAdABhAGIAYQBzAGUATgBhAG0AZQAgAD0AIABkAC4AbgBhAG0AZQANAAoACQAJACAAIAAgACAALABCAGEAYwBrAHUAcABUAHkAcABlACAAPQAgACcARgB1AGwAbAAnAA0ACgAJAAkAIAAgACAAIAAsAEwAYQBzAHQARgB1AGwAbABCAGEAYwBrAHUAcAAgAD0AIABJAFMATgBVAEwATAAoAEMATwBOAFYARQBSAFQAKABWAEEAUgBDAEgAQQBSACwAIABiAC4AYgBhAGMAawB1AHAAZABhAHQAZQAsACAAMQAyADAAKQAsACAAJwBOAEUAVgBFAFIAJwApAA0ACgAJAAkAIAAgACAAIAAsAEEAbABlAHIAdAAgAD0AIAAnAGEAbABlAHIAdAAnAA0ACgAJACAAIAAgACAARgBSAE8ATQANAAoACQAJACAAIAAgACAAcwB5AHMALgBkAGEAdABhAGIAYQBzAGUAcwAgAGQADQAKAAkACQAgACAAIAAgAEwARQBGAFQAIABKAE8ASQBOACAAKAANAAoACQAJAAkACQAJACAAIAAgACAAUwBFAEwARQBDAFQADQAKAAkACQAJAAkACQAJACAAIAAgACAAZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAJAAkACQAJAAkAIAAgACAAIAAsAFsAVAB5AHAAZQBdAA0ACgAJAAkACQAJAAkACQAgACAAIAAgACwATQBBAFgAKABiAGEAYwBrAHUAcABfAGYAaQBuAGkAcwBoAF8AZABhAHQAZQApACAAYgBhAGMAawB1AHAAZABhAHQAZQANAAoACQAJAAkACQAJACAAIAAgACAARgBSAE8ATQANAAoACQAJAAkACQAJAAkAIAAgACAAIABtAHMAZABiAC4AZABiAG8ALgBiAGEAYwBrAHUAcABzAGUAdAANAAoACQAJAAkACQAJACAAIAAgACAAVwBIAEUAUgBFAA0ACgAJAAkACQAJAAkACQAgACAAIAAgAFsAVAB5AHAAZQBdACAATABJAEsARQAgACcARAAnAA0ACgAJAAkACQAJAAkAIAAgACAAIABHAFIATwBVAFAAIABCAFkADQAKAAkACQAJAAkACQAJACAAIAAgACAAZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAJAAkACQAJAAkAIAAgACAAIAAsAFsAVAB5AHAAZQBdAA0ACgAJAAkACQAJAAkAIAAgACAAIAApACAAYgANAAoACQAJAAkAIAAgACAAIABPAE4AIABkAC4AbgBhAG0AZQAgAD0AIABiAC4AZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAgACAAIAAgAFcASABFAFIARQANAAoACQAJACAAIAAgACAAKAANAAoACQAJAAkACQAgACAAIAAgAGIAYQBjAGsAdQBwAGQAYQB0AGUAIABJAFMAIABOAFUATABMACAATwBSAA0ACgAJAAkACQAJACAAIAAgACAAYgBhAGMAawB1AHAAZABhAHQAZQAgADwAIABHAEUAVABEAEEAVABFACgAKQAgAC0AIAAxAA0ACgAJAAkAIAAgACAAIAApACAAQQBOAEQADQAKAAkACQAgACAAIAAgAGQALgBuAGEAbQBlACAAPAA+ACAAJwB0AGUAbQBwAGQAYgAnAA0ACgAJACAAIAAgACAAVQBOAEkATwBOAA0ACgAJAAkAIAAgACAAIABTAEUATABFAEMAVAANAAoACQAJAAkAIAAgACAAIABEAGEAdABhAGIAYQBzAGUATgBhAG0AZQAgAD0AIABkAC4AbgBhAG0AZQANAAoACQAJAAkAIAAgACAAIAAsAEIAYQBjAGsAdQBwAFQAeQBwAGUAIAA9ACAAJwBUAHIAbgAnAA0ACgAJAAkACQAgACAAIAAgACwATABhAHMAdABMAG8AZwBCAGEAYwBrAHUAcAAgAD0AIABJAFMATgBVAEwATAAoAEMATwBOAFYARQBSAFQAKABWAEEAUgBDAEgAQQBSACwAIABiAC4AYgBhAGMAawB1AHAAZABhAHQAZQAsACAAMQAyADAAKQAsACAAJwBOAEUAVgBFAFIAJwApAA0ACgAJAAkACQAgACAAIAAgACwAQQBsAGUAcgB0ACAAPQAgACcAYQBsAGUAcgB0ACcADQAKAAkACQAgACAAIAAgAEYAUgBPAE0ADQAKAAkACQAJACAAIAAgACAAcwB5AHMALgBkAGEAdABhAGIAYQBzAGUAcwAgAGQADQAKAAkACQAJACAAIAAgACAATABFAEYAVAAgAEoATwBJAE4AIAAoAA0ACgAJAAkACQAJAAkAIAAgACAAIAAgACAAIAAgAFMARQBMAEUAQwBUAA0ACgAJAAkACQAJAAkACQAJACAAIAAgACAAZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAJAAkACQAJAAkAIAAgACAAIAAgACAAIAAgACwAWwBUAHkAcABlAF0ADQAKAAkACQAJAAkACQAJACAAIAAgACAAIAAgACAAIAAsAE0AQQBYACgAYgBhAGMAawB1AHAAXwBmAGkAbgBpAHMAaABfAGQAYQB0AGUAKQAgAGIAYQBjAGsAdQBwAGQAYQB0AGUADQAKAAkACQAJAAkACQAJACAAIAAgACAARgBSAE8ATQANAAoACQAJAAkACQAJAAkACQAgACAAIAAgAG0AcwBkAGIALgBkAGIAbwAuAGIAYQBjAGsAdQBwAHMAZQB0AA0ACgAJAAkACQAJAAkACQAgACAAIAAgAFcASABFAFIARQANAAoACQAJAAkACQAJAAkACQAgACAAIAAgAFQAeQBwAGUAIABMAEkASwBFACAAJwBMACcADQAKAAkACQAJAAkACQAJACAAIAAgACAARwBSAE8AVQBQACAAQgBZAA0ACgAJAAkACQAJAAkACQAJACAAIAAgACAAZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAJAAkACQAJAAkAIAAgACAAIAAgACAAIAAgACwAWwBUAHkAcABlAF0ADQAKAAkACQAJAAkACQAgACAAIAAgACAAIAAgACAAKQAgAGIADQAKAAkACQAJAAkAIAAgACAAIABPAE4AIABkAC4AbgBhAG0AZQAgAD0AIABiAC4AZABhAHQAYQBiAGEAcwBlAF8AbgBhAG0AZQANAAoACQAJACAAIAAgACAAVwBIAEUAUgBFAA0ACgAJAAkACQAgACAAIAAgAHIAZQBjAG8AdgBlAHIAeQBfAG0AbwBkAGUAbAAgAD0AIAAxACAAQQBOAEQADQAKAAkACQAJACAAIAAgACAAKAANAAoACQAJAAkACQAgACAAIAAgACAAIAAgACAAYgBhAGMAawB1AHAAZABhAHQAZQAgAEkAUwAgAE4AVQBMAEwAIABPAFIADQAKAAkACQAJAAkAIAAgACAAIAAgACAAIAAgAGIAYQBjAGsAdQBwAGQAYQB0AGUAIAA8ACAARwBFAFQARABBAFQARQAoACkAIAAtACAAMQANAAoACQAJAAkAIAAgACAAIAApACAAQQBOAEQADQAKAAkACQAJACAAIAAgACAAZAAuAG4AYQBtAGUAIAA8AD4AIAAnAHQAZQBtAHAAZABiACcAOwA=')));
		[string]$MissingBackups = f2 -SQLServer $svr -TSQL $sql -ReportHeading $Heading
	}
    if ($SQLErrorsResults.Length -lt 4) { $SQLErrorsResults = ""} else {$SQLErrorsResults = $SQLErrorsResults.Substring(3)}
	if ($FailedAgentJobResults.Length -lt 4) { $FailedAgentJobResults = ""} else {$FailedAgentJobResults = $FailedAgentJobResults.Substring(3)}
	if ($MissingBackups.Length -lt 4) { $MissingBackups = ""} else {$MissingBackups = $MissingBackups.Substring(3)}
    [String]$MailBody = "$MailHeader $SystemInfo $SQLErrorsResults $FailedAgentJobResults $MissingBackups</body>"
	f1 -MailFromAddress "$svr@email.com" -MailAddress $emailTo -MailSubject "Server Check $svr" -MailBody $MailBody
}