﻿function get_red{
[cmdletbinding()]
Param(
        [parameter(ValueFromPipeLine=$True,ValueFromPipeLineByPropertyName=$True)]
        [Alias("CN","__Server","IPAddress","Server")]
        [string[]]$Computername = $Env:Computername
        )
begin{
clear
}
process{
    foreach($i in $Computername){
        if(Test-Connection -ComputerName $i -Count 1 -Quiet){
            #$i
            try{           
            $tcp = Get-WmiObject -ComputerName $i win32_networkadapterconfiguration -ErrorAction $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AG8AcAA=')))            
            $bios = get-wmiobject -computername $i win32_bios -erroraction $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwB0AG8AcAA=')))
                if($tcp.Length -eq 1){                                
                    #id = 0
                    #"if 0"                                              
                    $a_object = new-object PSObject -Property @{
                    ERROR = ""
                    IP = $i
                    NAME = $tcp.dnshostname
                    DHCP = $tcp.dhcpenabled
                    GW = $tcp.DefaultIPGateway
                    MASK = $tcp.ipsubnet
                    DNS = $tcp.DNSServerSearchOrder
                    MAC = $tcp.macaddress
                    SERIAL = $bios.serialnumber
                    }
                 $a_object                                                   #>salida
                 }
                ElseIf (($tcp.index).Length -gt 1) {
                #aplica un filtro"
                 #id = 0
                 #"elseif 0" + " $i"
                 $obj_sel = $tcp | Where-Object {$_.ipenabled -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAByAHUAZQA='))) -and ($_.caption -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBpAHIAdAB1AGEAbAA=')))) }                     
                    if(($obj_sel.index).length -eq 1){
                        #id = 0.1
                        #g"if = 0.1" + " $i"
                        $a_object = new-object PSObject -Property @{
                        ERROR = "~~"
                        IP = $i 
                        NAME = $obj_sel.dnshostname
                        DHCP = $obj_sel.dhcpenabled
                        GW = $obj_sel.DefaultIPGateway
                        MASK = $obj_sel.ipsubnet
                        DNS = $obj_sel.DNSServerSearchOrder
                        MAC = $obj_sel.macaddress
                        SERIAL = $bios.serialnumber
                        }
                        $a_object                                               #>salida              
                    }
                    elseif(($obj_sel.index).length -gt 1){
                    #id = 0.2
                        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBsAHMAZQBpAGYAIAAwAC4AMgA=')))
                        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlACAAZQBuAGMAbwBuAHQAcgBhAHIAbwBuACAAewAwAH0AIABvAGIAagBlAHQAbwBzAC4A'))) -f $obj_sel.Length
                        $a_object = new-object PSObject -Property @{
                            ERROR = "No"
                            IP = $i
                            NAME = $obj_sel.dnshostname
                            DHCP = $obj_sel.dhcpenabled
                            GW = $obj_sel.DefaultIPGateway
                            MASK = "~~"
                            DNS = "~~"
                            }
                            $obj_sel | select caption
                        #$a_object
                    }
                 }            
                else{
                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBsAHMAZQA=')))
                 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlACAAZQBuAGMAbwBuAHQAcgBhAHIAbwBuACAAewAwAH0AIABvAGIAagBlAHQAbwBzAC4A'))) -f $a.Length        
                 }
            }
            catch [System.Runtime.InteropServices.COMException] {
            #"error 0: {0}" -f $_.exception.message
                $a_object = new-object PSObject -Property @{
                ERROR = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBwAGMA')))
                IP = $i
                NAME = "~~"
                DHCP = "~~"
                GW = "~~"
                MASK = "~~"
                DNS = "~~"
                MAC = "~~"
                SERIAL = "~~"
                }
                $a_object                                                             #>salida
                #continue
                #break
            }
            catch [System.UnauthorizedAccessException]{#error de permisos
            #"error 1: {0}" -f $_.exception.message  
                $a_object = new-object PSObject -Property @{
                ERROR = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABlAHIAbQBpAHMAbwBzAA==')))
                IP = $i
                NAME = "~~"
                DHCP = "~~"
                GW = "~~"
                MASK = "~~"
                DNS = "~~"
                MAC = "~~"
                SERIAL = "~~"
                }
                $a_object                                                             #>salida
                #continue
                #break
            }
            catch{
            #"error 3: {0}" -f $_.exception.message
                $a_object  = new-object PSObject -Property @{
                ERROR = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABlAHMAYwBvAG4AbwBjAGkAZABvAA==')))
                IP = $i 
                NAME = "~~"
                DHCP = "~~"
                GW = "~~"
                MASK = "~~"
                DNS = "~~"
                MAC = "~~"
                SERIAL = "~~"
                }
                $a_object                                                             #>salida
                #continue
                #break
            }
        }
        else{
         $object = New-Object PSObject -Property @{
                    ERROR = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABpAG4AZwA=')))
                    IP = $i 
                    NAME = "~~"
                    DHCP = "~~"
                    GW = "~~"
                    MASK = "~~"
                    DNS = "~~"
                    MAC = "~~"
                    SERIAL = "~~"
                    }
         $object                                                                      #>salida
        }
    } 
}
end{
}
}
