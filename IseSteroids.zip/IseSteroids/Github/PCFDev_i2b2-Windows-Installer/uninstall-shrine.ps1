﻿
. .\functions.ps1
. .\config-system.ps1
. .\config-i2b2.ps1
. .\config-shrine.ps1
function _00111111110110010 {
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBuAGkAbgBzAHQAYQBsAGwAaQBuAGcAIABUAG8AbQBjAGEAdAA4ACAAcwBlAHIAdgBpAGMAZQAuAC4ALgA=')))
    & $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABFAG4AdgA6AEMAQQBUAEEATABJAE4AQQBfAEgATwBNAEUAXABiAGkAbgBcAHMAZQByAHYAaQBjAGUALgBiAGEAdAA='))) uninstall Tomcat8
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBhAGMAawBpAG4AZwAgAHUAcAAgAGQAYQB0AGEAcwBvAHUAcgBjAGUAIABmAGkAbABlACAAdABvACAAYgBhAGMAawB1AHAAIABmAG8AbABkAGUAcgAgAGIAZQBuAGUAYQB0AGgAIABKAEIATwBTAFMAIABkAGkAcgBlAGMAdABvAHIAeQAuAC4ALgA=')))
	mkdir $Env:JBOSS_HOME\backup
	Move-Item $Env:JBOSS_HOME\standalone\deployments\ont-ds.xml $Env:JBOSS_HOME\backup\ont-ds.xml
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgBhAGMAawB1AHAAIABmAGkAbgBpAHMAaABlAGQALgAgAE0AbwB2AGkAbgBnACAAcAByAGUALQBTAEgAUgBJAE4ARQAgAGQAYQB0AGEAcwBvAHUAcgBjAGUAIABpAG4AdABvACAAaQAyAGIAMgAgAGkAbgBzAHQAYQBsAGwAYQB0AGkAbwBuAC4ALgAuAA==')))
	Move-Item $_SHRINE_HOME\Datasource_Backup\ont-ds.xml $Env:JBOSS_HOME\standalone\deployments\ont-ds.xml -Force
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAG0AbwB2AGkAbgBnACAAUwBoAHIAaQBuAGUAIABhAG4AZAAgAFQAbwBtAGMAYQB0ACAAZgBpAGwAZQBzACAAYQBuAGQAIABkAGkAcgBlAGMAdABvAHIAaQBlAHMALgAuAC4A')))
    Remove-Item $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAbwBwAHQAXABzAGgAcgBpAG4AZQA='))) -Force -Recurse
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBoAHIAaQBuAGUAIABhAG4AZAAgAFQAbwBtAGMAYQB0ACAAaABhAHYAZQAgAGIAZQBlAG4AIAByAGUAbQBvAHYAZQBkAC4A')))
}
function _01100010111000010 {
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBlAGcAaQBuAG4AaQBuAGcAIABTAGgAcgBpAG4AZQAgAHIAZQBtAG8AdgBhAGwAIABmAHIAbwBtACAASQAyAEIAMgAgAEQAQgAuAC4ALgA=')))
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBwAGQAYQB0AGkAbgBnACAAaABpAHYAZQAgAGQAYQB0AGEAYgBhAHMAZQAuAC4ALgA=')))
    ${01101001000111100} = interpolate_file $__skelDirectory\shrine\$DEFAULT_DB_TYPE\uninstall_configure_hive_db_lookups.sql DB_NAME $HIVE_DB_NAME
    execSqlCmd $DEFAULT_DB_SERVER $DEFAULT_DB_TYPE $HIVE_DB_NAME $HIVE_DB_USER $HIVE_DB_PASS ${01101001000111100}
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBwAGQAYQB0AGkAbgBnACAAcABtACAAYwBlAGwAbAAgAGQAYQB0AGEAYgBhAHMAZQAuAC4ALgA=')))
    ${01101001000111100} = interpolate_file $__skelDirectory\shrine\$DEFAULT_DB_TYPE\uninstall_configure_pm.sql DB_NAME $PM_DB_NAME
    execSqlCmd $DEFAULT_DB_SERVER $DEFAULT_DB_TYPE $PM_DB_NAME $PM_DB_USER $PM_DB_PASS ${01101001000111100}
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAG0AbwB2AGkAbgBnACAAdABhAGIAbABlAHMALgAuAC4A')))
    ${01101001000111100} = interpolate_file $__skelDirectory\shrine\sqlserver\uninstall_ontology_create_tables.sql DB_NAME $ONT_DB_NAME |
        interpolate I2B2_DB_SCHEMA $DEFAULT_DB_SCHEMA
    execSqlCmd $DEFAULT_DB_SERVER $DEFAULT_DB_TYPE $ONT_DB_NAME $ONT_DB_USER $ONT_DB_PASS ${01101001000111100}
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBwAGQAYQB0AGkAbgBnACAAdABhAGIAbABlACAAYQBjAGMAZQBzAHMALgAuAC4A')))
    ${01101001000111100} = interpolate_file $__skelDirectory\shrine\sqlserver\ontology_table_access.sql DB_NAME $ONT_DB_NAME |
        interpolate I2B2_DB_SCHEMA $DEFAULT_DB_SCHEMA
    execSqlCmd $DEFAULT_DB_SERVER $DEFAULT_DB_TYPE $ONT_DB_NAME $ONT_DB_USER $ONT_DB_PASS ${01101001000111100}
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAG0AbwB2AGkAbgBnACAAUwBoAHIAaQBuAGUAIABEAEIAIABBAGQAbQBpAG4ALgAuAC4A')))
	removeUser $SHRINE_DB_NAME $SHRINE_DB_USER $SHRINE_DB_PASS $DEFAULT_DB_SCHEMA
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AcABsAGUAdABlAC4A')))
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAG0AbwB2AGkAbgBnACAAUwBoAHIAaQBuAGUAIABRAHUAZQByAHkAIABIAGkAcwB0AG8AcgB5ACAAZABhAHQAYQBiAGEAcwBlAC4ALgAuAA==')))
	removeDatabase $SHRINE_DB_NAME
	echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAG4AaQBzAGgAZQBkACAAcgBlAG0AbwB2AGkAbgBnACAAUwBoAHIAaQBuAGUAIABkAGEAdABhAC4AIABTAGgAcgBpAG4AZQAgAHUAbgBpAG4AcwB0AGEAbABsACAAYwBvAG0AcABsAGUAdABlAC4A')))
}
if($RemoveShrine -eq $true){
	_00111111110110010
	_01100010111000010
}
