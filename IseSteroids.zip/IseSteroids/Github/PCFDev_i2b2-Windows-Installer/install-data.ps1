﻿function f6{

    cd Crcdata

    createDatabase $CRC_DB_NAME
    createUser $CRC_DB_NAME $CRC_DB_USER $CRC_DB_PASS $DEFAULT_DB_SCHEMA

    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $CRC_DB_USER |
        interpolate DB_PASS $CRC_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $CRC_DB_DRIVER |
        interpolate DB_URL (escape $CRC_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties
    
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAEMAUgBDACAAVABhAGIAbABlAHMA')))    
    ant -f "${1}" create_crcdata_tables_release_1-7

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAEMAUgBDACAAUwB0AG8AcgBlAGQAIABQAHIAbwBjAGUAZAB1AHIAZQBzAA==')))
    ant -f "${1}" create_procedures_release_1-7

    if($InstallDemoData -eq $true){
        echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAEMAUgBDACAAZABlAG0AbwAgAGQAYQB0AGEA')))
        ant -f "${1}" db_demodata_load_data        
    }
    
    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBSAEMAIABEAGEAdABhACAASQBuAHMAdABhAGwAbABlAGQA')))

}

function f5{
    cd Hivedata
    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    createDatabase $HIVE_DB_NAME
    createUser $HIVE_DB_NAME $HIVE_DB_USER $HIVE_DB_PASS $DEFAULT_DB_SCHEMA

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $HIVE_DB_USER |
        interpolate DB_PASS $HIVE_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $HIVE_DB_DRIVER |
        interpolate DB_URL (escape $HIVE_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAEgAaQB2AGUAIABUAGEAYgBsAGUAcwA=')))

    ant -f "${1}" create_hivedata_tables_release_1-7


    if($InstallDemoData -eq $true){
       echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAEgAaQB2AGUAIABkAGUAbQBvACAAZABhAHQAYQA=')))

       ant -f "${1}" db_hivedata_load_data
    }

    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABpAHYAZQAgAEQAYQB0AGEAIABJAG4AcwB0AGEAbABsAGUAZAA=')))
}

function f4{

    cd Imdata
    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    createDatabase $IM_DB_NAME
    createUser $IM_DB_NAME $IM_DB_USER $IM_DB_PASS $DEFAULT_DB_SCHEMA

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $IM_DB_USER |
        interpolate DB_PASS $IM_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $IM_DB_DRIVER |
        interpolate DB_URL (escape $IM_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAEkATQAgAFQAYQBiAGwAZQBzAA==')))
    ant -f "${1}" create_imdata_tables_release_1-7
    
    if($InstallDemoData -eq $true){
        echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAEkATQAgAGQAZQBtAG8AIABkAGEAdABhAA==')))
        ant -f "${1}"  db_imdata_load_data
    }

    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBNACAARABhAHQAYQAgAEkAbgBzAHQAYQBsAGwAZQBkAA==')))
}

function f3{

    cd Metadata
    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    createDatabase $ONT_DB_NAME
    createUser $ONT_DB_NAME $ONT_DB_USER $ONT_DB_PASS $DEFAULT_DB_SCHEMA

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $ONT_DB_USER |
        interpolate DB_PASS $ONT_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $ONT_DB_DRIVER |
        interpolate DB_URL (escape $ONT_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAE8ATgBUACAAVABhAGIAbABlAHMA')))
    ant -f "${1}" create_metadata_tables_release_1-7
    
    if($InstallDemoData -eq $true){
        echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAE8ATgBUACAAZABlAG0AbwAgAGQAYQB0AGEA')))
        ant -f "${1}" db_metadata_load_data
    }

    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAHQAYQBkAGEAdABhACAARABhAHQAYQAgAEkAbgBzAHQAYQBsAGwAZQBkAA==')))
}

function f2{

    cd Pmdata        
    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    createDatabase $PM_DB_NAME
    createUser $PM_DB_NAME $PM_DB_USER $PM_DB_PASS $DEFAULT_DB_SCHEMA

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $PM_DB_USER |
        interpolate DB_PASS $PM_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $PM_DB_DRIVER |
        interpolate DB_URL (escape $PM_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAFAATQAgAFQAYQBiAGwAZQBzAA==')))

    ant -f "${1}" create_pmdata_tables_release_1-7

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAFAATQAgAFQAcgBpAGcAZwBlAHIAcwA=')))
    

    ant -f "${1}" create_triggers_release_1-7
    
    if($InstallDemoData -eq $true){
        echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAFAATQAgAGQAZQBtAG8AIABkAGEAdABhAA==')))
        ant -f "${1}" db_pmdata_load_data
    }

    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABNACAARABhAHQAYQAgAEkAbgBzAHQAYQBsAGwAZQBkAA==')))
}

function f1{

    cd Workdata    
    ${1} = (gi -Path ".\" -Verbose).FullName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABkAGEAdABhAF8AYgB1AGkAbABkAC4AeABtAGwA')))

    createDatabase $WORK_DB_NAME
    createUser $WORK_DB_NAME $WORK_DB_USER $WORK_DB_PASS $DEFAULT_DB_SCHEMA

    interpolate_file $__skelDirectory\i2b2\data\db.properties DB_TYPE $DEFAULT_DB_TYPE |
        interpolate DB_USER $WORK_DB_USER |
        interpolate DB_PASS $WORK_DB_PASS |
        interpolate DB_SERVER (escape $DEFAULT_DB_SERVER) |
        interpolate DB_DRIVER $WORK_DB_DRIVER |
        interpolate DB_URL (escape $WORK_DB_URL) |
        interpolate I2B2_PROJECT_NAME $I2B2_PROJECT_NAME |
        sc db.properties

    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABpAG4AZwAgAFcAbwByAGsAIABUAGEAYgBsAGUAcwA=')))

    ant -f "${1}" create_workdata_tables_release_1-7
  
    if($InstallDemoData -eq $true){
        echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZABpAG4AZwAgAFcAbwByAGsAIABkAGUAbQBvACAAZABhAHQAYQA=')))
        ant -f "${1}" db_workdata_load_data
    }

    cd ..
    echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHIAawAgAEQAYQB0AGEAIABJAG4AcwB0AGEAbABsAGUAZAA=')))
}





require $DEFAULT_DB_ADMIN_USER $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlACAAYQBkAG0AaQBuACAAdQBzAGUAcgBuAGEAbQBlACAAbQB1AHMAdAAgAGIAZQAgAHMAZQB0ACAAaQBuACAAdABoAGUAIABjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuAA==')))
require $DEFAULT_DB_ADMIN_PASS $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlACAAYQBkAG0AaQBuACAAcABhAHMAcwB3AG8AcgBkACAAbQB1AHMAdAAgAGIAZQAgAHMAZQB0ACAAaQBuACAAdABoAGUAIABjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuAA==')))
require $DEFAULT_DB_TYPE $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlACAAdAB5AHAAZQAgAG0AdQBzAHQAIABiAGUAIABzAGUAdAAgAGkAbgAgAHQAaABlACAAYwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgA=')))
require $DEFAULT_DB_SERVER $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlACAAcwBlAHIAdgBlAHIAIABtAHUAcwB0ACAAYgBlACAAcwBlAHQAIABpAG4AIAB0AGgAZQAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4A')))

echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAaQAyAGIAMgAgAEQAYQB0AGEAIABJAG4AcwB0AGEAbABsAGEAdABpAG8AbgA=')))


echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAcgBhAGMAdABpAG4AZwAgAGQAYQB0AGEAIABjAHIAZQBhAHQAaQBvAG4AIABzAGMAcgBpAHAAdABzAC4ALgAuAA==')))
unzip $__dataInstallationZipFile $__sourceCodeRootFolder $true
echo "Source extracted to $__sourceCodeRootFolder"

if(!(Test-Path $__sourceCodeRootFolder))
{
    Throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQAgAGMAcgBlAGEAdABpAG8AbgAgAHMAYwByAGkAcAB0AHMAIABuAG8AdAAgAGUAeAB0AHIAYQBjAHQAZQBkAA==')))
}

cd $__sourceCodeRootFolder\edu.harvard.i2b2.data\Release_1-7\NewInstall

f6
f5
f4
f3
f2
f1


cd $__currentDirectory

echo $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQAyAGIAMgAgAEQAYQB0AGEAIABJAG4AcwB0AGEAbABsAGEAdABpAG8AbgAgAEMAbwBtAHAAbABlAHQAZQBkAA==')))