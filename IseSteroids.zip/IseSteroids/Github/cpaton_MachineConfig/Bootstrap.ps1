﻿
Set-ExecutionPolicy RemoteSigned -Force
if ( Test-Path C:\MachineConfig ) {
    Remove-Item C:\MachineConfig -Recurse -Force
}
${/=\__/==\__/\__/=} = Get-Credential -UserName STORAGE\Public -Message "Public user"
net use \\192.168.0.21\ipc$ /delete
net use \\192.168.0.21\ipc$ ( ${/=\__/==\__/\__/=}.GetNetworkCredential().Password ) /user:Storage\Public
Copy-Item \\192.168.0.21\Public\MachineConfig c:\ -Recurse
c:\MachineConfig\Init.ps1