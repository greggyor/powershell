﻿${6} = $MyInvocation.MyCommand.Path
${4} = Split-Path ${6}

${7} = Join-Path ${4} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQB0AGkAbABpAHQAaQBlAHMALgBwAHMAMQA=')))
iex ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAgAHsAMAB9AA=='))) -f ${7} )

if ( -not ( Test-Admin ) ) {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAC0AcgB1AG4AbgBpAG4AZwAgAHQAaABpAHMAIABzAGMAcgBpAHAAdAAgAGEAcwAgAEEAZABtAGkAbgA=')))
    RunScriptAsAdmin ${6}
    return
}

Enable-PSRemoting -Force

if ( -not ( Test-Path C:\_cp ) ) {
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAZABpAHIAZQBjAHQAbwByAHkAIABDADoAXABfAGMAcAA=')))
    ni -Path C:\_cp -ItemType Directory | Out-Null
}

Get-PackageProvider -Name chocolatey -Force

Install-Package boxstarter -Force

<#
# Install Chocolately
if ( -not ( Test-Path Env:\ChocolateyInstall ) ) {
    Write-Host "Installing Chocolately"
    Invoke-Expression ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
}

choco install boxstarter -y
#>

# Add the boxstarter modules to the current shell
${5} = Join-Path $env:APPDATA $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBvAHgAUwB0AGEAcgB0AGUAcgBcAEIAbwB4AFMAdABhAHIAdABlAHIAUwBoAGUAbABsAC4AcABzADEA')))
iex ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgAgACcAewAwAH0AJwA='))) -f ${5} )

Enable-RemoteDesktop
Move-LibraryDirectory $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAHcAbgBsAG8AYQBkAHMA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAXwBjAHAAXABEAG8AdwBuAGwAbwBhAGQAcwA=')))
Enable-MicrosoftUpdate
Set-WindowsExplorerOptions -EnableShowHiddenFilesFoldersDrives -EnableShowFileExtensions -EnableShowFullPathInTitleBar
Update-Help -UICulture $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBuAC0AdQBzAA==')))

${3} = Join-Path ${4} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAGMAawBhAGcAZQBzAC4AQwBvAHIAZQAuAGMAbwBuAGYAaQBnAA==')))
#$packagesCore = "C:\_cp\Git\MachineConfig\Packages.Core.config"
${2} = [xml](gc ${3})

#$packages = [string[]]$packagesXml.Packages.package.id
#Install-Package -Name $packages -Force -Verbose


foreach ( ${1} in ${2}.Packages.package.id ) {
    Install-Package ${1} -Force -Verbose
}



<#
# Take the box starter template script BoxStarter.Common and create a specific one with the package configs to run
$boxStarterCommon = Join-Path $scriptDirectory "Boxstarter.Common.ps1"
$boxStarterScript = Join-Path $scriptDirectory "Boxstarter.ps1"

if ( Test-Path $boxStarterScript ) {
    Remove-Item $boxStarterScript
}
Copy-Item $boxStarterCommon $boxStarterScript

$packagesCore = Join-Path $scriptDirectory "Packages.Core.config"
Add-Content -Path $boxStarterScript ( "`nchoco install '{0}' -y" -f $packagesCore )

# Run boxstarter
$Boxstarter.RebootOk = $true
Install-BoxstarterPackage $boxStarterScript
#>