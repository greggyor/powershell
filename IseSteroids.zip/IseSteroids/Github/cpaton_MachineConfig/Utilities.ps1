﻿function Test-Admin {
    $identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal( $identity )
    return $principal.IsInRole( [System.Security.Principal.WindowsBuiltInRole]::Administrator )
}
function RunScriptAsAdmin() {
    [CmdletBinding()]
    param (
        [Parameter(Position = 0, Mandatory = $true)]
        [string] $ScriptPath
    )
    Write-Verbose ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgB1AG4AbgBpAG4AZwAgAHMAYwByAGkAcAB0ACAAewAwAH0AIABhAHMAIABhAGQAbQBpAG4AaQBzAHQAcgBhAHQAbwByAA=='))) -f $ScriptPath )
    saps powershell -Verb RunAs -ArgumentList ( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBFAHgAZQBjAHUAdABpAG8AbgBQAG8AbABpAGMAeQAgAGIAeQBwAGEAcwBzACAALQBOAG8ARQB4AGkAdAAgAC0ATgBvAFAAcgBvAGYAaQBsAGUAIAAtAEMAbwBtAG0AYQBuAGQAIAAiAHsAMAB9ACIA'))) -f $ScriptPath )
}