﻿
if($Host.Version.Major -ge 2) {
   function script:Resolve-Aliases
   {
      param($line)

      [System.Management.Automation.PSParser]::Tokenize($line,[ref]$null) | % {
         if($_.Type -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AbQBhAG4AZAA=')))) {
            $cmd = @(which $_.Content)[0]
            if($cmd.CommandType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGkAYQBzAA==')))) {
               $line = $line.Remove( $_.StartColumn -1, $_.Length ).Insert( $_.StartColumn -1, $cmd.Definition )
            }
         }
      }
      $line
   }
}

function alias {
   
   $alias,$cmd = [string]::join(" ",$args).split("=",2) | % { $_.trim()}

   if($Host.Version.Major -ge 2) {
      $cmd = Resolve-Aliases $cmd
   }
   ni -Path function: -Name "Global:Alias$Alias" -Options $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAUwBjAG8AcABlAA=='))) -Value @"
		Invoke-Expression '$cmd `$args'
		###ALIAS###
"@

   sal -Name $Alias -Value "Alias$Alias" -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQAgAFUATgBJAFgALQBzAHQAeQBsAGUAIABhAGwAaQBhAHMAIAB1AHMAaQBuAGcAIABmAHUAbgBjAHQAaQBvAG4AcwA='))) -Option $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAUwBjAG8AcABlAA=='))) -scope Global -passThru
}

function unalias([string]$Alias,[switch]$Force){ 
   if( (gal $Alias).Description -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQAgAFUATgBJAFgALQBzAHQAeQBsAGUAIABhAGwAaQBhAHMAIAB1AHMAaQBuAGcAIABmAHUAbgBjAHQAaQBvAG4AcwA='))) ) {
      rd "function:Alias$Alias" -Force:$Force
      rd "alias:$alias" -Force:$Force
      if($?) {
         "Removed alias '$Alias' and accompanying function"
      }
   } else {
      rd "alias:$alias" -Force:$Force
      if($?) {
         "Removed alias '$Alias'"
      }
   }
}