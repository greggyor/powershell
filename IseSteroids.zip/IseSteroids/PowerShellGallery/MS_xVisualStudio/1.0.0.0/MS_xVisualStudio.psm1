﻿enum Ensure
{
    Absent
    Present
}
[DscResource()]
class MS_xVisualStudio
{
    [DscProperty(Key)]
    [string] $ProductName
    [DscProperty(Mandatory)]
    [string] $ExecutablePath
    [DscProperty(Mandatory)]
    [string] $AdminDeploymentFile
    [DscProperty()]
    [string] $ProductKey
    [DscProperty(Mandatory)]
    [Ensure] $Ensure
    [DscProperty(NotConfigurable)]
    [bool] $IsValid
    [MS_xVisualStudio] Get()
    {
        ${_/\_/=\_/\/\__/\/} = $this.GetInstalledSoftwares() |? {$_.DisplayName -eq $this.ProductName}
        if(($this.Ensure -eq [Ensure]::Present) -and ${_/\_/=\_/\/\__/\/})
        {
            $this.IsValid = $true
        }
        else
        {
            $this.IsValid = $false
        }
        return $this
    }
    [void] Set()
    {
        if(-not (Test-Path $this.ExecutablePath))
        {
            throw "Invalid path : $($this.ExecutablePath)"
        }
        if($this.Ensure -eq [Ensure]::Present)
        {
            if(-not (Test-Path $this.AdminDeploymentFile))
            {
                throw "Invalid path : $($this.AdminDeploymentFile)"
            }
            $args = "/Quiet /NoRestart /AdminFile $($this.AdminDeploymentFile) /Log $Env:Temp\VisualStudio_$(Get-Date -Format "MM-dd-yyyy_hh-mm-ss")_Install.log"
            if($this.ProductKey)
            {
                $args = $args + " /ProductKey $this.ProductKey"
            }
            "Installation arguments : $args" | Write-Verbose
            "Starting installation" | Write-Verbose
            Start-Process -FilePath $this.ExecutablePath -ArgumentList $args -Wait -NoNewWindow       
            "Successfully completed the installation" | Write-Verbose
         }
         else
         {
            $args = "/Quiet /Force /Uninstall /Log $Env:Temp\VisualStudio_$(Get-Date -Format "MM-dd-yyyy_hh-mm-ss")_Install.log"
            "Uninstallation arguments : $args" | Write-Verbose
            "Starting uninstallation" | Write-Verbose
            Start-Process -FilePath $this.ExecutablePath -ArgumentList $args -Wait -NoNewWindow       
            "Successfully completed the uninstallation" | Write-Verbose
          }
       }
    [bool] Test()
    {
        ${_/\_/=\_/\/\__/\/} = $this.GetInstalledSoftwares() |? {$_.DisplayName -eq $this.ProductName}
        if($this.Ensure -eq [Ensure]::Present)
        {
            if(${_/\_/=\_/\/\__/\/})
            {
                return $true
            }
            else
            {
                return $false
            }
         }
         else
         {
            if(${_/\_/=\_/\/\__/\/})
            {
                return $false
            }
            else
            {
                return $true
            }
         }
    }
    [PSObject[]] RetrievePackages($path, $registry)
    {
        ${/==\_/===\/=\/\_/} = @()
        ${___/\_/\_/=\__/\_} = $registry.OpenSubKey($path) 
        ${_/=\/=\_/\_/=\_/\} = ${___/\_/\_/=\__/\_}.GetSubKeyNames() |% {
            ${__/=\__/\____/\_/} = $path + "\\" + $_ 
            ${___/=\___/\_/\/==} = $registry.OpenSubKey(${__/=\__/\____/\_/}) 
            ${_/=\_________/==\} = New-Object PSObject 
            ${_/=\_________/==\} | Add-Member -MemberType NoteProperty -Name "DisplayName" -Value $(${___/=\___/\_/\/==}.GetValue("DisplayName"))
            ${_/=\_________/==\} | Add-Member -MemberType NoteProperty -Name "DisplayVersion" -Value $(${___/=\___/\_/\/==}.GetValue("DisplayVersion"))
            ${_/=\_________/==\} | Add-Member -MemberType NoteProperty -Name "UninstallString" -Value $(${___/=\___/\_/\/==}.GetValue("UninstallString")) 
            ${_/=\_________/==\} | Add-Member -MemberType NoteProperty -Name "Publisher" -Value $(${___/=\___/\_/\/==}.GetValue("Publisher"))            
            ${/==\_/===\/=\/\_/} += ${_/=\_________/==\}      
        }
        return ${/==\_/===\/=\/\_/}
    }
    [PSCustomObject] GetInstalledSoftwares()
    {
        ${_/==\_/==\_/\_/\/} = @{}
        $path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall" 
        ${_____/\/\____/===} = [microsoft.win32.registrykey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry32)
        ${_/=\_/\/===\_____} = [microsoft.win32.registrykey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
        ${/==\_/===\/=\/\_/} = $this.RetrievePackages($path, ${_____/\/\____/===})
        ${/==\_/===\/=\/\_/} += $this.RetrievePackages($path, ${_/=\_/\/===\_____})
        ${/==\_/===\/=\/\_/}.Where({$_.DisplayName}) |% { 
            if(-not(${_/==\_/==\_/\_/\/}.ContainsKey($_.DisplayName)))
            {
                ${_/==\_/==\_/\_/\/}.Add($_.DisplayName, $_) 
            }
        }
        return ${_/==\_/==\_/\_/\/}.Values
    }
}