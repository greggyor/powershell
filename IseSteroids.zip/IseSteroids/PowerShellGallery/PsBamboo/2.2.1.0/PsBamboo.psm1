﻿Set-StrictMode -Version latest
Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABzAEIAYQBtAGIAbwBvACAAbQBvAGQAdQBsAGUA')))

${_/\___/=\__/==\/\} = Join-Path $PSScriptRoot $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgB1AG4AYwB0AGkAbwBuAHMAXAAqAC4AcABzADEA')))
Get-ChildItem -Path ${_/\___/=\__/==\/\} -Recurse | Foreach-Object {
    Write-Verbose "Loading function $($_.Name).."
    . $_.FullName
}

${/===\_/\___/==\/=} = Join-Path $PSScriptRoot $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgB1AG4AYwB0AGkAbwBuAHMAXAAqAC4AZgBvAHIAbQBhAHQALgBwAHMAMQB4AG0AbAA=')))
Get-ChildItem -Path ${/===\_/\___/==\/=} -Recurse | Foreach-Object {
    Write-Verbose "Loading format $($_.Name).."
    Update-formatdata -PrependPath $_.FullName
}

${script:__/==\/\/\/\/==\_} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBsAG8AYwBhAGwAaABvAHMAdAA6ADgAMAA4ADUA')))
${script:/======\/==\/\/=\} = $null
${script:__/\_/=\_/==\/==\} = $null
