﻿

function Get-CertificateHealth
{
    [CmdletBinding()]
    Param
    (
        [Parameter(ValueFromPipelineByPropertyName=$true)]
        [string[]]$Path = 'Cert:\LocalMachine\My',
        [string]$ComputerName,
        [int]$WarningDays = 60,
        [int]$CriticalDays = 30,
        [string[]]$ExcludedThumbprint,
        [string[]]$WarningAlgorithm=($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBoAGEAMQBSAFMAQQA=')))),
        [string[]]$CriticalAlgorithm=($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBkADUAUgBTAEEA')))),
        [int]$CriticalKeySize=1024,
        [int]$WarningKeySize=2048,
        [string]$CertUtilPath = 'C:\Windows\System32\certutil.exe',
        [string[]]$CertificateFileType = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGMAZQByAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAGMAcgB0AA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuAHAANwBiAA==')))),
        [switch]$Recurse = $false
    )

    Begin
    {
    }
    Process
    {
        
        foreach ($CertPath in $Path) {
            
            
            if ($CertPath -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBlAHIAdAA6AFwAKgA=')))) {
                
                
                if ($ComputerName) {
                    
                    try {
                        Write-Verbose "Getting certificates from $CertPath from $ComputerName"
                        $Certificates = Invoke-Command -ScriptBlock {Get-ChildItem -Path $args[0] -Recurse:([bool]$args[1].IsPresent) -Exclude $args[2]} -ComputerName $ComputerName -ArgumentList $CertPath,$Recurse,$ExcludedThumbprint -ErrorAction Stop
                        }
                    catch {
                        Write-Error "Unable to connect to $ComputerName"
                        return
                        }                    
                    }
                
                else {
                    Write-Verbose "Getting certificates from $CertPath"
                    $Certificates = Get-ChildItem -Path $CertPath -Recurse:([bool]$Recurse.IsPresent) -Exclude $ExcludedThumbprint
                    $ComputerName = $env:COMPUTERNAME
                    }
                }
            
            else {
                Write-Verbose "Getting certificates from $CertPath"
                $Certificates = Get-CertificateFile -Path $CertPath -CertificateFileType $CertificateFileType -Recurse:([bool]$Recurse.IsPresent) | Where-Object -FilterScript {$_.Thumbprint -notcontains $ExcludedThumbprint}
                }
            if ($Certificates) {
                
                foreach ($Certificate in $Certificates) {
                                
                    

                    if ($Certificate.PSPath) {
                            if ($PSVersionTable.PSVersion.Major -lt 3) {
                                $CertificateProperties = @{
                                    ComputerName = $ComputerName
                                    FileName = $Certificate.PSPath
                                    Subject = $Certificate.Subject
                                    SignatureAlgorithm = $Certificate.SignatureAlgorithm.FriendlyName
                                    NotBefore = $Certificate.NotBefore
                                    NotAfter = $Certificate.NotAfter
                                    Days = ($Certificate.NotAfter - (Get-Date)).Days
                                    Thumbprint = $Certificate.Thumbprint
                                    KeySize = $Certificate.PublicKey.Key.KeySize
                                    }
                                }
                            else {
                                $CertificateProperties = [ordered]@{
                                    ComputerName = $ComputerName
                                    FileName = $Certificate.PSPath
                                    Subject = $Certificate.Subject
                                    SignatureAlgorithm = $Certificate.SignatureAlgorithm.FriendlyName
                                    NotBefore = $Certificate.NotBefore
                                    NotAfter = $Certificate.NotAfter
                                    Days = ($Certificate.NotAfter - (Get-Date)).Days
                                    Thumbprint = $Certificate.Thumbprint
                                    KeySize = $Certificate.PublicKey.Key.KeySize
                                    }
                                }
                            $Certificate = New-Object -TypeName PSObject -Property $CertificateProperties
                            }
                        elseif ($Certificate.FileName) {
                            
                            }
                        else {
                            
                            }
                    
                    
                    
                    if ($Certificate.NotAfter -le (Get-Date).AddDays($WarningDays) -and $Certificate.NotAfter -gt (Get-Date).AddDays($CriticalDays)) {
                        Write-Verbose "Certificate is expiring within $WarningDays days."
                        $ValidityPeriodStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwA=')))
                        $ValidityPeriodStatusMessage = "Certificate expiring in $($Certificate.Days) days."
                        }
                    
                    elseif ($Certificate.NotAfter -le (Get-Date).AddDays($CriticalDays) -and $Certificate.NotAfter -gt (Get-Date)) {
                        Write-Verbose "Certificate is expiring within $CriticalDays days."
                        $ValidityPeriodStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGkAdABpAGMAYQBsAA==')))
                        $ValidityPeriodStatusMessage = "Certificate expiring in $($Certificate.Days) days."
                        }
                    
                    elseif ($Certificate.NotAfter -le (Get-Date)) {
                        Write-Verbose "Certificate is expiring within $CriticalDays"
                        $ValidityPeriodStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGkAdABpAGMAYQBsAA==')))
                        $ValidityPeriodStatusMessage = "Certificate expired: $($Certificate.Days) days."
                        }
                    
                    else {
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAaQBzACAAdwBpAHQAaABpAG4AIAB2AGEAbABpAGQAaQB0AHkAIABwAGUAcgBpAG8AZAAuAA==')))
                        $ValidityPeriodStatus = 'OK'
                        $ValidityPeriodStatusMessage = "Certificate expires in $($Certificate.Days) days."
                        }
                    

                    
                    if ($CriticalAlgorithm -contains $Certificate.SignatureAlgorithm) {
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAdQBzAGUAcwAgAGMAcgBpAHQAaQBjAGEAbAAgAGEAbABnAG8AcgBpAHQAaABtAC4A')))
                        $AlgorithmStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGkAdABpAGMAYQBsAA==')))
                        $AlgorithmStatusMessage = "Certificate uses a vulnerable algorithm $($Certificate.SignatureAlgorithm)."
                        }
                    elseif ($WarningAlgorithm -contains $Certificate.SignatureAlgorithm) {
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAdQBzAGUAcwAgAHcAYQByAG4AaQBuAGcAIABhAGwAZwBvAHIAaQB0AGgAbQAuAA==')))
                        $AlgorithmStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwA=')))
                        $AlgorithmStatusMessage = "Certificate uses the deprecated algorithm $($Certificate.SignatureAlgorithm)."
                        }
                    else {
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAdQBzAGUAcwAgAGEAYwBjAGUAcAB0AGEAYgBsAGUAIABhAGwAZwBvAHIAaQB0AGgAbQAuAA==')))
                        $AlgorithmStatus = 'OK'
                        $AlgorithmStatusMessage = "Certificate uses valid algorithm $($Certificate.SignatureAlgorithm)."
                        }
                    

                    
                    Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGkAbgBnACAAbQBpAG4AaQBtAHUAbQAgAGsAZQB5ACAAbABlAG4AZwB0AGgALgA=')))
                    if ($Certificate.KeySize -lt $CriticalKeySize) {
                        
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAawBlAHkAIABsAGUAbgBnAHQAaAAgAGkAcwAgAGMAcgBpAHQAaQBjAGEAbAAuAA==')))
                        $KeySizeStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGkAdABpAGMAYQBsAA==')))
                        $KeySizeStatusMessage = "Certificate key size $($Certificate.KeySize) is less than $CriticalKeySize."
                        }
                    elseif ($Certificate.KeySize -lt $WarningKeySize -and $Certificate.KeySize -ge $CriticalKeySize) {
                        
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAawBlAHkAIABsAGUAbgBnAHQAaAAgAGkAcwAgAHcAYQByAG4AaQBuAGcALgA=')))
                        $KeySizeStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAHIAbgBpAG4AZwA=')))
                        $KeySizeStatusMessage = "Certificate key size $($Certificate.KeySize) is less than $WarningKeySize."
                        }
                    elseif ($Certificate.KeySize -ge $WarningKeySize) {
                        
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAawBlAHkAIABsAGUAbgBnAHQAaAAgAGkAcwAgAE8ASwAuAA==')))
                        $KeySizeStatus = 'OK'
                        $KeySizeStatusMessage = "Certificate key size $($Certificate.KeySize) is greater than or equal to $WarningKeySize."
                        }
                    else {
                        
                        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAawBlAHkAIABsAGUAbgBnAHQAaAAgAGkAcwAgAFUAbgBrAG4AbwB3AG4ALgA=')))
                        $KeySizeStatus = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGsAbgBvAHcAbgA=')))
                        $KeySizeStatusMessage = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAHIAdABpAGYAaQBjAGEAdABlACAAawBlAHkAIABzAGkAegBlACAAaQBzACAAdQBuAGsAbgBvAHcAbgAuAA==')))
                        }
                    

                    Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAaQBuAGcAIABhAGQAZABpAHQAaQBvAG4AYQBsACAAcAByAG8AcABlAHIAdABpAGUAcwAgAHQAbwAgAHQAaABlACAAYwBlAHIAdABpAGYAaQBjAGEAdABlACAAbwBiAGoAZQBjAHQALgA=')))
                    if ($PSVersionTable.PSVersion.Major -lt 3) {
                        $CertificateProperties = @{
                            ComputerName = $ComputerName
                            FileName = $Certificate.Filename
                            Subject = $Certificate.Subject
                            SignatureAlgorithm = $Certificate.SignatureAlgorithm
                            NotBefore = $Certificate.NotBefore
                            NotAfter = $Certificate.NotAfter
                            Days = $Certificate.Days
                            Thumbprint = $Certificate.Thumbprint
                            ValidityPeriodStatus = $ValidityPeriodStatus
                            ValidityPeriodStatusMessage = $ValidityPeriodStatusMessage
                            AlgorithmStatus = $AlgorithmStatus
                            AlgorithmStatusMessage = $AlgorithmStatusMessage
                            KeySize = $Certificate.KeySize
                            KeySizeStatus = $KeySizeStatus
                            KeySizeStatusMessage = $KeySizeStatusMessage
                            }
                        }
                    else {
                        $CertificateProperties = [ordered]@{
                            ComputerName = $ComputerName
                            FileName = $Certificate.Filename
                            Subject = $Certificate.Subject
                            SignatureAlgorithm = $Certificate.SignatureAlgorithm
                            NotBefore = $Certificate.NotBefore
                            NotAfter = $Certificate.NotAfter
                            Days = $Certificate.Days
                            Thumbprint = $Certificate.Thumbprint
                            ValidityPeriodStatus = $ValidityPeriodStatus
                            ValidityPeriodStatusMessage = $ValidityPeriodStatusMessage
                            AlgorithmStatus = $AlgorithmStatus
                            AlgorithmStatusMessage = $AlgorithmStatusMessage
                            KeySize = $Certificate.KeySize
                            KeySizeStatus = $KeySizeStatus
                            KeySizeStatusMessage = $KeySizeStatusMessage
                            }
                        }
                    
                    $Certificate = New-Object -TypeName PSObject -Property $CertificateProperties
                    if ($PSVersionTable.PSVersion.Major -lt 3) {
                        $Certificate | Select-Object ComputerName,FileName,Subject,SignatureAlgorithm,NotBefore,NotAfter,Days,Thumbprint,ValidityPeriodStatus,ValidityPeriodStatusMessage,AlgorithmStatus,AlgorithmStatusMessage,KeySize,KeySizeStatus,KeySizeStatusMessage
                        }
                    else {
                        $Certificate
                        }
                    }
                
                }
            else {
                Write-Verbose "No Certificates found in $CertPath"
                }
            }
        
    }
    End
    {
    }
}