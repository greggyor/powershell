﻿<#
.Synopsis
   Gets object properties from a Delta File 
.DESCRIPTION
   Get-NAVApplicationObject alternative for DELTA files.
.EXAMPLE
   
.EXAMPLE
   $NAVObjects = get-item $Deltafiles | Get-NAVApplicationObjectPropertyFromDelta

#>
function Get-NAVApplicationObjectPropertyFromDelta
{
    param 
    (
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [Alias('Fullname')] 
        $Source
    )
    Process
    {
        Get-Item $Source | foreach {
            ${_/==\__/==\/\/==\} = Get-NAVApplicationObjectProperty -Source $_.Fullname
            if (${_/==\__/==\/\/==\}.Count -gt 1) {
                write-error "File $($_.Fullname) contains multiple objects, which is not supported by this function"
                break
            }
            ${/=\/\/\___/\/===\} = New-Object PSObject
            ${_/==\__/==\/\/==\} | Get-Member -MemberType Properties | foreach {
                ${/=\/\/\___/\/===\} | Add-Member -MemberType NoteProperty -Name $_.Name -Value ${_/==\__/==\/\/==\}."$($_.name)"        
            }
            IF (${/=\/\/\___/\/===\}.ObjectType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAaQBmAGkAYwBhAHQAaQBvAG4A')))) {
                ${_/\/\__/\/\_/=\_/} = (Get-Content $_)[0]
                ${_/\/=\/=\_/\/====} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgArAFwAKAAoAFwAdwArACkAIAAoAFwAZAArACkAXAApAA==')))
                ${/==\_/==\/=\/\/\_} = [regex]::Match(${_/\/\__/\/\_/=\_/}, ${_/\/=\/=\_/\/====})
                ${/=\/\/\___/\/===\}.ObjectType = ${/==\_/==\/=\/\/\_}.Groups.Item(1).value
                ${/=\/\/\___/\/===\}.Id = [int] ${/==\_/==\/=\/\/\_}.Groups.Item(2).value
            }
            return ${/=\/\/\___/\/===\}
        }
    }
}