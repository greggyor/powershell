﻿
Function Start-Parallel {
    [CmdletBinding(DefaultParameterSetName='Command')]
    Param  (
          [parameter(Mandatory=$true,ParameterSetName="Command",HelpMessage="Enter the command to process",Position=0)]
          $Command , 
          [parameter(Mandatory=$true,ParameterSetName="Block")]
          $Scriptblock,
          $TaskDisplayName = "Tasks", 
          [Parameter(ValueFromPipeline=$true)]$InputObject,
          [int]$MaxThreads           = 50,
          [int]$MilliSecondsDelay    = 200,
          [int]$MaxRunSeconds        = 300
    )
    Begin  { 
        Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAdABpAG4AZwAgAHUAcAAgACQAVABhAHMAawBEAGkAcwBwAGwAYQB5AE4AYQBtAGUA')))  -Status "Initializing"    
        if ($PSCmdlet.ParameterSetName -eq "Command") {
            try   { $Command = gcm -Name  $Command  }
            catch { Throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbQBtAGEAbgBkACAAZABvAGUAcwAgAG4AbwB0ACAAYQBwAHAAZQBhAHIAIAB0AG8AIABiAGUAIABhACAAdgBhAGwAaQBkACAAYwBvAG0AbQBhAG4AZAAuAA==')))}
        }
        else {  if ($Scriptblock -isnot [scriptblock] -and   (Test-Path -Path  $Scriptblock) )  {
                    $ScriptBlock      = [scriptblock]::create((gi -Path  $Scriptblock).OpenText().ReadToEnd()) }
                if ($Scriptblock -isnot [scriptblock]) {Throw "Invalid Scriptblock"}          
        }
        ${__/=\____/\___/\_}     = @()
        ${__/\_/===\___/===} = [runspacefactory]::CreateRunspacePool(1, $MaxThreads)
        ${__/\_/===\___/===}.Open()
        Write-Verbose -Message ("Runspace pool opened at " + ([datetime]::Now).ToString("HH:mm:ss.ffff"))
    }
    Process{ 
         ForEach  (${___/\_/==\/\__/=\} in $InputObject)  { 
            if    ($ScriptBlock )            { ${__/\_/===\_/\_/\_} = [powershell]::Create().AddScript($ScriptBlock)  }
            else                             { ${__/\_/===\_/\_/\_} = [powershell]::Create().AddCommand($Command)     } 
            if      (${___/\_/==\/\__/=\} -is [Int] -or
                     ${___/\_/==\/\__/=\} -is [string]   ) { ${__/\_/===\_/\_/\_}.AddArgument(${___/\_/==\/\__/=\})             | Out-Null  }
            elseif  (${___/\_/==\/\__/=\} -is [hashtable]) {
                ForEach (${_/\_____/==\/\/\_} in ${___/\_/==\/\__/=\}.Keys){ ${__/\_/===\_/\_/\_}.AddParameter(${_/\_____/==\/\/\_}, ${___/\_/==\/\__/=\}.${_/\_____/==\/\/\_}) | Out-Null  }
            }
            elseif  (${___/\_/==\/\__/=\} -is [psobject])  {
                Foreach (${_/\_____/==\/\/\_} in (gm -InputObject ${___/\_/==\/\__/=\} -MemberType NoteProperty).Name) {
                                                ${__/\_/===\_/\_/\_}.AddParameter(${_/\_____/==\/\/\_}, ${___/\_/==\/\__/=\}.${_/\_____/==\/\/\_}) | Out-Null 
                }
            }
            ${__/\_/===\_/\_/\_}.RunspacePool = ${__/\_/===\___/===}
            ${_/==\/=\/\_/\/===}                 = ${__/\_/===\_/\_/\_}.BeginInvoke()
            ${__/=\____/\___/\_}              += New-Object -TypeName psobject -Property @{"Handle"=${_/==\/=\/\_/\/===}; "Thread"=${__/\_/===\_/\_/\_};}
            Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAdABpAG4AZwAgAHUAcAAgACQAVABhAHMAawBEAGkAcwBwAGwAYQB5AE4AYQBtAGUA')))  -Status ("Created: " + ${__/=\____/\___/\_}.Count + " tasks" )
        }
        ${__/=\____/\___/\_} | ? {$_.Handle.IsCompleted } | % {
                $_.Thread.EndInvoke($_.Handle)
                $_.Thread.Dispose()
                $_.Thread = $_.Handle = $Null
        }
    }
    End    {
        Write-Verbose  -Message ("Last of $(${__/=\____/\___/\_}.count) threads started: " + ([datetime]::Now).ToString("HH:mm:ss.ffff"))
        Write-Verbose  -Message ("Waiting for " + ${__/=\____/\___/\_}.where({ $_.Handle.IsCompleted -eq $false}).count.tostring()  + " to complete.") 
        Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAdABpAG4AZwAgAHUAcAAgACQAVABhAHMAawBEAGkAcwBwAGwAYQB5AE4AYQBtAGUA')))  -Completed
        ${__/\_/\__/\___/==} = (Get-Date).AddSeconds($MaxRunSeconds) 
        While (${__/=\____/\___/\_}.where({$_.Handle}) -and (Get-Date) -lt ${__/\_/\__/\___/==})  {
            ${/==\/======\__/\_} = ${__/=\____/\___/\_}.where({ $_.Handle.IsCompleted -eq $false}).count
            Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAJABUAGEAcwBrAEQAaQBzAHAAbABhAHkATgBhAG0AZQAgAHQAbwAgAGMAbwBtAHAAbABlAHQAZQA='))) -Status $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AC8APQA9AFwALwA9AD0APQA9AD0APQBcAF8AXwAvAFwAXwB9ACAAdABhAHMAawBzACAAcgBlAG0AYQBpAG4AaQBuAGcA'))) -PercentComplete (100 * (${__/=\____/\___/\_}.count - ${/==\/======\__/\_})  / ${__/=\____/\___/\_}.Count) 
            ${__/=\____/\___/\_} | ? {$_.Handle.IsCompleted } | % {
                $_.Thread.EndInvoke($_.Handle)
                $_.Thread.Dispose()
                $_.Thread = $_.Handle = $Null
            }
            sleep -Milliseconds $MilliSecondsDelay        
        } 
        Write-Verbose -Message ("Wait for threads ended at " + ([datetime]::Now).ToString("HH:mm:ss.ffff"))
        Write-Verbose -Message ("Leaving " + ${__/=\____/\___/\_}.where({ $_.Handle.IsCompleted -eq $false}).count + " incomplete.")
        Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAJABUAGEAcwBrAEQAaQBzAHAAbABhAHkATgBhAG0AZQAgAHQAbwAgAGMAbwBtAHAAbABlAHQAZQA='))) -Completed
        [void]${__/\_/===\___/===}.Close()   
        [void]${__/\_/===\___/===}.Dispose() 
        [gc]::Collect()
   } 
}
