﻿function Add-TypeData
{
    
    [OutputType([Nullable],[PSModuleInfo])]
    param(
    
    
    [Parameter(Mandatory=$true,
        ValueFromPipeline=$true)]
    [ValidateScript({
        if ((-not $_.Types)) {
            throw "The root of a types XML most be a types element"
        }
        return $true
    })]
    [Xml]
    $TypeXml,
    
    
    
    
    [string]
    $Name,
    
    
    [Switch]
    $PassThru
    )    
    
    begin {        
        
        $typeFiles = @()
    }
    
    process {
        
        $tempFile = Join-Path $env:Temp ([IO.Path]::GetRandomFileName())
        $typeFileName = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AHQAZQBtAHAARgBpAGwAZQB9AC4AVAB5AHAAZQAuAHAAcwAxAHgAbQBsAA==')))
        $TypeXml.Save($typeFileName)        
        $typeFiles += (Get-Item $typeFileName).Name
        
    }
    
    end {     
        
        if (-not $name) { 
            $typeName = $TypeXml.SelectSingleNode("//Name")
            if ($typeName) {
                $name = $typeName.'#text'
            } else {
                $name = "TypeModule$($TypeModules.Count + 1)"
            }
            
        }

        $Name = $Name.Replace("#","").Replace("\","").Replace("/","")                
        
        $tempFile = Join-Path $env:Temp $name
        $tempFile = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AHQAZQBtAHAARgBpAGwAZQB9AC4AcABzAGQAMQA=')))
        Get-Module $name -ErrorAction SilentlyContinue | 
            Remove-Module
        $ModuleManifestParameters = @{
            FormatsToProcess = @()
            NestedModules = @()
            Author = $env:UserName
            CompanyName = ""
            Copyright = Get-Date
            ModuleToProcess =  ""
            RequiredModules = @()
            Description = ""
            RequiredAssemblies = @()
            TypesToProcess = $TypeFiles
            FileList = $TypeFiles
            Path = $tempFile
        }
        New-ModuleManifest @ModuleManifestParameters
        $script:TypeModules.Values | Import-Module -Force
        $module = Import-Module $tempFile -Force -PassThru           
        $script:TypeModules[$name] = $module        
        if ($passThru) { $module }
        
        
    }
}
