﻿
function Install-LabSqlServers
{
    [cmdletBinding()]
    param (
        [int]$InstallationTimeout = $PSCmdlet.MyInvocation.MyCommand.Module.PrivateData.Timeout_Sql2012Installation,
        [switch]$CreateCheckPoints
    )
    function Write-ArgumentVerbose
    {
        param
        (
            ${f1}
        )
        Write-ScreenInfo -Type Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAGcAdQBtAGUAbgB0ACAAJwAkAHsAZgAxAH0AJwA=')))
        ${f1}
    }
    Write-LogFunctionEntry
    ${21} = Get-Lab -ErrorAction SilentlyContinue
    if (-not ${21})
    {
        Write-LogFunctionExitWithError -Message 'No lab definition imported, so there is nothing to do. Please use the Import-Lab cmdlet first'
        return
    }
    ${1} = Get-LabMachine -Role SQLServer2008, SQLServer2008R2, SQLServer2012, SQLServer2014, SQLServer2016
    ${23} = ${1} | Where-Object HostType -eq Azure
    if (${23})
    {
        Write-ScreenInfo -Message 'Waiting for machines to start up'
        Start-LabVM -ComputerName ${23} -Wait -ProgressIndicator 2
        Enable-LabVMRemoting -ComputerName ${23}
        Write-ScreenInfo -Message "Configuring Azure SQL Servers '$(${23} -join ', ')'"
        foreach (${15} in ${23})
        {            
            Write-ScreenInfo -Type Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGkAbgBnACAAQQB6AHUAcgBlACAAUwBRAEwAIABTAGUAcgB2AGUAcgAgACcAJAB7ADEANQB9ACcA')))
            Write-ScreenInfo -Message (Get-Date)
            ${24} = {
                ${25} = @"
USE [master]
GO

CREATE LOGIN [BUILTIN\Administrators] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

-- ALTER SERVER ROLE [sysadmin] ADD MEMBER [BUILTIN\Administrators]
-- The folloing statement works in SQL 2008 to 2016
EXEC master..sp_addsrvrolemember @loginame = N'BUILTIN\Administrators', @rolename = N'sysadmin'
GO
"@
                if ((Get-PSSnapin -Registered -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue) -and -not (Get-PSSnapin -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue)) {
                    Add-PSSnapin -Name SqlServerCmdletSnapin100
                }
                Invoke-Sqlcmd -Query ${25}
            }
            Invoke-LabCommand -ComputerName ${15} -ActivityName SetupSqlPermissions -ScriptBlock ${24} -UseLocalCredential
        }
        Write-ScreenInfo -Type Verbose -Message "Finished configuring Azure SQL Servers '$(${23} -join ', ')'"
    }
    ${2} = @(${1} | Where-Object HostType -eq HyperV)
    if (${2})
    {
        if ((Get-LabMachine -Role SQLServer2008) -and -not (${21}.Sources.ISOs | Where-Object { $_.Name -eq 'SQLServer2008' }))
        {
            Write-LogFunctionExitWithError -Message "There is no ISO image available to install the role 'SQLServer2008'. Please add the required ISO to the lab and name it (warning: CaseSensitive) 'SQLServer2008'"
            return
        }
        if ((Get-LabMachine -Role SQLServer2008R2) -and -not (${21}.Sources.ISOs | Where-Object { $_.Name -eq 'SQLServer2008R2' }))
        {
            Write-LogFunctionExitWithError -Message "There is no ISO image available to install the role 'SQLServer2008R2'. Please add the required ISO to the lab and name it (warning: CaseSensitive) 'SQLServer2008R2'"
            return
        }
        if ((Get-LabMachine -Role SQLServer2012) -and -not (${21}.Sources.ISOs | Where-Object { $_.Name -eq 'SQLServer2012' }))
        {
            Write-LogFunctionExitWithError -Message "There is no ISO image available to install the role 'SQLServer2012'. Please add the required ISO to the lab and name it (warning: CaseSensitive) 'SQLServer2012'"
            return
        }
        if ((Get-LabMachine -Role SQLServer2014) -and -not (${21}.Sources.ISOs | Where-Object { $_.Name -eq 'SQLServer2014' }))
        {
            Write-LogFunctionExitWithError -Message "There is no ISO image available to install the role 'SQLServer2014'. Please add the required ISO to the lab and name it (warning: CaseSensitive) 'SQLServer2014'"
            return
        }
        ${22} = 4
        Write-ScreenInfo -Type Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHIAYQBsAGwAZQBsACAAaQBuAHMAdABhAGwAbABzADoAIAAkAHsAMgAyAH0A')))
        ${4} = 0
        ${7} = 0
        ${6} = [math]::Ceiling(${2}.count / ${22})
        do
        {
            ${12} = @()
            ${7}++
            ${5} = $(${2}[${4}..(${4} + ${22} - 1)])
            Write-ScreenInfo -Message "Starting machines '$(${5} -join ', ')'"
            Start-LabVM -ComputerName ${5}
            ${8} = @()
            foreach (${9} in ${5})
            {
                Write-ScreenInfo -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAbQBhAGMAaABpAG4AZQAgACcAJAB7ADkAfQAnACAAdABvACAAYgBlACAAcgBlAGEAZAB5AA=='))) -NoNewLine -Type Info
                Wait-LabVM -ComputerName ${9} -ProgressIndicator 30
                Write-ScreenInfo -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAaQBuAHMAdABhAGwAbABhAHQAaQBvAG4AIABvAGYAIABwAHIAZQAtAHIAZQBxAHUAaQBzAGkAdABlACAALgBOAGUAdAAgADMALgA1ACAARgByAGEAbQBlAHcAbwByAGsAIABvAG4AIABtAGEAYwBoAGkAbgBlACAAJwAkAHsAOQB9ACcA'))) -Type Info
                ${8} = Install-LabWindowsFeature -ComputerName ${9} -FeatureName Net-Framework-Core -NoDisplay -AsJob -PassThru                
            }
            Write-ScreenInfo -Message "Waiting for pre-requisite .Net 3.5 Framework to finish installation on machines '$(${5} -join ', ')'" -NoNewLine
            Wait-LWLabJob -Job ${8} -Timeout 10 -NoDisplay -ProgressIndicator 45
            foreach (${15} in ${5})
            {
                ${18} = ${15}.Roles | Where-Object Name -like SQLServer*
                Dismount-LabIsoImage -ComputerName ${15} -SupressOutput
                Mount-LabIsoImage -ComputerName ${15} -IsoPath (${21}.Sources.ISOs | Where-Object Name -eq ${18}.Name).Path -SupressOutput
                ${global:16} = ' /Q /Action=Install /IndicateProgress'
                ?? { ${18}.Properties.ContainsKey('Features') } `
                { ${global:16} += Write-ArgumentVerbose -f1 " /Features=$(${18}.Properties.Features.Replace(' ', ''))" } `
                { ${global:16} += Write-ArgumentVerbose -f1 ' /Features=SQL,AS,RS,IS,Tools' }
                ?? { ${18}.Properties.ContainsKey('InstanceName') } `
                { 
                    ${global:16} += Write-ArgumentVerbose -f1 " /InstanceName=$(${18}.Properties.InstanceName)"
                    ${script:19} = ${18}.Properties.InstanceName
                } `
                { 
                    ${global:16} += Write-ArgumentVerbose -f1 ' /InstanceName=MSSQLSERVER' 
                    ${script:19} = 'MSSQLSERVER'
                }
                ${20} = Invoke-LabCommand -ComputerName ${15} -ScriptBlock {
                    Get-Service -DisplayName $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBRAEwAIABTAGUAcgB2AGUAcgAgACgAJAB7ADEAOQB9ACkA'))) -ErrorAction SilentlyContinue
                } -Variable (Get-Variable -Name instanceName) -PassThru -NoDisplay
                if (${20})
                {
                    Write-ScreenInfo -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGMAaABpAG4AZQAgACcAJAB7ADEANQB9ACcAIABhAGwAcgBlAGEAZAB5ACAAaABhAHMAIABTAFEATAAgAFMAZQByAHYAZQByACAAaQBuAHMAdABhAGwAbABlAGQAIAB3AGkAdABoACAAcgBlAHEAdQBlAHMAdABlAGQAIABpAG4AcwB0AGEAbgBjAGUAIABuAGEAbQBlACAAJwAkAHsAMQA5AH0AJwA='))) -Type Warning
                    continue
                }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('Collation')}             { ${global:16} += Write-ArgumentVerbose -f1 (" /SQLCollation=" +          "$(${18}.Properties.Collation)") }             { ${global:16} += Write-ArgumentVerbose -f1 ' /SQLCollation=Latin1_General_CI_AS' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('SQLSvcAccount')}         { ${global:16} += Write-ArgumentVerbose -f1 (" /SQLSvcAccount=" +       """$(${18}.Properties.SQLSvcAccount)""") }       { ${global:16} += Write-ArgumentVerbose -f1 ' /SQLSvcAccount="NT Authority\Network Service"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('SQLSvcPassword')}        { ${global:16} += Write-ArgumentVerbose -f1 (" /SQLSvcPassword=" +      """$(${18}.Properties.SQLSvcPassword)""") }      { }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('AgtSvcAccount')}         { ${global:16} += Write-ArgumentVerbose -f1 (" /AgtSvcAccount=" +       """$(${18}.Properties.AgtSvcAccount)""") }       { ${global:16} += Write-ArgumentVerbose -f1 ' /AgtSvcAccount="NT Authority\System"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('AgtSvcPassword')}        { ${global:16} += Write-ArgumentVerbose -f1 (" /AgtSvcPassword=" +      """$(${18}.Properties.AgtSvcPassword)""") }      { }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('RsSvcAccount')}          { ${global:16} += Write-ArgumentVerbose -f1 (" /RsSvcAccount=" +        """$(${18}.Properties.RsSvcAccount)""") }        { ${global:16} += Write-ArgumentVerbose -f1 ' /RsSvcAccount="NT Authority\Network Service"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('AgtSvcStartupType')}     { ${global:16} += Write-ArgumentVerbose -f1 (" /AgtSvcStartupType=" +     "$(${18}.Properties.AgtSvcStartupType)") }     { ${global:16} += Write-ArgumentVerbose -f1 ' /AgtSvcStartupType=Disabled' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('BrowserSvcStartupType')} { ${global:16} += Write-ArgumentVerbose -f1 (" /BrowserSvcStartupType=" + "$(${18}.Properties.BrowserSvcStartupType)") } { ${global:16} += Write-ArgumentVerbose -f1 ' /BrowserSvcStartupType=Disabled' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('RsSvcStartupType')}      { ${global:16} += Write-ArgumentVerbose -f1 (" /RsSvcStartupType=" +      "$(${18}.Properties.RsSvcStartupType)") }      { ${global:16} += Write-ArgumentVerbose -f1 ' /RsSvcStartupType=Automatic' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('AsSysAdminAccounts')}    { ${global:16} += Write-ArgumentVerbose -f1 (" /AsSysAdminAccounts=" +    "$(${18}.Properties.AsSysAdminAccounts)") }    { ${global:16} += Write-ArgumentVerbose -f1 ' /AsSysAdminAccounts="BUILTIN\Administrators"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('AsSvcAccount')}          { ${global:16} += Write-ArgumentVerbose -f1 (" /AsSvcAccount=" +          "$(${18}.Properties.AsSvcAccount)") }          { ${global:16} += Write-ArgumentVerbose -f1 ' /AsSvcAccount="NT Authority\System"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('IsSvcAccount')}          { ${global:16} += Write-ArgumentVerbose -f1 (" /IsSvcAccount=" +          "$(${18}.Properties.IsSvcAccount)") }          { ${global:16} += Write-ArgumentVerbose -f1 ' /IsSvcAccount="NT Authority\System"' }
                Invoke-Ternary -Decider {${18}.Properties.ContainsKey('SQLSysAdminAccounts')}   { ${global:16} += Write-ArgumentVerbose -f1 (" /SQLSysAdminAccounts=" +   "$(${18}.Properties.SQLSysAdminAccounts)") }   { ${global:16} += Write-ArgumentVerbose -f1 ' /SQLSysAdminAccounts="BUILTIN\Administrators"' }
                Invoke-Ternary -Decider {${15}.roles.name -notcontains 'SQLServer2008'}      { ${global:16} += Write-ArgumentVerbose -f1 (' /IAcceptSQLServerLicenseTerms') }                                         { }
                ${14} = {                    
                    Write-Verbose 'Installing SQL Server...'
                    ${17} = ''
                    ${10} = (Get-Date)
                    while (-not ${17} -and ((${10}).AddSeconds(120) -gt (Get-Date)))
                    {
                        Start-Sleep -Seconds 2
                        ${17} = (Get-WmiObject -Class Win32_CDRomDrive).Drive
                    }
                    if (${17})
                    {
                        New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags' -Name '{f2d3ae3a-bfcc-45e2-bf63-178d1db34294}' -Value 4 -PropertyType 'DWORD'
                        New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags' -Name '{45da5a8b-67b5-4896-86b7-a2e838aee035}' -Value 4 -PropertyType 'DWORD'
                        Set-Content -Path C:\InstallSQLServer.cmd -Value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEANwB9AFwAUwBlAHQAdQBwAC4AZQB4AGUAJAB7ADEANgB9AA==')))
                        schtasks.exe /Create /SC ONLOGON /TN InstallSQLServer /TR "cmd /c c:\InstallSQLServer.cmd"
                        schtasks.exe /Run /I /TN "InstallSQLServer"
                        while (schtasks.exe /Query /TN "InstallSQLServer" | Where-Object { $_ -like '*InstallSQLServer*' -and $_ -notlike '*Running*' })
                        {
                            Start-Sleep -Seconds 1
                        }
                        while (schtasks.exe /Query /TN "InstallSQLServer" | Where-Object { $_ -like '*InstallSQLServer*' -and $_ -like '*Running*' })
                        {
                            Start-Sleep -Seconds 5
                        }
                        schtasks.exe /Delete /TN "InstallSQLServer" /F
                        if (-not (Test-Path -Path C:\DeployDebug))
                        {
                            New-Item -ItemType Directory -Path C:\DeployDebug | Out-Null
                        }
                        Move-Item -Path c:\InstallSQLServer.cmd -Destination C:\DeployDebug
                        Write-Verbose 'SQL Installation finished. Restarting machine.'
                        Restart-Computer -Force
                    }
                    else
                    {
                        Write-Error -Message 'Setup.exe in ISO file could not be found (or ISO was not successfully mounted)'
                    }
                }
                ${13} = @{}
                ${13}.Add('ComputerName', ${15})
                ${13}.Add('UseCredSSP', $true)
                ${13}.Add('ActivityName', 'Install SQL Server')
                ${13}.Add('AsJob', $True)
                ${13}.Add('PassThru', $True)
                ${13}.Add('NoDisplay', $True)
                ${13}.Add('Scriptblock', ${14})
                ${13}.Add('Variable', (Get-Variable -Name setupArguments))
                ${12} += Invoke-LabCommand @13
                ${4}++
            }
            if (${12})
            {
                Write-ScreenInfo -Type Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgACQASQBuAHMAdABhAGwAbABhAHQAaQBvAG4AVABpAG0AZQBvAHUAdAAgAG0AaQBuAHUAdABlAHMAIAB1AG4AdABpAGwAIAB0AGgAZQAgAGkAbgBzAHQAYQBsAGwAYQB0AGkAbwBuACAAaQBzACAAZgBpAG4AaQBzAGgAZQBkAA==')))
                Write-ScreenInfo -Message "Waiting for installation of SQL server to complete on machines '$(${5} -join ', ')'" -NoNewline
                ${10} = Get-Date
                ${11} = Get-LabMachine -Role SQLServer2008, SQLServer2008R2, SQLServer2012, SQLServer2014 |
                Where-Object { (Get-LabVMStatus -ComputerName $_.Name) -eq 'Stopped' }
                if (${11})
                {
                    Write-Verbose -Message 'Preparing more machines while waiting for installation to finish'
                    ${3} = Get-LabMachine -Role SQLServer2008, SQLServer2008R2, SQLServer2012, SQLServer2014 |
                    Where-Object { (Get-LabVMStatus -ComputerName $_) -eq 'Stopped' } |
                    Select-Object -First 2
                    while (${10}.AddMinutes(5) -gt (Get-Date) -and ${3})
                    {
                        Write-Verbose -Message "Starting machines '$(${3} -join ', ')'"
                        Start-LabVM -ComputerName ${3}
                        ${8} = @()
                        foreach (${9} in ${3})
                        {
                            Write-Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBhAGkAdABpAG4AZwAgAGYAbwByACAAbQBhAGMAaABpAG4AZQAgACcAJAB7ADkAfQAnACAAdABvACAAYgBlACAAcgBlAGEAZAB5AA==')))
                            Wait-LabVM -ComputerName ${9} -ProgressIndicator 120 -NoNewLine
                            Write-Verbose -Message $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0AGkAbgBnACAAaQBuAHMAdABhAGwAbABhAHQAaQBvAG4AIABvAGYAIABwAHIAZQAtAHIAZQBxAHUAaQBzAGkAdABlACAALgBOAGUAdAAgADMALgA1ACAARgByAGEAbQBlAHcAbwByAGsAIABvAG4AIABtAGEAYwBoAGkAbgBlACAAJwAkAHsAOQB9ACcA')))
                            ${8} = Install-LabWindowsFeature -ComputerName ${9} -FeatureName Net-Framework-Core -NoDisplay -AsJob -PassThru
                        }
                        Write-Verbose -Message "Waiting for machines '$(${3} -join ', ')' to be finish installation of pre-requisite .Net 3.5 Framework"
                        Wait-LWLabJob -Job ${8} -Timeout 10 -NoDisplay -ProgressIndicator 120 -NoNewLine
                        ${3} = Get-LabMachine -Role SQLServer2008, SQLServer2008R2, SQLServer2012, SQLServer2014 | Where-Object { (Get-LabVMStatus -ComputerName $_.Name) -eq 'Stopped' } | Select-Object -First 2
                    }
                    Write-Verbose -Message "Resuming waiting for SQL Servers batch ($(${5} -join ', ')) to complete installation and restart"
                }
                Wait-LabVMRestart -ComputerName ${5} -TimeoutInMinutes $InstallationTimeout -ProgressIndicator 120
                Wait-LabVM -ComputerName ${5} -PostDelaySeconds 30
                Dismount-LabIsoImage -ComputerName ${5} -SupressOutput
                if (${7} -lt ${6})
                {
                    Write-ScreenInfo -Message "Saving machines '$(${5} -join ', ')' as these are not needed right now" -Type Warning
                    Save-VM -Name ${5}
                }
            }    
        }
        until (${4} -ge ${2}.Count)
        ${3} = Get-LabMachine -Role SQLServer2008, SQLServer2008R2, SQLServer2012, SQLServer2014
        ${3} = ${3} | Where-Object { (Get-LabVMStatus -ComputerName $_) -ne 'Started' }
        if (${3})
        {
            Start-LabVM -ComputerName ${3} -Wait
        }
        Write-ScreenInfo -Message "All SQL Servers '$(${2} -join ', ')' have now been installed and restarted. Waiting for these to be ready." -NoNewline
        Wait-LabVM -ComputerName ${2} -TimeoutInMinutes 30 -ProgressIndicator 10
        if ($CreateCheckPoints)
        {
            Checkpoint-LabVM -ComputerName ${1} -SnapshotName 'Post SQL Server Installation'
        }
    }
    Write-LogFunctionExit
}
