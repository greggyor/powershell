﻿function ConvertFrom-InlinePowerShell
{
    
    
    
    
    
    
    
    
    
    
    
    
    
    [CmdletBinding(DefaultParameterSetName='PowerShellAndHTML')]
    [OutputType([string])]
    param(
    
    [Parameter(Mandatory=$true,
        ParameterSetName='FileName',
        ValueFromPipelineByPropertyName=$true)]
    [Alias('Fullname')]
    [ValidateScript({$ExecutionContext.SessionState.Path.GetResolvedPSPathFromPSPath($_)})]
    [string]$FileName,    
    
    
    [Parameter(Mandatory=$true,
        Position=0,
        ParameterSetName='PowerShellAndHtml',
        ValueFromPipelineByPropertyName=$true)]
    [string]$PowerShellAndHtml,
    
    
    [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$MasterPage,

    
    [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$CodeFile,

    
    [Parameter(ValueFromPipelineByPropertyName=$true)]
    [string]$Inherit,

    
    [string]$RunScriptMethod = 'runScript'
    )        
    
    process {
        if ($psCmdlet.ParameterSetName -eq 'FileName') {            
            if ($fileName -like "*.ps1") {
                $PowerShellAndHtml = [IO.File]::ReadAllText($ExecutionContext.SessionState.Path.GetResolvedPSPathFromPSPath($FileName))            
                $PowerShellAndHtml = $PowerShellAndHtml -ireplace "<|", "&lt;|" -ireplace "|>", "|&gt;"
                $powerShellAndHtml = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAB8ACAAJABQAG8AdwBlAHIAUwBoAGUAbABsAEEAbgBkAEgAdABtAGwAIAB8AD4A')))
            } else {
                $PowerShellAndHtml = [IO.File]::ReadAllText($ExecutionContext.SessionState.Path.GetResolvedPSPathFromPSPath($FileName))            
            }                        
        }
        
        
        $dataLanguageResult = try {
            $asScriptBlock = [ScriptBlock]::Create($PowerShellAndHtml)
            $asDataLanguage = & ([ScriptBlock]::Create($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQAgAHsAIAAkAGEAcwBTAGMAcgBpAHAAdABCAGwAbwBjAGsAIAB9AA==')))))            
        } catch {
            Write-Verbose "Could not convert into script block: $($_ | Out-string)"            
        }
        
        
        if ($dataLanguageResult) {
            
        } else {
            
            $powerShellAndHtml  = $powerShellAndHtml -ireplace 
                "\<psh\>", "<|" -ireplace
                "\</psh\>", "|>" -ireplace
                "\<\?posh\>", "<|" -ireplace
                "\<\?psh", "<|" -ireplace
                "\?>", "|>" 
                
            
            $start = 0
            

            $loopCount = 0

            $powerShellAndHtmlList = do {             
                if ($loopCount -ge 3) { break }    
                $found = $powerShellAndHtml.IndexOf("<|", $start)
                if ($found -eq -1) { $loopCount++; continue }                                
                
                $powershellAndHtml.Substring($start, $found - $start)
                $endFound = $powerShellAndHtml.IndexOf("|>", $found)                
                if ($endFound -eq -1) { $loopCount++; continue }                
                $scriptToBe = $powerShellAndHtml.Substring($found + 2, $endFound - $found - 2)                
                $scriptToBe = $scriptToBe.Replace("&lt;|", "<|").Replace("|&gt;", "|>")
                $scriptToBe = [ScriptBLock]::Create($scriptToBe)
                if (-not $?) { 
                    break 
                }                
                $embed = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABsAGEAcwB0AEMAbwBtAG0AYQBuAGQAIAA9ACAAewAgACQAcwBjAHIAaQBwAHQAVABvAEIAZQAgAH0ADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAaQBmACAAKAAkAG0AbwBkAHUAbABlACkAIAB7ACAALgAgACQAbQBvAGQAdQBsAGUAIAAkAEwAYQBzAHQAQwBvAG0AbQBhAG4AZAAgAHwAIABPAHUAdAAtAEgAdABtAGwAfQAgAGUAbABzAGUAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAALgAgACQAbABhAHMAdABDAG8AbQBtAGEAbgBkACAAfAAgAE8AdQB0AC0ASABUAE0ATAANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9ACAA'))).Replace('"','""')
                

                "$(if ($MasterPage) { '<asp:Content runat="server">' } else {'<%' }) ${RunScriptMethod}(@`"$embed`"); $(if ($MasterPage) { '</asp:Content>' } else {'%>'})"                
                $start = $endFound + 2
            } while ($powerShellAndHtml.IndexOf("<|", $start) -ne -1)
            
            $powerShellAndHtml = ($powerShellAndHtmlList -join '') + $powerShellAndHtml.Substring($start)
            
            $Params = @{Text=$powerShellAndHtml }
            if ($masterPage) {
                $Params.masterPage = $masterPage                
                $params.NoBootstrapper = $true
            }

            if ($CodeFile) {
                $Params.CodeFile = $CodeFile                
                $params.NoBootstrapper = $true
            }

            if ($inherit) {
                $Params.Inherit = $Inherit
                $params.NoBootstrapper = $true
            }
            Write-AspDotNetScriptPage @params 
        }        
    }
} 
