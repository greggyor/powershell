﻿<#
    .Synopsis
        This Module contains functions to manage INI files

    .Description
        This Module contains functions to manage INI files

    .Notes
        Author       : Oliver Lipkau <oliver@lipkau.net>
        Contributers : Craig Buchanan <https://github.com/craibuc>
                       Colin Bate <https://github.com/colinbate>
                       Sean Seymour <https://github.com/seanjseymour>
                       Alexis CÃ´tÃ© <https://github.com/popojargo>

        Homepage     : http://lipkau.github.io/PsIni/

#>
${10110000101000000} = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
# Name of the Section, in case the ini file had none
# Available in the scope of the module as `$script:NoSection`
${script:00111110010000000} = "_"
# public functions
. "${10110000101000000}\Functions\Get-IniContent.ps1"
. "${10110000101000000}\Functions\Out-IniFile.ps1"
. "${10110000101000000}\Functions\Add-IniComment.ps1"
. "${10110000101000000}\Functions\Remove-IniComment.ps1"
. "${10110000101000000}\Functions\Remove-IniEntry.ps1"
. "${10110000101000000}\Functions\Set-IniContent.ps1"
# private functions
. "${10110000101000000}\Functions\Convert-IniCommentToEntry.ps1"
. "${10110000101000000}\Functions\Convert-IniEntryToComment.ps1"
