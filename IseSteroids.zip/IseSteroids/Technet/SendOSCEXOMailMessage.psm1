﻿




Import-LocalizedData -BindingVariable Messages

Add-Type -AssemblyName System.Core

$webSvcInstallDirRegKey = gp -Path "HKLM:\SOFTWARE\Microsoft\Exchange\Web Services\2.0" -PSProperty "Install Directory" -ErrorAction:SilentlyContinue
if ($webSvcInstallDirRegKey -ne $null) {
	$moduleFilePath = $webSvcInstallDirRegKey.'Install Directory' + 'Microsoft.Exchange.WebServices.dll'
	ipmo $moduleFilePath
} else {
	$errorMsg = $Messages.InstallExWebSvcModule
	throw $errorMsg
}

Function New-OSCPSCustomErrorRecord
{
	
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Connect-OSCEXOWebService
{
	

    [cmdletbinding()]
	Param
	(
		
		[Parameter(Mandatory=$true,Position=1)]
		[System.Management.Automation.PSCredential]$Credential,
		[Parameter(Mandatory=$false,Position=2)]
		[Microsoft.Exchange.WebServices.Data.ExchangeVersion]$ExchangeVersion="Exchange2010_SP2",
		[Parameter(Mandatory=$false,Position=3)]
		[string]$TimeZoneStandardName,
		[Parameter(Mandatory=$false)]
		[switch]$Force
	)
	Process
	{
        
        if (-not [System.String]::IsNullOrEmpty($TimeZoneStandardName)) {
            Try
            {
                $tzInfo = [System.TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneStandardName)
            }
            Catch
            {
                $PSCmdlet.ThrowTerminatingError($_)
            }
        } else {
            $tzInfo = $null
        }

		
		$validateRedirectionUrlCallback = {
            param ([string]$Url)
			if ($Url -eq "https://autodiscover-s.outlook.com/autodiscover/autodiscover.xml") {
            	return $true
			} else {
				return $false
			}
        }	
	
		
		$existingExSvcVar = (gv -Name exService -Scope Global -ErrorAction:SilentlyContinue) -ne $null
		
		
		if ((-not $existingExSvcVar) -or $Force) {
			$verboseMsg = $Messages.EstablishConnection
			$PSCmdlet.WriteVerbose($verboseMsg)
            if ($tzInfo -ne $null) {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion,$tzInfo)			
            } else {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion)
            }
			
			
			$userName = $Credential.UserName
			$exService.Credentials = $Credential.GetNetworkCredential()
			Try
			{
				
				$exService.AutodiscoverUrl($userName,$validateRedirectionUrlCallback)
				$verboseMsg = $Messages.SaveExWebSvcVariable
				$PSCmdlet.WriteVerbose($verboseMsg)
				sv -Name exService -Value $exService -Scope Global -Force
			}
			Catch [Microsoft.Exchange.WebServices.Autodiscover.AutodiscoverRemoteException]
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
			Catch
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
		} else {
			$verboseMsg = $Messages.FindExWebSvcVariable
            $verboseMsg = $verboseMsg -f $exService.Credentials.Credentials.UserName
			$PSCmdlet.WriteVerbose($verboseMsg)            
		}
	}
}

Function Send-OSCEXOEmailMessage
{
	

    [cmdletbinding()]
	Param
	(
		
		[Parameter(Mandatory=$false,Position=1)]
		[string]$From,
		[Parameter(Mandatory=$false,Position=2)]
		[string[]]$To,
		[Parameter(Mandatory=$false,Position=3)]
		[string[]]$Cc,
		[Parameter(Mandatory=$false,Position=4)]
		[string[]]$Bcc,
		[Parameter(Mandatory=$true,Position=5)]
		[string]$Subject,
		[Parameter(Mandatory=$false,Position=6)]
		[string]$Body,
		[Parameter(Mandatory=$false,Position=7)]
        [ValidateSet("Normal","Low","High")]
		[string]$Priority="Normal",
		[Parameter(Mandatory=$false,Position=8)]
		[string[]]$Attachments,
		[Parameter(Mandatory=$false,Position=9)]
		[string[]]$InlineAttachments,
 		[Parameter(Mandatory=$false,Position=10)]
		[datetime]$DeferredSendTime,
 		[Parameter(Mandatory=$false)]
		[switch]$RequestReadReceipt,
 		[Parameter(Mandatory=$false)]
		[switch]$RequestDeliveryReceipt
	)
	Begin
	{
        
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
	}
    Process
    {
		
        if ([System.String]::IsNullOrEmpty($To) -and `
            [System.String]::IsNullOrEmpty($Cc) -and `
            [System.String]::IsNullOrEmpty($Bcc)) {
			$errorMsg = $Messages.RequiresRecipient
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }

		
        foreach ($attchmentPath in $Attachments) {
            if (-not (Test-Path -Path $attchmentPath)) {
 			    $errorMsg = $Messages.CannotFindFile
                $errorMsg = $errorMsg -f $attchment
			    $customError = New-OSCPSCustomErrorRecord `
			    -ExceptionString $errorMsg `
			    -ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			    $PSCmdlet.ThrowTerminatingError($customError)               
            }
        }

		
        foreach ($inlineAttachmentPath in $inlineAttchments) {
            if (-not (Test-Path -Path $inlineAttachmentPath)) {
 			    $errorMsg = $Messages.CannotFindFile
                $errorMsg = $errorMsg -f $attchment
			    $customError = New-OSCPSCustomErrorRecord `
			    -ExceptionString $errorMsg `
			    -ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			    $PSCmdlet.ThrowTerminatingError($customError)               
            }
        }

        
        Try
        {
            if ($DeferredSendTime -ne $null) {
                $sendTime = [System.DateTime]::Parse($DeferredSendTime)
                $sendTime = $sendTime.ToUniversalTime().ToString()
            }
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }

        
        $emailMessage = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage($exService)

        
        if (-not [System.String]::IsNullOrEmpty($From)) {
            $emailMessage.From = $From
        }

        
        if (-not [System.String]::IsNullOrEmpty($To)) {
            foreach ($toRecipient in $To) {
                $emailMessage.ToRecipients.Add($toRecipient) | Out-Null
            }
        }
        if (-not [System.String]::IsNullOrEmpty($Cc)) {
            foreach ($ccRecipient in $Cc) {
                $emailMessage.CcRecipients.Add($ccRecipient) | Out-Null
            }
        }
        if (-not [System.String]::IsNullOrEmpty($Bcc)) {
            foreach ($bccRecipient in $Bcc) {
                $emailMessage.CcRecipients.Add($bccRecipient) | Out-Null
            }
        }

        
        $emailMessage.Subject = $Subject
        $emailMessage.Body = $Body
        $emailMessage.Importance = $Priority
        $emailMessage.IsReadReceiptRequested = $RequestReadReceipt.ToBool()
        $emailMessage.IsDeliveryReceiptRequested = $RequestDeliveryReceipt.ToBool()
        
        
        foreach ($attachmentPath in $Attachments) {
            $attachment = $emailMessage.Attachments.AddFileAttachment($attachmentPath)
        }

        
        foreach ($inlineAttachmentPath in $InlineAttachments) {
            $fileName = $inlineAttachmentPath.Split("\")[-1]
            $inlineAttachment = $emailMessage.Attachments.AddFileAttachment($fileName,$inlineAttachmentPath)
            $inlineAttachment.IsInline = $true
            $inlineAttachment.ContentId = $fileName
        }

        
        if ($DeferredSendTime -ne $null) {
            
            $pidTagDeferredSendTime = 16367
            $prDeferredSendTime = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(`
                                  $pidTagDeferredSendTime,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
            
            $emailMessage.SetExtendedProperty($prDeferredSendTime,$sendTime)        
        }

        
        Try
        {
            $emailMessage.SendAndSaveCopy()
        }
        Catch
        {
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
	End {}
}

Export-ModuleMember -Function "Connect-OSCEXOWebService","Send-OSCEXOEmailMessage"