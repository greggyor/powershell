﻿import-module grouppolicy
function IsNotLinked(${_00001010011110111}){
    If (${_00001010011110111}.GPO.LinksTo -eq $null) {
        Return $true
    }
    Return $false
}
${10101101110111010} = @()
Get-GPO -All | ForEach { ${10110110000111110} = $_ ; $_ | Get-GPOReport -ReportType xml | ForEach { If(IsNotLinked([xml]$_)){${10101101110111010} += ${10110110000111110}} }}
If (${10101101110111010}.Count -eq 0) {
    $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAVQBuAGwAaQBuAGsAZQBkACAARwBQAE8AJwBzACAARgBvAHUAbgBkAA==')))
}
Else{
    ${10101101110111010} | Select DisplayName,ID | ft
}