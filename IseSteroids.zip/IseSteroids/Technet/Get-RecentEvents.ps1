﻿
[CmdletBinding()]
Param
    (
        $Servers,
        $Hours = 2,
        $FilePath = 'C:\LogFiles'
    )
Begin
    {
        ${2} = $MyInvocation.MyCommand.ToString()
        ${3} = "Application"
        ${5} = $MyInvocation.MyCommand.Path
        ${4} = $env:USERDOMAIN + "\" + ${env:4}
 
        New-EventLog -Source ${2} -LogName ${3} -ErrorAction SilentlyContinue
 
        ${1} = "Script: " + ${5} + "`nScript User: " + ${4} + "`nStarted: " + (Get-Date).toString()
        Write-EventLog -LogName ${3} -Source ${2} -EventID "104" -EntryType "Information" -Message ${1}
 
        
        Write-Verbose "Setting checkpoint to $(Get-Date)."
        ${11} = Get-Date
        ${13} = Get-Date -f MMddyyy-HHMMss
        ${8} = "$($FilePath)\$(${13})"
        
        if ((Test-Path ${8}) -ne $true)
        {
            Write-Verbose "Creating $(${8})"
            ni -Path ${8} -ItemType Directory -Force |Out-Null
            }
        }
Process
    {
        foreach (${7} in $Servers)
        {
            try
            {
                Write-Verbose "Get a list of logs that have records from $(${7})"
                ${12} = Get-WinEvent -ListLog * -ComputerName ${7} |? {$_.RecordCount -gt 0}
                Write-Verbose "Found $(${12}.Count) logs"
                
                foreach (${10} in ${12})
                {                   
                    Write-Verbose "Connect to $(${7}) and return a list of logs that were written within the last $($Hours) hour(s)"
                    ${9} = Get-WinEvent -LogName ${10}.LogName -ComputerName ${7} `
                        |? {(Get-Date($_.TimeCreated)) -gt ${11}.AddHours(-($Hours)) -and (Get-Date($_.TimeCreated)) -lt ${11}}
                    
                    if (${9})
                    {
                        Write-Verbose "$(${9}.Count) event(s) were found in $(${10}.LogName)"
                        Write-Verbose "Building filename from $(${10}.LogName)"
                        ${6} = "$((${10}.LogName).Replace('/','-')).csv"
                        Write-Verbose "$(${6})"
                        if ((Test-Path "$(${8})\$(${7})") -ne $true)
                        {
                            Write-Verbose "$(${8})\$(${7}) not found, creating."
                            ni -Path "$(${8})\$(${7})" -ItemType Directory -Force |Out-Null
                            }
                        Write-Verbose "Exporting $(${9}.Count) log entries to $(${8})\$(${7})\$(${6})"
                        ${9} |epcsv -Path "$(${8})\$(${7})\$(${6})" -NoTypeInformation
                        }
                    }
                }
            catch
            {
                ${1} = $Error[0].Exception
                Write-Verbose ${1}
                Write-EventLog -LogName ${3} -Source ${2} -EventID "101" -EntryType "Error" -Message ${1}	
                }
            }
        }
End
    {
        ${1} = "Script: " + ${5} + "`nScript User: " + ${4} + "`nFinished: " + (Get-Date).toString()
        Write-EventLog -LogName ${3} -Source ${2} -EventID "104" -EntryType "Information" -Message ${1}	
        }