﻿
[string] ${script:11000010110110101} = "Data Source=.\SQLEXPRESS;Initial Catalog=AdventureWorks;Integrated Security=True;";
[string] ${script:10110100111111010} = "
SELECT [AddressID]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[City]
      ,[StateProvinceID]
      ,[PostalCode]
      ,[rowguid]
      ,[ModifiedDate]
  FROM [Person].[Address]
 WHERE [AddressID] <= 100";
function startNotification
{
    ${01101100110110010} = New-Object Data.SqlClient.SqlConnection;
    ${01101100110110010}.ConnectionString = ${script:11000010110110101};
    ${01101100110110010}.Open();
    ${10100001111000011} = New-Object Data.SqlClient.SqlCommand ${script:10110100111111010}, ${01101100110110010};
    ${00100110111101010} = New-Object Data.SqlClient.SqlDependency ${10100001111000011};
    Register-ObjectEvent ${00100110111101010} "OnChange" -SourceIdentifier "PoShSsasQueryNotification" -Action `
    {
        $args = $event.SourceEventArgs;
        ${01011110100000100} = "Type: " + $args.Type.ToString() + " / Info: " + $args.Info.ToString();
        Write-Host ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + " " + ${01011110100000100});
        Unregister-Event -SourceIdentifier "PoShSsasQueryNotification";
        if ($args.Info -ne [Data.SqlClient.SqlNotificationInfo]::Invalid `
            -and $args.Type -ne [Data.SqlClient.SqlNotificationType]::Subscribe)
        {   startNotification;   }
    }  | Out-Null;
    ${10100001111000011}.ExecuteNonQuery() | Out-Null;
    ${10100001111000011}.Dispose();
    ${01101100110110010}.Close();
    ${01101100110110010}.Dispose();
}
Write-Output ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Started ...");
Write-Output ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Press Ctrl + C to stop the script.");
[Data.SqlClient.SqlDependency]::Start(${script:11000010110110101}) | Out-Null;
startNotification;
Wait-Event;
