﻿[CmdletBinding()][OutputType([int])]Param(
    [parameter(Mandatory=$true, ValueFromPipeLine=$true)][Alias("Msg")][string]$Message,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Ttl")][string]$Title = $null,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Duration")][int]$TimeOut = 0,
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("But","BS")][ValidateSet( "OK", "OC", "AIR", "YNC" , "YN" , "RC")][string]$ButtonSet = "OK",
    [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("ICO")][ValidateSet( "None", "Critical", "Question", "Exclamation" , "Information" )][string]$IconType = "None"
     )
Function _01100110011010011{
    [CmdletBinding()][OutputType([int])]Param(
        [parameter(Mandatory=$true, ValueFromPipeLine=$true)][Alias("Msg")][string]$Message,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Ttl")][string]$Title = $null,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("Duration")][int]$TimeOut = 0,
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("But","BS")][ValidateSet( "OK", "OC", "AIR", "YNC" , "YN" , "RC")][string]$ButtonSet = "OK",
        [parameter(Mandatory=$false, ValueFromPipeLine=$false)][Alias("ICO")][ValidateSet( "None", "Critical", "Question", "Exclamation" , "Information" )][string]$IconType = "None"
         )
    ${01110001101101100} = "OK", "OC", $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBJAFIA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBOAEMA'))) , "YN" , "RC"
    ${00111111101000011}  = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAG4AZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGkAdABpAGMAYQBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UQB1AGUAcwB0AGkAbwBuAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAbABhAG0AYQB0AGkAbwBuAA=='))) , $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwByAG0AYQB0AGkAbwBuAA==')))
    ${00011010001110110} = 0,16,32,48,64
    if((Get-Host).Version.Major -ge 3){
        ${01001100101100000}   = ${01110001101101100}.IndexOf($ButtonSet)
        ${00100000111100100}     = ${00011010001110110}[${00111111101000011}.IndexOf($IconType)]
        }
    else{
        ${01110001101101100}|ForEach-Object -Begin{${01001100101100000} = 0;${10100010000101101}=0} -Process{ if($_.Equals($ButtonSet)){${01001100101100000} = ${10100010000101101}           };${10100010000101101}++ }
        ${00111111101000011} |ForEach-Object -Begin{${00100000111100100}   = 0;${10100010000101101}=0} -Process{ if($_.Equals($IconType) ){${00100000111100100}   = ${00011010001110110}[${10100010000101101}]};${10100010000101101}++ }
        }
    ${10111110101000010} = New-Object -com $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBzAGMAcgBpAHAAdAAuAFMAaABlAGwAbAA=')))
    ${10111110101000010}.Popup($Message,$TimeOut,$Title,${01001100101100000}+${00100000111100100})
}
_01100110011010011 -Message $Message -Title $Title -TimeOut $TimeOut -ButtonSet $ButtonSet -IconType $IconType
