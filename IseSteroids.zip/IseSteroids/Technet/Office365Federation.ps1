﻿##########################################################################################
#Created by KannaGanesh On 10-15-12
#This script helps you to federated a new / existing domain with Office365 portal
##########################################################################################
#
write-host "This script helps you to federated a new / existing domain with Office365"
$cred = Get-Credential 
$Domain = Read-Host "Provide your domain name that will be added to your Office365Portal" # This reads your Domain name that needs to federated with your Office365 subscription
$logfile = Read-Host "Logfile path"
Connect-MsolService -Credential $cred #Provide your microsoftonline credentials <admin@domain.microsoftonline.com>
$confirm = Read-Host "Please hit "S" for federating your existing office365 domain / hit "N" for adding and federating a new domain to Office365"
If ($confirm -eq "S")
{
Convert-MsolDomainToFederated -DomainName $Domain # This converts your existing domain to federated
}
else
{
New-MsolFederatedDomain -DomainName $domain 	# This line adds your domain to Office365 portal
write-host "Please note the DNS entry might take sometime for replication" -foregroundcolor Red -backgroundcolor white
read-host "Hit enter once DNS entries or done"		
New-MsolFederatedDomain -DomainName $domain -errorvariable e; # This line validates your domain verification
Write-Output $e > $logfile
If($e -ne $null)
{
Read-Host "Hit enter once you are ready to verify your domain"  # This gives you a chance of verifiying the added domain again.
New-MsolFederatedDomain -DomainName $domain -errorvariable a -ea silentlycontinue -wa silentlycontinue; 
$date = (get-date).ToString()
Write-Output $a $date | out-file $logfile -append # If the verification failed, then it writes an output to log file
If($a -ne $null)
{write-host "Your Domain verification failed, pls verify the txt record and run New-MsolFederatedDomain -DomainName <Domain Name> for successfull completion of federation" -foreground "White" -background "Red" ; write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBvAHIAIABtAG8AcgBlACAAaQBuAGYAbwAgAGMAaABlAGMAawAgAHQAaABlACAAbABvAGcAIABmAGkAbABlACAAQAAgACQAbABvAGcAZgBpAGwAZQA=')))}
# This write-host command tells you how to validate your domain after fixing the DNS record
else 
{write-output "Congrats you have successfully configured federation"
}
}
}