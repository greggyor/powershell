﻿
$Server = "server"
$Database = ""
$ExportShare = "\\server\share"
$ReportShare = "\\server\share"
$RemovePSTBeforeExport = $false
if ($Server)
{
    if (!(Get-ExchangeServer $Server -ErrorAction SilentlyContinue))
    {
        throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAUwBlAHIAdgBlAHIAIAAkAFMAZQByAHYAZQByACAAbgBvAHQAIABmAG8AdQBuAGQA')));
    }
    if (!(Get-MailboxDatabase -Server $Server -ErrorAction SilentlyContinue))
    {
        throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAUwBlAHIAdgBlAHIAIAAkAFMAZQByAHYAZQByACAAZABvAGUAcwAgAG4AbwB0ACAAaABhAHYAZQAgAG0AYQBpAGwAYgBvAHgAIABkAGEAdABhAGIAYQBzAGUAcwA=')));
    }
    $Mailboxes = Get-Mailbox -Server $Server -ResultSize Unlimited
} elseif ($Database) {
    if (!(Get-MailboxDatabase $Database -ErrorAction SilentlyContinue))
    {
        throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGkAbABiAG8AeAAgAGQAYQB0AGEAYgBhAHMAZQAgACQARABhAHQAYQBiAGEAcwBlACAAbgBvAHQAIABmAG8AdQBuAGQA')))
    }
    $Mailboxes = Get-Mailbox -Database $Database
}
if (!$Mailboxes) 
{
    throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAbQBhAGkAbABiAG8AeABlAHMAIABmAG8AdQBuAGQAIABvAG4AIAAkAFMAZQByAHYAZQByAA==')))
}
if (!$Mailboxes.Count)
{
    throw "This script does not support a single mailbox export."
}
$date=Get-Date
$BatchName = "Export_$($date.Year)-$($date.Month)-$($date.Day)_$($date.Hour)-$($date.Minute)-$($date.Second)"
Write-Output "Queuing $($Mailboxes.Count) mailboxes as batch '$($BatchName)'"
foreach ($Mailbox in $Mailboxes)
{
    if ($RemovePSTBeforeExport -eq $true -and (Get-Item "$($ExportShare)\$($Mailbox.Alias).PST" -ErrorAction SilentlyContinue))
    { 
        Remove-Item "$($ExportShare)\$($Mailbox.Alias).PST" -Confirm:$false 
    }
    New-MailboxExportRequest -BatchName $BatchName -Mailbox $Mailbox.Alias -FilePath "$($ExportShare)\$($Mailbox.Alias).PST"
}
Write-Output "Waiting for batch to complete"
while ((Get-MailboxExportRequest -BatchName $BatchName | Where {$_.Status -eq "Queued" -or $_.Status -eq "InProgress"}))
{
    sleep 60
}
if ($ReportShare)
{
    Write-Output "Writing reports to $($ReportShare)"
    $Completed = Get-MailboxExportRequest -BatchName $BatchName | Where {$_.Status -eq "Completed"} | Get-MailboxExportRequestStatistics | Format-List
    if ($Completed)
    {
        $Completed | Out-File -FilePath "$($ReportShare)\$($BatchName)_Completed.txt"
    }
    $Incomplete = Get-MailboxExportRequest -BatchName $BatchName | Where {$_.Status -ne "Completed"} | Get-MailboxExportRequestStatistics | Format-List
    if ($Incomplete)
    {
        $Incomplete | Out-File -FilePath "$($ReportShare)\$($BatchName)_Incomplete_Report.txt"
    }
}
Write-Output "Removing requests created as part of batch '$($BatchName)'"
Get-MailboxExportRequest -BatchName $BatchName | Remove-MailboxExportRequest -Confirm:$false