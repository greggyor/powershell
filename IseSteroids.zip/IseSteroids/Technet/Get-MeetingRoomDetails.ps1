﻿
${__/\/\_/=\/\_/==\} = $true
sal read Read-Host
ipmo ActiveDirectory
cls
function __/\___/\/==\_/\__(${_/=====\/===\_/=\_}) {
	write-host ${_/=====\/===\_/=\_} -f $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
}
function _/=\_/\_/==\/=\/=\(${_/==\/\/=\____/\/\}) {
	foreach(${_/\_____/==\/=\/=} in ${_/==\/\/=\____/\/\}.GetEnumerator()){
		write-host "$(${_/\_____/==\/=\/=}.Key): "-nonewline
		write-host ${_/\_____/==\/=\/=}.Value -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAGUAZQBuAA==')))
	}
}
try {
	__/\___/\/==\_/\__ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBUAHIAeQAgAG4AbwB0AC4AIABEAG8ALAAgAG8AcgAgAGQAbwAgAG4AbwB0AC4AIABUAGgAZQByAGUAIABpAHMAIABuAG8AIAB0AHIAeQAuAAoA')))
	${_/\_/\/\/\_/=\_/=} = read $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBuAHQAZQByACAAbQBlAGUAdABpAG4AZwAgAHIAbwBvAG0A')))
	${_/==\/=\__/=\_/==} = Get-Mailbox ${_/\_/\/\/\_/=\_/=}
	${/=\/==\_______/==} = Get-CalendarProcessing ${_/\_/\/\/\_/=\_/=}
	__/\___/\/==\_/\__ "`n$(${_/==\/=\__/=\_/==}.DisplayName)`n"
	${_/==\_____/=\____} = @{}
	${_/==\_____/=\____}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABpAGQAZABlAG4ARgByAG8AbQBBAGQAZAByAGUAcwBzAEwAaQBzAHQA'))),${_/==\/=\__/=\_/==}.HiddenFromAddressListsEnabled)
	${_/==\_____/=\____}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABhAG4AeQA='))),${_/==\/=\__/=\_/==}.Company)
	${_/==\_____/=\____}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHAAYQByAHQAbQBlAG4AdAA='))),${_/==\/=\__/=\_/==}.Department)
	${_/==\_____/=\____}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBmAGYAaQBjAGUA'))),${_/==\/=\__/=\_/==}.Office)
	${_/==\_____/=\____}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAbwB1AHIAYwBlAEMAYQBwAGEAYwBpAHQAeQA='))),${_/==\/=\__/=\_/==}.ResourceCapacity)
	_/=\_/\_/==\/=\/=\ ${_/==\_____/=\____}
	__/\___/\/==\_/\__ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBEAGUAdABhAGkAbABzAAoA')))
	${/=\_/\________/=\} = @{}
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB1AHQAbwBtAGEAdABlAFAAcgBvAGMAZQBzAHMAaQBuAGcA'))),${/=\/==\_______/==}.AutomateProcessing)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAUwB1AGIAagBlAGMAdAA='))),${/=\/==\_______/==}.DeleteSubject)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQATwByAGcAYQBuAGkAegBlAHIAVABvAFMAdQBiAGoAZQBjAHQA'))),${/=\/==\_______/==}.AddOrganizerToSubject)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAQgBvAG8AawBJAG4AUABvAGwAaQBjAHkA'))),${/=\/==\_______/==}.AllBookInPolicy)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAUgBlAHEAdQBlAHMAdABJAG4AUABvAGwAaQBjAHkA'))),${/=\/==\_______/==}.AllRequestInPolicy)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBvAG8AawBpAG4AZwBXAGkAbgBkAG8AdwBJAG4ARABhAHkAcwA='))),${/=\/==\_______/==}.BookingWindowInDays)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAHgAaQBtAHUAbQBEAHUAcgBhAHQAaQBvAG4ASQBuAE0AaQBuAHUAdABlAHMA'))),${/=\/==\_______/==}.MaximumDurationInMinutes)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAbwB3AFIAZQBjAHUAcgByAGkAbgBnAE0AZQBlAHQAaQBuAGcAcwA='))),${/=\/==\_______/==}.AllowRecurringMeetings)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAdwBhAHIAZABSAGUAcQB1AGUAcwB0AHMAVABvAEQAZQBsAGUAZwBhAHQAZQBzAA=='))),${/=\/==\_______/==}.ForwardRequestsToDelegates)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAQQB0AHQAYQBjAGgAbQBlAG4AdABzAA=='))),${/=\/==\_______/==}.DeleteAttachments)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAQwBvAG0AbQBlAG4AdABzAA=='))),${/=\/==\_______/==}.DeleteComments)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGUAUAByAGkAdgBhAHQAZQBQAHIAbwBwAGUAcgB0AHkA'))),${/=\/==\_______/==}.RemovePrivateProperty)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAG4AdABhAHQAaQB2AGUAUABlAG4AZABpAG4AZwBBAHAAcAByAG8AdgBhAGwA'))),${/=\/==\_______/==}.TentativePendingApproval)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUATgBvAG4AQwBhAGwAZQBuAGQAYQByAEkAdABlAG0AcwA='))),${/=\/==\_______/==}.DeleteNonCalendarItems)
	${/=\_/\________/=\}.add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAGYAbwByAGMAZQBTAGMAaABlAGQAdQBsAGkAbgBnAEgAbwByAGkAegBvAG4A'))),${/=\/==\_______/==}.EnforceSchedulingHorizon)
	_/=\_/\_/==\/=\/=\ ${/=\_/\________/=\}
	__/\___/\/==\_/\__ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBEAGEAcwAgACcAVwBoAG8AIABpAHMAIABXAGgAbwAnACAAZABlAHMAIABNAGUAZQB0AGkAbgBnACAAUgBhAHUAbQBzAAoA')))
	${/=\/==\_______/==}.ResourceDelegates | ft @{Label=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAbwB1AHIAYwBlAEQAZQBsAGUAZwBhAHQAZQBzAA==')));Expression={$_.name}}
	${/=\/==\_______/==}.BookInPolicy | ft @{Label=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBvAG8AawBJAG4AUABvAGwAaQBjAHkA')));Expression={$_.name}}
	${/=\/==\_______/==}.RequestInPolicy | ft @{Label=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHEAdQBlAHMAdABJAG4AUABvAGwAaQBjAHkA')));Expression={$_.name}}
	${/=\/==\_______/==}.RequestOutOfPolicy | ft @{Label=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHEAdQBlAHMAdABPAHUAdABPAGYAUABvAGwAaQBjAHkA')));Expression={$_.name}}
	__/\___/\/==\_/\__ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBGAGEAbgB0AGEAcwB0AGkAYwAhAAoA')))
}
catch {
	Write-Host $Error[0].Exception;
	write-warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQAnAG0AIABzAG8AcgByAHkALAAgAEQAYQB2AGUALgAgAEkAJwBtACAAYQBmAHIAYQBpAGQAIABJACAAYwBhAG4AJwB0ACAAZABvACAAdABoAGEAdAAuAA==')))
}