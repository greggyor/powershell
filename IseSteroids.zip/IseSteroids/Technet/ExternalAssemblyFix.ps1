﻿$xml = New-Object XML
$xml.Load($args[0])
if (!$xml.mapsource.CustomXSLT)
{
	$newelement = $xml.CreateElement($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB1AHMAdABvAG0AWABTAEwAVAA='))))
	$newelement.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WABzAGwAdABQAGEAdABoAA=='))), '') 
	$newelement.SetAttribute($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQATwBiAGoAWABtAGwAUABhAHQAaAA='))), $args[1])
	$xml.mapsource.InsertAfter($newelement, $xml.mapsource.ScriptTypePrecedence)
	$xml.Save($args[0])
}
