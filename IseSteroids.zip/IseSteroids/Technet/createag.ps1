﻿###########################################################
# SCRIPT PARAMETERS 
###########################################################

Param
(
    # Name of the server instances that will participate in the availability group.
    # The first server is assumed to be the initial primary, the others initial secondaries.
    [Parameter(Mandatory=$true)]
    [string[]] $ServerList,

    # Name of the availability group
    [string] $AgName = "MyAvailabilityGroup",

    # Names of the databases to add to availability group
    [string[]] $DatabaseList,
    
    # Directory for backup files
    [Parameter(Mandatory=$true)]
    [string] $BackupShare
)

###########################################################
# SCRIPT BODY 
###########################################################

# Initialize some collections
$serverObjects = @()
$replicas = @()

foreach ($server in $ServerList)
{
    # Connection to the server instance, using Windows authentication
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAUwBNAE8AIABTAGUAcgB2AGUAcgAgAG8AYgBqAGUAYwB0ACAAZgBvAHIAIABzAGUAcgB2AGUAcgA6ACAAJABzAGUAcgB2AGUAcgA=')))
    $serverObject = New-Object Microsoft.SQLServer.Management.SMO.Server($server) 
    $serverObjects += $serverObject

    # Get the mirroring endpoint on the server
    $endpointObject = $serverObject.Endpoints | 
        ? { $_.EndpointType -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlAE0AaQByAHIAbwByAGkAbgBnAA=='))) } | 
        select -First 1

    # Create an endpoint if one doesn't exist
    if($endpointObject -eq $null)
    {
        throw $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAATQBpAHIAcgBvAHIAaQBuAGcAIABlAG4AZABwAG8AaQBuAHQAIABmAG8AdQBuAGQAIABvAG4AIABzAGUAcgB2AGUAcgA6ACAAJABzAGUAcgB2AGUAcgA=')))
    }

    $fqdn = $serverObject.Information.FullyQualifiedNetName
    $port = $endpointObject.Protocol.Tcp.ListenerPort
    $endpointURL = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABDAFAAOgAvAC8AJAB7AGYAcQBkAG4AfQA6ACQAewBwAG8AcgB0AH0A')))

    # Create an availability replica for this server instance.
    # For this example all replicas use asynchronous commit, manual failover, and 
    # support reads on the secondaries
    $replicas += (New-SqlAvailabilityReplica `
            -Name $server `
            -EndpointUrl $endpointURL `
            -AvailabilityMode $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBzAHkAbgBjAGgAcgBvAG4AbwB1AHMAQwBvAG0AbQBpAHQA'))) `
            -FailoverMode $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAG4AdQBhAGwA'))) `
            -ConnectionModeInSecondaryRole $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAbwB3AEEAbABsAEMAbwBuAG4AZQBjAHQAaQBvAG4AcwA='))) `
            -AsTemplate `
            -Version 11) 
}

$primary, $secondaries = $serverObjects

# Create the initial copies of the databases on the secondaries,
# via backup/restore
foreach ($db in $DatabaseList)
{
    $bakFile = Join-Path $BackupShare $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABkAGIALgBiAGEAawA=')))
    $trnFile = Join-Path $BackupShare $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABkAGIALgB0AHIAbgA=')))

    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawBpAG4AZwAgAHUAcAAgAGQAYQB0AGEAYgBhAHMAZQAgACcAJABkAGIAJwAgAG8AbgAgACQAcAByAGkAbQBhAHIAeQAgAHQAbwAgACQAYgBhAGsARgBpAGwAZQA=')))
    Backup-SqlDatabase -InputObject $primary -Database $db -BackupFile $bakFile -Init 
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawBpAG4AZwAgAHUAcAAgAHQAaABlACAAbABvAGcAIABvAGYAIABkAGEAdABhAGIAYQBzAGUAIAAnACQAZABiACcAIABvAG4AIAAkAHAAcgBpAG0AYQByAHkAIAB0AG8AIAAkAHQAcgBuAEYAaQBsAGUA')))
    Backup-SqlDatabase -InputObject $primary -Database $db -BackupFile $trnFile -BackupAction $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcA'))) -Init 

    foreach($secondary in $secondaries)
    {
        Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABvAHIAaQBuAGcAIABkAGEAdABhAGIAYQBzAGUAIAAnACQAZABiACcAIABvAG4AIAAkAHMAZQBjAG8AbgBkAGEAcgB5ACAAZgByAG8AbQAgACQAYgBhAGsARgBpAGwAZQA=')))
        Restore-SqlDatabase -InputObject $secondary -Database $db -BackupFile $bakFile -NoRecovery 
        Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABvAHIAaQBuAGcAIAB0AGgAZQAgAGwAbwBnACAAbwBmACAAZABhAHQAYQBiAGEAcwBlACAAJwAkAGQAYgAnACAAbwBuACAAJABzAGUAYwBvAG4AZABhAHIAeQAgAGYAcgBvAG0AIAAkAHQAcgBuAEYAaQBsAGUA')))
        Restore-SqlDatabase -InputObject $secondary -Database $db -BackupFile $trnFile -RestoreAction $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcA'))) -NoRecovery 
    }
}

# Create the availability group
New-SqlAvailabilityGroup -Name $AgName -InputObject $primary -AvailabilityReplica $Replicas -Database $DatabaseList | Out-Null

# Join the secondary replicas, and join the databases on those replicas
foreach ($secondary in $secondaries)
{
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SgBvAGkAbgBpAG4AZwAgAHMAZQBjAG8AbgBkAGEAcgB5ACAAaQBuAHMAdABhAG4AYwBlACAAJABzAGUAYwBvAG4AZABhAHIAeQAgAHQAbwAgAHQAaABlACAAYQB2AGEAaQBsAGEAYgBpAGwAaQB0AHkAIABnAHIAbwB1AHAAIAAnACQAQQBnAE4AYQBtAGUAJwA=')))
    Join-SqlAvailabilityGroup -InputObject $secondary -Name $AgName
    $ag = $secondary.AvailabilityGroups[$AgName]
    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SgBvAGkAbgBpAG4AZwAgAHMAZQBjAG8AbgBkAGEAcgB5ACAAZABhAHQAYQBiAGEAcwBlAHMAIABvAG4AIAAkAHMAZQBlAGMAbwBuAGQAYQByAHkAIAB0AG8AIAB0AGgAZQAgAGEAdgBhAGkAbABhAGIAaQBsAGkAdAB5ACAAZwByAG8AdQBwACAAJwAkAEEAZwBOAGEAbQBlACcA')))
    Add-SqlAvailabilityDatabase -InputObject $ag -Database $DatabaseList 
}

