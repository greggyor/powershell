﻿
function Invoke-Ternary ([scriptblock]$decider, [scriptblock]$ifTrue, [scriptblock]$ifFalse) 
{
	if (&$decider)
	{ 
		&$ifTrue
	}
	else
	{
		&$ifFalse
	}
}
sal ?? Invoke-Ternary -Option AllScope -Description $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHIAbgBhAHIAeQAgAE8AcABlAHIAYQB0AG8AcgAgAGwAaQBrAGUAIAAnAD8AJwAgAGkAbgAgAEMAIwA=')))
function Add-Ace 
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="SimpleInheritance")]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath","FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("FileSystemRights")]
		[System.Security.AccessControl.FileSystemRights] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="SimpleInheritance")]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.InheritanceFlags] $InheritanceFlags,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true,ParameterSetName="ComplexInheritance")]
		[System.Security.AccessControl.PropagationFlags] $PropagationFlags = [System.Security.AccessControl.PropagationFlags]::None,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	begin { }
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$ir = New-Object System.Security.Principal.SecurityIdentifier($Account.Sid)
			switch ($pscmdlet.ParameterSetName)
			{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAG0AcABsAGUASQBuAGgAZQByAGkAdABhAG4AYwBlAA==')))
				{
					if ($item -is [System.IO.FileInfo])
					{
						$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir, $AccessRights, $AccessType)
					}
					elseif ($item -is [System.IO.DirectoryInfo])
					{				
						$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir,
							$AccessRights,
							(?? {$NoInheritance} { [Security.AccessControl.InheritanceFlags]::None } {[Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit}),
							[Security.AccessControl.PropagationFlags]::None,
							$AccessType)
					}
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAeABJAG4AaABlAHIAaQB0AGEAbgBjAGUA')))
				{
					$ace = New-Object Security.AccessControl.FileSystemAccessRule($ir,
						$AccessRights,
						$InheritanceFlags,
						$PropagationFlags,
						$AccessType)
				}
			}
			try
			{
				$sd.AddAccessRule($ace)
				$item.SetAccessControl($sd)
			}
			catch [Exception]
			{
				Write-Error -Message "Error adding ACE to item: $($_.Exception.Message)" -Exception $_.Exception
			}
			Write-Verbose "ACE for user $Account added to ACL of $($item.FullName)"
			if ($PassThru)
			{
				$item | ____/\_/\__/\/\___ -ExcludeInherited
			}
		}
	}
	end { }
}
function Remove-Ace
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath","FullName")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Position=2,Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("FileSystemRights")]
		[Security2.FileSystemRights2] $AccessRights,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[Alias("AccessControlType")]
		[System.Security.AccessControl.AccessControlType] $AccessType = [System.Security.AccessControl.AccessControlType]::Allow,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $NoInheritance,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	begin { }
	process
	{
		$acesToRemove = $null
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$acl = $sd.GetAccessRules($true, $false, [System.Security.Principal.NTAccount])
			$acesToRemove = @($acl | ? { $_.IdentityReference -eq $Account })
			foreach ($ace in $acesToRemove)
			{
				try
				{
					if (($ace.FileSystemRights -eq $AccessRights) -or (-not $AccessRights))
					{
						$sd.RemoveAccessRule($ace) | Out-Null
					}
					else
					{
						if ([int]$ace.FileSystemRights -lt [int]$AccessRights)
						{
							continue
						}
						[Void]$sd.RemoveAccessRule($ace)
						$newAccessRight = [int]$ace.FileSystemRights -bxor [int]$AccessRights
						if ($newAccessRight)
						{
							$ace = New-Object System.Security.AccessControl.FileSystemAccessRule($ace.IdentityReference,
								([int]$ace.FileSystemRights -bxor [int]$AccessRights),
								$ace.InheritanceFlags,
								$ace.PropagationFlags,
								$ace.AccessControlType)
							$sd.AddAccessRule($ace)
						}
					}
					$item.SetAccessControl($sd)
					Write-Verbose "$($acesToRemove.Count) ACE(s) removed from item $($item.Name)"
				}
				catch [Exception]
				{
					Write-Error -Message "Error removing ACE(s) from item: $($_.Exception.Message)" -Exception $_.Exception
				}
			}
			if ($PassThru)
			{
				$item | ____/\_/\__/\/\___ -ExcludeInherited
			}
		}
	}
	end { }
}
function ____/\_/\__/\/\___
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
	begin { }
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
				{
					$ace = [Security2.FileSystemAccessRule2]$ace
					$ace.FullName = $item.FullName
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.FileSystemAccessRule2]$ace
				}
		}
	}
	end { }
}
function Get-OrphanedAce
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeExplicit,
		[Parameter(Mandatory=$false)]
		[switch] $ExcludeInherited
	)
	begin { }
	process
	{
		[bool] $hasOrphanedSIDs = $false
		$orphanedSidCount = 0
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			foreach ($ace in $sd.GetAccessRules(
					(?? { $ExcludeExplicit} { $false } { $true }),
					(?? { $ExcludeInherited } { $false } { $true }),
					[System.Security.Principal.NTAccount]))
			{
				$ace = [Security2.FileSystemAccessRule2]$ace
				if (-not $ace.IdentityReference.AccountName)
				{
					$ace.FullName = $item.FullName
					$ace.InheritanceEnabled = -not $sd.AreAccessRulesProtected
					[Security2.FileSystemAccessRule2]$ace
					$hasOrphanedSIDs = $true
					$orphanedSidCount++
				}
			}
			if ($hasOrphanedSIDs)
			{
				Write-Verbose ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQB0AGUAbQAgAHsAMAB9ACAAawBuAG8AdwBzACAAYQBiAG8AdQB0ACAAewAxAH0AIABvAHIAcABoAGEAbgBlAGQAIABTAEkARABzACAAaQBuACAAaQB0AHMAIABBAEMATAA='))) -f $item.FullName, $orphanedSidCount)
			}
		}
	}
}
function _/===\/\_/\/\_/\__
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path
	)
	begin
	{ }
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$owner = New-Object Security2.FileSystemOwner
			$owner.Item = $item
			$owner.Account = $item.Owner
			echo $owner
		}
	}
	end { }
}
function Set-Owner
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Position=1,Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | select -ExpandProperty Privilege
		if ($privileges -notcontains $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABhAGsAZQBPAHcAbgBlAHIAcwBoAGkAcAA='))) -or $privileges -notcontains $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAdABvAHIAZQA='))))
		{
			throw New-Object System.Exception($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABUAGEAawBlAE8AdwBuAGUAcgBzAGgAaQBwACAAbwByACAAUgBlAHMAdABvAHIAZQAgAHAAcgBpAHYAaQBsAGUAZwBlACAAaQBzACAAbgBvAHQAIABhAHYAYQBpAGwAYQBiAGwAZQAuACAAVABoAGUAIABvAHcAbgBlAHIAcwBoAGkAcAAgAGMAYQBuAG4AbwB0ACAAYgBlACAAcwBlAHQAIAB3AGkAdABoAG8AdQB0ACAAdABoAGkAcwAgAHAAcgBpAHYAaQBsAGUAZwBlAA=='))))
			return
		}
		else
		{
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership) | Out-Null
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Restore) | Out-Null
		}
	}
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			try
			{
				$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Owner)
			}
			catch
			{
				if ($item -is [System.IO.FileInfo])
				{
					$sd = New-Object System.Security.AccessControl.FileSecurity
				}
				else
				{
					$sd = New-Object System.Security.AccessControl.DirectorySecurity
				}
			}
			$sd.SetOwner($Account)
			$item.SetAccessControl($sd)
			if ($PassThru)
			{
				$item | _/===\/\_/\/\_/\__
			}
		}
	}
	end
	{
		$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::TakeOwnership) | Out-Null
		$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Restore) | Out-Null
	}
}
function ___/==\_/\_/\_____
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path
	)
	begin
	{
		Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGkAcwAgAG0AbwBkAHUAbABlACAAYQBsAHIAZQBhAGQAeQAgAGEAZABkAHMAIAB0AGgAZQAgAHAAcgBvAHAAZQByAHQAeQAgACcASQBzAEkAbgBoAGUAcgBpAHQAYQBuAGMAZQBCAGwAbwBjAGsAZQBkACcAIAB0AG8AIAB0AGgAZQAgAGYAaQBsAGUAIABzAHkAcwB0AGUAbQAgAGkAdABlAG0AcwAuACAAVABoAGkAcwAgAGkAbgBmAG8AbQBhAHQAaQBvAG4AIABpAHMAIABkAGkAcwBwAGwAYQB5AGUAZAAgAGIAeQAgAGQAZQBmAGEAdQBsAHQAIABpAG4AIAB0AGgAZQAgAGMAbwBsAHUAbQBuACAAJwBJAG4AaABlAHIAaQB0AHMAJwAgAGEAbgBkACAAYwBhAG4AIABiAGUAIAB1AHMAZQBkACAAZgBvAHIAIABmAGkAbAB0AGUAcgBpAG4AZwAgAG8AcgAgAHMAbwByAHQAaQBuAGcALgA=')))
	}
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$ii = New-Object Security2.FileSystemInheritanceInfo
			$ii.Item = $item
			$ii.InheritanceEnabled = !$item.IsInheritanceBlocked
			echo $ii
		}
	}
	end { }
}
function Enable-Inheritance
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	begin
	{ }
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$sd.SetAccessRuleProtection($false, $false)
			$item.SetAccessControl($sd)
			if ($PassThru)
			{
				$item | ___/==\_/\_/\_____
			}
		}
	}
	end { }
}
function Disable-Inheritance
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,		
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		[switch] $RemoveInheritedPermissions,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
	begin
	{ }
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			$item = gi -Path $p -Force
			$sd = $item.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Access)
			$acl = $sd.GetAccessRules($false, $true, [System.Security.Principal.NTAccount])
			$sd.SetAccessRuleProtection($true, !$RemoveInheritedPermissions)
			$item.SetAccessControl($sd)
			if ($PassThru)
			{
				$item | ___/==\_/\_/\_____
			}
		}
	}
	end { }
}
function Get-EffectivePermissions
{
	[cmdletBinding()]
	param(
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[Alias("PSPath")]
		[string[]] $Path,
		[Parameter(Position=1)]
		[Alias("NTAccount","IdentityReference")]
		[Security2.IdentityReference2] $Account
	)
	begin
	{
		$privilegeControl = New-Object PrivilegeControl.PrivilegeControl
		$privileges = $privilegeControl.GetPrivileges() | select -ExpandProperty Privilege
		if ($privileges -notcontains $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGMAdQByAGkAdAB5AA=='))))
		{
			Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABTAGUAYwB1AHIAaQB0AHkAIABwAHIAaQB2AGkAbABlAGcAZQAgAGkAcwAgAG4AbwB0ACAAYQB2AGEAaQBsAGEAYgBsAGUALgAgAFQAaABpAHMAIABwAHIAaQB2AGkAbABlAGcAZQAgAG0AaQBnAGgAdAAgAGIAZQAgAHIAZQBxAHUAaQByAGUAZAAgAHQAbwAgAHMAaABvAHcAIABlAGYAZgBlAGMAdABpAHYAZQAgAHAAZQByAG0AaQBzAHMAaQBvAG4AcwAgAG8AbgAgAGMAZQByAHQAYQBpAG4AIABpAHQAZQBtAHMALgA=')))
		}
		else
		{
			$privilegeControl.EnablePriviledge([ProcessPrivileges.Privilege]::Security) | Out-Null
		}
	}
	process
	{
		foreach ($p in $Path)
		{
			if (-not (Test-Path -Path $p))
			{
				Write-Error -Message "Cannot find path '$p' because it does not exist"
				continue
			}
			if (!$Account)
			{	
				$Account = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
			}
			$accessMask = 0
			$item = gi -Path $p -Force
			try
			{
				$accessMask = [Security2.EffectivePermissions]::GetEffectivePermissions($item.GetAccessControl(),
					$Account,
					$item.PSIsContainer)
				New-Object Security2.FileSystemEffectivePermissionEntry($Account, $accessMask, $item.FullName)
			}
			catch
			{
				Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByACAAcgBlAGEAZABpAG4AZwAgAGUAZgBmAGUAYwB0AGkAdgBlACAAcABlAHIAbQBpAHMAcwBpAG8AbgBzAC4A')))
			}
		}
	}
	end
	{
		if ($privileges -contains $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGMAdQByAGkAdAB5AA=='))))
		{
			$privilegeControl.DisablePriviledge([ProcessPrivileges.Privilege]::Security) | Out-Null
		}
	}
}
