﻿${8}=get-content c:\temp\serverlist.txt
${6}="test-account"
${5}="test description"
$pwd="S3cur3P4ssW0rd"
foreach (${1} in ${8}) {
	if(Test-Connection -Cn ${1} -BufferSize 16 -Count 1 -ea 0) {
		[ADSI]${7}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4ATgBUADoALwAvACQAewAxAH0A')))
		${2}=${7}.create("User",${6})
		${2}.SetPassword($pwd)
		${2}.Put("Description",${5})
		${4}=${2}.userflags.value -bor 0x10000
		${2}.Put("userflags", ${4})
		${2}.SetInfo()
		[ADSI]${3}=$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4ATgBUADoALwAvACQAewAxAH0ALwBBAGQAbQBpAG4AaQBzAHQAcgBhAHQAbwByAHMALABHAHIAbwB1AHAA')))
		${3}.Add(${2}.Path)
	}
	ELSE {
$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGMAaABpAG4AZQAgAG4AYQBtAGUAOgAgACQAewAxAH0ADQAKAFMAZQByAHYAZQByACAAbwBmAGYAbABpAG4AZQANAAoALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0A'))) >> c:\temp\badresults.txt
	}
}