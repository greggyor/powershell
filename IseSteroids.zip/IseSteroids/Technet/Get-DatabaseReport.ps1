﻿
[CmdletBinding()]
param
(
	[Parameter(Position=0,Mandatory=$false,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
	[AllowEmptyString()]
	[String]$ServerName=".",				
	[Parameter(Position=1,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[String]$EmailRelay = ".",		
	[Parameter(Position=2,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[String]$EmailSender='systemreport@localhost',
	[Parameter(Position=3,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[String]$EmailRecipient='default@yourdomain.com',
	[Parameter(Position=4,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[Bool[]]$SendMail=$false,
	[Parameter(Position=5,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[Bool[]]$SaveReport=$false,
	[Parameter(Position=6,Mandatory=$false,ValueFromPipeline=$false,ValueFromPipelineByPropertyName=$true)]
	[String]$ReportName=".\DatabaseStatusReport.html"
)
$mailboxCountThreshold = 100
$dbSizeThreshold = 10GB 
$backupThreshold = 1 
$mbxSizeThreshold = 30MB 
$date = ( Get-Date ).ToString('yyyy/MM/dd') 
$HtmlHeader = @"
<html> 
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>
<title>$($ServerName) Database Report</title>
<STYLE TYPE="text/css">
<!--
td {
font-family: Tahoma;
font-size: 11px;
border-top: 1px solid #999999;
border-right: 1px solid #999999;
border-bottom: 1px solid #999999;
border-left: 1px solid #999999;
padding-top: 0px;
padding-right: 0px;
padding-bottom: 0px;
padding-left: 0px;
}
body {
margin-left: 5px;
margin-top: 5px;
margin-right: 0px;
margin-bottom: 10px;

table {
border: thin solid #000000;
}
-->
</style>
</head>
<body>
<table width='100%'>
<tr bgcolor='#CCCCCC'>
<td colspan='7' height='25' align='center'>
<font face='tahoma' color='#003399' size='4'><strong>Exchange Database Report - $date</strong></font>
</td>
</tr>
</table>
<table width='100%'><tbody>
<tr bgcolor=#CCCCCC>
<td width='10%' align='center'>Database Name</td>
<td width='10%' align='center'>Server</td>
<td width='15%' align='center'>Database File</td>
<td width='10%' align='center'>Database Size(MB)</td>
<td width='7%' align='center'># of Mailboxes</td> 
<td width='10%' align='center'>WhiteSpace(MB)</td>
<td width='10%' align='center'>Top Mailbox</td>
<td width='10%' align='center'>Top Mailbox Size</td> 
<td width='10%' align='center'>Last Full Backup</td>
<td width='15%' align='center'>No Backup Since?</td>
</tr>
"@ 
$HtmlFooter = @"
</table>
</body> 
</html> 
"@ 
Function _/=\/\/===\/\___/=
{
    [CmdletBinding()]
    Param
    (
    [parameter(Mandatory=$False,Position=0)][int64]$Size
    )
    Switch ($Size)
    {
        {$Size -gt 1PB}
        {
            Write-Verbose "Convert to PB"
            $NewSize = "$([math]::Round(($Size / 1PB),2))PB"
            Break
        }
        {$Size -gt 1TB}
        {
            Write-Verbose "Convert to TB"
            $NewSize = "$([math]::Round(($Size / 1TB),2))TB"
            Break
        }
        {$Size -gt 1GB}
        {
            Write-Verbose "Convert to GB"
            $NewSize = "$([math]::Round(($Size / 1GB),2))GB"
            Break
        }
        {$Size -gt 1MB}
        {
            Write-Verbose "Convert to MB"
            $NewSize = "$([math]::Round(($Size / 1MB),2))MB"
            Break
        }
        {$Size -gt 1KB}
        {
            Write-Verbose "Convert to KB"
            $NewSize = "$([math]::Round(($Size / 1KB),2))KB"
            Break
        }
        Default
        {
            Write-Verbose "Convert to Bytes"
            $NewSize = "$([math]::Round($Size,2))Bytes"
            Break
        }
    }
    Return $NewSize
}
Function _/=\__/==\/=\/==== 
{ 
    Param
    (
    	[parameter(Mandatory=$False,Position=0)]
		[string]$ServerName
    )
	 $dbs = Get-MailboxDatabase -Status -Server $ServerName
	 foreach($db in $dbs) 
	 { 
	    $name = $db.name 
	    $svr = $db.servername     
	    $edb = $db.edbfilepath     
	    $edbSize = _/=\/\/===\/\___/= $db.DatabaseSize.tobytes()
	    $whiteSpace = _/=\/\/===\/\___/= $db.AvailableNewMailboxSpace.tobytes()
	    $mbxCount = (Get-Mailbox -Database $db).count 
	    $topMailbox = Get-MailboxStatistics -Database $db.name| ? {$_.totalitemsize -ne $null}|sort TotalItemSize -Descending |select DisplayName -First 1 | ft Displayname -HideTableHeaders | Out-String 
	    $topMailboxSize = Get-MailboxStatistics -Database $db.name| ? {$_.totalitemsize -ne $null} | sort TotalItemSize -Descending | select totalitemsize -First 1 
		$topMailboxSize = _/=\/\/===\/\___/= $topMailboxSize.TotalItemSize.Value.tobytes()
	    $lastBackup =  $db.LastFullBackup; $currentDate = Get-Date 
	    if ($lastBackup -eq $null) 
	    {     
	     $howOldBkp =  $null      
	    } 
	    else 
	    { 
	    $howOldBkp = $currentDate - $lastBackup     
	    $howOldBkp = $howOldBkp.days     
	    } 
	    $TableResults += ____/\_/\_________ $name $svr $edb $edbSize $whiteSpace $mbxCount $topMailbox $topMailboxSize $lastBackup $howOldBkp 
	} 
	Return $TableResults  
} 
Function ____/\_/\_________ 
{ 
	param($name,$svr,$edb,$edbSize,$whiteSpace,$mbxCount,$topMailbox,$topMailboxSize,$lastBackup,$howOldBkp) 
	$tableEntry = "<tr><td>$name</td><td>$svr</td><td>$edb</td>" 
	if ($edbSize -gt $dbSizeThreshold) 
	{ 
	 $edbSize = $edbSize/1mb 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>$edbSize</td>" 
	} 
	else 
	{ 
	 $edbSize = $edbSize/1mb 
	 $tableEntry += "<td bgcolor='#387C44' align=center>$edbSize</td>" 
	} 
	if ($mbxCount -gt $mailboxCountThreshold) 
	{ 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>$mbxCount</td>" 
	} 
	else 
	{ 
	 $tableEntry += "<td bgcolor='#387C44' align=center>$mbxCount</td>" 
	} 
	$tableEntry +=  "<td>$whiteSpace</td>" 
	$tableEntry +=  "<td>$topMailbox</td>" 
	if ($topMailboxSize -gt $mbxSizeThreshold) 
	{ 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>$topMailboxSize</td>" 
	} 
	else 
	{ 
	 $tableEntry += "<td bgcolor='#387C44' align=center>$topMailboxSize</td>" 
	} 
	if ($howOldBkp -eq $null) 
	{ 
	 $tableEntry += "<td bgcolor='#FF0000' align=center> null </td>" 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>Never Backed Up</td>" 
	} 
	elseif ($howOldBkp -le $backupThreshold) 
	{ 
	 $tableEntry += "<td bgcolor='#387C44' align=center>$lastbackup</td>" 
	 $tableEntry += "<td bgcolor='#387C44' align=center>$howOldBkp</td>" 
	} 
	else 
	{ 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>$lastbackup</td>" 
	 $tableEntry += "<td bgcolor='#FF0000' align=center>$howOldBkp</td>" 
	} 
	Return $tableEntry 
} 
$ReportOutput += $HtmlHeader
$ReportOutput += _/=\__/==\/=\/==== $ServerName
$ReportOutput += $HtmlFooter
if ($SendMail)
{
	$HTMLmessage = $ReportOutput | Out-String
	$email= 
	@{
		From = $EmailSender
		To = $EmailRecipient
		Subject = "Exchange Database Report - $ServerName"
		SMTPServer = $EmailRelay
		Body = $HTMLmessage
		Encoding = ([System.Text.Encoding]::UTF8)
		BodyAsHTML = $true
	}
	Send-MailMessage @email
	Sleep -Milliseconds 200
}
elseif ($SaveReport)
{
	$ReportOutput | Out-File $ReportName
}
else
{
   Return $HTMLmessage
}
