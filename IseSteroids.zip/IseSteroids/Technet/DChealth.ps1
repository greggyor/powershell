﻿<#
	** THIS SCRIPT IS PROVIDED WITHOUT WARRANTY, USE AT YOUR OWN RISK **	
    
    .SYNOPSIS
	    Runs DCdiag or Repadmin on your Domain Controller(s).

	.DESCRIPTION
	    This script uses PSremoting and the Invoke-Command CMDlet to remotely run a few commands
        on a particular server and write the results to a logfile. I have included a couple different 
        version of the DCdiag command as well as a couple different versions of repadmin.
        
        As it is it should run in any environment provided you have met the requirements below.

    .REQUIREMENTS
        1.	Powershell remoting must be enabled on the target server, do this by running Enable-PSRemoting -force 
        from your server console.
        2. Proper credentials on the target server.

    .NOTES
        Tested with Windows 7, Windows Vista, Windows Server 2003, Windows Server 2K8 and 2K8 R2

	.AUTHOR
		David Hall | http://www.signalwarrant.com/
		
	.LINK
		
#>

$date = get-date -format M.d.yyyy

$server = Read-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABuAGEAbQBlAA==')))

# Path the where the logs will be stored
$logPath = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAcwBlAHIAdgBlAHIAXwBsAG8AZwBzAFwA'))) + $server + "_" + $date + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBsAG8AZwA=')))

# CMDs that can be ran as a part of this script
$dcdiag = {cmd.exe /c dcdiag}
$dcdiagverbose = {cmd.exe /c dcdiag /v}
$showrepl = {cmd.exe /c repadmin /showrepl}
$replsummary = {cmd.exe /c repadmin /replsummary}

# Error message displayed if an invalid entry is made
$errorMessage = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAqACoAIABJAE4AVgBBAEwASQBEACAARQBOAFQAUgBZACAAKgAqACoA')))

# CMD Selection message
$selectionChoice = Write-Host -foregroundcolor Cyan $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgAgAEMAaABvAG8AcwBlACAAZgByAG8AbQAgAHQAaABlACAAZgBvAGwAbABvAHcAaQBuAGcAIABDAE0ARABzADoAIAAKAA=='))) `
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAgAD0AIABEAEMAZABpAGEAZwAgAAoAIAAyACAAPQAgAEQAQwBkAGkAYQBnACAALwB2ACAAKABEAGUAdABhAGkAbABlAGQAIABpAG4AZgBvAHIAbQBhAHQAaQBvAG4AKQAgAAoAIAAzACAAPQAgAFIAZQBwAEEAZABtAGkAbgAgAC8AcwBoAG8AdwByAGUAcABsACAACgA='))) `
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAgAD0AIABSAGUAcABBAGQAbQBpAG4AIAAvAHIAZQBwAGwAcwB1AG0AbQBhAHIAeQAgAAoA')))`

# CMD input message
$cmdSelection = Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGkAYwBoACAAQwBNAEQA')))

# *** Start CMD Selection Code Block

$cmd = $cmdSelection

if(!($cmd)) {
	Throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABOAE8AIABPAFAAVABJAE8ATgAgAFMARQBMAEUAQwBUAEUARAAgAA==')))
	Exit
}

Switch($cmd) {
	1 {$cmd = $dcdiag}
    2 {$cmd = $dcdiagverbose}
	3 {$cmd = $showrepl}
    4 {$cmd = $replsummary}
	default {
    $errorMessage
    Exit
    }
}
# *** Start CMD Selection Code Block

# Run the chosen command on the server
$command = $cmd
write-host -foregroundcolor yellow $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABsAGUAYQBzAGUAIAB3AGEAaQB0AC4ALgAuACAAUgB1AG4AbgBpAG4AZwAgAGMAbwBtAG0AYQBuAGQA')))
$runCommand = icm -Computername $server -ScriptBlock $command
$runCommand | out-file $logPath -append
write-host -foregroundcolor yellow "Script complete, logfile is located at $logPath"