﻿Function Set-FSMORoleOwner { 
[cmdletbinding( 
    SupportsShouldProcess = 'True', 
    ConfirmImpact = 'High', 
    DefaultParameterSetName = 'Transfer' 
    )]  
Param ( 
    [parameter(Position=1,Mandatory = 'True',ValueFromPipeline = 'True', 
        HelpMessage='Enter the Fully Qualified Domain Name of the Domain Controller')] 
    [ValidateCount(1,1)] 
    [string[]]$DomainController, 
    [parameter(Position=2,Mandatory = 'True', 
        HelpMessage = "InfrastructureRole,NamingRole,PdcRole,RidRole,SchemaRole")] 
    [Alias('fsmo','fsmorole')] 
    [ValidateSet('InfrastructureRole','NamingRole','PdcRole','RidRole','SchemaRole')] 
    [ValidateCount(1,5)] 
    [string[]]$Role, 
    [parameter(Position=4,ParameterSetName='Transfer')] 
    [Switch]$Transfer,     
    [parameter(Position=4,ParameterSetName='Seize')] 
    [Switch]$Seize, 
    [parameter(Position=5)] 
    [switch]$PassThru 
    ) 
Begin {} 
Process { 
    Try { 
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AbgBlAGMAdABpAG4AZwAgAHQAbwAgAEYAbwByAGUAcwB0AA=='))) 
        $forest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest() 
        Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGMAYQB0AGkAbgBnACAAJABEAG8AbQBhAGkAbgBDAG8AbgB0AHIAbwBsAGwAZQByAA==')))  
        $dc = $forest.domains | ForEach { 
            $_.Domaincontrollers | Where { 
                $_.Name -eq $DomainController 
                } 
            } 
        } 
    Catch { 
        Write-Warning "$($Error)" 
        Break 
        } 
    If (-NOT [string]::IsNullOrEmpty($dc)) { 
        ForEach ($r in $role) { 
            Switch ($PScmdlet.ParameterSetName) { 
               $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAGEAbgBzAGYAZQByAA=='))) { 
                Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBlAGcAaQBuAG4AaQBuAGcAIAB0AHIAYQBuAHMAZgBlAHIAIABvAGYAIAAkAHIAIAB0AG8AIAAkAEQAbwBtAGEAaQBuAEMAbwBuAHQAcgBvAGwAbABlAHIA'))) 
                    If ($PScmdlet.ShouldProcess($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABEAG8AbQBhAGkAbgBDAG8AbgB0AHIAbwBsAGwAZQByAA=='))),"Transfer Role: $($Role)")) { 
                        Try { 
                            $dc.TransferRoleOwnership($r) 
                            } 
                        Catch { 
                            Write-Warning "$($Error[0])" 
                            Break 
                            } 
                        } 
                    } 
                $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGkAegBlAA=='))) { 
                    Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABlAHIAZgBvAHIAbQBpAG4AZwAgAHQAaABpAHMAIABhAGMAdABpAG8AbgAgAGkAcwAgAGkAcgByAGUAdgBlAHIAcwBpAGIAbABlACEACgBUAGgAZQAgAEQAbwBtAGEAaQBuACAAQwBvAG4AdAByAG8AbABsAGUAcgAgAHQAaABhAHQAIABvAHIAaQBnAGkAbgBhAGwAbAB5ACAAaABvAGwAZABzACAAdABoAGkAcwAgAHIAbwBsAGUAIABzAGgAbwB1AGwAZAAgAGIAZQAgAHIAZQBiAHUAaQBsAHQAIAB0AG8AIABhAHYAbwBpAGQAIABpAHMAcwB1AGUAcwAgAG8AbgAgAHQAaABlACAAZABvAG0AYQBpAG4AIQA='))) 
                    Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGkAegBpAG4AZwAgACQAcgAgAGEAbgBkACAAcABsAGEAYwBpAG4AZwAgAG8AbgAgACQARABvAG0AYQBpAG4AQwBvAG4AdAByAG8AbABsAGUAcgA='))) 
                    If ($PScmdlet.ShouldProcess($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABEAG8AbQBhAGkAbgBDAG8AbgB0AHIAbwBsAGwAZQByAA=='))),"Seize Role: $($Role)")) { 
                        Try { 
                            $dc.SeizeRoleOwnership($r) 
                            } 
                        Catch { 
                            Write-Warning "$($Error[0])" 
                            Break 
                            } 
                        }                
                    } 
                Default { 
                    Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIABtAHUAcwB0ACAAcwBwAGUAYwBpAGYAeQAgAGUAaQB0AGgAZQByACAALQBUAHIAYQBuAHMAZgBlAHIAIABvAHIAIAAtAFMAZQBpAHoAZQAhAA=='))) 
                    Break 
                    } 
                } 
            } 
        } 
    Else { 
        Write-Warning $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGEAYgBsAGUAIAB0AG8AIABsAG8AYwBhAHQAZQAgACQARABvAG0AYQBpAG4AQwBvAG4AdAByAG8AbABsAGUAcgAhAA=='))) 
        Break 
        } 
    } 
End { 
    If ($PSBoundParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHMAcwBUAGgAcgB1AA==')))]) { 
        $forest = [system.directoryservices.activedirectory.Forest]::GetCurrentForest() 
        ForEach ($domain in $forest.domains) { 
            $forestproperties = @{ 
                Forest = $Forest.name  
                Domain = $domain.name  
                SchemaRole = $forest.SchemaRoleOwner  
                NamingRole = $forest.NamingRoleOwner  
                RidRole = $Domain.RidRoleOwner  
                PdcRole = $Domain.PdcRoleOwner  
                InfrastructureRole = $Domain.InfrastructureRoleOwner  
                } 
            $newobject = New-Object PSObject -Property $forestproperties 
            $newobject.PSTypeNames.Insert(0,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQAUgBvAGwAZQBzAA==')))) 
            $newobject         
            } 
        } 
    } 
}