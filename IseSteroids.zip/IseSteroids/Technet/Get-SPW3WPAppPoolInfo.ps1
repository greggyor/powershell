﻿Function Get-SPW3WPAppPoolInfo
{
  [CmdletBinding()]
      Param(
      [Parameter(Position=0, Mandatory=$false, ValueFromPipeline=$true, ValueFromPipelinebyPropertyName=$true)]
      [int]$W3WPID 
      )
      Begin {
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAGkAbgBnACAAQgBlAGcAaQBuACAAQgBsAG8AYwBrAA==')))
        If (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAG0AaQBuAGkAcwB0AHIAYQB0AG8AcgA=')))))
        {
           Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBvAHUAIABkAG8AIABuAG8AdAAgAGgAYQB2AGUAIABBAGQAbQBpAG4AaQBzAHQAcgBhAHQAbwByACAAcgBpAGcAaAB0AHMAIAB0AG8AIAByAHUAbgAgAHQAaABpAHMAIABzAGMAcgBpAHAAdAAhAAoAUABsAGUAYQBzAGUAIAByAGUALQByAHUAbgAgAHQAaABpAHMAIABzAGMAcgBpAHAAdAAgAGEAcwAgAGEAbgAgAEEAZABtAGkAbgBpAHMAdAByAGEAdABvAHIAIQA=')))
           Exit
        }
        try {
            $isSPPowerShellLoadedOnStart = $null
            $SPSnapin = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAGgAYQByAGUAUABvAGkAbgB0AC4AUABvAHcAZQByAFMAaABlAGwAbAA=')))
            if (Get-PSSnapin $SPSnapin -ErrorAction SilentlyContinue) {
            $isSPPowerShellLoadedOnStart = $true
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAGgAYQByAGUAUABvAGkAbgB0AC4AUABvAHcAZQByAFMAaABlAGwAbAAgAFMAbgBhAHAAcABpAG4AIABhAGwAcgBlAGEAZAB5ACAAcgBlAGcAaQBzAHQAZQByAGUAZAAgAGEAbgBkACAAbABvAGEAZABlAGQA')))
            }
            elseif (Get-PSSnapin $SPSnapin -Registered -ErrorAction SilentlyContinue) {
            $isSPPowerShellLoadedOnStart = $false
                Add-PSSnapin $SPSnapin 
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAGgAYQByAGUAUABvAGkAbgB0AC4AUABvAHcAZQByAFMAaABlAGwAbAAgAFMAbgBhAHAAcABpAG4AIABpAHMAIAByAGUAZwBpAHMAdABlAHIAZQBkACAAYQBuAGQAIABoAGEAcwAgAGIAZQBlAG4AIABsAG8AYQBkAGUAZAAgAGYAbwByACAAcwBjAHIAaQBwAHQAIABvAHAAZQByAGEAdABpAG8AbgA=')))
            }
            else {
                Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAGgAYQByAGUAUABvAGkAbgB0AC4AUABvAHcAZQByAFMAaABlAGwAbAAgAFMAbgBhAHAAcABpAG4AIABuAG8AdAAgAGYAbwB1AG4AZAAuACAARQB4AGkAdAAgAGYAdQBuAGMAdABpAG8AbgAuAA==')))
                Exit
            }
        }
        catch [System.Exception] {
            Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAcgBlACAAdwBhAHMAIABhAG4AIABpAHMAcwB1AGUAIABsAG8AYQBkAGkAbgBnACAAdABoAGUAIABNAGkAYwByAG8AcwBvAGYAdAAuAFMAaABhAHIAZQBQAG8AaQBuAHQALgBQAG8AdwBlAHIAUwBoAGUAbABsACAAUwBuAGEAcABwAGkAbgAuACAARQB4AGkAdAAgAGYAdQBuAGMAdABpAG8AbgAuAA==')))
            Exit
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAGEAdgBpAG4AZwAgAEIAZQBnAGkAbgAgAEIAbABvAGMAawA=')))
      } 
      Process {
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAGkAbgBnACAAUAByAG8AYwBlAHMAcwAgAEIAbABvAGMAawA=')))
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAYQBuACAAQQByAHIAYQB5AEwAaQBzAHQAIAB0AG8AIABzAHQAbwByAGUAIABjAHUAcwB0AG8AbQAgAFAAUwBPAGIAagBlAGMAdABzAA==')))
        $processCollection = New-Object System.Collections.ArrayList
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAHQAZQByAG0AaQBuAGUAIAB3AGgAZQB0AGgAZQByACAAVwAzAFcAUABJAEQAIABQAGEAcgBhAG0AZQB0AGUAcgAgAGgAYQBzACAAYgBlAGUAbgAgAHAAcgBvAHYAaQBkAGUAZAAgAGIAeQAgAHUAcwBlAHIA')))
        $W3WPProcessSupplied = $false
        if($W3WPID) {
            $W3WPProcessSupplied = $true
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBlAHQAYwBoACAAcgB1AG4AbgBpAG4AZwAgAHcAMwB3AHAALgBlAHgAZQAgAHAAcgBvAGMAZQBzAHMAZQBzACAAdQBzAGkAbgBnACAAVwBNAEkA'))) 
        $w3wpProcesses = $null
        if($W3WPProcessSupplied) {
            $w3wpProcesses = gwmi Win32_Process | where {$_.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwAzAHcAcAAuAGUAeABlAA=='))) -and $_.ProcessId -eq $W3WPID}
        }
        else {
            $w3wpProcesses = gwmi Win32_Process | where {$_.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dwAzAHcAcAAuAGUAeABlAA==')))}
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBlAHQAYwBoACAAVwBvAHIAawBlAHIAIABQAHIAbwBjAGUAcwBzAGUAcwAgAGYAcgBvAG0AIABJAEkAUwAgAHUAcwBpAG4AZwAgAFcATQBJAA==')))
        $iisWorkerProcesses = $null
        if($W3WPProcessSupplied) {
            $iisWorkerProcesses = gwmi -Class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHIAawBlAHIAUAByAG8AYwBlAHMAcwA='))) -NameSpace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAFcAZQBiAEEAZABtAGkAbgBpAHMAdAByAGEAdABpAG8AbgA='))) | where {$_.ProcessId -eq $W3WPID}
        }
        else {
            $iisWorkerProcesses = gwmi -Class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHIAawBlAHIAUAByAG8AYwBlAHMAcwA='))) -NameSpace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAFcAZQBiAEEAZABtAGkAbgBpAHMAdAByAGEAdABpAG8AbgA=')))
        } 
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAGkAbgBnACAAZgBvAHIAZQBhAGMAaAAgAGwAbwBvAHAAIAAtACAAcAByAG8AYwBlAHMAcwAgAGUAYQBjAGgAIAB3ADMAdwBwAC4AZQB4AGUAIABwAHIAbwBjAGUAcwBzAA=='))) 
        foreach($w3wpProcess in $w3wpProcesses) {
            $processID = $w3wpProcess.ProcessId
            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBXADMAVwBQAC4AZQB4AGUAIABQAHIAbwBjAGUAcwBzADoAIAAkAFAAcgBvAGMAZQBzAHMASQBkAA=='))) 
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAEQAbwBtAGEAaQBuAFwAVQBzAGUAcgBuAGEAbQBlACAAaQBuAGYAbwByAG0AYQB0AGkAbwBuAA==')))
            $processAccount = $w3wpProcess.GetOwner().User
            $processDomain = $w3wpProcess.GetOwner().Domain
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHcAMwB3AHAALgBlAHgAZQAgAHAAcgBvAGMAZQBzAHMAIAB1AHMAaQBuAGcAIABHAGUAdAAtAFAAcgBvAGMAZQBzAHMAIABjAG0AZABsAGUAdAAgACgAUwB5AHMAdABlAG0ALgBEAGkAYQBnAG4AbwBzAHQAaQBjAHMALgBQAHIAbwBjAGUAcwBzACkA')))
            $w3wpGetProcess = ps w3wp | where {$_.Id -eq $w3wpProcess.ProcessId}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHQAaABlACAASQBJAFMAIABXAG8AcgBrAGUAcgAgAFAAcgBvAGMAZQBzAHMAIABhAHMAcwBvAGMAaQBhAHQAZQBkACAAdwBpAHQAaAAgAGkAbgBzAHQAYQBuAGMAZQAgAG8AZgAgAHcAMwB3AHAALgBlAHgAZQA=')))
            $iisWorkerProcess = $iisWorkerProcesses | where {$_.ProcessId -eq $w3wpProcess.ProcessId}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHQAaABlACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuACAAUABvAG8AbAAgAE4AYQBtAGUAIABmAHIAbwBtACAAdABoAGUAIABJAEkAUwAgAFcAbwByAGsAZQByACAAUAByAG8AYwBlAHMAcwA=')))
            $iisAppPoolName = $iisWorkerProcesses | where {$_.ProcessId -eq $w3wpProcess.ProcessId} | select -expand AppPoolName 
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHQAaABlACAAdwAzAHcAcAAuAGUAeABlACAAcAByAG8AYwBlAHMAcwAgAEMAbwBtAG0AYQBuAGQAIABMAGkAbgBlACAAQQByAGcAdQBtAGUAbgB0AHMA')))
            $w3wpCommandLine = $w3wpProcess.CommandLine
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEMAcgBlAGEAdABpAG4AZwAgAG4AZQB3ACAAUABTAE8AYgBqAGUAYwB0AA==')))
                $object = New-Object PSObject -Property @{        
                    W3WPID                = $w3wpProcess.ProcessId
                    W3WPProcessWMI        = $w3wpProcess
                    W3WPProcess           = $w3wpGetProcess
                    WorkerProcessWMI      = $iisWorkerProcess
                    W3WPCommandLine       = $w3wpCommandLine
                    isSharePoint          = $false                              
                    IISAppPoolName        = $iisAppPoolName
                    SPAppPoolFriendlyName = ""
                    ProcessDomain         = $processDomain
                    ProcessAccount        = $processAccount
                    ProcessAccountName    = $processDomain + "\" + $processAccount                
                 }
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEEAZABkACAAbgBlAHcAIABQAFMATwBiAGoAZQBjAHQAIABpAG4AdABvACAAdABoAGUAIABBAHIAcgBhAHkATABpAHMAdAA=')))
            $processCollection.Add($object) | Out-Null
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAGEAdgBpAG4AZwAgAGYAbwByAGUAYQBjAGgAIABsAG8AbwBwACAALQAgAGQAbwBuAGUAIABwAHIAbwBjAGUAcwBzAGkAbgBnACAAZQBhAGMAaAAgAHcAMwB3AHAALgBlAHgAZQAgAHAAcgBvAGMAZQBzAHMA')))
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBlAHQAYwBoACAAUwBoAGEAcgBlAFAAbwBpAG4AdAAgAFcAZQBiACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuAHMA')))
        $webapplications = Get-SPWebApplication -includecentraladministration
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAGkAbgBnACAAZgBvAHIAZQBhAGMAaAAgAGwAbwBvAHAAIAAtACAAcAByAG8AYwBlAHMAcwAgAGUAYQBjAGgAIABTAGgAYQByAGUAUABvAGkAbgB0ACAAVwBlAGIAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4A'))) 
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAIABtAHUAcwB0ACAAYgBlACAAaQBuAHMAcABlAGMAdABlAGQAIABhAHMAIAB3AGUAIABkAG8AbgAnAHQAIABrAG4AbwB3ACAAYQB0ACAAYQBuAHkAIABnAGkAdgBlAG4AIABtAG8AbQBlAG4AdAAgAHcAaABpAGMAaAAgAFcAZQBiACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuAHMAIAB3AGkAbABsACAAaABhAHYAZQAgAGEAIABsAGkAdgBlACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuACAAUABvAG8AbAA=')))
        foreach($webapplication in $webapplications) {
            $webAppDisplayName = $webapplication.DisplayName
            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBTAGgAYQByAGUAUABvAGkAbgB0ACAAVwBlAGIAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AOgAgACQAdwBlAGIAQQBwAHAARABpAHMAcABsAGEAeQBOAGEAbQBlAA=='))) 
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAFMAaABhAHIAZQBQAG8AaQBuAHQAIABXAGUAYgAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgAgAFAAbwBvAGwAIABOAGEAbQBlAA==')))
            $appPoolName = [string]($webapplication.ApplicationPool.Name)
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHQAaABlACAAYQBzAHMAbwBjAGkAYQB0AGUAZAAgAHcAaQBuAF8AMwAyACAAdwAzAHcAcAAuAGUAeABlACAAcAByAG8AYwBlAHMAcwAgAGYAcgBvAG0AIAB0AGgAZQAgAFcATQBJACAAYwBvAGwAbABlAGMAdABpAG8AbgA=')))
            $w3wpProcess = $processCollection | where {$_.IISAppPoolName -eq $appPoolName}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAHQAaABlACAAYQBzAHMAbwBjAGkAYQB0AGUAZAAgAHcAaQBuAF8AMwAyACAAdwAzAHcAcAAuAGUAeABlACAAcAByAG8AYwBlAHMAcwAgAEkARAAgAGYAcgBvAG0AIAB0AGgAZQAgAFcATQBJACAAYwBvAGwAbABlAGMAdABpAG8AbgA=')))
            $w3wpProcessID = $w3wpProcess.W3WPID
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEQAZQB0AGUAcgBtAGkAbgBlACAAdABoAGUAIABBAHIAcgBhAHkATABpAHMAdAAgAG8AYgBqAGUAYwB0ACAAaQBuAGQAZQB4ACAAbgB1AG0AYgBlAHIAIABmAG8AcgAgAHQAaABlACAAdwAzAHcAcAAuAGUAeABlACAAcAByAG8AYwBlAHMAcwAgAGEAcwBzAG8AYwBpAGEAdABlAGQAIAB3AGkAdABoACAAdABoAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsACAAZgBvAHIAIAB0AGgAaQBzACAAVwBlAGIAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4ALAAgAGkAZgAgAGkAdAAgAGUAeABpAHMAdABzAA==')))
            $indexCounter=0
            $indexSelected = -1
            $processCollection | foreach-object {if($_.W3WPID -eq $w3wpProcessID) { $indexSelected = $indexCounter;} $indexCounter++}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEkAZgAgAHQAaABlAHIAZQAgAGkAcwAgAGEAbgAgAGwAaQB2AGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsACAAZgBvAHIAIAB0AGgAaQBzACAAVwBlAGIAIABBAHAAcAAsACAAZQBuAHMAdQByAGUAIAB0AGgAZQAgACcAUwBQAEEAcABwAFAAbwBvAGwARgByAGkAZQBuAGQAbAB5AE4AYQBtAGUAJwAgAGEAbgBkACAAJwBpAHMAUwBoAGEAcgBlAFAAbwBpAG4AdAAnACAAUABTAE8AYgBqAGUAYwB0ACAAcAByAG8AcABlAHIAdABpAGUAcwAgAGEAcgBlACAAcABvAHAAdQBsAGEAdABlAGQALgA=')))
            if($indexSelected -ne -1) {         
            $curValue = $processCollection[[int]$indexSelected].SPAppPoolFriendlyName
                if($curValue -eq "") {
                    $processCollection[[int]$indexSelected].SPAppPoolFriendlyName = $appPoolName
                    $processCollection[[int]$indexSelected].isSharePoint = $true
                }
            }
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAGEAdgBpAG4AZwAgAGYAbwByAGUAYQBjAGgAIABsAG8AbwBwACAALQAgAGQAbwBuAGUAIABwAHIAbwBjAGUAcwBzAGkAbgBnACAAUwBoAGEAcgBlAFAAbwBpAG4AdAAgAFcAZQBiACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuAHMA')))
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBlAHQAYwBoACAAUwBoAGEAcgBlAFAAbwBpAG4AdAAgAFMAZQByAHYAaQBjAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AcwAgAHcAaABpAGMAaAAgAHUAdABpAGwAaQB6AGUAIABhAG4AIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsACAAaQBuACAASQBJAFMA')))
        $serviceapplications = Get-SPServiceApplication | where {$_.ApplicationPool -ne $null}
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAGkAbgBnACAAZgBvAHIAZQBhAGMAaAAgAGwAbwBvAHAAIAAtACAAcAByAG8AYwBlAHMAcwAgAGUAYQBjAGgAIABTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAHIAdgBpAGMAZQAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgA='))) 
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAIABtAHUAcwB0ACAAYgBlACAAaQBuAHMAcABlAGMAdABlAGQAIABhAHMAIAB3AGUAIABkAG8AbgAnAHQAIABrAG4AbwB3ACAAYQB0ACAAYQBuAHkAIABnAGkAdgBlAG4AIABtAG8AbQBlAG4AdAAgAHcAaABpAGMAaAAgAFMAZQByAHYAaQBjAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AcwAgAHcAaQBsAGwAIABoAGEAdgBlACAAYQAgAGwAaQB2AGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsAA==')))
        foreach($serviceapplication in $serviceapplications) {
            $serviceAppDisplayName = $serviceapplication.DisplayName
            Write-Verbose $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBTAGgAYQByAGUAUABvAGkAbgB0ACAAUwBlAHIAdgBpAGMAZQAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgA6ACAAJABzAGUAcgB2AGkAYwBlAEEAcABwAEQAaQBzAHAAbABhAHkATgBhAG0AZQA='))) 
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAFMAZQByAHYAaQBjAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsACAAbgBhAG0AZQAuACAAUwBvAG0AZQAgAGEAcABwACAAcABvAG8AbABzACAAdQBzAGUAIAB0AGgAZQAgAGYAcgBpAGUAbgBkAGwAeQAgAG4AYQBtAGUAIABhAHMAIAB0AGgAZQAgAGEAcABwACAAcABvAG8AbAAgAG4AYQBtAGUAIABpAG4AIABJAEkAUwA=')))             
            $appPoolFriendlyName = [string]($serviceapplication.ApplicationPool.Name)
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEYAZQB0AGMAaAAgAFMAZQByAHYAaQBjAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIABQAG8AbwBsACAARwB1AGkAZAAuACAAUwBvAG0AZQAgAGEAcABwACAAcABvAG8AbABzACAAdQBzAGUAIAB0AGgAZQAgAGcAdQBpAGQAIABhAHMAIAB0AGgAZQAgAGEAcABwACAAcABvAG8AbAAgAG4AYQBtAGUAIABpAG4AIABJAEkAUwAgACgAdwBpAHQAaAAgAGQAYQBzAGgAZQBzACAAcwB0AHIAaQBwAHAAZQBkACkA')))
            $appPoolGuidName = ([string]$serviceapplication.ApplicationPool.Id).Replace("-","")
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEMAaABlAGMAawAgAEYAcgBpAGUAbgBkAGwAeQAgAGEAbgBkACAARwB1AGkAZAAgAG4AYQBtAGUAcwAgAGEAZwBhAGkAbgBzAHQAIABJAEkAUwAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgAgAFAAbwBvAGwAcwAgAHQAbwAgAG0AYQBrAGUAIABhAG4AIABhAHMAcwBvAGMAaQBhAHQAaQBvAG4A')))
            $checkFriendlyName = $iisWorkerProcess | where {$_.AppPoolName -eq $appPoolFriendlyName}
            $checkGuidName     = $iisWorkerProcess | where {$_.AppPoolName -eq $appPoolGuidName}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEQAZQB0AGUAcgBtAGkAbgBlACAAUwBlAHIAdgBpAGMAZQAgAEEAcABwAGwAaQBjAGEAdABpAG8AbgAgAFAAbwBvAGwAIAB3ADMAdwBwAC4AZQB4AGUAIABwAHIAbwBjAGUAcwBzAA==')))
            $w3wpProcessID = $null
            if($checkFriendlyName -ne "") {
                $w3wpProcessID = $checkFriendlyName.ProcessID
            }
            elseif($checkGuidName -ne "") {
                $w3wpProcessID = $checkGuidName.ProcessID
            }
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEQAZQB0AGUAcgBtAGkAbgBlACAAdABoAGUAIABBAHIAcgBhAHkATABpAHMAdAAgAG8AYgBqAGUAYwB0ACAAaQBuAGQAZQB4ACAAbgB1AG0AYgBlAHIAIABmAG8AcgAgAHQAaABlACAAdwAzAHcAcAAuAGUAeABlACAAcAByAG8AYwBlAHMAcwAgAGEAcwBzAG8AYwBpAGEAdABlAGQAIAB3AGkAdABoACAAdABoAGUAIABBAHAAcAAgAFAAbwBvAGwAIABmAG8AcgAgAHQAaABpAHMAIABTAGUAcgB2AGkAYwBlACAAQQBwAHAALAAgAGkAZgAgAGkAdAAgAGUAeABpAHMAdABzAA==')))
            $indexCounter=0
            $indexSelected = $null
            $processCollection | foreach-object {if($_.W3WPID -eq $w3wpProcessID) { $indexSelected = $indexCounter;} $indexCounter++}
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAEkAZgAgAHQAaABlAHIAZQAgAGkAcwAgAGEAbgAgAGwAaQB2AGUAIABBAHAAcAAgAFAAbwBvAGwAIABmAG8AcgAgAHQAaABpAHMAIABTAGUAcgB2AGkAYwBlACAAQQBwAHAALAAgAGUAbgBzAHUAcgBlACAAdABoAGUAIAAnAFMAUABBAHAAcABQAG8AbwBsAEYAcgBpAGUAbgBkAGwAeQBOAGEAbQBlACcAIABhAG4AZAAgACcAaQBzAFMAaABhAHIAZQBQAG8AaQBuAHQAJwAgAFAAUwBPAGIAagBlAGMAdAAgAHAAcgBvAHAAZQByAHQAaQBlAHMAIABhAHIAZQAgAHAAbwBwAHUAbABhAHQAZQBkAC4A')))
            $curValue = $processCollection[[int]$indexSelected].SPAppPoolFriendlyName
            if($curValue -eq "") { 
                $processCollection[[int]$indexSelected].SPAppPoolFriendlyName = $appPoolFriendlyName
                $processCollection[[int]$indexSelected].isSharePoint = $true
            }
        }
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAGEAdgBpAG4AZwAgAGYAbwByAGUAYQBjAGgAIABsAG8AbwBwACAALQAgAGQAbwBuAGUAIABwAHIAbwBjAGUAcwBzAGkAbgBnACAAUwBoAGEAcgBlAFAAbwBpAG4AdAAgAFMAZQByAHYAaQBjAGUAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AcwA=')))
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIAB0AGgAZQAgAHAAaQBwAGUAbABpAG4AZQAgAG8AdQB0AHAAdQB0ACAALQAgAHMAZQBsAGUAYwB0ACAAYQBuAGQAIABmAGkAbAB0AGUAcgAgAHQAaABlACAAQQByAHIAYQB5AEwAaQBzAHQAIABvAGIAagBlAGMAdABzAA==')))
        $pipelineOutput = $null
        $pipelineOutput = $processCollection |  select W3WPID, w3wpProcess, w3wpProcessWMI, WorkerProcessWMI, W3WPCommandLine, isSharePoint, IISAppPoolName, SPAppPoolFriendlyName, ProcessDomain, ProcessAccount, ProcessAccountName | sort w3wpid
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAG4AZAAgAHQAaABlACAAcABpAHAAZQBsAGkAbgBlACAAbwB1AHQAcAB1AHQAIAB0AG8AIAB0AGgAZQAgAHAAaQBwAGUAbABpAG4AZQA=')))
        echo $pipelineOutput 
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABlAGEAdgBpAG4AZwAgAFAAcgBvAGMAZQBzAHMAIABCAGwAbwBjAGsA')))
    } 
} 