﻿ls -Path $PSScriptRoot\*.ps1 | Foreach-Object{ . $_.FullName }

nal Send-FTPItem Add-FTPItem
nal Receive-FTPItem Get-FTPItem

Export-ModuleMember -Function * -Alias *