﻿function Configure-PerformanceMonitor {



[CmdletBinding(
    SupportsShouldProcess=$True,
    ConfirmImpact='High')]

param (

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    $ComputerName = $env:computername,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    $PerfLogDir = "C:\PerfLogs",

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Counter')]
    $CounterFileName = "Counter.txt",

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Name')]        
    $DataCollectorName = "Performance_Overview",
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('SI')]
    $SampleInterval = "00:05:00",

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('M')]
    $MaximumSize = "250",
        
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('NonStop','Continuous')]
    [Switch] $AutoStartup,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Show')]
    [Switch] $ShowCounter,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]

    [Switch] $Start,
    
    

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('AD')]
    [Switch] $ActiveDirectory,
            
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('ASP')]
    [Switch] $ActiveServerPages,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $ASPNET,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Biz')]
    [Switch] $BizTalk,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('DAX2012')]
    [Switch] $DynamicAX2012,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('DAX')]
    [Switch] $DynamicAX,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2003')]
    [Switch] $Exchange2003,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007')]
    [Switch] $Exchange2007,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2010')]
    [Switch] $Exchange2010,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007CAS')]
    [Switch] $Exchange2007CAS,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007CASTechnet')]
    [Switch] $Exchange2007CAS_Technet,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007EdgeTechnet')]
    [Switch] $Exchange2007Edge_Technet,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007Hub')]
    [Switch] $Exchange2007Hub,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007HubTechnet')]
    [Switch] $Exchange2007Hub_Technet,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007MBX')]
    [Switch] $Exchange2007Mailbox,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007MBXTechnet')]
    [Switch] $Exchange2007Mailbox_Technet,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('EXC2007UMTechnet')]
    [Switch] $Exchange2007UM_Technet,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('FAST', 'FAST2010')]
    [Switch] $FASTSearch,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('TMG')]
    [Switch] $Forefront_TMG,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $HyperV,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $HyperV2012,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('IIS')]
    [Switch] $InternetInformationServices,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('SHP', 'SharePoint')]
    [Switch] $MOSS2007,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('MSSearch')]
    [Switch] $MOSS2007_MSSearch,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('SHP2010', 'SharePoint2010')]
    [Switch] $MOSS2010,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $OCS2007R2Archiving,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $OCS2007R2CWA,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $OCS2007R2Edge,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('OCS2007R2Ent')]
    [Switch] $OCS2007R2Enterprise,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $OCS2007R2Mediation,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $OCS2007R2Monitoring,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('OCS2007R2Std')]
    [Switch] $OCS2007R2Standard,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('SQL')]
    [Switch] $SQLServer,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Generic')]
    [Switch] $SystemOverview,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Quick')]
    [Switch] $SystemOverview_Quick,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('Standard')]
    [Switch] $SystemOverview_Standard,
    
[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    [Alias('VM')]
    [Switch] $VMWare,

[Parameter(
    Mandatory=$False,
    ValueFromPipeline=$True,
    ValueFromPipelineByPropertyName=$True)]
    
    [Switch] $XenApp
       
)

BEGIN {}

PROCESS {

    
    
    
    $Object = New-Object PSObject

    
    if($ActiveDirectory) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\AB Client Sessions" -value "\NTDS\AB Client Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\DRA Pending Replication Operations" -value "\NTDS\DRA Pending Replication Operations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\DRA Pending Replication Synchronizations" -value "\NTDS\DRA Pending Replication Synchronizations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\Kerberos Authentications" -value "\NTDS\Kerberos Authentications" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\LDAP Active Threads" -value "\NTDS\LDAP Active Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\LDAP Bind Time" -value "\NTDS\LDAP Bind Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\LDAP Client Sessions" -value "\NTDS\LDAP Client Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NTDS\LDAP Searches/sec" -value "\NTDS\LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(lsass)\% Processor Time" -value "\Process(lsass)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(lsass)\Working Set" -value "\Process(lsass)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Server Sessions" -value "\Server\Server Sessions" -Force
    }
    
    
    
    if($ActiveServerPages) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Active Server Pages\Errors/Sec" -value "\Active Server Pages\Errors/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Active Server Pages\Request Execution Time" -value "\Active Server Pages\Request Execution Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Active Server Pages\Request Wait Time" -value "\Active Server Pages\Request Wait Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Active Server Pages\Requests Queued" -value "\Active Server Pages\Requests Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Active Server Pages\Requests/Sec" -value "\Active Server Pages\Requests/Sec" -Force
    }
    
    
    
    if($ASPNET) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Application Restarts" -value "\ASP.NET\Application Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Request Wait Time" -value "\ASP.NET\Request Wait Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Current" -value "\ASP.NET\Requests Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Applications(*)\Requests In Application Queue" -value "\ASP.NET Applications(*)\Requests In Application Queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Rejected" -value "\ASP.NET\Requests Rejected" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Worker Process Restarts" -value "\ASP.NET\Worker Process Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Applications(*)\Request Execution Time" -value "\ASP.NET Applications(*)\Request Execution Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Apps v2.0.50727(*)\Request Execution Time" -value "\ASP.NET Apps v2.0.50727(*)\Request Execution Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Apps v2.0.50727(*)\Requests In Application Queue" -value "\ASP.NET Apps v2.0.50727(*)\Requests In Application Queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Apps v2.0.50727(*)\Requests/Sec" -value "\ASP.NET Apps v2.0.50727(*)\Requests/Sec" -Force
    }
    
    
    
    if($BizTalk) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High database session" -value "\BizTalk:Message Agent(*)\High database session" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High database size" -value "\BizTalk:Message Agent(*)\High database size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High in-process message count" -value "\BizTalk:Message Agent(*)\High in-process message count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High message delivery rate" -value "\BizTalk:Message Agent(*)\High message delivery rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High message publishing rate" -value "\BizTalk:Message Agent(*)\High message publishing rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High process memory" -value "\BizTalk:Message Agent(*)\High process memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High system memory" -value "\BizTalk:Message Agent(*)\High system memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\High thread count" -value "\BizTalk:Message Agent(*)\High thread count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\Message delivery delay (ms)" -value "\BizTalk:Message Agent(*)\Message delivery delay (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\Message delivery throttling state" -value "\BizTalk:Message Agent(*)\Message delivery throttling state" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\Message publishing delay (ms)" -value "\BizTalk:Message Agent(*)\Message publishing delay (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Agent(*)\Message publishing throttling state" -value "\BizTalk:Message Agent(*)\Message publishing throttling state" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Box:General Counters(*)\Spool Size" -value "\BizTalk:Message Box:General Counters(*)\Spool Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Box:General Counters(*)\Tracking Data Size" -value "\BizTalk:Message Box:General Counters(*)\Tracking Data Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Box:Host Counters(*)\Host Queue - Length" -value "\BizTalk:Message Box:Host Counters(*)\Host Queue - Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Message Box:Host Counters(*)\Host Queue - Suspended Msgs - Length" -value "\BizTalk:Message Box:Host Counters(*)\Host Queue - Suspended Msgs - Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Messaging(*)\ID Process" -value "\BizTalk:Messaging(*)\ID Process" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Messaging Latency(*)\Inbound Latency (sec)" -value "\BizTalk:Messaging Latency(*)\Inbound Latency (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Messaging Latency(*)\Request-Response Latency (sec)" -value "\BizTalk:Messaging Latency(*)\Request-Response Latency (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\BizTalk:Messaging Latency(*)\Outbound Adapter Latency (sec)" -value "\BizTalk:Messaging Latency(*)\Outbound Adapter Latency (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Dehydrating orchestrations" -value "\XLANG/s Orchestrations(*)\Dehydrating orchestrations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Idle orchestrations" -value "\XLANG/s Orchestrations(*)\Idle orchestrations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\MessageBox databases connection failures" -value "\XLANG/s Orchestrations(*)\MessageBox databases connection failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Orchestrations suspended/sec" -value "\XLANG/s Orchestrations(*)\Orchestrations suspended/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Orchestrations completed/sec" -value "\XLANG/s Orchestrations(*)\Orchestrations completed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Orchestrations discarded/sec" -value "\XLANG/s Orchestrations(*)\Orchestrations discarded/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Orchestrations resident in-memory" -value "\XLANG/s Orchestrations(*)\Orchestrations resident in-memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Pending messages" -value "\XLANG/s Orchestrations(*)\Pending messages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Persistence points/sec" -value "\XLANG/s Orchestrations(*)\Persistence points/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Megabytes allocated private memory" -value "\XLANG/s Orchestrations(*)\Megabytes allocated private memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Transactional scopes aborted/sec" -value "\XLANG/s Orchestrations(*)\Transactional scopes aborted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Transactional scopes compensated/sec" -value "\XLANG/s Orchestrations(*)\Transactional scopes compensated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\XLANG/s Orchestrations(*)\Megabytes allocated virtual memory" -value "\XLANG/s Orchestrations(*)\Megabytes allocated virtual memory" -Force
    }
    
    
    
    if($DynamicAX2012) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF CLEARS" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF CLEARS" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF CLEARS TRIGGERED BY AOS DATA SYNCHRONIZATION" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF CLEARS TRIGGERED BY AOS DATA SYNCHRONIZATION" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF DELETES FROM DATA CACHE" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF DELETES FROM DATA CACHE" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF HITS" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF HITS" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF MISSES" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF MISSES" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF SELECTS ON CACHED TABLES" -value "\Microsoft Dynamics AX Object Server(*)\TOTAL NUMBER OF SELECTS ON CACHED TABLES" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Calls" -value "\ServiceModelService 4.0.0.0(*)\Calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Calls Duration" -value "\ServiceModelService 4.0.0.0(*)\Calls Duration" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Calls Failed" -value "\ServiceModelService 4.0.0.0(*)\Calls Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Calls Faulted" -value "\ServiceModelService 4.0.0.0(*)\Calls Faulted" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Calls" -value "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Instances" -value "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Instances" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Sessions" -value "\ServiceModelService 4.0.0.0(*)\Percent Of Max Concurrent Sessions" -Force
    }
    
    
    
    if($DynamicAX) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Active Sessions" -value "\Microsoft Dynamics AX Object Server(*)\Active Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Number of Bytes Received by Server" -value "\Microsoft Dynamics AX Object Server(*)\Number of Bytes Received by Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Number of Bytes Sent by Server" -value "\Microsoft Dynamics AX Object Server(*)\Number of Bytes Sent by Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Number of Client Requests" -value "\Microsoft Dynamics AX Object Server(*)\Number of Client Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Number of Client Requests per Second" -value "\Microsoft Dynamics AX Object Server(*)\Number of Client Requests per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Number of Server Requests" -value "\Microsoft Dynamics AX Object Server(*)\Number of Server Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Microsoft Dynamics AX Object Server(*)\Total Sessions" -value "\Microsoft Dynamics AX Object Server(*)\Total Sessions" -Force
    }
    

    
    if($Exchange2003) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Database Cache Size" -value "\Database(*)\Database Cache Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Database Pages Written/sec" -value "\Database(*)\Database Pages Written/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Log Record Stalls/sec" -value "\Database(*)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Log Threads Waiting" -value "\Database(*)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Log Writes/sec" -value "\Database(*)\Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Epoxy(*)\Client Out Queue Length" -value "\Epoxy(*)\Client Out Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Epoxy(*)\Store Out Queue Length" -value "\Epoxy(*)\Store Out Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Caches(*)\Cache Hits/Sec" -value "\MSExchangeDSAccess Caches(*)\Cache Hits/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSaccess Caches(*)\LDAP Searches/Sec" -value "\MSExchangeDSaccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Domain Controllers(*)\LDAP Read calls/Sec" -value "\MSExchangeDSAccess Domain Controllers(*)\LDAP Read calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchangeDSAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchangeDSAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchangeDSAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Processes(*)\LDAP Read Time" -value "\MSExchangeDSAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeDSAccess Processes(*)\LDAP Search Time" -value "\MSExchangeDSAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Exchmem: Number of Additional Heaps" -value "\MSExchangeIS\Exchmem: Number of Additional Heaps" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Exchmem: Number of heaps with memory errors" -value "\MSExchangeIS\Exchmem: Number of heaps with memory errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Exchmem: Number of memory errors" -value "\MSExchangeIS\Exchmem: Number of memory errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Averaged Latency" -value "\MSExchangeIS\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Operations/sec" -value "\MSExchangeIS\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Requests" -value "\MSExchangeIS\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow QP Threads" -value "\MSExchangeIS\Slow QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow Search Threads" -value "\MSExchangeIS\Slow Search Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\User Count" -value "\MSExchangeIS\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Files Scanned/Sec" -value "\MSExchangeIS\Virus Scan Files Scanned/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Messages Processed/Sec" -value "\MSExchangeIS\Virus Scan Messages Processed/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Queue Length" -value "\MSExchangeIS\Virus Scan Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Largest Block Size" -value "\MSExchangeIS\VM Largest Block Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total 16MB Free Blocks" -value "\MSExchangeIS\VM Total 16MB Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Free Blocks" -value "\MSExchangeIS\VM Total Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Large Free Block Bytes" -value "\MSExchangeIS\VM Total Large Free Block Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Folder Opens/sec" -value "\MSExchangeIS Mailbox(*)\Folder Opens/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Local Delivery Rate" -value "\MSExchangeIS Mailbox(*)\Local Delivery Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Receive Queue Size" -value "\MSExchangeIS Mailbox(*)\Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Send Queue Size" -value "\MSExchangeIS Mailbox(*)\Send Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Message Opens/sec" -value "\MSExchangeIS Mailbox(*)\Message Opens/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -value "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Search Task Rate" -value "\MSExchangeIS Mailbox(*)\Search Task Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Slow Findrow Rate" -value "\MSExchangeIS Mailbox(*)\Slow Findrow Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Receive Queue Size" -value "\MSExchangeIS Public(*)\Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Replication Receive Queue Size" -value "\MSExchangeIS Public(*)\Replication Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Send Queue Size" -value "\MSExchangeIS Public(*)\Send Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(emsmta)\% Processor Time" -value "\Process(emsmta)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(inetinfo)\% Processor Time" -value "\Process(inetinfo)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(store)\% Processor Time" -value "\Process(store)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(System)\% Processor Time" -value "\Process(System)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SMTP Server(*)\Categorizer Queue Length" -value "\SMTP Server(*)\Categorizer Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SMTP Server(*)\Local Queue Length" -value "\SMTP Server(*)\Local Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SMTP Server(*)\Messages Delivered/sec" -value "\SMTP Server(*)\Messages Delivered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SMTP Server(*)\Remote Queue Length" -value "\SMTP Server(*)\Remote Queue Length" -Force
    }


    
    if($Exchange2007) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Database Cache Size" -value "\Database(*)\Database Cache Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Database Page Fault Stalls/sec" -value "\Database(*)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Log Record Stalls/sec" -value "\Database(*)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(*)\Log Threads Waiting" -value "\Database(*)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database(Information Store)\Version buckets allocated" -value "\Database(Information Store)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Database ==> Instances(*)\Log Generation Checkpoint Depth" -value "\Database ==> Instances(*)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Faults/sec" -value "\Memory\Transition Faults/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Requests/sec" -value "\MSExchange ActiveSync\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -value "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -value "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Read Time" -value "\MSExchange ADAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Search Time" -value "\MSExchange ADAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -value "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events in queue" -value "\MSExchange Assistants(*)\Events in queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events Polled/sec" -value "\MSExchange Assistants(*)\Events Polled/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Mailboxes processed/sec" -value "\MSExchange Assistants(*)\Mailboxes processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Number of events processed per second." -value "\MSExchange Assistants(*)\Number of events processed per second." -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -value "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -value "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Availability Requests (sec)" -value "\MSExchange Availability Service\Availability Requests (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -value "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Requests Failed" -value "\MSExchange Calendar Attendant\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache % Hit" -value "\MSExchange Database(Information Store)\Database Cache % Hit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache Size" -value "\MSExchange Database(Information Store)\Database Cache Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(*)\Database Page Fault Stalls/sec" -value "\MSExchange Database(*)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Bytes Write/sec" -value "\MSExchange Database(Information Store)\Log Bytes Write/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Record Stalls/sec" -value "\MSExchange Database(Information Store)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(*)\Log Threads Waiting" -value "\MSExchange Database(*)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Version buckets allocated" -value "\MSExchange Database(Information Store)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -value "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -value "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Active Conversions" -value "\MSExchange OWA\Active Conversions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Conversion Time" -value "\MSExchange OWA\Average Conversion Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Response Time" -value "\MSExchange OWA\Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Search Time" -value "\MSExchange OWA\Average Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Current Unique Users" -value "\MSExchange OWA\Current Unique Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Queued Conversion Requests" -value "\MSExchange OWA\Queued Conversion Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Requests/sec" -value "\MSExchange OWA\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replica Seeder(*)\Seeding Finished %" -value "\MSExchange Replica Seeder(*)\Seeding Finished %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\CopyQueueLength" -value "\MSExchange Replication(*)\CopyQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\ReplayQueueLength" -value "\MSExchange Replication(*)\ReplayQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Average Resource Booking Processing Time" -value "\MSExchange Resource Booking\Average Resource Booking Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Requests Failed" -value "\MSExchange Resource Booking\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Average document indexing time" -value "\MSExchange Search Indices(*)\Average document indexing time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Full Crawl Mode Status" -value "\MSExchange Search Indices(*)\Full Crawl Mode Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -value "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Throttling Delay Value" -value "\MSExchange Search Indices(*)\Throttling Delay Value" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -value "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -value "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\ROP Requests outstanding" -value "\MSExchange Store Interface(_Total)\ROP Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -value "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests failed (%)" -value "\MSExchange Store Interface(*)\RPC Requests failed (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests outstanding" -value "\MSExchange Store Interface(*)\RPC Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests sent/sec" -value "\MSExchange Store Interface(*)\RPC Requests sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests (%)" -value "\MSExchange Store Interface(*)\RPC Slow requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -value "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAutodiscover\Requests/sec" -value "\MSExchangeAutodiscover\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Task Queued" -value "\MSExchangeFDS:OAB(*)\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:UM\Download Task Queued" -value "\MSExchangeFDS:UM\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -value "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Current Connections" -value "\MSExchangeImap4\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Averaged Latency" -value "\MSExchangeIS\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Client Backoff/sec" -value "\MSExchangeIS\RPC Client Backoff/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Num. of Slow Packets" -value "\MSExchangeIS\RPC Num. of Slow Packets" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Operations/sec" -value "\MSExchangeIS\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Requests" -value "\MSExchangeIS\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow QP Threads" -value "\MSExchangeIS\Slow QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow Search Threads" -value "\MSExchangeIS\Slow Search Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\User Count" -value "\MSExchangeIS\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Files Scanned/sec" -value "\MSExchangeIS\Virus Scan Files Scanned/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Messages Processed/sec" -value "\MSExchangeIS\Virus Scan Messages Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Queue Length" -value "\MSExchangeIS\Virus Scan Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Largest Block Size" -value "\MSExchangeIS\VM Largest Block Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total 16MB Free Blocks" -value "\MSExchangeIS\VM Total 16MB Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Free Blocks" -value "\MSExchangeIS\VM Total Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Large Free Block Bytes" -value "\MSExchangeIS\VM Total Large Free Block Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Log Records/sec" -value "\MSExchangeIS Client(*)\JET Log Records/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Pages Read/sec" -value "\MSExchangeIS Client(*)\JET Pages Read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Average Latency" -value "\MSExchangeIS Client(*)\RPC Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Operations/sec" -value "\MSExchangeIS Client(*)\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Categorization Count" -value "\MSExchangeIS Mailbox(*)\Categorization Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -value "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -value "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -value "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -value "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -value "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Search Task Rate" -value "\MSExchangeIS Mailbox(*)\Search Task Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -value "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Receive Queue Size" -value "\MSExchangeIS Public(*)\Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -value "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -value "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Average Command Processing Time (milliseconds)" -value "\MSExchangePop3\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Connections Current" -value "\MSExchangePop3\Connections Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Batch Point(*)\Transactions committed/sec" -value "\MSExchangeTransport Batch Point(*)\Transactions committed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -value "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream read/sec" -value "\MSExchangeTransport Database(*)\Stream read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream writes/sec" -value "\MSExchangeTransport Database(*)\Stream writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -value "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -value "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Item Count" -value "\MSExchangeTransport Dumpster\Dumpster Item Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Size" -value "\MSExchangeTransport Dumpster\Dumpster Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -value "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Poison Queue Length" -value "\MSExchangeTransport Queues(_total)\Poison Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Submission Queue Length" -value "\MSExchangeTransport Queues(_total)\Submission Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -value "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -value "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -value "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -value "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Requests/sec" -value "\MSExchangeWS\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Data Bytes/sec" -value "\Process(EdgeTransport)\IO Data Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Read Bytes/sec" -value "\Process(EdgeTransport)\IO Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Write Bytes/sec" -value "\Process(EdgeTransport)\IO Write Bytes/sec" -Force
    }


    
    if($Exchange2010) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Requests/sec" -value "\MSExchange ActiveSync\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Availability Requests (sec)" -value "\MSExchange Availability Service\Availability Requests (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -value "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -value "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Current Unique Users" -value "\MSExchange OWA\Current Unique Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Task Queued" -value "\MSExchangeFDS:OAB(*)\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:UM\Download Task Queued" -value "\MSExchangeFDS:UM\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Search Time" -value "\MSExchange OWA\Average Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Requests/sec" -value "\MSExchange OWA\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Requests/sec" -value "\MSExchangeWS\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Response Time" -value "\MSExchange OWA\Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Connections Current" -value "\MSExchangePop3\Connections Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Average Command Processing Time (milliseconds)" -value "\MSExchangePop3\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -value "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Current Connections" -value "\MSExchangeImap4\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAutodiscover\Requests/sec" -value "\MSExchangeAutodiscover\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -value "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Read Time" -value "\MSExchange ADAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Search Time" -value "\MSExchange ADAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -value "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Operations/sec" -value "\MSExchangeIS Client(*)\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -value "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -value "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -value "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -value "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -value "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Averaged Latency" -value "\MSExchangeIS\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Operations/sec" -value "\MSExchangeIS\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Requests" -value "\MSExchangeIS\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\User Count" -value "\MSExchangeIS\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Queue Length" -value "\MSExchangeIS\Virus Scan Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Files Scanned/sec" -value "\MSExchangeIS\Virus Scan Files Scanned/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Messages Processed/sec" -value "\MSExchangeIS\Virus Scan Messages Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Largest Block Size" -value "\MSExchangeIS\VM Largest Block Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total 16MB Free Blocks" -value "\MSExchangeIS\VM Total 16MB Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Free Blocks" -value "\MSExchangeIS\VM Total Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Large Free Block Bytes" -value "\MSExchangeIS\VM Total Large Free Block Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -value "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Faults/sec" -value "\Memory\Transition Faults/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Num. of Slow Packets" -value "\MSExchangeIS\RPC Num. of Slow Packets" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Client Backoff/sec" -value "\MSExchangeIS\RPC Client Backoff/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Average Latency" -value "\MSExchangeIS Client(*)\RPC Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -value "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests outstanding" -value "\MSExchange Store Interface(*)\RPC Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -value "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache Size" -value "\MSExchange Database(Information Store)\Database Cache Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(*)\Database Page Fault Stalls/sec" -value "\MSExchange Database(*)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Record Stalls/sec" -value "\MSExchange Database(Information Store)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(*)\Log Threads Waiting" -value "\MSExchange Database(*)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Version buckets allocated" -value "\MSExchange Database(Information Store)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache % Hit" -value "\MSExchange Database(Information Store)\Database Cache % Hit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Log Records/sec" -value "\MSExchangeIS Client(*)\JET Log Records/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Pages Read/sec" -value "\MSExchangeIS Client(*)\JET Pages Read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Bytes Write/sec" -value "\MSExchange Database(Information Store)\Log Bytes Write/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Receive Queue Size" -value "\MSExchangeIS Public(*)\Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow QP Threads" -value "\MSExchangeIS\Slow QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow Search Threads" -value "\MSExchangeIS\Slow Search Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Categorization Count" -value "\MSExchangeIS Mailbox(*)\Categorization Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Throttling Delay Value" -value "\MSExchange Search Indices(*)\Throttling Delay Value" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Average document indexing time" -value "\MSExchange Search Indices(*)\Average document indexing time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Full Crawl Mode Status" -value "\MSExchange Search Indices(*)\Full Crawl Mode Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Average Resource Booking Processing Time" -value "\MSExchange Resource Booking\Average Resource Booking Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Requests Failed" -value "\MSExchange Resource Booking\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -value "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Requests Failed" -value "\MSExchange Calendar Attendant\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests failed (%)" -value "\MSExchange Store Interface(*)\RPC Requests failed (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests sent/sec" -value "\MSExchange Store Interface(*)\RPC Requests sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests (%)" -value "\MSExchange Store Interface(*)\RPC Slow requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -value "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\CopyQueueLength" -value "\MSExchange Replication(*)\CopyQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\ReplayQueueLength" -value "\MSExchange Replication(*)\ReplayQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Write Bytes/sec" -value "\Process(EdgeTransport)\IO Write Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Data Bytes/sec" -value "\Process(EdgeTransport)\IO Data Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Read Bytes/sec" -value "\Process(EdgeTransport)\IO Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Submission Queue Length" -value "\MSExchangeTransport Queues(_total)\Submission Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -value "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Size" -value "\MSExchangeTransport Dumpster\Dumpster Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -value "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Item Count" -value "\MSExchangeTransport Dumpster\Dumpster Item Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -value "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream writes/sec" -value "\MSExchangeTransport Database(*)\Stream writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream read/sec" -value "\MSExchangeTransport Database(*)\Stream read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -value "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -value "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -value "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -value "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Poison Queue Length" -value "\MSExchangeTransport Queues(_total)\Poison Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -value "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -value "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -value "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -value "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -value "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -value "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\ROP Requests outstanding" -value "\MSExchange Store Interface(_Total)\ROP Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Search Task Rate" -value "\MSExchangeIS Mailbox(*)\Search Task Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -value "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Approval Assistant\Average Approval Assistant Processing Time" -value "\MSExchange Approval Assistant\Average Approval Assistant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Approval Assistant\Last Approval Assistant Processing Time" -value "\MSExchange Approval Assistant\Last Approval Assistant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Average Event Queue Time In Seconds" -value "\MSExchange Assistants - Per Assistant(*)\Average Event Queue Time In Seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Average Event Processing Time In Seconds" -value "\MSExchange Assistants - Per Assistant(*)\Average Event Processing Time In Seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Average Request Time" -value "\MSExchange ActiveSync\Average Request Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Heartbeat Interval" -value "\MSExchange ActiveSync\Heartbeat Interval" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Elapsed Time Since Last Event Queued" -value "\MSExchange Assistants - Per Assistant(*)\Elapsed Time Since Last Event Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Events in Queue" -value "\MSExchange Assistants - Per Assistant(*)\Events in Queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Events Processed/sec" -value "\MSExchange Assistants - Per Assistant(*)\Events Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Assistant(*)\Handled Exceptions" -value "\MSExchange Assistants - Per Assistant(*)\Handled Exceptions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Database(*)\Average Event Processing Time In seconds" -value "\MSExchange Assistants - Per Database(*)\Average Event Processing Time In seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Database(*)\Average Mailbox Processing Time In seconds" -value "\MSExchange Assistants - Per Database(*)\Average Mailbox Processing Time In seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Database(*)\Events in queue" -value "\MSExchange Assistants - Per Database(*)\Events in queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Database(*)\Events Polled/sec" -value "\MSExchange Assistants - Per Database(*)\Events Polled/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants - Per Database(*)\Mailboxes processed/sec" -value "\MSExchange Assistants - Per Database(*)\Mailboxes processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Federated Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Federated Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Client-Reported Failures - Total" -value "\MSExchange Availability Service\Client-Reported Failures - Total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Cross-Site Calendar Failures (sec)" -value "\MSExchange Availability Service\Cross-Site Calendar Failures (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Cross-Site Calendar Queries (sec)" -value "\MSExchange Availability Service\Cross-Site Calendar Queries (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Successful Client-Reported Requests - Over 20 seconds" -value "\MSExchange Availability Service\Successful Client-Reported Requests - Over 20 seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\AS Queries Failure %" -value "\MSExchange OWA\AS Queries Failure %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Current Proxy Users" -value "\MSExchange OWA\Current Proxy Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Failed Requests/sec" -value "\MSExchange OWA\Failed Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Store Logon Failure %" -value "\MSExchange OWA\Store Logon Failure %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Logons/sec" -value "\MSExchange OWA\Logons/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Proxy Response Time Average" -value "\MSExchange OWA\Proxy Response Time Average" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Proxy User Requests/sec" -value "\MSExchange OWA\Proxy User Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Active Backend Connections (% of Limit)" -value "\MSExchange RpcClientAccess Per Server\RPC Active Backend Connections (% of Limit)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Average Latency (Backend)" -value "\MSExchange RpcClientAccess Per Server\RPC Average Latency (Backend)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End)" -value "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End) - Cached Mode" -value "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End) - Cached Mode" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End) - Online Mode" -value "\MSExchange RpcClientAccess Per Server\RPC Average Latency (End To End) - Online Mode" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess Per Server\RPC Failed Backend Connections" -value "\MSExchange RpcClientAccess Per Server\RPC Failed Backend Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Active User Count" -value "\MSExchange RpcClientAccess\Active User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Client: RPCs Failed" -value "\MSExchange RpcClientAccess\Client: RPCs Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Client: Latency > 10 sec RPCs" -value "\MSExchange RpcClientAccess\Client: Latency > 10 sec RPCs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Client: Latency > 2 sec RPCs" -value "\MSExchange RpcClientAccess\Client: Latency > 2 sec RPCs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Client: Latency > 5 sec RPCs" -value "\MSExchange RpcClientAccess\Client: Latency > 5 sec RPCs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\Connection Count" -value "\MSExchange RpcClientAccess\Connection Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\RPC Averaged Latency" -value "\MSExchange RpcClientAccess\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\RPC Operations/sec" -value "\MSExchange RpcClientAccess\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\RPC Packets/sec" -value "\MSExchange RpcClientAccess\RPC Packets/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\RPC Requests" -value "\MSExchange RpcClientAccess\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange RpcClientAccess\User Count" -value "\MSExchange RpcClientAccess\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Throttling Service Client\Average request processing time." -value "\MSExchange Throttling Service Client\Average request processing time." -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Throttling(*)\OverBudgetThreshold" -value "\MSExchange Throttling(*)\OverBudgetThreshold" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Throttling(*)\Unique Budgets OverBudget" -value "\MSExchange Throttling(*)\Unique Budgets OverBudget" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Throttling(*)\Users X Times OverBudget" -value "\MSExchange Throttling(*)\Users X Times OverBudget" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI Connections Current" -value "\MSExchangeAB\NSPI Connections Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI Connections/sec" -value "\MSExchangeAB\NSPI Connections/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI RPC Browse Requests Average Latency" -value "\MSExchangeAB\NSPI RPC Browse Requests Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI RPC Requests" -value "\MSExchangeAB\NSPI RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI RPC Requests Average Latency" -value "\MSExchangeAB\NSPI RPC Requests Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\NSPI RPC Requests/sec" -value "\MSExchangeAB\NSPI RPC Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\Referral RPC Requests Average Latency" -value "\MSExchangeAB\Referral RPC Requests Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAB\Referral RPC Requests/sec" -value "\MSExchangeAB\Referral RPC Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Connections Rate" -value "\MSExchangeImap4\Connections Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Proxy Current Connections" -value "\MSExchangeImap4\Proxy Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\SearchFolder Creation Rate" -value "\MSExchangeImap4\SearchFolder Creation Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Connections Rate" -value "\MSExchangePop3\Connections Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\DELE Rate" -value "\MSExchangePop3\DELE Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Proxy Current Connections" -value "\MSExchangePop3\Proxy Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\RETR Rate" -value "\MSExchangePop3\RETR Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\UIDL Rate" -value "\MSExchangePop3\UIDL Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Average Response Time" -value "\MSExchangeWS\Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Items Read/sec" -value "\MSExchangeWS\Items Read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Proxy Average Response Time" -value "\MSExchangeWS\Proxy Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Moves in Completion State" -value "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Moves in Completion State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Moves in Initial Seeding State" -value "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Moves in Initial Seeding State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves (Content Indexing)" -value "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves (Content Indexing)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves (Database Replication)" -value "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves (Database Replication)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves Total" -value "\MSExchange Mailbox Replication Service Per Mdb\Active Moves: Stalled Moves Total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Content Indexing Lagging" -value "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Content Indexing Lagging" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Database Replication Lagging" -value "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Database Replication Lagging" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Scan Failure" -value "\MSExchange Mailbox Replication Service Per Mdb\MDB Health: Scan Failure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Journaling Agent\Journal Reports Created/sec" -value "\MSExchange Journaling Agent\Journal Reports Created/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Journaling Agent\Journaling Processing Time per Message" -value "\MSExchange Journaling Agent\Journaling Processing Time per Message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Journaling Agent\Journaling Processing Time" -value "\MSExchange Journaling Agent\Journaling Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Journaling Agent\Users Journaled/sec" -value "\MSExchange Journaling Agent\Users Journaled/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Average message bytes/message" -value "\MSExchangeTransport SmtpSend(_total)\Average message bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Average recipients/message" -value "\MSExchangeTransport SmtpSend(_total)\Average recipients/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPReceive(_total)\Disconnections by Agents/second" -value "\MSExchangeTransport SMTPReceive(_total)\Disconnections by Agents/second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPReceive(_total)\Message Bytes Received/sec" -value "\MSExchangeTransport SMTPReceive(_total)\Message Bytes Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Activity" -value "\MSExchangeTransport SMTPAvailability(*)\% Activity" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Availability" -value "\MSExchangeTransport SMTPAvailability(*)\% Availability" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To Active Directory Down" -value "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To Active Directory Down" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To Back Pressure" -value "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To Back Pressure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To IO Exceptions" -value "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To IO Exceptions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To MaxInboundConnectionLimit" -value "\MSExchangeTransport SMTPAvailability(*)\% Failures Due To MaxInboundConnectionLimit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Queued for Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Queued for Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Resubmit Jobs: Average Execution Time (sec)" -value "\MSExchangeTransport Dumpster\Dumpster Resubmit Jobs: Average Execution Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Resubmit Jobs: Average Request Latency (sec)" -value "\MSExchangeTransport Dumpster\Dumpster Resubmit Jobs: Average Request Latency (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Transport Rules(_total)\Messages Evaluated/sec" -value "\MSExchange Transport Rules(_total)\Messages Evaluated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Transport Rules(_total)\Messages Processed/sec" -value "\MSExchange Transport Rules(_total)\Messages Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Component Latency(*)\Percentile99" -value "\MSExchangeTransport Component Latency(*)\Percentile99" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Connection Filtering Agent\Connections on IP Block List Providers /sec" -value "\MSExchange Connection Filtering Agent\Connections on IP Block List Providers /sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages Scanned Per Second" -value "\MSExchange Content Filter Agent\Messages Scanned Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Throttling Service Client\Percentage of Denied Submission Request." -value "\MSExchange Throttling Service Client\Percentage of Denied Submission Request." -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\% Connections" -value "\MSExchangeIS\% Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\% RPC Threads" -value "\MSExchangeIS\% RPC Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Request Timeout Detected on Database" -value "\MSExchangeIS\RPC Request Timeout Detected on Database" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Request Timeout Detected on Mailbox" -value "\MSExchangeIS\RPC Request Timeout Detected on Mailbox" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Request Timeout Detected on Server" -value "\MSExchangeIS\RPC Request Timeout Detected on Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\CI QP Threads" -value "\MSExchangeIS\CI QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Ten More" -value "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Ten More" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Exchange Search Slow First Batch" -value "\MSExchangeIS Mailbox(_Total)\Exchange Search Slow First Batch" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Queries" -value "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Queries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Zero Results Queries" -value "\MSExchangeIS Mailbox(_Total)\ExchangeSearch Zero Results Queries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Folder opens/sec" -value "\MSExchangeIS Mailbox(_Total)\Folder opens/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Last Query Time" -value "\MSExchangeIS Mailbox(_Total)\Last Query Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Local delivery rate" -value "\MSExchangeIS Mailbox(_Total)\Local delivery rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Logon Operations/sec" -value "\MSExchangeIS Mailbox(_Total)\Logon Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Message Opens/sec" -value "\MSExchangeIS Mailbox(_Total)\Message Opens/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Store Only Queries" -value "\MSExchangeIS Mailbox(_Total)\Store Only Queries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Store Only Query Ten More" -value "\MSExchangeIS Mailbox(_Total)\Store Only Query Ten More" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(_total)\Log Copy KB/Sec" -value "\MSExchange Replication(_total)\Log Copy KB/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(_total)\Avg Log Copy Latency (msec)" -value "\MSExchange Replication(_total)\Avg Log Copy Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(_total)\Log Copying is Not Keeping Up" -value "\MSExchange Replication(_total)\Log Copying is Not Keeping Up" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(_total)\Number of Outstanding Batches" -value "\MSExchange Search Indices(_total)\Number of Outstanding Batches" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(_total)\Number of Outstanding Documents" -value "\MSExchange Search Indices(_total)\Number of Outstanding Documents" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(_total)\Number of Mailboxes Left to Crawl" -value "\MSExchange Search Indices(_total)\Number of Mailboxes Left to Crawl" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indexer\Number of Databases Being Indexed" -value "\MSExchange Search Indexer\Number of Databases Being Indexed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indexer\Number of Indexed Databases Being Kept Up-to-Date by Notifications" -value "\MSExchange Search Indexer\Number of Indexed Databases Being Kept Up-to-Date by Notifications" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mail Submission(*)\Hub Servers In Retry" -value "\MSExchange Mail Submission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mail Submission(*)\Failed Submissions Per Second" -value "\MSExchange Mail Submission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Mail Submission(*)\Shadow Re-submission Queue Length" -value "\MSExchange Mail Submission(*)\Shadow Re-submission Queue Length" -Force
    }
    
    
    
    if($Exchange2007CAS) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -value "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(_Global_)\% Time in GC" -value "\.NET CLR Memory(_Global_)\% Time in GC" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(*)\# Bytes in all Heaps" -value "\.NET CLR Memory(*)\# Bytes in all Heaps" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Application Restarts" -value "\ASP.NET\Application Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Request Wait Time" -value "\ASP.NET\Request Wait Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Current" -value "\ASP.NET\Requests Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Queued" -value "\ASP.NET\Requests Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Rejected" -value "\ASP.NET\Requests Rejected" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Worker Process Restarts" -value "\ASP.NET\Worker Process Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Applications(__Total__)\Requests In Application Queue" -value "\ASP.NET Applications(__Total__)\Requests In Application Queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Applications\Request Execution Time" -value "\ASP.NET Applications\Request Execution Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(C:)\Free Megabytes" -value "\LogicalDisk(C:)\Free Megabytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Available MBytes" -value "\Memory\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free System Page Table Entries" -value "\Memory\Free System Page Table Entries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Cache Bytes" -value "\Memory\Cache Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Commit Limit" -value "\Memory\Commit Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Committed Bytes" -value "\Memory\Committed Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Page Reads/sec" -value "\Memory\Page Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Input/sec" -value "\Memory\Pages Input/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Output/sec" -value "\Memory\Pages Output/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages/sec" -value "\Memory\Pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\% Committed Bytes In Use" -value "\Memory\% Committed Bytes In Use" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\System Cache Resident Bytes" -value "\Memory\System Cache Resident Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Faults/sec" -value "\Memory\Transition Faults/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Pages RePurposed/sec" -value "\Memory\Transition Pages RePurposed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Nonpaged Bytes" -value "\Memory\Pool Nonpaged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Paged Bytes" -value "\Memory\Pool Paged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Average Request Time" -value "\MSExchange ActiveSync\Average Request Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Ping Commands Pending" -value "\MSExchange ActiveSync\Ping Commands Pending" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Requests/sec" -value "\MSExchange ActiveSync\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Sync Commands/sec" -value "\MSExchange ActiveSync\Sync Commands/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -value "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -value "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Read Time" -value "\MSExchange ADAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Search Time" -value "\MSExchange ADAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -value "\MSExchange Availability Service\Average Number of Mailboxes Processed per Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Forest Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Cross-Site Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -value "\MSExchange Availability Service\Average Time to Process a Meeting Suggestions Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Availability Requests (sec)" -value "\MSExchange Availability Service\Availability Requests (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Active Conversions" -value "\MSExchange OWA\Active Conversions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Conversion Time" -value "\MSExchange OWA\Average Conversion Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Response Time" -value "\MSExchange OWA\Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Search Time" -value "\MSExchange OWA\Average Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Current Unique Users" -value "\MSExchange OWA\Current Unique Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Queued Conversion Requests" -value "\MSExchange OWA\Queued Conversion Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Requests/sec" -value "\MSExchange OWA\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAutodiscover\Requests/sec" -value "\MSExchangeAutodiscover\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Task Queued" -value "\MSExchangeFDS:OAB(*)\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Tasks Completed" -value "\MSExchangeFDS:OAB(*)\Download Tasks Completed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:UM\Download Task Queued" -value "\MSExchangeFDS:UM\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Current Connections" -value "\MSExchangeImap4\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -value "\MSExchangeImap4\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Connections Current" -value "\MSExchangePop3\Connections Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangePop3\Average Command Processing Time (milliseconds)" -value "\MSExchangePop3\Average Command Processing Time (milliseconds)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Requests/sec" -value "\MSExchangeWS\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Outbound Errors" -value "\Network Interface(*)\Packets Outbound Errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Output Queue Length" -value "\Network Interface(*)\Output Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Total/sec" -value "\Network Interface(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage" -value "\Paging File(*)\% Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage Peak" -value "\Paging File(*)\% Usage Peak" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\% Processor Time" -value "\Process(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Virtual Bytes" -value "\Process(*)\Virtual Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Data Bytes/sec" -value "\Process(EdgeTransport)\IO Data Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Data Operations/sec" -value "\Process(*)\IO Data Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Other Operations/sec" -value "\Process(*)\IO Other Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Read Bytes/sec" -value "\Process(EdgeTransport)\IO Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Write Bytes/sec" -value "\Process(EdgeTransport)\IO Write Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Interrupt Time" -value "\Processor(*)\% Interrupt Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Privileged Time" -value "\Processor(*)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Processor Time" -value "\Processor(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Nonpaged Failures" -value "\Server\Pool Nonpaged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Paged Failures" -value "\Server\Pool Paged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Privileged Time" -value "\Processor(_Total)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Processor Time" -value "\Processor(_Total)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Context Switches/sec" -value "\System\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Processor Queue Length" -value "\System\Processor Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Connection Attempts/sec" -value "\Web Service(_Total)\Connection Attempts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Current Connections" -value "\Web Service(_Total)\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\ISAPI Extension Requests" -value "\Web Service(_Total)\ISAPI Extension Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Other Request Methods/sec" -value "\Web Service(_Total)\Other Request Methods/sec" -Force
    }


    
    if($Exchange2007CAS_Technet) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Application Restarts" -value "\ASP.NET\Application Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Request Wait Time" -value "\ASP.NET\Request Wait Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Requests Current" -value "\ASP.NET\Requests Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET\Worker Process Restarts" -value "\ASP.NET\Worker Process Restarts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\ASP.NET Applications(*)\Requests In Application Queue" -value "\ASP.NET Applications(*)\Requests In Application Queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(_Total)\Disk Reads/sec" -value "\LogicalDisk(_Total)\Disk Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(_Total)\Disk Writes/sec" -value "\LogicalDisk(_Total)\Disk Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Average Request Time" -value "\MSExchange ActiveSync\Average Request Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Ping Commands Pending" -value "\MSExchange ActiveSync\Ping Commands Pending" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Requests/sec" -value "\MSExchange ActiveSync\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ActiveSync\Sync Commands/sec" -value "\MSExchange ActiveSync\Sync Commands/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -value "\MSExchange Availability Service\Average Time to Process a Free Busy Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Availability Service\Availability Requests (sec)" -value "\MSExchange Availability Service\Availability Requests (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Response Time" -value "\MSExchange OWA\Average Response Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Average Search Time" -value "\MSExchange OWA\Average Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Current Unique Users" -value "\MSExchange OWA\Current Unique Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange OWA\Requests/sec" -value "\MSExchange OWA\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeAutodiscover\Requests/sec" -value "\MSExchangeAutodiscover\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Task Queued" -value "\MSExchangeFDS:OAB(*)\Download Task Queued" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeFDS:OAB(*)\Download Tasks Completed" -value "\MSExchangeFDS:OAB(*)\Download Tasks Completed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeWS\Requests/sec" -value "\MSExchangeWS\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RPC/HTTP Proxy\Current Number of Incoming RPC over HTTP Connections" -value "\RPC/HTTP Proxy\Current Number of Incoming RPC over HTTP Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RPC/HTTP Proxy\Current Number of Unique Users" -value "\RPC/HTTP Proxy\Current Number of Unique Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RPC/HTTP Proxy\Number of Failed Back-End Connection attempts per Second" -value "\RPC/HTTP Proxy\Number of Failed Back-End Connection attempts per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RPC/HTTP Proxy\RPC/HTTP Requests per Second" -value "\RPC/HTTP Proxy\RPC/HTTP Requests per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Current Connections" -value "\Web Service(_Total)\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\WebService(_Total)\Connection Attempts/sec" -value "\WebService(_Total)\Connection Attempts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\ISAPI Extension Requests/sec" -value "\Web Service(_Total)\ISAPI Extension Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Other Request Methods/sec" -value "\Web Service(_Total)\Other Request Methods/sec" -Force
    }


    
    if($Exchange2007Edge_Technet) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\AD/AM(ADAM_MSExchange)\LDAP Searches/sec" -value "\AD/AM(ADAM_MSExchange)\LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\AD/AM(ADAM_MSExchange)\LDAP Writes/sec" -value "\AD/AM(ADAM_MSExchange)\LDAP Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\DirectoryServices(ADAM_MSExchange)\LDAP Searches/sec" -value "\DirectoryServices(ADAM_MSExchange)\LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\DirectoryServices(ADAM_MSExchange)\LDAP Writes/sec" -value "\DirectoryServices(ADAM_MSExchange)\LDAP Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Queue Length" -value "\LogicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Transfer" -value "\LogicalDisk(*)\Avg. Disk sec/Transfer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Attachment Filtering\Messages Attachment Filtered" -value "\MSExchange Attachment Filtering\Messages Attachment Filtered" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Attachment Filtering\Messages Filtered/sec" -value "\MSExchange Attachment Filtering\Messages Filtered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages Deleted" -value "\MSExchange Content Filter Agent\Messages Deleted" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages Quarantined" -value "\MSExchange Content Filter Agent\Messages Quarantined" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages Rejected" -value "\MSExchange Content Filter Agent\Messages Rejected" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages Scanned Per Second" -value "\MSExchange Content Filter Agent\Messages Scanned Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages that Bypassed Scanning" -value "\MSExchange Content Filter Agent\Messages that Bypassed Scanning" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 0" -value "\MSExchange Content Filter Agent\Messages with SCL 0" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 1" -value "\MSExchange Content Filter Agent\Messages with SCL 1" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 2" -value "\MSExchange Content Filter Agent\Messages with SCL 2" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 3" -value "\MSExchange Content Filter Agent\Messages with SCL 3" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 4" -value "\MSExchange Content Filter Agent\Messages with SCL 4" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 5" -value "\MSExchange Content Filter Agent\Messages with SCL 5" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 6" -value "\MSExchange Content Filter Agent\Messages with SCL 6" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 7" -value "\MSExchange Content Filter Agent\Messages with SCL 7" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 8" -value "\MSExchange Content Filter Agent\Messages with SCL 8" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Content Filter Agent\Messages with SCL 9" -value "\MSExchange Content Filter Agent\Messages with SCL 9" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(edgetransport)\Database Cache Size (MB)" -value "\MSExchange Database(edgetransport)\Database Cache Size (MB)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads/sec" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes/sec" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Log Reads/sec" -value "\MSExchange Database ==> Instances(*)\I/O Log Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Log Writes/sec" -value "\MSExchange Database ==> Instances(*)\I/O Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Record Stalls/sec" -value "\MSExchange Database ==> Instances(*)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Threads Waiting" -value "\MSExchange Database ==> Instances(*)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Version buckets allocated" -value "\MSExchange Database ==> Instances(*)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -value "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Protocol Analysis Background Agent\Block Senders" -value "\MSExchange Protocol Analysis Background Agent\Block Senders" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Recipient Filter Agent\Recipients Rejected by Block List/sec" -value "\MSExchange Recipient Filter Agent\Recipients Rejected by Block List/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Recipient Filter Agent\Recipients Rejected by Recipient Validation/sec" -value "\MSExchange Recipient Filter Agent\Recipients Rejected by Recipient Validation/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Sender Filter Agent\Messages Filtered by Sender Filter/sec" -value "\MSExchange Sender Filter Agent\Messages Filtered by Sender Filter/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Sender Id Agent\DNS Queries/sec" -value "\MSExchange Sender Id Agent\DNS Queries/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Transport Rules\Messages Evaluated/sec" -value "\MSExchange Transport Rules\Messages Evaluated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Transport Rules\Messages Processed/sec" -value "\MSExchange Transport Rules\Messages Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Edge objects added/sec" -value "\MSExchangeEdgeSync Job\Edge objects added/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Edge objects deleted/sec" -value "\MSExchangeEdgeSync Job\Edge objects deleted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Edge objects updated/sec" -value "\MSExchangeEdgeSync Job\Edge objects updated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Scan jobs completed successfully total" -value "\MSExchangeEdgeSync Job\Scan jobs completed successfully total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Scan jobs failed because could not extend lock total" -value "\MSExchangeEdgeSync Job\Scan jobs failed because could not extend lock total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Scan jobs failed because of directory error total" -value "\MSExchangeEdgeSync Job\Scan jobs failed because of directory error total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Source objects scanned/sec" -value "\MSExchangeEdgeSync Job\Source objects scanned/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeEdgeSync Job\Target objects scanned/sec" -value "\MSExchangeEdgeSync Job\Target objects scanned/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -value "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Items Completed Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Items Completed Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Message" -value "\MSExchangeTransport Queues(_total)\Message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Poison Queue Length" -value "\MSExchangeTransport Queues(_total)\Poison Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Submission Queue Length" -value "\MSExchangeTransport Queues(_total)\Submission Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -value "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -value "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -value "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -value "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk Queue Length" -value "\PhysicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Transfer" -value "\PhysicalDisk(*)\Avg. Disk sec/Transfer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
    }
    
    
    if($Exchange2007Hub) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Processor Time" -value "\Processor(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Total/sec" -value "\Network Interface(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Current Bandwidth" -value "\Network Interface(*)\Current Bandwidth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Processor Queue Length" -value "\System\Processor Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Privileged Time" -value "\Processor(*)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free System Page Table Entries" -value "\Memory\Free System Page Table Entries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Nonpaged Bytes" -value "\Memory\Pool Nonpaged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Paged Bytes" -value "\Memory\Pool Paged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Available MBytes" -value "\Memory\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages/sec" -value "\Memory\Pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Output Queue Length" -value "\Network Interface(*)\Output Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Processor Time" -value "\Processor(_Total)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Privileged Time" -value "\Processor(_Total)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Context Switches/sec" -value "\System\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\% Processor Time" -value "\Process(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Virtual Bytes" -value "\Process(*)\Virtual Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(C:)\Free Megabytes" -value "\LogicalDisk(C:)\Free Megabytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Interrupt Time" -value "\Processor(*)\% Interrupt Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\System Cache Resident Bytes" -value "\Memory\System Cache Resident Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Data Operations/sec" -value "\Process(*)\IO Data Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Other Operations/sec" -value "\Process(*)\IO Other Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Input/sec" -value "\Memory\Pages Input/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage" -value "\Paging File(*)\% Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage Peak" -value "\Paging File(*)\% Usage Peak" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -value "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Connection Attempts/sec" -value "\Web Service(_Total)\Connection Attempts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(*)\# Bytes in all Heaps" -value "\.NET CLR Memory(*)\# Bytes in all Heaps" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Page Reads/sec" -value "\Memory\Page Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(_Global_)\% Time in GC" -value "\.NET CLR Memory(_Global_)\% Time in GC" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -value "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Read Time" -value "\MSExchange ADAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Search Time" -value "\MSExchange ADAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -value "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Faults/sec" -value "\Memory\Transition Faults/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Cache Bytes" -value "\Memory\Cache Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -value "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(*)\Database Page Fault Stalls/sec" -value "\MSExchange Database(*)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Nonpaged Failures" -value "\Server\Pool Nonpaged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Paged Failures" -value "\Server\Pool Paged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -value "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Output/sec" -value "\Memory\Pages Output/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Write Bytes/sec" -value "\Process(EdgeTransport)\IO Write Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Data Bytes/sec" -value "\Process(EdgeTransport)\IO Data Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(EdgeTransport)\IO Read Bytes/sec" -value "\Process(EdgeTransport)\IO Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Submission Queue Length" -value "\MSExchangeTransport Queues(_total)\Submission Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -value "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Size" -value "\MSExchangeTransport Dumpster\Dumpster Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -value "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Item Count" -value "\MSExchangeTransport Dumpster\Dumpster Item Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -value "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream writes/sec" -value "\MSExchangeTransport Database(*)\Stream writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\Stream read/sec" -value "\MSExchangeTransport Database(*)\Stream read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -value "\MSExchangeTransport Database(*)\MailItem begin commit/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Batch Point(*)\Transactions committed/sec" -value "\MSExchangeTransport Batch Point(*)\Transactions committed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -value "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -value "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttempts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -value "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Poison Queue Length" -value "\MSExchangeTransport Queues(_total)\Poison Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -value "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -value "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -value "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -value "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -value "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Pages RePurposed/sec" -value "\Memory\Transition Pages RePurposed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Outbound Errors" -value "\Network Interface(*)\Packets Outbound Errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Committed Bytes" -value "\Memory\Committed Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Commit Limit" -value "\Memory\Commit Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\% Committed Bytes In Use" -value "\Memory\% Committed Bytes In Use" -Force
    }
    
    
    
    if($Exchange2007Hub_Technet) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Database Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\I/O Log Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -value "\MSExchange Database ==> Instances(edgetransport/Transport Mail Database)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -value "\MSExchange Extensibility Agents(*)\Average Agent Processing Time (sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -value "\MSExchange Extensibility Agents(*)\Total Agent Invocations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: LocalDeliveryCallsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -value "\MSExchange Store Driver(_total)\Inbound: MessageDeliveryAttemptsPerSecond" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -value "\MSExchange Store Driver(_total)\Inbound: Recipients Delivered Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -value "\MSExchange Store Driver(_total)\Outbound: Submitted Mail Items Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -value "\MSExchangeTransport Dumpster\Dumpster Deletes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -value "\MSExchangeTransport Dumpster\Dumpster Inserts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Item Count" -value "\MSExchangeTransport Dumpster\Dumpster Item Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Dumpster\Dumpster Size" -value "\MSExchangeTransport Dumpster\Dumpster Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Active Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -value "\MSExchangeTransport Queues(_total)\Aggregate Delivery Queue Length (All Queues)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Largest Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Completed Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Queued for Delivery Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Queued for Delivery Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -value "\MSExchangeTransport Queues(_total)\Messages Submitted Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Poison Queue Length" -value "\MSExchangeTransport Queues(_total)\Poison Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Mailbox Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Non-Smtp Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -value "\MSExchangeTransport Queues(_total)\Retry Remote Delivery Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Submission Queue Length" -value "\MSExchangeTransport Queues(_total)\Submission Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -value "\MSExchangeTransport Queues(_total)\Unreachable Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -value "\MSExchangeTransport SmtpReceive(_total)\Average bytes/message" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -value "\MSExchangeTransport SmtpReceive(_total)\Messages Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -value "\MSExchangeTransport SmtpSend(_total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write " -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
    }
    
    
    
    if($Exchange2007Mailbox) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -value "\.NET CLR Exceptions(*)\# of Exceps Thrown / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(*)\% Time in GC" -value "\.NET CLR Memory(*)\% Time in GC" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\.NET CLR Memory(*)\# Bytes in all Heaps" -value "\.NET CLR Memory(*)\# Bytes in all Heaps" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\IPv4\Datagrams/sec" -value "\IPv4\Datagrams/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\IPv6\Datagrams/sec" -value "\IPv6\Datagrams/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(C:)\Free Megabytes" -value "\LogicalDisk(C:)\Free Megabytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Transfer" -value "\LogicalDisk(*)\Avg. Disk sec/Transfer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Available MBytes" -value "\Memory\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free System Page Table Entries" -value "\Memory\Free System Page Table Entries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\% Committed Bytes In Use" -value "\Memory\% Committed Bytes In Use" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Cache Bytes" -value "\Memory\Cache Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Committed Bytes" -value "\Memory\Committed Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Page Reads/sec" -value "\Memory\Page Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Input/sec" -value "\Memory\Pages Input/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Output/sec" -value "\Memory\Pages Output/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages/sec" -value "\Memory\Pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\System Cache Resident Bytes" -value "\Memory\System Cache Resident Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Faults/sec" -value "\Memory\Transition Faults/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Pages RePurposed/sec" -value "\Memory\Transition Pages RePurposed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Nonpaged Bytes" -value "\Memory\Pool Nonpaged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Paged Bytes" -value "\Memory\Pool Paged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -value "\MSExchange ADAccess Caches(*)\LDAP Searches/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search calls/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -value "\MSExchange ADAccess Domain Controllers(*)\LDAP Searches timed out per minute" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -value "\MSExchange ADAccess Domain Controllers(*)\Long running LDAP operations/Min" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Read Time" -value "\MSExchange ADAccess Processes(*)\LDAP Read Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange ADAccess Processes(*)\LDAP Search Time" -value "\MSExchange ADAccess Processes(*)\LDAP Search Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -value "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events in queue" -value "\MSExchange Assistants(*)\Events in queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events Polled/sec" -value "\MSExchange Assistants(*)\Events Polled/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Mailboxes processed/sec" -value "\MSExchange Assistants(*)\Mailboxes processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Number of events processed per second." -value "\MSExchange Assistants(*)\Number of events processed per second." -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -value "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Requests Failed" -value "\MSExchange Calendar Attendant\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache % Hit" -value "\MSExchange Database(Information Store)\Database Cache % Hit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache Size" -value "\MSExchange Database(Information Store)\Database Cache Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Page Fault Stalls/sec" -value "\MSExchange Database(Information Store)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Bytes Write/sec" -value "\MSExchange Database(Information Store)\Log Bytes Write/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Record Stalls/sec" -value "\MSExchange Database(Information Store)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Threads Waiting" -value "\MSExchange Database(Information Store)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Version buckets allocated" -value "\MSExchange Database ==> Instances(*)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replica Seeder(*)\Seeding Finished %" -value "\MSExchange Replica Seeder(*)\Seeding Finished %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\CopyQueueLength" -value "\MSExchange Replication(*)\CopyQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication(*)\ReplayQueueLength" -value "\MSExchange Replication(*)\ReplayQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Average Resource Booking Processing Time" -value "\MSExchange Resource Booking\Average Resource Booking Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Requests Failed" -value "\MSExchange Resource Booking\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Average document indexing time" -value "\MSExchange Search Indices(*)\Average document indexing time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Full Crawl Mode Status" -value "\MSExchange Search Indices(*)\Full Crawl Mode Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -value "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Throttling Delay Value" -value "\MSExchange Search Indices(*)\Throttling Delay Value" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\ConnectionCache active connections" -value "\MSExchange Store Interface(*)\ConnectionCache active connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\ConnectionCache out of limit creations" -value "\MSExchange Store Interface(*)\ConnectionCache out of limit creations" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\ROP Requests outstanding" -value "\MSExchange Store Interface(*)\ROP Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -value "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests failed (%)" -value "\MSExchange Store Interface(*)\RPC Requests failed (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests outstanding" -value "\MSExchange Store Interface(*)\RPC Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests sent/sec" -value "\MSExchange Store Interface(*)\RPC Requests sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests (%)" -value "\MSExchange Store Interface(*)\RPC Slow requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -value "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Averaged Latency" -value "\MSExchangeIS\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Client Backoff/sec" -value "\MSExchangeIS\RPC Client Backoff/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Num. of Slow Packets" -value "\MSExchangeIS\RPC Num. of Slow Packets" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Operations/sec" -value "\MSExchangeIS\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Requests" -value "\MSExchangeIS\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow QP Threads" -value "\MSExchangeIS\Slow QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow Search Threads" -value "\MSExchangeIS\Slow Search Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\User Count" -value "\MSExchangeIS\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Files Scanned/sec" -value "\MSExchangeIS\Virus Scan Files Scanned/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Messages Processed/sec" -value "\MSExchangeIS\Virus Scan Messages Processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Virus Scan Queue Length" -value "\MSExchangeIS\Virus Scan Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Largest Block Size" -value "\MSExchangeIS\VM Largest Block Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total 16MB Free Blocks" -value "\MSExchangeIS\VM Total 16MB Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Free Blocks" -value "\MSExchangeIS\VM Total Free Blocks" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\VM Total Large Free Block Bytes" -value "\MSExchangeIS\VM Total Large Free Block Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Log Records/sec" -value "\MSExchangeIS Client(*)\JET Log Records/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Pages Read/sec" -value "\MSExchangeIS Client(*)\JET Pages Read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Average Latency" -value "\MSExchangeIS Client(*)\RPC Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Operations/sec" -value "\MSExchangeIS Client(*)\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Categorization Count" -value "\MSExchangeIS Mailbox(*)\Categorization Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -value "\MSExchangeIS Mailbox(*)\Messages Delivered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -value "\MSExchangeIS Mailbox(*)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -value "\MSExchangeIS Mailbox(*)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -value "\MSExchangeIS Mailbox(*)\Messages Submitted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -value "\MSExchangeIS Mailbox(*)\Restricted View Cache Miss Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Search Task Rate" -value "\MSExchangeIS Mailbox(*)\Search Task Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -value "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(*)\Messages Queued For Submission" -value "\MSExchangeIS Public(*)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(_Total)\Replication Receive Queue Size" -value "\MSExchangeIS Public(_Total)\Replication Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -value "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -value "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Outbound Errors" -value "\Network Interface(*)\Packets Outbound Errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Output Queue Length" -value "\Network Interface(*)\Output Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Total/sec" -value "\Network Interface(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Current Bandwidth" -value "\Network Interface(*)\Current Bandwidth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage" -value "\Paging File(*)\% Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage Peak" -value "\Paging File(*)\% Usage Peak" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\% Processor Time" -value "\Process(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(Microsoft.Exchange.Search.ExSearch)\% Processor Time" -value "\Process(Microsoft.Exchange.Search.ExSearch)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Virtual Bytes" -value "\Process(*)\Virtual Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Data Operations/sec" -value "\Process(*)\IO Data Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Other Operations/sec" -value "\Process(*)\IO Other Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Interrupt Time" -value "\Processor(*)\% Interrupt Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Privileged Time" -value "\Processor(_Total)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Processor Time" -value "\Processor(_Total)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Processor Time" -value "\Processor(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% User Time" -value "\Processor(_Total)\% User Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Nonpaged Failures" -value "\Server\Pool Nonpaged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Paged Failures" -value "\Server\Pool Paged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Context Switches/sec" -value "\System\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Processor Queue Length" -value "\System\Processor Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Connection Failures" -value "\TCPv4\Connection Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Connections Established" -value "\TCPv4\Connections Established" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Connections Reset" -value "\TCPv4\Connections Reset" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Segments Received/sec" -value "\TCPv4\Segments Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Connection Failures" -value "\TCPv6\Connection Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Connections Established" -value "\TCPv6\Connections Established" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Connections Reset" -value "\TCPv6\Connections Reset" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Segments Received/sec" -value "\TCPv6\Segments Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Connection Attempts/sec" -value "\Web Service(_Total)\Connection Attempts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Current Connections" -value "\Web Service(_Total)\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Other Request Methods/sec" -value "\Web Service(_Total)\Other Request Methods/sec" -Force
    }
    
    
    
    if($Exchange2007Mailbox_Technet) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Transfer" -value "\LogicalDisk(*)\Avg. Disk sec/Transfer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -value "\MSExchange Assistants(*)\Average Event Processing Time In seconds" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events in queue" -value "\MSExchange Assistants(*)\Events in queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Events Polled/sec" -value "\MSExchange Assistants(*)\Events Polled/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Assistants(*)\Mailboxes processed/sec" -value "\MSExchange Assistants(*)\Mailboxes processed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -value "\MSExchange Calendar Attendant\Average Calendar Attendant Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Calendar Attendant\Requests Failed" -value "\MSExchange Calendar Attendant\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Page Fault Stalls/sec" -value "\MSExchange Database(Information Store)\Database Page Fault Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Record Stalls/sec" -value "\MSExchange Database(Information Store)\Log Record Stalls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Threads Waiting" -value "\MSExchange Database(Information Store)\Log Threads Waiting" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Version buckets allocated" -value "\MSExchange Database(Information Store)\Version buckets allocated" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache % Hit" -value "\MSExchange Database(Information Store)\Database Cache % Hit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Database Cache Size (MB)" -value "\MSExchange Database(Information Store)\Database Cache Size (MB)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database(Information Store)\Log Bytes Write/sec" -value "\MSExchange Database(Information Store)\Log Bytes Write/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Reads Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -value "\MSExchange Database ==> Instances(*)\I/O Database Writes Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -value "\MSExchange Database ==> Instances(*)\Log Generation Checkpoint Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replica Seeder\Seeding Finished %" -value "\MSExchange Replica Seeder\Seeding Finished %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication\CopyQueueLength" -value "\MSExchange Replication\CopyQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Replication\ReplayQueueLength" -value "\MSExchange Replication\ReplayQueueLength" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Average Resource Booking Processing Time" -value "\MSExchange Resource Booking\Average Resource Booking Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Resource Booking\Requests Failed" -value "\MSExchange Resource Booking\Requests Failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Average document indexing time" -value "\MSExchange Search Indices(*)\Average document indexing time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Full Crawl Mode Status" -value "\MSExchange Search Indices(*)\Full Crawl Mode Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -value "\MSExchange Search Indices(*)\Recent Average Latency of RPCs Used to Obtain Content" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Search Indices(*)\Throttling Delay Value" -value "\MSExchange Search Indices(*)\Throttling Delay Value" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\ROP Requests outstanding" -value "\MSExchange Store Interface(*)\ROP Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -value "\MSExchange Store Interface(_Total)\RPC Latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests failed (%)" -value "\MSExchange Store Interface(*)\RPC Requests failed (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests outstanding" -value "\MSExchange Store Interface(*)\RPC Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Requests sent/sec" -value "\MSExchange Store Interface(*)\RPC Requests sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests (%)" -value "\MSExchange Store Interface(*)\RPC Slow requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -value "\MSExchange Store Interface(*)\RPC Slow requests latency average (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchange Store Interface(_Total)\RPC Requests outstanding" -value "\MSExchange Store Interface(_Total)\RPC Requests outstanding" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -value "\MSExchangeIS\Client: RPCs Failed: Server Too Busy / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Averaged Latency" -value "\MSExchangeIS\RPC Averaged Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Client Backoff/sec" -value "\MSExchangeIS\RPC Client Backoff/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Num. of Slow Packets" -value "\MSExchangeIS\RPC Num. of Slow Packets" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Operations/sec" -value "\MSExchangeIS\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\RPC Requests" -value "\MSExchangeIS\RPC Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow QP Threads" -value "\MSExchangeIS\Slow QP Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\Slow Search Threads" -value "\MSExchangeIS\Slow Search Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS\User Count" -value "\MSExchangeIS\User Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -value "\MSExchangeIS Client(*)\Directory Access: LDAP Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Log Records/sec" -value "\MSExchangeIS Client(*)\JET Log Records/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\JET Pages Read/sec" -value "\MSExchangeIS Client(*)\JET Pages Read/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Average Latency" -value "\MSExchangeIS Client(*)\RPC Average Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Client(*)\RPC Operations/sec" -value "\MSExchangeIS Client(*)\RPC Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Categorization Count" -value "\MSExchangeIS Mailbox(*)\Categorization Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Messages Delivered/sec" -value "\MSExchangeIS Mailbox(_Total)\Messages Delivered/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Messages Queued For Submission" -value "\MSExchangeIS Mailbox(_Total)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Messages Sent/sec" -value "\MSExchangeIS Mailbox(_Total)\Messages Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(_Total)\Messages Submitted/sec" -value "\MSExchangeIS Mailbox(_Total)\Messages Submitted/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Search Task Rate" -value "\MSExchangeIS Mailbox(*)\Search Task Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -value "\MSExchangeIS Mailbox(*)\Slow FindRow Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(_Total)\Messages Queued For Submission" -value "\MSExchangeIS Public(_Total)\Messages Queued For Submission" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeIS Public(_Total)\Replication Receive Queue Size" -value "\MSExchangeIS Public(_Total)\Replication Receive Queue Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Failed Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -value "\MSExchangeMailSubmission(*)\Hub Servers In Retry" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -value "\MSExchangeMailSubmission(*)\Successful Submissions Per Second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -value "\MSExchangeMailSubmission(*)\Temporary Submission Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(msftefd)\% Processor Time" -value "\Process(msftefd)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(store)\% Processor Time" -value "\Process(store)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(Microsoft.Exchange.Search.ExSearch)\% Processor Time" -value "\Process(Microsoft.Exchange.Search.ExSearch)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(MSExchangeMailboxAssistants)\% Processor Time" -value "\Process(MSExchangeMailboxAssistants)\% Processor Time" -Force
    }

    
    
    if($Exchange2007UM_Technet) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Call Answer Queued Messages" -value "\MSExchangeUMAvailability\Call Answer Queued Messages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Directory Access Failures" -value "\MSExchangeUMAvailability\Directory Access Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Hub Transport Access Failures" -value "\MSExchangeUMAvailability\Hub Transport Access Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Mailbox Server Access Failures" -value "\MSExchangeUMAvailability\Mailbox Server Access Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Queued OCS User Event Notifications" -value "\MSExchangeUMAvailability\Queued OCS User Event Notifications" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMAvailability\Unhandled Exceptions/sec" -value "\MSExchangeUMAvailability\Unhandled Exceptions/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMCallAnswer\Calls Disconnected by Callers During UM Audio Hourglass" -value "\MSExchangeUMCallAnswer\Calls Disconnected by Callers During UM Audio Hourglass" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSExchangeUMPerformance\Operations over Six Seconds" -value "\MSExchangeUMPerformance\Operations over Six Seconds" -Force
    }
    
    
    
    if($FASTSearch) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Indexer(*)\API queue load" -value "\FAST Search Indexer(*)\API queue load" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Indexer Status(*)\Time since last index" -value "\FAST Search Indexer Status(*)\Time since last index" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Indexer(*)\Documents in indexer" -value "\FAST Search Indexer(*)\Documents in indexer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Indexer(*)\Disk low state" -value "\FAST Search Indexer(*)\Disk low state" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search QRServer(*)\# of Fail user queries" -value "\FAST Search QRServer(*)\# of Fail user queries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Content Distributor(*)\Document processors" -value "\FAST Search Content Distributor(*)\Document processors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\FAST Search Indexer(*)\Fixml fill rate" -value "\FAST Search Indexer(*)\Fixml fill rate" -Force
    }
    
    
    
    if($Forefront_TMG) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Cache\Disk Failure Rate (failures/sec)" -value "\Forefront TMG Cache\Disk Failure Rate (failures/sec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Packet Engine\Active Connections" -value "\Forefront TMG Firewall Packet Engine\Active Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Packet Engine\Backlogged Packets" -value "\Forefront TMG Firewall Packet Engine\Backlogged Packets" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Packet Engine\Dropped Packets/sec" -value "\Forefront TMG Firewall Packet Engine\Dropped Packets/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Packet Engine\ReInject Available IRPs" -value "\Forefront TMG Firewall Packet Engine\ReInject Available IRPs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\Accepting TCP Connections" -value "\Forefront TMG Firewall Service\Accepting TCP Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\Available Worker Threads" -value "\Forefront TMG Firewall Service\Available Worker Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\DNS Cache Hits %" -value "\Forefront TMG Firewall Service\DNS Cache Hits %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\Pending DNS Resolutions" -value "\Forefront TMG Firewall Service\Pending DNS Resolutions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\Pending TCP Connections" -value "\Forefront TMG Firewall Service\Pending TCP Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Firewall Service\Worker Threads" -value "\Forefront TMG Firewall Service\Worker Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\% Failing Requests/sec" -value "\Forefront TMG Web Proxy\% Failing Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Failing Requests/sec" -value "\Forefront TMG Web Proxy\Failing Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Requests/sec" -value "\Forefront TMG Web Proxy\Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Active Web Sessions" -value "\Forefront TMG Web Proxy\Active Web Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Average Milliseconds/request" -value "\Forefront TMG Web Proxy\Average Milliseconds/request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Current Cache Fetches Average Milliseconds/request" -value "\Forefront TMG Web Proxy\Current Cache Fetches Average Milliseconds/request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Current Direct Fetches Average Milliseconds/request" -value "\Forefront TMG Web Proxy\Current Direct Fetches Average Milliseconds/request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\% HTTPS inspection failures/sec" -value "\Forefront TMG Web Proxy\% HTTPS inspection failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\HTTPS connection inspection/sec" -value "\Forefront TMG Web Proxy\HTTPS connection inspection/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\HTTPS inspection failures/sec" -value "\Forefront TMG Web Proxy\HTTPS inspection failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Total Failing Requests" -value "\Forefront TMG Web Proxy\Total Failing Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Cache Hit Ratio for Last 10K Requests (%)" -value "\Forefront TMG Web Proxy\Cache Hit Ratio for Last 10K Requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Memory Pool for HTTP Requests (%)" -value "\Forefront TMG Web Proxy\Memory Pool for HTTP Requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Forefront TMG Web Proxy\Memory Pool for SSL Requests (%)" -value "\Forefront TMG Web Proxy\Memory Pool for SSL Requests (%)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSSQL`$MSFW:Buffer Manager\Lazy writes/sec" -value "\MSSQL`$MSFW:Buffer Manager\Lazy writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MSSQL`$ISARS:Buffer Manager\Lazy writes/sec" -value "\MSSQL`$ISARS:Buffer Manager\Lazy writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Netlogon(_Total)\Semaphore Holders" -value "\Netlogon(_Total)\Semaphore Holders" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Netlogon(_Total)\Semaphore Waiters" -value "\Netlogon(_Total)\Semaphore Waiters" -Force
    }
    
    
    
    if($HyperV) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster Shared Volumes(*)\IO Read Bytes" -value "\Cluster Shared Volumes(*)\IO Read Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster Shared Volumes(*)\IO Write Bytes" -value "\Cluster Shared Volumes(*)\IO Write Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory Balancer(*)\Average" -value "\Hyper-V Dynamic Memory Balancer(*)\Average" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Added Memory" -value "\Hyper-V Dynamic Memory VM(*)\Added Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Average Pressure" -value "\Hyper-V Dynamic Memory VM(*)\Average Pressure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Removed Memory" -value "\Hyper-V Dynamic Memory VM(*)\Removed Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor\Logical Processors" -value "\Hyper-V Hypervisor\Logical Processors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor\Virtual Processors" -value "\Hyper-V Hypervisor\Virtual Processors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Logical Processor(*)\Context Switches/sec" -value "\Hyper-V Hypervisor Logical Processor(*)\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Logical Processor(*)\% Total Run Time" -value "\Hyper-V Hypervisor Logical Processor(*)\% Total Run Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Partition(*)\Virtual TLB Flush Entires/sec" -value "\Hyper-V Hypervisor Partition(*)\Virtual TLB Flush Entires/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Partition(*)\Address Spaces" -value "\Hyper-V Hypervisor Root Partition(*)\Address Spaces" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Partition(*)\Deposited Pages" -value "\Hyper-V Hypervisor Root Partition(*)\Deposited Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Virtual Processor(*)\Hypercalls Cost" -value "\Hyper-V Hypervisor Root Virtual Processor(*)\Hypercalls Cost" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Virtual Processor(_Total)\IO Instructions Cost" -value "\Hyper-V Hypervisor Root Virtual Processor(_Total)\IO Instructions Cost" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Virtual Processor(*)\% Guest Run Time" -value "\Hyper-V Hypervisor Virtual Processor(*)\% Guest Run Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Machine Health Summary\Health Critical" -value "\Hyper-V Virtual Machine Health Summary\Health Critical" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Network Adapter(*)\Bytes/sec" -value "\Hyper-V Virtual Network Adapter(*)\Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Error Count" -value "\Hyper-V Virtual Storage Device(*)\Error Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Read Bytes/sec" -value "\Hyper-V Virtual Storage Device(*)\Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Write Bytes/sec" -value "\Hyper-V Virtual Storage Device(*)\Write Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Switch(*)\Bytes/sec" -value "\Hyper-V Virtual Switch(*)\Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Numa Node(*)\ProcessorCount" -value "\Hyper-V VM Vid Numa Node(*)\ProcessorCount" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Partition(*)\Preferred NUMA Node Index" -value "\Hyper-V VM Vid Partition(*)\Preferred NUMA Node Index" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Partition(*)\Remote Physical Pages" -value "\Hyper-V VM Vid Partition(*)\Remote Physical Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Transfers/sec" -value "\PhysicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RemoteFX Root GPU Management(*)\Resources: VMs running RemoteFX" -value "\RemoteFX Root GPU Management(*)\Resources: VMs running RemoteFX" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RemoteFX Root GPU Management(*)\VRAM: Available MB per GPU" -value "\RemoteFX Root GPU Management(*)\VRAM: Available MB per GPU" -Force
    }


    
    if($HyperV2012) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Virtual Processor(*)\% Guest Run Time" -value "\Hyper-V Hypervisor Virtual Processor(*)\% Guest Run Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Logical Processor(*)\% Total Run Time" -value "\Hyper-V Hypervisor Logical Processor(*)\% Total Run Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Network Adapter(*)\Bytes/sec" -value "\Hyper-V Virtual Network Adapter(*)\Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Switch(*)\Bytes/sec" -value "\Hyper-V Virtual Switch(*)\Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Read Bytes/sec" -value "\Hyper-V Virtual Storage Device(*)\Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Write Bytes/sec" -value "\Hyper-V Virtual Storage Device(*)\Write Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Storage Device(*)\Error Count" -value "\Hyper-V Virtual Storage Device(*)\Error Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Machine Health Summary\Health Critical" -value "\Hyper-V Virtual Machine Health Summary\Health Critical" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor\Logical Processors" -value "\Hyper-V Hypervisor\Logical Processors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor\Virtual Processors" -value "\Hyper-V Hypervisor\Virtual Processors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Partition(*)\Deposited Pages" -value "\Hyper-V Hypervisor Root Partition(*)\Deposited Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Partition(*)\Remote Physical Pages" -value "\Hyper-V VM Vid Partition(*)\Remote Physical Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Numa Node(*)\ProcessorCount" -value "\Hyper-V VM Vid Numa Node(*)\ProcessorCount" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V VM Vid Partition(*)\Preferred NUMA Node Index" -value "\Hyper-V VM Vid Partition(*)\Preferred NUMA Node Index" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Virtual Processor(*)\Hypercalls Cost" -value "\Hyper-V Hypervisor Root Virtual Processor(*)\Hypercalls Cost" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Virtual Processor(_Total)\IO Instructions Cost" -value "\Hyper-V Hypervisor Root Virtual Processor(_Total)\IO Instructions Cost" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Partition(*)\Virtual TLB Flush Entires/sec" -value "\Hyper-V Hypervisor Partition(*)\Virtual TLB Flush Entires/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Added Memory" -value "\Hyper-V Dynamic Memory VM(*)\Added Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Average Pressure" -value "\Hyper-V Dynamic Memory VM(*)\Average Pressure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Removed Memory" -value "\Hyper-V Dynamic Memory VM(*)\Removed Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory Balancer(*)\Average Pressure" -value "\Hyper-V Dynamic Memory Balancer(*)\Average Pressure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RemoteFX Root GPU Management(*)\Resources: VMs running RemoteFX" -value "\RemoteFX Root GPU Management(*)\Resources: VMs running RemoteFX" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\RemoteFX Root GPU Management(*)\VRAM: Available MB per GPU" -value "\RemoteFX Root GPU Management(*)\VRAM: Available MB per GPU" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Root Partition(*)\Address Spaces" -value "\Hyper-V Hypervisor Root Partition(*)\Address Spaces" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Hypervisor Logical Processor(*)\Context Switches/sec" -value "\Hyper-V Hypervisor Logical Processor(*)\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Transfers/sec" -value "\PhysicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Guest Visible Physical Memory" -value "\Hyper-V Dynamic Memory VM(*)\Guest Visible Physical Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Dynamic Memory VM(*)\Smart Paging Working Set Size" -value "\Hyper-V Dynamic Memory VM(*)\Smart Paging Working Set Size" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\NUMA Node Memory(*)\Available MBytes" -value "\NUMA Node Memory(*)\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Virtual Switch Processor(*)\Number of VMQs" -value "\Hyper-V Virtual Switch Processor(*)\Number of VMQs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV Volume Cache(*)\Cache Size - Configured" -value "\Cluster CSV Volume Cache(*)\Cache Size - Configured" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV Volume Cache(*)\Cache Size - Current" -value "\Cluster CSV Volume Cache(*)\Cache Size - Current" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV Volume Cache(*)\Cache IO Read - Bytes/sec" -value "\Cluster CSV Volume Cache(*)\Cache IO Read - Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV Volume Cache(*)\Disk IO Read - Bytes/Sec" -value "\Cluster CSV Volume Cache(*)\Disk IO Read - Bytes/Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Replica VM(*)\Network Bytes Recv" -value "\Hyper-V Replica VM(*)\Network Bytes Recv" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Hyper-V Replica VM(Hoster-Replica-Test)\Network Bytes Sent" -value "\Hyper-V Replica VM(Hoster-Replica-Test)\Network Bytes Sent" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV File System(*)\Redirected Read Bytes/sec" -value "\Cluster CSV File System(*)\Redirected Read Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cluster CSV File System(*)\Redirected Write Bytes/sec" -value "\Cluster CSV File System(*)\Redirected Write Bytes/sec" -Force
    }
    
    
    
    if($InternetInformationServices) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Current Application Pool State" -value "\APP_POOL_WAS(*)\Current Application Pool State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Current Application Pool Uptime" -value "\APP_POOL_WAS(*)\Current Application Pool Uptime" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Current Worker Processes" -value "\APP_POOL_WAS(*)\Current Worker Processes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Recent Worker Process Failures" -value "\APP_POOL_WAS(*)\Recent Worker Process Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Total Worker Process Failures" -value "\APP_POOL_WAS(*)\Total Worker Process Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Total Worker Process Ping Failures" -value "\APP_POOL_WAS(*)\Total Worker Process Ping Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Total Worker Process Shutdown Failures" -value "\APP_POOL_WAS(*)\Total Worker Process Shutdown Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\APP_POOL_WAS(*)\Total Worker Process Startup Failures" -value "\APP_POOL_WAS(*)\Total Worker Process Startup Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\ArrivalRate" -value "\HTTP Service Request Queues(*)\ArrivalRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\CacheHitRate" -value "\HTTP Service Request Queues(*)\CacheHitRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\CurrentQueueSize" -value "\HTTP Service Request Queues(*)\CurrentQueueSize" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\MaxQueueItemAge" -value "\HTTP Service Request Queues(*)\MaxQueueItemAge" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\RejectedRequests" -value "\HTTP Service Request Queues(*)\RejectedRequests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Request Queues(*)\RejectionRate" -value "\HTTP Service Request Queues(*)\RejectionRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\AllRequests" -value "\HTTP Service Url Groups(*)\AllRequests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\BytesReceivedRate" -value "\HTTP Service Url Groups(*)\BytesReceivedRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\BytesSentRate" -value "\HTTP Service Url Groups(*)\BytesSentRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\BytesTransferredRate" -value "\HTTP Service Url Groups(*)\BytesTransferredRate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\ConnectionAttempts" -value "\HTTP Service Url Groups(*)\ConnectionAttempts" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\CurrentConnections" -value "\HTTP Service Url Groups(*)\CurrentConnections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\GetRequests" -value "\HTTP Service Url Groups(*)\GetRequests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\HeadRequests" -value "\HTTP Service Url Groups(*)\HeadRequests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\HTTP Service Url Groups(*)\MaxConnections" -value "\HTTP Service Url Groups(*)\MaxConnections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Active Requests" -value "\W3SVC_W3WP(*)\Active Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Active Threads Count" -value "\W3SVC_W3WP(*)\Active Threads Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Current File Cache Memory " -value "\W3SVC_W3WP(*)\Current File Cache Memory" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Current Files Cached" -value "\W3SVC_W3WP(*)\Current Files Cached" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Current Metadata Cached" -value "\W3SVC_W3WP(*)\Current Metadata Cached" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Current URIs Cached" -value "\W3SVC_W3WP(*)\Current URIs Cached" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\File Cache Misses / sec" -value "\W3SVC_W3WP(*)\File Cache Misses / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Maximum Threads Count" -value "\W3SVC_W3WP(*)\Maximum Threads Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Metadata Cache Misses / sec" -value "\W3SVC_W3WP(*)\Metadata Cache Misses / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Output Cache Current Memory Usage" -value "\W3SVC_W3WP(*)\Output Cache Current Memory Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Output Cache Misses / sec" -value "\W3SVC_W3WP(*)\Output Cache Misses / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Requests / Sec" -value "\W3SVC_W3WP(*)\Requests / Sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\W3SVC_W3WP(*)\Total Threads" -value "\W3SVC_W3WP(*)\Total Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\WAS_W3WP(*)\Active Listener Channels" -value "\WAS_W3WP(*)\Active Listener Channels" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\WAS_W3WP(*)\Active Protocol Handlers" -value "\WAS_W3WP(*)\Active Protocol Handlers" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\WAS_W3WP(*)\Health Ping Reply Latency" -value "\WAS_W3WP(*)\Health Ping Reply Latency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(*)\Bytes Total/sec" -value "\Web Service(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Connection Attempts/sec" -value "\Web Service(_Total)\Connection Attempts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(*)\Current Anonymous Users" -value "\Web Service(*)\Current Anonymous Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Current Connections" -value "\Web Service(_Total)\Current Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(*)\Current NonAnonymous Users" -value "\Web Service(*)\Current NonAnonymous Users" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\ISAPI Extension Requests/sec" -value "\Web Service(_Total)\ISAPI Extension Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service(_Total)\Other Request Methods/sec" -value "\Web Service(_Total)\Other Request Methods/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service Cache\File Cache Hits %" -value "\Web Service Cache\File Cache Hits %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service Cache\Kernel: URI Cache Hits %" -value "\Web Service Cache\Kernel: URI Cache Hits %" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Web Service Cache\Output Cache Current Hits" -value "\Web Service Cache\Output Cache Current Hits" -Force
    }

    
    
    if($MOSS2007) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache flushes / second" -value "\SharePoint Publishing Cache(*)\Publishing cache flushes / second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache hit ratio" -value "\SharePoint Publishing Cache(*)\Publishing cache hit ratio" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache misses / sec" -value "\SharePoint Publishing Cache(*)\Publishing cache misses / sec" -Force
    }
    
    
    
    if($MOSS2007_MSSearch) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Archival Plugin(Portal_Content)\Total docs in first queue" -value "\Office Server Search Archival Plugin(Portal_Content)\Total docs in first queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Archival Plugin(Portal_Content)\Total docs in Second queue" -value "\Office Server Search Archival Plugin(Portal_Content)\Total docs in Second queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Archival Plugin(ProfileImport)\Total docs in first queue" -value "\Office Server Search Archival Plugin(ProfileImport)\Total docs in first queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Archival Plugin(ProfileImport)\Total docs in Second queue" -value "\Office Server Search Archival Plugin(ProfileImport)\Total docs in Second queue" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Gatherer\Idle Threads" -value "\Office Server Search Gatherer\Idle Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Gatherer\Threads Accessing Network" -value "\Office Server Search Gatherer\Threads Accessing Network" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Gatherer\Filtering Threads" -value "\Office Server Search Gatherer\Filtering Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Office Server Search Gatherer\Threads In Plug-ins" -value "\Office Server Search Gatherer\Threads In Plug-ins" -Force
    }
    
    
    
    if($MOSS2010) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Current Page Requests" -value "\SharePoint Foundation(*)\Current Page Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Executing Sql Queries" -value "\SharePoint Foundation(*)\Executing Sql Queries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Executing Time/Page Request" -value "\SharePoint Foundation(*)\Executing Time/Page Request" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Incoming Page Requests Rate" -value "\SharePoint Foundation(*)\Incoming Page Requests Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Reject Page Requests Rate" -value "\SharePoint Foundation(*)\Reject Page Requests Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Responded Page Requests Rate" -value "\SharePoint Foundation(*)\Responded Page Requests Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Sql Query Executing  time" -value "\SharePoint Foundation(*)\Sql Query Executing  time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(*)\Throttled Page Requests" -value "\SharePoint Foundation(*)\Throttled Page Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(_Total)\Active Heap Count" -value "\SharePoint Foundation(_Total)\Active Heap Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Foundation(_Total)\Active Threads" -value "\SharePoint Foundation(_Total)\Active Threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache flushes / second" -value "\SharePoint Publishing Cache(*)\Publishing cache flushes / second" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache hits / sec" -value "\SharePoint Publishing Cache(*)\Publishing cache hits / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(*)\Publishing cache hit count" -value "\SharePoint Publishing Cache(*)\Publishing cache hit count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(_Total)\Total number of cache flushes" -value "\SharePoint Publishing Cache(_Total)\Total number of cache flushes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(_Total)\Publishing cache hit ratio" -value "\SharePoint Publishing Cache(_Total)\Publishing cache hit ratio" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SharePoint Publishing Cache(_Total)\Publishing cache misses / sec" -value "\SharePoint Publishing Cache(_Total)\Publishing cache misses / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\OSS Search Archival Plugin(_Total)\Total documents" -value "\OSS Search Archival Plugin(_Total)\Total documents" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\OSS Search Gatherer\Documents Filtered" -value "\OSS Search Gatherer\Documents Filtered" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\OSS Search Gatherer\Documents Filtered Rate" -value "\OSS Search Gatherer\Documents Filtered Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\OSS Search Gatherer\Performance Level" -value "\OSS Search Gatherer\Performance Level" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\OSS Search Gatherer\Threads Accessing Network" -value "\OSS Search Gatherer\Threads Accessing Network" -Force
    }
    
    
    
    if($OCS2007R2Archiving) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LC:Arch Service - 01 - READ\Arch Service - 002 - Messages that failed validation" -value "\LC:Arch Service - 01 - READ\Arch Service - 002 - Messages that failed validation" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:Arch Service - 01 - READ\Arch Service - 006 - Dropped messages from MQ" -value "\LC:Arch Service - 01 - READ\Arch Service - 006 - Dropped messages from MQ" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:Arch Service - 02 - WRITE\Arch Service - 002 - Messages failed to be written to DB" -value "\LC:Arch Service - 02 - WRITE\Arch Service - 002 - Messages failed to be written to DB" -Force
    }
    
    
    
    if($OCS2007R2CWA) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 00 - Directory Search(_Total)\CWA - 003 - LDAP errors" -value "\CWA - 00 - Directory Search(_Total)\CWA - 003 - LDAP errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 01 - Authentication Module(_Total)\CWA - 003 - Forms auth logon failures" -value "\CWA - 01 - Authentication Module(_Total)\CWA - 003 - Forms auth logon failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 01 - Authentication Module(_Total)\CWA - 007 - IWA auth logon failures" -value "\CWA - 01 - Authentication Module(_Total)\CWA - 007 - IWA auth logon failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 01 - Authentication Module(_Total)\CWA - 012 - LDAP error total" -value "\CWA - 01 - Authentication Module(_Total)\CWA - 012 - LDAP error total" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 01 - Authentication Module(_Total)\CWA - 014 - Logons denied due to server throttling" -value "\CWA - 01 - Authentication Module(_Total)\CWA - 014 - Logons denied due to server throttling" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 02 - Security(_Total)\CWA - 001 - Requests rejected due to invalid ticket / sec" -value "\CWA - 02 - Security(_Total)\CWA - 001 - Requests rejected due to invalid ticket / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 03 - User session Service(_Total)\CWA - 004 - Sessions failed to sign in" -value "\CWA - 03 - User session Service(_Total)\CWA - 004 - Sessions failed to sign in" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 03 - User session Service(_Total)\CWA - 007 - Total sessions timed out" -value "\CWA - 03 - User session Service(_Total)\CWA - 007 - Total sessions timed out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 03 - User session Service(_Total)\CWA - 016 - Requests to nonexistent sessions" -value "\CWA - 03 - User session Service(_Total)\CWA - 016 - Requests to nonexistent sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CWA - 03 - User session Service(_Total)\CWA - 018 - Total requests failed" -value "\CWA - 03 - User session Service(_Total)\CWA - 018 - Total requests failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MCX - 01 - User session Service(_Total)\MCX - 005 - Sessions failed to sign in" -value "\MCX - 01 - User session Service(_Total)\MCX - 005 - Sessions failed to sign in" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\MCX - 01 - User session Service(_Total)\MCX - 011 - Total sessions timed out" -value "\MCX - 01 - User session Service(_Total)\MCX - 011 - Total sessions timed out" -Force

    }
    
    
    
    if($OCS2007R2Edge) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Auth - 00 - Requests\- 003 - Bad Requests Received/sec" -value "\A/V Auth - 00 - Requests\- 003 - Bad Requests Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 00 - UDP Counters(_Total)\- 004 - Authentication Failures/sec" -value "\A/V Edge - 00 - UDP Counters(_Total)\- 004 - Authentication Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 00 - UDP Counters(_Total)\- 006 - Allocate Requests Exceeding Port Limit/sec" -value "\A/V Edge - 00 - UDP Counters(_Total)\- 006 - Allocate Requests Exceeding Port Limit/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 00 - UDP Counters(_Total)\- 021 - Packets Dropped/sec" -value "\A/V Edge - 00 - UDP Counters(_Total)\- 021 - Packets Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 00 - UDP Counters(_Total)\- 026 - Active Sessions Exceeding Avg Bandwidth Limit" -value "\A/V Edge - 00 - UDP Counters(_Total)\- 026 - Active Sessions Exceeding Avg Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 00 - UDP Counters(_Total)\- 027 - Active Sessions Exceeding Peak Bandwidth Limit" -value "\A/V Edge - 00 - UDP Counters(_Total)\- 027 - Active Sessions Exceeding Peak Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 01 - TCP Counters(_Total)\- 004 - Authentication Failures/sec" -value "\A/V Edge - 01 - TCP Counters(_Total)\- 004 - Authentication Failures/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 01 - TCP Counters(_Total)\- 006 - Allocate Requests Exceeding Port Limit/sec" -value "\A/V Edge - 01 - TCP Counters(_Total)\- 006 - Allocate Requests Exceeding Port Limit/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 01 - TCP Counters(_Total)\- 022 - Packets Dropped/sec" -value "\A/V Edge - 01 - TCP Counters(_Total)\- 022 - Packets Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 01 - TCP Counters(_Total)\- 025 - Active Sessions Exceeding Avg Bandwidth Limit" -value "\A/V Edge - 01 - TCP Counters(_Total)\- 025 - Active Sessions Exceeding Avg Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 01 - TCP Counters(_Total)\- 026 - Active Sessions Exceeding Peak Bandwidth Limit" -value "\A/V Edge - 01 - TCP Counters(_Total)\- 026 - Active Sessions Exceeding Peak Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 02 - Total Counters(_Total)\- 027 - Active Sessions Exceeding Avg Bandwidth Limit" -value "\A/V Edge - 02 - Total Counters(_Total)\- 027 - Active Sessions Exceeding Avg Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\A/V Edge - 02 - Total Counters(_Total)\- 028 - Active Sessions Exceeding Peak Bandwidth Limit" -value "\A/V Edge - 02 - Total Counters(_Total)\- 028 - Active Sessions Exceeding Peak Bandwidth Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -value "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 004 - Above Limit Connections Dropped (Access Proxies only)" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 004 - Above Limit Connections Dropped (Access Proxies only)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -value "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -value "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -value "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -value "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 08 - Access Edge Server Connections\SIP - 013 - Rejected External Edge Server Connections/sec" -value "\LC:SIP - 08 - Access Edge Server Connections\SIP - 013 - Rejected External Edge Server Connections/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 08 - Access Edge Server Connections\SIP - 015 - Rejected External Edge Client Connections/sec" -value "\LC:SIP - 08 - Access Edge Server Connections\SIP - 015 - Rejected External Edge Client Connections/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 021 - Messages/sec Dropped Due To Unknown Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 021 - Messages/sec Dropped Due To Unknown Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 027 - External Messages/sec Dropped Due To Blocked Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 027 - External Messages/sec Dropped Due To Blocked Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 029 - Client Messages/sec Dropped Due To Unsupported Internal Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 029 - Client Messages/sec Dropped Due To Unsupported Internal Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 031 - Remote User Client Messages/sec Dropped Due To Access Disabled" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 031 - Remote User Client Messages/sec Dropped Due To Access Disabled" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 033 - Anonymous User Client Messages/sec Dropped Due To Access Disabled" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 033 - Anonymous User Client Messages/sec Dropped Due To Access Disabled" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 053 - Messages/sec From Users Not Enabled For Federation" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 053 - Messages/sec From Users Not Enabled For Federation" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 055 - Messages/sec From Users Not Enabled For Public IM Providers" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 055 - Messages/sec From Users Not Enabled For Public IM Providers" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 057 - External Messages/sec Dropped Due To Unresolved Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 057 - External Messages/sec Dropped Due To Unresolved Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 059 - External Messages/sec Dropped Due To Blocked IM Service Provider Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 059 - External Messages/sec Dropped Due To Blocked IM Service Provider Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 061 - External Messages/sec Dropped Due To Unauthorized IM Service Provider Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 061 - External Messages/sec Dropped Due To Unauthorized IM Service Provider Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 063 - External Messages/sec Dropped Due To Unauthorized Allowed or Discovered Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 063 - External Messages/sec Dropped Due To Unauthorized Allowed or Discovered Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 065 - External Messages/sec Dropped Due To Incompatible DNS SRV Result for Allowed Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 065 - External Messages/sec Dropped Due To Incompatible DNS SRV Result for Allowed Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 067 - External Messages/sec Dropped Due To Multiple Incompatible DNS SRV Results" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 067 - External Messages/sec Dropped Due To Multiple Incompatible DNS SRV Results" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 069 - External Messages/sec Dropped Due To Incompatible Message Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 069 - External Messages/sec Dropped Due To Incompatible Message Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 071 - Messages/sec Dropped Due To Incompatible Asserted Identity" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 071 - Messages/sec Dropped Due To Incompatible Asserted Identity" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 09 - Access Edge Server Messages\SIP - 073 - Messages/sec Dropped Due To Incompatible Boss Domain" -value "\LC:SIP - 09 - Access Edge Server Messages\SIP - 073 - Messages/sec Dropped Due To Incompatible Boss Domain" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAPROXY - 00 - Server Connections(_Total)\DATAPROXY - 034 - Current count of server connections that are throttled" -value "\LC:DATAPROXY - 00 - Server Connections(_Total)\DATAPROXY - 034 - Current count of server connections that are throttled" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAPROXY - 00 - Server Connections(_Total)\DATAPROXY - 041 - System is throttling" -value "\LC:DATAPROXY - 00 - Server Connections(_Total)\DATAPROXY - 041 - System is throttling" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAPROXY - 01 - Client Connections\DATAPROXY - 008 - Clients disconnected per second due to invalid cookie timestamp" -value "\LC:DATAPROXY - 01 - Client Connections\DATAPROXY - 008 - Clients disconnected per second due to invalid cookie timestamp" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAPROXY - 01 - Client Connections\DATAPROXY - 012 - Clients disconnected per second due to invalid cookie data" -value "\LC:DATAPROXY - 01 - Client Connections\DATAPROXY - 012 - Clients disconnected per second due to invalid cookie data" -Force
    }
    
    
    
    if($OCS2007R2Enterprise) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RGS - 01 - Response Group Service Match Making\RGS - 001 - Current number of calls" -value "\LC:RGS - 01 - Response Group Service Match Making\RGS - 001 - Current number of calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:AcpMcu - 00 - AcpMcu Conferences\ACPMCU - 007 - Throttled Sip Connections" -value "\LC:AcpMcu - 00 - AcpMcu Conferences\ACPMCU - 007 - Throttled Sip Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:AcpMcu - 02 - MCU Health And Performance\ACPMCU - 005 - MCU Health State" -value "\LC:AcpMcu - 02 - MCU Health And Performance\ACPMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -value "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 004 - Number of rejected metrics reports" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 004 - Number of rejected metrics reports" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 014 - Total number of metrics reports rejected by the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 014 - Total number of metrics reports rejected by the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 015 - Total number of failures occurred while sending reports to the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 015 - Total number of failures occurred while sending reports to the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 016 - Total number of reports that could not be sent to the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 016 - Total number of reports that could not be sent to the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:ImMcu - 00 - IMMcu Conferences\IMMCU - 020 - Throttled Sip Connections" -value "\LC:ImMcu - 00 - IMMcu Conferences\IMMCU - 020 - Throttled Sip Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:ImMcu - 02 - MCU Health And Performance\IMMCU - 005 - MCU Health State" -value "\LC:ImMcu - 02 - MCU Health And Performance\IMMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 006 - Failed Exchange UM calls" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 006 - Failed Exchange UM calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 022 - Received 5XX from VOIP gateway" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 022 - Received 5XX from VOIP gateway" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 025 - Calls failed due to gateway unavailability" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 025 - Calls failed due to gateway unavailability" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -value "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -value "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -value "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 04 - Responses\SIP - 052 - Local 500 Responses" -value "\LC:SIP - 04 - Responses\SIP - 052 - Local 500 Responses" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 04 - Responses\SIP - 054 - Local 503 Responses" -value "\LC:SIP - 04 - Responses\SIP - 054 - Local 503 Responses" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 002 - Security Association (SAs) Stored" -value "\LC:SIP - 06 - Authentication\SIP - 002 - Security Association (SAs) Stored" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 013 - Incoming Messages Not Authenticated/sec" -value "\LC:SIP - 06 - Authentication\SIP - 013 - Incoming Messages Not Authenticated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 015 - Incoming Messages Not Authorized/sec" -value "\LC:SIP - 06 - Authentication\SIP - 015 - Incoming Messages Not Authorized/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 027 - Authentication System Errors/sec" -value "\LC:SIP - 06 - Authentication\SIP - 027 - Authentication System Errors/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 000 - Average Holding Time For Incoming Messages" -value "\LC:SIP - 07 - Load Management\SIP - 000 - Average Holding Time For Incoming Messages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 006 - Incoming Messages Timed out" -value "\LC:SIP - 07 - Load Management\SIP - 006 - Incoming Messages Timed out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -value "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 000 - Queue Depth" -value "\LC:USrv - 00 - DBStore\USrv - 000 - Queue Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 002 - Queue Latency (msec)" -value "\LC:USrv - 00 - DBStore\USrv - 002 - Queue Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 004 - Sproc Latency (msec)" -value "\LC:USrv - 00 - DBStore\USrv - 004 - Sproc Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 014 - Total Dropped Requests" -value "\LC:USrv - 00 - DBStore\USrv - 014 - Total Dropped Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 17 - RPC Client(_Total)\USrv - 000 - Outstanding Outbound RPC Calls" -value "\LC:USrv - 17 - RPC Client(_Total)\USrv - 000 - Outstanding Outbound RPC Calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 20 - Https Transport\USrv - 013 - Average Outgoing Queue Delay (ms)" -value "\LC:USrv - 20 - Https Transport\USrv - 013 - Average Outgoing Queue Delay (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 23 - Conference Control\USrv - 004 - Outstanding C3P transactions" -value "\LC:USrv - 23 - Conference Control\USrv - 004 - Outstanding C3P transactions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 23 - Conference Control\USrv - 023 - Transactions Timed-Out / sec" -value "\LC:USrv - 23 - Conference Control\USrv - 023 - Transactions Timed-Out / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 24 - Conference Control Notification\USrv - 004 - Notifications in processing" -value "\LC:USrv - 24 - Conference Control Notification\USrv - 004 - Notifications in processing" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 011 - Factory Call Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 011 - Factory Call Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 019 - Create Conference Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 019 - Create Conference Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 021 - Allocation Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 021 - Allocation Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CAA - 00 - Operations\CAA - 000 - Incomplete calls per sec" -value "\CAA - 00 - Operations\CAA - 000 - Incomplete calls per sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\AVMCU - 00 - Operations\AVMCU - 000 - Number of Conferences" -value "\AVMCU - 00 - Operations\AVMCU - 000 - Number of Conferences" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\AVMCU - 04 - MCU Health And Performance\AVMCU - 005 - MCU Health State" -value "\AVMCU - 04 - MCU Health And Performance\AVMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 016 - Invalid input requests/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 016 - Invalid input requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 018 - Timed out Requests that fetch Security Descriptors/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 018 - Timed out Requests that fetch Security Descriptors/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 024 - Soap exceptions/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 024 - Soap exceptions/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 026 - Compliance errors" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 026 - Compliance errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 031 - Resources over conference space limit" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 031 - Resources over conference space limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 038 - Number of Unhandled Application Exception" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 038 - Number of Unhandled Application Exception" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 041 - Session queues state" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 041 - Session queues state" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 02 - MCU Health And Performance\DATAMCU - 005 - MCU Health State" -value "\LC:DATAMCU - 02 - MCU Health And Performance\DATAMCU - 005 - MCU Health State" -Force
    }
    
    
    
    if($OCS2007R2Mediation) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\MediationServer - 03 - Health Indices\- 000 - Load Call Failure Index" -value "\MediationServer - 03 - Health Indices\- 000 - Load Call Failure Index" -Force
    }
    
    
    
    if($OCS2007R2Monitoring) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMS - 00 - QoEMonitoringServer\QMS - 002 - Total number of message transactions that failed" -value "\LC:QMS - 00 - QoEMonitoringServer\QMS - 002 - Total number of message transactions that failed" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:CDR Service - 01 - READ\CDR Service - 002 - Messages that failed validation" -value "\LC:CDR Service - 01 - READ\CDR Service - 002 - Messages that failed validation" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:CDR Service - 01 - READ\CDR Service - 006 - Dropped messages from MQ" -value "\LC:CDR Service - 01 - READ\CDR Service - 006 - Dropped messages from MQ" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:CDR Service - 02 - WRITE\CDR Service - 002 - Messages failed to be written to DB" -value "\LC:CDR Service - 02 - WRITE\CDR Service - 002 - Messages failed to be written to DB" -Force
    }
    
    
    
    if($OCS2007R2Standard) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RGS - 01 - Response Group Service Match Making\RGS - 001 - Current number of calls" -value "\LC:RGS - 01 - Response Group Service Match Making\RGS - 001 - Current number of calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:AcpMcu - 00 - AcpMcu Conferences\ACPMCU - 007 - Throttled Sip Connections" -value "\LC:AcpMcu - 00 - AcpMcu Conferences\ACPMCU - 007 - Throttled Sip Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:AcpMcu - 02 - MCU Health And Performance\ACPMCU - 005 - MCU Health State" -value "\LC:AcpMcu - 02 - MCU Health And Performance\ACPMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -value "\LC:API - 00 - API Application Instance Counters(_Total)\API - 026 - Transactions Pending Dispatch Completion" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 004 - Number of rejected metrics reports" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 004 - Number of rejected metrics reports" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 014 - Total number of metrics reports rejected by the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 014 - Total number of metrics reports rejected by the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 015 - Total number of failures occurred while sending reports to the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 015 - Total number of failures occurred while sending reports to the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 016 - Total number of reports that could not be sent to the external report consumer" -value "\LC:QMSAgent - 00 - QoEMonitoringServerAgent\QMSAgent - 016 - Total number of reports that could not be sent to the external report consumer" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:ImMcu - 00 - IMMcu Conferences\IMMCU - 020 - Throttled Sip Connections" -value "\LC:ImMcu - 00 - IMMcu Conferences\IMMCU - 020 - Throttled Sip Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:ImMcu - 02 - MCU Health And Performance\IMMCU - 005 - MCU Health State" -value "\LC:ImMcu - 02 - MCU Health And Performance\IMMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 006 - Failed Exchange UM calls" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 006 - Failed Exchange UM calls" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 022 - Received 5XX from VOIP gateway" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 022 - Received 5XX from VOIP gateway" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 025 - Calls failed due to gateway unavailability" -value "\LC:RoutingApps - 00 - UC Routing Applications\RoutingApps - 025 - Calls failed due to gateway unavailability" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 001 - TLS Connections Active" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 018 - Sends Timed-Out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 023 - Flow-controlled Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -value "\LC:SIP - 01 - Peers(_Total)\SIP - 024 - Flow-controlled Connections Dropped" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 005 - Incoming Requests Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -value "\LC:SIP - 02 - Protocol\SIP - 009 - Incoming Responses Dropped/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -value "\LC:SIP - 02 - Protocol\SIP - 011 - Messages/sec Dropped Due To Certificate Mismatch" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -value "\LC:SIP - 02 - Protocol\SIP - 012 - Messages In Server" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -value "\LC:SIP - 02 - Protocol\SIP - 021 - Average Incoming Message Processing Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 04 - Responses\SIP - 052 - Local 500 Responses" -value "\LC:SIP - 04 - Responses\SIP - 052 - Local 500 Responses" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 04 - Responses\SIP - 054 - Local 503 Responses" -value "\LC:SIP - 04 - Responses\SIP - 054 - Local 503 Responses" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 002 - Security Association (SAs) Stored" -value "\LC:SIP - 06 - Authentication\SIP - 002 - Security Association (SAs) Stored" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 013 - Incoming Messages Not Authenticated/sec" -value "\LC:SIP - 06 - Authentication\SIP - 013 - Incoming Messages Not Authenticated/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 015 - Incoming Messages Not Authorized/sec" -value "\LC:SIP - 06 - Authentication\SIP - 015 - Incoming Messages Not Authorized/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 06 - Authentication\SIP - 027 - Authentication System Errors/sec" -value "\LC:SIP - 06 - Authentication\SIP - 027 - Authentication System Errors/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 000 - Average Holding Time For Incoming Messages" -value "\LC:SIP - 07 - Load Management\SIP - 000 - Average Holding Time For Incoming Messages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 006 - Incoming Messages Timed out" -value "\LC:SIP - 07 - Load Management\SIP - 006 - Incoming Messages Timed out" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -value "\LC:SIP - 07 - Load Management\SIP - 009 - Address space usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 000 - Queue Depth" -value "\LC:USrv - 00 - DBStore\USrv - 000 - Queue Depth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 002 - Queue Latency (msec)" -value "\LC:USrv - 00 - DBStore\USrv - 002 - Queue Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 004 - Sproc Latency (msec)" -value "\LC:USrv - 00 - DBStore\USrv - 004 - Sproc Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 00 - DBStore\USrv - 014 - Total Dropped Requests" -value "\LC:USrv - 00 - DBStore\USrv - 014 - Total Dropped Requests" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 20 - Https Transport\USrv - 013 - Average Outgoing Queue Delay (ms)" -value "\LC:USrv - 20 - Https Transport\USrv - 013 - Average Outgoing Queue Delay (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 23 - Conference Control\USrv - 004 - Outstanding C3P transactions" -value "\LC:USrv - 23 - Conference Control\USrv - 004 - Outstanding C3P transactions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 23 - Conference Control\USrv - 023 - Transactions Timed-Out / sec" -value "\LC:USrv - 23 - Conference Control\USrv - 023 - Transactions Timed-Out / sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 24 - Conference Control Notification\USrv - 004 - Notifications in processing" -value "\LC:USrv - 24 - Conference Control Notification\USrv - 004 - Notifications in processing" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 011 - Factory Call Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 011 - Factory Call Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 019 - Create Conference Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 019 - Create Conference Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 021 - Allocation Latency (msec)" -value "\LC:USrv - 25 - Conference Mcu Allocator\USrv - 021 - Allocation Latency (msec)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\AVMCU - 00 - Operations\AVMCU - 000 - Number of Conferences" -value "\AVMCU - 00 - Operations\AVMCU - 000 - Number of Conferences" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\AVMCU - 04 - MCU Health And Performance\AVMCU - 005 - MCU Health State" -value "\AVMCU - 04 - MCU Health And Performance\AVMCU - 005 - MCU Health State" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\CAA - 00 - Operations\CAA - 000 - Incomplete calls per sec" -value "\CAA - 00 - Operations\CAA - 000 - Incomplete calls per sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 016 - Invalid input requests/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 016 - Invalid input requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 018 - Timed out Requests that fetch Security Descriptors/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 018 - Timed out Requests that fetch Security Descriptors/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 024 - Soap exceptions/sec" -value "\LC:DLX - 00 - Address Book and Distribution List Expansion\DLX - 024 - Soap exceptions/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 026 - Compliance errors" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 026 - Compliance errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 031 - Resources over conference space limit" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 031 - Resources over conference space limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 038 - Number of Unhandled Application Exception" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 038 - Number of Unhandled Application Exception" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 041 - Session queues state" -value "\LC:DATAMCU - 00 - DataMCU Conferences\DATAMCU - 041 - Session queues state" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LC:DATAMCU - 02 - MCU Health And Performance\DATAMCU - 005 - MCU Health State" -value "\LC:DATAMCU - 02 - MCU Health And Performance\DATAMCU - 005 - MCU Health State" -Force
    }
    
    
    
    if($SQLServer) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Process(sqlservr)\% Privileged Time" -value "\Process(sqlservr)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Forwarded Records/sec" -value "\SQLServer:Access Methods\Forwarded Records/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\FreeSpace Scans/sec" -value "\SQLServer:Access Methods\FreeSpace Scans/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Full Scans/sec" -value "\SQLServer:Access Methods\Full Scans/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Index Searches/sec" -value "\SQLServer:Access Methods\Index Searches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Page Splits/sec" -value "\SQLServer:Access Methods\Page Splits/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Scan Point Revalidations/sec" -value "\SQLServer:Access Methods\Scan Point Revalidations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Workfiles Created/sec" -value "\SQLServer:Access Methods\Workfiles Created/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Access Methods\Worktables Created/sec" -value "\SQLServer:Access Methods\Worktables Created/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Buffer cache hit ratio" -value "\SQLServer:Buffer Manager\Buffer cache hit ratio" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Checkpoint pages/sec" -value "\SQLServer:Buffer Manager\Checkpoint pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Free pages" -value "\SQLServer:Buffer Manager\Free pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Lazy writes/sec" -value "\SQLServer:Buffer Manager\Lazy writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Page life expectancy" -value "\SQLServer:Buffer Manager\Page life expectancy" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Page lookups/sec" -value "\SQLServer:Buffer Manager\Page lookups/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Page reads/sec" -value "\SQLServer:Buffer Manager\Page reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Buffer Manager\Page writes/sec" -value "\SQLServer:Buffer Manager\Page writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:General Statistics\Logins/sec" -value "\SQLServer:General Statistics\Logins/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:General Statistics\Logouts/sec" -value "\SQLServer:General Statistics\Logouts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:General Statistics\User Connections" -value "\SQLServer:General Statistics\User Connections" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Latches\Latch Waits/sec" -value "\SQLServer:Latches\Latch Waits/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Latches\Total Latch Wait Time (ms)" -value "\SQLServer:Latches\Total Latch Wait Time (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Locks(*)\Lock Requests/sec" -value "\SQLServer:Locks(*)\Lock Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Locks(*)\Lock Timeouts/sec" -value "\SQLServer:Locks(*)\Lock Timeouts/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Locks(*)\Lock Wait Time (ms)" -value "\SQLServer:Locks(*)\Lock Wait Time (ms)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Locks(*)\Lock Waits/sec" -value "\SQLServer:Locks(*)\Lock Waits/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Locks(*)\Number of Deadlocks/sec" -value "\SQLServer:Locks(*)\Number of Deadlocks/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Memory Manager\Memory Grants Pending" -value "\SQLServer:Memory Manager\Memory Grants Pending" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Memory Manager\Target Server Memory(KB)" -value "\SQLServer:Memory Manager\Target Server Memory(KB)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:Memory Manager\Total Server Memory (KB)" -value "\SQLServer:Memory Manager\Total Server Memory (KB)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:SQL Statistics\Batch Requests/sec" -value "\SQLServer:SQL Statistics\Batch Requests/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:SQL Statistics\SQL Compilations/sec" -value "\SQLServer:SQL Statistics\SQL Compilations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\SQLServer:SQL Statistics\SQL Re-Compilations/sec" -value "\SQLServer:SQL Statistics\SQL Re-Compilations/sec" -Force
    }
    
    
    
    if($SystemOverview) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\% Processor Time" -value "\Process(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Virtual Bytes" -value "\Process(*)\Virtual Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Data Operations/sec" -value "\Process(*)\IO Data Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Other Operations/sec" -value "\Process(*)\IO Other Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\ID Process" -value "\Process(*)\ID Process" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Read Operations/sec" -value "\Process(*)\IO Read Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\IO Write Operations/sec" -value "\Process(*)\IO Write Operations/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\% Privileged Time" -value "\Process(*)\% Privileged Time" -Force
    }
    
    
    
    if($SystemOverview_Quick) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Cache\Dirty Pages" -value "\Cache\Dirty Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cache\Lazy Write Flushes/sec" -value "\Cache\Lazy Write Flushes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\% Free Space" -value "\LogicalDisk(*)\% Free Space" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\% Idle Time" -value "\LogicalDisk(*)\% Idle Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Queue Length" -value "\LogicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Bytes/Read" -value "\LogicalDisk(*)\Avg. Disk Bytes/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Bytes/Write" -value "\LogicalDisk(*)\Avg. Disk Bytes/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Current Disk Queue Length" -value "\LogicalDisk(*)\Current Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Bytes/sec" -value "\LogicalDisk(*)\Disk Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Free Megabytes" -value "\LogicalDisk(*)\Free Megabytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Reads/sec" -value "\LogicalDisk(*)\Disk Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Writes/sec" -value "\LogicalDisk(*)\Disk Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\% Committed Bytes In Use" -value "\Memory\% Committed Bytes In Use" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Available MBytes" -value "\Memory\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Cache Bytes" -value "\Memory\Cache Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Commit Limit" -value "\Memory\Commit Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Committed Bytes" -value "\Memory\Committed Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free & Zero Page List Bytes" -value "\Memory\Free & Zero Page List Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free System Page Table Entries" -value "\Memory\Free System Page Table Entries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Input/sec" -value "\Memory\Pages Input/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Output/sec" -value "\Memory\Pages Output/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages/sec" -value "\Memory\Pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Nonpaged Bytes" -value "\Memory\Pool Nonpaged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Paged Bytes" -value "\Memory\Pool Paged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\System Cache Resident Bytes" -value "\Memory\System Cache Resident Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Pages RePurposed/sec" -value "\Memory\Transition Pages RePurposed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Inspection System\Average inspection latency (sec/bytes)" -value "\Network Inspection System\Average inspection latency (sec/bytes)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Total/sec" -value "\Network Interface(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Received/sec" -value "\Network Interface(*)\Bytes Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Sent/sec" -value "\Network Interface(*)\Bytes Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization" -value "\Network Interface(*)\% Network Utilization" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization Received" -value "\Network Interface(*)\% Network Utilization Received" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization Sent" -value "\Network Interface(*)\% Network Utilization Sent" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Current Bandwidth" -value "\Network Interface(*)\Current Bandwidth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Output Queue Length" -value "\Network Interface(*)\Output Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Outbound Errors" -value "\Network Interface(*)\Packets Outbound Errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Received/sec" -value "\Network Interface(*)\Packets Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Sent/sec" -value "\Network Interface(*)\Packets Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets/sec" -value "\Network Interface(*)\Packets/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage" -value "\Paging File(*)\% Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk Queue Length" -value "\PhysicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Current Disk Queue Length" -value "\PhysicalDisk(*)\Current Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Bytes/sec" -value "\PhysicalDisk(*)\Disk Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Reads/sec" -value "\PhysicalDisk(*)\Disk Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Writes/sec" -value "\PhysicalDisk(*)\Disk Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Idle Time" -value "\Processor(*)\% Idle Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% DPC Time" -value "\Processor(*)\% DPC Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Interrupt Time" -value "\Processor(*)\% Interrupt Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Privileged Time" -value "\Processor(*)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Processor Time" -value "\Processor(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% User Time" -value "\Processor(*)\% User Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\DPC Rate" -value "\Processor(*)\DPC Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Privileged Time" -value "\Processor(_Total)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Processor Time" -value "\Processor(_Total)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor Information(*)\% of Maximum Frequency" -value "\Processor Information(*)\% of Maximum Frequency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor Information(*)\Parking Status" -value "\Processor Information(*)\Parking Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Nonpaged Failures" -value "\Server\Pool Nonpaged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Paged Failures" -value "\Server\Pool Paged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Context Switches/sec" -value "\System\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Processor Queue Length" -value "\System\Processor Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\System Calls/sec" -value "\System\System Calls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Connection Failures" -value "\TCPv4\Connection Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Connection Failures" -value "\TCPv6\Connection Failures" -Force
    }
    
    
    
    if($SystemOverview_Standard) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Cache\Dirty Pages" -value "\Cache\Dirty Pages" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Cache\Lazy Write Flushes/sec" -value "\Cache\Lazy Write Flushes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\% Free Space" -value "\LogicalDisk(*)\% Free Space" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\% Idle Time" -value "\LogicalDisk(*)\% Idle Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Queue Length" -value "\LogicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Bytes/Read" -value "\LogicalDisk(*)\Avg. Disk Bytes/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk Bytes/Write" -value "\LogicalDisk(*)\Avg. Disk Bytes/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Current Disk Queue Length" -value "\LogicalDisk(*)\Current Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Bytes/sec" -value "\LogicalDisk(*)\Disk Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Transfers/sec" -value "\LogicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Free Megabytes" -value "\LogicalDisk(*)\Free Megabytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Read" -value "\LogicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Reads/sec" -value "\LogicalDisk(*)\Disk Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Avg. Disk sec/Write" -value "\LogicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\LogicalDisk(*)\Disk Writes/sec" -value "\LogicalDisk(*)\Disk Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\% Committed Bytes In Use" -value "\Memory\% Committed Bytes In Use" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Available MBytes" -value "\Memory\Available MBytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Cache Bytes" -value "\Memory\Cache Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Commit Limit" -value "\Memory\Commit Limit" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Committed Bytes" -value "\Memory\Committed Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free & Zero Page List Bytes" -value "\Memory\Free & Zero Page List Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Free System Page Table Entries" -value "\Memory\Free System Page Table Entries" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Input/sec" -value "\Memory\Pages Input/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages Output/sec" -value "\Memory\Pages Output/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pages/sec" -value "\Memory\Pages/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Nonpaged Bytes" -value "\Memory\Pool Nonpaged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Pool Paged Bytes" -value "\Memory\Pool Paged Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\System Cache Resident Bytes" -value "\Memory\System Cache Resident Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Memory\Transition Pages RePurposed/sec" -value "\Memory\Transition Pages RePurposed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Inspection System\Average inspection latency (sec/bytes)" -value "\Network Inspection System\Average inspection latency (sec/bytes)" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Total/sec" -value "\Network Interface(*)\Bytes Total/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Received/sec" -value "\Network Interface(*)\Bytes Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Bytes Sent/sec" -value "\Network Interface(*)\Bytes Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization" -value "\Network Interface(*)\% Network Utilization" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization Received" -value "\Network Interface(*)\% Network Utilization Received" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\% Network Utilization Sent" -value "\Network Interface(*)\% Network Utilization Sent" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Current Bandwidth" -value "\Network Interface(*)\Current Bandwidth" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Output Queue Length" -value "\Network Interface(*)\Output Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Outbound Errors" -value "\Network Interface(*)\Packets Outbound Errors" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Received/sec" -value "\Network Interface(*)\Packets Received/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets Sent/sec" -value "\Network Interface(*)\Packets Sent/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Network Interface(*)\Packets/sec" -value "\Network Interface(*)\Packets/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Paging File(*)\% Usage" -value "\Paging File(*)\% Usage" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\%% Idle Time" -value "\PhysicalDisk(*)\% Idle Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk Queue Length" -value "\PhysicalDisk(*)\Avg. Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Read" -value "\PhysicalDisk(*)\Avg. Disk sec/Read" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Avg. Disk sec/Write" -value "\PhysicalDisk(*)\Avg. Disk sec/Write" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Current Disk Queue Length" -value "\PhysicalDisk(*)\Current Disk Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Bytes/sec" -value "\PhysicalDisk(*)\Disk Bytes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Transfers/sec" -value "\PhysicalDisk(*)\Disk Transfers/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Reads/sec" -value "\PhysicalDisk(*)\Disk Reads/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\PhysicalDisk(*)\Disk Writes/sec" -value "\PhysicalDisk(*)\Disk Writes/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Private Bytes" -value "\Process(*)\Private Bytes" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Handle Count" -value "\Process(*)\Handle Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Thread Count" -value "\Process(*)\Thread Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Process(*)\Working Set" -value "\Process(*)\Working Set" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Print Queue(*)\Bytes Printed/sec" -value "\Print Queue(*)\Bytes Printed/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Print Queue(*)\Jobs" -value "\Print Queue(*)\Jobs" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Idle Time" -value "\Processor(*)\% Idle Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% DPC Time" -value "\Processor(*)\% DPC Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Interrupt Time" -value "\Processor(*)\% Interrupt Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Privileged Time" -value "\Processor(*)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% Processor Time" -value "\Processor(*)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\% User Time" -value "\Processor(*)\% User Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(*)\DPC Rate" -value "\Processor(*)\DPC Rate" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Privileged Time" -value "\Processor(_Total)\% Privileged Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor(_Total)\% Processor Time" -value "\Processor(_Total)\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor Information(*)\% of Maximum Frequency" -value "\Processor Information(*)\% of Maximum Frequency" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Processor Information(*)\Parking Status" -value "\Processor Information(*)\Parking Status" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Nonpaged Failures" -value "\Server\Pool Nonpaged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server\Pool Paged Failures" -value "\Server\Pool Paged Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Context Switches/sec" -value "\System\Context Switches/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\Processor Queue Length" -value "\System\Processor Queue Length" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\System\System Calls/sec" -value "\System\System Calls/sec" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv4\Connection Failures" -value "\TCPv4\Connection Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\TCPv6\Connection Failures" -value "\TCPv6\Connection Failures" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Server Work Queues(*)\Available Work Items" -value "\Server Work Queues(*)\Available Work Items" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Terminal Services\Active Sessions" -value "\Terminal Services\Active Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Terminal Services\Inactive Sessions" -value "\Terminal Services\Inactive Sessions" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Terminal Services\Total Sessions" -value "\Terminal Services\Total Sessions" -Force
    }
  
  
    
    if($VMWare) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Active in MB" -value "\VM Memory\Memory Active in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Ballooned in MB" -value "\VM Memory\Memory Ballooned in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Limit in MB" -value "\VM Memory\Memory Limit in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Mapped in MB" -value "\VM Memory\Memory Mapped in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Overhead in MB" -value "\VM Memory\Memory Overhead in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Reservation in MB" -value "\VM Memory\Memory Reservation in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Shared in MB" -value "\VM Memory\Memory Shared in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Shared Saved in MB" -value "\VM Memory\Memory Shared Saved in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Shares" -value "\VM Memory\Memory Shares" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Swapped in MB" -value "\VM Memory\Memory Swapped in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Memory\Memory Used in MB" -value "\VM Memory\Memory Used in MB" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\% Processor Time" -value "\VM Processor\% Processor Time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\CPU stolen time" -value "\VM Processor\CPU stolen time" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\Effective VM Speed in MHz" -value "\VM Processor\Effective VM Speed in MHz" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\Host processor speed in MHz" -value "\VM Processor\Host processor speed in MHz" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\Limit in MHz" -value "\VM Processor\Limit in MHz" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\Reservation in MHz" -value "\VM Processor\Reservation in MHz" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\VM Processor\Shares" -value "\VM Processor\Shares" -Force
    }
    
    
    if($XenApp) {
        
        $Object | Add-Member -MemberType noteproperty -Name "\Citrix Licensing\License Server Connection Failure" -value "\Citrix Licensing\License Server Connection Failure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Citrix MetaFrame Presentation Server\Data Store Connection Failure" -value "\Citrix MetaFrame Presentation Server\Data Store Connection Failure" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Citrix MetaFrame Presentation Server\Number of busy XML threads" -value "\Citrix MetaFrame Presentation Server\Number of busy XML threads" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Citrix MetaFrame Presentation Server\Resolution WorkItem Queue Ready Count" -value "\Citrix MetaFrame Presentation Server\Resolution WorkItem Queue Ready Count" -Force
        $Object | Add-Member -MemberType noteproperty -Name "\Citrix MetaFrame Presentation Server\WorkItem Queue Ready Count" -value "\Citrix MetaFrame Presentation Server\WorkItem Queue Ready Count" -Force
    }
    
            
    

    
    if($ShowCounter) {
    
        
        $Object | Get-Member -MemberType noteproperty | Sort-Object | Select-Object Name

        Break
    }
    
    
    if($ComputerName -eq $Env:ComputerName) {

        
        
        
        if((Test-Path $PerfLogDir) -eq $False) { 
            
            
            $NewPerfLogDir = New-Item "C:\PerfLogs" -Type Directory -Verbose
            $PerfLogDir = "C:\PerfLogs"
        }
        
        
        $CounterFilePath = $PerfLogDir + "\" + $CounterFileName

        
        if(Test-Path $CounterFilePath) {
            
            
            
            if($PSBoundParameters['Verbose']) { Remove-Item $CounterFilePath -Verbose }else{ Remove-Item $CounterFilePath }
        }
        
        
        $PropertyNames = $Object | Get-Member -MemberType noteproperty | Select -ExpandProperty Name
        
        
        foreach($PropertyName in $PropertyNames) {
        
            if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: Added $PropertyName Counter" -ForegroundColor blue }
            
            
            Add-Content -Path $CounterFilePath -Value $Object.$PropertyName
        }
        
        if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: Created $CounterFilePath" -ForegroundColor blue }
        
        
        $CounterOutputFileName = $PerfLogDir + "\" + $DataCollectorName + "_" + $ComputerName
        
        
        if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: Creating $DataCollectorName Data Collector Set" -ForegroundColor blue }
        Logman Create Counter $DataCollectorName -v mmddhhmm -cf $CounterFilePath -si $SampleInterval -f bincirc -o $CounterOutputFileName -max $MaximumSize
        
        if($Start) {
        
            
            if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: Starting $DataCollectorName Data Collector Set" -ForegroundColor blue }
            Logman Start $DataCollectorName
            
        }
            
        
        if($AutoStartup) {
        
            $StartupScriptsINIFile = "C:\Windows\System32\GroupPolicy\Machine\Scripts\scripts.ini"
            $LogmanStartupScriptPath = "C:\Windows\System32\GroupPolicy\Machine\Scripts\Startup\StartupPerfmon.bat"
            $StartupKeyParentPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Startup\0"
            $StartupKeyStateParentPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine\Scripts\Startup\0"
            
            if(Test-Path $LogmanStartupScriptPath) {
                
                if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: $LogmanStartupScriptPath Exist" -ForegroundColor blue }
                
                
                Add-Content -Path $LogmanStartupScriptPath -Value "Logman Start $DataCollectorName" -ErrorVariable UpdateStartupScript_Error
                
                if($PSBoundParameters['Verbose']) {
                    if($UpdateStartupScript_Error -eq $Null) { Write-Host "VERBOSE: Updated $LogmanStartupScriptPath" -ForegroundColor blue }
                }
            
            }else{
                
                
                Add-Content -Path $LogmanStartupScriptPath -Value "Logman Start $DataCollectorName" -ErrorVariable CreateStartupScript_Error
                
                if($PSBoundParameters['Verbose']) { 
                    if($CreateStartupScript_Error -eq $Null) { Write-Host "VERBOSE: Created $LogmanStartupScriptPath" -ForegroundColor blue }
                }
            }
            
            if(Test-Path $StartupKeyParentPath) {
                
                
                $LastKey = Get-ChildItem $StartupKeyParentPath | Select-Object -Last 1
                $StartupNewKey = [Int] $LastKey.PSChildName + 1
            
            }else{
            
                if(Test-Path $StartupKeyParentPath.TrimEnd("\Startup\0")) {
                
                New-Item -Path $StartupKeyParentPath.TrimEnd("\0")
                New-Item -Path $StartupKeyParentPath
                $StartupNewKey = 0
                
                }
            }
            
            if(Test-Path $StartupKeyStateParentPath) {
            
                
                $LastKey = Get-ChildItem $StartupKeyStateParentPath | Select-Object -Last 1
                $StartupStateNewKey = [Int] $LastKey.PSChildName + 1
            
            }else{

                if(Test-Path $StartupKeyStateParentPath.TrimEnd("\Startup\0")) {
                    
                    New-Item -Path $StartupKeyStateParentPath.TrimEnd("\0")
                    New-Item -Path $StartupKeyStateParentPath
                    $StartupStateNewKey = 0
                }
            }
            
            if(Test-Path $StartupScriptsINIFile) {
            
                if($StartupNewKey -eq $StartupStateNewKey) {
                    
                    
                    $StartupSection = Select-String -Path $StartupScriptsINIFile -Pattern "[Startup]" -SimpleMatch
                    
                    
                    if($StartupSection -eq $Null) {
                        Add-Content -Path $StartupScriptsINIFile -Value "[Startup]" -Encoding Unicode
                    }
                    
                    
                    $CmdLine = [String] $StartupNewKey + "CmdLine=" + $LogmanStartupScriptPath
                    $Parameters = [String] $StartupNewKey + "Parameters="
                    
                    
                    Add-Content -Path $StartupScriptsINIFile -Value $CmdLine -Encoding Unicode
                    Add-Content -Path $StartupScriptsINIFile -Value $Parameters -Encoding Unicode
                
                    
                    $NewStartupKeyPath = $StartupKeyParentPath + "\" + $StartupNewKey
                    
                    
                    New-Item -Path $NewStartupKeyPath
                    
                    
                    New-ItemProperty -Path $NewStartupKeyPath -Name "ExecTime" -PropertyType QWORD
                    New-ItemProperty -Path $NewStartupKeyPath -Name "IsPowershell" -PropertyType DWORD
                    New-ItemProperty -Path $NewStartupKeyPath -Name "Parameters"
                    New-ItemProperty -Path $NewStartupKeyPath -Name "Script" -Value $LogmanStartupScriptPath
            
                    
                    $NewStartupStateKeyPath = $StartupKeyStateParentPath + "\" + $StartupNewKey
                    
                    
                    New-Item -Path $NewStartupStateKeyPath
                    
                    
                    New-ItemProperty -Path $NewStartupStateKeyPath -Name "ExecTime" -PropertyType QWORD
                    New-ItemProperty -Path $NewStartupStateKeyPath -Name "Parameters"
                    New-ItemProperty -Path $NewStartupStateKeyPath -Name "Script" -Value $LogmanStartupScriptPath
                    
                    if($PSBoundParameters['Verbose']) { Write-Host "VERBOSE: Added $LogmanStartupScriptPath Startup Script for Local Computer" -ForegroundColor blue }
                }
            }
        }
        
    }else{

        
        
        
        Invoke-Command -ComputerName $ComputerName -ScriptBlock {
            
            param($PerfLogDir, $CounterFileName, $Object, $Verbose)

            
            if((Test-Path $PerfLogDir) -eq $False) { 
                
                
                $NewPerfLogDir = New-Item "C:\PerfLogs" -Type Directory -Verbose
                $PerfLogDir = "C:\PerfLogs"
            }
            
            
            $CounterFilePath = $PerfLogDir + "\" + $CounterFileName

            
            if(Test-Path $CounterFilePath) {
                
                
                
                if($Verbose) { Remove-Item $CounterFilePath -Verbose }else{ Remove-Item $CounterFilePath }
            }
            
            
            $PropertyNames = $Object | Get-Member -MemberType noteproperty | Select -ExpandProperty Name
            
            
            foreach($PropertyName in $PropertyNames) {
            
                if($Verbose) { Write-Host "VERBOSE: Added $PropertyName Counter" -ForegroundColor blue }
                
                
                Add-Content -Path $CounterFilePath -Value $Object.$PropertyName
            }
            
            if($Verbose) { Write-Host "VERBOSE: Created $CounterFilePath" -ForegroundColor blue }
            
        } -ArgumentList $PerfLogDir, $CounterFileName, $Object, $PSBoundParameters['Verbose'] -ErrorVariable CreateCounter_Error

        
        Invoke-Command -ComputerName $ComputerName -ScriptBlock {
            
            param($PerfLogDir, $CounterFileName, $DataCollectorName, $ComputerName, $SampleInterval, $MaximumSize, $Start)
            
            
            $CounterFilePath = $PerfLogDir + "\" + $CounterFileName
            
            
            $CounterOutputFileName = $PerfLogDir + "\" + $DataCollectorName + "_" + $ComputerName
            
            
            if($Verbose) { Write-Host "VERBOSE: Creating $DataCollectorName Data Collector Set" -ForegroundColor blue }
            Logman Create Counter $DataCollectorName -v mmddhhmm -cf $CounterFilePath -si $SampleInterval -f bincirc -o $CounterOutputFileName -max $MaximumSize

            if($Start) {
            
                
                if($Verbose) { Write-Host "VERBOSE: Starting $DataCollectorName Data Collector Set" -ForegroundColor blue }
                Logman Start $DataCollectorName
            }
            
        } -ArgumentList $PerfLogDir, $CounterFileName, $DataCollectorName, $ComputerName, $SampleInterval, $MaximumSize, $Start -ErrorVariable CreatePerformanceLog_Error
        
        
        
        if($AutoStartup) {
        
            
            Invoke-Command -ComputerName $ComputerName -ScriptBlock {
                
                param($LogmanStartupScriptPath, $DataCollectorName, $Verbose)
                
                $StartupScriptsINIFile = "C:\Windows\System32\GroupPolicy\Machine\Scripts\scripts.ini"
                $LogmanStartupScriptPath = "C:\Windows\System32\GroupPolicy\Machine\Scripts\Startup\StartupPerfmon.bat"
                $StartupKeyParentPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Startup\0"
                $StartupKeyStateParentPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine\Scripts\Startup\0"
                
                if(Test-Path $LogmanStartupScriptPath) {
                    
                    if($Verbose) { Write-Host "VERBOSE: $LogmanStartupScriptPath Exist" -ForegroundColor blue }
                    
                    
                    Add-Content -Path $LogmanStartupScriptPath -Value "Logman Start $DataCollectorName" -ErrorVariable UpdateStartupScript_Error
                
                    if($Verbose) { 
                        if($UpdateStartupScript_Error -eq $Null) { Write-Host "VERBOSE: Updated $LogmanStartupScriptPath" -ForegroundColor blue }
                    }
                
                }else{
                    
                    
                    Add-Content -Path $LogmanStartupScriptPath -Value "Logman Start $DataCollectorName" -ErrorVariable CreateStartupScript_Error
                    
                    if($Verbose) { 
                        if($CreateStartupScript_Error -eq $Null) { Write-Host "VERBOSE: Created $LogmanStartupScriptPath" -ForegroundColor blue }
                    }
                }
                
                if(Test-Path $StartupKeyParentPath) {
                    
                    
                    $LastKey = Get-ChildItem $StartupKeyParentPath | Select-Object -Last 1
                    $StartupNewKey = [Int] $LastKey.PSChildName + 1
                
                }else{
                
                    if(Test-Path $StartupKeyParentPath.TrimEnd("\Startup\0")) {
                    
                    New-Item -Path $StartupKeyParentPath.TrimEnd("\0")
                    New-Item -Path $StartupKeyParentPath
                    $StartupNewKey = 0
                    
                    }
                }
                
                if(Test-Path $StartupKeyStateParentPath) {
                
                    
                    $LastKey = Get-ChildItem $StartupKeyStateParentPath | Select-Object -Last 1
                    $StartupStateNewKey = [Int] $LastKey.PSChildName + 1
                
                }else{

                    if(Test-Path $StartupKeyStateParentPath.TrimEnd("\Startup\0")) {
                        
                        New-Item -Path $StartupKeyStateParentPath.TrimEnd("\0")
                        New-Item -Path $StartupKeyStateParentPath
                        $StartupStateNewKey = 0
                    }
                }
                
                if(Test-Path $StartupScriptsINIFile) {
                
                    if($StartupNewKey -eq $StartupStateNewKey) {
                        
                        
                        $StartupSection = Select-String -Path $StartupScriptsINIFile -Pattern "[Startup]" -SimpleMatch
                        
                        
                        if($StartupSection -eq $Null) {
                            Add-Content -Path $StartupScriptsINIFile -Value "[Startup]" -Encoding Unicode
                        }
                        
                        
                        $CmdLine = [String] $StartupNewKey + "CmdLine=" + $LogmanStartupScriptPath
                        $Parameters = [String] $StartupNewKey + "Parameters="
                        
                        
                        Add-Content -Path $StartupScriptsINIFile -Value $CmdLine -Encoding Unicode
                        Add-Content -Path $StartupScriptsINIFile -Value $Parameters -Encoding Unicode
                    
                        
                        $NewStartupKeyPath = $StartupKeyParentPath + "\" + $StartupNewKey
                        
                        
                        New-Item -Path $NewStartupKeyPath
                        
                        
                        New-ItemProperty -Path $NewStartupKeyPath -Name "ExecTime" -PropertyType QWORD
                        New-ItemProperty -Path $NewStartupKeyPath -Name "IsPowershell" -PropertyType DWORD
                        New-ItemProperty -Path $NewStartupKeyPath -Name "Parameters"
                        New-ItemProperty -Path $NewStartupKeyPath -Name "Script" -Value $LogmanStartupScriptPath
                
                        
                        $NewStartupStateKeyPath = $StartupKeyStateParentPath + "\" + $StartupNewKey
                        
                        
                        New-Item -Path $NewStartupStateKeyPath
                        
                        
                        New-ItemProperty -Path $NewStartupStateKeyPath -Name "ExecTime" -PropertyType QWORD
                        New-ItemProperty -Path $NewStartupStateKeyPath -Name "Parameters"
                        New-ItemProperty -Path $NewStartupStateKeyPath -Name "Script" -Value $LogmanStartupScriptPath
                        
                        if($Verbose) { Write-Host "VERBOSE: Added $LogmanStartupScriptPath Startup Script for Local Computer" -ForegroundColor blue }
                    }
                }

            } -ArgumentList $LogmanStartupScriptPath, $DataCollectorName, $PSBoundParameters['Verbose'] -ErrorVariable SetupLogmanStartup_Error
            
        }
        
    }
    
}

END {}

}