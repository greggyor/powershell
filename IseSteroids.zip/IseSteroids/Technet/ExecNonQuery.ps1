﻿#########################################################
# Script:      SqlExecNonQuery.ps1                      #
# Created By:  Nathon Dalton                            #
# Created On:  08/16/2011                               #
# Description: Execute a command against a SQL database #
#              without returning a result (NonQuery).   #
#########################################################
#############
# Functions #
#############
# Performs an ExecuteNonQuery command against the database connection.
function ExecNonQuery
{
    param (${_10011101101010110}, ${_01011110011101001})
    # Determine if parameters were correctly populated.
    if (!${_10011101101010110} -or !${_01011110011101001})
    {
        # One or more parameters didn't contain values.
        write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGUAYwBOAG8AbgBRAHUAZQByAHkAIABmAHUAbgBjAHQAaQBvAG4AIABjAGEAbABsAGUAZAAgAHcAaQB0AGgAIABuAG8AIABjAG8AbgBuAGUAYwB0AGkAbwBuACAAcwB0AHIAaQBuAGcAIABhAG4AZAAvAG8AcgAgAGMAbwBtAG0AYQBuAGQAIAB0AGUAeAB0AC4A')))
    }
    else
    {
        write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAUwBRAEwAIABDAG8AbgBuAGUAYwB0AGkAbwBuAC4ALgAuAA==')))
        # Instantiate new SqlConnection object.
        ${01010110010110000} = New-Object System.Data.SQLClient.SQLConnection
        # Set the SqlConnection object's connection string to the passed value.
        ${01010110010110000}.ConnectionString = ${_10011101101010110}
        # Perform database operations in try-catch-finally block since database operations often fail.
        try
        {
            write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgBpAG4AZwAgAFMAUQBMACAAQwBvAG4AbgBlAGMAdABpAG8AbgAuAC4ALgA=')))
            # Open the connection to the database.
            ${01010110010110000}.Open()
            write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAUwBRAEwAIABDAG8AbQBtAGEAbgBkAC4ALgAuAA==')))
            # Instantiate a SqlCommand object.
            ${00111011001001001} = New-Object System.Data.SQLClient.SQLCommand
            # Set the SqlCommand's connection to the SqlConnection object above.
            ${00111011001001001}.Connection = ${01010110010110000}
            # Set the SqlCommand's command text to the query value passed in.
            ${00111011001001001}.CommandText = ${_01011110011101001}
            write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGUAYwB1AHQAaQBuAGcAIABTAFEATAAgAEMAbwBtAG0AYQBuAGQALgAuAC4A')))
            # Execute the command against the database without returning results (NonQuery).
            ${00111011001001001}.ExecuteNonQuery()
        }
        catch [System.Data.SqlClient.SqlException]
        {
            # A SqlException occurred. According to documentation, this happens when a command is executed against a locked row.
            write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBuAGUAIABvAHIAIABtAG8AcgBlACAAbwBmACAAdABoAGUAIAByAG8AdwBzACAAYgBlAGkAbgBnACAAYQBmAGYAZQBjAHQAZQBkACAAdwBlAHIAZQAgAGwAbwBjAGsAZQBkAC4AIABQAGwAZQBhAHMAZQAgAGMAaABlAGMAawAgAHkAbwB1AHIAIABxAHUAZQByAHkAIABhAG4AZAAgAGQAYQB0AGEAIAB0AGgAZQBuACAAdAByAHkAIABhAGcAYQBpAG4ALgA=')))
        }
        catch
        {
            # An generic error occurred somewhere in the try area.
            write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBuACAAZQByAHIAbwByACAAbwBjAGMAdQByAHIAZQBkACAAdwBoAGkAbABlACAAYQB0AHQAZQBtAHAAdABpAG4AZwAgAHQAbwAgAG8AcABlAG4AIAB0AGgAZQAgAGQAYQB0AGEAYgBhAHMAZQAgAGMAbwBuAG4AZQBjAHQAaQBvAG4AIABhAG4AZAAgAGUAeABlAGMAdQB0AGUAIABhACAAYwBvAG0AbQBhAG4AZAAuAA==')))
        }
        finally {
            # Determine if the connection was opened.
            if (${01010110010110000}.State -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAGUAbgA='))))
            {
                write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAG8AcwBpAG4AZwAgAEMAbwBuAG4AZQBjAHQAaQBvAG4ALgAuAC4A')))
                # Close the currently open connection.
                ${01010110010110000}.Close()
            }
        }
    }
}
################
# Script Start #
################
# Specify SQL Connection String.
${_10011101101010110} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBlAHIAPQAoAGwAbwBjAGEAbAApADsAZABhAHQAYQBiAGEAcwBlAD0ATQB5AEQAQgA7AHQAcgB1AHMAdABlAGQAXwBjAG8AbgBuAGUAYwB0AGkAbwBuAD0AdAByAHUAZQA7AA==')))
# Execute SQL Command Against Database.
ExecNonQuery -_10011101101010110 ${_10011101101010110} -_01011110011101001 $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB4AGUAYwAgAHMAcABfAG0AeQBTAHQAbwByAGUAZABQAHIAbwBjAA==')))
write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UQB1AGUAcgB5ACAAQwBvAG0AcABsAGUAdABlACEA')))