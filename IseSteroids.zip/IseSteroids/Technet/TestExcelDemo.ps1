﻿# determine the script's location
$scriptPath = Split-Path $MyInvocation.MyCommand.Path

# get paths to required files
$imgPath = Join-Path $scriptPath Ensign.jpg
$GetRamData = Join-Path $scriptPath Get-InUseMemory.ps1
$RemoveComObject = Join-Path $scriptPath Remove-ComObject.ps1
$XLImgNoCleanup = Join-Path $scriptPath Excel_Image_Demo_No_Cleanup.ps1
$XLImgCleanup = Join-Path $scriptPath Excel_Image_Demo_Cleanup.ps1

# check for required files
[Array]$missing = $imgPath, $GetRamData, $RemoveComObject, $XLImgNoCleanup, $XLImgCleanup |
 Where-Object {-not (Test-Path $_ -PathType Leaf)}
if ($missing.Count) {
	Write-Error "Cannot find '$($missing[0])'. Make sure it is in the '$scriptPath' directory."
 exit
}

# instance to Excel to demonstrate Remove-ComObject does not remove COM objects outside its calling scoope 
$xl = New-Object -ComObject Excel.Application -Property @{Visible = $true; DisplayAlerts = $false}

# monitor running Excel process before executing Excel and images demo scripts
Write-Host Excel processes running before executing Excel and images demo scripts -ForegroundColor Black -BackgroundColor White
Get-Process Excel -ErrorAction SilentlyContinue

# dot source external function
. $RemoveComObject

# execute external scripts
& $XLImgNoCleanup
& $XLImgCleanup

# exit Excel; but process should remain running for a while
$xl.Quit()

# monitor running Excel process after executing Excel and images demo scripts
Write-Host Excel processes running after executing Excel and images demo scripts -ForegroundColor Black -BackgroundColor White
Write-Host '(should have the same ID as the one running at the start)' -ForegroundColor Black -BackgroundColor White
Get-Process Excel -ErrorAction SilentlyContinue

Write-Host Cleanup the Excel process instatiated in this script`'s scope that remains running after the end -ForegroundColor Black -BackgroundColor White
Remove-ComObject -Verbose
Start-Sleep -Milliseconds 300

# monitor running Excel process after executing Excel and images demo scripts
Write-Host Excel processes running now -ForegroundColor Black -BackgroundColor White
Get-Process Excel -ErrorAction SilentlyContinue