﻿



















Set-StrictMode -Version 2.0
 
${7} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbABlAG8AdQB0AGYAcwA='))) 
${6} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBIAEQATABpAGIAcgBhAHIAeQA=')))

${5} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACQAewA3AH0AXAAkAHsANgB9AA==')))


${2} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAG4AYQBuAHQAUwB3AGkAdABjAGgA')))
${4} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aABjAHAAXABBAGQAbQBpAG4AaQBzAHQAcgBhAHQAbwByAA==')))


${3} = @{ 
	
	
	
		Storage = @{	
		  VHDLibraryLocation = ${5}
		} 
	} 


${1} = @{ 
  
  AdminAccount = ${4}
  
  Clusters = ${3} 

  VMSettings = @{
    vSwitchName = ${2}  
	ACLS = @{
		Meter = @{
			Inbound = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADAALgAwAFwAMQA2AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuACoA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgA6ACoA'))))  
			Outbound = @( $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADAALgAwAFwAMQA2AA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAuACoA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgA6ACoA'))) )  
        } 
    } 
    
	Rates = @{
		BaseCost = 50

		MemoryCostPerGB = 20
		ProcessorCostPerGHz = 30
		IncomingNetworkCostPerGB = 10
		OutgoingNetworkCostPerGB = 30
	}
  }
}

return ${1}