﻿. $PSScriptRoot\ExternWin32API.ps1
${2} = ipmo $PSScriptRoot\readline.psm1 -AsCustomObject
${1} = (get-item function:prompt).scriptblock;
function global:prompt { "`b" }
function PSReadlinePrompt {
	& ${1}
}
function PSConsoleHostReadline {
    if ( ($Host.UI.RawUI.CursorPosition.X -eq 3) -and !$Host.UI.RawUI.KeyAvailable ) {
        ${2}.Edit({$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAA')))}, $false )
    }
    else {
        ${2}.Edit($function:PSReadlinePrompt , $true)
    }
}
$executioncontext.sessionstate.module.onremove = { set-item function:global:prompt ${1} -force }