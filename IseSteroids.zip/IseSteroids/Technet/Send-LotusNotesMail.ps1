﻿function Send-LotusNotesMail {
[CmdletBinding()]
param(
    [Parameter()] 
    [string]
	$NotesInstallDir = "C:\Program Files\IBM\Lotus\Notes",
    [Parameter()] 
    [string]
	$Password = "",
    [Parameter()] 
    [string]
	[ValidateNotNullOrEmpty()]
	$MailFileServer = "",
    [Parameter()] 
    [string]
	[ValidateNotNullOrEmpty()]
	$MailFile = "",
    [Parameter(Position=0, Mandatory=$true)] 
    [string[]]
	[ValidateNotNullOrEmpty()]
	$SendTo = "",
    [Parameter(Position=1, Mandatory=$true)] 
    [string]
	[ValidateNotNullOrEmpty()]
	$From = "",
    [Parameter(Position=2, Mandatory=$true)] 
    [string]
	$Subject = "",
    [Parameter(Position=3, Mandatory=$true)] 
    [string]
	$Body = "",
    [Parameter()] 
    [string]
	$Attachment = ""
)
regsvr32 "$NotesInstallDir\nlsxbe.dll" /s
${3} = New-Object -ComObject Lotus.NotesSession
${3}.Initialize("$Password")
${2} = ${3}.GetDatabase("$MailFileServer", "$MailFile")
if(${2}.isopen)
    {
    ${1} = ${2}.CreateDocument()
    ${1}.AppendItemValue("Form", "Memo") | Out-Null
    ${1}.AppendItemValue("SendTo", "$SendTo") | Out-Null
    ${1}.AppendItemValue("From", "$From") | Out-Null
    ${1}.AppendItemValue("Subject", "$Subject") | Out-Null
	${1}.AppendItemValue("Body", "$Body") | Out-Null
	if ($Attachment -ne "") {
		$(${1}.CreateRichTextItem("Attachment")).EmbedObject(1454, "", "$Attachment", "Attachment") | Out-Null
    }
	${1}.Save($True, $False) | Out-Null
    ${1}.Send($False)
    }
}