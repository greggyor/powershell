﻿${01010110100101100}=[RunspaceFactory]::CreateRunspace() 
${01010110100101100}.ApartmentState = "STA" 
${01010110100101100}.ThreadOptions = "ReuseThread" 
${01010110100101100}.Open() 
${01011001111011100} = [PowerShell]::Create() 
${01011001111011100}.Runspace = ${01010110100101100} 
${01011001111011100}.Runspace.SessionStateProxy.SetVariable("pwd",$pwd) 
[void]${01011001111011100}.AddScript({  
Add-Type –assemblyName PresentationFramework 
Add-Type –assemblyName PresentationCore 
Add-Type –assemblyName WindowsBase 
Add-Type -AssemblyName System.Windows.Forms 
${00011011101101101} = New-Object System.Windows.Controls.PrintDialog 
Function Create-Password { 
        [int]${00000011010010111} = 14 
        [int]${10001010101011100} = 3 
        [int]${10101111001111010} = 3 
        [int]${00111110000110110} = 3 
        [int]${01100100000010010} = 3 
        [int]${00111100011100100} = (${00000011010010111} - (${10001010101011100} + ${10101111001111010} + ${00111110000110110} + ${01100100000010010})) 
        If (${00111100011100100} -lt 0) { 
            [System.Windows.Forms.MessageBox]::Show("Password specification is not configured correctly, please make the proper edits and try again.","Warning") | Out-Null 
            Break 
            } 
        ${10100011000000001} = @("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z") 
        ${01000001110101001} = @("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z") 
        ${10011100110111000} = @(1,2,3,4,5,6,7,8,9,0) 
        ${01011010101011010} = @("!","@","#","%","&","(",")","`"",".","<",">","+","=","-","_") 
        ${01100100111000011} = ${10100011000000001} + ${01000001110101001} + ${10011100110111000} + ${01011010101011010} 
        ${01010001000011101} = @() 
        1..${10001010101011100} | ForEach {${01010001000011101} += Get-Random ${10100011000000001}} 
        1..${10101111001111010} | ForEach {${01010001000011101} += Get-Random ${01000001110101001}}  
        1..${00111110000110110} | ForEach {${01010001000011101} += Get-Random ${10011100110111000}} 
        1..${01100100000010010} | ForEach {${01010001000011101} += Get-Random ${01011010101011010}}     
        1..${00111100011100100} | ForEach {${01010001000011101} += Get-Random ${01100100111000011}}             
        ${00000111001011000}  = $Null 
        Get-Random ${01010001000011101} -count ${00000011010010111} | ForEach {[string]${00000111001011000} += $_} 
        Return ${00000111001011000}     
    } 
[xml]${10011101100010101} = @" 
<Window 
    xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' 
    xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' 
    Height = '500' Width = '750' ResizeMode = 'NoResize' WindowStartupLocation = 'CenterScreen'  
    ShowInTaskbar = 'True' Title = 'Password Generator Version 5.0'> 
    <Grid HorizontalAlignment="Stretch" ShowGridLines='false'> 
        <Grid.ColumnDefinitions> 
            <ColumnDefinition Width="25"/> 
            <ColumnDefinition Width="*"/> 
            <ColumnDefinition Width="*"/> 
            <ColumnDefinition Width="25"/> 
        </Grid.ColumnDefinitions> 
        <Grid.RowDefinitions> 
            <RowDefinition Height = '*'/> 
            <RowDefinition Height = 'Auto'/> 
            <RowDefinition Height = '*'/> 
            <RowDefinition Height = '*'/>                 
            <RowDefinition Height = '*'/> 
            <RowDefinition Height = '*'/> 
        </Grid.RowDefinitions> 
        <Label Grid.ColumnSpan = '4' Grid.Column = '0' Grid.Row = '0' HorizontalAlignment = 'Center' Foreground = 'Green' 
        FontWeight="Bold" FontSize="24" VerticalAlignment = 'Center'> 
        FOR OFFICIAL USE ONLY 
        </Label> 
        <TextBlock Grid.ColumnSpan = '2' Grid.Column = '1' Grid.Row = '1' HorizontalAlignment = 'Center' TextWrapping = 'wrap' 
        FontWeight="Bold" FontSize="15"> 
        Ensure your password contains at least 3 special characters, 3 numbers, 3  
        uppercase and 3 lowercase letters for a total of at least 14 characters long. 
        </TextBlock>  
        <Label Grid.Column = '1' Grid.Row = '2' HorizontalAlignment = 'Right' VerticalAlignment = 'Center' FontSize = '16' 
        FontWeight="Bold"> 
        Password: 
        </Label>       
        <TextBox x:Name = 'PassTextBlock' Grid.Column = '2' Grid.Row = '2' HorizontalAlignment = 'left' VerticalAlignment = 'Center' FontSize = '16' 
        FontWeight="Bold" IsReadOnly = 'True' Width = 'Auto'> 
        NOTVALID 
        </TextBox> 
        <CheckBox x:Name = 'PrintCheckBox' Grid.Column = '1' Grid.ColumnSpan = '2' Grid.Row = '3' HorizontalAlignment = 'Center' IsChecked = 'True' 
        VerticalAlignment = 'Center'> 
        Send to Printer 
        </CheckBox> 
        <Button x:Name = 'GenButton' Grid.Column = '1' Grid.ColumnSpan = '2' Grid.Row = '4' HorizontalAlignment = 'Center' Height = '30'> 
        Generate Password 
        </Button>          
        <Label Grid.ColumnSpan = '4' Grid.Column = '0' Grid.Row = '5' HorizontalAlignment = 'Center' Foreground = 'Green' 
        FontWeight="Bold" FontSize="24" VerticalAlignment = 'Center'> 
        FOR OFFICIAL USE ONLY 
        </Label>         
    </Grid>     
</Window> 
"@ 
${01111000011101000}=(New-Object System.Xml.XmlNodeReader ${10011101100010101}) 
${10011000101001111}=[Windows.Markup.XamlReader]::Load( ${01111000011101000} ) 
${01101101010000100} = ${10011000101001111}.FindName('GenButton') 
${00010110011111100} = ${10011000101001111}.FindName('PassTextBlock') 
${10111001101101100} = ${10011000101001111}.FindName('PrintCheckBox') 
${01101101010000100}.Add_Click({ 
    ${00010110011111100}.Text = Create-Password 
    [Windows.Forms.Clipboard]::SetText(${00010110011111100}.Text) 
    ${10011000101001111}.UpdateLayout() 
    If (${10111001101101100}.IsChecked) { 
        Try { 
            ${00011011101101101}.PrintVisual(${10011000101001111},'Window Print') 
            } 
        Catch { 
            If ($error[0] -match "printqueue") { 
                [windows.messagebox]::Show('No Default Printer specified!','Warning','OK','Exclamation') 
                } 
            Else { 
                [windows.messagebox]::Show('Unknown Error Occurred!','Error','OK','Exclamation') 
                } 
            } 
        } 
    })   
${10011000101001111}.Add_Closed({ 
    [Windows.Forms.Clipboard]::Clear() 
    })           
${10011000101001111}.ShowDialog() | Out-Null 
}).BeginInvoke()