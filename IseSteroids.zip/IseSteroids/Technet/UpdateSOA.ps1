﻿function UpdateSOA ($Server, $Domain, $RecType, $Value)
<#
$Server is your DNS server hosting the zone
$Domain is the zone that is to have its SOA modified
$RecType is the SOA record to be modified (see below for available options)
$Value is the value for the record to be modified (see below for types of data expected)

SOA records that can be modified via WMI, sourced from http://msdn.microsoft.com/en-us/library/windows/desktop/ms682734(v=vs.85).aspx#methods

class MicrosoftDNS_SOAType : MicrosoftDNS_ResourceRecord
{
  uint32 SerialNumber;
  string PrimaryServer;
  string ResponsibleParty;
  uint32 RefreshInterval;
  uint32 RetryDelay;
  uint32 ExpireLimit;
  uint32 MinimumTTL;
};
#>
{
   try #Call the wmi MicrosoftDNS_SOAType, set the proper SOA record and commit with the modify method
   {
   ${01001100111011010} = get-wmiObject -class $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQARABOAFMAXwBTAE8AQQBUAHkAcABlAA=='))) -namespace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBvAG8AdABcAE0AaQBjAHIAbwBzAG8AZgB0AEQATgBTAA=='))) -comp $Server | where-object {$_.ContainerName -LIKE $Domain}
   ${01001100111011010}.$RecType = $Value
   ${01001100111011010}.modify(${01001100111011010}.TTL, ${01001100111011010}.SerialNumber, ${01001100111011010}.PrimaryServer, ${01001100111011010}.ResponsibleParty, ${01001100111011010}.RefreshInterval, ${01001100111011010}.RetryDelay, ${01001100111011010}.ExpireLimit, ${01001100111011010}.MinimumTTL)
   }
   catch [system.exception] #If there was a problem, fail gracefully
   {
    write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGkAbABlAGQAIAB0AG8AIABTAGUAdAAgAHQAbwAgAHQAaABlACAARABOAFMAIABTAE8AQQAsACAAYwBoAGUAYwBrACAAeQBvAHUAcgAgAHAAYQByAGEAbQBlAHQAZQByAHMA')))
    write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAZQBwAHQAaQBvAG4AIABTAHQAcgBpAG4AZwA6AA==')))+$($_.Exception.Message)
    exit
   }
}
