﻿Set-SPEnterpriseSearchMetadataManagedProperty -Identity ContentType -SearchApplication $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGEAcgBjAGgAIABTAGUAcgB2AGkAYwBlACAAQQBwAHAAbABpAGMAYQB0AGkAbwBuAA=='))) -EnabledForScoping $true



