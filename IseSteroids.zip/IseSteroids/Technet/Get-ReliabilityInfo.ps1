﻿Function Get-ReliabilityInfo{
 

    Param(
    [String[]]$Computername=$Env:Computername,
    [String]$Type='Application Error'
    )

Process{
    ForEach ($Computer in $ComputerName){
        gwmi Win32_ReliabilityRecords -ComputerName $Computer |
        ?{$_.SourceName -eq $Type} |
        sort TimeGenerated |
        select SourceName,Logfile,TimeGenerated,EventIdentifier,Message
        }
    }
}