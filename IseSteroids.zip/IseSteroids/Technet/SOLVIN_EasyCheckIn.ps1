﻿



PARAM(
    [parameter(Mandatory=$true)]
	[string] 
	$ProjectServerURL 
	,
	[parameter(Mandatory=$true)]
	[string] 
	$DatabaseServer 
	,
	[parameter(Mandatory=$true)]
	[string] 
	$DraftDB 
   )



$connection= new-object system.data.sqlclient.sqlconnection 

$connection.ConnectionString =$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAHIAdgBlAHIAPQAkAEQAYQB0AGEAYgBhAHMAZQBzAGUAcgB2AGUAcgA7AGQAYQB0AGEAYgBhAHMAZQA9ACQARAByAGEAZgB0AEQAQgA7AHQAcgB1AHMAdABlAGQAXwBjAG8AbgBuAGUAYwB0AGkAbwBuAD0AVAByAHUAZQA='))) 

Write-host "connection information:" 

$connection 

Write-host "connect to database successful." 

$connection.open() 



$SqlCmd = New-Object System.Data.SqlClient.SqlCommand 

$SqlQuery = "SELECT [Proj_UID] FROM [dbo].[MSP_projects] WHERE proj_checkoutby is not null and proj_type in (0,5,6)" 

$SqlCmd.CommandText = $SqlQuery 

$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter 

$SqlAdapter.SelectCommand = $SqlCmd

$SqlCmd.Connection = $connection 

$DataSet = New-Object System.Data.DataSet 

$SqlAdapter.Fill($DataSet)  

$connection.Close() 

	$svcPSProxy = New-WebServiceProxy -uri $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABQAHIAbwBqAGUAYwB0AFMAZQByAHYAZQByAFUAUgBMAC8AXwB2AHQAaQBfAGIAaQBuAC8AUABTAEkALwBQAHIAbwBqAGUAYwB0AC4AYQBzAG0AeAA/AHcAcwBkAGwA'))) -useDefaultCredential

	foreach ($row in $DataSet.Tables[0])
	{ 
		if ($row.ItemArray.Count -gt 0)
	    {
			Write-Host "Checkin Project " + $row[0]
			$projId = [System.Guid]$row[0]
			$svcPSProxy.QueueCheckInProject([System.Guid]::NewGuid() , $projId, "true",[System.Guid]::NewGuid(),"SOLVIN Easy CheckIn")
		}
	}
