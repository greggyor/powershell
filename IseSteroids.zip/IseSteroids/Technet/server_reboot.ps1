﻿
Import-Module Hyperv
${01010100000110010} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAFIAVgBFAFIATgBBAE0ARQA=')))
Shutdown-VM -vm ${01010100000110010} -server HYPERVHOST -confirm:$false
start-sleep -s 240
${01111110111010111} = get-vm ${01010100000110010} -server HYPERVHOST
if (${01111110111010111}.Enabledstate -eq "3"){
${01110110001000110} = Get-date
start-VM -VM ${01010100000110010} -server HYPERVHOST -confirm:$false
}
start-sleep -s 60
${10111111000101111} = Get-VM -VM ${01010100000110010} -server HYPERVHOST 
if (${10111111000101111}.enabledstate -eq "2") {
${00111000011100000} = @{                        
                Subject = "${01010100000110010} reboot status for $((Get-Date).ToShortDateString())"                        
                Body = " The Server ${01010100000110010} has rebooted at - ${01110110001000110}. The server is up and operational."                      
                From = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBvAC0AcgBlAHAAbAB5AEAAZQBtAGEAaQBsAC4AYwBvAG0A')))                        
                To = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgBAAGUAbQBhAGkAbAAuAGMAbwBtAA==')))                        
                SmtpServer = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAFIAVgBFAFIA'))) }
send-mailmessage @00111000011100000 -bodyashtml
}
if (${10111111000101111}.enabledstate -ne "3") {
${00110000101000111} = @{                        
                Subject = "${01010100000110010} reboot status for $((Get-Date).ToShortDateString())"                        
                Body = " The Server ${01010100000110010} has rebooted at  - ${01110110001000110}. Please check the vm ${01010100000110010} as there may be an issue. It has not fully restarted"                
                From = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBvAC0AcgBlAHAAbAB5AEAAZQBtAGEAaQBsAC4AYwBvAG0A')))                        
                To = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGUAcgBAAGUAbQBhAGkAbAAuAGMAbwBtAA==')))                        
                SmtpServer = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAFIAVgBFAFIA'))) }
send-mailmessage @00110000101000111 -bodyashtml
}
exit
