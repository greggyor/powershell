﻿
function New-FASTManagedProperty([string]$Name, [string]$CrawledPropertyName, [string]$Type,[bool]$Refinement,$Sortable)
{
	switch ($Type) 
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHgAdAA='))) {$type = "1"}  
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQBnAGUAcgA='))) {$type = "2"} 
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGMAaQBtAGEAbAA='))) {$type = "5"} 
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAZQBUAGkAbQBlAA=='))) {$type = "6"} 
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBsAG8AYQB0AA=='))) {$type = "4"} 
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBpAG4AYQByAHkA'))) {$type = "3"}  
    }
	$managedproperty = Get-FASTSearchMetadataManagedProperty –Name $Name
	if ($managedproperty -eq $null){
		New-FASTSearchMetadataManagedProperty -Name $Name -Type $Type -ea 0
		$managedproperty = Get-FASTSearchMetadataManagedProperty –Name $Name
	}
			Set-FASTSearchMetadataManagedProperty –Name $Name –Queryable $true –StemmingEnabled $false –RefinementEnabled  $Refinement -SortableType $Sortable
	$cp = Get-FASTSearchMetadataCrawledProperty -Name $CrawledPropertyName
		if ($cp -eq $null){
			switch($type){
				"1" {$variant = "31"}  
				"2" {$variant = "3"} 
				"5" {$variant = "4"} 
				"6" {$variant = "64"} 
				"4" {$variant = "5"} 
				"3" {$variant = "11"}  
			}
			New-FASTSearchMetadataCrawledProperty -Name $CrawledPropertyName -Propset $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAwADEAMwAwADMAMgA5AC0AMAAwADAAMAAtADAAMQAzADAALQBjADAAMAAwAC0AMAAwADAAMAAwADAAMQAzADEAMwA0ADYA'))) -VariantType $variant
			$cp = Get-FASTSearchMetadataCrawledProperty -Name $CrawledPropertyName
			write-host "Created $($CrawledPropertyName) Crawled Property"
		}
		New-FASTSearchMetadataCrawledPropertyMapping –Managedproperty $managedproperty –crawledproperty $cp -ea 0
	write-host "Created $($Name)"
}
New-FASTManagedProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAGUAYQA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwB3AHMAXwBBAHIAZQBhAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHgAdAA='))) $true "1" 
New-FASTManagedProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBlAGkAbgBnAFIAZQB2AGkAcwBlAGQA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwB3AHMAXwBCAGUAaQBuAGcAUgBlAHYAaQBzAGUAZAA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBpAG4AYQByAHkA'))) $false "0"
New-FASTManagedProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBlAGkAbgBnAFIAZQB2AGkAcwBlAGQATgBvAHQAZQBzAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwB3AHMAXwBDAG8AbQBtAGUAbgB0AHMA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHgAdAA='))) $false "0"
New-FASTManagedProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAYwBpAHAAbABpAG4AZQA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bwB3AHMAXwBEAGkAcwBjAGkAcABsAGkAbgBlAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABlAHgAdAA='))) $true "1"
