﻿
${5} = "OU=Scripting,OU=Groups,DC=lab,DC=lan"
${1} = "OU=Empty,OU=Groups,DC=lab,DC=lan"
${4} = Get-ADGroup -filter * -Properties members,memberof -searchbase ${5} | where {!$_.members} | where {!$_.membersof}
foreach (${3} in ${4})
{
${2} = ${3}.DistinguishedName
Move-ADObject -Identity ${2} -TargetPath ${1}
}
