﻿# ------------------------------------------------------------------------
# NAME: Get-IPObjectDefaultEnabledFormatNonIPOutput.ps1
# AUTHOR: ed wilson, Microsoft
# DATE:2/18/2009
#
# KEYWORDS: Function, default value, type constraint,
# Get-WmiObject
# COMMENTS: This demonstrates a function that obtains
# information from WMI using the Win32_NetworkAdapterConfiguration
# class. It demonstrates use of a function with a type constraint
# a default value, and a single purpose function
#
# PowerShell Best Practices
# ------------------------------------------------------------------------
Function f4([bool]${f2} = $true)
{
 gwmi -class Win32_NetworkAdapterConfiguration -Filter "IPEnabled = ${f2}"
} #end Get-IPObject

Function f3(${f1})
{ 
  Begin { $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGQAZQB4ACAAIwAgACAARABlAHMAYwByAGkAcAB0AGkAbwBuAA=='))) }
  Process {
   ForEach (${1} in ${f1})
    {
     Write-Host ${1}.Index `t ${1}.Description
    } #end ForEach
 } #end Process
} #end Format-NonIPOutput

# *** Entry Point ***

${f1} = f4 -f2 $False
f3(${f1})