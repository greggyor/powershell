﻿
[CmdletBinding()]
Param
    (
    $ComputerName = @($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzADEALgBjAG8AbQBwAGEAbgB5AC4AYwBvAG0A'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBzADIALgBjAG8AbQBwAGEAbgB5AC4AYwBvAG0A')))),
    $SharedDrives = @('G','W','U'),
    $FileName = 'C:\Users\jspatton\DPMvolumeSizing v3.3\DPMvolumeSizing.xlsx',
    $WorkSheetName = 'DPM File Volume',
    $VolumeIDColumn = 'D:D',
    $TargetColumn = 'E'
    )
Begin
    {
        $ScriptName = $MyInvocation.MyCommand.ToString()
        $LogName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuAA==')))
        $ScriptPath = $MyInvocation.MyCommand.Path
        $Username = $env:USERDOMAIN + "\" + $env:USERNAME
 
        New-EventLog -Source $ScriptName -LogName $LogName -ErrorAction SilentlyContinue
 
        $Message = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQAOgAgAA=='))) + $ScriptPath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBTAGMAcgBpAHAAdAAgAFUAcwBlAHIAOgAgAA=='))) + $Username + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBTAHQAYQByAHQAZQBkADoAIAA='))) + (Get-Date).toString()
        Write-EventLog -LogName $LogName -Source $ScriptName -EventID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADQA'))) -EntryType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwByAG0AYQB0AGkAbwBuAA=='))) -Message $Message
 
        
        Write-Verbose "Does $($FileName) exist?"
        if ((Test-Path -Path $FileName) -ne $true)
        {
            $Message = "The path specified is invalid. $($FileName)"
            Write-Verbose $Message
            Write-EventLog -LogName $LogName -Source $ScriptName -EventID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADEA'))) -EntryType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))) -Message $Message
            break
            }
        }
Process
    {
        $Drives = @()
        Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIABhACAAcwBjAHIAaQBwAHQAYgBsAG8AYwBrACAAdABoAGEAdAAgAHcAaQBsAGwAIABjAG8AbABsAGUAYwB0ACAAdABoAGUAIABOAGEAbQBlACAAYQBuAGQAIAB1AHMAZQBkACAAcwBwAGEAYwBlACAAaQBuACAARwBCACAAZgByAG8AbQAgAHQAaABlACAAcgBlAG0AbwB0AGUAIABzAGUAcgB2AGUAcgA=')))
        $ScriptBlock = {Get-PSDrive -PSProvider FileSystem |Select-Object -Property Name, @{Label=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAZAA=')));Expression={$_.Used /1gb}}}

        try
        {
            foreach ($Computer in $ComputerName)
            {
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIABhACAAbgBlAHcAIABzAGUAcwBzAGkAbwBuACAAZgBvAHIAIAAkACgAJABDAG8AbQBwAHUAdABlAHIAKQA=')))
                $ThisSession = New-PSSession -ComputerName $Computer -Credential $Credentials
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AbgBlAGMAdAAgAHQAbwAgAHQAaABlACAAcwBlAHMAcwBpAG8AbgAsACAAYQBuAGQAIABjAG8AbABsAGUAYwB0ACAAdABoAGUAIAByAGUAcwB1AGwAdABzACAAbwBmACAAdABoAGUAIABzAGMAcgBpAHAAdABiAGwAbwBjAGsA')))
                $Drives += Invoke-Command -Session $ThisSession -ScriptBlock $ScriptBlock
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAG8AcwBlACAAcwBlAHMAaQBvAG4AIAB3AGgAZQBuACAAZABvAG4AZQAuAA==')))
                Remove-PSSession -Session $ThisSession
                }
            }
        catch
        {
            $Message = $Error[0]
            Write-Verbose $Message
            Write-EventLog -LogName $LogName -Source $ScriptName -EventID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADEA'))) -EntryType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))) -Message $Message
            Remove-PSSession -Session $ThisSession
            break
            }
        try
        {
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGUAIABhAG4AIABFAHgAYwBlAGwAIABpAG4AcwB0AGEAbgBjAGUA')))
            $Excel = New-Object -ComObject Excel.Application
            Write-Verbose "Open the $($FileName) spreadsheet"
            $Excel.Workbooks.Open($FileName)
            Write-Verbose "Open the $($WorkSheetName) worksheet"
            $WorkSheet = $Excel.Worksheets.Item($WorkSheetName)
            Write-Verbose "Select column $($VolumeIDColumn), the Volume Identification column"
            $Range = $WorkSheet.Range($VolumeIDColumn)
            
            foreach ($SharedDrive in $SharedDrives)
            {
                Write-Verbose "Find $($SharedDrive) in $($VolumeIDColumn)"
                $Target = $Range.Find($SharedDrive)
                Write-Verbose "Found $($SharedDrive) at $($Target.AddressLocal($true,$true,$true))"
                Write-Verbose "Get the used space for $($SharedDrive)"
                $Used = $Drives |Where-Object {$_.Name -eq $SharedDrive} |Select-Object -Property Used
                Write-Verbose "$($SharedDrive) : $($Used.Used)GB Used"
                $TargetReference = "$($TargetColumn)$($Target.Row)"
                Write-Verbose "Updating $($TargetReference) with value $($Used.Used)"
                $WorkSheet.Range($TargetReference).Value2 = $Used.Used
                Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBwAGQAYQB0AGUAZAA=')))
                }
            Write-Verbose "Saving $($FileName)"
            $Excel.Save()
            Write-Verbose "Closing $($WorkSheetName)"
            $Excel.Workbooks.Close()
            Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGkAdAAgAEUAeABjAGUAbAA=')))
            $Excel.Application.Quit()
            }
        catch
        {
            $Message = $Error[0]
            Write-Verbose $Message
            Write-EventLog -LogName $LogName -Source $ScriptName -EventID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADEA'))) -EntryType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByAA=='))) -Message $Message
            break
            }
        }
End
    {
        $Message = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAHIAaQBwAHQAOgAgAA=='))) + $ScriptPath + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBTAGMAcgBpAHAAdAAgAFUAcwBlAHIAOgAgAA=='))) + $Username + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBGAGkAbgBpAHMAaABlAGQAOgAgAA=='))) + (Get-Date).toString()
        Write-EventLog -LogName $LogName -Source $ScriptName -EventID $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADQA'))) -EntryType $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGYAbwByAG0AYQB0AGkAbwBuAA=='))) -Message $Message	
        }
