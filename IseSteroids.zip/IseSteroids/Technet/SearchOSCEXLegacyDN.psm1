﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages

$webSvcInstallDirRegKey = gp -Path "HKLM:\SOFTWARE\Microsoft\Exchange\Web Services\2.0" -PSProperty "Install Directory" -ErrorAction:SilentlyContinue
if ($webSvcInstallDirRegKey -ne $null) {
	$moduleFilePath = $webSvcInstallDirRegKey.'Install Directory' + 'Microsoft.Exchange.WebServices.dll'
	ipmo $moduleFilePath
} else {
	$errorMsg = $Messages.InstallexServiceModule
	throw $errorMsg
}

Function ___/\/\/\/=\____/\
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Connect-OSCEXWebService
{
	#.EXTERNALHELP Connect-OSCEXWebService-Help.xml

    [cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
		[System.Management.Automation.PSCredential]$Credential,
		[Parameter(Mandatory=$false,Position=2)]
		[Microsoft.Exchange.WebServices.Data.ExchangeVersion]$ExchangeVersion="Exchange2010_SP2",
		[Parameter(Mandatory=$false,Position=3)]
		[string]$TimeZoneStandardName,
		[Parameter(Mandatory=$false)]
		[switch]$Force
	)
	Process
	{
        #Get specific time zone info
        if (-not [System.String]::IsNullOrEmpty($TimeZoneStandardName)) {
            Try
            {
                $tzInfo = [System.TimeZoneInfo]::FindSystemTimeZoneById($TimeZoneStandardName)
            }
            Catch
            {
                $PSCmdlet.ThrowTerminatingError($_)
            }
        } else {
            $tzInfo = $null
        }

        #Try to get email address of current user
		Try
		{
			$directoryEntry = New-Object System.DirectoryServices.DirectoryEntry
			$currentDomain = New-Object System.DirectoryServices.DirectoryEntry("LDAP://" + $directoryEntry.distinguishedName)
			$currentUserName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name.Split("\")[1]
			$driectorySearcher = New-Object System.DirectoryServices.DirectorySearcher(`
									$currentDomain,"sAMAccountName=$currentUserName")
			$driectorySearcher.PropertiesToLoad.Add("mail") | Out-Null
			$currentUserMailAddress = $driectorySearcher.FindOne().GetDirectoryEntry().Properties["mail"].ToString()
			if (-not [System.String]::IsNullOrEmpty($currentUserMailAddress)) {
				$userName = $currentUserMailAddress
			} else {
				$errorMsg = $Messages.RequiresUserMailAddress
				$errorMsg = $errorMsg -f $currentUserName
				$customError = ___/\/\/\/=\____/\ `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
				$PSCmdlet.ThrowTerminatingError($customError)					
			}			
		}
		Catch
		{
			$PSCmdlet.ThrowTerminatingError($_)
		}
	
		#Try to get exchange service object from global scope
		$existingExSvcVar = (gv -Name exService -Scope Global -ErrorAction:SilentlyContinue) -ne $null
		
		#Establish the connection to Exchange Web Service
		if ((-not $existingExSvcVar) -or $Force) {
			$verboseMsg = $Messages.EstablishConnection
			$PSCmdlet.WriteVerbose($verboseMsg)
            if ($tzInfo -ne $null) {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion,$tzInfo)			
            } else {
                $exService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService(`
				    		 [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$ExchangeVersion)
            }
			
			#Set network credential
			if ($Credential -ne $null) {
				$userName = $Credential.UserName
				$exService.Credentials = $Credential.GetNetworkCredential()
			} else {
				$exService.UseDefaultCredentials = $true
			}
			Try
			{
				#Set the URL by using Autodiscover
				$exService.AutodiscoverUrl($userName,$validateRedirectionUrlCallback)
				$verboseMsg = $Messages.SaveExWebSvcVariable
				$PSCmdlet.WriteVerbose($verboseMsg)
				sv -Name exService -Value $exService -Scope Global -Force
			}
			Catch [Microsoft.Exchange.WebServices.Autodiscover.AutodiscoverRemoteException]
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
			Catch
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
		} else {
			$verboseMsg = $Messages.FindExWebSvcVariable
            if ($Credential -ne $null) {
                $verboseMsg = $verboseMsg -f $exService.Credentials.Credentials.UserName
            } else {
                $verboseMsg = $verboseMsg -f $userName
            }
			$PSCmdlet.WriteVerbose($verboseMsg)            
		}
	}
}

Function Get-OSCEXLegacyDN
{
	#.EXTERNALHELP Get-OSCEXLegacyDN-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1,ValueFromPipeline=$true)]
		[Microsoft.Exchange.WebServices.Data.SearchFolder]$SearchFolder,
		[Parameter(Mandatory=$false,Position=2)]
		[int]$PageSize=100,
		[Parameter(Mandatory=$false)]
		[switch]$KeepSearchFolder
	)
    Begin
    {
        #Verify the existence of exchange service object
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = ___/\/\/\/=\____/\ `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
	
        #Define a hashtable for storing legacyExcnahgeDNs
        $legacyDNs = @{}

        #Define propertyset for limiting the data that will be returned from the server
        $msgPropertySet = New-Object Microsoft.Exchange.WebServices.Data.PropertySet(`
									[Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::From,`
									[Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::Subject,`
									[Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::ToRecipients,`
									[Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::CcRecipients)     
    }
    Process
    {
        #Define the view settings in a folder search operation.
        $itemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView($PageSize)
        
        #Create a progress bar for displaying the search progress
        $progressRecord = New-Object System.Management.Automation.ProgressRecord(1,"{0}","{0}")

        #Begin to find items from the search folder
        do
        {
            $findResults = $SearchFolder.FindItems($itemView)
            $prActivity = $Messages.ProgressRecordActivity -f $findResults.TotalCount
            $progressRecord.Activity = $prActivity

            foreach ($findResult in $findResults) {
                $counter++

                #Bind each email with a small set of ProperrtSet
                $emailMsg = [Microsoft.Exchange.WebServices.Data.EmailMessage]::Bind(`
                            $exService,$findResult.Id,$msgPropertySet)
                
                #Display detail information
                $statDesc = $Messages.ProgressRecordStatusDescription -f $emailMsg.Subject,$legacyDNs.Count
                $progressRecord.StatusDescription = $statDesc
                $progressRecord.PercentComplete = $counter / $findResults.TotalCount * 100
                $PSCmdlet.WriteProgress($progressRecord)

                #Verify the RoutingType of the email addresses
                if ($emailMsg.From.RoutingType -eq "EX") {
                    if (-not $legacyDNs.ContainsKey($emailMsg.From.Address)) {
                        $legacyDNs.Add($emailMsg.From.Address,$emailMsg.From.Name)
                    }
                }
                foreach ($toRecipient in $emailMsg.ToRecipients) {
                    if ($toRecipient.RoutingType -eq "EX") {
                        if (-not $legacyDNs.ContainsKey($toRecipient.Address)) {
                            $legacyDNs.Add($toRecipient.Address,$toRecipient.Name)
                        }
                    }
                }
                foreach ($ccRecipient in $emailMsg.CcRecipients) {
                    if ($ccRecipient.RoutingType -eq "EX") {
                        if (-not $legacyDNs.Contains($ccRecipient.Address)) {
                            $legacyDNs.Add($ccRecipient.Address,$ccRecipient.Name)
                        }
                    }                        
                }
            }
			$itemView.Offset += $PageSize
        } while ($findResults.MoreAvailable)

        #Remove the search folder if you don't want to keep it
        if (-not $KeepSearchFolder) {
			Try
			{
				$SearchFolder.Delete([Microsoft.Exchange.WebServices.Data.DeleteMode]::MoveToDeletedItems)
			}
			Catch
			{
				$PSCmdlet.ThrowTerminatingError($_)
			}
        }
    }
    End
    {
        #Iterate each legacyExchangeDN for generating user friendly outputs
        foreach ($legacyDN in $legacyDNs.Keys.GetEnumerator()) {
            $legacyDNObject = New-Object System.Management.Automation.PSObject
            $legacyDNObject | Add-Member -MemberType NoteProperty -Name Name -Value $legacyDNs[$legacyDN]
            $legacyDNObject | Add-Member -MemberType NoteProperty -Name LegacyDN -Value $legacyDN
            $PSCmdlet.WriteObject($legacyDNObject)
        }
    }
}

Function New-OSCEXSearchFolder
{
	#.EXTERNALHELP New-OSCEXSearchFolder-Help.xml

	[cmdletbinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$false,Position=1)]
        [ValidateSet("Inbox","SentItems","DeletedItems")]
		[string]$WellKnownFolderName="Inbox",		
		[Parameter(Mandatory=$false,Position=2)]
		[datetime]$StartDate=(Get-Date).AddDays(-30),
		[Parameter(Mandatory=$false,Position=3)]
		[datetime]$EndDate=(Get-Date),
		[Parameter(Mandatory=$false,Position=4)]
		[string]$Subject,
		[Parameter(Mandatory=$false,Position=5)]
		[string]$From,
		[Parameter(Mandatory=$false,Position=6)]
		[string]$DisplayTo,
		[Parameter(Mandatory=$false,Position=7)]
		[string]$DisplayCc,
		[Parameter(Mandatory=$false,Position=8)]
		[int]$PageSize=100,
		[Parameter(Mandatory=$false,Position=9)]
		[Microsoft.Exchange.WebServices.Data.SearchFolderTraversal]$Traversal="Shallow",
		[Parameter(Mandatory=$false,Position=10)]
		[string]$DisplayName=(Get-Date)
	)
	Begin
	{
        #Verify the existence of exchange service object
        if ($exService -eq $null) {
			$errorMsg = $Messages.RequireConnection
			$customError = ___/\/\/\/=\____/\ `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $PSCmdlet
			$PSCmdlet.ThrowTerminatingError($customError)
        }
	}
	Process
	{   
        #Define base property sets that are used as the base for custom property sets.
        $folderPropertySet = New-Object Microsoft.Exchange.WebServices.Data.PropertySet(`
                       		 [Microsoft.Exchange.WebServices.Data.BasePropertySet]::IdOnly,`
                       		 [Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName,`
					   		 [Microsoft.Exchange.WebServices.Data.FolderSchema]::ChildFolderCount)
							 
        $itemPropertySet = New-Object Microsoft.Exchange.WebServices.Data.PropertySet(`
                       	   [Microsoft.Exchange.WebServices.Data.BasePropertySet]::IdOnly,`
						   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::ItemClass,`
                       	   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::Subject,`
					   	   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DateTimeReceived,`
                           [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::From,`
					   	   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DisplayTo,`
						   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DisplayCc)
						   
		#Define FolderView and ItemView
		$folderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView($PageSize)
		$folderView.PropertySet = $folderPropertySet
		$itemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView($PageSize)
		$itemView.PropertySet = $itemPropertySet
               
        #Prepare search filter for searching emails
        $searchFilterCollection = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+SearchFilterCollection(`
                                  [Microsoft.Exchange.WebServices.Data.LogicalOperator]::And)
		$startDateFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsGreaterThanOrEqualTo(`
						   [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DateTimeCreated,$StartDate)
		$endDateFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsLessThanOrEqualTo(`
						 [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DateTimeCreated,$endDate)
		$itemClassFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo(`
						  [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::ItemClass,"IPM.Note")						 
		$searchFilterCollection.Add($startDateFilter)
		$searchFilterCollection.Add($endDateFilter)
		$searchFilterCollection.Add($itemClassFilter)
		
        if (-not [System.String]::IsNullOrEmpty($Subject)) {
            $subjectFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+ContainsSubString(`
                             [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::Subject,$Subject)  
            $searchFilterCollection.Add($subjectFilter)
        }

        if (-not [System.String]::IsNullOrEmpty($From)) {
            $fromFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+ContainsSubString(`
                             [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::From,$From)  
            $searchFilterCollection.Add($fromFilter)
        }

        if (-not [System.String]::IsNullOrEmpty($DisplayTo)) {
            $displayToFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+ContainsSubString(`
                             [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DisplayTo,$DisplayTo)  
            $searchFilterCollection.Add($displayToFilter)
        }

        if (-not [System.String]::IsNullOrEmpty($DisplayCc)) {
            $displayCcFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+ContainsSubString(`
                             [Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::DisplayCc,$DisplayCc)  
            $searchFilterCollection.Add($displayCcFilter)
        }

        $folderID = New-Object Microsoft.Exchange.WebServices.Data.FolderId(`
                    [Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::$WellKnownFolderName)
		
        Try
        {
            #Create a new search folder
            $searchFolder = New-Object Microsoft.Exchange.WebServices.Data.SearchFolder($exService)
            $searchFolder.SearchParameters.RootFolderIds.Add($folderID) | Out-Null
            $searchFolder.SearchParameters.Traversal = [Microsoft.Exchange.WebServices.Data.SearchFolderTraversal]::$Traversal
            $searchFolder.SearchParameters.SearchFilter = $searchFilterCollection
            $searchFolder.DisplayName = $DisplayName
            $searchFolder.Save([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::SearchFolders)

            #Return the newly created search folder
            return $searchFolder
        }
        Catch
        {
            $PSCmdlet.WriteError($_)
            return $null
        }
	}
	End {}
}


Export-ModuleMember -Function "Connect-OSCEXWebService","Get-OSCEXLegacyDN","New-OSCEXSearchFolder"