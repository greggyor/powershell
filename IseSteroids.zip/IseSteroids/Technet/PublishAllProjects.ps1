﻿${3} = New-WebServiceProxy -uri $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB2AG0AMwA1ADMALwBwAHcAYQB0AGUAcwB0AC8AXwB2AHQAaQBfAGIAaQBuAC8AUABTAEkALwBQAHIAbwBqAGUAYwB0AC4AYQBzAG0AeAA/AHcAcwBkAGwA'))) -useDefaultCredential 
${5} = [system.guid]::empty
${4} = ${3}.ReadProjectStatus($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADUAfQA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHIAawBpAG4AZwBTAHQAbwByAGUA'))),"", "0").Project | format-table proj_uid -hidetableheaders | out-string -stream
foreach (${1} in ${4}) 
{
	if (${1} -ne "")
	{ 
${2} = [System.Guid]::NewGuid() 
${3}.QueuePublish($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADIAfQA='))), ${1}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAByAHUAZQA='))),"")}}