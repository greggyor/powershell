﻿<#
.SYNOPSIS
Gets the installed applications on a local or remote computer.

.DESCRIPTION
Returns information about all installed applications for a computer, not just those installed by Windows Installer.

Without parameters, the script gets the installed applications on the local computer and includes errors at the end of the output.

.PARAMETER ComputerName
Gets the installed applications for the specified computers. The default is the local computer.

Type the NetBIOS name, an IP address, or a fully qualified domain name of a computer or you can pass an array of strings to the script that represent computer names.

.PARAMETER HideErrors
Removes errors from the output. Any errors thrown are ignored and are not passed as output. If this switch is set, the user should re-run the script and set the ShowErrors switch to ensure valid results.

.PARAMETER ShowErrors
Shows only errors (if any were encountered) as output. Output is returned as a hashtable. No valid results are shown if this switch is set, only errors.

.INPUTS
Values for ComputerName may be passed into the script through the pipeline.

.EXAMPLE
PS C:\> .\getInstalledSoftware.ps1

Gets the installed applications on the localhost.

.EXAMPLE
PS C:\> .\getInstalledSoftware.ps1 -ComputerName SVR001, SVR002, SVR003

Gets the installed applications on SVR001, SVR002, SVR003 and displays any errors encountered.

.EXAMPLE
PS C:\> $names = Get-Content C:\ListOfNames.txt
PS C:\> $names | .\getInstalledSoftware.ps1 -ShowErrors
PS C:\> $names | .\getInstalledSoftware.ps1 -HideErrors

Attempts to get installed applications from all computers in ListOfNames.txt but only dispays errors that were encountered. This is useful for verifying results from the next command, especially when ListOfNames contains a large number of computers. 

The next command gets the installed applications on the computers in C:\ListOfNames.txt but does not include any error information.
#>
#*=============================================================================
#* Name:	getInstalledSoftware
#* Created: 12/9/2011
#* Author: 	James Keeler
#* Email: 	James.R.Keeler(at)gmail.com
#*
#* Params:	[String[]] $ComputerName - name(s) of the remote computer(s)
#*			[Switch] $HideErrors - do not show errors in output
#*			[Switch] $ShowErrors - show only errors in output
#* Returns:	All installed software for the computer(s)
#*-----------------------------------------------------------------------------
#* Purpose:	Quickly returns information about all installed software on
#* computers regardless of whether it was installed by Windows Installer.
#*
#*=============================================================================
#*=============================================================================
#* REVISION HISTORY
#*-----------------------------------------------------------------------------
#* Version:		1.1
#* Date: 		12/12/2011
#* Time: 		4:28 PM
#* Issue: 		Install date not properly formatted
#* Solution:	Use substring to re-format the string
#*
#*-----------------------------------------------------------------------------
#* Version:		1.2
#* Date: 		12/19/2011
#* Time: 		10:55 AM
#* Issue: 		No data returned for 64-bit apps
#* Solution:	Check for 64-bit OS, then enumerate the Wow6432Node key
#*
#*-----------------------------------------------------------------------------
#* Version:		1.3
#* Date: 		12/28/2011
#* Time: 		10:47 AM
#* Issue: 		No options for error output
#* Solution:	Added switch parameters to either show or hide errors
#*
#*=============================================================================
#*=============================================================================
#* SCRIPT BODY
#*=============================================================================
param 
( 
    [Parameter(ValueFromPipeline=$true)] 
    [String[]] $ComputerName = @($env:COMPUTERNAME),
	[switch] $HideErrors,
	[switch] $ShowErrors
) 
begin 
{ 
    # Create an array to hold our job objects 
    $jobs = @() 
	# Ensure that both switches weren't set
	if ($ShowErrors -and $HideErrors) {throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAHMAdwBpAHQAYwBoACAAcABhAHIAYQBtAGUAdABlAHIAIABjAG8AbQBiAGkAbgBhAHQAaQBvAG4A')))}
} 
process 
{ 
    foreach ($name in $ComputerName) 
    { 
        # We use Invoke-Command to remotely call the scriptblock below and  
        # create a job for each computer so that the work runs concurrently. 
        $jobs += Invoke-Command -ComputerName $name -ScriptBlock `
        { 
#*=============================================================================
#* BEGIN REMOTE SCRIPTBLOCK
#*=============================================================================
# Any error at this point should be terminating
$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AG8AcAA=')))
# Create a custom object to hold our application information 
Add-Type $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAB1AGIAbABpAGMAIABjAGwAYQBzAHMAIABJAG4AcwB0AGEAbABsAGUAZABBAHAAcABsAGkAYwBhAHQAaQBvAG4AIAB7ACAADQAKACAAIAAgACAAcAB1AGIAbABpAGMAIABzAHQAcgBpAG4AZwAgACAAIAAgACAARABpAHMAcABsAGEAeQBOAGEAbQBlADsAIAANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAAIAAgACAAIABJAG4AcwB0AGEAbABsAEQAYQB0AGUAOwAgAA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIAAgACAAIAAgAFAAdQBiAGwAaQBzAGgAZQByADsAIAANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAAIAAgACAAIABEAGkAcwBwAGwAYQB5AFYAZQByAHMAaQBvAG4AOwAgAA0ACgAgACAAIAAgAHAAdQBiAGwAaQBjACAAaQBuAHQAIAAgACAAIAAgACAAIAAgAFYAZQByAHMAaQBvAG4ATQBhAGoAbwByADsAIAANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAIAAgACAAIAAgACAAIAAgAFYAZQByAHMAaQBvAG4ATQBpAG4AbwByADsAIAANAAoAIAAgACAAIABwAHUAYgBsAGkAYwAgAGQAbwB1AGIAbABlACAAIAAgACAAIABFAHMAdABpAG0AYQB0AGUAZABTAGkAegBlAE0AQgA7ACAADQAKACAAIAAgACAAcAB1AGIAbABpAGMAIABzAHQAcgBpAG4AZwAgACAAIAAgACAATQBvAGQAaQBmAHkAUABhAHQAaAA7ACAADQAKACAAIAAgACAAcAB1AGIAbABpAGMAIABzAHQAcgBpAG4AZwAgACAAIAAgACAAVQBuAGkAbgBzAHQAYQBsAGwAUwB0AHIAaQBuAGcAOwAgAA0ACgB9ACAA'))) # This is required to be at the beginning of the line 
# This is the real magic of the script.  We use Get-ChildItem to  
# get all of the subkeys that contain application info. 
$keys = Get-ChildItem `
	HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall -Recurse 
# Get registry info from the Wow6432Node if the computer is 64-bit
if ((Get-WmiObject Win32_ComputerSystem).SystemType -like $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('eAA2ADQAKgA='))))
{
	$keys += Get-ChildItem `
		HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall -Recurse
}
$app = New-Object InstalledApplication 
# Build out each InstalledApplication object 
foreach ($key in $keys) 
{ 
	# If we've made it to this point we can safely ignore errors
	$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQA=')))
    # We need to convert the date from yyyymmdd to mm/dd/yyyy 
    if ($tempDate = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABEAGEAdABlAA=='))))) 
    { 
        $tempDate = $tempDate.SubString(4,2) + "/" + `
					$tempDate.SubString(6,2) + "/" + `
                    $tempDate.SubString(0,4) 
    } 
    $app.DisplayName = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAcABsAGEAeQBOAGEAbQBlAA==')))) 
    $app.InstallDate = $tempDate 
    $app.Publisher = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAB1AGIAbABpAHMAaABlAHIA')))) 
    $app.DisplayVersion = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAcABsAGEAeQBWAGUAcgBzAGkAbwBuAA==')))) 
    $app.VersionMajor = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBlAHIAcwBpAG8AbgBNAGEAagBvAHIA')))) 
    $app.VersionMinor = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBlAHIAcwBpAG8AbgBNAGkAbgBvAHIA')))) 
    $app.EstimatedSizeMB = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoATgAyAH0A'))) -f ($key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBzAHQAaQBtAGEAdABlAGQAUwBpAHoAZQA=')))) / 1MB) 
    $app.ModifyPath = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAGQAaQBmAHkAUABhAHQAaAA=')))) 
    $app.UninstallString = $key.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGkAbgBzAHQAYQBsAGwAUwB0AHIAaQBuAGcA')))) 
	# Only send back data for apps with a name
    if ($app.DisplayName) {Write-Output $app}
	$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdABpAG4AdQBlAA==')))
} # end foreach key 
#*=============================================================================
#* END REMOTE SCRIPTBLOCK
#*=============================================================================
        } -AsJob
    } # end foreach name 
} 
# Wait for all jobs to complete, receive output, then remove the jobs
end 
{ 
	$originalColor = $Host.UI.RawUI.ForegroundColor 
	$errorList = @{}
    $jobs | Wait-Job | Out-Null
	# Completed successfully
	$completed = $jobs | where {$_.State -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAGQA')))} | Receive-Job
	# Did not complete
	$jobs | where {$_.State -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAGQA')))} | `
		foreach {$errorList[$_.Location] = Receive-Job -Job $_ 2>&1}
	# Display the appropriate output based on the switch parameters
	if ($HideErrors)
	{
		Write-Output $completed
	}
	elseif ($ShowErrors)
	{
		# Since these are errors, they need to be displayed in red text
		$Host.ui.rawui.ForegroundColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGQA'))) 
	    Write-Output $errorList
		$Host.ui.rawui.ForegroundColor = $originalColor 
	}
	else
	{
		Write-Output $completed
		$Host.ui.rawui.ForegroundColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGQA'))) 
	    Write-Output $errorList
		$Host.ui.rawui.ForegroundColor = $originalColor 
	}
    $jobs | Remove-Job 
}
#*=============================================================================
#* END OF SCRIPT: getInstalledSoftware
#*=============================================================================
