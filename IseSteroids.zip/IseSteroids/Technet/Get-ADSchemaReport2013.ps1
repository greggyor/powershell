﻿
ipmo ActiveDirectory 
${11} = Get-ADObject -SearchBase ((Get-ADRootDSE).schemaNamingContext) `
    -SearchScope OneLevel -Filter * -Property objectClass, name, whenChanged,`
    whenCreated | select objectClass, name, whenCreated, whenChanged, `
    @{name="event";expression={($_.whenCreated).Date.ToShortDateString()}} | `
    sort whenCreated
"`nDetails of schema objects created by date:"
${11} | ft objectClass, name, whenCreated, whenChanged `
    -GroupBy event -AutoSize
"`nCount of schema objects created by date:"
${11} | group event | ft Count, Name, Group -AutoSize
"`nForest domain creation dates:"
Get-ADObject -SearchBase (Get-ADForest).PartitionsContainer `
    -LDAPFilter "(&(objectClass=crossRef)(systemFlags=3))" `
    -Property dnsRoot, nETBIOSName, whenCreated |
  sort whenCreated |
  ft dnsRoot, nETBIOSName, whenCreated -AutoSize
${1} = @()
${10} = @{
    13="Windows 2000 Server";
    30="Windows Server 2003 RTM";
    31="Windows Server 2003 R2";
    44="Windows Server 2008 RTM";
    47="Windows Server 2008 R2";
    56="Windows Server 2012 RTM"
    }
${5} = (Get-ADRootDSE).NamingContexts | ? {$_ -like "*Schema*"}
${9} = (Get-ADObject ${5} -Property objectVersion).objectVersion
${1} += 1 | select `
    @{name="Product";expression={"AD"}}, `
    @{name="Schema";expression={${9}}}, `
    @{name="Version";expression={${10}.Item(${9})}}
${7} = @{
    4397="Exchange Server 2000 RTM";
    4406="Exchange Server 2000 SP3";
    6870="Exchange Server 2003 RTM";
    6936="Exchange Server 2003 SP3";
    10628="Exchange Server 2007 RTM";
    10637="Exchange Server 2007 RTM";
    11116="Exchange 2007 SP1";
    14622="Exchange 2007 SP2 or Exchange 2010 RTM";
    14625="Exchange 2007 SP3";
    14726="Exchange 2010 SP1";
    14732="Exchange 2010 SP2";
    14734="Exchange 2010 SP3";
    15137="Exchange 2013 RTM"
    }
${8} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBOAD0AbQBzAC0ARQB4AGMAaAAtAFMAYwBoAGUAbQBhAC0AVgBlAHIAcwBpAG8AbgAtAFAAdAAsACQAewA1AH0A')))
If (Test-Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBEADoAJAB7ADgAfQA=')))) {
    ${6} = (Get-ADObject ${8} -Property rangeUpper).rangeUpper
} Else {
    ${6} = 0
}
${1} += 1 | select `
    @{name="Product";expression={"Exchange"}}, `
    @{name="Schema";expression={${6}}}, `
    @{name="Version";expression={${7}.Item(${6})}}
${3} = @{
    1006="LCS 2005";
    1007="OCS 2007 R1";
    1008="OCS 2007 R2";
    1100="Lync Server 2010";
    1150="Lync Server 2013"
    }
${4} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBOAD0AbQBzAC0AUgBUAEMALQBTAEkAUAAtAFMAYwBoAGUAbQBhAFYAZQByAHMAaQBvAG4ALAAkAHsANQB9AA==')))
If (Test-Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBEADoAJAB7ADQAfQA=')))) {
    ${2} = (Get-ADObject ${4} -Property rangeUpper).rangeUpper
} Else {
    ${2} = 0
}
${1} += 1 | select `
    @{name="Product";expression={"Lync"}}, `
    @{name="Schema";expression={${2}}}, `
    @{name="Version";expression={${3}.Item(${2})}}
"`nKnown current schema version of products:"
${1} | ft * -AutoSize
