﻿write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAZQA6ACAAUAByAG8AYwBlAHMAcwBvAHIAIABzAGUAdAB0AGkAbgBnAHMAIABjAG8AdQBsAGQAIABvAG4AbAB5ACAAYgBlACAAYwBoAGEAbgBnAGUAZAAgAHcAaABpAGwAZQAgAHQAaABlACAAVgBNACAAaQBzACAAcwBoAHUAdABkAG8AdwBuAA=='))) -foregroundcolor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAGUAZQBuAA==')))

${4} = get-vmhost # delete this line if you only will do it on your local server
foreach (${1} in ${4}) { # delete this line if you only will do it on your local server
${3} = get-vm
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB1AHIAcgBlAG4AdAAgAHMAZQB0AHQAaQBuAGcAcwAsACAAYgBlAGYAbwByAGUAIABjAGgAYQBuAGcAaQBuAGcA')))
get-vm -ComputerName (${1}).name | Get-VMProcessor | ft vmname, CompatibilityForOlderOperatingSystemsEnabled
foreach (${2} in ${3}){
   if ((${2}).state -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgB1AG4AbgBpAG4AZwA=')))) 
    {write-host (${2}).name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aQBzACAAcgB1AG4AbgBpAG4AZwAsACAAcABsAGUAYQBzAGUAIABzAGgAdQB0ACAAZABvAHcAbgAhAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGQA')))}
else {get-vm -ComputerName (${1}).name | Set-VMProcessor -CompatibilityForOlderOperatingSystemsEnabled $true}
}
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0A')))
$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAdABpAG4AZwBzACAAYQBmAHQAZQByACAAYwBoAGEAbgBnAGkAbgBnAA==')))
get-vm | Get-VMProcessor | ft vmname, CompatibilityForOlderOperatingSystemsEnabled
} # delete this line if you only will do it on your local server