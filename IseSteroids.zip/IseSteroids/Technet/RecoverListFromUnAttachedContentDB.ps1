﻿param(
    [string] $UnAttachedContentDbName,
    [string] $DbServer,
    [string] $SiteUrl,
    [string] $ListName,
    [boolean] $IncludeSecurity
)
[System.Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAGgAYQByAGUAUABvAGkAbgB0AA==')))) 

Add-PSSnapin Microsoft.SharePoint.PowerShell -ea SilentlyContinue
Start-SPAssignment -Global

Write-Host -ForeGroundColor White $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAHUAbgBhAHQAdABhAGMAaABlAGQAIABjAG8AbgB0AGUAbgB0ACAAZABhAHQAYQBiAGEAcwBlAA==')))
${6} = Get-SPContentDatabase -ConnectAsUnattachedDatabase -DatabaseName $UnAttachedContentDbName -DatabaseServer $DbServer

Write-Host -ForeGroundColor White $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAEMAZQBuAHQAcgBhAGwAIABBAGQAbQBpAG4AaQBzAHQAcgBhAHQAaQBvAG4AIABTAGkAdABlACAAVQByAGwA')))
${7} = Get-spwebapplication -includecentraladministration | where {$_.IsAdministrationWebApplication}
${5} = ${7}.Url

Write-Host -ForeGroundColor White $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHQAdABpAG4AZwAgAG8AYgBqAGUAYwB0ACAAdABvACAAZQB4AHAAbwByAHQA')))
${4} = New-Object Microsoft.SharePoint.Deployment.SPExportObject
${4}.Type = [Microsoft.SharePoint.Deployment.SPDeploymentObjectType]::List 
${4}.Url =  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LwBMAGkAcwB0AHMALwA='))) + $ListName 
${4}.IncludeDescendants = [Microsoft.SharePoint.Deployment.SPIncludeDescendants]::All

Write-Host -ForeGroundColor White $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGkAbgBnACAARQB4AHAAbwByAHQAIABTAGUAdAB0AGkAbgBnAHMA')))
${3} = New-Object Microsoft.SharePoint.Deployment.SPExportSettings
${3}.UnattachedContentDatabase = ${6}
${3}.SiteUrl = ${5}
${3}.FileLocation = $env:TEMP
${3}.LogFilePath = $env:TEMP
${3}.BaseFileName = "$ListName.cmp"
${3}.ExportObjects.Add(${4})
${3}.IncludeVersions = [Microsoft.SharePoint.Deployment.SPIncludeVersions]::All
${3}.ExportMethod = [Microsoft.SharePoint.Deployment.SPExportMethodType]::ExportAll
${3}.OverwriteExistingDataFile = $True

If($IncludeSecurity)
{
    ${3}.IncludeSecurity = [Microsoft.SharePoint.Deployment.SPIncludeSecurity]::All
}

${2} = New-Object Microsoft.SharePoint.Deployment.SPExport(${3})
Write-Host -ForeGroundColor White "Exporting List $ListName from unattached content database $UnAttachedContentDbName"
${2}.Run()
Write-Host -ForeGroundColor White $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHAAbwByAHQAIABvAHAAZQByAGEAdABpAG8AbgAgAGMAbwBtAHAAbABlAHQAZQBkACAAcwB1AGMAYwBlAHMAcwBmAHUAbABsAHkA')))

Write-Host -ForeGroundColor White "Importing List $ListName exported from unattached content database into $SiteUrl"
${1} = Join-Path $env:TEMP "$ListName.cmp"
Import-SPWeb $SiteUrl -Path ${1} -Force -Confirm -IncludeUserSecurity:$IncludeSecurity 

Stop-SPAssignment -Global
