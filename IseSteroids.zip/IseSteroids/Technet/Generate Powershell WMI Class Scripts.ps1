﻿
${4} = gwmi -list win32_*
foreach (${2} in ${4})
{
${3} = ${2}.name
write-host "`$ComputerName = `".`"`r`n"
write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABjAG8AbABJAHQAZQBtAHMAIAA9ACAARwBlAHQALQBXAE0ASQBPAGIAagBlAGMAdAAgAC0AYwBsAGEAcwBzACAAIgAkAHsAMwB9ACIAIAAtAG4AYQBtAGUAcwBwAGEAYwBlACAAIgByAG8AbwB0AFwAQwBJAE0AVgAyACIAIAAtAGMAbwBtAHAAdQB0AGUAcgBuAGEAbQBlACAAJABDAG8AbQBwAHUAdABlAHIAbgBhAG0AZQAgAA0ACgA=')))
write-host "ForEach(`$objItem in `$colItems){"
foreach (${1} in ${2}.properties){"`tWrite-Host `"$(${1}.Name): `" `$objitem.$(${1}.name)"}
write-host "`tWrite-Host"
write-host "}"
write-host "-----------------------------------------------------------------------"
} 