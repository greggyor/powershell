﻿<#
  .SYNOPSIS
    Striped Backup of Sql Server Databases
  .DESCRIPTION
    Database getting larger and larger, that's their nature. In the same way backups of the database getting
    larger, needing more and more time to finish; this can cause serious problems in productive enviroment.
    Also, where to backup extrem large database to? A split over several drives would be nice.
    SQL Server provides a build-in function to strip SQL Server database backups over several files and they
    can be spread over several drives/folder to increase the through-put. This can (significant) increase
    your backup performance as well as the one for restoring.
    Unfortunately you can't create a maintenance plan to backup this way, but ...
    This PowerShell script performs a striped backup for all databases from given list spread over all
    predefined folders.
    Additional it creates restore T-SQL scripts for easily restoring in a case of failure.
    You could run this script with a SQL Server-Agent job to maintaine yor backups frequently.
  .CONFIGURATION
    $servername:
      The name of the SQL Server instance where the database are hosted.
    $folders:
      A list of folders to write the backups to.
      Tip: You can add one folder several times; the multiple files are created in that folder, even this
      can increase the performance.
    $scripts:
      A folder name, where the RESTORE script will be saved; with this script you can easily & quickly restore
      the database with the striped backup files.
    $databases:
      A list of database name, which should be backuped. If you leave it empty = @(), then the script backups
      all databases of the SQL Server.
    $compression:
      If set to $true, the backup file will be compressed. Please note: backup compressions are only supported
      in SQL Server 2008 Enterprise Edition or SQL Server 2008R2 Standard and higher editions. If your used
      SQL Server don't support compression, the script will fail.
    $withInfoMsg:
      If set to $true, informations of the backup progress are printed to the host.
  .REMARKS
     The script do only less error handling and validations.
  .NOTE
    Author:  Olaf Helper
    Release: 2011-12-07
    Version: 1
  .REQUIREMENTS
    PowerShell 1.0
    Permissions on the SQL Server to backup databases; at least db_backupoperator role for the db's.
    Works with SQL Server 2005 and higher in all editions.
  .LINKS
    BACKUP (Transact-SQL)
      http://msdn.microsoft.com/en-us/library/ms186865.aspx
    Optimizing Backup and Restore Performance in SQL Server:
      http://msdn.microsoft.com/en-us/library/ms190954.aspx  
#>
# Configuration settings.
[string]   ${19}  = ".\sqlexpress";
[string[]] ${14}     = @("C:\temp\Backup\", "C:\temp\Backup\", "C:\temp\Backup1", "E:\Backup2\");
[string]   ${9}     = "C:\temp\BackupScripts\";
[string[]] ${15}   = @();
[bool]     ${11} = $false;
[bool]     ${3} = $true;
# Function to remove for file names invalid chars /\ <> : | * ? "
function removeInvalidChars
{
    param([parameter(Mandatory=$true)] [String] $fileName)
    $fileName = $fileName.Replace("/", "");
    $fileName = $fileName.Replace("\", "");
    $fileName = $fileName.Replace(":", "");
    $fileName = $fileName.Replace("<", "");
    $fileName = $fileName.Replace(">", "");
    $fileName = $fileName.Replace("|", "");
    $fileName = $fileName.Replace("*", "");
    $fileName = $fileName.Replace("?", "");
    $fileName = $fileName.Replace("'", "");
    $fileName = $fileName.Replace("""", "");
    return $fileName;
}
if (${14}.Length -eq 0)
{
    Write-Host "You should define at least one folder to backup to!" -ForegroundColor Red;
    Break;
}
cls;
Write-Host ((Get-Date -format yyyy-MM-dd_HH:mm:ss) + ": Starting ...");
# Open ADO.NET Connection with Windows authentification.
${1} = New-Object Data.SqlClient.SqlConnection;
${1}.ConnectionString = "Data Source=${19};Initial Catalog=master;Integrated Security=True;";
${1}.Open();
${2} = New-Object Data.SqlClient.SqlCommand;
${2}.Connection = ${1};
if (${3})
{
    # Register event "InfoMessage" and define action for it. 
    ${5} = Register-ObjectEvent ${1} "InfoMessage" -SourceIdentifier "PoShStripedBackup" -Action `
    { 
        [Data.SqlClient.SqlInfoMessageEventArgs] ${18} = $Event.SourceEventArgs;
        Write-Host ((Get-Date -format yyyy-MM-dd_HH:mm:ss) + ${18}.Message);    
    }
}
# If the list of databases is empty, query all names from Sql Server.
if (${15}.Length -eq 0)
{
    [string] ${17} = "SELECT [name] FROM sys.databases ORDER BY [name];";
    ${2}.CommandText = ${17};
    ${16} = ${2}.ExecuteReader();
    while (${16}.Read())
    {
        ${15} += ${16}.GetString(0);
    }
    ${16}.Close();
    ${16}.Dispose();
}
foreach (${4} in ${15})
{
    [string] ${8} = (Get-Date -format yyyy-MM-dd_HH-mm-ss);
    [int]    ${12} = 1;
    [string] ${10}   = [String]::Empty;
    [string] ${6}  = "BACKUP DATABASE [${4}] TO ";
    [string] ${7} = "USE [master]; `r`n" + `
                        "GO`r`n`r`n" + `
                        "RESTORE DATABASE [${4}] FROM ";    
    # Skip in all case the TempDB.
    if (${4} -eq "tempdb")
    {   continue;   }
    Write-Host ((Get-Date -format yyyy-MM-dd_HH:mm:ss) + ": Start striped backup of ${4}.");
    $fileName = removeInvalidChars ${4};
    foreach (${13} in ${14})
    {
        if (!${13}.EndsWith("\"))
        {   ${13} += "\";   }
        ${10} += "`r`nDISK = N'${13}$fileName`_${8}`_${12}.bak',";
        ${12} += 1;
    }
    ${6} += ${10}.Substring(0, ${10}.Length - 1);
    ${6} += "`r`nWITH NOFORMAT, INIT, NAME = N'${4} backup ${8}', SKIP, NOREWIND, NOUNLOAD, STATS = 10";
    if (${11}) 
    { ${6} += ", COMPRESSION;"   }
    else
    { ${6} += ";"   }    
    sc "${9}$fileName`_Backup`_${8}.sql" ${6};
    ${7} += ${10}.Substring(0, ${10}.Length - 1);
    ${7} += "`r`nWITH  FILE = 1, NOUNLOAD, REPLACE, STATS = 10;";
    sc "${9}$fileName`_Restore`_${8}.sql"  ${7};
    # Starting the backup    
    ${2}.CommandText = ${6};
    ${5} = ${2}.ExecuteNonQuery();
    Write-Host ((Get-Date -format yyyy-MM-dd_HH:mm:ss) + ": Finished striped backup of ${4}.`n`n");
}
if (${3})
{   Unregister-Event -SourceIdentifier "PoShStripedBackup";   }
${2}.Dispose();
${1}.Close();
${1}.Dispose();
Write-Host ((Get-Date -format yyyy-MM-dd_HH:mm:ss) + ": Finished");