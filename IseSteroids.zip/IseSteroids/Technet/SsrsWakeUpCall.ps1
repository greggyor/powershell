﻿
[string] ${00001011000001101} = "http://localhost/Reports";
[System.Net.WebClient] ${10011011011111101} = New-Object System.Net.WebClient;
${10011011011111101}.UseDefaultCredentials = $true;
try
{
    [string] ${01000100111000011} = ${10011011011111101}.DownloadString(${00001011000001101});
    [int] ${01010010000110110} = ${01000100111000011}.IndexOf("META Name=""Report Server""");
    if (${01010010000110110} -gt -1)
    {
        Write-Output "Response is ok.";
    }
    else
    {
        Write-Output "Got response, but not as expected.";
    }
}
catch
{
    Write-Verbose $_.Exception.Message;
}
${10011011011111101}.Dispose();
