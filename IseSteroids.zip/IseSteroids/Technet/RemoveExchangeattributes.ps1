﻿#Requires -version 2
<#
.SYNOPSIS

RemoveExchangeAttributes.ps1 - It Will Remove Exchange Attributes from Active Directory Accounts

Caution : Mailbox Will Go Disconnected and Exchange Attributes will be Removed"


.DESCRIPTION 

Remove Exchange 2010 Attributes for a Corrupted Active Directory Account

After an Exchange Server Crash. At times Some Active Directory accounts will get corrupted 

and It will not allow to disable the mailbox 

Its hard to Have all the Exchange attributes to get to Null .

So simplied the task into a simple script. Where we can set the Exchange attributes to Null in one shot


.EXAMPLE 

[PS] C:\>.\RemoveExchangeattributes.ps1


Remove Exchange Attributes
----------------------------

Remove Exchange 2010 Attributes for a Corrupted Active Directory Account

Caution : Mailbox Will Go Disconnected and Exchange Attributes will be Removed
Enter Alias: Manager

.NOTES
Written By: Satheshwaran Manoharan
Website : Www.careexchange.in

Change Log
V1.0, 08/11/2012 - Initial version
#>
#Add Exchange 2010 snapin if not already loaded
if (!(Get-PSSnapin | where {$_.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBFAHgAYwBoAGEAbgBnAGUALgBNAGEAbgBhAGcAZQBtAGUAbgB0AC4AUABvAHcAZQByAFMAaABlAGwAbAAuAEUAMgAwADEAMAA=')))}))
{
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue
}
Write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKAA0ACgBSAGUAbQBvAHYAZQAgAEUAeABjAGgAYQBuAGcAZQAgAEEAdAB0AHIAaQBiAHUAdABlAHMADQAKAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ADQAKAA0ACgBSAGUAbQBvAHYAZQAgAEUAeABjAGgAYQBuAGcAZQAgADIAMAAxADAAIABBAHQAdAByAGkAYgB1AHQAZQBzACAAZgBvAHIAIABhACAAQwBvAHIAcgB1AHAAdABlAGQAIABBAGMAdABpAHYAZQAgAEQAaQByAGUAYwB0AG8AcgB5ACAAQQBjAGMAbwB1AG4AdAANAAoADQAKAEMAYQB1AHQAaQBvAG4AIAA6ACAATQBhAGkAbABiAG8AeAAgAFcAaQBsAGwAIABHAG8AIABEAGkAcwBjAG8AbgBuAGUAYwB0AGUAZAAgAGEAbgBkACAARQB4AGMAaABhAG4AZwBlACAAQQB0AHQAcgBpAGIAdQB0AGUAcwAgAHcAaQBsAGwAIABiAGUAIABSAGUAbQBvAHYAZQBkAA=='))) -ForeGround $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
$EnterUser = Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByACAAQQBsAGkAYQBzAA==')))
$ADaccount = Get-User "$EnterUser"
$FullDistinguishName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwA='))) + $ADaccount.distinguishedName
$AccountEntry = New-Object DirectoryServices.DirectoryEntry $FullDistinguishName
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBhAGkAbAA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABvAG0AZQBNAEQAQgA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABvAG0AZQBNAFQAQQA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABlAGcAYQBjAHkARQB4AGMAaABhAG4AZwBlAEQATgA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBhAGkAbABiAG8AeABBAHUAZABpAHQARQBuAGEAYgBsAGUA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAQQBkAGQAcgBlAHMAcwBCAG8AbwBrAEYAbABhAGcAcwA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAQQByAGMAaABpAHYAZQBRAHUAbwB0AGEA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAQQByAGMAaABpAHYAZQBXAGEAcgBuAFEAdQBvAHQAYQA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAQgB5AHAAYQBzAHMAQQB1AGQAaQB0AA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgARAB1AG0AcABzAHQAZQByAFEAdQBvAHQAYQA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgARAB1AG0AcABzAHQAZQByAFcAYQByAG4AaQBuAGcAUQB1AG8AdABhAA=='))), $null) 
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgASABvAG0AZQBTAGUAcgB2AGUAcgBOAGEAbQBlAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBhAGkAbABiAG8AeABBAHUAZABpAHQARQBuAGEAYgBsAGUA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBhAGkAbABiAG8AeABBAHUAZABpAHQATABvAGcAQQBnAGUATABpAG0AaQB0AA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBhAGkAbABiAG8AeABHAHUAaQBkAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBEAEIAUgB1AGwAZQBzAFEAdQBvAHQAYQA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgATQBvAGQAZQByAGEAdABpAG8AbgBGAGwAYQBnAHMA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAUABvAGwAaQBjAGkAZQBzAEkAbgBjAGwAdQBkAGUAZAA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAUAByAG8AdgBpAHMAaQBvAG4AaQBuAGcARgBsAGEAZwBzAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAUgBCAEEAQwBQAG8AbABpAGMAeQBMAGkAbgBrAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAUgBlAGMAaQBwAGkAZQBuAHQARABpAHMAcABsAGEAeQBUAHkAcABlAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAUgBlAGMAaQBwAGkAZQBuAHQAVAB5AHAAZQBEAGUAdABhAGkAbABzAA=='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAVAByAGEAbgBzAHAAbwByAHQAUgBlAGMAaQBwAGkAZQBuAHQAUwBlAHQAdABpAG4AZwBzAEYAbABhAGcAcwA='))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAVQBNAEQAdABtAGYATQBhAHAA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAVQBNAEUAbgBhAGIAbABlAGQARgBsAGEAZwBzADIA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAVQBzAGUAcgBBAGMAYwBvAHUAbgB0AEMAbwBuAHQAcgBvAGwA'))), $null)
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAEUAeABjAGgAVgBlAHIAcwBpAG8AbgA='))), $null) 
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cAByAG8AeAB5AEEAZABkAHIAZQBzAHMAZQBzAA=='))), $null) 
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBoAG8AdwBJAG4AQQBkAGQAcgBlAHMAcwBCAG8AbwBrAA=='))), $null) 
$AccountEntry.PutEx(1, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBhAGkAbABOAGkAYwBrAG4AYQBtAGUA'))), $null)
$AccountEntry.SetInfo()
