﻿
[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact="High")]
Param(
    [parameter(Mandatory=$true,ParameterSetName="Type",ValueFromPipeline=$true)]
    [type]$Type,
    [parameter(Mandatory=$true,ParameterSetName="MemberDefinition",ValueFromPipeline=$true)]
    [Microsoft.PowerShell.Commands.MemberDefinition]$MemberDefinition,
    [parameter(Mandatory=$true,ParameterSetName="Query",ValueFromPipeline=$true)]
    [string]$Query,
    [switch]$Bing
)
Begin { 
    if ($Bing)
        { $search = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwB3AHcAdwAuAGIAaQBuAGcALgBjAG8AbQAvAHMAZQBhAHIAYwBoAD8AcQA9AHsAMAB9AA=='))) }
    else
        { $search = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBzAG8AYwBpAGEAbAAuAG0AcwBkAG4ALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AcwBlAGEAcgBjAGgALwBlAG4ALQB1AHMALwA/AHEAdQBlAHIAeQA9AHsAMAB9AA=='))) }
    Write-Verbose "Search engine set to $($search -f $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cQB1AGUAcgB5AA=='))))"
    $typeList = New-Object System.Collections.ArrayList
}
Process
{
    switch ($PsCmdlet.ParameterSetName)
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAB5AHAAZQA='))) { $searchType = $Type.FullName }
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBlAG0AYgBlAHIARABlAGYAaQBuAGkAdABpAG8AbgA='))) { $searchType = ($MemberDefinition.TypeName -replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XgAoAFMAZQBsAGUAYwB0AGUAZABcAC4AfABDAFMAVgA6AHwARABlAHMAZQByAGkAYQBsAGkAegBlAGQAXAAuACkAKwAoAC4AKgApAA=='))), '$2') }
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UQB1AGUAcgB5AA=='))) { $searchType = $Query }
    }
    if ($typeList.IndexOf($searchType) -ge 0)
        { Write-Verbose "Skipping already known type: $searchType" }
    else
    {
        Write-Verbose "Found new type: $searchType"
        [Void]($typeList.Add($searchType))
        if ($PsCmdlet.ShouldProcess($searchType, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABhAHUAbgBjAGgAIABzAGUAYQByAGMAaAAgAGUAbgBnAGkAbgBlAA==')))))
            { start ( $search -f $searchType ) }
    }
}
End {
    Remove-Variable typeList
}