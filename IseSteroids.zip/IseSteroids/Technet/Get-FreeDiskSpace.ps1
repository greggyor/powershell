﻿
Function f1($drive,$computer)
{
 $driveData = gwmi -class win32_LogicalDisk `
 -computername $computer -filter "Name = '$drive'" 
"
 $computer free disk space on drive $drive 
    $($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($driveData.FreeSpace/1MB)) MegaBytes
" 
}
f1 -drive "C:" -computer $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dgBpAHMAdABhAA==')))