﻿





$credential = Get-Credential
$cn = Read-Host -Prompt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBuAHQAZQByACAAYQAgAGMAbwBtAHAAdQB0AGUAcgAgAG4AYQBtAGUA')))
Get-WmiObject win32_bios -cn $cn -Credential $credential