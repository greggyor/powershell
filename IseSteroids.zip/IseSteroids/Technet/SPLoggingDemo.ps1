﻿# Demo of "SPLogging" by Ingo Karstein (ikarstein<at>hotmail.com)
#  v1.0

ipmo "$(split-path $MyInvocation.MyCommand.Path)\SPLogging.ps1"

Add-SPDiagnostigLoggingArea -AreaName "TestArea"

"PowerShell", "PS1", "PS2" | Add-SPDiagnostigLoggingArea 

Add-SPDiagnostigLoggingAreaCategory -AreaName "TestArea" -CategoryName "Category1" -TraceSeverityDefault High

Add-SPDiagnostigLoggingAreaCategory "TestArea\Category2" -TraceSeverityDefault High

"Test1", "Test2", "Test3" | Add-SPDiagnostigLoggingAreaCategory -AreaName "PowerShell" 
"Test1", "Test2", "Test3" | Add-SPDiagnostigLoggingAreaCategory -AreaName "PS1" 

Write-Host ""
Get-SPDiagnosticLoggingCategory -CategoryName "PowerShell\Test1"

Write-Host ""
Get-SPDiagnosticLoggingCategory -AreaName "PowerShell"

Write-Host ""
Get-SPDiagnosticLoggingCategory 


Write-SPDiagnosticLogging -CategoryName "PowerShell\Test1" -Message "Hello 1!" 

"Hello 2!" | Write-SPDiagnosticLogging -CategoryName "PS1\Test1" 

"Hello 3!", "Current date/time: {0}" | Write-SPDiagnosticLogging -CategoryName "PS1\Test2" -MessageArguments @(([DateTime]::Now)) -TraceSeverity "High"

