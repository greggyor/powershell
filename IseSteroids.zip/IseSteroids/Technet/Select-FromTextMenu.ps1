﻿function Select-FromTextMenu {
            <#
            .Synopsis
               Selects objects from an array using a text menu of selected properties.
            .DESCRIPTION
              Offers a text menu to select one or more objects from a an array, 
              by a list of selected properties. The display object will have an Item number,
              and the properties specified in the -By parameter taken from the original object.
              After the selection is made, the select Item numers will be used to select the
              original objects from the array to return - i.e. the return will be the original 
              objects, with all properties and methods intact, not the display objects.
              

              The default is to allow only a single object to be selectd.

              Use -Multi to allow selection of one or more entries from the menu.
                When selecting multiple objects, PowerShell range and/or array syntax can be used
                to specify the Items to select.

            .EXAMPLE
              $users | Select-FromTextMenu -by * | unlock-adaccount
            .EXAMPLE
              get-childitem *.csv | Select-FromTextMenu -by name,lastwritetime | invoke-item
            .EXAMPLE
              get-childitem *.txt |
               Select-FromTextMenu -Multi -by name,length,creationtime -Prompt 'Choose files to open'|
                invoke-item

            .Notes
             Author: Rob Campbell (@mjolinor)
             Version: 1.5
             Last Edit: 01/11/2013 16:30
            #>
           Param
            (
             # Objects to select from
             [Parameter(ValueFromPipeline=$true)]
             [object[]]
             $InputObjects,
             # Fields to display 
             [Parameter(Mandatory=$false,
                     Position=0)]
             [string[]]
             $By,
             # Prompt to display 
             [String]
             $Prompt,
             # Select Multiple Objects
             [Switch]
             $Multi
         )
           Begin
           {
             $DebugPreference = "continue"
             #Get Selection
                ${4} =
                {
                   ${3} = $Null
                   ${7} | ft -auto | oh
                   ${3} = Read-Host $Prompt
                   #Check for Single item
                     If (
                          (-not $Multi) -and
                          ${3}.Split('.,').count -gt 1
                          )
                           {
                            Write-Host 'You may only select a single Item' -ForegroundColor Yellow
                             .${4}
                             Return
                           }
                   #Check for Cancel
                   if (${3} -ieq 'C'){
                        Write-Host 'Selection Cancelled'
                       Return 'Cancelled'
                       }        
                   #Check for invalid characters and syntax
                   if (
                       (${3} -notmatch '[0-9,.]') -or
                       (${3}.Split(',') -notmatch '^((?:\d+\.\.\d+)|(?:\d+))$')
                      )
                       {
                         Write-Host 'Enter selection numbers as a range and/or comma separated list.' -ForegroundColor Yellow
                         Write-Host 'Examples: 3,1,2,4  1..3,7   5,1..2,4' -ForegroundColor Gray
                         .${4}
                         Return
                        }
                     #Check for out of range values
                     ${15} =   [int[]](${3}.Split('.,')) -match '\d+' | 
                       Sort | 
                       select -last 1
                     if (
                         ${15} -gt ${7}.count
                        )
                         {
                           Write-Host 'Selection is out of range.' -ForegroundColor Yellow
                           .${4}
                           Return
                         }
                      else {Return ${3}}
                  } # End Get-Selection
           ${8} = 1
           ${7} = @()
           ${2} = @()
           ${10} = $true
          }
         Process
         {
           #Validate -By property list from first object
           if (${10})
              {
               #-By contains property list
               if ($By)
                  {
                   ${14} = $_.psobject.properties |
                     select -expand Name
                   ${13} = $By |
                     Where {${14} -notcontains $_}
                  if (${13}){
                    #Invalid property name(s) found in -By list
                    Write-Warning "Select-FromTextMenu: One or more invalid property names found in -By list: $([string]${13})" 
                    ${5} = $true
                    Break
                    }
                    else {${9} = @('Item') + $By}
                  }
               # No properties specified for -By. Use default
               if (-not $By)
                 {
                   ${12} = $_  |
                   format-list |
                   out-string 
                   ${11} = (${12} -split "`n") -match '^\S+\s+:\s.+?$' |
                     select -first 5 |
                     foreach {($_ -split '\s:\s')[0].trim()}
                   ${9} = @('Item') + ${11}
                 }
              ${10} = $false
              } #End FirstObject setup
            ${2} += $_
            ${6} =   $_ | select ${9}
            ${6}.Item = [string](${8}++)
            ${7} += ${6}
       }
        End 
       { 
       if (${5})
         {
          Return
         }
       If (-not $Prompt)
         {
           If ($Multi) {$Prompt = 'Choose one or more'}
              Else {$Prompt = 'Choose one'}
         }
       $Prompt += ' (C to Cancel)'
       ${3} = &${4}
       if (${3} -ieq 'Cancelled')
         {
           Return
        }
         else {
                ${1} = ${3}.split(',')|% {iex $_}
                 ${1} = ${1} |
                  gu |
                  foreach {$_ -1}
                 ${2}[${1}]
               }
        }
    }
