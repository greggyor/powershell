﻿function Remove-ComObject {
 [CmdletBinding()]
 param()
 end {
  Start-Sleep -Milliseconds 500
  [Management.Automation.ScopedItemOptions]${1} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGEAZABPAG4AbAB5ACwAIABDAG8AbgBzAHQAYQBuAHQA')))
  Get-Variable -Scope 1 | Where-Object {
   $_.Value.pstypenames -contains $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBfAF8AQwBvAG0ATwBiAGoAZQBjAHQA'))) -and -not (${1} -band $_.Options)
  } | Remove-Variable -Scope 1 -Verbose:([Bool]$PSBoundParameters[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBlAHIAYgBvAHMAZQA=')))].IsPresent)
  [GC]::Collect()
 }
 <#
 .Synopsis
     Releases all <__ComObject> objects in the caller scope.
 .Description
     Releases all <__ComObject> objects in the caller scope, except for those that are Read-Only or Constant.
 .Example
     Remove-ComObject -Verbose
     Description
     ===========
     Releases <__ComObject> objects in the caller scope and displays the released COM objects' variable names.
 .Inputs
     None
 .Outputs
     None
 .Notes
     Name:      Remove-ComObject
     Author:    Robert Robelo
     LastEdit:  01/13/2010 19:14
 #>
}