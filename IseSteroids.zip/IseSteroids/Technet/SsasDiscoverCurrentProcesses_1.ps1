﻿
[string] $servername = "ServerName\InstanceName";
[bool] $onlyOverview = $false;
Clear-Host;
$connFmt = (@{ Label="ConnID" ; Alignment="right" ; Width=9 ; Expression={$_.ConnID} ; }, `
            @{ Label="Last Command Start" ; Alignment="left" ; Width=20 ; Expression={$_.LastCmdStartTime} ; }, `
            @{ Label="Last Command End" ; Alignment="left" ; Width=20 ; Expression={$_.LastCmdEndTime} ; }, `
            @{ Label="User Name" ; Alignment="left" ; Width=20 ; Expression={$_.UserName} ; }, `
            @{ Label="Host Name" ; Alignment="left" ; Width=20 ; Expression={$_.HostName} ; }, `
            @{ Label="Application" ; Alignment="left" ; Width=60 ; Expression={$_.HostApplication} ; } `
           );
$sessFmt = (@{ Label="Spid" ; Alignment="right" ; Width=9 ; Expression={$_.Spid} ; }, `
            @{ Label="Last Command Start" ; Alignment="left" ; Width=20 ; Expression={$_.LastCmdStartTime} ; }, `
            @{ Label="Last Command End" ; Alignment="left" ; Width=20 ; Expression={$_.LastCmdEndTime} ; }, `
            @{ Label="Cpu sec" ; Alignment="right" ; Width=10 ; Expression={$_.CpuTimeMs / 1000.0} ; FormatString="N1" ; }, `
            @{ Label="Mem KB" ; Alignment="right" ; Width=9 ; Expression={$_.UsedMemory} ; FormatString="N0" ; }, `
            @{ Label="Current DB" ; Alignment="left" ; Width=20 ; Expression={$_.CurrentDB} ; }, `
            @{ Label="Last Command" ; Alignment="left" ; Width=60 ; Expression={$_.LastCommand} ; } `
           );
$cmdFmt =  (@{ Label="Spid" ; Alignment="right" ; Width=9 ; Expression={$_.Spid} ; }, `
            @{ Label="Command Start Time" ; Alignment="left" ; Width=20 ; Expression={$_.StartTime} ; }, `
            @{ Label="Command End Time" ; Alignment="left" ; Width=20 ; Expression={$_.EndTime} ; }, `
            @{ Label="Cpu sec" ; Alignment="right" ; Width=10 ; Expression={$_.CpuTimeMs / 1000.0} ; FormatString="N1" ; }, `
            @{ Label="Reads" ; Alignment="right" ; Width=9 ; Expression={$_.Reads} ; FormatString="N0" ; }, `
            @{ Label="Read KB" ; Alignment="right" ; Width=9 ; Expression={$_.ReadKB} ; FormatString="N0" ; }, `
            @{ Label="Cmds #" ; Alignment="right" ; Width=10 ; Expression={$_.CmdCount} ; FormatString="N0" ; }, `
            @{ Label="Command" ; Alignment="left" ; Width=60 ; Expression={$_.CmdText} ; } `
           );
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices.AdomdClient") | Out-Null;
Write-Host ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Started ...`n");
$conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection;
$conn.ConnectionString = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQAgAFMAbwB1AHIAYwBlAD0AJABzAGUAcgB2AGUAcgBuAGEAbQBlADsAUwBzAHAAcgBvAHAASQBuAGkAdABBAHAAcABOAGEAbQBlAD0AUABvAHcAZQByAFMAaABlAGwAbAAgAFMAcwBhAHMARABpAHMAYwBvAHYAZQByAEMAdQByAHIAZQBuAHQAUAByAG8AYwBlAHMAcwBlAHMAOwA=')))
$conn.Open();
$cmd = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdCommand;
$cmd.Connection = $conn;
$da = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdDataAdapter;
[String] $mdx = "
SELECT SESSION_CONNECTION_ID AS ConnID
      ,SESSION_ID AS SessionID
      ,SESSION_SPID AS Spid
FROM `$SYSTEM.DISCOVER_SESSIONS
WHERE SESSION_ID = '" + $conn.SessionID + "'
ORDER BY SESSION_CONNECTION_ID;"
$cmd.CommandText = $mdx;
$da.SelectCommand = $cmd;
$meTbl = New-Object System.Data.DataTable;
$nil = $da.Fill($meTbl);
$me = $meTbl.Rows[0];
$mdx = "
SELECT CONNECTION_ID AS ConnID
      ,CONNECTION_USER_NAME AS [UserName]
      ,CONNECTION_HOST_NAME AS HostName
      ,CONNECTION_HOST_APPLICATION AS HostApplication
      ,CONNECTION_START_TIME AS StartTime
      ,CONNECTION_LAST_COMMAND_START_TIME AS LastCmdStartTime
      ,CONNECTION_LAST_COMMAND_END_TIME AS LastCmdEndTime
      ,CONNECTION_BYTES_SENT AS BytesSent
      ,CONNECTION_DATA_BYTES_RECEIVED AS BytesReceived
FROM `$SYSTEM.DISCOVER_CONNECTIONS
WHERE CONNECTION_ID <> " + $me.ConnID + "
ORDER BY CONNECTION_ID;"
$cmd.CommandText = $mdx;
$da.SelectCommand = $cmd;
$connTbl = New-Object System.Data.DataTable;
$nil = $da.Fill($connTbl);
$mdx = "
SELECT SESSION_CONNECTION_ID AS ConnID
      ,SESSION_ID AS SessionID
      ,SESSION_SPID AS Spid
      ,SESSION_USER_NAME AS [UserName]
      ,SESSION_CURRENT_DATABASE AS CurrentDB
      ,SESSION_USED_MEMORY AS UsedMemory
      ,SESSION_START_TIME AS StartTime
      ,SESSION_LAST_COMMAND AS LastCommand
      ,SESSION_LAST_COMMAND_START_TIME AS LastCmdStartTime
      ,SESSION_LAST_COMMAND_END_TIME AS LastCmdEndTime
      ,SESSION_LAST_COMMAND_CPU_TIME_MS AS LastCmdCpuTimeMs
      ,SESSION_COMMAND_COUNT AS CmdCount
      ,SESSION_CPU_TIME_MS AS CpuTimeMs
      ,SESSION_READS AS Reads
      ,SESSION_READ_KB AS ReadKB
FROM `$SYSTEM.DISCOVER_SESSIONS
WHERE SESSION_CONNECTION_ID <> " + $me.ConnID + "
ORDER BY SESSION_CONNECTION_ID;"
$cmd.CommandText = $mdx;
$da.SelectCommand = $cmd;
$sessTbl = New-Object System.Data.DataTable;
$nil = $da.Fill($sessTbl);
$mdx = "
SELECT SESSION_SPID AS Spid
      ,SESSION_COMMAND_COUNT AS CmdCount
      ,COMMAND_START_TIME AS StartTime
      ,COMMAND_END_TIME AS EndTime
      ,COMMAND_CPU_TIME_MS AS CpuTimeMs
      ,COMMAND_READS AS Reads
      ,COMMAND_READ_KB AS ReadKb
      ,COMMAND_TEXT AS CmdText
FROM `$SYSTEM.DISCOVER_COMMANDS
WHERE SESSION_SPID <> " + $me.Spid + "
ORDER BY SESSION_SPID;";
$cmd.CommandText = $mdx;
$da.SelectCommand = $cmd;
$cmdTbl = New-Object System.Data.DataTable;
$nil = $da.Fill($cmdTbl);
if (!$onlyOverview)
{
    Write-Host;
    foreach ($connRow in ($connTbl.Rows | Sort-Object ConnId))
    {
        Write-Host "Connection" $connRow.ConnID "of user" $connRow.UserName "********************************************************************"`
                   -ForegroundColor Blue;
        Write-Output $connRow | Format-Table ($connFmt);
        Write-Output ($sessTbl.Rows) | Where-Object {$_.ConnID -eq $connRow.ConnID} | Sort-Object Spid | Format-Table ($sessFmt);
        [long[]] $spids = (($sessTbl.Rows) | Where-Object {$_.ConnID -eq $connRow.ConnID} | Select-Object Spid).Spid;
        Write-Output ($cmdTbl.Rows) | Where-Object {$spids -contains $_.Spid} | Sort-Object Spid | Format-Table ($cmdFmt);
    }
}
Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBzAGEAcwAgAFAAcgBvAGMAZQBzAHMAIABPAHYAZQByAHYAaQBlAHcAIABvAGYAIAAkAHMAZQByAHYAZQByAG4AYQBtAGUAIAA6AA=='))) -ForegroundColor Blue;
Write-Host "Connections #:  " ($connTbl | Measure-Object).Count;
Write-Host "Send total:     " ([Math]::Round(($connTbl | Measure-Object -sum -Property BytesSent).Sum / 1024, 1)) "KB";
Write-Host "Received total: " ([Math]::Round(($connTbl | Measure-Object -sum -Property BytesReceived).Sum / 1024, 1)) "KB`n";
Write-Host "Sessions #:     " ($sessTbl | Measure-Object).Count;
Write-Host "Total used mem: " ([Math]::Round(($sessTbl | Measure-Object -sum -Property UsedMemory).Sum / 1024, 1)) "KB";
Write-Host "Total commands: " (($sessTbl | Measure-Object -sum -Property CmdCount).Sum);
Write-Host "Cpu time:       " ([Math]::Round(($sessTbl | Measure-Object -sum -Property CpuTimeMs).Sum / 1000, 1)) "sec";
Write-Host "Reads #:        " (($sessTbl | Measure-Object -sum -Property Reads).Sum);
Write-Host "Read data:      " (($sessTbl | Measure-Object -sum -Property ReadKB).Sum) "KB`n";
Write-Host "Commands #:     " ($cmdTbl | Measure-Object).Count;
Write-Host "Curr. running:  " ($cmdTbl | Where-Object {$_.EndTime.ToString() -eq ""} | Measure-Object).Count;
Write-Host "Cpu time:       " ([Math]::Round(($cmdTbl | Measure-Object -sum -Property CpuTimeMs).Sum / 1000, 1)) "sec";
Write-Host "Reads #:        " (($cmdTbl | Measure-Object -sum -Property Reads).Sum);
Write-Host "Read data:      " (($cmdTbl | Measure-Object -sum -Property ReadKB).Sum) "KB`n";
$da.Dispose();
$meTbl.Dispose();
$connTbl.Dispose();
$sessTbl.Dispose();
$cmdTbl.Dispose();
$cmd.Dispose();
$conn.Close();
$conn.Dispose();
Write-Host;
Write-Host ((Get-Date -format yyyy-MM-dd-HH:mm:ss) + ": Finished")