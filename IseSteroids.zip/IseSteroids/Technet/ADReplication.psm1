﻿#region Internals
# This function returns the number of trailing zeroes in the input byte
function _01110111000110001 {
	Param ([byte] $x)
	
	$numOfTrailingZeroes = 0;
	if ( $x -eq 0)
	{
   		return 8
	}
	
	if ( $x % 2 -eq 0)
	{
		$numOfTrailingZeroes ++;
		$numOfTrailingZeroes +=  _01110111000110001($x / 2)
	}
	
	return $numOfTrailingZeroes
}

# This function returns the number of non-zero bits in an ip-address
function _01100110110100111 {
	Param ([System.Net.IPAddress] $ipAddress)
	
	$byteArray = $ipAddress.GetAddressBytes()
	$numOfTrailingZeroes = 0;
	
	for ($i = $byteArray.Length - 1; $i -ge 0; $i--)
	{
    	$numOfZeroesInByte = _01110111000110001($byteArray[$i]);
    	if ($numOfZeroesInByte -eq 0)
		{
			break
		}
    	$numOfTrailingZeroes += $numOfZeroesInByte;
	}
	(($byteArray.Length * 8) - $numOfTrailingZeroes)
}

function _00110101110110100([String]$IPAddress)
{
	[Char[]] $charSplitter = @('.')
	[String[]] $ipData = $IPAddress.Split($charSplitter)
	
	return [Int64](
		([Int32]::Parse($ipData[0]) * [Math]::Pow(2, 24) +
		([Int32]::Parse($ipData[1]) * [Math]::Pow(2, 16) +
		([Int32]::Parse($ipData[2]) * [Math]::Pow(2, 8) +
		([Int32]::Parse($ipData[3]))))))
}

#region .net type ActiveDirectorySchedule2
$type_ActiveDirectorySchedule2 = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGkAbgBnACAAUwB5AHMAdABlAG0ALgBDAG8AbABsAGUAYwB0AGkAbwBuAHMALgBHAGUAbgBlAHIAaQBjADsADQAKAHUAcwBpAG4AZwAgAFMAeQBzAHQAZQBtAC4AVABlAHgAdAA7AA0ACgB1AHMAaQBuAGcAIABTAHkAcwB0AGUAbQAuAEQAaQByAGUAYwB0AG8AcgB5AFMAZQByAHYAaQBjAGUAcwA7AA0ACgB1AHMAaQBuAGcAIABTAHkAcwB0AGUAbQAuAEQAaQByAGUAYwB0AG8AcgB5AFMAZQByAHYAaQBjAGUAcwAuAEEAYwB0AGkAdgBlAEQAaQByAGUAYwB0AG8AcgB5ADsADQAKAA0ACgBuAGEAbQBlAHMAcABhAGMAZQAgAFMAeQBzAHQAZQBtAC4ARABpAHIAZQBjAHQAbwByAHkAUwBlAHIAdgBpAGMAZQBzAC4AQQBjAHQAaQB2AGUARABpAHIAZQBjAHQAbwByAHkADQAKAHsADQAKAAkAcAB1AGIAbABpAGMAIABjAGwAYQBzAHMAIABBAGMAdABpAHYAZQBEAGkAcgBlAGMAdABvAHIAeQBTAGMAaABlAGQAdQBsAGUAMgAgADoAIABBAGMAdABpAHYAZQBEAGkAcgBlAGMAdABvAHIAeQBTAGMAaABlAGQAdQBsAGUADQAKACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIABTAGkAdABlAEwAaQBuAGsATgBhAG0AZQAgAHsAIABnAGUAdAA7ACAAcwBlAHQAOwAgAH0ADQAKACAAIAAgACAAIAAgACAAIAAvAC8AcAB1AGIAbABpAGMAIABEAGkAYwB0AGkAbwBuAGEAcgB5ADwARABhAHkATwBmAFcAZQBlAGsALAAgAFMAYwBoAGUAZAB1AGwAZQBFAG4AdAByAHkAPgAgAEYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAUwB5AHMAdABlAG0ALgBDAG8AbABsAGUAYwB0AGkAbwBuAHMALgBBAHIAcgBhAHkATABpAHMAdAAgAEYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQANAAoAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGcAZQB0AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAC8ALwBEAGkAYwB0AGkAbwBuAGEAcgB5ADwARABhAHkATwBmAFcAZQBlAGsALAAgAFMAYwBoAGUAZAB1AGwAZQBFAG4AdAByAHkAPgAgAGYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwAgAEQAaQBjAHQAaQBvAG4AYQByAHkAPABEAGEAeQBPAGYAVwBlAGUAawAsACAAUwBjAGgAZQBkAHUAbABlAEUAbgB0AHIAeQA+ACgAKQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFMAeQBzAHQAZQBtAC4AQwBvAGwAbABlAGMAdABpAG8AbgBzAC4AQQByAHIAYQB5AEwAaQBzAHQAIABmAG8AcgBtAGEAdAB0AGUAZABTAGMAaABlAGQAdQBsAGUAIAA9ACAAbgBlAHcAIABTAHkAcwB0AGUAbQAuAEMAbwBsAGwAZQBjAHQAaQBvAG4AcwAuAEEAcgByAGEAeQBMAGkAcwB0ACgAKQA7AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABpAEQAYQB5ACAAPQAgADAAOwAgAGkARABhAHkAIAA8ACAAdABoAGkAcwAuAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQAuAEcAZQB0AEwAZQBuAGcAdABoACgAMAApADsAIABpAEQAYQB5ACsAKwApAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABTAGMAaABlAGQAdQBsAGUARQBuAHQAcgB5ACAAcwB3ACAAPQAgAG4AZQB3ACAAUwBjAGgAZQBkAHUAbABlAEUAbgB0AHIAeQAoACkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGYAbwByACAAKABpAG4AdAAgAGkASABvAHUAcgAgAD0AIAAwADsAIABpAEgAbwB1AHIAIAA8ACAAdABoAGkAcwAuAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQAuAEcAZQB0AEwAZQBuAGcAdABoACgAMQApADsAIABpAEgAbwB1AHIAKwArACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABiAG8AbwBsACAAaAB4AHgARQBuAGEAYgBsAGUAZAAgAD0AIABmAGEAbABzAGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAZgBvAHIAIAAoAGkAbgB0ACAAaQBUAGkAbQBlAFMAbABpAGMAZQAgAD0AIAAwADsAIABpAFQAaQBtAGUAUwBsAGkAYwBlACAAPAAgAHQAaABpAHMALgBSAGEAdwBTAGMAaABlAGQAdQBsAGUALgBHAGUAdABMAGUAbgBnAHQAaAAoADIAKQA7ACAAaQBUAGkAbQBlAFMAbABpAGMAZQArACsAKQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABpAGYAIAAoAHQAaABpAHMALgBSAGEAdwBTAGMAaABlAGQAdQBsAGUAWwBpAEQAYQB5ACwAIABpAEgAbwB1AHIALAAgAGkAVABpAG0AZQBTAGwAaQBjAGUAXQAgAD0APQAgAHQAcgB1AGUAKQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGgAeAB4AEUAbgBhAGIAbABlAGQAIAA9ACAAdAByAHUAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAcwB3AC4ARwBlAHQAVAB5AHAAZQAoACkALgBHAGUAdABQAHIAbwBwAGUAcgB0AHkAKABzAHQAcgBpAG4AZwAuAEYAbwByAG0AYQB0ACgAIgBoAHsAMAA6ADAAMAB9ACIALAAgAGkASABvAHUAcgApACkALgBTAGUAdABWAGEAbAB1AGUAKABzAHcALAAgAGgAeAB4AEUAbgBhAGIAbABlAGQAIAA/ACAAMQAgADoAIAAwACwAIABuAHUAbABsACkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAcwB3AC4ARABhAHkAIAA9ACAAKABEAGEAeQBPAGYAVwBlAGUAawApAGkARABhAHkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAcwB3AC4AUwBpAHQAZQBMAGkAbgBrAE4AYQBtAGUAIAA9ACAAdABoAGkAcwAuAFMAaQB0AGUATABpAG4AawBOAGEAbQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAALwAvAGYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQAuAEEAZABkACgAKABTAHkAcwB0AGUAbQAuAEQAYQB5AE8AZgBXAGUAZQBrACkAaQBEAGEAeQAsACAAcwB3ACkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQAuAEEAZABkACgAcwB3ACkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAByAGUAdAB1AHIAbgAgAGYAbwByAG0AYQB0AHQAZQBkAFMAYwBoAGUAZAB1AGwAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAfQANAAoADQAKACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAEEAYwB0AGkAdgBlAEQAaQByAGUAYwB0AG8AcgB5AFMAYwBoAGUAZAB1AGwAZQAyACgAQQBjAHQAaQB2AGUARABpAHIAZQBjAHQAbwByAHkAUwBjAGgAZQBkAHUAbABlACAAUwBjAGgAZQBkAHUAbABlACwAIABzAHQAcgBpAG4AZwAgAFMAaQB0AGUATABpAG4AawBOAGEAbQBlACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgADoAIABiAGEAcwBlACgAUwBjAGgAZQBkAHUAbABlACkADQAKACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAB0AGgAaQBzAC4AUwBpAHQAZQBMAGkAbgBrAE4AYQBtAGUAIAA9ACAAUwBpAHQAZQBMAGkAbgBrAE4AYQBtAGUAOwANAAoAIAAgACAAIAAgACAAIAAgAH0ADQAKAA0ACgAgACAAIAAgACAAIAAgACAAcAB1AGIAbABpAGMAIABBAGMAdABpAHYAZQBEAGkAcgBlAGMAdABvAHIAeQBTAGMAaABlAGQAdQBsAGUAMgAoACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgADoAIABiAGEAcwBlACgAKQANAAoAIAAgACAAIAAgACAAIAAgAHsAIAB9AA0ACgANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAdgBvAGkAZAAgAFIAZQBtAG8AdgBlAEQAYQBpAGwAeQBUAGkAbQBlAFMAbABvAHQAKABIAG8AdQByAE8AZgBEAGEAeQAgAGYAcgBvAG0ASABvAHUAcgAsACAASABvAHUAcgBPAGYARABhAHkAIAB0AG8ASABvAHUAcgApAA0ACgAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAaQBmACAAKABSAGEAdwBTAGMAaABlAGQAdQBsAGUAIAA9AD0AIABuAHUAbABsACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlACAAPQAgAG4AZQB3ACAAYgBvAG8AbABbADcALAAgADIANAAsACAANABdADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABiAG8AbwBsAFsALAAgACwAXQAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwAgAGIAbwBvAGwAWwA3ACwAIAAyADQALAAgADQAXQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAIAA9ACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABkACAAPQAgADAAOwAgAGQAIAA8ACAANwA7ACAAZAArACsAKQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABmAEgAIAA9ACAAKABpAG4AdAApAGYAcgBvAG0ASABvAHUAcgA7ACAAZgBIACAAPAA9ACAAKABpAG4AdAApAHQAbwBIAG8AdQByADsAIABmAEgAKwArACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMABdACAAPQAgAGYAYQBsAHMAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAbgBlAHcAUwBjAGgAZQBkAHUAbABlAFsAZAAsACAAZgBIACwAIAAxAF0AIAA9ACAAZgBhAGwAcwBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADIAXQAgAD0AIABmAGEAbABzAGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMwBdACAAPQAgAGYAYQBsAHMAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAH0ADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAH0ADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABSAGEAdwBTAGMAaABlAGQAdQBsAGUAIAA9ACAAbgBlAHcAUwBjAGgAZQBkAHUAbABlADsADQAKACAAIAAgACAAIAAgACAAIAB9AA0ACgANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAdgBvAGkAZAAgAEEAZABkAEQAYQBpAGwAeQBUAGkAbQBlAFMAbABvAHQAKABIAG8AdQByAE8AZgBEAGEAeQAgAGYAcgBvAG0ASABvAHUAcgAsACAASABvAHUAcgBPAGYARABhAHkAIAB0AG8ASABvAHUAcgApAA0ACgAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAaQBmACAAKABSAGEAdwBTAGMAaABlAGQAdQBsAGUAIAA9AD0AIABuAHUAbABsACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlACAAPQAgAG4AZQB3ACAAYgBvAG8AbABbADcALAAgADIANAAsACAANABdADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABiAG8AbwBsAFsALAAgACwAXQAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwAgAGIAbwBvAGwAWwA3ACwAIAAyADQALAAgADQAXQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAIAA9ACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABkACAAPQAgADAAOwAgAGQAIAA8ACAANwA7ACAAZAArACsAKQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABmAEgAIAA9ACAAKABpAG4AdAApAGYAcgBvAG0ASABvAHUAcgA7ACAAZgBIACAAPAA9ACAAKABpAG4AdAApAHQAbwBIAG8AdQByADsAIABmAEgAKwArACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMABdACAAPQAgAHQAcgB1AGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMQBdACAAPQAgAHQAcgB1AGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMgBdACAAPQAgAHQAcgB1AGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMwBdACAAPQAgAHQAcgB1AGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAB9AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlACAAPQAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAfQANAAoADQAKACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAHYAbwBpAGQAIABBAGQAZABUAGkAbQBlAFMAbABvAHQAKABEAGEAeQBPAGYAVwBlAGUAawAgAGYAcgBvAG0ARABhAHkALAAgAEQAYQB5AE8AZgBXAGUAZQBrACAAdABvAEQAYQB5ACwAIABIAG8AdQByAE8AZgBEAGEAeQAgAGYAcgBvAG0ASABvAHUAcgAsACAASABvAHUAcgBPAGYARABhAHkAIAB0AG8ASABvAHUAcgApAA0ACgAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAaQBmACAAKABSAGEAdwBTAGMAaABlAGQAdQBsAGUAIAA9AD0AIABuAHUAbABsACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlACAAPQAgAG4AZQB3ACAAYgBvAG8AbABbADcALAAgADIANAAsACAANABdADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABiAG8AbwBsAFsALAAgACwAXQAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwAgAGIAbwBvAGwAWwA3ACwAIAAyADQALAAgADQAXQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAIAA9ACAAUgBhAHcAUwBjAGgAZQBkAHUAbABlADsADQAKAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABmAG8AcgAgACgAaQBuAHQAIABkACAAPQAgACgAaQBuAHQAKQBmAHIAbwBtAEQAYQB5ADsAIABkACAAPAAgACgAaQBuAHQAKQB0AG8ARABhAHkAOwAgAGQAKwArACkADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAZgBvAHIAIAAoAGkAbgB0ACAAZgBIACAAPQAgACgAaQBuAHQAKQBmAHIAbwBtAEgAbwB1AHIAOwAgAGYASAAgADwAPQAgACgAaQBuAHQAKQB0AG8ASABvAHUAcgA7ACAAZgBIACsAKwApAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADAAXQAgAD0AIAB0AHIAdQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADEAXQAgAD0AIAB0AHIAdQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADIAXQAgAD0AIAB0AHIAdQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADMAXQAgAD0AIAB0AHIAdQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAfQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAfQANAAoADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAOwANAAoAIAAgACAAIAAgACAAIAAgAH0ADQAKAA0ACgAgACAAIAAgACAAIAAgACAAcAB1AGIAbABpAGMAIAB2AG8AaQBkACAAUgBlAG0AbwB2AGUAVABpAG0AZQBTAGwAbwB0ACgARABhAHkATwBmAFcAZQBlAGsAIABmAHIAbwBtAEQAYQB5ACwAIABEAGEAeQBPAGYAVwBlAGUAawAgAHQAbwBEAGEAeQAsACAASABvAHUAcgBPAGYARABhAHkAIABmAHIAbwBtAEgAbwB1AHIALAAgAEgAbwB1AHIATwBmAEQAYQB5ACAAdABvAEgAbwB1AHIAKQANAAoAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGkAZgAgACgAUgBhAHcAUwBjAGgAZQBkAHUAbABlACAAPQA9ACAAbgB1AGwAbAApAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwAgAGIAbwBvAGwAWwA3ACwAIAAyADQALAAgADQAXQA7AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAYgBvAG8AbABbACwAIAAsAF0AIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAIAA9ACAAbgBlAHcAIABiAG8AbwBsAFsANwAsACAAMgA0ACwAIAA0AF0AOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAbgBlAHcAUwBjAGgAZQBkAHUAbABlACAAPQAgAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQA7AA0ACgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAZgBvAHIAIAAoAGkAbgB0ACAAZAAgAD0AIAAoAGkAbgB0ACkAZgByAG8AbQBEAGEAeQA7ACAAZAAgADwAIAAoAGkAbgB0ACkAdABvAEQAYQB5ADsAIABkACsAKwApAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGYAbwByACAAKABpAG4AdAAgAGYASAAgAD0AIAAoAGkAbgB0ACkAZgByAG8AbQBIAG8AdQByADsAIABmAEgAIAA8AD0AIAAoAGkAbgB0ACkAdABvAEgAbwB1AHIAOwAgAGYASAArACsAKQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAbgBlAHcAUwBjAGgAZQBkAHUAbABlAFsAZAAsACAAZgBIACwAIAAwAF0AIAA9ACAAZgBhAGwAcwBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAWwBkACwAIABmAEgALAAgADEAXQAgAD0AIABmAGEAbABzAGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AFMAYwBoAGUAZAB1AGwAZQBbAGQALAAgAGYASAAsACAAMgBdACAAPQAgAGYAYQBsAHMAZQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAbgBlAHcAUwBjAGgAZQBkAHUAbABlAFsAZAAsACAAZgBIACwAIAAzAF0AIAA9ACAAZgBhAGwAcwBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAfQANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAfQANAAoADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAFIAYQB3AFMAYwBoAGUAZAB1AGwAZQAgAD0AIABuAGUAdwBTAGMAaABlAGQAdQBsAGUAOwANAAoAIAAgACAAIAAgACAAIAAgAH0ADQAKAA0ACgANAAoADQAKACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGMAbABhAHMAcwAgAFMAYwBoAGUAZAB1AGwAZQBFAG4AdAByAHkADQAKACAAIAAgACAAIAAgACAAIAB7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAAUwBpAHQAZQBMAGkAbgBrAE4AYQBtAGUAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAEQAYQB5AE8AZgBXAGUAZQBrACAARABhAHkAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADAAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADEAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADIAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADMAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADQAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADUAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADYAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADcAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADgAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAwADkAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADAAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADEAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADIAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADMAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADQAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADUAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADYAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADcAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADgAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAxADkAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAyADAAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAyADEAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAyADIAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABwAHUAYgBsAGkAYwAgAGkAbgB0ACAAaAAyADMAIAB7ACAAZwBlAHQAOwAgAHMAZQB0ADsAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAfQANAAoAIAAgACAAIAB9AA0ACgB9AA==')))
#endregion
#endregion

#---------------------------------------------------

#region Remove-ADSite
function Remove-ADSite
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$site = $null
		try
		{
			$site = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::FindByName($script:ctx, $Name)
		}
		catch [Exception]
		{
			Write-Error -Exception $_ -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAHQAbwAgAGQAZQBsAGUAdABlAA==')))
			return
		}
		
		try
		{
			$site.Delete()
			Write-Warning "Site $Name was removed"
		}
		catch [Exception]
		{
			Write-Error "Could not remove site $($Name): $($_.Exception.Message)"
		}
    }
	
	end { }
}
#endregion

#region Get-ADSite
function _10100000100001101
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		
		[Parameter(Mandatory=$true,ParameterSetName="All")]
		[switch] $All,
		
		[Parameter(Mandatory=$true,ParameterSetName="Current")]
		[switch] $Current,
		
		[Parameter(Mandatory=$true,ParameterSetName="ByIPAddress")]
		[System.Net.IPAddress] $IPAddress
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$site = $null
		try
		{
			switch ($pscmdlet.ParameterSetName)
			{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))
				{
					[System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::FindByName($script:ctx, $name)
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGwA')))
				{
					[System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest().Sites
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwB1AHIAcgBlAG4AdAA=')))
				{
					[System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::GetComputerSite()
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB5AEkAUABBAGQAZAByAGUAcwBzAA==')))
				{
					$result = New-Object System.Collections.ArrayList
					$subnets = _10000110100110110 -All
					[Int64] $ipAddressInDecimal = _00110101110110100($IPAddress);
					
					foreach ($subnet in $subnets)
					{
						$splittedSubnetName = $subnet.Name.Split('/');
						
						if ($splittedSubnetName.Length -eq 2)
						{
							[Int32] $subnetMask = [Int32]::Parse($splittedSubnetName[1]);
							[Int32] $numberOfAddresses = [Int32][Math]::Pow(2, (32 - $subnetMask)) - 1
							[string]$ipRange = $splittedSubnetName[0]
							[Int64] $lowIPAddress = _00110101110110100($ipRange)
							[Int64] $highIPAddress = $lowIPAddress + $numberOfAddresses
							[Int64] $totalIPAddressCount = ([Int64][Math]::Pow(2, 31)) - 1

							if (($lowIPAddress -le $ipAddressInDecimal) -and ($ipAddressInDecimal -le $highIPAddress) -and ($numberOfAddresses -le $totalIPAddressCount))
							{
								$result.Add($subnet) | Out-Null
							}
						}
					}
					
					if ($result.Count -gt 1)
					{
						Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQB1AGwAdABpAHAAbABlACAAUwB1AGIAbgBlAHQAcwAgAGYAbwB1AG4AZAAgAG0AYQB0AGMAaABpAG4AZwAgAHQAaABlACAASQBQACAAQQBkAGQAcgBlAHMAcwA=')))						
					}
					$result
				}
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAC8AIABzAGkAdABlAHMA')))
		}
    }
	
	end { }
}
#endregion

#region New-ADSite
function New-ADSite
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$false,Position=1,ValueFromPipelineByPropertyName=$true)]
		[string] $Location,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteOptions] $Options,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$site = $null
		try
		{
			$site = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::FindByName($script:ctx, $Name)
		}
		catch { }
		if ($site)
		{
			Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQAgAGQAbwBlAHMAIABhAGwAcgBlAGEAZAB5ACAAZQB4AGkAcwB0AA==')))
			return
		}
		
		try
		{
			$site = New-Object System.DirectoryServices.ActiveDirectory.ActiveDirectorySite($script:ctx, $Name)
			if ($Location)
			{
				$site.Location = $Location
			}
			
			if ($Options)
			{
				$Site.Options = $Options
			}
			
			$site.Save()
		
			if (($Description) -and ($Description -ne $site.Description))
			{
				$site.Description = $Description
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not create site: $($_.Exception.Message)"
			return
		}
		
		if ($PassThru)
		{
			$site
		}
    }
	
	end { }
}
#endregion

#region Set-ADSite
function Set-ADSite
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Location,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $ISTG,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteOptions] $Options,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$site = $null
		try
		{
			$site = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::FindByName($script:ctx, $Name)
		}
		catch
		{
			Write-Error "Could not read site $Name: $($_.Exception.Message)"
		}
		
		if (($Location) -and ($Location -ne $site.Location))
		{
			$site.Location = $Location
		}
		
		if (($Options) -and ($Options -ne $site.Options))
		{
			$Site.Options = $Options
		}
		
		if (($Description) -and ($Description -ne $site.Description))
		{
			$site.Description = $Description
		}
		
		try
		{
			$site.Save()
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not set site: $($_.Exception.Message)"
		}
		
		if ($PassThru)
		{
			$site
		}
    }
	
	end { }
}
#endregion

#---------------------------------------------------

#region Test-ADObject
function Test-ADObject
{
	[CmdletBinding(ConfirmImpact="Low")]
    Param (
    	[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true, 
        	HelpMessage="Identity of the AD object to verify if exists or not.")]
		[Object] $Identity 
	)
	
	process
	{
		try
		{
			if (Get-ADObject -Identity $Identity)
			{ return $true }
			else
			{ return $false }
		}
		catch [Exception]
		{
			Write-Error $_
			return $false
		}	
	}
}
#endregion

#---------------------------------------------------

#region New-ADSubnet
function New-ADSubnet
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[ValidateScript({
			if ($_.Contains("/"))
			{
				$subnetIPAddressStr,$prefixLengthStr = $_.Split("/")
				$subnetIPAddress = [System.Net.IPAddress]::Parse($subnetIPAddressStr)
				$specifiedPrefixLength = [int]::Parse($prefixLengthStr)
	          
				$ipAddressPrefixLength = _01100110110100111 $subnetIPAddress
				if ($ipAddressPrefixLength -gt $specifiedPrefixLength)
				{
					throw New-Object System.Management.Automation.PSArgumentException($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAHUAYgBuAGUAdAAgAHAAcgBlAGYAaQB4ACAAbABlAG4AZwB0AGgAIAB5AG8AdQAgAHMAcABlAGMAaQBmAGkAZQBkACAAaQBzACAAaQBuAGMAbwByAHIAZQBjAHQALgAgAFAAbABlAGEAcwBlACAAYwBoAGUAYwBrACAAdABoAGUAIABwAHIAZQBmAGkAeAAgAGEAbgBkACAAdAByAHkAIABhAGcAYQBpAG4ALgA='))))
				}
      		}
			else
			{
				$subnetIPAddress = [System.Net.IPAddress]::Parse($_)
				$prefixLength = _01100110110100111 $subnetIPAddress
				$Name = $_ + "/" + $prefixLength
			}
			return $true
		})]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$false,Position=1,ValueFromPipelineByPropertyName=$true)]
		[string] $Location,
		[Parameter(Mandatory=$false,Position=2,ValueFromPipelineByPropertyName=$true)]
		[ValidateScript({
			if ([string]::IsNullOrEmpty($_))
			{
				return $true
			}
			
			if (_10100000100001101 -Name $_)
			{ return $true }
			else
			{
				throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAGkAdABlACAAcwBwAGUAYwBpAGYAaQBlAGQAIABjAG8AdQBsAGQAIABuAG8AdAAgAGIAZQAgAGYAbwB1AG4AZAA=')))
			}
		})]
		[string] $Site,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$subnet = $null
		try
		{
			$subnet = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet]::($script:ctx, $Name)
		}
		catch { }
		if ($subnet)
		{
			Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGIAbgBlAHQAIABkAG8AZQBzACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdAA=')))
			return
		}
		
		try
		{
			$subnet = New-Object System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet($script:ctx, $Name)
			if ($Location)
			{
				$subnet.Location = $Location
			}
			
			if ($Site)
			{
				$subnet.Site = _10100000100001101 -Name $Site
			}
			
			$subnet.Save()
		
			if (($Description) -and ($Description -ne $subnet.Description))
			{
				$subnet.Description = $Description
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not create subnet: $($_.Exception.Message)"
			return
		}
		
		if ($PassThru)
		{
			$subnet
		}
    }
	
	end { }
}
#endregion

#region Get-ADSubnet
function _10000110100110110
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		
		[Parameter(Mandatory=$true,ParameterSetName="All")]
		[switch] $All
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$subnet = $null
		try
		{
			switch ($pscmdlet.ParameterSetName)
			{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))
				{
					[System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet]::FindByName($script:ctx, $Name)
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGwA')))
				{
      				$subnetContainerDN = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBOAD0AUwB1AGIAbgBlAHQAcwAsAEMATgA9AFMAaQB0AGUAcwAsAA=='))) + (Get-ADRootDSE).ConfigurationNamingContext)
					$searchRoot = New-Object System.DirectoryServices.DirectoryEntry($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwA='))) + $subnetContainerDN)
					$ds = New-Object System.DirectoryServices.DirectorySearcher
					$ds.SearchRoot = $searchRoot
					$ds.Filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABvAGIAagBlAGMAdABDAGEAdABlAGcAbwByAHkAPQBzAHUAYgBuAGUAdAApAA==')))
					$ds.PropertiesToLoad.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA=')))) | Out-Null
					
					foreach ($sn in $ds.FindAll())
					{
						[System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet]::FindByName($script:ctx, $sn.Properties[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))])
					}
				}
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAC8AIABzAGkAdABlAHMA')))
		}
    }
	
	end { }
}
#endregion

#region Remove-ADSubnet
function Remove-ADSubnet
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$subnet = $null
		try
		{
			$subnet = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet]::FindByName($script:ctx, $Name)
		}
		catch [Exception]
		{
			Write-Error -Exception $_ -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwB1AGIAbgBlAHQAIAB0AG8AIABkAGUAbABlAHQAZQA=')))
			return
		}
		
		try
		{
			$subnet.Delete()
			Write-Warning "Subnet $Name was removed"
		}
		catch [Exception]
		{
			Write-Error "Could not remove subnet $($Name): $($_.Exception.Message)"
		}
    }
	
	end { }
}
#endregion

#region Set-ADSubnet
function Set-ADSubnet
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[ValidateScript({
			if ($_.Contains("/"))
			{
				$subnetIPAddressStr,$prefixLengthStr = $_.Split("/")
				$subnetIPAddress = [System.Net.IPAddress]::Parse($subnetIPAddressStr)
				$specifiedPrefixLength = [int]::Parse($prefixLengthStr)
	          
				$ipAddressPrefixLength = _01100110110100111 $subnetIPAddress
				if ($ipAddressPrefixLength -gt $specifiedPrefixLength)
				{
					throw New-Object System.Management.Automation.PSArgumentException($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAHUAYgBuAGUAdAAgAHAAcgBlAGYAaQB4ACAAbABlAG4AZwB0AGgAIAB5AG8AdQAgAHMAcABlAGMAaQBmAGkAZQBkACAAaQBzACAAaQBuAGMAbwByAHIAZQBjAHQALgAgAFAAbABlAGEAcwBlACAAYwBoAGUAYwBrACAAdABoAGUAIABwAHIAZQBmAGkAeAAgAGEAbgBkACAAdAByAHkAIABhAGcAYQBpAG4ALgA='))))
				}
      		}
			else
			{
				$subnetIPAddress = [System.Net.IPAddress]::Parse($_)
				$prefixLength = _01100110110100111 $subnetIPAddress
				$Name = $_ + "/" + $prefixLength
			}
			return $true
		})]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Location,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[ValidateScript({
			if ([string]::IsNullOrEmpty($_))
			{
				return $true
			}
			
			if (_10100000100001101 -Name $_)
			{ return $true }
			else
			{
				throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAGkAdABlACAAcwBwAGUAYwBpAGYAaQBlAGQAIABjAG8AdQBsAGQAIABuAG8AdAAgAGIAZQAgAGYAbwB1AG4AZAA=')))
			}
		})]
		[string] $Site,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$subnet = $null
		try
		{
			$subnet = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySubnet]::FindByName($script:ctx, $Name)
		}
		catch
		{
			throw New-Object System.Exception("Could not read subnet $Name: $($_.Exception.Message)", $_.Exception)
		}
		
		if ($Location)
		{
			$subnet.Location = $Location
		}
		
		if ($Site)
		{
			$subnet.Site = _10100000100001101 -Name $Site
		}
		
		if (($Description) -and ($Description -ne $subnet.Description))
		{
			$subnet.Description = $Description
		}
		
		try
		{
			$subnet.Save()
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not set subnet: $($_.Exception.Message)"
		}
		
		if ($PassThru)
		{
			$subnet
		}
    }
	
	end { }
}
#endregion

#---------------------------------------------------

#region Remove-ADSiteLink
function Remove-ADSiteLink
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$siteLink = $null
		try
		{
			$siteLink = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink]::FindByName($script:ctx, $Name)
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAGwAaQBuAGsAIAB0AG8AIABkAGUAbABlAHQAZQA=')))
			return
		}
		
		try
		{
			$siteLink.Delete()
			Write-Warning "Site link $Name was removed"
		}
		catch [Exception]
		{
			Write-Error "Could not remove site link $($Name): $($_.Exception.Message)"
		}
    }
	
	end { }
}
#endregion

#region Get-ADSiteLink
function Get-ADSiteLink
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		
		[Parameter(Mandatory=$true,ParameterSetName="All")]
		[switch] $All		
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$siteLink = $null
		try
		{
			switch ($pscmdlet.ParameterSetName)
			{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))
				{
					[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink]::FindByName($script:ctx, $name)
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGwA')))
				{
					$siteLinkContainerDN = ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBOAD0ASQBQACwAQwBOAD0ASQBuAHQAZQByAC0AUwBpAHQAZQAgAFQAcgBhAG4AcwBwAG8AcgB0AHMALABDAE4APQBTAGkAdABlAHMALAA='))) + (Get-ADRootDSE).ConfigurationNamingContext)
					$searchRoot = New-Object System.DirectoryServices.DirectoryEntry($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwA='))) + $siteLinkContainerDN)
					$ds = New-Object System.DirectoryServices.DirectorySearcher
					$ds.SearchRoot = $searchRoot
					$ds.Filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABvAGIAagBlAGMAdABDAGEAdABlAGcAbwByAHkAPQBzAGkAdABlAEwAaQBuAGsAKQA=')))
					$ds.PropertiesToLoad.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBhAG0AZQA=')))) | Out-Null
					
					foreach ($sl in $ds.FindAll())
					{
						[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink]::FindByName($script:ctx, $sl.Properties[$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))])
					}
				}
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAGwAaQBuAGsAIAAvACAAcwBpAHQAZQAgAGwAaQBuAGsAcwA=')))
		}
    }
	
	end { }
}
#endregion

#region New-ADSiteLink
<#
Sample 3
$sites = Get-ADSite -All | Where-Object { $_.Name -ne 'Default-First-Site-Name' }
$mainSite = Get-ADSite -Name Default-First-Site-Name
$sites | ForEach-Object { New-ADSiteLink -Name "$($_.Name)-$($mainSite.Name)" -Description "Automatically created" -Sites $mainSite,$_ -Cost 100 -Interval 15 -NotificationEnabled }
#>
function New-ADSiteLink
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateCount(2, 50)]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySite[]] $Sites,
		[Parameter(Mandatory=$true,Position=1,ValueFromPipelineByPropertyName=$true)]
		[int] $Cost,
		[Parameter(Mandatory=$true,Position=2,ValueFromPipelineByPropertyName=$true)]
		[ValidateScript({
			if ($_ -isnot [System.Int32] -and $_ -isnot [System.TimeSpan])
			{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABtAHUAcwB0ACAAYgBlACAAbwBmACAAdAB5AHAAZQAgAEkAbgB0ADMAMgAgAG8AcgAgAFQAaQBtAGUAUwBwAGEAbgA='))) }
			
			if ($_ -is [Int32])
			{
				if ($_ -lt 15)
				{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABjAGEAbgBuAG8AdAAgAGIAZQAgAGwAZQBzAHMAIAB0AGgAYQBuACAAMQA1ACAAbQBpAG4AdQB0AGUAcwA='))) }
			}
			elseif ($_ -is [System.TimeSpan])
			{
				if ($_.TotalMinutes -lt 15)
				{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABjAGEAbgBuAG8AdAAgAGIAZQAgAGwAZQBzAHMAIAB0AGgAYQBuACAAMQA1ACAAbQBpAG4AdQB0AGUAcwA='))) }
			}
			return $true
		})]
		$ReplicationInterval,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $ReciprocalReplicationEnabled,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $NotificationEnabled,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[switch] $DataCompressionEnabled,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$siteLink = $null
		try
		{
			$siteLink = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink]::FindByName($script:ctx, $Name)
		}
		catch { }
		if ($siteLink)
		{
			Write-Error $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQAgAEwAaQBuAGsAIABkAG8AZQBzACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdAA=')))
			return
		}
		
		try
		{
			$siteLink = New-Object System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink($script:ctx, $Name)
			$siteLink.Cost = $Cost
			
			if ($ReplicationInterval -is [System.Int32])
			{ $siteLink.ReplicationInterval = New-TimeSpan -Minutes $ReplicationInterval }
			elseif ( $ReplicationInterval -is [System.TimeSpan] )
			{ $siteLink.ReplicationInterval = $ReplicationInterval }
			
			$siteLink.DataCompressionEnabled = $DataCompressionEnabled
			$siteLink.NotificationEnabled = $NotificationEnabled
			$siteLink.ReciprocalReplicationEnabled = $ReciprocalReplicationEnabled
			
			if ($sites)
			{
				foreach ($site in $Sites)
				{
					$siteLink.Sites.Add($site) | Out-Null
				}
			}
			
			$siteLink.Save()
			
			if (($Description) -and ($Description -ne $siteLink.Description))
			{
				$siteLink.Description = $Description
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not create site link: $($_.Exception.Message)"
			return
		}
		
		if ($PassThru)
		{
			$siteLink
		}
    }
	
	end { }
}
#endregion

#region Set-ADSiteLink
function Set-ADSiteLink
{
	[CmdletBinding(ConfirmImpact="Low")]
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipelineByPropertyName=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[string] $Description,
		[Parameter(Mandatory=$true,ValueFromPipelineByPropertyName=$true)]
		[ValidateCount(2, 50)]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySite[]] $Sites,
		[Parameter(Mandatory=$true,Position=1,ValueFromPipelineByPropertyName=$true)]
		[int] $Cost,
		[Parameter(Mandatory=$true,Position=2,ValueFromPipelineByPropertyName=$true)]
		[ValidateScript({
			if ($_ -isnot [System.Int32] -and $_ -isnot [System.TimeSpan])
			{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABtAHUAcwB0ACAAYgBlACAAbwBmACAAdAB5AHAAZQAgAEkAbgB0ADMAMgAgAG8AcgAgAFQAaQBtAGUAUwBwAGEAbgA='))) }
			
			if ($_ -is [Int32])
			{
				if ($_ -lt 15)
				{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABjAGEAbgBuAG8AdAAgAGIAZQAgAGwAZQBzAHMAIAB0AGgAYQBuACAAMQA1ACAAbQBpAG4AdQB0AGUAcwA='))) }
			}
			elseif ($_ -is [System.TimeSpan])
			{
				if ($_.TotalMinutes -lt 15)
				{ throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIAByAGUAcABsAGkAYwBhAHQAaQBvAG4AIABpAG4AdABlAHIAdgBhAGwAIABjAGEAbgBuAG8AdAAgAGIAZQAgAGwAZQBzAHMAIAB0AGgAYQBuACAAMQA1ACAAbQBpAG4AdQB0AGUAcwA='))) }
			}
			return $true
		})]
		$ReplicationInterval,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[bool] $ReciprocalReplicationEnabled,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[bool] $NotificationEnabled,
		[Parameter(Mandatory=$false,ValueFromPipelineByPropertyName=$true)]
		[bool] $DataCompressionEnabled,
		[Parameter(Mandatory=$false)]
		[switch] $PassThru
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$siteLink = $null
		try
		{
			$siteLink = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink]::FindByName($script:ctx, $Name)
		}
		catch
		{
			Write-Error "Could not read site Link $Name: $($_.Exception.Message)"
		}
		
		if (($Cost) -and ($Cost -ne $siteLink.Cost))
		{
			$siteLink.Cost = $Cost
		}
		
		if ($ReplicationInterval -is [System.Int32])
		{
			if (($ReplicationInterval) -and ($ReplicationInterval -ne $siteLink.ReplicationInterval.TotalMinutes))
			{
				$siteLink.ReplicationInterval = New-TimeSpan -Minutes $ReplicationInterval
			}
		}
		elseif ( $ReplicationInterval -is [System.TimeSpan] )
		{
			if ($siteLink.ReplicationInterval -ne $ReplicationInterval)
			{
				$siteLink.ReplicationInterval = $ReplicationInterval
			}
		}
		
		if (($ReciprocalReplicationEnabled -ne $siteLink.ReciprocalReplicationEnabled))
		{
			$siteLink.ReciprocalReplicationEnabled = $ReciprocalReplicationEnabled
		}
		if (($NotificationEnabled -ne $siteLink.NotificationEnabled))
		{
			$siteLink.NotificationEnabled = $NotificationEnabled
		}
		if (($DataCompressionEnabled -ne $siteLink.DataCompressionEnabled))
		{
			$siteLink.DataCompressionEnabled = $DataCompressionEnabled
		}
		
		if (($Description) -and ($Description -ne $site.Description))
		{
			$siteLink.Description = $Description
		}
		
		try
		{
			$siteLink.Save()
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message "Could not set site link: $($_.Exception.Message)"
		}
		
		if ($PassThru)
		{
			$siteLink
		}
    }
	
	end { }
}
#endregion

#---------------------------------------------------

#region Get-ADReplicationSchedule
function Get-ADReplicationSchedule
{
	[CmdletBinding(
		ConfirmImpact="Low"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true)]
		[ValidateNotNullOrEmpty()]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink] $SiteLink
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		try
		{			
			if ($SiteLink.InterSiteReplicationSchedule)
			{
				$schedule = New-Object System.DirectoryServices.ActiveDirectory.ActiveDirectorySchedule2($SiteLink.InterSiteReplicationSchedule, $siteLink.Name)
				$schedule.FormattedSchedule
			}
			else
			{
				Write-Warning $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABzAGkAdABlACAAbABpAG4AawAgAGgAYQBzACAAbgBvACAAcwBjAGgAZQBkAHUAbABlACAAYwBvAG4AZgBpAGcAdQByAGUAZAA=')))
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAGwAaQBuAGsAIAAvACAAcwBpAHQAZQAgAGwAaQBuAGsAcwA=')))
		}
    }
	
	end { }
}
#endregion

#region Reset-ADReplicationSchedule
function Reset-ADReplicationSchedule
{
	[CmdletBinding(
		ConfirmImpact="Low"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true)]
		[ValidateNotNullOrEmpty()]
		[System.DirectoryServices.ActiveDirectory.ActiveDirectorySiteLink] $SiteLink
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		try
		{			
			$schedule = New-Object System.DirectoryServices.ActiveDirectory.ActiveDirectorySchedule2
			$schedule.ResetSchedule()
			$schedule.AddDailyTimeSlot(0, 23)
			$siteLink.InterSiteReplicationSchedule = $schedule
			$siteLink.Save()
			Write-Warning "Inter Site Replication Schedule on site link $($siteLink.Name) was has been resetted (open 24x7)"
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABnAGUAdAAgAHQAaABlACAAcwBpAHQAZQAgAGwAaQBuAGsAIAAvACAAcwBpAHQAZQAgAGwAaQBuAGsAcwA=')))
		}
    }
	
	end { }
}
#endregion

#region Set-ADReplicationSchedule
function Set-ADReplicationSchedule
{
	throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAIABpAG0AcABsAGUAbQBlAG4AdABlAGQAIAB5AGUAdAA=')))
}
#endregion

#---------------------------------------------------

#region Get-ADReplicationLink
function Get-ADReplicationLink
{
	[CmdletBinding(
		ConfirmImpact="Low",
		DefaultParameterSetName="Name"
	)]
	
	Param (
		[Parameter(Mandatory=$true,Position=0,ValueFromPipeline=$true,ParameterSetName="Name")]
		[ValidateNotNullOrEmpty()]
		[ValidateScript({
			if (-not $_.Contains("."))
			{
				throw $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABOAGEAbQBlACAAbQB1AHMAdAAgAGIAZQAgAGEAIABGAFEARABOAA==')))
			}
			return $true
		})]
		[string] $Name,
		
		[Parameter(Mandatory=$true,ParameterSetName="All")]
		[switch] $All,
		
		[Parameter(Mandatory=$false)]
		[switch] $ErrorsOnly
	)
 
	begin {
		$script:ctx = $null
		try
		{
			$script:ctx = New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAZQBzAHQA'))))
		}
		catch [Exception]
		{
			Write-Error $_
			return
		}
	}
 
	process {
		$repInfo = @()
		try
		{
			switch ($pscmdlet.ParameterSetName)
			{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA=')))
				{
					$forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
					foreach ($domain in $forest.Domains)
					{
						foreach ($domainController in $domain.DomainControllers)
						{
							if ($domainController.Name -ne $Name)
							{
								continue
							}

							foreach ($partition in $domainController.Partitions)
							{
								$repNeighbors = $domainController.GetReplicationNeighbors($partition)
								if ($ErrorsOnly)
								{
									$repNeighbors = $repNeighbors | Where-Object { $_.LastSyncResult -ne 0 }
								}
								if ($repNeighbors.Count -eq 0 -or $repNeighbors -eq $null)
								{
									continue
								}
								
								$repNeighbors = $repNeighbors | ForEach-Object {
									$_ | Add-Member -MemberType NoteProperty -Name DestinationServer -Value $domainController.Name
									$_ | Add-Member -MemberType NoteProperty -Name DestinationServerAndNamingContext -Value "$($domainController.Name) $($_.PartitionName)"
									$_
								}
								$repInfo += $repNeighbors
							}
						}
					}
				}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBsAGwA')))
				{
					$forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
					foreach ($domain in $forest.Domains)
					{
						foreach ($domainController in $domain.DomainControllers)
						{
							foreach ($partition in $domainController.Partitions)
							{
								$repNeighbors = $domainController.GetReplicationNeighbors($partition)
								if ($ErrorsOnly)
								{
									$repNeighbors = $repNeighbors | Where-Object { $_.LastSyncResult -ne 0 }
								}
								if ($repNeighbors.Count -eq 0 -or $repNeighbors -eq $null)
								{
									continue
								}
								
								$repNeighbors = $repNeighbors | ForEach-Object {
									$_ | Add-Member -MemberType NoteProperty -Name DestinationServer -Value $domainController.Name
									$_ | Add-Member -MemberType NoteProperty -Name DestinationServerAndNamingContext -Value "$($domainController.Name) $($_.PartitionName)"
									$_
								}
								$repInfo += $repNeighbors
							}
						}
					}
				}
			}
		}
		catch [Exception]
		{
			Write-Error -Exception $_.Exception -Message $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQByAHIAbwByACAAcgBlAGEAZABpAG4AZwAgAHIAZQBwAGwAaQBjAGEAdABpAG8AbgAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgA=')))
		}
		
		$repInfo
    }
	
	end { }
}
#endregion

#---------------------------------------------------

Add-Type -TypeDefinition $type_ActiveDirectorySchedule2 -Language CSharpVersion3 -ReferencedAssemblies System.DirectoryServices
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBEACAAUgBlAHAAbABpAGMAYQB0AGkAbwBuACAATQBvAGQAdQBsAGUAIABsAG8AYQBkAGUAZAA='))) -ForegroundColor DarkGreen