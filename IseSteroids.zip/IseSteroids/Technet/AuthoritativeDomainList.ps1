﻿csvde -f C:\OUTempDump.csv -r "(objectclass=organizationalunit)"
$OUdump = Import-CSV C:\OUTempDump.csv
$report = @()
$auths = Get-AcceptedDomain | Where-Object{$_.DomainType -eq 'Authoritative'}
Foreach($Auth in $auths)
{
$Members = $OUdump | Where-Object{$_.upnsuffixes -like $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgAkAGEAdQB0AGgAKgA=')))} 
$Trick = $Auth.Name
$Total = $Members.Count
$userObj = New-Object PSObject
$userObj | Add-Member NoteProperty -Name "OrganizationalUnit" -Value $members.Name
$userObj | Add-Member NoteProperty -Name "Authoritative Domain" -Value $Trick
$report = $report += $userObj
$report | Export-csv -Path C:\OUdump.csv -NoTypeInformation
}