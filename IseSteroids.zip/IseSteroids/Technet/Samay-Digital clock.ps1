﻿
function _01001000011101010 {
	return $true 
}
function _10000001110000001 {
	$script:ExitCode = 0 
}
function _00110011010001101 {
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGMAbwByAGwAaQBiACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgA3ADcAYQA1AGMANQA2ADEAOQAzADQAZQAwADgAOQA='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAHIAYQB3AGkAbgBnACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIAMAAzAGYANQBmADcAZgAxADEAZAA1ADAAYQAzAGEA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBYAG0AbAAsACAAVgBlAHIAcwBpAG8AbgA9ADIALgAwAC4AMAAuADAALAAgAEMAdQBsAHQAdQByAGUAPQBuAGUAdQB0AHIAYQBsACwAIABQAHUAYgBsAGkAYwBLAGUAeQBUAG8AawBlAG4APQBiADcANwBhADUAYwA1ADYAMQA5ADMANABlADAAOAA5AA=='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGkAcgBlAGMAdABvAHIAeQBTAGUAcgB2AGkAYwBlAHMALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgAwADMAZgA1AGYANwBmADEAMQBkADUAMABhADMAYQA='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBDAG8AcgBlACwAIABWAGUAcgBzAGkAbwBuAD0AMwAuADUALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBTAGUAcgB2AGkAYwBlAFAAcgBvAGMAZQBzAHMALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgAwADMAZgA1AGYANwBmADEAMQBkADUAMABhADMAYQA='))))
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formSamayPowershellDigit = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQA=')))
	$Clocklabel = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	$timer1 = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABpAG0AZQByAA==')))
	$InitialFormWindowState = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQBXAGkAbgBkAG8AdwBTAHQAYQB0AGUA')))
	$formSamayPowershellDigit_Load={
	}
	$Clocklabel_Click={
	}
	$timer1_Tick={
		$Clocklabel.text = (Get-Date).ToString($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABIADoAbQBtADoAcwBzAA=='))))
	}
	$Form_StateCorrection_Load=
	{
		$formSamayPowershellDigit.WindowState = $InitialFormWindowState
	}
	$Form_Cleanup_FormClosed=
	{
		try
		{
			$Clocklabel.remove_Click($Clocklabel_Click)
			$formSamayPowershellDigit.remove_Load($formSamayPowershellDigit_Load)
			$timer1.remove_Tick($timer1_Tick)
			$formSamayPowershellDigit.remove_Load($Form_StateCorrection_Load)
			$formSamayPowershellDigit.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	$formSamayPowershellDigit.Controls.Add($Clocklabel)
	$formSamayPowershellDigit.BackColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABpAGcAaAB0AFMAawB5AEIAbAB1AGUA')))
	$formSamayPowershellDigit.ClientSize = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAxADEALAAgADkANAA=')))
	$formSamayPowershellDigit.FormBorderStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAHgAZQBkAFMAaQBuAGcAbABlAA==')))
	$formSamayPowershellDigit.MaximizeBox = $False
	$formSamayPowershellDigit.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBvAHIAbQBTAGEAbQBhAHkAUABvAHcAZQByAHMAaABlAGwAbABEAGkAZwBpAHQA')))
	$formSamayPowershellDigit.Opacity = 0.8
	$formSamayPowershellDigit.ShowIcon = $False
	$formSamayPowershellDigit.SizeGripStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABpAGQAZQA=')))
	$formSamayPowershellDigit.StartPosition = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAG4AdABlAHIAUwBjAHIAZQBlAG4A')))
	$formSamayPowershellDigit.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBhAG0AYQB5ACAAOgAgAFAAbwB3AGUAcgBzAGgAZQBsAGwAIABEAGkAZwBpAHQAYQBsACAAQwBsAG8AYwBrACAAIAA=')))
	$formSamayPowershellDigit.add_Load($formSamayPowershellDigit_Load)
	$Clocklabel.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAGcAbwBlACAAVQBJACwAIAAzADYAcAB0AA==')))
	$Clocklabel.ForeColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGkAdABlAA==')))
	$Clocklabel.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwA0ACwAIAA5AA==')))
	$Clocklabel.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAG8AYwBrAGwAYQBiAGUAbAA=')))
	$Clocklabel.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA2ADUALAAgADYAMwA=')))
	$Clocklabel.TabIndex = 0
	$Clocklabel.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsADEA')))
	$Clocklabel.add_Click($Clocklabel_Click)
	$timer1.Enabled = $True
	$timer1.Interval = 1
	$timer1.add_Tick($timer1_Tick)
	$InitialFormWindowState = $formSamayPowershellDigit.WindowState
	$formSamayPowershellDigit.add_Load($Form_StateCorrection_Load)
	$formSamayPowershellDigit.add_FormClosed($Form_Cleanup_FormClosed)
	return $formSamayPowershellDigit.ShowDialog()
} 
if((_01001000011101010) -eq $true)
{
	_00110011010001101 | Out-Null
	_10000001110000001
}
