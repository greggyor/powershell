﻿<# 
================================================================================
PURPOSE:	Graph Nested AD Security Groups

AUTHORS:	Axel Limousin
VERSION:	1.1 
DATE:		04/21/2013 

SYNTAX:		List-ADSecurityGroupMemberOf <ObjectDN> ` 
            [-SC {<Onelevel> | <Subtree>}] [-RL <integer>] `
			| Graph-ADSecurityGroupMemberOf `
			> <FilePath>

EXAMPLE:	List-ADSecurityGroupMemberOf "OU=MyOU,DC=MyDom,DC=MyRoot"
			| Graph-ADSecurityGroupMemberOf `
			> "$env:USERPROFILE\Desktop\ADSecurityGroupMemberOf.viz"

THANKS:		Thomas Corbiere
================================================================================
#>
function Dig-ADSecurityGroupMemberOf { 
	param ( 
		[Parameter(ValueFromPipeline = $true, Mandatory = $true)] 
        [Microsoft.ActiveDirectory.Management.ADGroup] $ADSGroup,
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
        [Alias("RL")]
		[Byte] $RecursionLevel = 5,
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[Alias("CL")]
        [Byte] $CurrentLevel = 0
    )
    if ($CurrentLevel -ge $RecursionLevel) { 
		return 
    }
 	if ($ADSGroup.GroupCategory -eq "Security") {
		Get-ADGroup $ADSGroup.DistinguishedName -Properties MemberOf `
		| Select-Object Name, DistinguishedName, GroupScope, MemberOf
	}
    (Get-ADGroup $ADSGroup.DistinguishedName -Properties MemberOf).MemberOf `
	| ForEach-Object -Process {
		Get-ADGroup $_ | Dig-ADSecurityGroupMemberOf `
		-RL $RecursionLevel `
		-CL ($CurrentLevel+1)
	}
}
function List-ADSecurityGroupMemberOf { 
	param ( 
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[String] $ADDN = (Get-ADDomain).DistinguishedName,
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
        [Alias("SC")]
		[Microsoft.ActiveDirectory.Management.ADSearchScope] $Scope = "Subtree",
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
        [Alias("RL")]
		[Byte] $RecursionLevel = 5
    )
	$ADObject = Get-ADObject $ADDN -Properties groupType
	if ($ADObject.ObjectClass -eq "domainDNS" `
	-or $ADObject.ObjectClass -eq "organizationalUnit" `
	-or $ADObject.ObjectClass -eq "container") { 
		$ADSGroupList = Get-ADGroup -Filter {GroupCategory -eq "Security"} `
		-SearchBase $ADDN -SearchScope $Scope -Properties MemberOf `
		| ForEach-Object -Process { 
			if($_.MemberOf) { 
				$_ | Dig-ADSecurityGroupMemberof -RL $RecursionLevel 
        	}
    	} 
		$ADSGroupList = $ADSGroupList | Sort-Object -Uniq `
		-Property DistinguishedName 
		return $ADSGroupList 
	}
	elseif ($ADObject.ObjectClass -eq "group" `
	-and $ADObject.groupType -like "-2*") {
		$ADSGroup = Get-ADGroup $ADObject.DistinguishedName
		$ADSGroupList = Dig-ADSecurityGroupMemberof $ADSGroup `
		-RL $RecursionLevel
		$ADSGroupList = $ADSGroupList | Sort-Object -Uniq `
		-Property DistinguishedName 
		return $ADSGroupList
	}
	else {
		Write-Warning -Message "Please select a Domain, an OU, a Container `
		or a Security Group" 
	}
}
function Graph-ADSecurityGroupMemberOf {
	param (
		[Parameter(ValueFromPipeline = $true, Mandatory = $true)]
		[System.Management.Automation.PSObject[]] $ADSGroupList,
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
		[String] $DomainLocalColor = "Red",
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
        [String] $GlobalColor      = "Green",
		[Parameter(ValueFromPipeline = $false, Mandatory = $false)]
        [String] $UniversalColor   = "Cyan"
    )
    begin {
        $Groups = @() #ComparisonArray
        $GroupColor = {
			param (
				[Parameter(ValueFromPipeline = $false, Mandatory = $true)]
				[Microsoft.ActiveDirectory.Management.ADGroupScope] $GroupScope
			)
            switch ($GroupScope) {
                "DomainLocal" { return $DomainLocalColor }
                "Global"      { return $GlobalColor }
                "Universal"   { return $UniversalColor }
            }
        }
        $GraphNode = {
			param (
				[Parameter(ValueFromPipeline = $false, Mandatory = $true)]
				[System.Management.Automation.PSObject] $ADSGroup
			)
			$StrMark = $ADSGroup.DistinguishedName.IndexOf("DC=")
			$DomainName = $ADSGroup.DistinguishedName.Substring($StrMark)
			#$StrMark = $ADSGroup.DistinguishedName.IndexOf(",DC=dom,DC=root")
			#$DomainName = $ADSGroup.DistinguishedName.Remove($StrMark)
            #$DomainName = $DomainName.Substring($DomainName.IndexOf("OU="))
            "node_{0} [" -f [Array]::indexOf($Groups, `
			$ADSGroup.DistinguishedName)						| Write-Output
            'label="{0}|{1}";' -f $ADSGroup.Name, $DomainName	| Write-Output
            "color={0};" -f (&$GroupColor $ADSGroup.GroupScope)	| Write-Output
            'shape = "record"'									| Write-Output
            "]"													| Write-Output
        }
        "digraph g {" 				| Write-Output
        'graph [rankdir = "LR"] ;' 	| Write-Output
        "overlap = false ;" 		| Write-Output
    }
    process {
		foreach ($ADSGroup in $ADSGroupList) {
        	if ([Array]::indexOf($Groups, $ADSGroup.DistinguishedName) -eq -1) {
				$Groups += $ADSGroup.DistinguishedName
            	&$GraphNode $ADSGroup
        	}
        	$ADSGroup.MemberOf | ForEach-Object -Process {
				$ParentGroup = Get-ADGroup $_
				if ($ParentGroup.GroupCategory -eq "Security") {
					if ([array]::indexOf($Groups, `
					$ParentGroup.DistinguishedName) -eq -1) {
						$Groups += $ParentGroup.DistinguishedName
                		&$GraphNode $ParentGroup
           			}
            	"node_{0} -> node_{1} ;" -f [Array]::indexOf($Groups, `
				$ADSGroup.DistinguishedName), [Array]::indexOf($Groups, `
				$ParentGroup.DistinguishedName)					| Write-Output
        		}
			}
		}
    }
    end {
		"}"	| Write-Output
    }
}