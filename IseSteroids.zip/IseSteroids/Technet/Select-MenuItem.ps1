﻿FUNCTION GLOBAL:Select-MenuItem {
[CMDLETBINDING()]
PARAM
(
	[string]
	$heading = "Response required:"
	,
	[string]
	$Prompt = "Enter your selection from the menu shown below:"
	,
	$Default = 0
	,
	[string]
	$MenuText = ""
	,
	[string]
	$Delimiter = "`n"
	,
	[switch]
	$showMenu
)
	switch ( $MenuText ) {
		"Ok"    { $MenuText = "&Ok = acknowledge the above information" }
		"OkC"   { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBPAGsAIAA9ACAAcABlAHIAZgBvAHIAbQAgAHQAaABlACAAcwB1AGcAZwBlAHMAdABlAGQAIABhAGMAdABpAG8AbgAgACQARABlAGwAaQBtAGkAdABlAHIAIAA=')))+`
		                      "&Cancel = cancel the current operation" }
		"ARI"   { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBBAGIAbwByAHQAIAA9ACAAYQBiAG8AcgB0ACAAdABoAGUAIABjAHUAcgByAGUAbgB0ACAAbwBwAGUAcgBhAHQAaQBvAG4AIAAkAEQAZQBsAGkAbQBpAHQAZQByACAA')))+`
		                      $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBSAGUAdAByAHkAIAA9ACAAcgBlAHQAcgB5ACAAdABoAGUAIABhAGMAdABpAG8AbgAgAHQAaABhAHQAIABmAGEAaQBsAGUAZAAgACQARABlAGwAaQBtAGkAdABlAHIAIAA=')))+`
		                      "&Ignore = ignore the error and continue" }
		"YN"    { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBZAGUAcwAgAD0AIABwAGUAcgBmAG8AcgBtACAAdABoAGUAIABzAHUAZwBnAGUAcwB0AGUAZAAgAGEAYwB0AGkAbwBuACAAJABEAGUAbABpAG0AaQB0AGUAcgAgAA==')))+`
		                      "&No = do not perform the suggested action" }
		"YNC"   { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBZAGUAcwAgAD0AIABwAGUAcgBmAG8AcgBtACAAdABoAGUAIABzAHUAZwBnAGUAcwB0AGUAZAAgAGEAYwB0AGkAbwBuACAAJABEAGUAbABpAG0AaQB0AGUAcgAgAA==')))+`
		                      $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBOAG8AIAA9ACAAZABvACAAbgBvAHQAIABwAGUAcgBmAG8AcgBtACAAdABoAGUAIABzAHUAZwBnAGUAcwB0AGUAZAAgAGEAYwB0AGkAbwBuACAAJABEAGUAbABpAG0AaQB0AGUAcgAgAA==')))+`
		                      "&Cancel = cancel the current operation altogether" }
		"RC"    { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBSAGUAdAByAHkAIAA9ACAAcgBlAHQAcgB5ACAAdABoAGUAIABhAGMAdABpAG8AbgAgAHQAaABhAHQAIABmAGEAaQBsAGUAZAAgACQARABlAGwAaQBtAGkAdABlAHIAIAA=')))+`
		                      "&Cancel = cancel the current operation altogether" }
		"YANLS" { $MenuText = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBZAGUAcwAgAD0AIABDAG8AbgB0AGkAbgB1AGUAIAB3AGkAdABoACAAbwBuAGwAeQAgAHQAaABlACAAbgBlAHgAdAAgAHMAdABlAHAAIABvAGYAIAB0AGgAZQAgAG8AcABlAHIAYQB0AGkAbwBuAC4AIAAkAEQAZQBsAGkAbQBpAHQAZQByAA==')))+`
							  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAHMAIAB0AG8AIAAmAEEAbABsACAAIAA9ACAAQwBvAG4AdABpAG4AdQBlACAAdwBpAHQAaAAgAGEAbABsACAAdABoAGUAIABzAHQAZQBwAHMAIABvAGYAIAB0AGgAZQAgAG8AcABlAHIAYQB0AGkAbwBuAC4AIAAkAEQAZQBsAGkAbQBpAHQAZQByAA==')))+`
							  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JgBOAG8AIAAgACAAIAAgACAAIAAgACAAIAA9ACAAUwBrAGkAcAAgAHQAaABpAHMAIABvAHAAZQByAGEAdABpAG8AbgAgAGEAbgBkACAAcAByAG8AYwBlAGUAZAAgAHcAaQB0AGgAIAB0AGgAZQAgAG4AZQB4AHQAIABvAHAAZQByAGEAdABpAG8AbgAuACAAJABEAGUAbABpAG0AaQB0AGUAcgA=')))+`
							  $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAdABvACAAQQAmAGwAbAAgACAAIAA9ACAAUwBrAGkAcAAgAHQAaABpAHMAIABvAHAAZQByAGEAdABpAG8AbgAgAGEAbgBkACAAYQBsAGwAIABzAHUAYgBzAGUAcQB1AGUAbgB0ACAAbwBwAGUAcgBhAHQAaQBvAG4AcwAuACAAJABEAGUAbABpAG0AaQB0AGUAcgA=')))+`
							  "&Suspend     = Pause the current pipeline and return to the command prompt. Type 'exit' to resume the pipeline." }
		""     {
			$Heading   = "Demonstration mode: the available menu shortcuts are shown as"
			$Prompt    = "keywords with the corresponding options listed under 'Meaning'"
			$Default   = "OK"
			$showMenu  = $true 
			$MenuText  = @"
				&OK    = OK only
				OK&C   = OK and Cancel
				AR&I   = Abort, Retry and Ignore
				&YN    = Yes and No
				Y&NC   = Yes, No, and Cancel
				&RC    = Retry and Cancel
				Y&ANLS = Yes, Yes to All, No, No to All, Suspend
"@
		}
	}
	$returnFormat = "number"
	$useAsDefault = $default
	$choices      = @() 
	$accelerators = @() 
	$keyWords     = @() 
	$menushow     = @() 
	foreach ( $item in $MenuText.split( $Delimiter ) ) {
		$itemNo = $choices.count
		$keyword,$phrase = $item.split("=")
		$keyword         = $keyword.trim()
		$phrase          = $phrase.trim()
		$word            = $keyword.replace("&","")
		$before,$after   = $keyword.split("&")
		TRY {$accelerator = $after[0]} CATCH {$accelerator = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABpAHQAZQBtAE4AbwA=')))}
		if ( $accelerator -eq $default ) {
			$returnFormat = "keyChar"
			$useAsDefault = $itemNo
		} elseif ( $word -eq $default ) {
			$returnFormat = "keyWord"
			$useAsDefault = $itemNo
		}
		$choices      += New-Object System.Management.Automation.Host.ChoiceDescription $keyword, $phrase
		$accelerators += $accelerator
		$keyWords     += $word
		$menushow     += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB3AG8AcgBkAAkAIAAtACAAJABwAGgAcgBhAHMAZQA=')))
	}
	$options = [System.Management.Automation.Host.ChoiceDescription[]]( $choices )
	if ( $showMenu ) {
		write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgAkAEgAZQBhAGQAaQBuAGcACgAkAFAAcgBvAG0AcAB0AAoACgBLAGUAeQB3AG8AcgBkAAkAIAAtACAATQBlAGEAbgBpAG4AZwA=')))
		write-host '=================================================='
		$menushow | foreach {write-host $_}
		write-host '=================================================='
	}
	TRY
	{
		$result = $host.ui.PromptForChoice( $heading, $Prompt, $options, $useAsDefault )
	}
	CATCH
	{
		$result = $host.ui.PromptForChoice( $heading, $Prompt, $options, -1 )
	} 
	switch ( $returnFormat ) {
		"keychar" { $result = $accelerators[$result] }
		"keyword" { $result = $keyWords[$result] }
	}
	return $result
}	
