﻿#set error action
$erroractionpreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQA=')))

# declear object filter 

${00110001010001000} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABvAGIAagBlAGMAdABDAGEAdABlAGcAbwByAHkAPQBVAHMAZQByACkA')))

# declare Vars for Domain

# connects to Domain at base OU of Exchange/recipients 
${10010100101000111} = New-Object System.DirectoryServices.DirectoryEntry($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwBPAFUAPQBSAGUAYwBpAHAAaQBlAG4AdABzACwATwBVAD0ARQB4AGMAaABhAG4AZwBlACwARABDAD0AZQB4AGMAaABhAG4AZwBlACwARABDAD0AYwBvAG4AdABvAHMAbwAsAEQAQwA9AGMAbwBtAA=='))))
# Init AD Search in 2k domain 
${10000110101011011} = New-Object System.DirectoryServices.DirectorySearcher
${10000110101011011}.SearchRoot = ${10010100101000111}
${10000110101011011}.PageSize = 3000
${10000110101011011}.Filter = ${00110001010001000}
${10000110101011011}.SearchScope = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGIAdAByAGUAZQA=')))

# Init Query 

${00011001010100101} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBhAG0AZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cABlAHIAcwBvAG4AYQBsAFQAaQB0AGwAZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQBtAHAAbABvAHkAZQBlAFQAeQBwAGUA')))
foreach (${10110000001001111} in ${00011001010100101}){${10000110101011011}.PropertiesToLoad.Add(${10110000001001111})}




# set main Vars
[array]${10000000100100001} 
[string]${10101011100101100}
${00100010000110101} = get-mailbox -OrganizationalUnit $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZQB4AGMAaABhAG4AZwBlAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtAC8ARQB4AGMAaABhAG4AZwBlAC8AUgBlAGMAaQBwAGkAZQBuAHQAcwAvAG8AcgBnADEA'))) -ResultSize Unlimited
${10000000100100001} = ${00100010000110101}

#start eval of each Object returned
foreach (${01000010111000100} in ${10000000100100001})
{ 
#Eval for employeeType based on personalTitle 
 if (${01000010111000100}.personalTitle -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBpAHYA'))) )
{
#Set Civilian employeeType = C
${10101011100101100} =  "C"
write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBtAHAAbABvAHkAZQBlACAAVAB5AHAAZQAgAGYAbwByACAA')))${01000010111000100}.alias$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABzAGUAdAAgAHQAbwA6AA=='))) ${10101011100101100} -foregroundcolor White
${11000011000111000} = set-mailbox ${01000010111000100}.identity  -employeeType ${10101011100101100}
${11000011000111000}
}
 if (${01000010111000100}.personalTitle -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBUAFIA'))) )
{
#Set Contractor employeeType = E
${10101011100101100} =  "E"
write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBtAHAAbABvAHkAZQBlACAAVAB5AHAAZQAgAGYAbwByACAA')))${01000010111000100}.alias$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABzAGUAdAAgAHQAbwA6AA=='))) ${10101011100101100} -foregroundcolor White
${11000011000111000} = set-mailbox ${01000010111000100}.identity  -employeeType ${10101011100101100}
${11000011000111000}
}
 else 
{
#Set Federal employeeType = A
${10101011100101100} =  "A"
write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBtAHAAbABvAHkAZQBlACAAVAB5AHAAZQAgAGYAbwByACAA')))${01000010111000100}.alias$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABzAGUAdAAgAHQAbwA6AA=='))) ${10101011100101100} -foregroundcolor White
${11000011000111000} = set-mailbox ${01000010111000100}.identity  -employeeType ${10101011100101100}
$setcommandnull
}
}