﻿








param (
      $serverList =  "C:\\Machine.txt"
)
$computers = gc $serverList




$mailto = "mail1@mail.net, mail2@mail.net" 




$emailFrom = "suport@mail.net"
$smtpServer = "myAnonymousSmtpServer" 




[decimal]$warningThresholdSpace = 20 
[decimal]$criticalThresholdSpace = 10 




[System.Array]$results = foreach ($cmp in $computers) { 
 Get-WMIObject  -ComputerName $cmp Win32_LogicalDisk |
where{($_.DriveType -eq 3) -and (($_.freespace/$_.size*100) -lt $warningThresholdSpace) }|
select @{n='Server Name' ;e={"{0:n0}" -f ($cmp)}},
@{n='Volume Name' ;e={"{0:n0}" -f ($_.volumename)}},
@{n='Driver' ;e={"{0:n0}" -f ($_.name)}},
@{n='Capacity (Gb)' ;e={"{0:n2}" -f ($_.size/1gb)}},
@{n='Free Space (Gb)';e={"{0:n2}" -f ($_.freespace/1gb)}},
@{n='Percentage Free';e={"{0:n2}%" -f ($_.freespace/$_.size*100)}}
}





$tableStart="<table style='boder:0px 0px 0px 0px;'><tr><th>Server Name</th><th>Volume Name</th><th>Driver</th>
<th>Capacity (Gb)</th><th>Free Space (Gb)</th><th>Percentage Free</th></tr>"

$allLines=""
for($i=0;$i -lt $results.Length;$i++){
     
     $servers=($results[$i] | select -ExpandProperty "Server Name"  )
     $volumes=($results[$i] | select -ExpandProperty "Volume Name" )
     $drives=($results[$i] | select -ExpandProperty "Driver" )
     $capac=($results[$i] | select -ExpandProperty "Capacity (Gb)" )
     $freeSpace=($results[$i] | select -ExpandProperty "Free Space (Gb)" )
     $percentage=($results[$i] | select -ExpandProperty "Percentage Free" )
     
     
     if(($i % 2) -ne 0){
         $beginning="<tr style='background-color:white;'>"
     }else{
         $beginning="<tr style='background-color:rgb(245,245,245);'>"
     }
     
     $bodyEl ="<td> " + $servers+ " </td>" 
     $bodyEl+="<td> " + $volumes + " </td>"
     $bodyEl+="<td style='text-align:center;'> " + $drives + " </td>"
     $bodyEl+="<td style='text-align:center;'> " + $capac + " </td>"
     $bodyEl+="<td style='text-align:center;'> " + $freeSpace + " </td>"
     $fr=[System.Double]::Parse($freeSpace)
     $cap=[System.Double]::Parse($capac)
     if((($fr/$cap)*100) -lt [System.Int32]::Parse($criticalThresholdSpace)){
         $bodyEl+= "<td style='color:red;font-weight:bold;text-align:center;'>"+$percentage +"</td>"
     }
     else{
         $bodyEl+="<td style='color:orange;text-align:center;'>"+$percentage +"</td>"
     }    
     $end="</tr>"
     $allLines+=$beginning+$bodyEl+$end
}
$tableBody=$allLines
$tableEnd="</table>"
$tableHtml=$tableStart+$tableBody+$tableEnd


$HTMLmessage = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PABmAG8AbgB0ACAAYwBvAGwAbwByAD0AIgAiAGIAbABhAGMAawAiACIAIABmAGEAYwBlAD0AIgAiAEEAcgBpAGEAbAAiACIAIABzAGkAegBlAD0AIgAiADMAIgAiAD4ADQAKADwAaAAxACAAcwB0AHkAbABlAD0AJwBmAG8AbgB0AC0AZgBhAG0AaQBsAHkAOgBhAHIAaQBhAGwAOwAnAD4APABiAD4ARABpAHMAawAgAFMAcABhAGMAZQAgAFMAdABvAHIAYQBnAGUAIABSAGUAcABvAHIAdAA8AC8AYgA+ADwALwBoADEAPgANAAoAPABwACAAcwB0AHkAbABlAD0AJwBmAG8AbgB0ADoAIAAuADgAZQBtACAAIgAiAEwAdQBjAGkAZABhACAARwByAGEAbgBkAGUAIgAiACwAIABUAGEAaABvAG0AYQAsACAAQQByAGkAYQBsACwAIABIAGUAbAB2AGUAdABpAGMAYQAsACAAcwBhAG4AcwAtAHMAZQByAGkAZgA7ACcAPgBUAGgAaQBzACAAcgBlAHAAbwByAHQAIAB3AGEAcwAgAGcAZQBuAGUAcgBhAHQAZQBkACAAYgBlAGMAYQB1AHMAZQAgAHQAaABlACAAZAByAGkAdgBlACgAcwApACAAbABpAHMAdABlAGQAIABiAGUAbABvAHcAIABoAGEAdgBlACAAbABlAHMAcwAgAHQAaABhAG4AIAAkAHcAYQByAG4AaQBuAGcAVABoAHIAZQBzAGgAbwBsAGQAUwBwAGEAYwBlACAAJQAgAGYAcgBlAGUAIABzAHAAYQBjAGUALgAgAEQAcgBpAHYAZQBzACAAYQBiAG8AdgBlACAAdABoAGkAcwAgAHQAaAByAGUAcwBoAG8AbABkACAAdwBpAGwAbAAgAG4AbwB0ACAAYgBlACAAbABpAHMAdABlAGQALgA8AC8AcAA+AA0ACgA8AGIAcgA+ADwAYgByAD4ADQAKADwAcwB0AHkAbABlACAAdAB5AHAAZQA9ACIAIgB0AGUAeAB0AC8AYwBzAHMAIgAiAD4AYgBvAGQAeQB7AGYAbwBuAHQAOgAgAC4AOABlAG0AIAAiACIATAB1AGMAaQBkAGEAIABHAHIAYQBuAGQAZQAiACIALAAgAFQAYQBoAG8AbQBhACwAIABBAHIAaQBhAGwALAAgAEgAZQBsAHYAZQB0AGkAYwBhACwAIABzAGEAbgBzAC0AcwBlAHIAaQBmADsAfQANAAoAbwBsAHsAbQBhAHIAZwBpAG4AOgAwADsAfQANAAoAdABhAGIAbABlAHsAdwBpAGQAdABoADoAOAAwACUAOwB9AA0ACgB0AGgAZQBhAGQAewB9AA0ACgB0AGgAZQBhAGQAIAB0AGgAewBmAG8AbgB0AC0AcwBpAHoAZQA6ADEAMgAwACUAOwB0AGUAeAB0AC0AYQBsAGkAZwBuADoAbABlAGYAdAA7AH0ADQAKAHQAaAB7AGIAbwByAGQAZQByAC0AYgBvAHQAdABvAG0AOgAyAHAAeAAgAHMAbwBsAGkAZAAgAHIAZwBiACgANwA5ACwAMQAyADkALAAxADgAOQApADsAYgBvAHIAZABlAHIALQB0AG8AcAA6ADIAcAB4ACAAcwBvAGwAaQBkACAAcgBnAGIAKAA3ADkALAAxADIAOQAsADEAOAA5ACkAOwBwAGEAZABkAGkAbgBnAC0AYgBvAHQAdABvAG0AOgAxADAAcAB4ADsAcABhAGQAZABpAG4AZwAtAHQAbwBwADoAMQAwAHAAeAA7AH0ADQAKAHQAcgB7AHAAYQBkAGQAaQBuAGcAOgAxADAAcAB4ACAAMQAwAHAAeAAgADEAMABwAHgAIAAxADAAcAB4ADsAYgBvAHIAZABlAHIAOgBuAG8AbgBlADsAfQANAAoAIwBtAGkAZABkAGwAZQB7AGIAYQBjAGsAZwByAG8AdQBuAGQALQBjAG8AbABvAHIAOgAjADkAMAAwADsAfQANAAoAPAAvAHMAdAB5AGwAZQA+AA0ACgA8AGIAbwBkAHkAIABCAEcAQwBPAEwATwBSAD0AIgAiAHcAaABpAHQAZQAiACIAPgANAAoAJAB0AGEAYgBsAGUASAB0AG0AbAANAAoAPAAvAGIAbwBkAHkAPgA=')))






$regexsubject = $HTMLmessage
$regex = [regex] '(?im)<td>'


if ($regex.IsMatch($regexsubject)) {
     send-mailmessage -from $emailFrom -to $mailto -subject $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAawAgAFMAcABhAGMAZQAgAEEAbABlAHIAdAAgAGYAbwByACAAJABjAG8AbQBwAHUAdABlAHIA'))) -BodyAsHTML -body $HTMLmessage -priority High -smtpServer $smtpServer
}