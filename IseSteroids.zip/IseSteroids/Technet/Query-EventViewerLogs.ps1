﻿##Query-EventViewerLogs
##**Parses saved Event Viewer logs based on the SQL query defined in the script body.

Begin{
	#Creating objects for Log Query
	${00001100111000000} = New-Object -COM MSUtil.LogQuery
	${01001100010111111} = New-Object -COM MSUtil.LogQuery.EventLogInputFormat
	${00011101110100000} = New-Object -COM MSUtil.LogQuery.CSVOutputFormat
	
	#This is the directory that contains the event log files. Collects the files and builds an array.
	${00001000000110011} = "<File_Location>"
	${10010111001100111} = ls ${00001000000110011}
	Foreach (${00000010000101101} in ${10010111001100111}){
		${00100101001111101} = [System.IO.Path]::GetExtension(${00000010000101101}).ToString()
		If (${00100101001111101} -eq ".evtx" -or ${00100101001111101} -eq ".evt"){
			${00011100010110001} = ${00000010000101101}.Name
			[Array]${01110101011011010} +=${00011100010110001}	
		}
	}
	# Gets the directory the script was executed from and creates a directory for output files.
	${00101111110011000} = (gl).Path
	If (!(Test-Path ${00101111110011000}\LogQuery)){
		ni -Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADAAMQAxADEAMQAxADEAMAAwADEAMQAwADAAMAB9AFwATABvAGcAUQB1AGUAcgB5AA=='))) -ItemType Directory -Force
	}
}
Process{
	#Builds and executes the query based on the variables defined above. Also the output path is defined.
	Foreach (${00011010001100010} in ${01110101011011010}){
		$Input = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAwADAAMQAwADAAMAAwADAAMAAxADEAMAAwADEAMQB9AFwAJAB7ADAAMAAwADEAMQAwADEAMAAwADAAMQAxADAAMAAwADEAMAB9AA==')))
		${10000000001001111} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADAAMAAxADAAMQAxADEAMQAxADEAMAAwADEAMQAwADAAMAB9AFwATABvAGcAUQB1AGUAcgB5AFwARQB2AGUAbgB0AEwAbwBnAFMAZQBhAHIAYwBoAF8AJAB7ADAAMAAwADEAMQAwADEAMAAwADAAMQAxADAAMAAwADEAMAB9AC4AYwBzAHYA')))
		${00111000000111111} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkAUwBFAEwARQBDAFQAIABUAGkAbQBlAEcAZQBuAGUAcgBhAHQAZQBkACwARQB2AGUAbgB0AEkARAAsAEUAdgBlAG4AdABUAHkAcABlACwARQB2AGUAbgB0AFQAeQBwAGUATgBhAG0AZQAsAEUAdgBlAG4AdABDAGEAdABlAGcAbwByAHkALABFAHYAZQBuAHQAQwBhAHQAZQBnAG8AcgB5AE4AYQBtAGUALABTAG8AdQByAGMAZQBOAGEAbQBlACwAUwB0AHIAaQBuAGcAcwAsAEMAbwBtAHAAdQB0AGUAcgBOAGEAbQBlACwAUwBJAEQALABNAGUAcwBzAGEAZwBlACAADQAKAAkACQAJAEkATgBUAE8AIAAnACQAewAxADAAMAAwADAAMAAwADAAMAAwADEAMAAwADEAMQAxADEAfQAnAAkADQAKAAkACQAJAEYAUgBPAE0AIAAnACQASQBuAHAAdQB0ACcAIAANAAoACQAJAAkAVwBIAEUAUgBFACAAVABPAF8ATABPAFcARQBSAEMAQQBTAEUAKABNAGUAcwBzAGEAZwBlACkAIABMAEkASwBFACAAJwAlAGEAcABwAGwAaQBjAGEAdABpAG8AbgBuAGEAbQBlACUAJwAnACAALwAqACAAQgBlACAAcwB1AHIAZQAgAHQAbwAgAHIAZQBwAGwAYQBjAGUAIAB0AGgAaQBzACAAdwBpAHQAaAAgAHQAaABlACAAYQBjAHQAdQBhAGwAIABuAGEAbQBlACAAbwBmACAAdABoAGUAIABhAHAAcABsAGkAYwBhAHQAaQBvAG4AIAAqAC8ADQAKAAkACQAJAE8AUgBEAEUAUgAgAEIAWQAgAFQAaQBtAGUARwBlAG4AZQByAGEAdABlAGQA')))
		${00001100111000000}.ExecuteBatch(${00111000000111111}, ${01001100010111111}, ${00011101110100000})
	}
}
End{
	#Closing parser objects
	rv -Name Parser -Force
	rv -Name InputType -Force
	rv -Name OutputType -Force
}