﻿<#
==================================================================================
DESCRIPTION    : Exchange Database and Storage Report
AUTHOR         : Luca Fabbri
VERSION HISTORY: 1.2 - Progress bar added
				 1.1 - Getting Volume information through WMI optimization
				 1.0 - Start
REQUIREMENTS   : PowerShell 2.0 at least, Exchange Management Shell, WMI Interface

==================================================================================
#>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true,Position=1)]
    [string[]]$ServerName
)
# Default Template
$appName = $MyInvocation.MyCommand.Name.Substring(0,$MyInvocation.MyCommand.Name.LastIndexOf("."))
$appPath = Split-Path $MyInvocation.MyCommand.Definition
$outPath = $env:temp
$outFile = $outPath + "\" + $appName + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBjAHMAdgA=')))
# Prepare output collection
$return = @()
# Initialize counter for progress bar
$counter = 0
# Convert Dates to WMI CIM dates
$Tc = [System.Management.ManagementDateTimeconverter]
$evtTimeStart =$Tc::ToDmtfDateTime((Get-Date).AddDays(-1).Date)
# Create two calculated properties for InsertionStrings values  
$evtDb = @{Name="Db";Expression={$_.InsertionStrings[1]}}
$evtFreeMB = @{Name=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAGUAZQBNAEIA')));Expression={[int]$_.InsertionStrings[0]}}
# Loop through Exchange Databases
$DBs = Get-MailboxDatabase -Server "$ServerName" | Sort-Object $_.EdbFilePath.PathName
ForEach ($Db in $DBs)
{
	# Increase counter for progress bar
	$counter++
	# Display progress bar
	Write-Progress -Activity $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAEQAYQB0AGEAYgBhAHMAZQAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgA='))) -Status "Processing Database $Db" -PercentComplete (100 * ($counter/@($DBs).count))
	$dbFilePath = $Db.EdbFilePath.PathName
	# Get DB volume information (both Logical Drive and Mount Point): Name, Capacity, Free Space	
	$path = $dbFilePath
	Do
	{
		$parent = $path -Replace $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WwBeAFwAXABdACoAJAA=')))
		$Volume = Get-WmiObject -Class Win32_Volume -ComputerName $ServerName -Filter ("Name = '" + $parent.Replace("\","\\") + "'")
		$path = $parent -Replace ".$"
	} While ($Volume -eq $null)
	# Get DBs file size information
	$DbFile = Get-WmiObject -Class CIM_LogicalFile -ComputerName $ServerName -Filter ("Name = '" + $dbFilePath.Replace("\","\\") + "'")
	# Count DB mailboxes
	$mailboxCount = Get-MailboxStatistics -Database $Db.Identity | Where-Object {$_.DisconnectDate -eq $null -and $_.ObjectClass -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGkAbABiAG8AeAA=')))} | Measure-Object
	# Count disconnected DB mailboxes
	$disconnectedMailboxCount = Get-MailboxStatistics -Database $Db.Identity | Where-Object {$_.DisconnectDate -ne $null} | Measure-Object
	# Get DB free space information from Application Events Log (Event ID 1221)
	$dbName = $Db.Identity.Parent.Name + "\" + $Db.Identity.Name
	$DbFreeSpace = Get-WMIObject Win32_NTLogEvent -ComputerName $ServerName -Filter `
	"LogFile = 'Application' AND EventCode = 1221 AND TimeWritten > '$evtTimeStart'" | `
	Where-Object {$_.InsertionStrings[1] -eq $dbName} | Select-Object $evtDb, $evtFreeMB -First 1 | Sort-Object TimeWritten, FreeMB –Unique –Descending
	$volumeCapacity = ($Volume.Capacity / 1GB)
	$volumeFreeSpace = ($Volume.FreeSpace / 1GB)
	$dbFreSpace = ($DbFreeSpace.FreeMB / 1024)
	$Obj = New-Object PSObject
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUATgBhAG0AZQA='))) -Value $Volume.Name
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUAQwBhAHAAYQBjAGkAdAB5ACgARwBCACkA'))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f $volumeCapacity)
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUARgByAGUAZQBTAHAAYQBjAGUAKABHAEIAKQA='))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f $volumeFreeSpace)
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUARgByAGUAZQAlAA=='))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($volumeFreeSpace / $volumeCapacity * 100))
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBvAGwAdQBtAGUAVABvAHQAYQBsAEYAcgBlAGUAKABHAEIAKQA='))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($volumeFreeSpace + $dbFreSpace))
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAXABTAHQAbwByAGEAZwBlAEcAcgBvAHUAcABcAEQAYQB0AGEAYgBhAHMAZQA='))) -Value $Db.Identity
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABiAEYAaQBsAGUAUwBpAHoAZQAoAEcAQgApAA=='))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f ($DbFile.FileSize / 1GB))
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABiAEYAcgBlAGUAUwBpAHoAZQAoAEcAQgApAA=='))) -Value ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAbgAyAH0A'))) -f $dbFreSpace)
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBNAGEAaQBsAGIAbwB4AEMAbwB1AG4AdAA='))) -Value $mailboxCount.Count
	$Obj | Add-Member NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAYwBvAG4AbgBlAGMAdABlAGQATQBhAGkAbABiAG8AeABDAG8AdQBuAHQA'))) -Value $disconnectedMailboxCount.Count
	$return += $Obj
}
Write-Progress -Activity $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAHQAdABpAG4AZwAgAEQAYQB0AGEAYgBhAHMAZQAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AcABsAGUAdABlAGQA'))) -Completed
# Export output to csv
$return | Export-Csv -Path $outFile -Delimiter ";" -Force -noTypeInformation -Encoding UTF8
Write-Output $return