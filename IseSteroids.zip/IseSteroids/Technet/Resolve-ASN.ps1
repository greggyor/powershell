﻿<#
.SYNOPSIS
This script takes as input hostnames or IP addresses, and returns information
on the autonomous system associated with the entity. It's a PowerShelly version 
of whois.

.DESCRIPTION
This script takes a hostname, resolves it to an IP address, and attempts to
identify the autonomous system on the Internet responsible for that address. If an
IP address is provided, we us that directly. We return some basic information on the AS
like its advertising prefix, locale, and organization.

This script relies on the IP-to-ASN mapping service provided by Team Cymru,
which provides fairly good ASN data through DNS. 

Proper whois would actually use a whois server and the whois protocol, 
but its much easier to use a DNS service.

.PARAMETER HostName
The hostname used to gather ASN information.

.PARAMETER IPAddress
The IP address used to gather ASN information

.PARAMETER IPv4Only
This parameter indicates that ASN information should be returned only for IPv4 addresses. By default a random address for the host name is used.

.PARAMETER IPv6Only
This parameter indicates that ASN information should be returned only for IPv6 addresses.By default a random address for the host name is used.

.INPUTS
None

.OUTPUTS
The script outputs a System.Object for each AS that is declared as an owner
of the specified host. 

.EXAMPLE
.\Resolve-ASN.ps1 bing.com

IPAddress   : 65.52.107.149
ASNumber    : 8075
ASPrefix    : 65.52.104.0/21
Locale      : US
Description : MICROSOFT-CORP---MSN-AS-BLOCK - Microsoft Corp

.EXAMPLE
Get-NetIPAddress -IPAddress 2001* | .\Resolve-ASN.ps1
IPAddress   : 2001:4898:0:fff:200:5efe:157.59.25.188
ASNumber    : 3598
ASPrefix    : 2001:4898::/32
Locale      : US
Description : MICROSOFT-CORP-AS - Microsoft Corp

.EXAMPLE
.\Resolve-ASN.ps1 xbox.com -IPv6Only
IPAddress   : 2a01:111:f009::3b03
ASNumber    : 8075
ASPrefix    : 2a01:111::/32
Locale      : GB
Description : MICROSOFT-CORP---MSN-AS-BLOCK - Microsoft Corp


.NOTES
Requires Windows 8 or later.

.LINK
The DNS service used for the script:
http://www.team-cymru.org/Services/ip-to-asn.html
The cmdlet that does all the hard work:
Resolve-DNSName
#>
param
(
        
    [Parameter(ParameterSetName="HostName",Mandatory=$True,
    ValueFromPipelineByPropertyName=$True , Position=0)]
    [string]$HostName = $null, 
    
    [Parameter(ParameterSetName="IPAddress", Mandatory=$True,
    ValueFromPipelineByPropertyName=$True)]
    [ipaddress]$IPAddress=$null,

    [Parameter(ParameterSetName="HostName", Mandatory=$false,
    ValueFromPipelineByPropertyName=$True)]
    [switch]$IPv4Only=$false,

    [Parameter(ParameterSetName="HostName", Mandatory=$false,
    ValueFromPipelineByPropertyName=$True)]
    [switch]$IPv6Only=$false
)

##Services we're getting the ASN information from.
${6}= ".origin.asn.cymru.com"
${4} = ".asn.cymru.com"

##Convert the supplied hostname into a set of IP addresses.      
if($IPAddress -eq $null)
{   
    write-debug "Hostname provided, will have to resolve to DNS name"
    try{
        if($IPv4Only)
            {${16} = Resolve-DnsName $HostName -Type  A -erroraction Stop}
        if($IPv6Only)
            {${16} = Resolve-DnsName $HostName -Type  AAAA -erroraction Stop}
        if(!($IPv4Only -or $IPv6Only))
            {${16} = Resolve-DnsName $HostName -Type  A_AAAA -erroraction Stop}

        }
    catch{
        throw "Could not resolve the provided hostname"
        exit
        }
    ${16} = ${16} | where {$_.IPAddress -ne $null}
    
    if (${16} -eq $null)
        {
            throw "No records found for the provided hostname"
            exit
        }
    else
        {
            $IPAddress = ${16}[0].IPAddress
        }

         write-debug "Hostname resolved"

}
            


${7} = $null 

##Check if its an IPv6 Address. If so, we need to reverse the characters of the IP address
if($IPAddress.AddressFamily -eq "InterNetworkV6")
{
    ${6}= "origin6.asn.cymru.com"
    ${15} = $IPAddress.IPAddressToString
    
    ##We're going to do some URI magic because it'll make our string conversions easier.
    ${14} = new-object -TypeName System.Uri -ArgumentList "http://[${15}]"
    ${13} = ${14}.DnsSafeHost
    ${13} = ${13}.ToCharArray()
    ${11} = ""
    foreach(${12} in ${13})
    {
        if(${12} -ne ":")
        {
            ${11} = ${11}.Insert(0,"${12}.")
        }
    }
    ${7} = ${11} 
        

}
else
{
    ##Little bit easier to do reverse DNS lookups with IPv4
    if(${7} -eq $null)
        {${7} = $IPAddress.ToString()}
    
    ${10} = ${7}.Split(".")
    ${8} = ""
    foreach (${9} in ${10})
    {
        ${8} = "." + ${8}.Insert(0,${9})
    }
    ${7} = ${8}.Substring(1)

}
##Resolve the name against the ASN-IP service
${3} = ${7} + ${6}
try{
        ${2} = Resolve-DnsName ${3}  -Type TXT -ErrorAction Stop
   }
    catch{
        throw "Could not find AS information for ${3}"
        exit
    }


##Each record represent an ASN. We're going to populate more information on each object before returning them.
##This loop also generates the objects we'll be returning
foreach (${5} in ${2})
{
    ${1} = New-Object System.Object
    ${1} | Add-Member -Type NoteProperty -Name IPAddress -Value  $IPAddress
    
    ${1} | Add-Member -Type NoteProperty -Name ASNumber -Value ${5}.Strings.Split("|")[0].Trim()
    ${1} | Add-Member -Type NoteProperty -Name ASPrefix -Value ${5}.Strings.Split("|")[1].Trim()
    ${1} | Add-Member -Type NoteProperty -Name Locale -Value ${5}.Strings.Split("|")[2].Trim()
    ${3} = "AS" +${1}.ASNumber + ${4}

    try{
            
        ${2} = Resolve-DnsName ${3}  -Type TXT 
       }
    catch{
        throw "Could not resolve detailed infromation for AS" +${1}.ASNumber 
        exit
    }
    
    ${1} | Add-Member -Type NoteProperty -Name Description -Value ${2}.Strings.Split("|")[4].Trim()
    ${1}
}

