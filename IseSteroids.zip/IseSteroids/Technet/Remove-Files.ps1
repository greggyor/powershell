﻿


[cmdletBinding(SupportsShouldProcess=$true)]
param(
	[Parameter(Position = 0, Mandatory = $true)]
	[ValidateScript({
		$vr = Test-Path $_
		if(!$vr){Write-Host "The provided path $_ is invalid!"}
		$vr
	})][String]$Path,
	[String][ValidatePattern("\.[a-z]{2,5}")]$Extension,	
	[Int]$KeepFiles,
	[ValidateScript({
		if($Date){$vr = $false; write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHIAYQBtAGUAdABlAHIAIABlAHIAcgBvAHIAIABzAGUAZQAgAGcAZQB0AC0AaABlAGwAcAAgAC4AXABSAGUAbQBvAHYAZQAtAEYAaQBsAGUAcwAuAHAAcwAxAA==')))}
		else{$vr = $true}
		$vr
	})][Int]$KeepDays,
	[ValidateScript({
		if($KeepDays){$vr = $false; write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHIAYQBtAGUAdABlAHIAIABlAHIAcgBvAHIAIABzAGUAZQAgAGcAZQB0AC0AaABlAGwAcAAgAC4AXABSAGUAbQBvAHYAZQAtAEYAaQBsAGUAcwAuAHAAcwAxAA==')))}
		else{$vr = $true}
		$vr
	})][DateTime]$Date,
	[int]$FileSize=0,
	[Switch]$Recurse
)



function f3
{
	param(
		[Parameter(Mandatory = $true)][DateTime]$TargetDate,
		[Parameter(Mandatory = $true)][Int]$Keep,
		[Parameter(Mandatory = $true)][Object[]]$Files
	)
	$Files = $Files | sort-object -Property PSParentPath,LastWriteTime -Descending | group -Property PSParentPath
	$FileList = @()
	foreach ($Group in $Files){
		$i=1
		Foreach ($item in $Group.Group){
			if($Item.LastWriteTime -lt $TargetDate -and $i -gt $Keep){
				$FileList += $Item
			}
			$i++
		}
	}
	return $FileList
}
function f2
{
	param(
		[Parameter(Mandatory = $true)][Int]$Keep,
		[Parameter(Mandatory = $true)][Object[]]$Files
	)
	
	$Files = $Files | sort-object -Property PSParentPath,LastWriteTime -Descending | group -Property PSParentPath | ? {$_.count -gt $KeepFiles}
	$FileList = @()
	foreach ($Group in $Files){
		$i=1	
		foreach ($Item in $Group.Group){
			if ($i -gt $Keep){
				$FileList += $Item
			}
			$i++
		}
	}
	return $FileList
}
function f1 
{
	foreach ($File in $Files2Delete){
		if($pscmdlet.ShouldProcess($File.FullName, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAIABGAGkAbABlAA=='))))){
			rd -LiteralPath $File.FullName
		}
	}
}




if ($Recurse){$RecOption = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQBSAGUAYwB1AHIAcwBlAA==')))}
if ($Extension){$ExtOption = "-Filter *$Extension"}
$strGetChild = "Get-ChildItem -Path `"$Path`" $RecOption $ExtOption | Where-Object {`$_ -is [System.IO.FileInfo]}"
$cbGetChild = [scriptblock]::Create($strGetChild)

$Files = @(icm -ScriptBlock $cbGetChild)
$Files = $Files | ? {$_.Length -ge $FileSize}

if($KeepDays){
	
	$Files2Delete = @(f3 -TargetDate ((Get-Date).AddDays(-$KeepDays)) -Files $Files -Keep $KeepFiles)
}
elseif($Date){
	
	$Files2Delete = f3 -TargetDate $Date -Files $Files -Keep $KeepFiles
}
else{
	$Files2Delete = f2 -Keep $KeepFiles -Files $Files
}
if ($Files2Delete -eq $null){
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAaABpAG4AZwAgAHQAbwAgAGQAZQBsAGUAdABlACEA')))
}
else {
	f1 $Files2Delete
}

