﻿# ------------------------------------------------------------------------
# NAME: Get-IPObjectDefaultEnabled.ps1
# AUTHOR: ed wilson, Microsoft
# DATE:2/18/2009
#
# KEYWORDS: Function, default value, type constraint,
# Get-WmiObject
# COMMENTS: This demonstrates a function that obtains
# information from WMI using the Win32_NetworkAdapterConfiguration
# class. It demonstrates use of a function with a type constraint
# a default value, and a single purpose function
#
# PowerShell Best Practices
# ------------------------------------------------------------------------
Function f1([bool]$IPEnabled = $true)
{
 gwmi -class Win32_NetworkAdapterConfiguration -Filter $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQAEUAbgBhAGIAbABlAGQAIAA9ACAAJABJAFAARQBuAGEAYgBsAGUAZAA=')))
} #end Get-IPObject

f1 -IPEnabled $False