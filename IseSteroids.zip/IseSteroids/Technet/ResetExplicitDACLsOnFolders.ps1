﻿
${7} = [System.Security.AccessControl.FileSystemRights]"ReadAndExecute"
${4} =[System.Security.AccessControl.AccessControlType]::Allow 

New-PSDrive -Name Z -PSProvider Filesystem -Root "\\SERVERNAME\DRIVELETTER$\ROOTPATH\"
Set-Location "z:\"
${10} = Get-ChildItem "z:\"
foreach (${1} in ${10}) {
	${2} = Get-Acl ${1}
	foreach (${9} in ${2}.access) {
		${6} = ${9}.InheritanceFlags
		${5} = ${9}.PropagationFlags
		${8} = ${9}.IdentityReference
		
		${3} = New-Object System.Security.AccessControl.FileSystemAccessRule `
    	(${8}, ${7}, ${6}, ${5}, ${4})
		${2}.SetAccessRule(${3})
		${1}.SetAccessControl(${2})
		
		}
	${1}.GetAccessControl() | fl
	}