﻿. $PSScriptRoot\ExternWin32API.ps1
$_readline = ipmo $PSScriptRoot\readline.psm1 -AsCustomObject
# save old prompt
$userPrompt = (get-item function:prompt).scriptblock;
# replace prompt with empty string - engine requires at least one char, so use backspace.
# hack courtesy of Lee Holmes (thanks!)
function global:prompt { "`b" }
function PSReadlinePrompt {
	& $userprompt
}
# hijack readline
function PSConsoleHostReadline {
 $_readline.Edit($function:PSReadlinePrompt , $true)
}
# restore global prompt on exit
$executioncontext.sessionstate.module.onremove = { set-item function:global:prompt $userPrompt -force }
