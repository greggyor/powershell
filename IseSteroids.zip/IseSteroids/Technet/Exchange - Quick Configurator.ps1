﻿












[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgA3ADcAYQA1AGMANQA2ADEAOQAzADQAZQAwADgAOQA='))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAHIAYQB3AGkAbgBnACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIAMAAzAGYANQBmADcAZgAxADEAZAA1ADAAYQAzAGEA'))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGMAbwByAGwAaQBiACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBYAG0AbAAsACAAVgBlAHIAcwBpAG8AbgA9ADIALgAwAC4AMAAuADAALAAgAEMAdQBsAHQAdQByAGUAPQBuAGUAdQB0AHIAYQBsACwAIABQAHUAYgBsAGkAYwBLAGUAeQBUAG8AawBlAG4APQBiADcANwBhADUAYwA1ADYAMQA5ADMANABlADAAOAA5AA=='))))
[void][Reflection.Assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGkAcgBlAGMAdABvAHIAeQBTAGUAcgB2AGkAYwBlAHMALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgAwADMAZgA1AGYANwBmADEAMQBkADUAMABhADMAYQA='))))





function Main {
	Param ([String]${f1})
	
	
	
	
	
	
	
	if((Call-MainForm_pff) -eq "OK")
	{
		
	}
	
	${global:221} = 0 
}










function Call-MainForm_pff
{

	
	
	
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgA3ADcAYQA1AGMANQA2ADEAOQAzADQAZQAwADgAOQA='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAHIAYQB3AGkAbgBnACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIAMAAzAGYANQBmADcAZgAxADEAZAA1ADAAYQAzAGEA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGMAbwByAGwAaQBiACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBYAG0AbAAsACAAVgBlAHIAcwBpAG8AbgA9ADIALgAwAC4AMAAuADAALAAgAEMAdQBsAHQAdQByAGUAPQBuAGUAdQB0AHIAYQBsACwAIABQAHUAYgBsAGkAYwBLAGUAeQBUAG8AawBlAG4APQBiADcANwBhADUAYwA1ADYAMQA5ADMANABlADAAOAA5AA=='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGkAcgBlAGMAdABvAHIAeQBTAGUAcgB2AGkAYwBlAHMALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgAwADMAZgA1AGYANwBmADEAMQBkADUAMABhADMAYQA='))))
	

	
	
	
	[System.Windows.Forms.Application]::EnableVisualStyles()
	${66} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQA=')))
	${170} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${168} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${167} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${165} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${164} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${162} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${161} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${159} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${158} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${156} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${155} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABhAGIAQwBvAG4AdAByAG8AbAA=')))
	${154} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABhAGIAUABhAGcAZQA=')))
	${153} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${151} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARwByAG8AdQBwAEIAbwB4AA==')))
	${150} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${149} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${148} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${147} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBvAG0AYgBvAEIAbwB4AA==')))
	${146} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${145} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${144} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBvAG0AYgBvAEIAbwB4AA==')))
	${142} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${141} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBvAG0AYgBvAEIAbwB4AA==')))
	${139} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${138} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${137} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${136} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${135} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${134} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARwByAG8AdQBwAEIAbwB4AA==')))
	${133} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${132} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${131} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${130} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${129} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${128} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${127} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARwByAG8AdQBwAEIAbwB4AA==')))
	${125} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${123} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${122} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${120} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${117} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${115} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${113} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${111} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${110} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${109} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${108} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${107} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${106} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${104} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${103} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${102} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${101} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${99} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${98} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABhAGIAUABhAGcAZQA=')))
	${97} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${61} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${96} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${95} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${93} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${92} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${91} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${90} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${89} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${88} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${87} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${86} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABlAHgAdABCAG8AeAA=')))
	${85} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATABhAGIAZQBsAA==')))
	${84} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQwBoAGUAYwBrAEIAbwB4AA==')))
	${82} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${81} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${79} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${77} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARwByAG8AdQBwAEIAbwB4AA==')))
	${76} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARABhAHQAYQBHAHIAaQBkAFYAaQBlAHcA')))
	${75} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AQgB1AHQAdABvAG4A')))
	${73} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARQByAHIAbwByAFAAcgBvAHYAaQBkAGUAcgA=')))
	${208} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAGwAZABlAHIAQgByAG8AdwBzAGUAcgBEAGkAYQBsAG8AZwA=')))
	${72} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATwBwAGUAbgBGAGkAbABlAEQAaQBhAGwAbwBnAA==')))
	${71} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ATwBwAGUAbgBGAGkAbABlAEQAaQBhAGwAbwBnAA==')))
	${70} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARQByAHIAbwByAFAAcgBvAHYAaQBkAGUAcgA=')))
	${69} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARQByAHIAbwByAFAAcgBvAHYAaQBkAGUAcgA=')))
	${68} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARQByAHIAbwByAFAAcgBvAHYAaQBkAGUAcgA=')))
	${67} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4AVABvAG8AbABUAGkAcAA=')))
	${5} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQBXAGkAbgBkAG8AdwBTAHQAYQB0AGUA')))
	

	
	
	
	
	
	${171}={
	
	
	}
	
	
	function Load-DataGridView
	{
		
		Param (
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.DataGridView]$DataGridView,
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			$Item,
		    [Parameter(Mandatory=$false)]
			[string]$DataMember
		)
		$DataGridView.SuspendLayout()
		$DataGridView.DataMember = $DataMember
		
		if ($Item -is [System.ComponentModel.IListSource]`
		-or $Item -is [System.ComponentModel.IBindingList] -or $Item -is [System.ComponentModel.IBindingListView] )
		{
			$DataGridView.DataSource = $Item
		}
		else
		{
			${220} = New-Object System.Collections.ArrayList
			
			if ($Item -is [System.Collections.IList])
			{
				${220}.AddRange($Item)
			}
			else
			{	
				${220}.Add($Item)	
			}
			$DataGridView.DataSource = ${220}
		}
		
		$DataGridView.ResumeLayout()
	}
	
	function Load-ComboBox 
	{
	
		Param (
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.ComboBox]${f5},
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			$Items,
		    [Parameter(Mandatory=$false)]
			[string]$DisplayMember,
			[switch]$Append
		)
		
		if(-not $Append)
		{
			${f5}.Items.Clear()	
		}
		
		if($Items -is [Object[]])
		{
			${f5}.Items.AddRange($Items)
		}
		elseif ($Items -is [Array])
		{
			${f5}.BeginUpdate()
			foreach(${219} in $Items)
			{
				${f5}.Items.Add(${219})	
			}
			${f5}.EndUpdate()
		}
		else
		{
			${f5}.Items.Add($Items)	
		}
	
		${f5}.DisplayMember = $DisplayMember	
	}
	
	function Load-ListBox 
	{
	
		Param (
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			[System.Windows.Forms.ListBox]$listBox,
			[ValidateNotNull()]
			[Parameter(Mandatory=$true)]
			$Items,
		    [Parameter(Mandatory=$false)]
			[string]$DisplayMember,
			[switch]$Append
		)
		
		if(-not $Append)
		{
			$listBox.Items.Clear()	
		}
		
		if($Items -is [System.Windows.Forms.ListBox+ObjectCollection])
		{
			$listBox.Items.AddRange($Items)
		}
		elseif ($Items -is [Array])
		{
			$listBox.BeginUpdate()
			foreach(${219} in $Items)
			{
				$listBox.Items.Add(${219})
			}
			$listBox.EndUpdate()
		}
		else
		{
			$listBox.Items.Add($Items)	
		}
	
		$listBox.DisplayMember = $DisplayMember	
	}
	
	
	${218}={
	
		if(${72}.ShowDialog() -eq 'OK')
		{
			$txtOutputFile.Text = ${72}.FileName
		}
	}
	
	
	${217}=[System.Windows.Forms.NavigateEventHandler]{
	
	
		${76}.Row
	}
	
	${152}={
		if (${144}.Text -and ${141}.Text -and ${147}.Text)
		{
			${216} = New-Object PSObject
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Value ${146}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgAFYAZQByAHMAaQBvAG4A'))) -Value ${147}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBvAGwAZQA='))) -Value ${144}.Text
	        ${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AYQBsACAARABvAG0AYQBpAG4A'))) -Value ${149}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAVgBlAHIAcwBpAG8AbgA='))) -Value ${141}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQA='))) -Value ${148}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGcAaQBvAG4A'))) -Value ${145}.Text
			${216} | Add-Member Noteproperty -Name "IP" -Value ${113}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQACAAUwB1AGIAbgBlAHQA'))) -Value ${117}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQACAARwBhAHQAZQB3AGEAeQA='))) -Value ${120}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAGYAYQBjAGUAIABOAGEAbQBlAA=='))) -Value ${99}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBMAEIAIABvAHIAIABEAEEARwAgAEkAUAA='))) -Value ${125}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABBAEcAIABSAGUAcABsAGkAYwBhAHQAaQBvAG4A'))) -Value ${101}.Checked		
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AZQB0ACAARgBhAGMAaQBuAGcA'))) -Value ${110}.Checked
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBMAEIA'))) -Value ${106}.Checked
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB1AHQAbwBkAGkAcwBjAG8AdgBlAHIAIABVAFIATAA='))) -Value ${132}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMAIABVAFIATAA='))) -Value ${131}.Text
	        ${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAHIAYQB5AEQAQQBHACAAVQBSAEwA'))) -Value ${133}.Text
			${216} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBTAEwAIABPAGYAZgBsAG8AYQBkAA=='))) -Value ${122}.Checked
			${57}+=${216}
			${65} = ${57} | Out-DataTable
			${76}.DataSource = ${65}
			${76}.Refresh
		}
		Else
		{
			
			[void][System.Windows.Forms.MessageBox]::Show($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAHMAcwBpAG4AZwAgAHMAbwBtAGUAIAByAGUAcQB1AGkAcgBlAGQAIABpAG4AZgBvACAAYgB1AGIALAAgAHQAcgB5ACAAYQBnAGEAaQBuAC4A'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHIAcgB5AA=='))))
		}
	}
	
	${74}={
		${215} = ${76}.CurrentRow.Index
		if (${57}.Count -le 1)
		{
			${57} = @()
		}
		else
		{
			${57} = ${57} | Where-Object {$_ -ne ${57}[${215}]}
		
		}
		${65} = ${57} | Out-DataTable
		${76}.DataSource = ${65}
		${76}.Refresh
		
	}
	
	${80}={
	    ${31} = ${88}.Checked
	    ${32} = ${86}.Text
	    ${35} = ${90}.Checked
	    ${21} = ${92}.Checked
	    ${18} = ${95}.Checked
	    ${17} = ${61}.Text
		If (${156})
		{
			Sort-ExchangeServers
			${214} = . Generate-Preqs
			${212} = . Generate-CASConfiguration
			[string]${213} = ${156}.Text		
			Out-File -FilePath $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADIAMQAzAH0AXABnAGUAbgBlAHIAYQB0AGUALQBwAHIAZQByAGUAcQBzAC4AcABzADEA'))) -Force -InputObject ${214} -Width 200 -Encoding ascii
			Out-File -FilePath $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADIAMQAzAH0AXABnAGUAbgBlAHIAYQB0AGUALQBoAHUAYgBjAGEAcwByAG8AbABlAHMALgBwAHMAMQA='))) -Force -InputObject ${212} -Width 200 -Encoding ascii
		}
		
		Else
		{
			
			[void][System.Windows.Forms.MessageBox]::Show($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBvAHIAcgB5ACwAIABuAG8AIABmAGkAbABlACAAdwBhAHMAIABzAHAAZQBjAGkAZgBpAGUAZAAgAGYAbwByACAAbwB1AHQAcAB1AHQA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGUAcgBlACcAcwAgAHQAaABlACAAbwB1AHQAcAB1AHQAIABtAGEAbgA/AA=='))))
		}
	}
	
	${83}={
		if (${84}.Checked)
		{
			${82}.Enabled = $true
		}
		else
		{
			${82}.Enabled = $false
		}
	}
	
	${143}={
		switch (${144}.Text) {
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABVAEIALwBDAEEAUwA='))) {
				
				${122}.Enabled = $true
				${110}.Enabled = $true
				${106}.Enabled = $true
				${131}.Enabled = $true
				${133}.Enabled = $true
				${132}.Enabled = $true
				${101}.Enabled = $false
				
				
				${101}.Checked = $false
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlAA=='))) {
				
				${101}.Enabled = $true
				${122}.Enabled = $false
				${110}.Enabled = $false
				${106}.Enabled = $false
				${131}.Enabled = $false
				${133}.Enabled = $true
				${132}.Enabled = $false
				${125}.Enabled = $true
	            
				
				${110}.Checked = $false
				${106}.Checked = $false
				${122}.Checked = $false			
				${131}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${132}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGEAdQB0AG8AZABpAHMAYwBvAHYAZQByAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${133}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGQAYQBnADEALgBjAG8AbgB0AG8AcwBvAC4AYwBvAG0AKQA=')))
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBkAGcAZQA='))) {
				
				${122}.Enabled = $false
				${110}.Enabled = $false
				${106}.Enabled = $false
				${131}.Enabled = $false
				${133}.Enabled = $false
				${132}.Enabled = $false
				${101}.Enabled = $false
				
				
				${110}.Checked = $false
				${106}.Checked = $false
				${122}.Checked = $false
				${101}.Checked = $false
				${131}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${132}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGEAdQB0AG8AZABpAHMAYwBvAHYAZQByAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${133}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAG8AbgB0AC0ARQBuAGQA'))) {
				
				${101}.Enabled = $false
	
				
				${110}.Checked = $false
				${106}.Checked = $false
				${122}.Checked = $false
				${101}.Checked = $false
				${131}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${132}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGEAdQB0AG8AZABpAHMAYwBvAHYAZQByAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${133}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
	
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawAtAEUAbgBkAA=='))) {
				
				${101}.Checked = $false
				${122}.Enabled = $false
				${110}.Enabled = $false
				${106}.Enabled = $false
				${131}.Enabled = $false
				${133}.Enabled = $false
				${132}.Enabled = $false
				${101}.Enabled = $false
	            ${125}.Enabled = $false
				
				
				${110}.Checked = $false
				${106}.Checked = $false
				${122}.Checked = $false
				${101}.Checked = $false
				${131}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${132}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGEAdQB0AG8AZABpAHMAYwBvAHYAZQByAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
				${133}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMA'))) {
				
				${101}.Checked = $false
	            ${125}.Enabled = $false
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SAB1AGIALwBUAHIAYQBuAHMAcABvAHIAdAAvAEQAYQB0AGEAYgBhAHMAZQA='))) {
				${101}.Enabled = $true
				${122}.Enabled = $false
				${110}.Enabled = $false
				${106}.Enabled = $false
				${131}.Enabled = $false
				${133}.Enabled = $true
				${132}.Enabled = $false
	            ${125}.Enabled = $true
			}
	        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMALwBIAHUAYgAvAFQAcgBhAG4AcwBwAG8AcgB0AC8ARABhAHQAYQBiAGEAcwBlAA=='))) {
				${101}.Enabled = $true
				${122}.Enabled = $true
				${110}.Enabled = $true
				${106}.Enabled = $false
				${131}.Enabled = $true
				${133}.Enabled = $true
				${132}.Enabled = $true
	            ${125}.Enabled = $true
			}
			default {
				
				${122}.Enabled = $false
				${110}.Enabled = $false
				${106}.Enabled = $false
				${131}.Enabled = $false
				${133}.Enabled = $false
				${132}.Enabled = $false
				${101}.Enabled = $false
			}
		}
	}
	
	${211}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${113}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${73}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${210}={
		
		${73}.SetError($this, "");	
	}
	
	function Validate-IsIP ([string] ${f4})
	{
			
		
		
		
		try
		{
			return ([System.Net.IPAddress]::Parse(${f4}) -ne $null)
		}
		catch
		{ }
		
		return $false	
	}
	
	${114}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${113}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${73}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${112}={
		
		${73}.SetError($this, "");	
	}
	${209}={
	
		if(${71}.ShowDialog() -eq 'OK')
		{
			${159}.Text = ${71}.FileName
		}
	}
	
	${157}={
		if(${208}.ShowDialog() -eq 'OK')
		{
			${156}.Text = ${208}.SelectedPath
		}
	}
	
	${160}={
	
		if(${72}.ShowDialog() -eq 'OK')
		{
			${159}.Text = ${72}.FileName
		}
	}
	
	${166}={
	
		if(${71}.ShowDialog() -eq 'OK')
		{
			${165}.Text = ${71}.FileName
		}
	}
	
	${163}={
		if (${159}.Text)
		{
			${57} | Export-Csv -NoTypeInformation -Path ${159}.Text
		}
		Else
		{
			
			[void][System.Windows.Forms.MessageBox]::Show($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAGUAZAAgAGEAIABmAGkAbABlAG4AYQBtAGUA'))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGEAdAAgAHQAaABlACAAaABlAGMAawA/AA=='))))
		}
	}
	
	${169}={
		if (${165}.Text)
		{
			${57} = Import-Csv -Path ${165}.Text
			${65} = ${57} | Out-DataTable
			${76}.DataSource = ${65}
			${76}.Refresh
		}
		Else
		{
			
			[void][System.Windows.Forms.MessageBox]::Show($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAGUAZAAgAGEAIABmAGkAbABlACAAdABvACAAbABvAGEAZAA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SAB1AGgAPwA='))))
		}
	}
	
	${78}={
		${66}.Close()	
	}
	
	
	${140}={
			${144}.Enabled = $true		
			${122}.Enabled = $false
			${110}.Enabled = $false
			${106}.Enabled = $false
			${131}.Enabled = $false
			${133}.Enabled = $false
			${132}.Enabled = $false
			${101}.Enabled = $false
			switch (${141}.Text) 
	        {
	    		$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAAMwA='))) 
	            {
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAG8AbgB0AC0ARQBuAGQA')))
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawAtAEUAbgBkAA=='))) -Append
	    		}
	    		$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAANwA='))) 
	            {
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgByAG8AbgB0AC0ARQBuAGQA')))
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgBhAGMAawAtAEUAbgBkAA=='))) -Append
	    		}
	    		$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMAA='))) 
	            {
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABVAEIALwBDAEEAUwA=')))
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlAA=='))) -Append
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBkAGcAZQA='))) -Append
	                Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMALwBIAHUAYgAvAFQAcgBhAG4AcwBwAG8AcgB0AC8ARABhAHQAYQBiAGEAcwBlAA=='))) -Append
	    		}
	    		$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMgA='))) 
	            {
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMA')))
	    			Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABVAEIALwBUAHIAYQBuAHMAcABvAHIAdAAvAEQAYQB0AGEAYgBhAHMAZQA='))) -Append
	                Load-ComboBox ${144} $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMALwBIAHUAYgAvAFQAcgBhAG4AcwBwAG8AcgB0AC8ARABhAHQAYQBiAGEAcwBlAA=='))) -Append
	    		}
	    		default 
	    		{
	    		
	    		}
		}	
	}
	
	
	${207}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${117}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${70}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${206}={
		
		${70}.SetError($this, "");	
	}
	
	${205}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${117}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${70}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${204}={
		
		${70}.SetError($this, "");	
	}
	
	${118}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${117}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${70}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${116}={
		
		${70}.SetError($this, "");	
	}
	
	
	${121}=[System.ComponentModel.CancelEventHandler]{
	
	
		${201} = -not (Validate-IsIP ${120}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${69}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${119}={
		
		${69}.SetError($this, "");	
	}
	
	${203}=[System.ComponentModel.CancelEventHandler]{
	
		
		${201} = -not (Validate-IsIP ${125}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${68}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${202}={
		
		${68}.SetError($this, "");	
	}
	
	
	${126}=[System.ComponentModel.CancelEventHandler]{
	
		
		${201} = -not (Validate-IsIP ${125}.Text)
	
		if(${201} -eq $true)
		{
			$_.Cancel = $true
			${68}.SetError($this, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHYAYQBsAGkAZAAgAEkAUAAgAGEAZABkAHIAZQBzAHMA'))));
		}
	}
	
	${124}={
		
		${68}.SetError($this, "");	
	}
	
	${100}=
	{
		If (${101}.Checked)
		{
			${125}.Enabled = $false
		}
		Else
		{
			${125}.Enabled = $true
		}
	}
	
	${105}={
		If (${106}.Checked)
		{
			${125}.Enabled = $true
	        ${133}.Enabled = $true
		}
		Else
		{
			${125}.Enabled = $false
	        ${133}.Enabled = $false
		}	
	}
	
	${94}={
		If (${95}.Checked)
		{
			${61}.Enabled = $false        
		}
		Else
		{
			${61}.Enabled = $true
		}
		
	}
		
	
	
	
	
	${4}=
	{
		
		${66}.WindowState = ${5}
	}
	
	${2}=
	{
		
		${script:200} = ${165}.Text
		${script:199} = ${159}.Text
		${script:198} = ${156}.Text
		${script:197} = ${149}.Text
		${script:196} = ${148}.Text
		${script:195} = ${147}.Text
		${script:194} = ${146}.Text
		${script:193} = ${145}.Text
		${script:192} = ${144}.Text
		${script:191} = ${141}.Text
		${script:190} = ${133}.Text
		${script:189} = ${132}.Text
		${script:188} = ${131}.Text
		${script:187} = ${125}.Text
		${script:186} = ${122}.Checked
		${script:185} = ${120}.Text
		${script:184} = ${117}.Text
		${script:183} = ${113}.Text
		${script:182} = ${110}.Checked
		${script:181} = ${106}.Checked
		${script:180} = ${101}.Checked
		${script:179} = ${99}.Text
		${script:178} = ${61}.Text
		${script:177} = ${95}.Checked
		${script:176} = ${92}.Checked
		${script:175} = ${90}.Checked
		${script:174} = ${88}.Checked
		${script:173} = ${86}.Text
		${script:172} = ${84}.Checked
	}

	
	${3}=
	{
		
		try
		{
			${170}.remove_Click(${169})
			${167}.remove_Click(${166})
			${164}.remove_Click(${163})
			${161}.remove_Click(${160})
			${158}.remove_Click(${157})
			${153}.remove_Click(${152})
			${144}.remove_SelectedValueChanged(${143})
			${141}.remove_SelectedIndexChanged(${140})
			${125}.remove_Validating(${126})
			${125}.remove_Validated(${124})
			${120}.remove_Validating(${121})
			${120}.remove_Validated(${119})
			${117}.remove_Validating(${118})
			${117}.remove_Validated(${116})
			${113}.remove_Validating(${114})
			${113}.remove_Validated(${112})
			${106}.remove_CheckedChanged(${105})
			${101}.remove_CheckedChanged(${100})
			${95}.remove_CheckedChanged(${94})
			${84}.remove_CheckedChanged(${83})
			${81}.remove_Click(${80})
			${79}.remove_Click(${78})
			${75}.remove_Click(${74})
			${66}.remove_Load(${171})
			${66}.remove_Load(${4})
			${66}.remove_Closing(${2})
			${66}.remove_FormClosed(${3})
		}
		catch [Exception]
		{ }
	}
	

	
	
	
	
	
	
	${66}.Controls.Add(${170})
	${66}.Controls.Add(${168})
	${66}.Controls.Add(${167})
	${66}.Controls.Add(${165})
	${66}.Controls.Add(${164})
	${66}.Controls.Add(${162})
	${66}.Controls.Add(${161})
	${66}.Controls.Add(${159})
	${66}.Controls.Add(${158})
	${66}.Controls.Add(${156})
	${66}.Controls.Add(${155})
	${66}.Controls.Add(${85})
	${66}.Controls.Add(${84})
	${66}.Controls.Add(${82})
	${66}.Controls.Add(${81})
	${66}.Controls.Add(${79})
	${66}.Controls.Add(${77})
	${66}.ClientSize = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADQAMAAsACAANAA1ADMA')))
	${66}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgByAG0ATQBhAGkAbgA=')))
	${66}.StartPosition = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBlAG4AdABlAHIAUwBjAHIAZQBlAG4A')))
	${66}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAUQB1AGkAYwBrACAAQwBvAG4AZgBpAGcAdQByAGEAdABvAHIAIAAoAGEAbABwAGgAYQApAA==')))
	${66}.add_Load(${171})
	
	
	
	${170}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA0ADcALAAgADMAMwAxAA==')))
	${170}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4ATABvAGEAZAA=')))
	${170}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${170}.TabIndex = 36
	${170}.TabStop = $False
	${170}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZAA=')))
	${170}.UseVisualStyleBackColor = $True
	${170}.add_Click(${169})
	
	
	
	${168}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${168}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzADcALAAgADMAMwA2AA==')))
	${168}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEwAbwBhAGQAQwBvAG4AZgBpAGcA')))
	${168}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADUA')))
	${168}.TabIndex = 35
	${168}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGEAZAAgAEMAbwBuAGYAaQBnADoA')))
	
	
	
	${167}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ADMALAAgADMAMwAxAA==')))
	${167}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB1AHQAdABvAG4AQgByAG8AdwBzAGUAMgA=')))
	${167}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwACwAIAAyADMA')))
	${167}.TabIndex = 1
	${167}.TabStop = $False
	${167}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
	${167}.UseVisualStyleBackColor = $True
	${167}.add_Click(${166})
	
	
	
	${165}.AutoCompleteMode = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGcAZwBlAHMAdABBAHAAcABlAG4AZAA=')))
	${165}.AutoCompleteSource = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQBTAHkAcwB0AGUAbQA=')))
	${165}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAzADIALAAgADMAMwAzAA==')))
	${165}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAHgAdABiAG8AeABMAG8AYQBkAA==')))
	${165}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA1ADUALAAgADIAMAA=')))
	${165}.TabIndex = 0
	${165}.TabStop = $False
	
	
	
	${164}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA0ADcALAAgADMAMAA1AA==')))
	${164}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4AUwBhAHYAZQA=')))
	${164}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${164}.TabIndex = 34
	${164}.TabStop = $False
	${164}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBhAHYAZQA=')))
	${164}.UseVisualStyleBackColor = $True
	${164}.add_Click(${163})
	
	
	
	${162}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${162}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzADcALAAgADMAMQAwAA==')))
	${162}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFMAYQB2AGUAQwBvAG4AZgBpAGcA')))
	${162}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADUA')))
	${162}.TabIndex = 33
	${162}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBhAHYAZQAgAEMAbwBuAGYAaQBnADoA')))
	
	
	
	${161}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ADMALAAgADMAMAA1AA==')))
	${161}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB1AHQAdABvAG4AQgByAG8AdwBzAGUA')))
	${161}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwACwAIAAyADMA')))
	${161}.TabIndex = 19
	${161}.TabStop = $False
	${161}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
	${161}.UseVisualStyleBackColor = $True
	${161}.add_Click(${160})
	
	
	
	${159}.AutoCompleteMode = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGcAZwBlAHMAdABBAHAAcABlAG4AZAA=')))
	${159}.AutoCompleteSource = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQBTAHkAcwB0AGUAbQA=')))
	${159}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAzADIALAAgADMAMAA3AA==')))
	${159}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAHgAdABiAG8AeABTAGEAdgBlAA==')))
	${159}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA1ADUALAAgADIAMAA=')))
	${159}.TabIndex = 0
	${159}.TabStop = $False
	
	
	
	${158}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ADMALAAgADIANwA5AA==')))
	${158}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB1AHQAdABvAG4AQgByAG8AdwBzAGUARgBvAGwAZABlAHIA')))
	${158}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwACwAIAAyADMA')))
	${158}.TabIndex = 18
	${158}.TabStop = $False
	${158}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgAuAC4A')))
	${158}.UseVisualStyleBackColor = $True
	${158}.add_Click(${157})
	
	
	
	${156}.AutoCompleteMode = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGcAZwBlAHMAdABBAHAAcABlAG4AZAA=')))
	${156}.AutoCompleteSource = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQBTAHkAcwB0AGUAbQBEAGkAcgBlAGMAdABvAHIAaQBlAHMA')))
	${156}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAzADIALAAgADIAOAAxAA==')))
	${156}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQATwB1AHQAcAB1AHQARABpAHIA')))
	${156}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA1ADUALAAgADIAMAA=')))
	${156}.TabIndex = 3
	${156}.TabStop = $False
	
	
	
	${155}.Controls.Add(${154})
	${155}.Controls.Add(${98})
	${155}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyACwAIAAxADIA')))
	${155}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABhAGIAYwBvAG4AdAByAG8AbAAxAA==')))
	${155}.SelectedIndex = 0
	${155}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAwADEALAAgADQAMwA4AA==')))
	${155}.TabIndex = 0
	${155}.TabStop = $False
	
	
	
	${154}.Controls.Add(${153})
	${154}.Controls.Add(${151})
	${154}.Controls.Add(${134})
	${154}.Controls.Add(${127})
	${154}.BackColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGkAdABlAFMAbQBvAGsAZQA=')))
	${154}.BorderStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAHgAZQBkAFMAaQBuAGcAbABlAA==')))
	${154}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAsACAAMgAyAA==')))
	${154}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABhAGIAcABhAGcAZQAxAA==')))
	${154}.Padding = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAsACAAMwAsACAAMwAsACAAMwA=')))
	${154}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA5ADMALAAgADQAMQAyAA==')))
	${154}.TabIndex = 0
	${154}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAIABTAGUAcgB2AGUAcgBzAA==')))
	
	
	
	${153}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${153}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwA5ADYALAAgADMAOAA1AA==')))
	${153}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4AQQBkAGQA')))
	${153}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${153}.TabIndex = 3
	${153}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQA')))
	${153}.UseVisualStyleBackColor = $True
	${153}.add_Click(${152})
	
	
	
	${151}.Controls.Add(${150})
	${151}.Controls.Add(${149})
	${151}.Controls.Add(${148})
	${151}.Controls.Add(${147})
	${151}.Controls.Add(${146})
	${151}.Controls.Add(${145})
	${151}.Controls.Add(${144})
	${151}.Controls.Add(${142})
	${151}.Controls.Add(${141})
	${151}.Controls.Add(${139})
	${151}.Controls.Add(${138})
	${151}.Controls.Add(${137})
	${151}.Controls.Add(${136})
	${151}.Controls.Add(${135})
	${151}.FlatStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAHAAdQBwAA==')))
	${151}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AVQBuAGQAZQByAGwAaQBuAGUA')))
	${151}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAMQAwAA==')))
	${151}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAG8AdQBwAGIAbwB4AEcAZQBuAGUAcgBhAGwA')))
	${151}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA2ADgALAAgADEAMQA4AA==')))
	${151}.TabIndex = 0
	${151}.TabStop = $False
	${151}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAG4AZQByAGEAbAA=')))
	
	
	
	${150}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${150}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAsACAAOQAzAA==')))
	${150}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEkAbgB0AGUAcgBuAGEAbABEAG8AbQBhAGkAbgA=')))
	${150}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAxADgALAAgADEANwA=')))
	${150}.TabIndex = 26
	${150}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AYQBsACAARABvAG0AYQBpAG4AOgA=')))
	
	
	
	${149}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${149}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADIALAAgADkAMAA=')))
	${149}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQASQBuAHQAZQByAG4AYQBsAEQAbwBtAGEAaQBuAA==')))
	${149}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA0ADkALAAgADIAMAA=')))
	${149}.TabIndex = 6
	${149}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGMAbwBuAHQAbwBzAG8ALgBsAG8AYwBhAGwAKQA=')))
	${67}.SetToolTip(${149}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAGkAbQBhAHIAaQBsAHkAIAB1AHMAZQBkACAAZgBvAHIAIABFAFcAUwAgAE4ATABCACAAYgB5AHAAYQBzAHMAIAB1AHIAbAAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4ALgA='))))
	
	
	
	${148}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${148}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADIALAAgADMANgA=')))
	${148}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAUwBpAHQAZQBOAGEAbQBlAA==')))
	${148}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${148}.TabIndex = 2
	${148}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAEQAZQBmAGEAdQBsAHQALQBGAGkAcgBzAHQALQBTAGkAdABlAC0ATgBhAG0AZQApAA==')))
	${67}.SetToolTip(${148}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAZAAgAHQAbwAgAGQAZQB0AGUAcgBtAGkAbgBlACAAbgBhAG0AaQBuAGcAIABhAG4AZAAgAGQAZQBwAGwAbwB5AG0AZQBuAHQAIABvAGYAIABDAEEAUwAgAGEAcgByAGEAeQBzACAADQAKACgAbwBuAGUAIABwAGUAcgAgAHMAaQB0AGUAIABpAHMAIABiAGUAcwB0ACAAcAByAGEAYwB0AGkAYwBlACAAaQBuACAAMgAwADEAMAAsACAAbgBvAHQAIAByAGUAYQBsAGwAeQAgAGEAcwAgAGkAbQBwAG8AcgB0AGEAbgB0ACAAaQBuACAAMgAwADEAMgApAC4AIAANAAoAVABoAGkAcwAgAG0AYQB5ACAAYgBlACAAdQBzAGUAZAAgAGwAYQB0AGUAcgAgAHMAbwAgAHkAbwB1ACAAbQBhAHkAIABhAHMAIAB3AGUAbABsACAAZgBpAGwAbAAgAHQAaABpAHMAIABvAHUAdAAgAGEAYwBjAHUAcgBhAHQAZQBsAHkALgA='))))
	
	
	
	${147}.DropDownStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAByAG8AcABEAG8AdwBuAEwAaQBzAHQA')))
	${147}.FormattingEnabled = $True
	[void]${147}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgADIAMAAwADgAIABSADIA'))))
	[void]${147}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgADIAMAAxADIA'))))
	${147}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAzADAALAAgADEAMgA=')))
	${147}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AYgBvAE8AUwA=')))
	${147}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADAALAAgADIAMQA=')))
	${147}.TabIndex = 1
	
	
	
	${146}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${146}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADIALAAgADEAMgA=')))
	${146}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAUwBlAHIAdgBlAHIATgBhAG0AZQA=')))
	${146}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA0ADkALAAgADIAMAA=')))
	${146}.TabIndex = 0
	${146}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAEMAQQBTADEAKQA=')))
	${67}.SetToolTip(${146}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHQAQgBJAE8AUwAgACgAbgBvAG4ALQBGAFEARABOACkAIABuAGEAbQBlACAAbwBmACAAdABoAGUAIABzAGUAcgB2AGUAcgAuAA=='))))
	
	
	
	${145}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${145}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAzADAALAAgADMAOQA=')))
	${145}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAUgBlAGcAaQBvAG4A')))
	${145}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADAALAAgADIAMAA=')))
	${145}.TabIndex = 3
	${145}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAFUAUwApAA==')))
	${67}.SetToolTip(${145}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAZAAgAGYAbwByACAAZABvAGMAdQBtAGUAbgB0AGEAdABpAG8AbgAgAHAAdQByAHAAbwBzAGUAcwAgAG8AbgBsAHkAIABjAHUAcgByAGUAbgB0AGwAeQAuAA=='))))
	
	
	
	${144}.DropDownStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAByAG8AcABEAG8AdwBuAEwAaQBzAHQA')))
	${144}.Enabled = $False
	${144}.FormattingEnabled = $True
	[void]${144}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABVAEIALwBDAEEAUwA='))))
	${144}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAzADAALAAgADYAMQA=')))
	${144}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AYgBvAEUAeABjAGgAUgBvAGwAZQA=')))
	${144}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADAALAAgADIAMQA=')))
	${144}.TabIndex = 5
	${144}.add_SelectedValueChanged(${143})
	
	
	
	${142}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${142}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAsACAAMQA3AA==')))
	${142}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFMAZQByAHYAZQByAE4AYQBtAGUA')))
	${142}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADUA')))
	${142}.TabIndex = 3
	${142}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlADoA')))
	
	
	
	${141}.DropDownStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RAByAG8AcABEAG8AdwBuAEwAaQBzAHQA')))
	${141}.FormattingEnabled = $True
	[void]${141}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAAMwA='))))
	[void]${141}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAANwA='))))
	[void]${141}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMAA='))))
	[void]${141}.Items.Add($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMgA='))))
	${141}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADIALAAgADYAMgA=')))
	${141}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBvAG0AYgBvAEUAeABjAGgAVgBlAHIA')))
	${141}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMQA=')))
	${141}.TabIndex = 4
	${141}.add_SelectedIndexChanged(${140})
	
	
	
	${139}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${139}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADAALAAgADEANwA=')))
	${139}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAE8AUwA=')))
	${139}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzACwAIAAxADcA')))
	${139}.TabIndex = 24
	${139}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBTADoA')))
	
	
	
	${138}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${138}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAsACAANgA1AA==')))
	${138}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEUAeABjAGgAYQBuAGcAZQBWAGUAcgBzAGkAbwBuAA==')))
	${138}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAxADgALAAgADEANwA=')))
	${138}.TabIndex = 22
	${138}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAVgBlAHIAcwBpAG8AbgA6AA==')))
	
	
	
	${137}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${137}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA3ADkALAAgADMAOQA=')))
	${137}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFIAZQBnAGkAbwBuAA==')))
	${137}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzACwAIAAxADcA')))
	${137}.TabIndex = 22
	${137}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGcAaQBvAG4AOgA=')))
	
	
	
	${136}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${136}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAsACAAMwA5AA==')))
	${136}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFMAaQB0AGUA')))
	${136}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA2ACwAIAAxADcA')))
	${136}.TabIndex = 9
	${136}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQA6AA==')))
	
	
	
	${135}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${135}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADAALAAgADYAOAA=')))
	${135}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFIAbwBsAGUA')))
	${135}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA5ACwAIAAxADUA')))
	${135}.TabIndex = 0
	${135}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBvAGwAZQA6AA==')))
	
	
	
	${134}.Controls.Add(${133})
	${134}.Controls.Add(${132})
	${134}.Controls.Add(${131})
	${134}.Controls.Add(${130})
	${134}.Controls.Add(${129})
	${134}.Controls.Add(${128})
	${134}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AVQBuAGQAZQByAGwAaQBuAGUA')))
	${134}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAMgA4ADAA')))
	${134}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAG8AdQBwAGIAbwB4AFUAUgBMAA==')))
	${134}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA2ADgALAAgADkAOAA=')))
	${134}.TabIndex = 2
	${134}.TabStop = $False
	${134}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBSAEwAIABJAG4AZgBvAHIAbQBhAHQAaQBvAG4A')))
	
	
	
	${133}.Enabled = $False
	${133}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${133}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADQALAAgADcANAA=')))
	${133}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAQQByAHIAYQB5AEQAQQBHAFUAUgBMAA==')))
	${133}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${133}.TabIndex = 17
	${133}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
	
	
	
	${132}.Enabled = $False
	${132}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${132}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADUALAAgADQANgA=')))
	${132}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAQQB1AHQAbwBkAGkAcwBjAG8AdgBlAHIAVQBSAEwA')))
	${132}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${132}.TabIndex = 16
	${132}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAGEAdQB0AG8AZABpAHMAYwBvAHYAZQByAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
	
	
	
	${131}.Enabled = $False
	${131}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${131}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADUALAAgADIAMgA=')))
	${131}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAQwBBAFMAVQBSAEwA')))
	${131}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${131}.TabIndex = 15
	${131}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAG8AdwBhAC4AYwBvAG4AdABvAHMAbwAuAGMAbwBtACkA')))
	${67}.SetToolTip(${131}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBBAFMAIABBAGMAYwBlAHMAcwAgAFUAUgBMACAAKABmAG8AcgAgADIAMAAwADcALwAyADAAMAAzACAAcwBlAHIAdgBlAHIAcwAgAHQAaABpAHMAIABpAHMAIAB0AGgAZQAgAGwAZQBnAGEAYwB5ACAAdQByAGwAKQA='))))
	
	
	
	${130}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${130}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAsACAAMwAwAA==')))
	${130}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEEAYwBjAGUAcwBzAFUAUgBMAA==')))
	${130}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADUA')))
	${130}.TabIndex = 6
	${130}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAGMAZQBzAHMAIABVAFIATAA6AA==')))
	
	
	
	${129}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${129}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAsACAANQAyAA==')))
	${129}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEEAdQB0AG8AZABpAHMAYwBvAHYAZQByAFUAUgBMAA==')))
	${129}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAxADgALAAgADEANQA=')))
	${129}.TabIndex = 7
	${129}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB1AHQAbwBkAGkAcwBjAG8AdgBlAHIAIABVAFIATAA6AA==')))
	
	
	
	${128}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${128}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwAsACAANwA3AA==')))
	${128}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEEAcgByAGEAeQBEAEEARwBVAFIATAA=')))
	${128}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADcALAAgADEANgA=')))
	${128}.TabIndex = 8
	${128}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQByAHIAYQB5AC8ARABBAEcAIABVAFIATAA6AA==')))
	
	
	
	${127}.Controls.Add(${125})
	${127}.Controls.Add(${123})
	${127}.Controls.Add(${122})
	${127}.Controls.Add(${120})
	${127}.Controls.Add(${117})
	${127}.Controls.Add(${115})
	${127}.Controls.Add(${113})
	${127}.Controls.Add(${111})
	${127}.Controls.Add(${110})
	${127}.Controls.Add(${109})
	${127}.Controls.Add(${108})
	${127}.Controls.Add(${107})
	${127}.Controls.Add(${106})
	${127}.Controls.Add(${104})
	${127}.Controls.Add(${103})
	${127}.Controls.Add(${102})
	${127}.Controls.Add(${101})
	${127}.Controls.Add(${99})
	${127}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AVQBuAGQAZQByAGwAaQBuAGUA')))
	${127}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAMQAzADQA')))
	${127}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAG8AdQBwAGIAbwB4AEkAUABJAG4AZgBvAA==')))
	${127}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA2ADgALAAgADEANAA1AA==')))
	${127}.TabIndex = 1
	${127}.TabStop = $False
	${127}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQACAAQQBkAGQAcgBlAHMAcwAgAEkAbgBmAG8A')))
	
	
	
	${125}.Anchor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHAALAAgAEwAZQBmAHQALAAgAFIAaQBnAGgAdAA=')))
	${125}.Enabled = $False
	${125}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${68}.SetIconAlignment(${125}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGQAZABsAGUATABlAGYAdAA='))))
	${68}.SetIconPadding(${125}, 2)
	${125}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADMALAAgADEAMAA5AA==')))
	${125}.MaxLength = 200
	${125}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQATgBMAEIARABBAEcASQBQAA==')))
	${125}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${125}.TabIndex = 10
	${125}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADEALgAyADAAMAA=')))
	${67}.SetToolTip(${125}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBvAHIAIABOAEwAQgA6ACAAVABoAGkAcwAgAGkAcwAgAGoAdQBzAHQAIAB0AGgAZQAgAHMAaABhAHIAZQBkACAATgBMAEIAIABJAFAAIAB5AG8AdQAgAGEAcgBlACAAZwBvAGkAbgBnACAAdABvACAAdQBzAGUALgANAAoAVABoAGkAcwAgACgAbwBiAHYAaQBvAHUAcwBsAHkAKQAgAGkAcwAgAG8AbgBsAHkAIABhAHAAcABsAGkAYwBhAGIAbABlACAAcABlAHIAIABzAGkAdABlAC4ADQAKAA0ACgBGAG8AcgAgAEQAQQBHADoAIABUAGgAaQBzACAAaQBzACAAdABoAGUAIABEAEEARwAgAEkAUAAgACgAbwBuACAAdABoAGUAIABNAEEAUABJACAAbgBlAHQAdwBvAHIAawApACAAeQBvAHUAIAB3AGkAbABsAA0ACgBiAGUAIAB1AHQAaQBsAGkAegBpAG4AZwAuACAATgBvAHQAZQAgAHQAaABhAHQAIAB5AG8AdQAgAG4AZQBlAGQAIABvAG4AZQAgAG8AZgAgAHQAaABlAHMAZQAgAHAAZQByACAAcwBpAHQAZQAuAA=='))))
	${125}.add_Validating(${126})
	${125}.add_Validated(${124})
	
	
	
	${123}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${123}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAMQAxADIA')))
	${123}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAE4ATABCAEQAQQBHAEkAUAA=')))
	${123}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADYALAAgADEAMQA=')))
	${123}.TabIndex = 37
	${123}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBMAEIALwBEAEEARwAgAEkAUAA6AA==')))
	
	
	
	${122}.Enabled = $False
	${122}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAzADkALAAgADMANwA=')))
	${122}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsAUwBTAEwATwBmAGYAbABvAGEAZAA=')))
	${122}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA4ACwAIAAyADQA')))
	${122}.TabIndex = 12
	${67}.SetToolTip(${122}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAIABpAG0AcABsAGUAbQBlAG4AdABlAGQAIAAoAHkAZQB0ACEAKQA='))))
	${122}.UseVisualStyleBackColor = $True
	
	
	
	${120}.Anchor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHAALAAgAEwAZQBmAHQALAAgAFIAaQBnAGgAdAA=')))
	${120}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${69}.SetIconAlignment(${120}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGQAZABsAGUATABlAGYAdAA='))))
	${69}.SetIconPadding(${120}, 2)
	${120}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADMALAAgADYANAA=')))
	${120}.MaxLength = 200
	${120}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQASQBQAEcAYQB0AGUAdwBhAHkA')))
	${120}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${120}.TabIndex = 8
	${120}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADEALgAxAA==')))
	${67}.SetToolTip(${120}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABnAGEAdABlAHcAYQB5ACAAZgBvAHIAIAB0AGgAZQAgAG4AZQB0AHcAbwByAGsAIABpAG4AdABlAHIAZgBhAGMAZQAgAGIAZQBpAG4AZwAgAGQAZQBmAGkAbgBlAGQALgANAAoASQBmACAAdABoAGkAcwAgAGkAcwAgAGEAIABEAEEARwAgAHIAZQBwAGwAaQBjAGEAdABpAG8AbgAgAG4AZQB0AHcAbwByAGsAIAB5AG8AdQAgAHMAdABpAGwAbAAgAHcAYQBuAHQAIAB0AG8AIABkAGUAZgBpAG4AZQANAAoAYQAgAGcAYQB0AGUAdwBhAHkAIABoAGUAcgBlACwAIABiAHUAdAAgAGwAZQBhAHYAZQAgAHQAaABlACAAYQBjAHQAdQBhAGwAIABnAGEAdABlAHcAYQB5ACAAbwBuACAAdABoAGUAIABOAEkAQwANAAoAZQBtAHAAdAB5AC4A'))))
	${120}.add_Validating(${121})
	${120}.add_Validated(${119})
	
	
	
	${117}.Anchor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHAALAAgAEwAZQBmAHQALAAgAFIAaQBnAGgAdAA=')))
	${117}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${70}.SetIconAlignment(${117}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGQAZABsAGUATABlAGYAdAA='))))
	${70}.SetIconPadding(${117}, 2)
	${117}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADMALAAgADQAMgA=')))
	${117}.MaxLength = 200
	${117}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQASQBQAFMAdQBiAG4AZQB0AA==')))
	${117}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${117}.TabIndex = 7
	${117}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA1ADUALgAyADUANQAuADIANQA1AC4AMAA=')))
	${117}.add_Validating(${118})
	${117}.add_Validated(${116})
	
	
	
	${115}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${115}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwADEALAAgADQAMgA=')))
	${115}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFMAUwBMAE8AZgBmAGwAbwBhAGQA')))
	${115}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADgALAAgADEANAA=')))
	${115}.TabIndex = 32
	${115}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBTAEwAIABPAGYAZgBsAG8AYQBkAD8A')))
	
	
	
	${113}.Anchor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAHAALAAgAEwAZQBmAHQALAAgAFIAaQBnAGgAdAA=')))
	${113}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${73}.SetIconAlignment(${113}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGQAZABsAGUATABlAGYAdAA='))))
	${73}.SetIconPadding(${113}, 2)
	${113}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADMALAAgADEAOQA=')))
	${113}.MaxLength = 200
	${113}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQASQBQAEEAZABkAHIAZQBzAHMA')))
	${113}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${113}.TabIndex = 6
	${113}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALgAxADYAOAAuADEALgAxADAAMAA=')))
	${113}.add_Validating(${114})
	${113}.add_Validated(${112})
	
	
	
	${111}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${111}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAOQAxAA==')))
	${111}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEkAbgB0AGUAcgBmAGEAYwBlAE4AYQBtAGUA')))
	${111}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADYALAAgADEAMQA=')))
	${111}.TabIndex = 2
	${111}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAGYAYQBjAGUAIABOAGEAbQBlADoA')))
	
	
	
	${110}.Enabled = $False
	${110}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAzADkALAAgADUAOQA=')))
	${110}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsASQBuAHQAZQByAG4AZQB0AEYAYQBjAGkAbgBnAA==')))
	${110}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA4ACwAIAAyADQA')))
	${110}.TabIndex = 13
	${67}.SetToolTip(${110}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBmACAAdABoAGkAcwAgAGkAcwAgAGUAeAB0AGUAcgBuAGEAbABsAHkAIABmAGEAYwBpAG4AZwAgAGEAbgBkACAAeQBvAHUAIABhAHIAZQAgAHUAcwBpAG4AZwAgAGEAIAByAGUAdgBlAHIAcwBlACAAcAByAG8AeAB5AA0ACgAoAGEAcwAgAHkAbwB1ACAAcwBoAG8AdQBsAGQAIABiAGUAIABkAG8AaQBuAGcAKQAgAHQAaABlAG4AIAB0AGgAZQAgAGEAdQB0AGgAZQBuAHQAaQBjAGEAdABpAG8AbgAgAGYAbwByACAAbwB3AGEALwBlAGMAcAANAAoAbQBpAGcAaAB0ACAAbgBlAGUAZAAgAHQAbwAgAGIAZQAgAGMAaABhAG4AZwBlAGQAIABhAG4AZAAgAHQAaABpAHMAIABzAGgAbwB1AGwAZAAgAGIAZQAgAHMAZQBsAGUAYwB0AGUAZAAuACAATwB0AGgAZQByAHcAaQBzAGUADQAKAGkAZgAgAHQAaABpAHMAIABpAHMAIAB1AHMAZQBkACAAZgBvAHIAIABpAG4AdABlAHIAbgBhAGwAIABhAGMAYwBlAHMAcwAgAG8AbgBsAHkAIAB0AGgAZQBuACAAbABlAGEAdgBlACAAdABoAGkAcwAgAHUAbgBzAGUAbABlAGMAdABlAGQALgANAAoADQAKAEUAeAB0AGUAcgBuAGEAbAAgAEUAeABhAG0AcABsAGUAOgANAAoASQBuAHQAZQByAG4AZQB0ACAAPAAtAD4AIABSAGUAdgBlAHIAcwBlACAAUAByAG8AeAB5ACAAPAAtAD4AIABFAHgAdABlAHIAbgBhAGwAIABDAEEAUwAgAE4ASQBDACAAPAAtAD4ADQAKAEMAQQBTACAAUwBlAHIAdgBlAHIALgAgAA0ACgANAAoASQBuAHQAZQByAG4AYQBsACAARQB4AGEAbQBwAGwAZQA6AA0ACgBJAG4AdABlAHIAbgBhAGwAIABOAGUAdAB3AG8AcgBrACAAPAAtAD4AIABJAG4AdABlAHIAbgBhAGwAIABDAEEAUwAgAE4ASQBDACAAPAAtAD4AIABDAEEAUwAgAFMAZQByAHYAZQByAC4AIAANAAoA'))))
	${110}.UseVisualStyleBackColor = $True
	
	
	
	${109}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${109}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAANgA3AA==')))
	${109}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEcAYQB0AGUAdwBhAHkA')))
	${109}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA2ACwAIAAxADcA')))
	${109}.TabIndex = 36
	${109}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBhAHQAZQB3AGEAeQA6AA==')))
	
	
	
	${108}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${108}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwADEALAAgADYANAA=')))
	${108}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEkAbgB0AGUAcgBuAGUAdABGAGEAYwBpAG4AZwA=')))
	${108}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADgALAAgADEANAA=')))
	${108}.TabIndex = 4
	${108}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AZQB0ACAARgBhAGMAaQBuAGcAPwA=')))
	
	
	
	${107}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${107}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAAMgA1AA==')))
	${107}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEkAUABBAGQAZAByAGUAcwBzAA==')))
	${107}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA2ACwAIAAxADEA')))
	${107}.TabIndex = 1
	${107}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQACAAQQBkAGQAcgBlAHMAcwA6AA==')))
	
	
	
	${106}.Enabled = $False
	${106}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAzADkALAAgADgAMwA=')))
	${106}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsATgBMAEIA')))
	${106}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA4ACwAIAAyADQA')))
	${106}.TabIndex = 14
	${67}.SetToolTip(${106}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGkAcwAgAGkAcwAgACIAdQBzAHUAYQBsAGwAeQAiACAAeQBvAHUAcgAgAGkAbgB0AGUAcgBuAGEAbAAgAEMAQQBTACAAZwBlAHQAdABpAG4AZwAgAFcAaQBuAGQAbwB3AHMAIABOAGUAdAB3AG8AcgBrACAATABvAGEAZAAgAEIAYQBsAGEAbgBjAGUAZAAuAA0ACgBJAGYAIAB1AHMAaQBuAGcAIABhACAAaABhAHIAZAB3AGEAcgBlACAAbABvAGEAZAAgAGIAYQBsAGEAbgBjAGUAcgAgAGQAbwBuACcAdAAgAHMAZQBsAGUAYwB0ACAAdABoAGkAcwA='))))
	${106}.UseVisualStyleBackColor = $True
	${106}.add_CheckedChanged(${105})
	
	
	
	${104}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${104}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NgAsACAANQAxAA==')))
	${104}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFMAdQBiAG4AZQB0AA==')))
	${104}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA2ACwAIAAxADEA')))
	${104}.TabIndex = 24
	${104}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGIAbgBlAHQAOgA=')))
	
	
	
	${103}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${103}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwADEALAAgADgAOAA=')))
	${103}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFcAaQBuAGQAbwB3AHMATgBMAEIA')))
	${103}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA3ACwAIAAxADQA')))
	${103}.TabIndex = 5
	${103}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgAE4ATABCAD8A')))
	
	
	
	${102}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${102}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAwADEALAAgADEANgA=')))
	${102}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFIAZQBwAGwAaQBjAGEAdABpAG8AbgBOAGUAdAB3AG8AcgBrAA==')))
	${102}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAzADIALAAgADEANAA=')))
	${102}.TabIndex = 33
	${102}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHAAbABpAGMAYQB0AGkAbwBuACAATgBlAHQAdwBvAHIAawA/AA==')))
	
	
	
	${101}.Enabled = $False
	${101}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAzADkALAAgADEAMwA=')))
	${101}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsARABBAEcAUgBlAHAAbABpAGMAYQB0AGkAbwBuAA==')))
	${101}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA4ACwAIAAyADQA')))
	${101}.TabIndex = 11
	${67}.SetToolTip(${101}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBmACAAeQBvAHUAIABhAHIAZQAgAGQAZQBmAGkAbgBpAG4AZwAgAGEAIABEAEEARwAgAHIAZQBwAGwAaQBjAGEAdABpAG8AbgAgAGkAbgB0AGUAcgBmAGEAYwBlACAAdABoAGUAbgAgAHMAZQBsAGUAYwB0AA0ACgB0AGgAaQBzAC4AIABOAG8AdABlACAAdABoAGEAdAAgAGkAbgAgAGEAbgB5ACAARABBAEcAIABhACAAcwBlAGMAbwBuAGQAIABkAGUAZABpAGMAYQB0AGUAZAAgAHIAZQBwAGwAaQBjAGEAcwB0AGkAbwBuAA0ACgBWAEwAQQBOACAAaQBzACAAYgBlAHMAdAAgAHAAcgBhAGMAdABpAGMAZQAuACAASQBuACAAYQAgAG0AdQBsAHQAaQBwAGwAZQAgAHMAaQB0AGUAIABEAEEARwAgAHQAaABlACAAcwBhAG0AZQAgAGIAZQBzAHQADQAKAHAAcgBhAGMAdABpAGMAZQAgAHMAaABvAHUAbABkACAAYgBlACAAZgBvAGwAbABvAHcAZQBkACAAYQBuAGQAIABlAGEAYwBoACAAbwBmACAAdABoAGUAcwBlACAAZABlAGQAaQBjAGEAdABlAGQADQAKAFYATABBAE4AcwAgAHMAaABvAHUAbABkACAAYgBlACAAcgBvAHUAdABhAGIAbABlACAAdABvACAAbwBuAGUAIABhAG4AbwB0AGgAZQByAC4A'))))
	${101}.UseVisualStyleBackColor = $True
	${101}.add_CheckedChanged(${100})
	
	
	
	${99}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${99}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAyADMALAAgADgANwA=')))
	${99}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQASQBuAHQATgBhAG0AZQA=')))
	${99}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA1ADAALAAgADIAMAA=')))
	${99}.TabIndex = 9
	${99}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABpAGUALgAgAEkATgBUAEUAUgBOAEEATAApAA==')))
	${67}.SetToolTip(${99}, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAIABsAGkAdABlAHIAYQBsACAATgBJAEMAIABpAG4AdABlAHIAZgBhAGMAZQAgAG4AYQBtAGUALgA='))))
	
	
	
	${98}.Controls.Add(${97})
	${98}.Controls.Add(${61})
	${98}.Controls.Add(${96})
	${98}.Controls.Add(${95})
	${98}.Controls.Add(${93})
	${98}.Controls.Add(${92})
	${98}.Controls.Add(${91})
	${98}.Controls.Add(${90})
	${98}.Controls.Add(${89})
	${98}.Controls.Add(${88})
	${98}.Controls.Add(${87})
	${98}.Controls.Add(${86})
	${98}.BackColor = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGkAdABlAFMAbQBvAGsAZQA=')))
	${98}.BorderStyle = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAHgAZQBkAFMAaQBuAGcAbABlAA==')))
	${98}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAsACAAMgAyAA==')))
	${98}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABhAGIAcABhAGcAZQAyAA==')))
	${98}.Padding = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MwAsACAAMwAsACAAMwAsACAAMwA=')))
	${98}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA5ADMALAAgADQAMQAyAA==')))
	${98}.TabIndex = 1
	${98}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBwAHQAaQBvAG4AcwA=')))
	
	
	
	${97}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${97}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAxADkALAAgADEANgA0AA==')))
	${97}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEUAeAB0AGUAcgBuAGEAbABEAE4AUwBOAGEAbQBlAHMAcABhAGMAZQA=')))
	${97}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA2ADIALAAgADIAMwA=')))
	${97}.TabIndex = 11
	${97}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAZQByAG4AYQBsACAARABOAFMAIABOAGEAbQBlAHMAcABhAGMAZQA6AA==')))
	
	
	
	${61}.Enabled = $False
	${61}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADEANgA0AA==')))
	${61}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQARQB4AHQAZQByAG4AYQBsAEQAbwBtAGEAaQBuAE4AYQBtAGUAUwBwAGEAYwBlAA==')))
	${61}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADYALAAgADIAMAA=')))
	${61}.TabIndex = 10
	
	
	
	${96}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${96}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADMANwA=')))
	${96}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFUAcwBlAEkAbgB0AGUAcgBuAGEAbABDAEEAUwBBAHIAcgBhAHkARAA=')))
	${96}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADIALAAgADIAMwA=')))
	${96}.TabIndex = 9
	${96}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAIABJAG4AdABlAHIAbgBhAGwAIABDAEEAUwAgAEEAcgByAGEAeQAgAEQAbwBtAGEAaQBuADoA')))
	
	
	
	${95}.Checked = $True
	${95}.CheckState = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGUAZAA=')))
	${95}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADEAMwAyAA==')))
	${95}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsAVQBzAGUASQBuAHQAZQByAG4AYQBsAEMAQQBTAEQAbwBtAGEAaQBuAA==')))
	${95}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA3ACwAIAAyADQA')))
	${95}.TabIndex = 8
	${95}.UseVisualStyleBackColor = $True
	${95}.add_CheckedChanged(${94})
	
	
	
	${93}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${93}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA0ADYALAAgADEAMQAxAA==')))
	${93}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEcAZQBuAGUAcgBhAHQAZQBDAEEAUwBBAHIAcgBhAHkAcwA=')))
	${93}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAzADUALAAgADIAMwA=')))
	${93}.TabIndex = 7
	${93}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAG4AZQByAGEAdABlACAAQwBBAFMAIABBAHIAcgBhAHkAcwA6AA==')))
	
	
	
	${92}.Checked = $True
	${92}.CheckState = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGUAZAA=')))
	${92}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADEAMAA2AA==')))
	${92}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsARwBlAG4AZQByAGEAdABlAEMAQQBTAEEAcgByAGEAeQBzAA==')))
	${92}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA3ACwAIAAyADQA')))
	${92}.TabIndex = 6
	${92}.UseVisualStyleBackColor = $True
	
	
	
	${91}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${91}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA0ADAALAAgADgAMgA=')))
	${91}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEEAcwBzAHUAbQBlAFIAZQB2AGUAcgBzAGUAUAByAG8AeAB5AA==')))
	${91}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA0ADcALAAgADIAMwA=')))
	${91}.TabIndex = 5
	${91}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBzAHMAdQBtAGUAIABSAGUAdgBlAHIAcwBlACAAUAByAG8AeAB5ADoA')))
	
	
	
	${90}.Checked = $True
	${90}.CheckState = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGUAZAA=')))
	${90}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADcANQA=')))
	${90}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsAUgBlAHYAZQByAHMAZQBQAHIAbwB4AHkA')))
	${90}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA3ACwAIAAyADQA')))
	${90}.TabIndex = 4
	${90}.UseVisualStyleBackColor = $True
	
	
	
	${89}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${89}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA4ADcALAAgADUAMAA=')))
	${89}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAFIAZQBkAGkAcgBlAGMAdABVAFIATABzAA==')))
	${89}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwADAALAAgADIAMwA=')))
	${89}.TabIndex = 3
	${89}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQAaQByAGUAYwB0ACAAVQBSAEwAcwA6AA==')))
	
	
	
	${88}.Checked = $True
	${88}.CheckState = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBoAGUAYwBrAGUAZAA=')))
	${88}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADQANQA=')))
	${88}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsAUgBlAGQAaQByAGUAYwB0AGkAbwBuAA==')))
	${88}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA3ACwAIAAyADQA')))
	${88}.TabIndex = 2
	${88}.UseVisualStyleBackColor = $True
	
	
	
	${87}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${87}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ACwAIAAyADIA')))
	${87}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAEkAbgB0AGUAcgBuAGEAbABFAHgAYwBoAGEAbgBnAGUAVgBpAHIAdAA=')))
	${87}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA2ADgALAAgADIAMwA=')))
	${87}.TabIndex = 1
	${87}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AYQBsACAARQB4AGMAaABhAG4AZwBlACAAVgBpAHIAdAB1AGEAbAAgAEQAaQByAGUAYwB0AG8AcgB5ACAATABvAGMAYQB0AGkAbwBuADoA')))
	
	
	
	${86}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADcALAAgADEAOQA=')))
	${86}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dAB4AHQAdgBkAGkAcgBsAG8AYwBhAHQAaQBvAG4A')))
	${86}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQA5ADYALAAgADIAMAA=')))
	${86}.TabIndex = 0
	${86}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwA6AFwAaQBuAGUAdABwAHUAYgBcAGUAeABjAGgAYQBuAGcAZQAtAGkAbgB0AGUAcgBuAGEAbAA=')))
	
	
	
	${85}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AQgBvAGwAZAA=')))
	${85}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzADcALAAgADIAOAA0AA==')))
	${85}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bABhAGIAZQBsAE8AdQB0AHAAdQB0AEYAbwBsAGQAZQByAA==')))
	${85}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OAA5ACwAIAAxADUA')))
	${85}.TabIndex = 31
	${85}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQAcAB1AHQAIABGAG8AbABkAGUAcgA6AA==')))
	
	
	
	${84}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAzADcALAAgADMANQA2AA==')))
	${84}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBoAGsARwB1AG4AUwBsAGkAbgBnAGUAcgA=')))
	${84}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAwADQALAAgADUANAA=')))
	${84}.TabIndex = 20
	${84}.TabStop = $False
	${84}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QgB5ACAAYwBoAGUAYwBrAGkAbgBnACAAdABoAGkAcwAgAGIAbwB4ACAAeQBvAHUAIABhAHIAZQAgAGEAZwByAGUAZQBpAG4AZwAgAHQAaABhAHQAIAB5AG8AdQAgAGEAbABvAG4AZQAgAGEAcgBlACAAcgBlAHMAcABvAG4AcwBpAGIAbABlACAAZgBvAHIAIAB5AG8AdQByACAARQB4AGMAaABhAG4AZwBlACAAZQBuAHYAaQByAG8AbgBtAGUAbgB0ACAAYQBuAGQAIABhAHIAZQAgAHAAYQB0AGUAbgB0AGwAeQAgAGkAZwBuAG8AcgBuAGkAbgBnACAAdABoAGUAIABmAGEAYwB0ACAAdABoAGEAdAAgAHQAaABpAHMAIABzAGMAcgBpAHAAdAAgAGkAcwAgAEIARQBUAEEAIABhAG4AZAAgAG0AYQB5ACAAcwBjAHIAZQB3ACAAdABoAGkAbgBnAHMAIAB1AHAALgA=')))
	${84}.UseVisualStyleBackColor = $True
	${84}.Visible = $False
	${84}.add_CheckedChanged(${83})
	
	
	
	${82}.Enabled = $False
	${82}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA0ADcALAAgADMANwAxAA==')))
	${82}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4AUgB1AG4A')))
	${82}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${82}.TabIndex = 21
	${82}.TabStop = $False
	${82}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgB1AG4AIABTAGMAcgBpAHAAdAA=')))
	${82}.UseVisualStyleBackColor = $True
	${82}.Visible = $False
	
	
	
	${81}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA0ADcALAAgADIANwA5AA==')))
	${81}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4ARwBlAG4AZQByAGEAdABlAA==')))
	${81}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${81}.TabIndex = 19
	${81}.TabStop = $False
	${81}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAG4AZQByAGEAdABlACEA')))
	${81}.UseVisualStyleBackColor = $True
	${81}.add_Click(${80})
	
	
	
	${79}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OQA0ADcALAAgADMAOQA4AA==')))
	${79}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4ARQB4AGkAdAA=')))
	${79}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${79}.TabIndex = 22
	${79}.TabStop = $False
	${79}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGkAdAA=')))
	${79}.UseVisualStyleBackColor = $True
	${79}.add_Click(${78})
	
	
	
	${77}.Controls.Add(${76})
	${77}.Controls.Add(${75})
	${77}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAAsACAAcwB0AHkAbABlAD0AVQBuAGQAZQByAGwAaQBuAGUA')))
	${77}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAyADcALAAgADIANwA=')))
	${77}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZwByAG8AdQBwAGIAbwB4AFMAZQByAHYAZQByAEwAaQBzAHQA')))
	${77}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NQAwADEALAAgADIANAA3AA==')))
	${77}.TabIndex = 24
	${77}.TabStop = $False
	${77}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABMAGkAcwB0AA==')))
	
	
	
	${76}.AllowUserToAddRows = $False
	${76}.ColumnHeadersHeightSizeMode = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB1AHQAbwBTAGkAegBlAA==')))
	${76}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MQAwACwAIAAxADkA')))
	${76}.MultiSelect = $False
	${76}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZABhAHQAYQBnAHIAaQBkAFMAZQByAHYAZQByAHMA')))
	${76}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAA4ADUALAAgADEAOQAxAA==')))
	${76}.TabIndex = 2
	${76}.TabStop = $False
	
	
	
	${75}.Font = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQAIABTAGEAbgBzACAAUwBlAHIAaQBmACwAIAA4AC4AMgA1AHAAdAA=')))
	${75}.Location = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NAAyADAALAAgADIAMQA2AA==')))
	${75}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YgB0AG4ARABlAGwAZQB0AGUA')))
	${75}.Size = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('NwA1ACwAIAAyADMA')))
	${75}.TabIndex = 16
	${75}.TabStop = $False
	${75}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUA')))
	${75}.UseVisualStyleBackColor = $True
	${75}.add_Click(${74})
	
	
	
	${73}.ContainerControl = ${66}
	
	
	
	
	
	
	${72}.CheckFileExists = $False
	${72}.DefaultExt = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBzAHYA')))
	${72}.Filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AbQBhACAAUwBlAHAAYQByAGEAdABlAGQAIABWAGEAbAB1AGUAIABGAGkAbABlACAAKAAuAGMAcwB2ACkAfAAqAC4AYwBzAHYA')))
	${72}.ShowHelp = $True
	
	
	
	${71}.DefaultExt = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YwBzAHYA')))
	${71}.Filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG0AbQBhACAAUwBlAHAAYQByAGEAdABlAGQAIABWAGEAbAB1AGUAIABGAGkAbABlACAAKAAuAGMAcwB2ACkAfAAqAC4AYwBzAHYA')))
	${71}.ShowHelp = $True
	
	
	
	${70}.ContainerControl = ${66}
	
	
	
	${69}.ContainerControl = ${66}
	
	
	
	${68}.ContainerControl = ${66}
	
	
	
	${67}.AutomaticDelay = 0
	${67}.AutoPopDelay = 100000
	${67}.InitialDelay = 500
	${67}.ReshowDelay = 100
	${67}.ShowAlways = $True
	

	

	
	${5} = ${66}.WindowState
	
	${66}.add_Load(${4})
	
	${66}.add_FormClosed(${3})
	
	${66}.add_Closing(${2})
	
	return ${66}.ShowDialog()

}



	
	
	
	
	${65} = New-Object System.Data.DataTable
	${57} = @()
	
	
	${41} = @()
	${34} = @()
	${37} = @()
	${53} = @()
	${26} = @()
	${28} = @()
	${39} = @()
	${45} = @()
	${64} = @()
	${63} = @()
	${56} = @()
	${30} = @()
	${62} = @()
	
	
	${44} = @()
	${43} = @()
	${20} = @()
	${47} = @()
	
	
	${51} = $false
	${50} = $false
	${49} = $false
	${48} = $false
	${46} = $false
	
	
	${47} = @()
	${42} = @()
	
	
	${35} = $true
	${32} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAaQBuAGUAdABwAHUAYgBcAGUAeABjAGgAYQBuAGcAZQAtAGkAbgB0AGUAcgBuAGEAbABcAA==')))
	${31} = $true
	${21} = $true
	${18} = $true
	${17} = ${61}.Text
	
	
	
	${60} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwByAGUAZwBpAG8AbgAgAE0AbwBkAHUAbABlAC8AUwBuAGEAcABpAG4ALwBEAG8AdAAgAFMAbwB1AHIAYwBpAG4AZwANAAoAaQBmACAAKAAhACAAKABHAGUAdAAtAFAAUwBTAG4AYQBwAGkAbgAgAE0AaQBjAHIAbwBzAG8AZgB0AC4ARQB4AGMAaABhAG4AZwBlAC4ATQBhAG4AYQBnAGUAbQBlAG4AdAAuAFAAbwB3AGUAcgBTAGgAZQBsAGwALgBFADIAMAAxADAAIAAtAEUAcgByAG8AcgBBAGMAdABpAG8AbgA6AFMAaQBsAGUAbgB0AGwAeQBDAG8AbgB0AGkAbgB1AGUAKQAgACkADQAKAHsAIAANAAoACQBBAGQAZAAtAFAAUwBTAG4AYQBwAGkAbgAgAE0AaQBjAHIAbwBzAG8AZgB0AC4ARQB4AGMAaABhAG4AZwBlAC4ATQBhAG4AYQBnAGUAbQBlAG4AdAAuAFAAbwB3AGUAcgBTAGgAZQBsAGwALgBFADIAMAAxADAAIAANAAoAfQANAAoASQBtAHAAbwByAHQALQBNAG8AZAB1AGwAZQAgAFcAZQBiAEEAZABtAGkAbgBpAHMAdAByAGEAdABpAG8AbgANAAoAIwBlAG4AZAByAGUAZwBpAG8AbgAgAE0AbwBkAHUAbABlAC8AUwBuAGEAcABpAG4ALwBEAG8AdAAgAFMAbwB1AHIAYwBpAG4AZwA=')))
	
	
	
	
	function Validate-Environment
	{
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		${59} = $true
			
				
					
	}
	
	function ConvertTo-ScriptBlock 
	{
		param
		(
			[parameter(ValueFromPipeline=$true,Position=0)]
			[string]
			$string
		)
		${58} = [scriptblock]::Create($string)
		return ${58}
	}
	
	
	
	
	
	function Sort-ExchangeServers
	{
		
		ForEach (${22} in ${57})
		{
			switch (${22}."Exchange Version")
			{
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMgA=')))
				{
					switch (${22}."Role")
					{
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAGkAbABiAG8AeAA='))) 
						{
							
						}
					$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SAB1AGIALwBUAHIAYQBuAHMAcABvAHIAdAAvAEQAYQB0AGEAYgBhAHMAZQA='))) 
						{
							
						}
					}
				}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADEAMAA=')))
				{
	            ${script:20} += ${22}
				switch (${22}."Role") 
				{
				
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABVAEIALwBDAEEAUwA='))) 
					{			
						${script:41} += ${22}
						if (${22}."Internet Facing" -eq $true)
						{
							${script:37} += ${22}
							if (${22}."NLB" -eq $true)
							{
								${script:28} += ${22}
								${script:30} += ${22}                                
							}
						}
						else
						{
							${script:34} += ${22}
							if (${22}."NLB" -eq $true)
							{
								${script:26} += ${22}
								${script:30} += ${22}
							}
						}				
					}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQBiAGEAcwBlAA=='))) 
					{
						${script:39} += ${22}
						If (${22}."DAG Replication" -eq $true)
						{
							${script:45} += ${22}
						}
					}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBkAGcAZQA='))) 
					{
						${script:56} += ${22}
						
					}
				}
			}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAANwA=')))
				{
					${script:43} += ${22}
				}
			$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlACAAMgAwADAAMwA=')))
				{
					${script:44} += ${22}
				}
			}
			switch (${22}."Windows Version")
				{
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgADIAMAAxADIA')))
					{
						${Script:47} += ${22}
					}
				$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAG4AZABvAHcAcwAgADIAMAAwADgAIABSADIA')))
					{
						${Script:42} += ${22}
					}
				}
		}
	    
	    
	    if (${37}.Count -ge 1)
	    {
	        
	        foreach (${55} in ${37})
	        {
	            if (${37}.Count -ge 1)
	            {
	                foreach (${54} in ${34})
	                {
	            	    if (${55}."Server Name" -eq ${54}."Server Name")
	                    {
	    		            ${52} = New-Object PSObject
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIATgBhAG0AZQA='))) -Value ${55}."Server Name"
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AGMAaABhAG4AZwBlAFYAZQByAHMAaQBvAG4A'))) -Value ${55}."Exchange Version"
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQA='))) -Value ${55}."Site"
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAZQByAG4AYQBsAEEAdQB0AG8AZABpAHMAYwBvAHYAZQByAFUAUgBMAA=='))) -Value ${55}."Autodiscover URL"
	                        ${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AYQBsAEEAdQB0AG8AZABpAHMAYwBvAHYAZQByAFUAUgBMAA=='))) -Value ${54}."Autodiscover URL"
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAZQByAG4AYQBsAEMAQQBTAFUAUgBMAA=='))) -Value ${55}."CAS URL"
	                		${52} | Add-Member Noteproperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHQAZQByAG4AYQBsAEMAQQBTAFUAUgBMAA=='))) -Value ${54}."CAS URL"
	                        ${Script:53} += ${52}
	    				}
	    			}
				}
		    }
		}
		
		if ((${44}) -and (${20}))
		{
			${Script:51} = $true
		}
		
		if ((${44}) -and (${47}))
		{
			${Script:50} = $true
		}
		
		if ((${43}) -and (${20}))
		{
			${Script:49} = $true
		}
		
		if ((${43}) -and (${47}))
		{
			${Script:48} = $true
		}
		
		if ((${20}) -and (${47}))
		{
			${Script:46} = $true
		}
		
	}
	
	
	function Generate-Preqs
	{
		${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAgAA0ACgAjACMAIABQAFIARQBSAEUAUQBVAEkAUwBJAFQARQBTACAARABJAFIARQBDAFQASQBPAE4AUwAvAFMAQwBSAEkAUABUAFMAIAAgACAAIAAgACAAIAAgACAAIwAjAA0ACgAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjACMAIwAjAA0ACgA=')))
		
		
		${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PAAjACAARwBlAG4AZQByAGEAbAAgAE4AbwB0AGUAcwAgACgAcwBvAG0AZQAgAHMAbgBhAGcAZwBlAGQAIABmAHIAbwBtACAAaAB0AHQAcAA6AC8ALwBtAHMAdQBuAGkAZgBpAGUAZAAuAG4AZQB0AC8AMgAwADAAOQAvADEAMAAvADMAMAAvAGUAeABjAGgAYQBuAGcAZQAtADIAMAAxADAALQBwAHIAZQByAGUAcQB1AGkAcwBpAHQAZQBzAC0AbwBuAC0AcwBlAHIAdgBlAHIALQAyADAAMAA4AC0AcgAyAC8AIAANAAoAIAAgACAAIABvAHQAaABlAHIAcwAgAGYAcgBvAG0AIABtAHUAbAB0AGkAcABsAGUAIABzAG8AdQByAGMAZQBzACAAYQBuAGQAIABlAHgAcABlAHIAaQBlAG4AYwBlACkADQAKAAkALQAgAE0AYQBrAGUAIABzAHUAcgBlACAAdABoAGEAdAAgAHQAaABlACAAZgB1AG4AYwB0AGkAbwBuAGEAbAAgAGwAZQB2AGUAbAAgAG8AZgAgAHkAbwB1AHIAIABmAG8AcgBlAHMAdAAgAGkAcwAgAGEAdAAgAGwAZQBhAHMAdAAgAFcAaQBuAGQAbwB3AHMAIABTAGUAcgB2AGUAcgAgADIAMAAwADMADQAKACAAIAAgACAALQAgAEEAbABzAG8AIABtAGEAawBlACAAcwB1AHIAZQAgAHQAaABhAHQAIAB0AGgAZQAgAFMAYwBoAGUAbQBhACAATQBhAHMAdABlAHIAIABpAHMAIAByAHUAbgBuAGkAbgBnACAAVwBpAG4AZABvAHcAcwAgAFMAZQByAHYAZQByACAAMgAwADAAMwAgAHcAaQB0AGgAIABTAGUAcgB2AGkAYwBlACAAUABhAGMAawAgADEAIABvAHIAIABsAGEAdABlAHIA')))
		if ((${45}) -or ($2012DatabaseDAGServers0))
		{
			${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACAAIAAgACAALQAgAEkAZgAgAEQAYQB0AGEAYgBhAHMAZQAgAEEAdgBhAGkAbABhAGIAaQBsAGkAdAB5ACAARwByAG8AdQBwAHMAIAAoAEQAQQBHACkAIABpAHMAIABnAG8AaQBuAGcAIAB0AG8AIABiAGUAIAB1AHMAZQBkACAAaQBuAHMAdABhAGwAbAAgAFMAZQByAHYAZQByACAAMgAwADAAOAAgAFIAMgAgAEUAbgB0AGUAcgBwAHIAaQBzAGUAIABFAGQAaQB0AGkAbwBuAA0ACgAgACAAIAAgACAAIAAgACAALQAgAEUAeABjAGgAYQBuAGcAZQAgADIAMAAxADAAIABTAHQAYQBuAGQAYQByAGQAIABFAGQAaQB0AGkAbwBuACAAcwB1AHAAcABvAHIAdABzACAARABBAEcAIAB3AGkAdABoACAAdQBwACAAdABvACAANQAgAGQAYQB0AGEAYgBhAHMAZQBzAA0ACgAgACAAIAAgACAAIAAgACAALQAgAEUAeABjAGgAYQBuAGcAZQAgADIAMAAxADAAIABFAG4AdABlAHIAcAByAGkAcwBlACAARQBkAGkAdABpAG8AbgAgAHMAdQBwAHAAbwByAHQAcwAgAHUAcAAgAHQAbwAgADEAMAAwACAAZABhAHQAYQBiAGEAcwBlAHMAIABwAGUAcgAgAHMAZQByAHYAZQByAA0ACgAgACAAIAAgACAAIAAgACAALQAgAFkAbwB1ACAAYwBhAG4AIABpAG4AcwB0AGEAbABsACAAYQBsAGwAIABzAGUAcgB2AGUAcgAgAHIAbwBsAGUAcwAgAG8AbgAgAHQAaABlACAAcwBhAG0AZQAgAHMAZQByAHYAZQByACAAdwBoAGUAbgAgAHUAcwBpAG4AZwAgAEQAQQBHAA0ACgAgACAAIAAgACAAIAAgACAALQAgAEIAdQB0ACAAdABoAGUAbgAgAHkAbwB1ACAAbgBlAGUAZAAgAGEAIABoAGEAcgBkAHcAYQByAGUAIABsAG8AYQBkACAAYgBhAGwAYQBuAGMAZQByACAAIABmAG8AcgAgAHIAZQBkAHUAbgBkAGEAbgB0ACAAQwBBAFMAIABhAG4AZAAgAEgAVQBCACAAZAB1AGUAIAB0AG8AIABhACAAVwBpAG4AZABvAHcAcwAgAGwAaQBtAGkAdABhAHQAaQBvAG4AIABwAHIAZQB2AGUAbgB0AGkAbgBnACAAeQBvAHUAIABmAHIAbwBtACAAdQBzAGkAbgBnACAAVwBpAG4AZABvAHcAcwAgAE4ATABCACAAYQBuAGQAIABDAGwAdQBzAHQAZQByAGkAbgBnACAAUwBlAHIAdgBpAGMAZQBzACAAbwBuACAAdABoAGUAIABzAGEAbQBlACAAVwBpAG4AZABvAHcAcwAgAGIAbwB4AA0ACgAgACAAIAAgACAAIAAgACAALQAgAFQAdwBvACAAbgBvAGQAZQAgAEQAQQBHACAAcgBlAHEAdQBpAHIAZQBzACAAYQAgAHcAaQB0AG4AZQBzAHMAIAB0AGgAYQB0ACAAaQBzACAAbgBvAHQAIABvAG4AIABhACAAcwBlAHIAdgBlAHIAIAB3AGkAdABoAGkAbgAgAHQAaABlACAARABBAEcADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAC0AIABFAHgAYwBoAGEAbgBnAGUAIAAyADAAMQAwACAAYQB1AHQAbwBtAGEAdABpAGMAYQBsAGwAeQAgAHQAYQBrAGUAcwAgAGMAYQByAGUAIABvAGYAIABGAFMAVwAgAGMAcgBlAGEAdABpAG8AbgA7ACAAdABoAG8AdQBnAGgAIAB5AG8AdQAgAGQAbwAgAGgAYQB2AGUAIAB0AG8AIABzAHAAZQBjAGkAZgB5ACAAdABoAGUAIABsAG8AYwBhAHQAaQBvAG4AIABvAGYAIAB0AGgAZQAgAEYAUwBXAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAtACAASQB0ACAAaQBzACAAcgBlAGMAbwBtAG0AZQBuAGQAZQBkACAAdABvACAAcwBwAGUAYwBpAGYAeQAgAHQAaABlACAARgBTAFcAIAB0AG8AIABiAGUAIABjAHIAZQBhAHQAZQBkACAAbwBuACAAYQAgAEgAdQBiACAAVAByAGEAbgBzAHAAbwByAHQAIABTAGUAcgB2AGUAcgANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAALQAgAEEAbAB0AGUAcgBuAGEAdABpAHYAZQBsAHkALAAgAHkAbwB1ACAAYwBhAG4AIABwAHUAdAAgAHQAaABlACAAdwBpAHQAbgBlAHMAcwAgAG8AbgAgAGEAIABuAG8AbgAtAEUAeABjAGgAYQBuAGcAZQAgAFMAZQByAHYAZQByACAAYQBmAHQAZQByACAAcwBvAG0AZQAgAHAAcgBlAHIAZQBxAHUAaQBzAGkAdABlAHMAIABoAGEAdgBlACAAYgBlAGUAbgAgAGMAbwBtAHAAbABlAHQAZQBkAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAtACAAWQBvAHUAIABjAGEAbgAgAGYAbwBsAGwAbwB3ACAAdABoAGUAcwBlACAAcwB0AGUAcABzACAAdABvACAAZwBlAHQAIAB5AG8AdQByACAAbQBlAG0AYgBlAHIAIABzAGUAcgB2AGUAcgAgAHQAbwAgAGEAYwB0ACAAYQBzACAARgBTAFcADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAYQBkAGQAIAB0AGgAZQAgABwgRQB4AGMAaABhAG4AZwBlACAAVAByAHUAcwB0AGUAZAAgAFMAdQBiAHMAeQBzAHQAZQBtAB0gIABnAHIAbwB1AHAAIAB0AG8AIABvAHUAcgAgAEwAbwBjAGEAbAAgAEEAZABtAGkAbgBpAHMAdAByAGEAdABvAHIAcwAgAEcAcgBvAHUAcAAgAG8AbgAgAHQAaABhAHQAIABtAGUAbQBiAGUAcgAgAHMAZQByAHYAZQByAA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAtACAATwBuACAAcwBlAHIAdgBlAHIAcwAgAHQAaABhAHQAIAB3AGkAbABsACAAaABvAHMAdAAgAHQAaABlACAASAB1AGIAIABUAHIAYQBuAHMAcABvAHIAdAAgAG8AcgAgAE0AYQBpAGwAYgBvAHgAIABzAGUAcgB2AGUAcgAgAHIAbwBsAGUALAAgAGkAbgBzAHQAYQBsAGwAIAB0AGgAZQAgAE0AaQBjAHIAbwBzAG8AZgB0ACAARgBpAGwAdABlAHIAIABQAGEAYwBrAC4AIABGAG8AcgAgAGQAZQB0AGEAaQBsAHMALAAgAHMAZQBlACAAMgAwADAANwAgAE8AZgBmAGkAYwBlACAAUwB5AHMAdABlAG0AIABDAG8AbgB2AGUAcgB0AGUAcgA6ACAATQBpAGMAcgBvAHMAbwBmAHQAIABGAGkAbAB0AGUAcgAgAFAAYQBjAGsAIAAoAHQAaABpAHMAIABhAGwAbABvAHcAcwAgAG8AZgBmAGkAYwBlACAAYQB0AHQAYQBjAGgAbQBlAG4AdABzACAAYwBvAG4AdABlAG4AdAAgAHQAbwAgAGIAZQAgAHMAZQBhAHIAYwBoAGUAZAAgAGEAbgBkACAAaQBuAGQAZQB4AGUAZAApAA0ACgAgACAAIAAgAC0AIABTAGUAdAAgAFAAYQBnAGUAZgBpAGwAZQAgAHMAaQB6AGUALAAgAFIAQQBNACAAKwAgADEAMABNAEIAIAAoAGYAbwByACAAcwB5AHMAdABlAG0AcwAgAHcAaQB0AGgAIAA4ACAARwBCACAAbwBmACAAUgBBAE0AIABvAHIAIABsAGUAcwBzACwAIABzAGUAdAAgAHAAYQBnAGUAZgBpAGwAZQAgAHQAbwAgAFIAQQBNACAAKgAgADEALAA1ACkADQAKACAAIAAgACAALQAgAEQAaQBzAGEAYgBsAGUAIABJAFAAdgA2ACAAYgB5ACAAdQBzAGkAbgBnACAAdABoAGkAcwAgAGcAdQBpAGQAZQA6ACAAaAB0AHQAcAA6AC8ALwBzAHUAcABwAG8AcgB0AC4AbQBpAGMAcgBvAHMAbwBmAHQALgBjAG8AbQAvAGsAYgAvADkAMgA5ADgANQAyAA0ACgAgACAAIAAgAC0AIABSAHUAbgAgAFcAaQBuAGQAbwB3AHMAIABVAHAAZABhAHQAZQAgAHUAbgB0AGkAbABsACAAYQBsAGwAIAB1AHAAZABhAHQAZQBzACAAYQByAGUAIABpAG4AcwB0AGEAbABsAGUAZAANAAoAIAAgAA0ACgAgACAAIABEAEEARwAgAE4AZQB0AHcAbwByAGsAIABDAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuACAAQgBlAHMAdAAgAFAAcgBhAGMAdABpAGMAZQBzACAAIwAjAA0ACgAgACAAIABBAGQAYQBwAHQAbwByACAAQwBvAG0AcABvAG4AZQBuAHQAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABNAEEAUABJACAATgBJAEMAIAAgACAAIAAgACAAIABSAGUAcABsAGkAYwBhAHQAaQBvAG4AIABOAEkAQwANAAoAIAAgACAAXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwAgACAAIAAgACAAXwBfAF8AXwBfAF8AXwBfACAAIAAgACAAIAAgACAAXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8AXwBfAF8ADQAKACAAIAAgAEMAbABpAGUAbgB0ACAAZgBvAHIAIABNAGkAYwByAG8AcwBvAGYAdAAgAE4AZQB0AHcAbwByAGsAcwAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEUAbgBhAGIAbABlAGQAIAAgACAAIAAgACAAIAAgAEQAaQBzAGEAYgBsAGUAZAANAAoAIAAgACAAUQBvAFMAIABQAGEAYwBrAGUAdAAgAFMAYwBoAGUAZAB1AGwAZQByACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAATwBwAHQAaQBvAG4AYQBsACAAIAAgACAAIAAgACAATwBwAHQAaQBvAG4AYQBsAA0ACgAgACAAIABGAGkAbABlACAAYQBuAGQAIABQAHIAaQBuAHQAZQByACAAUwBoAGEAcgBpAG4AZwAgAGYAbwByACAATQBpAGMAcgBvAHMAbwBmAHQAIABOAGUAdAB3AG8AcgBrAHMAIAAgACAAIABFAG4AYQBiAGwAZQBkACAAIAAgACAAIAAgACAAIABEAGkAcwBhAGIAbABlAGQADQAKACAAIAAgAEkAbgB0AGUAcgBuAGUAdAAgAFAAcgBvAHQAbwBjAG8AbAAgAFYAZQByAHMAaQBvAG4AIAA2ACAAKABUAEMAUAAvAEkAUAAgAHYANgApACAAIAAgACAAIAAgACAAIAAgACAAIAAgAE8AcAB0AGkAbwBuAGEAbAAgACAAIAAgACAAIAAgAE8AcAB0AGkAbwBuAGEAbAANAAoAIAAgACAASQBuAHQAZQByAG4AZQB0ACAAUAByAG8AdABvAGMAbwBsACAAVgBlAHIAcwBpAG8AbgAgADQAIAAoAFQAQwBQAC8ASQBQACAAdgA0ACkAIAAgACAAIAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAANAAoAIAAgACAATABpAG4AawAtAEwAYQB5AGUAcgAgAFQAbwBwAG8AbABvAGcAeQAgAEQAaQBzAGMAbwB2AGUAcgB5ACAATQBhAHAAcABlAHIAIABJAC8ATwAgAEQAcgBpAHYAZQByACAAIAAgACAARQBuAGEAYgBsAGUAZAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAANAAoAIAAgACAATABpAG4AawAtAEwAYQB5AGUAcgAgAFQAbwBwAG8AbABvAGcAeQAgAEQAaQBzAGMAbwB2AGUAcgB5ACAAUgBlAHMAcABvAG4AZABlAHIAIAAgACAAIAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAANAAoAIAAgACAAUgBlAGcAaQBzAHQAZQByACAAQwBvAG4AbgBlAGMAdABpAG8AbgAgAGkAbgAgAEQATgBTACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAARQBuAGEAYgBsAGUAZAAgACAAIAAgACAAIAAgACAARABpAHMAYQBiAGwAZQBkAA0ACgAgACAAIABEAGUAZgBhAHUAbAB0ACAARwBhAHQAZQB3AGEAeQAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIABFAG4AYQBiAGwAZQBkACAAIAAgACAAIAAgACAAIABEAGkAcwBhAGIAbABlAGQAIAAoAHUAcwBlACAAcwB0AGEAdABpAGMAIAByAG8AdQB0AGUAcwApAA==')))
		}
	    if (${44})
	    {
	     	${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAANAAoAIAAgACAAIAAqACoAIABFAHgAYwBoAGEAbgBnAGUAIAAyADAAMAAzACAAQwBvAGUAeABpAHMAdABlAG4AYwBlACAAVABpAHAAcwAgACoAKgANAAoACQAJAA==')))
		}
	    if (${43})
	    {
	     	${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAANAAoAIAAgACAAIAAqACoAIABFAHgAYwBoAGEAbgBnAGUAIAAyADAAMAA3ACAAQwBvAGUAeABpAHMAdABlAG4AYwBlACAAVABpAHAAcwAgACoAKgA=')))
		}
	    ${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAANAAoAIwA+AA==')))
	
	
	    
		If ((${42}) -and (${20}))
		{
	        ${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKADwAIwANAAoAKgAqACoAKgAgAEUAWABDAEgAQQBOAEcARQAgADIAMAAxADAAIAAtACAAVwBpAG4AZABvAHcAcwAgADIAMAAwADgAIABSADIAIAAqACoAKgAqAA0ACgAjAD4A')))
			
			If (${41})	
			{
				${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKADwAIwANAAoAKgAqACoAKgAgAEUAWABDAEgAQQBOAEcARQAgADIAMAAxADAAIAAtACAASABVAEIALwBDAEEAUwAgAFMARQBSAFYARQBSAFMAIAAqACoAKgAqAA0ACgAjAD4ADQAKAA==')))
				${40} = (${41} | Select -Unique -ExpandProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))))
				foreach (${22} in ${40})
				{
					${15} += @"

#--------------------------------------------- 
# $(${22}.ToUpper()) - Prerequisites
#---------------------------------------------
# Run this via an administrative powershell console

Set-ExecutionPolicy RemoteSigned
Import-Module ServerManager
Enable-PSRemoting -Force
Add-WindowsFeature NET-Framework,RSAT-ADDS,Web-Server,Web-Basic-Auth,Web-Windows-Auth,Web-Metabase,Web-Net-Ext,Web-Lgcy-Mgmt-Console,WAS-Process-Model,RSAT-Web-Server,Web-ISAPI-Ext,Web-Digest-Auth,Web-Dyn-Compression,NET-HTTP-Activation,Web-Asp-Net,Web-Client-Auth,Web-Dir-Browsing,Web-Http-Errors,Web-Http-Logging,Web-Http-Redirect,Web-Http-Tracing,Web-ISAPI-Filter,Web-Request-Monitor,Web-Static-Content,Web-WMI,RPC-Over-HTTP-Proxy -Restart

# After the server has rebooted run this via an administrative powershell console
	Set-Service NetTcpPortSharing -StartupType Automatic

<# Per Technet documentation (http://technet.microsoft.com/en-us/library/bb691354.aspx) do the following:
	
 The following hotfix is required for Windows Server 2008 R2 and must be installed after the operating system 
 prerequisites have been installed:
   - Install the hotfix described in Knowledge Base article 982867, WCF services that are hosted by computers together 
    with a NLB fail in .NET Framework 3.5 SP1. For more information, see these MSDN Code Gallery pages:
        http://go.microsoft.com/fwlink/?linkid=3052&kbid=982867
        For additional background information, see KB982867 - WCF: Enable WebHeader settings on the RST/SCT.
            http://go.microsoft.com/fwlink/?LinkId=199857
        For the available downloads, see KB982867 - WCF: Enable WebHeader settings on the RST/SCT.
            http://go.microsoft.com/fwlink/?LinkId=199858

 Download and install the Office 2010 Filter Packs
  http://www.microsoft.com/en-us/download/details.aspx?id=17062

 After installing the preceding prerequisites, and before installing Exchange 2010, 
 it is recommended that you install any critical or recommended updates from Microsoft Update and reboot.
#>
"@
				}
			}
			
			If (${39})
			{
				${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAIAAgACAADQAKADwAIwANAAoAKgAqACoAKgAgAEUAWABDAEgAQQBOAEcARQAgADIAMAAxADAAIAAtACAATQBBAEkATABCAE8AWAAgAFMARQBSAFYARQBSAFMAIAAqACoAKgAqAA0ACgAjAD4ADQAKAA==')))
			${38} = (${39} | Select -Unique -ExpandProperty $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))))
			foreach (${22} in ${38})
			{
				${15} += @"

#--------------------------------------------- 
# $(${22}.ToUpper()) - Prerequisites
#---------------------------------------------
#
# Run this via an administrative powershell console
Set-ExecutionPolicy RemoteSigned
Import-Module ServerManager
Enable-PSRemoting -Force
Add-WindowsFeature NET-Framework,RSAT-ADDS,Web-Server,Web-Basic-Auth,Web-Windows-Auth,Web-Metabase,Web-Net-Ext,Web-Lgcy-Mgmt-Console,WAS-Process-Model,RSAT-Web-Server -Restart

<# Per Technet documentation (http://technet.microsoft.com/en-us/library/bb691354.aspx) do the following:
	
The following hotfix is required for Windows Server 2008 R2 and must be installed after the operating system prerequisites have been installed:
   Install the hotfix described in Knowledge Base article 982867, WCF services that are hosted by computers together with a NLB 
   fail in .NET Framework 3.5 SP1. For more information, see these MSDN Code Gallery pages:
      http://go.microsoft.com/fwlink/?linkid=3052&kbid=982867
        For additional background information, see KB982867 - WCF: Enable WebHeader settings on the RST/SCT.
            http://go.microsoft.com/fwlink/?LinkId=199857
        For the available downloads, see KB982867 - WCF: Enable WebHeader settings on the RST/SCT.
            http://go.microsoft.com/fwlink/?LinkId=199858

After installing the preceding prerequisites, and before installing Exchange 2010, it is recommended 
that you install any critical or recommended updates from Microsoft Update and reboot.
#>
"@
				}
			}
		}
		Return ${15}
	}
	
	function Generate-CASConfiguration 
	{
		${15} = ''
		
		If (${37})	
		{
			${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAcgBlAGcAaQBvAG4AIABIAHUAYgAvAEMAQQBTACAALQAgAEUAeAB0AGUAcgBuAGEAbAANAAoAPAAjAA0ACgAqACoAKgAqACAARQBYAEMASABBAE4ARwBFACAAMgAwADEAMAAgAC0AIABFAFgAVABFAFIATgBBAEwAIABIAFUAQgAvAEMAQQBTACAAUwBFAFIAVgBFAFIAUwAgACoAKgAqACoADQAKACMAPgANAAoA')))
			${36} = ${37} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Unique
			ForEach (${22} in ${36})
			{            
				${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - External Hub/CAS Config
#-------------------------------------------------
"@
	    
		        if (${31})
	            {
	                ${15} += @"

`$remotecmd = {   
    # Functions
    function Get-Exchange2010InstallPath	
    {
        # Get the root setup entries.
        `$setupRegistryPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\v14\Setup"
        `$setupEntries = Get-ItemProperty `$setupRegistryPath
        if(`$setupEntries -eq `$null) {
            return `$null
        }

        # Try to get the Install Path.
        `$InstallPath = `$setupEntries.MsiInstallPath
        return `$InstallPath
    }

    # Module/Snapin/Dot Sourcing
    if (! (Get-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction:SilentlyContinue) )
    { 
    	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 
    }
    Import-Module WebAdministration
    
    Backup-WebConfiguration -Name $(${22}."Server Name")-IISBackup

    # Setup http redirection on external cas
    Write-Host "``n"
	Write-Host "$(${22}."Server Name") - Setting SSL configuration" -ForegroundColor green	
    Set-WebConfigurationProperty -Filter //security/access -name sslflags -Value "" -PSPath IIS:\ -Location "Default Web Site/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name enabled -Value "true" -PSPath IIS:\ -Location "Default Web Site/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name destination -Value "https://$(${22}."CAS URL")/owa" -PSPath IIS:\ -Location "Default Web Site/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name ChildOnly -Value "true" -PSPath IIS:\ -Location "Default Web Site/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name httpResponseStatus -Value "Found" -PSPath IIS:\ -Location "Default Web Site/"
	
	# Fix redirection of non owa external directories
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Default Web Site\Autodiscover" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Default Web Site\ews" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Default Web Site\Microsoft-Server-ActiveSync" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Default Web Site\OAB" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}

    # Fix OAB virtual directory permission issues
    `$PathToFile = (Get-Exchange2010InstallPath)+"ClientAccess\OAB\web.config"
    `$runcmd = icacls `$PathToFile /grant:R 'NT Authority\Authenticated Users:RX'
    `$runcmd

    # Be nice and restart IIS
    `$runcmd = iisreset
    `$runcmd
"@
				}
	            ${15} += @"
            
}

Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock `$remotecmd
"@
	            if (${35})
	            {
	                ${15} += @"
                
# External Authentication
Set-OwaVirtualDirectory "$(${22}."Server Name")(default web site)\owa" -ExternalUrl "https://$(${22}."CAS URL")/owa" -ExternalAuthenticationMethods "Basic" -BasicAuthentication $true -FormsAuthentication $false
Set-ECPVirtualDirectory "$(${22}."Server Name")(default web site)\ecp" -ExternalUrl "https://$(${22}."CAS URL")/owa" -ExternalAuthenticationMethods "Basic" -BasicAuthentication $true -FormsAuthentication $false
"@
				}
			}
	        ${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAZQBuAGQAcgBlAGcAaQBvAG4AIABIAHUAYgAvAEMAQQBTACAALQAgAEUAeAB0AGUAcgBuAGEAbAA=')))
		}
	
		
		If (${34})	
		{
			${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAcgBlAGcAaQBvAG4AIABIAHUAYgAvAEMAQQBTACAALQAgAEkAbgB0AGUAcgBuAGEAbAANAAoAPAAjAA0ACgAqACoAKgAqACAARQBYAEMASABBAE4ARwBFACAAMgAwADEAMAAgAC0AIABJAE4AVABFAFIATgBBAEwAIABIAFUAQgAvAEMAQQBTACAAUwBFAFIAVgBFAFIAUwAgACoAKgAqACoADQAKACMAPgA=')))
			${33} = ${34} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Unique
	
			
			ForEach (${22} in ${33})
			{
				${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - Internal Hub/CAS Config
#-------------------------------------------------
                
`$remotecmd = {   
    # Functions
    function Get-Exchange2010InstallPath	
    {
        # Get the root setup entries.
        `$setupRegistryPath = "HKLM:\SOFTWARE\Microsoft\ExchangeServer\v14\Setup"
        `$setupEntries = Get-ItemProperty `$setupRegistryPath
        if(`$setupEntries -eq `$null) {
            return `$null
        }

        # Try to get the Install Path.
        `$InstallPath = `$setupEntries.MsiInstallPath
        return `$InstallPath
    }

    # Module/Snapin/Dot Sourcing
    if (! (Get-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction:SilentlyContinue) )
    { 
    	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 
    }
    Import-Module WebAdministration

    # Create folder on $(${22}."Server Name") for internal facing website
    New-Item -Path $(${32}) -type directory -Force 
    Write-Host "Folder creation complete"
    
    Backup-WebConfiguration -Name $(${22}."Server Name")-IISBackup
	# Create the new internal site and virtual directories
	New-Website -Name "Exchange-Internal" -IPAddress $(${22}."IP") -PhysicalPath $(${32}) -Port 443 -Ssl
	Set-WebBinding -Name "Exchange-Internal" -IPAddress $(${22}."IP") -Port 80
	Remove-WebBinding -Name "Exchange-Internal" -IPAddress "127.0.0.1" -Port 443
	Remove-WebBinding -Name "Exchange-Internal" -IPAddress "127.0.0.1" -Port 80
	New-ActiveSyncVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."CAS URL")/Microsoft-Server-ActiveSync"
	New-WebServicesVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."CAS URL")/ews/exchange.asmx" -Force
	New-AutodiscoverVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."Autodiscover URL")/autodiscover"
	New-OWAVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."CAS URL")/owa"
	New-OABVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."CAS URL")/OAB"
	New-ECPVirtualDirectory -WebSiteName "Exchange-Internal" -InternalURL "https://$(${22}."CAS URL")/ECP"

"@
	            if (${31})
	            {
	                ${15} += @"

	# Make ssl a requirement on the root directory
	Set-WebConfigurationProperty -Filter //security/access -name sslflags -Value "Ssl" -PSPath IIS:\ -Location "Exchange-Internal/"
	
	#Setup http redirection
	Set-WebConfigurationProperty -Filter //httpRedirect -Name enabled -Value "true" -PSPath IIS:\ -Location "Exchange-Internal/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name destination -Value "https://$(${22}."CAS URL")/owa" -PSPath IIS:\ -Location "Exchange-Internal/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name ChildOnly -Value "true" -PSPath IIS:\ -Location "Exchange-Internal/"
	Set-WebConfigurationProperty -Filter //httpRedirect -Name httpResponseStatus -Value "Found" -PSPath IIS:\ -Location "Exchange-Internal/"

	# Fix redirection of non owa-internal directories
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Exchange-Internal\Autodiscover" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Exchange-Internal\ews" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Exchange-Internal\Microsoft-Server-ActiveSync" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
	Set-WebConfiguration system.webserver/httpRedirect "IIS:\sites\Exchange-Internal\OAB" -Value @{enabled="false";destination="";ChildOnly="true";httpResponseStatus="Found"}
    
    # Fix OAB virtual directory permission issues
    `$PathToFile = (Get-Exchange2010InstallPath)+"ClientAccess\OAB\web.config"
    `$runcmd = icacls `$PathToFile /grant:R 'NT Authority\Authenticated Users:RX'
    `$runcmd

    # Be nice and restart IIS
    `$runcmd = iisreset
    `$runcmd
"@
				}
	            ${15} += @"
            
}

Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock `$remotecmd
"@
			}
	        ${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgAA0ACgAjAGUAbgBkAHIAZQBnAGkAbwBuACAASAB1AGIALwBDAEEAUwAgAC0AIABJAG4AdABlAHIAbgBhAGwA')))
		}
		If (${30}.Count -ge 1)
		{
			${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAcgBlAGcAaQBvAG4AIABOAEwAQgAgAEMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4ADQAKADwAIwANAAoAKgAqACoAKgAgAEUAWABDAEgAQQBOAEcARQAgADIAMAAxADAAIAAtACAATgBMAEIAIABDAE8ATgBGAEkARwAgACoAKgAqACoADQAKACMAPgANAAoA')))
			${29} = ${30} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Unique
	
			
			ForEach (${22} in ${29})
			{
				${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - Add NLB Feature
#-------------------------------------------------
Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock {
	Import-Module ServerManager
	Add-WindowsFeature NLB, RSAT-NLB	
}
"@
			}
			
			if (${28})
			{
				${27} = ${28} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Unique
				${24} = 0
				
				ForEach (${22} in ${27})
				{
					${24}++
					if (${24} -eq 1)
					{
						${23} = ${22}
						${15} += @"

#-------------------------------------------------
# $((${22}."Server Name").ToUpper()) - Configure External NLB Cluster
#-------------------------------------------------
Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock {
	`$runcmd = Netsh interface ipv4 set int $(${22}."Interface Name") forwarding=enabled
	`$runcmd
	if(`$runcmd -match 'ok'){write-Host "forwarding is enabled"}
    else{write-Host "Failed to configure forwarding on interface"}
	Import-Module NetworkLoadBalancingClusters
	New-NlbCluster -InterfaceName $(${22}."Interface Name") -ClusterName CAS-External -HostName $(${22}."Server Name") -ClusterPrimaryIP $(${22}."NLB or DAG IP")
	Get-NlbClusterPortRule | Remove-NlbClusterPortRule -Force
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 80 -EndPort 80 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 443 -EndPort 443 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 135 -EndPort 135 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 1024 -EndPort 65535 -Protocol Both -Affinity Single
}
"@
					}
					else
					{
						${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - Configure External NLB Members
#-------------------------------------------------
Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock {
	`$runcmd = netsh interface ipv4 set int $(${22}."Interface Name") forwarding=enabled
	`$runcmd
	if(`$runcmd -match 'ok'){write-Host "forwarding is enabled"}
    else{write-Host "Failed to configure forwarding on interface"}
	Import-Module NetworkLoadBalancingClusters
	Get-NlbCluster -Hostname $(${23}."Server Name")  -InterfaceName $(${23}."Interface Name") | Add-NlbClusterNode -NewNodeName $(${22}."Server Name") -NewNodeInterface $(${22}."Interface Name")
}
"@
					}
				}
			}
			
			
			
			if (${26})
			{
				${25} = ${26} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBlAHIAdgBlAHIAIABOAGEAbQBlAA=='))) -Unique
				${24} = 0
				
				ForEach (${22} in ${25})
				{
					${24}++
					if (${24} -eq 1)
					{
						${23} = ${22}
						${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - Configure Internal NLB Cluster
#-------------------------------------------------
Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock {
	`$runcmd = Netsh interface ipv4 set int $(${22}."Interface Name") forwarding=enabled
	`$runcmd
	if(`$runcmd -match 'ok'){write-Host "forwarding is enabled"}
    else{write-Host "Failed to configure forwarding on interface"}
	Import-Module NetworkLoadBalancingClusters
	New-NlbCluster -InterfaceName $(${22}."Interface Name") -ClusterName CAS-Internal -HostName $(${22}."Server Name") -ClusterPrimaryIP $(${22}."NLB or DAG IP")
	Get-NlbClusterPortRule | Remove-NlbClusterPortRule -Force
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 80 -EndPort 80 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 443 -EndPort 443 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 135 -EndPort 135 -Protocol TCP -Affinity Single
	Get-NlbCluster | Add-NlbClusterPortRule -StartPort 1024 -EndPort 65535 -Protocol Both -Affinity Single
}
"@
					}
					else
					{
						${15} += @"

#------------------------------------------------ 
# $((${22}."Server Name").ToUpper()) - Configure Internal NLB Members
#-------------------------------------------------
Invoke-Command -ComputerName $(${22}."IP") -ScriptBlock {
	`$runcmd = netsh interface ipv4 set int $(${22}."Interface Name") forwarding=enabled
	`$runcmd
	if(`$runcmd -match 'ok'){write-Host "forwarding is enabled"}
    else{write-Host "Failed to configure forwarding on interface"}
	Import-Module NetworkLoadBalancingClusters
	Get-NlbCluster -Hostname $(${23}."Server Name")  -InterfaceName $(${23}."Interface Name") | Add-NlbClusterNode -NewNodeName $(${22}."Server Name") -NewNodeInterface $(${22}."Interface Name")
}
"@
					}
				}
			}
			
		${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAZQBuAGQAcgBlAGcAaQBvAG4AIABOAEwAQgAgAEMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4A')))
		}
		If (${21})
		{
	        	${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAcgBlAGcAaQBvAG4AIABDAEEAUwAgAEEAcgByAGEAeQAgAEcAZQBuAGUAcgBhAHQAaQBvAG4ADQAKADwAIwANAAoAKgAqACoAKgAgAEUAWABDAEgAQQBOAEcARQAgADIAMAAxADAAIAAtACAAQwBBAFMAIABBAHIAcgBhAHkAIABHAGUAbgBlAHIAYQB0AGkAbwBuACAAKgAqACoAKgANAAoAIwA+AA0ACgANAAoAIwAjACAATgBPAFQARQA6ACAASQBmACAAeQBvAHUAIABhAHIAZQAgAHMAZQB0AHQAaQBuAGcAIAB0AGgAaQBzACAAdQBwACAAdABoAGUAbgAgAHkAbwB1ACAAcgBlAGEAbABsAHkADQAKACMAIwAgACAAIAAgACAAIAAgAG4AZQBlAGQAIAB0AG8AIABsAG8AbwBrACAAYQBuAGQAIABtAGEAawBlACAAcwB1AHIAZQAgAHQAaABlAHMAZQAgAEMAQQBTACAAYQByAHIAYQB5AA0ACgAjACMAIAAgACAAIAAgACAAIABuAGEAbQBlAHMAIABhAHIAZQAgAHcAaABhAHQAIAB3AG8AcgBrAHMAIABpAG4AIAB5AG8AdQByACAAZQBuAHYAcgBpAHIAbwBuAG0AZQBuAHQADQAKACMAIwAgACAAIAAgACAAIAAgACgAaQB0ACAAaQBzACAAVgBFAFIAWQAgAHUAbgBsAGkAawBlAGwAeQAgAHQAaABhAHQAIAB0AGgAZQB5ACAAYQByAGUAIQApAA0ACgAjACMAIAAgACAAIAAgACAAIABVAHMAdQBhAGwAbAB5ACAAdABoAGUAcwBlACAAQwBBAFMAIABhAHIAcgBhAHkAIABuAGEAbQBlAHMAIABhAHIAZQAgAHQAaABlACAAcwBhAG0AZQANAAoAIwAjACAAIAAgACAAIAAgACAAYQBzACAAdABoAGUAIABhAGMAYwBlAHMAcwAgAFUAUgBMACAAZgBvAHIAIABlAG4AZAAgAHUAcwBlAHIAcwAgAGkAbgAgAHMAbQBhAGwAbABlAHIADQAKACMAIwAgACAAIAAgACAAIAAgAGQAZQBwAGwAbwB5AG0AZQBuAHQAcwAgAHcAaQB0AGgAIABhACAAcwBpAG4AZwBsAGUAIABwAG8AaQBuAHQAIABvAGYAIABhAGMAYwBlAHMAcwAuACAAIAAgACAAIAA=')))
			${19} = ${20} | sort-object -Property $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAHQAZQA='))) -Unique
			
			Foreach (${16} in ${19})
			{
				If (${18})
	            {
					${15} += @"
			
#------------------------------------------------ 
# $((${16}."Site").ToUpper()) - CAS Array
#-------------------------------------------------
	New-ClientAccessArray -fqdn $(${16}."Site")-Array.$(${16}."Internal Domain") -site $(${16}."Site")
"@
				}
				Else
				{
					${15} += @"
			
#------------------------------------------------ 
# $((${16}."Site").ToUpper()) - CAS Array
#-------------------------------------------------
	New-ClientAccessArray -fqdn $(${16}."Site")-Array.$(${17}) -site $(${16}."Site")
"@
				}
			}
		}
	    ${15} += $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('DQAKACMAZQBuAGQAcgBlAGcAaQBvAG4AIABDAEEAUwAgAEEAcgByAGEAeQAgAEcAZQBuAGUAcgBhAHQAaQBvAG4A')))
		Return ${15}
	}
	
	
	function Get-Type 
	{ 
	    param(${f3}) 
	 
	${14} = @( 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBCAG8AbwBsAGUAYQBuAA=='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBCAHkAdABlAFsAXQA='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBCAHkAdABlAA=='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBDAGgAYQByAA=='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABlAHQAaQBtAGUA'))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGUAYwBpAG0AYQBsAA=='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAG8AdQBiAGwAZQA='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBHAHUAaQBkAA=='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBJAG4AdAAxADYA'))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBJAG4AdAAzADIA'))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBJAG4AdAA2ADQA'))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBTAGkAbgBnAGwAZQA='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBVAEkAbgB0ADEANgA='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBVAEkAbgB0ADMAMgA='))), 
	$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBVAEkAbgB0ADYANAA=')))) 
	 
	    if ( ${14} -contains ${f3} ) { 
	        Write-Output $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7AGYAMwB9AA=='))) 
	    } 
	    else { 
	        Write-Output $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBTAHQAcgBpAG4AZwA='))) 
	         
	    } 
	} 
	 
	
	 
	function Out-DataTable 
	{ 
	    [CmdletBinding()] 
	    param([Parameter(Position=0, Mandatory=$true, ValueFromPipeline = $true)] [PSObject[]]${f2}) 
	 
	    Begin 
	    { 
	        ${8} = new-object Data.datatable   
	        ${9} = $true  
	    } 
	    Process 
	    { 
	        foreach (${13} in ${f2}) 
	        { 
	            ${10} = ${8}.NewRow()   
	            foreach(${11} in ${13}.PsObject.get_properties()) 
	            {   
	                if (${9}) 
	                {   
	                    ${12} =  new-object Data.DataColumn   
	                    ${12}.ColumnName = ${11}.Name.ToString()   
	                    if (${11}.value) 
	                    { 
	                        if (${11}.value -isnot [System.DBNull]) { 
	                            ${12}.DataType = [System.Type]::GetType("$(Get-Type ${11}.TypeNameOfValue)") 
	                         } 
	                    } 
	                    ${8}.Columns.Add(${12}) 
	                }   
	                if (${11}.IsArray) { 
	                    ${10}.Item(${11}.Name) =${11}.value | ConvertTo-XML -AS String -NoTypeInformation -Depth 1 
	                }   
	               else { 
	                    ${10}.Item(${11}.Name) = ${11}.value 
	                } 
	            }   
	            ${8}.Rows.Add(${10})   
	            ${9} = $false 
	        } 
	    }  
	      
	    End 
	    { 
	        Write-Output @(,(${8})) 
	    } 
	 
	} 
	
	
	function Get-ScriptDirectory
	{ 
		if($hostinvocation -ne $null)
		{
			Split-Path $hostinvocation.MyCommand.path
		}
		else
		{
			Split-Path $script:MyInvocation.MyCommand.Path
		}
	}
	
	
	[string]${7} = Get-ScriptDirectory
	



function Call-ChildForm_pff
{



	
	
	
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgA3ADcAYQA1AGMANQA2ADEAOQAzADQAZQAwADgAOQA='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAHIAYQB3AGkAbgBnACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIAMAAzAGYANQBmADcAZgAxADEAZAA1ADAAYQAzAGEA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQBzAGMAbwByAGwAaQBiACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGEAdABhACwAIABWAGUAcgBzAGkAbwBuAD0AMgAuADAALgAwAC4AMAAsACAAQwB1AGwAdAB1AHIAZQA9AG4AZQB1AHQAcgBhAGwALAAgAFAAdQBiAGwAaQBjAEsAZQB5AFQAbwBrAGUAbgA9AGIANwA3AGEANQBjADUANgAxADkAMwA0AGUAMAA4ADkA'))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBYAG0AbAAsACAAVgBlAHIAcwBpAG8AbgA9ADIALgAwAC4AMAAuADAALAAgAEMAdQBsAHQAdQByAGUAPQBuAGUAdQB0AHIAYQBsACwAIABQAHUAYgBsAGkAYwBLAGUAeQBUAG8AawBlAG4APQBiADcANwBhADUAYwA1ADYAMQA5ADMANABlADAAOAA5AA=='))))
	[void][reflection.assembly]::Load($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBEAGkAcgBlAGMAdABvAHIAeQBTAGUAcgB2AGkAYwBlAHMALAAgAFYAZQByAHMAaQBvAG4APQAyAC4AMAAuADAALgAwACwAIABDAHUAbAB0AHUAcgBlAD0AbgBlAHUAdAByAGEAbAAsACAAUAB1AGIAbABpAGMASwBlAHkAVABvAGsAZQBuAD0AYgAwADMAZgA1AGYANwBmADEAMQBkADUAMABhADMAYQA='))))
	

	
	
	
	[System.Windows.Forms.Application]::EnableVisualStyles()
	${1} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQA=')))
	${5} = New-Object $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzAC4ARgBvAHIAbQBXAGkAbgBkAG8AdwBTAHQAYQB0AGUA')))
	

	
	
	
	
	
	${6}={
		
		
	}
	
		
	
	
	
	
	${4}=
	{
		
		${1}.WindowState = ${5}
	}
	
	${2}=
	{
		
	}

	
	${3}=
	{
		
		try
		{
			${1}.remove_Load(${6})
			${1}.remove_Load(${4})
			${1}.remove_Closing(${2})
			${1}.remove_FormClosed(${3})
		}
		catch [Exception]
		{ }
	}
	

	
	
	
	
	
	
	${1}.ClientSize = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MgA4ADQALAAgADIANgAyAA==')))
	${1}.Name = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ZgBvAHIAbQAxAA==')))
	${1}.Text = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAGkAbQBhAGwAIABGAG8AcgBtAA==')))
	${1}.add_Load(${6})
	

	

	
	${5} = ${1}.WindowState
	
	${1}.add_Load(${4})
	
	${1}.add_FormClosed(${3})
	
	${1}.add_Closing(${2})
	
	return ${1}.ShowDialog()

}



Main (${f1})
