﻿#This sample is provided as is and is not meant for use on a 
#production environment. It is provided only for illustrative 
#purposes. The end user must test and modify the sample to suit 
#their target environment.
#
#Microsoft can make no representation concerning the content of 
#this sample. Microsoft is providing this information only as a 
#convenience to you. This is to inform you that Microsoft has not 
#tested the sample and therefore cannot make any representations 
#regarding the quality, safety, or suitability of any code or 
#information found here.
${12} = "localhost"
${11} = "root\sms\site_CAS"
${24} = ".\Desktop\ApprovalsSnippet.txt"
${30} = "localhost"
${29} = "CM_CAS"
${4} = New-Object System.Data.SqlClient.SqlConnection
${4}.ConnectionString = "Server = ${30}; Database =
${29}; Integrated Security = True"
${19} = New-Object System.Data.SqlClient.SqlCommand
${1} = Get-Date
echo "Beginning to parse input file, ${24}.`t${1}"
${28} = Import-CSV ${24} -Delimiter "`t"
${23} = @{}
${1} = Get-Date
echo "Completed parse of input file, ${24}.`t ${1}"
${1} = Get-Date
echo "Beginning sort of input file, ${24}.`t ${1}"
${3} = 0
foreach(${25} in ${28})
{
    ${27} = (${3} / ${28}.Length * 100)
    Write-Progress -Activity "Sorting approvals by Computer Group" -Status "Progress ${27}%" -percentcomplete ${27} 
    if(${23}.ContainsKey(${25}.ComputerGroupName) -eq $False)
    {
        ${26} = @{}
        ${26}.Add(${25}.UpdateGUID, ${25}.UpdateTitle + "`t" + ${25}.UpdateArticleId)
        ${23}.Add(${25}.ComputerGroupName,${26})
    }
    else
    {
        ${23}[${25}.ComputerGroupName].Add(${25}.UpdateGUID, ${25}.UpdateTitle + "`t" + ${25}.UpdateArticleId)
    }
    ${3}++
}
Write-Progress -Activity "Sorting approvals by Computer Group" -Status "progress ->" -Completed
${1} = Get-Date
echo "Completed sort of input file, ${24}. Found ${3} approvals.`t ${1}"
${2} = 1
${1} = Get-Date
echo "--> Starting to work through results...`t ${1}"
foreach(${6} in ${23}.Keys)
{
    ${1} = Get-Date
    echo "-> Creating software update group for ${6}.`t ${1}"
    Write-Progress -Activity "Creating Software Update Groups:" -Status "Working..." -percentcomplete (${2} / ${23}.Count * 100) -CurrentOperation "at ${6}."
    #[int32[]]$arrayofCIidsFound = 0
    ${15} = ${6}
    ${14} = 0
    ${5} = 0
    ${22} = ${23}[${6}].Count
    foreach(${21} in ${23}[${6}].Keys)
    {
        Write-Progress -Activity "Inserting updates into ${15}" -Status "Found ${5} of ${14} processed updates and ${22} total updates..." -percentcomplete (${14} / ${22} * 100) -CurrentOperation "at ${21}"
        ${20} = "SELECT CI_ID AS CIID FROM v_UpdateInfo WHERE CI_UniqueID = '${21}'"
        ${19}.CommandText = ${20}
        ${19}.Connection = ${4}
        ${18} = New-Object System.Data.SqlClient.SqlDataAdapter
        ${18}.SelectCommand = ${19}
        ${16} = New-Object System.Data.DataSet
        ${17} = ${18}.Fill(${16})
        if(${17} -eq 0)
        {}
        else
        {
            if(${5} -eq 0)
            {
                #DEBUG#$dataset.Tables[0].Rows[0].CIID
                [int32[]]${9} += ${16}.Tables[0].Rows[0].CIID
            }
            else
            {
                #DEBUG#$dataset.Tables[0].Rows[0].CIID
                ${9} += ${16}.Tables[0].Rows[0].CIID
            }
            ${5}++
        }
        ${14}++
    }
    #DEBUG#$arrayofCIidsFound
    Write-Progress -Activity "Inserting updates into ${15}" -Status "Found $iCount updates..." -Completed 
    ${1} = Get-Date
    echo "Found ${5} out of ${14} processed updates in site database for ${6}.`t ${1}"
    if(${5} -gt 0)
    {
        ${1} = Get-Date
        echo "Starting creation of ConfigMgr software updat group for ${6}...`t ${1}"
        ${13} = ([WMICLASS] ("\\${12}\${11}" + ":SMS_CI_LocalizedProperties")).CreateInstance()
        ${13}.DisplayName = "WSUS Import - ${6}"
        ${13}.Description = "This update group was imported from a WSUS environment, based on the approvals assigned to the '${6}' computer group"
        ${13}.LocaleID = 1033
        [System.Management.ManagementObject[]] ${10} += ${13}
        ${8} = ([WMICLASS] ("\\${12}\${11}" + ":SMS_AuthorizationList")).CreateInstance()
        ${8}.LocalizedInformation = ${10}
        ${8}.Updates = ${9}
        ${7} = ${8}.Put()
        if(${7}.Path -gt "")
        {
            ${1} = Get-Date
            echo "Completed creation of ConfigMgr software update group for ${6}.`t ${1}"
        }
        else
        {
            ${1} = Get-Date
            echo "Failed to create the ${6} group as a ConfigMgr software update group.`t ${1}"
        }
    }
    else
    {
        ${1} = Get-Date
        echo "${5} updates for this approval group, skipping ConfigMgr object creation.`t ${1}"
    }
    rd variable:arrayofCIidsFound
    ${2}++
}
${4}.Close()
${1} = Get-Date
echo "--> Finished processing ${3} approvals into ${2} software update groups. Shutting down.`t ${1}"