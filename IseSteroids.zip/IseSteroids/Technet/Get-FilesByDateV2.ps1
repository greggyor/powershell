﻿# -----------------------------------------------------------------------------
# Script: Get-FilesByDateV2.ps1
# Author: ed wilson, msft
# Date: 05/28/2012 16:07:04
# Keywords: 
# comments: 
#
# -----------------------------------------------------------------------------
Function Get-FilesByDate
{
 Param(
  [string[]]$fileTypes = @(".DOC","*.DOCX"),
  [Parameter(Mandatory=$true)]
  [int]$month,
  [Parameter(Mandatory=$true)]
  [int]$year,
  [Parameter(Mandatory=$true)]
  [string[]]$path)
   ls -Path $path -Include $filetypes -Recurse |
   ? { 
   $_.lastwritetime.month -eq $month -AND $_.lastwritetime.year -eq $year }
  } #end function Get-FilesByDate