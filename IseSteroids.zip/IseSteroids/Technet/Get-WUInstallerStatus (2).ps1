﻿Function Get-WUInstallerStatus
{
    
	
	[CmdletBinding(
    	SupportsShouldProcess=$True,
        ConfirmImpact="Low"
    )]
    Param()
	
	Begin{}
	
	Process
	{
        if ($pscmdlet.ShouldProcess($Env:COMPUTERNAME,"Check that Windows Installer is ready to install next updates")) 
		{	    
			${1}=New-Object -ComObject "Microsoft.Update.Installer"
		    if(${1}.IsBusy)
		    {
		        Write-Host "Installer is busy."
		    }
		    else
		    {
		        Write-Host "Installer is ready."
		    }
		}
	}
	
	End{}	
}