﻿
${4}	= "c:\temp"				
${1}		= 15					
${5}		= gc env:computername	
if (${1} -le 60) {${1} = 60}	
${3}		= 0
function New-Zip
{
	param([string]${f1})
	set-content ${f1} ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
	(dir ${f1}).IsReadOnly = $false
}
function Add-Zip
{
	param([string]${f1})
	if(-not (test-path(${f1})))
	{
		set-content ${f1} ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
		(dir ${f1}).IsReadOnly = $false	
	}
	${13} = new-object -com shell.application
	${12} = ${13}.NameSpace(${f1})
	foreach(${11} in $input) 
	{ 
		${12}.CopyHere(${11}.FullName)
		Start-sleep -milliseconds 500
	}
}
cls
Write-Host "`n"
Write-Host " WARNING: This script sample is provided AS-IS with no warranties and confers no rights." -ForegroundColor Yellow 
Write-Host "          This script sample is NOT intended for production use." -ForegroundColor Yellow 
Write-Host "          There is NO error handling and is not ready for mission-critical work." -ForegroundColor Yellow 
Write-Host "`n This script sample will attempt to output and archive port usage information`n" 
if (Test-Path ($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQBcACQAewA1AH0AIABuAGUAdABzAHQAYQB0ACAAYQByAGMAaABpAHYAZQAuAHoAaQBwAA=='))))) {} else {new-zip $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQBcACQAewA1AH0AIABuAGUAdABzAHQAYQB0ACAAYQByAGMAaABpAHYAZQAuAHoAaQBwAA==')))}
do 
{
	${2}	= get-date
	${10} 	= ${2}.Year
	${9} 	= ${2}.Month
	${8} 	= ${2}.Day
	${7} 	= ${2}.Hour
	${6} = ${2}.Minute
	if (${6} -le 9) {${6} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAAkAHsANgB9AA==')))}
	netstat -ano > "${4}\netstat ${5} ${10}-${9}-${8} ${7}${6}.txt"
	dir ${4}"\*.txt" | add-zip $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADQAfQBcACQAewA1AH0AIABuAGUAdABzAHQAYQB0ACAAYQByAGMAaABpAHYAZQAuAHoAaQBwAA==')))
	del ${4}"\netstat*.txt"
	${2} = ${2}.AddSeconds(${1})
	${3} = ${3}+1
	Write-Host "_________________________________________________________" -ForegroundColor Green
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABhAHQAYQAgAHMAZQB0AHMAIABjAG8AbABsAGUAYwB0AGUAZAAgADoAIAAkAHsAMwB9AA==')))
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHgAdAAgAHIAdQBuACAAIAAgACAAIAAgACAAIAAgACAAIAAgADoAIAAkAHsAMgB9AA==')))
	Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CgBQAGEAdQBzAGkAbgBnACAAJAB7ADEAfQAgAHMAZQBjAG8AbgBkAHMALgAuAC4AIABQAHIAZQBzAHMAIABDAFQAUgBMAC0AQwAgAHQAbwAgAHMAdABvAHAAIAB0AGgAZQAgAHMAYwByAGkAcAB0AA=='))) -ForegroundColor Yellow
	Start-Sleep -s ${1}
} until (1 -eq 0)
