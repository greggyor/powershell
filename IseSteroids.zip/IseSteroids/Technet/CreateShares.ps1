﻿































param(
    [hashtable[]]
    $FileShare 
    )
Set-strictMode -version 2

function Fileshare {
    param(
    [string]
    [ValidateSet('Storage','Witness')]
        $Type='Storage',
    [string]
    [Parameter( Mandatory=$True )]
    [string]
        $Name,
    [Parameter( Mandatory=$True,
        ParameterSetName='FullPath' )]
    [string]
        $Path,
    [Parameter( Mandatory=$True )]
    [String[]] 
        $Fullaccess,
    [Parameter( Mandatory=$True,
        ParameterSetName='DiskNumber' )]
    [ValidateScript({$_ -as [UInt32]})]    
    [string]
        $DiskNumber, 
    [Parameter( Mandatory=$True,
        ParameterSetName='VDiskFriendlyName' )]
    [string]
        $VDiskFriendlyName,
    [Parameter( Mandatory=$True,
        ParameterSetName='VDiskFriendlyName' )]
    [Parameter( Mandatory=$True,
        ParameterSetName='DiskNumber' )]
    [string]
        $SubPath 
    )
    $PSBoundParameters 
}

function _/==\/\_/=\/\__/=\ {
    param(
    [Parameter(
        Mandatory=$true,
        ParameterSetName = 'DiskNumber'
        )] 
    [validatescript({$_ -ne $null})]           
    [int]
    $DiskNumber,
    [Parameter(
        Mandatory=$true,
        ParameterSetName = 'VirtualDiskFriendlyName'
        )]
    [string]
    $VirtualDiskFriendlyName
    )

    switch ( $PsCmdlet.ParameterSetName )
    {
        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAawBOAHUAbQBiAGUAcgA='))) { 
            Get-Disk -Number $DiskNumber | 
                get-partition | ? { $_.type -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAZQByAHYAZQBkAA=='))) } | 
                    select -ExpandProperty accesspaths | ? { 
                        $_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAHUAcwB0AGUAcgBTAHQAbwByAGEAZwBlAA=='))) } | % { $_.TrimEnd('\') }
            ; break
        }

        $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VgBpAHIAdAB1AGEAbABEAGkAcwBrAEYAcgBpAGUAbgBkAGwAeQBOAGEAbQBlAA=='))) { 
            Get-ClusterSharedVolume | ? { ( $_ | Get-ClusterParameter virtualdiskname ).value -eq $VirtualDiskFriendlyName } | 
                select -ExpandProperty SharedVolumeInfo | 
                    select -ExpandProperty FriendlyVolumeName |  ? { 
                        $_ -match $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAHUAcwB0AGUAcgBTAHQAbwByAGEAZwBlAA=='))) } | % { $_.TrimEnd('\') }
            ; break
        }
    } 
}

Function _/=\_/=\__/=\/=\/\ {
param(
[string]
[Parameter( Mandatory=$True )]
[string]
    $Name,
[Parameter( Mandatory=$True,
    ParameterSetName='FullPath' )]
[string]
    $Path,
[Parameter( Mandatory=$True )]
[String[]] 
    $Fullaccess,
[Parameter( Mandatory=$True,
    ParameterSetName='DiskNumber' )]
[ValidateScript({$_ -as [UInt32]})]    
[string]
    $DiskNumber, 
[Parameter( Mandatory=$True,
    ParameterSetName='VDiskFriendlyName' )]
[string]
    $VDiskFriendlyName,
[Parameter( Mandatory=$True,
    ParameterSetName='VDiskFriendlyName' )]
[Parameter( Mandatory=$True,
    ParameterSetName='DiskNumber' )]
[string]
    $SubPath 
)
    
    if( $Path )
    {
        $DirectoryPath = $Path
    }
    else
    {    
        
        if( $DiskNumber ) 
        {
            
            $Accesspath = _/==\/\_/=\/\__/=\ -DiskNumber $DiskNumber 

            
            $DirectoryPath = Join-Path -Path $Accesspath -ChildPath $SubPath 
        }  
        if( $VDiskFriendlyName ) {
            
            
            $Accesspath = _/==\/\_/=\/\__/=\ -VirtualDiskFriendlyName $VDiskFriendlyName 
            
            
            $DirectoryPath = Join-Path -Path $Accesspath -ChildPath $SubPath 
        }
    }

    
    if( test-path $DirectoryPath ){
         
    }else {
        
        ni -ItemType Directory -Path  $DirectoryPath 
    }

    
    $acl = Get-Acl $DirectoryPath 
     
    
    $acl.SetAccessRuleProtection($True, $False)
    
    
    $FullAccess | % {          
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($_, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgB1AGwAbABDAG8AbgB0AHIAbwBsAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AdABhAGkAbgBlAHIASQBuAGgAZQByAGkAdAAsACAATwBiAGoAZQBjAHQASQBuAGgAZQByAGkAdAA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAG4AZQA='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAbwB3AA=='))))
        $acl.AddAccessRule($rule)
    }         
    
    
    Set-Acl  $DirectoryPath $acl | Out-null
    
    
    $FullAccess | % {
        icacls $DirectoryPath /grant "${_}:(OI)(CI)(F)" > $null
    }
    
    
    $share = New-SmbShare -Name $Name -Path  $DirectoryPath 
    @( $fullAccess ) | % { $out = Grant-SmbShareAccess $Name  -AccountName $_ -AccessRight full -Confirm:$False  }              
}




 
if ( $Fileshare )
{
    ipmo SmbShare
    ipmo SmbWitness
    If (-not (test-path variable:ParentProgressID)) { $ParentProgressId = -1 }
    
    @( $Fileshare ) | % {
        Write-progress -Activity $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAARgBpAGwAZQBzAGgAYQByAGUAcwA='))) -Status ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBoAGEAcgBlACAAewAwAH0A'))) -f $_.Name) -ParentId $ParentProgressID
        _/=\_/=\__/=\/=\/\ @_ 
    }

} 
 