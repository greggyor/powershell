﻿# OU-Import - 8/12/11
# Copyright Greg Martin gmartin@gmartin.org
# License MS-LPL 
#
# Part of the copyAD suite of Powershell scripts
# Imports a list of OUs 
#
# Warning: AD does not export OUs in order.  Some OUs will fail during creation because their parent container 
# has not yet been created.  This can be solved by re-running script until all generate an error!

#Import-Module ActiveDirectory -ErrorAction SilentlyContinue  

$OldDomain = 'dc=yourco,dc=com'
$NewDomain = 'dc=yourtest,dc=local'
$incsv = 'E:\Data\ADexport\OUexport.csv'

$good = 0
$oops = 0

$oulist = import-csv $incsv
$oulist |foreach { 
    $outemp = $_.Distinguishedname -replace $OldDomain,$NewDomain
        #need to split ouTemp and lose the first item
    $ousplit = $outemp -split ',',2
    $outemp
    try {    
        $newOU = New-ADOrganizationalUnit -name $_.Name -path $ousplit[1] -EA stop
        Write-Host "Created: $_.Name"
        $good++
    }
    Catch {
        Write-host "Error creating OU: $outemp"  #$error[0].exception.message"
        $oops++
     }
     Finally {
            echo ""
     }
        
    }
    Write-host "Created $good OUs with $oops errors"