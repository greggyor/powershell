﻿#Powershell User Account locked out Maxzor1908 *16/4/2013*
${5}= "c:\powershell\html.html"
${6}=@"
<title>Account locked out Report</title>
<style>
BODY{background-color :#FFFFF}
TABLE{Border-width:thin;border-style: solid;border-color:Black;border-collapse: collapse;}
TH{border-width: 1px;padding: 1px;border-style: solid;border-color: black;background-color: ThreeDShadow}
TD{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color: Transparent}
H2{color: #457dcf;font-family: Arial, Helvetica, sans-serif;font-size: medium; margin-left: 40px;
</style>
"@
${10} = @{n='Account name';e={$_.ReplacementStrings[-1]}}
${9} = @{n='Account Domain';e={$_.ReplacementStrings[-2]}}
${8} = @{n='Caller Computer Name';e={$_.ReplacementStrings[-1]}}
${7}= Get-EventLog -LogName Security -InstanceId 4740 -Newest 1 |
   Select TimeGenerated,ReplacementStrings,"Account name","Account Domain","Caller Computer Name" |
   % {
     New-Object PSObject -Property @{
      "Account name" = $_.ReplacementStrings[-7]
      "Account Domain" = $_.ReplacementStrings[5]
      "Caller Computer Name" = $_.ReplacementStrings[1]
      Date = $_.TimeGenerated
    }
   }
  ${7} | ConvertTo-Html -Property "Account name","Account Domain","Caller Computer Name",Date -head ${6} -body  "<H2> User is locked in the Active Directory</H2>"|
	 Out-File ${5} -Append
${3}= Get-Content ${5}
${4}= "User Account locked out"
${2} = New-Object system.net.mail.smtpClient
${2}.host = "smtp.yoursmtpserver"
${1} = New-Object system.net.mail.mailmessage
${1}.from = "account_locked_out@........com"
${1}.To.add("youremail@youremail.com")
${1}.Subject = ${4}
${1}.IsBodyHtml = 1
${1}.Body = ${3}
${2}.Send(${1})
del c:\powershell\html.html