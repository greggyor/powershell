﻿


Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin -ErrorAction "SilentlyContinue"



${10100011001011000} = "C:\Program Files\Microsoft\Exchange Server\Logging\MigrationLogs”

${10100000000110000} = Get-DistributionGroupMember GroupOfUsersBeingMO

${00011101001110010} = 4

${01100101001101100} = @("EXCHMBX1","EXHCMBX2","EXHCMBX3","EXHCMBX4","EXHCMBX5")


${00010010111010001} = Get-MailboxDatabase -status | Where {($_.Name -like "MBX*") -and ($_.Recovery -eq $False) `
	-and ($_.Mounted -eq "True") -and ($_.Name -notlike "MBX5*")} | sort Name


If (!(Test-Path -Path ${10100011001011000}\Old)) {ni ${10100011001011000}\Old -Type directory | Out-Null}


ls ${10100011001011000} -Filter *.log | mi -Destination ${10100011001011000}\Old
ls ${10100011001011000} -Filter *.xml | mi -Destination ${10100011001011000}\Old
ls ${10100011001011000} -Filter *.CSV | mi -Destination ${10100011001011000}\Old



icm -ComputerName EXHCSCOM2 -filepath \\EXHCSCOM2\C$\SCRIPTS\DisableSCOMFFRTS.ps1




Foreach (${10010001100100010} in ${01100101001101100}) {
    icm -ComputerName ${10010001100100010} -ScriptBlock {
        Add-PSSnapin fssp*
        Set-FSERealtimeScan -Bypass $True
    }
}


${10011000100111100} = New-Object System.Data.DataTable “MBXDatabaseTable”

${10011000100111100}.Columns.Add("DataBase") | Out-Null
${10011000100111100}.Columns["DataBase"].Unique = $true
${10011000100111100}.PrimaryKey = ${10011000100111100}.Columns["DataBase"]

${10011000100111100}.Columns.Add("ActiveSTDMBs",[Int]) | Out-Null

${10011000100111100}.Columns.Add("ActiveLRGMBs",[Int]) | Out-Null

${10011000100111100}.Columns.Add("ActiveALLMBs",[Int]) | Out-Null

${10011000100111100}.Columns.Add("MailboxMoves",[Array]) | Out-Null


${01110011011000101}=0

Foreach (${10100101100110111} in ${00010010111010001}) {
    
    ${00101010110110110} = [Math]::Round((${01110011011000101}++ / ${00010010111010001}.Count * 100),1)
    ${10111111000000110} = ${10100101100110111}.Name
    Write-Progress -Activity "Mailbox Database Query in Progress" -PercentComplete ${00101010110110110} `
        -Status "${00101010110110110}% Complete" -CurrentOperation "Current Database: ${10111111000000110}"
    
    ${10100110100011010} = Get-Mailbox -Database ${10100101100110111} 
    
    ${10110110011111000} = 0
    ${10010001001011110} = 0
    
    Foreach (${10110001110011001} in ${10100110100011010}) {
		If (${10110001110011001}.UseDatabaseQuotaDefaults -eq $true) {
			
			${10110110011111000}++
		} Else {
			
			${10010001001011110}++
		}
	}
    
    ${00011000100101011} = ${10011000100111100}.NewRow()
	${00011000100101011}.DataBase = ${10100101100110111}
    ${00011000100101011}.ActiveSTDMBs = ${10110110011111000}
    ${00011000100101011}.ActiveLRGMBs = ${10010001001011110}
    
	${00011000100101011}.ActiveALLMBs = (${10110110011111000} + ${10010001001011110})
	${00011000100101011}.MailboxMoves = @()
 	${10011000100111100}.Rows.Add(${00011000100101011})
}

Write-Progress -Activity "Mailbox Database Query in Progress" -Completed -Status "Completed"


${10100000000110000} | ForEach {
	${01101000011110000} = Get-Mailbox $_.Identity
	
	If (${01101000011110000}.UseDatabaseQuotaDefaults -eq $True) {
		
		
        
        
		If (${01101000011110000}.CustomAttribute7.Length -ne 8) {
            ${10101000101000011} = (${10011000100111100} | sort ActiveALLMBs,ActiveLRGMBs | Select -First 1)
        } Else {
            ${10101000101000011} = (${10011000100111100} | Where {$_.Database -notlike "EXHCMBX1*"} | sort ActiveALLMBs,ActiveLRGMBs | Select -First 1)
        }
	} Else {
		
		
        
        
		If (${01101000011110000}.CustomAttribute7.Length -ne 8) {
            ${10101000101000011} = (${10011000100111100} | sort ActiveLRGMBs,ActiveALLMBs | Select -First 1)
        } Else {
            ${10101000101000011} = (${10011000100111100} | Where {$_.Database -notlike "EXHCMBX1*"} |  sort ActiveLRGMBs,ActiveALLMBs | Select -First 1)
        }
	}
	${10011000100111100}.Rows.Find(${10101000101000011}.Database).ActiveALLMBs++
	${10011000100111100}.Rows.Find(${10101000101000011}.Database).MailboxMoves += ${01101000011110000}.PrimarySmtpAddress.ToString()
	If (${01101000011110000}.UseDatabaseQuotaDefaults -eq $true) {
		${10011000100111100}.Rows.Find(${10101000101000011}.Database).ActiveSTDMBs++
	} Else {
		${10011000100111100}.Rows.Find(${10101000101000011}.Database).ActiveLRGMBs++
	}
}


$MBXMoveArray = ${10011000100111100} | ? {$_.MailboxMoves -ne $Null} | Select Database,MailboxMoves


${10010111011011011} = [Math]::Round($MBXMoveArray.Count / ${00011101001110010})

$MBXMoveArrayStart = 0

${01001100101011001} = (${10010111011011011} -1)

${00011100101000011} = 1
While (${00011100101000011} -le ${00011101001110010}) {
    ${10001010010000001} = "MoveJob" + ${00011100101000011}
    Write-Host -ForegroundColor Yellow "Working on job ${00011100101000011} with the array start of $MBXMoveArrayStart and the array end of ${01001100101011001}."
    sajb -Name ${10001010010000001} `
    -InitializationScript {Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin -ErrorAction "SilentlyContinue"} `
    -ScriptBlock {
        
        Param($MBXMoveArray,$MBXMoveArrayStart,$MBMXMoveArrayEnd)
        
        $MBXMoveArray[$MBXMoveArrayStart..$MBMXMoveArrayEnd] |  ForEach {
    	    ${00001110110101001} = $_.Database
            $_.MailboxMoves | Move-Mailbox -TargetDatabase ${00001110110101001} -BadItemLimit 50 -PreserveMailboxSizeLimit:$True -MaxThreads:10 -Confirm:$False
        }
    
    } -ArgumentList ($MBXMoveArray,$MBXMoveArrayStart,${01001100101011001})
    
    ${00011100101000011}++
    
    $MBXMoveArrayStart = (${01001100101011001} + 1)
    
    If (${00011100101000011} -eq ${00011101001110010}) {
        ${01001100101011001} = $MBXMoveArray.Count
    
    } Else { 
        ${01001100101011001} = ($MBXMoveArrayStart + (${10010111011011011} - 1))
    }
} 


While ((gjb -Name MoveJob* | Where {$_.State -eq "Completed"}).Count -lt ${00011101001110010}) {
    Write-Host -ForegroundColor Blue "Waiting on all jobs to reach a Completed status. Sleeping for 60 seconds."
    sleep -Seconds 60
}


Write-Host -ForegroundColor Green "All jobs have reported a Completed status!"
gjb -Name MoveArray* | rjb



sleep -Seconds 60


${01100111001100101} = @()
ForEach (${01111010010101110} in ls ${10100011001011000} -Filter move*.xml ) {
    ${01100111001100101} += [xml](gc ${01111010010101110}.fullname)
} 


${10001111111000101} = New-Object system.Data.DataTable “MoveResults”
${10001111111000101}.Columns.Add("Mailbox",[String]) | Out-Null
${10001111111000101}.Columns.Add("PrimarySMTPAddress",[String]) | Out-Null
${10001111111000101}.Columns.Add("TargetDatabase",[String]) | Out-Null
${10001111111000101}.Columns.Add("ErrorCode",[String]) | Out-Null
${10001111111000101}.Columns.Add("MailboxSizeMB",[String]) | Out-Null
${10001111111000101}.Columns.Add("ItemCount",[String]) | Out-Null
${10001111111000101}.Columns.Add("StartTime",[String]) | Out-Null
${10001111111000101}.Columns.Add("EndTime",[String]) | Out-Null
${10001111111000101}.Columns.Add("Duration",[String]) | Out-Null
${10001111111000101}.Columns.Add("DurationInSec",[String]) | Out-Null
${10001111111000101}.Columns.Add("SpeedInKBps",[Int]) | Out-Null
${10001111111000101}.Columns.Add("IsWarning",[String]) | Out-Null
${10001111111000101}.Columns.Add("MovedBy",[String]) | Out-Null            


${01100111001100101} | %{
    ${00001110110101001} = (Get-MailboxDatabase $_."move-Mailbox".TaskHeader.Options.TargetDatabase).Name
    ${00010101000010111} = $_."move-Mailbox".TaskHeader.RunningAs
    ${01000000100111010} = $_."move-Mailbox".TaskHeader.StartTime
    ${11000000100101111} = $_."move-Mailbox".TaskFooter.EndTime
    ${01110011100001011} = $_."move-Mailbox".taskdetails.item | %{
    ${01111100000110101} = $_.MailboxSize
        
        
        If (${01111100000110101}.EndsWith("KB")) {
            [Int]${01011010010110110} = ${01111100000110101}.Substring(0,(${01111100000110101}.Length - 2))
            ${01011010010110110} = ${01011010010110110} * 1024
        } Elseif (${01111100000110101}.EndsWith("MB")) {
            [Int]${01011010010110110} = ${01111100000110101}.Substring(0,(${01111100000110101}.Length - 2))
            ${01011010010110110} = ${01011010010110110} * 1024 * 1024
        } Elseif (${01111100000110101}.EndsWith("GB")) {
            [Int]${01011010010110110} = ${01111100000110101}.Substring(0,(${01111100000110101}.Length - 2))
            ${01011010010110110} = ${01011010010110110} * 1024 * 1024 * 1024
        } Else {
            ${01011010010110110} = ${01111100000110101}
        }
        
        
        ${00000010101001110} = $Null
        
        ${00101111100010001} = $Null 
        
        If ($_.Duration) {
            
            ${10011110000100000} = $_.Duration.Split(“.:”)
            If (${10011110000100000}.Count -eq 4) {${00000010101001110} = New-Timespan -Days ${10011110000100000}[0] -Hours ${10011110000100000}[1] -Minutes ${10011110000100000}[2] `
              -Seconds ${10011110000100000}[3]}
            If (${10011110000100000}.Count -eq 3) {${00000010101001110} = New-Timespan -Hours ${10011110000100000}[0] -Minutes ${10011110000100000}[1] -Seconds ${10011110000100000}[2]}
            ${00101111100010001} = ${01011010010110110} / ${00000010101001110}.TotalSeconds
        } 
        
        ${00011000100101011} = ${10001111111000101}.NewRow()
        ${00011000100101011}.Mailbox = $_.MailboxName
        ${00011000100101011}.PrimarySMTPAddress = $_.Source.PrimarySmtpAddress
        ${00011000100101011}.TargetDatabase = ${00001110110101001}
        ${00011000100101011}.ErrorCode = $_.Result.ErrorCode
        
        
        ${00011000100101011}.MailboxSizeMB = [Math]::Round(${01011010010110110} / 1024 / 1024)
        
        ${00011000100101011}.ItemCount = (Get-MailboxStatistics $_.Source.PrimarySmtpAddress).ItemCount
        ${00011000100101011}.StartTime = ${01000000100111010}
        ${00011000100101011}.EndTime = ${11000000100101111}
        ${00011000100101011}.Duration =  $_.Duration
        ${00011000100101011}.DurationInSec = ${00000010101001110}.TotalSeconds
        
        ${00011000100101011}.SpeedInKBps = (${00101111100010001}/1024)
        ${00011000100101011}.IsWarning = $_.Result.IsWarning
        ${00011000100101011}.MovedBy = ${00010101000010111}
        ${10001111111000101}.Rows.Add(${00011000100101011})    
    }
}

${01101100000011100} = ${10100011001011000} + "\MailboxMove" + (Get-Date -Format "MM-dd-yyyy") + ".CSV"

${10001111111000101} | epcsv -NoTypeInformation ${01101100000011100}


Foreach (${10010001100100010} in ${01100101001101100}) {
    icm -ComputerName ${10010001100100010} -ScriptBlock {
        Add-PSSnapin fssp*
        Set-FSERealtimeScan -Bypass $False
    }
}


sleep -Seconds 15
icm -ComputerName EXHCSCOM2 -filepath \\EXHCSCOM2\C$\SCRIPTS\EnableSCOMFFRTS.ps1




${10100000000110000} | Get-Mailbox | Where {($_.UseDatabaseQuotaDefaults -eq $True) -and ($_.IssueWarningQuota -like 0)} | `
Set-Mailbox -IssueWarningQuota Unlimited -ProhibitSendQuota Unlimited -ProhibitSendReceiveQuota Unlimited


${10010101110011010} = Get-Date -Format "ddd MM/dd/yyyy h:mm tt"



${01111001000000010} = "Mailbox migration completed at ${10010101110011010}."


${01101100110000010} = "False"
${10001111111000101} | ForEach {
    If ($_.ErrorCode -ne "0") {
        ${01101100110000010} = "True" 
    }
}

If (${01101100110000010} -eq "True") {
    ${01111110010100110} = "There was one or more errors in the migration, please check the attached CSV."
} Else {
    ${01111110010100110} = "There were no errors in the migration."
}

Send-MailMessage -Subject ${01111001000000010} -From "Postmaster@company.com" -To "Postmaster@company.com" -Body ${01111110010100110} `
    -Attachments ${01101100000011100} -SmtpServer "smtprelay.company.com"