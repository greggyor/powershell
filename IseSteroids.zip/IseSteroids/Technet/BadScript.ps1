﻿# ------------------------------------------------------------------------
# NAME: BadScript.ps1
# AUTHOR: ed wilson, Microsoft
# DATE: 4/1/2012
#
# KEYWORDS: template
#
# COMMENTS: This script has a couple of errors in it
# 1. TimesOne function multiplies by 2
# 2. Script pipelines input but function does not take pipe
# 3. Script divides by 0
#
#
# ------------------------------------------------------------------------
Function f2([int]$num)
{
 $num+1
} #end function AddOne
Function f1([int]$num)
{
 $num+2
} #end function AddTwo
Function f4([int]$num)
{
 $num-1
} #end function SubOne
Function TimesOne([int]$num)
{
  $num*2
} #end function TimesOne
Function TimesTwo([int]$num)
{
 $num*2
} #end function TimesTwo
Function f3([int]$num)
{ 
 12/$num
} #end function DivideNum
# *** Entry Point to Script ***
$num = 0
f4($num) | f3($num)
f2($num) | f1($num)
