﻿







Import-Module ActiveDirectory


$groupArray = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABvAG0AYQBpAG4AIABBAGQAbQBpAG4AcwA='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAG0AaQBuAGkAcwB0AHIAYQB0AG8AcgBzAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBjAGMAbwB1AG4AdAAgAE8AcABlAHIAYQB0AG8AcgBzAA=='))),$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBuAHQAZQByAHAAcgBpAHMAZQAgAEEAZABtAGkAbgBzAA==')))

$todaysShortDate = $todaysDateTime.ToShortDateString()
$todaysTime = $todaysDateTime.ToShortTimeString()
$todaysModdedShortDate = $todaysShortDate.Replace("/", "-")


$csvFilePath = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFAAcgBpAHYARwByAG8AdQBwAHMAXwAkAHQAbwBkAGEAeQBzAE0AbwBkAGQAZQBkAFMAaABvAHIAdABEAGEAdABlAC4AYwBzAHYA')))


$csvHeaderRow = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBSAE8AVQBQACAATgBBAE0ARQAsAFUAUwBFAFIAIABOAEEATQBFACwAVQBTAEUAUgAgAEwAQQBTAFQAIABOAEEATQBFACwAVQBTAEUAUgAgAEYASQBSAFMAVAAgAE4AQQBNAEUALABNAEEATgBBAEcARQBSACwATQBBAE4AQQBHAEUAUgAgAEUATQBBAEkATAAsAEQAQQBUAEUAIABDAEEAUABUAFUAUgBFAEQA')))


$csvHeaderRow | Out-File $csvFilePath -Encoding $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA=')))

$dateCaptured = $todaysModdedShortDate



foreach ($groupName In $groupArray) {
		$groupObject = Get-ADGroup -Identity $groupName -Properties Member,cn
		$groupCN = $groupObject.cn
		$memberCollection = $groupObject.Member
		foreach ($distinguishedName In $memberCollection){			
			$userObject = Get-ADObject -Identity $distinguishedName -Properties cn,sn,givenName,manager
			$userName = $userObject.cn
			$lastName = $userObject.sn
			$firstName = $userObject.givenName
			$managerDN = $userObject.manager
			if ($managerDN.Length -ge 5) {
				$managerUserObject = Get-ADUser -Identity $managerDN -Properties givenName,sn,mail
				$managerFirstName = $managerUserObject.givenName
				$managerLastName = $managerUserObject.sn
				$managerFullName = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABtAGEAbgBhAGcAZQByAEYAaQByAHMAdABOAGEAbQBlACAAJABtAGEAbgBhAGcAZQByAEwAYQBzAHQATgBhAG0AZQA=')))
				$managerEmail = $managerUserObject.mail				
			}
			else {
				$managerFullName = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAbQBhAG4AYQBnAGUAcgAgAHMAcABlAGMAaQBmAGkAZQBkAA==')))
				$managerEmail = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAbQBhAG4AYQBnAGUAcgAgAGUAbQBhAGkAbAAgAHMAcABlAGMAaQBmAGkAZQBkAA==')))
			}			
			$csvRow = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABnAHIAbwB1AHAAQwBOACwAJAB1AHMAZQByAE4AYQBtAGUALAAkAGwAYQBzAHQATgBhAG0AZQAsACQAZgBpAHIAcwB0AE4AYQBtAGUALAAkAG0AYQBuAGEAZwBlAHIARgB1AGwAbABOAGEAbQBlACwAJABtAGEAbgBhAGcAZQByAEUAbQBhAGkAbAAsACQAZABhAHQAZQBDAGEAcAB0AHUAcgBlAGQA')))
			$csvRow | Out-File $csvFilePath -Append -Encoding $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGYAYQB1AGwAdAA=')))							
		}				
}
	

$sender = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAG4AZABlAHIAQABtAHkAZABvAG0AYQBpAG4ALgBjAG8AbQA=')))
$recipients = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cgBlAGMAZQBwAGkAZQBuAHQAQABtAHkAZABvAG0AYQBpAG4ALgBjAG8AbQA=')))
$subject = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAGkAdgBpAGwAZQBnAGUAZAAgAEcAcgBvAHUAcAAgAFIAZQBwAG8AcgB0ACAAZgByAG8AbQAgACQAdABvAGQAYQB5AHMAUwBoAG8AcgB0AEQAYQB0AGUA')))
$body = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQB0AHQAYQBjAGgAZQBkACAAaQBzACAAdABoAGUAIABsAGkAcwB0ACAAbwBmACAAcAByAGkAdgBpAGwAZQBnAGUAZAAgAGcAcgBvAHUAcABzACAAYQBuAGQAIABtAGUAbQBiAGUAcgBzACAAYwBhAHAAdAB1AHIAZQBkACAAbwBuACAAJAB0AG8AZABhAHkAcwBTAGgAbwByAHQARABhAHQAZQAgAGEAdAAgACQAdABvAGQAYQB5AHMAVABpAG0AZQAuAA==')))
$smtpServer = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bQB5AHMAbQB0AHAAcwBlAHIAdgBlAHIAQABtAHkAZABvAG0AYQBpAG4ALgBjAG8AbQA=')))
$attachments = $csvFilePath

Send-MailMessage -From $sender -To $recipients -Subject $subject -Body $body -SmtpServer $smtpServer -Attachments $attachments

