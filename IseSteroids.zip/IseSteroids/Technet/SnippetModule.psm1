﻿Function Get-CodeSnippetV2
{ 
<#
.Synopsis
Either displays contents of a file in Notepad, or adds the content to
current insertion point of script.
.Description
The Get-CodeSnippetV2 function accepts an input folder of code snippets,
and displays a file dialog box that allows you to select a particular
file to either view the contents in Notepad, or add the content to
your script at the current insertion point.
.Example
Get-CodeSnippetV2 -InitialDirectory c:\fso
Opens a File dialog box situated on the c:\fso directory. Initial view
is .ps1 and .psm1 files, but you can choose to view all files. If you
select a file, its contents will be displayed in Notepad.
.Example
Get-CodeSnippetV2 -InitialDirectory c:\fso -add
Opens a File dialog box situated on the c:\fso directory. Initial view
is .ps1 and .psm1 files, but you can choose to view all files. If you
select a file, its contents will automatically be added at the current
insertion point of your script.
.Parameter InitialDirectory
The initial directory to be homed for the Open File dialog box
.Parameter Add
A switched parameter that will cause the function to add the content to
current script at current insertion point.
.Inputs 
[string]
.Outputs 
[string]
.Notes
NAME: Get-CodeSnippetV2
AUTHOR: Ed Wilson, Microsoft
LASTEDIT: 02/10/2011 13:14:07
KEYWORDS: Weekend Scripter, scripting techniques, scripting templates 
HSG: WES-2-12-2011
.Link
Http://www.ScriptingGuys.com
#Requires -Version 2.0
#>
Param(
[Parameter(Mandatory=$true)]
[string]$InitialDirectory,
[switch]$add
)
If($ExecutionContext.Host.name -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBTAEUAIABIAG8AcwB0ACQA'))))
{
${11} = Read-Host -Prompt $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGkAcwAgAHMAYwByAGkAcAB0ACAAbQB1AHMAdAAgAHIAdQBuACAAaQBuACAAVwBpAG4AZABvAHcAcwAgAFAAbwB3AGUAcgBTAGgAZQBsAGwAIABJAFMARQAuACAAPABZAD4AIAB0AG8AIABlAHgAaQB0AC4A')))
if(${11} -match "y") { Exit }
} #end if
Add-Type -AssemblyName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgB3AGkAbgBkAG8AdwBzAC4AZgBvAHIAbQBzAA==')))
${10} = new-object System.Windows.Forms.OpenFileDialog
${10}.initialDirectory = $initialDirectory
${10}.filter = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABvAHcAZQByAFMAaABlAGwAbAAgAFMAYwByAGkAcAB0AHMAIAAoACoALgBwAHMAMQA7ACoALgBwAHMAbQAxADsAKgAuAHMAbgBpAHAAKQB8ACoALgBwAHMAMQA7ACoALgBwAHMAbQAxADsAKgAuAHMAbgBpAHAAfABBAGwAbAAgAGYAaQBsAGUAcwAgACgAKgAuACoAKQB8ACAAKgAuACoA')))
${10}.ShowDialog() | out-null
Try
{
if(!$add) 
{ notepad ${10}.filename } 
if($add)
{
${9} = gc -Path ${10}.filename -Encoding ascii -Delimiter `r`n
$psise.CurrentFile.Editor.InsertText(${9})
} #end if $add
} #end try
Catch [System.Exception]
{ $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAZgBpAGwAZQAgAHcAYQBzACAAcwBlAGwAZQBjAHQAZQBkAC4A'))) }
} #end function Get-CodeSnippet
# *** entry point to script ***
#Get-CodeSnippetV2 -InitialDirectory (Join-path -path (Split-Path -path $profile -Parent) -ChildPath snippet)
#New-SnipType.ps1
Function f1
{
ndr -Name HKCR -PSProvider registry -Root HKEY_CLASSES_ROOT | Out-Null
pushd
cd -Path HKCR:
ni -Name .snip -ItemType String -Value snip_file | Out-Null
New-ItemProperty -Path HKCR:\.snip -Name PerceivedType -Value Text -PropertyType String | Out-Null
ni -Name snip_file -ItemType string | Out-Null
ni -Name shell -Path HKCR:\snip_file -ItemType string | Out-Null
ni -Name edit -Path HKCR:\snip_file\shell -ItemType string | Out-Null
ni -Name command -Path HKCR:\snip_file\shell\edit -ItemType ExpandString -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQBTAHkAcwB0AGUAbQBSAG8AbwB0ACUAXABzAHkAcwB0AGUAbQAzADIAXABOAE8AVABFAFAAQQBEAC4ARQBYAEUAIAAlADEA'))) | Out-Null
ni -Name open -Path HKCR:\snip_file\shell -ItemType string | Out-Null
ni -Name command -Path HKCR:\snip_file\shell\open -ItemType ExpandString -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JQBTAHkAcwB0AGUAbQBSAG8AbwB0ACUAXABzAHkAcwB0AGUAbQAzADIAXABOAE8AVABFAFAAQQBEAC4ARQBYAEUAIAAlADEA'))) | Out-Null 
cd -Path HKCU:
${8} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEMAVQA6AFwAUwBvAGYAdAB3AGEAcgBlAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFwAQwB1AHIAcgBlAG4AdABWAGUAcgBzAGkAbwBuAFwARQB4AHAAbABvAHIAZQByAFwARgBpAGwAZQBFAHgAdABzAA==')))
ni -Name .snip -Path ${8} | Out-Null
ni -Name OpenWithList -Path ${8}\.snip | Out-Null
New-ItemProperty -Name a -Path ${8}\.snip\OpenWithList -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAZQBwAGEAZAAuAEUAeABlAA=='))) -PropertyType String | Out-Null
New-ItemProperty -Name MRUList -Path ${8}\.snip\OpenWithList -value a -PropertyType String | Out-Null
ni -Name OpenWithProgids -Path ${8}\.snip | Out-Null
New-ItemProperty -Name snip_file -Path ${8}\.snip\OpenWithProgids -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KAB6AGUAcgBvAC0AbABlAG4AZwB0AGgAIABiAGkAbgBhAHIAeQAgAHYAYQBsAHUAZQApAA=='))) -PropertyType Unknown | Out-Null
ni -Name UserChoice -Path ${8}\.snip | Out-Null
New-ItemProperty -Name Progid -Path ${8}\.snip\UserChoice -value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBwAHAAbABpAGMAYQB0AGkAbwBuAHMAXABOAG8AdABlAHAAYQBkAC4ARQB4AGUA'))) -PropertyType String | Out-Null
popd 
rdr -Name HKCR
} #end function New-SnipType
#Remove-SnipType.ps1
Function Remove-SnipType 
{
ndr -Name HKCR -PSProvider registry -Root HKEY_CLASSES_ROOT | Out-Null
pushd
cd -Path HKCR:
rd -Path HKCR:\.snip -Recurse
rd -Path HKCR:\snip_file -Recurse 
cd -Path HKCU:
rd -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.snip -Recurse  
popd 
rdr -Name HKCR
} #end function Remove-SnipType
Function f2
{
 Param($path)
#use path if you have a local source of the snip.zip file
${6} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBiAGkAdAAuAGwAeQAvAGcAYQAwAGsAMABpAA==')))
#$source = "http://public.bay.livefilestore.com/y1pWfzVoKQeFsgOgBR6btSYG7ToGKfuivGSfP0z5eiDQ_erRBwRw9hZpd7Nue9wD_RSL6JQ9Jg2PlWqLSgMlrr0vw/snip.zip"
${3} = ni -Path (Split-Path -Path $profile -Parent) -Name snippet -ItemType directory
${5} = Join-Path -Path ${3} -ChildPath snip.zip
if($path)
{
 cp -Path $path -Destination ${5}
}
ELSE
{
 ${7} = New-Object system.net.webclient
 ${7}.downloadFile(${6},${5})
 }
${4} = New-Object -ComObject shell.application
${2} = ${4}.namespace(${5}).items()
${4}.NameSpace(${3}.fullname).copyHere(${2})
} #end function copy-codesnippetsfrominternet
function f3 
{ 
<# 
.Synopsis 
Tests if the user is an administrator 
.Description 
Returns true if a user is an administrator, false if the user  
is not an administrator 
.Example 
Test-IsAdministrator 
.Notes 
NAME: Test-IsAdministrator 
AUTHOR: Ed Wilson 
LASTEDIT: 5/20/2009 
KEYWORDS: 
.Link 
Http://www.ScriptingGuys.com 
#Requires -Version 2.0 
#> 
param()  
${1} = [Security.Principal.WindowsIdentity]::GetCurrent() 
(New-Object Security.Principal.WindowsPrincipal ${1}).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator) 
} #end function Test-IsAdministrator 
Function Register-CodeSnippets
{
 Param($path)
 # this function downloads, installs, and registers codesnippets
 # if you have a local source of code snippets, use $path to specify
 if(!(f3)) {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABoAGkAcwAgAHIAZQBxAHUAaQByAGUAcwAgAGEAZABtAGkAbgAgAHIAaQBnAGgAdABzAA==')));exit}
 ELSE
 {
  if($path) {f2 -path $path}
  else
   {f2}
  f1
 }
} #end function register-codesnippets
# ***** ENtryPoint ***
nv -Name SnipHome -Value (Join-path -path (Split-Path -path $profile -Parent) -ChildPath snippet)
#Export-ModuleMember -Function * -Variable *
Export-ModuleMember -Function Get-CodeSnippetV2 -Variable sniphome