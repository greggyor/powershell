﻿#+-------------------------------------------------------------------+  
#| = : = : = : = : = : = : = : = : = : = : = : = : = : = : = : = : = |  
#|{>/-------------------------------------------------------------\<}|           
#|: | Author:  Aman Dhally                                        | :|           
#| :| Email:   amandhally@gmail.com
#|: | Purpose: Maintain Leavers :)  in AD GUI Version
#| :|      
#|: |  more info: http://newdelhipowershellusergroup.blogspot.in/              						                    
#| :|          
#|: |         		Date: 02-August-2012
#|: |                            12:41
#| :| 	/^(o.o)^\    Version: 1          						  |: | 
#|{>\-------------------------------------------------------------/<}|
#| = : = : = : = : = : = : = : = : = : = : = : = : = : = : = : = : = |
#+-------------------------------------------------------------------+
#========================================================================
#----------------------------------------------
#region Application Functions
#----------------------------------------------
function OnApplicationLoad {
	#Note: This function is not called in Projects
	#Note: This function runs before the form is created
	#Note: To get the script directory in the Packager use: Split-Path $hostinvocation.MyCommand.path
	#Note: To get the console output in the Packager (Windows Mode) use: $ConsoleOutput (Type: System.Collections.ArrayList)
	#Important: Form controls cannot be accessed in this function
	#TODO: Add snapins and custom code to validate the application load
	return $true #return true for success or false for failure
}
function OnApplicationExit {
	#Note: This function is not called in Projects
	#Note: This function runs after the form is closed
	#TODO: Add custom code to clean up and unload snapins when the application exits
	$script:ExitCode = 0 #Set the exit code for the Packager
}
#endregion Application Functions
#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Call-Leavers_Processs_Community_pff {
	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load("mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Xml, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	[void][reflection.assembly]::Load("System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
	[void][reflection.assembly]::Load("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")
	#endregion Import Assemblies
	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formLeaversV1 = New-Object 'System.Windows.Forms.Form'
	$groupbox3 = New-Object 'System.Windows.Forms.GroupBox'
	$labelfound = New-Object 'System.Windows.Forms.Label'
	$labelActiveDirectoryModul = New-Object 'System.Windows.Forms.Label'
	$groupbox2 = New-Object 'System.Windows.Forms.GroupBox'
	$labelInformation = New-Object 'System.Windows.Forms.Label'
	$richtextbox2 = New-Object 'System.Windows.Forms.RichTextBox'
	$buttonStart = New-Object 'System.Windows.Forms.Button'
	$labelNewPassword = New-Object 'System.Windows.Forms.Label'
	$textbox3 = New-Object 'System.Windows.Forms.TextBox'
	$groupbox1 = New-Object 'System.Windows.Forms.GroupBox'
	$richtextbox1 = New-Object 'System.Windows.Forms.RichTextBox'
	$buttonFind = New-Object 'System.Windows.Forms.Button'
	$textbox2 = New-Object 'System.Windows.Forms.TextBox'
	$labelLastName = New-Object 'System.Windows.Forms.Label'
	$labelFirstName = New-Object 'System.Windows.Forms.Label'
	$textbox1 = New-Object 'System.Windows.Forms.TextBox'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects
	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	#
	# leavers Process :
	# Date - 31-07-2012
	###
	ipmo ActiveDirectory
	$module = gmo -Name ActiveDirectory
	if ( $module -eq $null ) { $found = "NO" } else { $found = "Yes" }
	#######
	$cred = Get-Credential
	$server = "MY-DC"
	$ArchiveOu = 'OU=Archived,DC=localDC,DC=com'
	# Importing Modules
	$formLeaversV1_Load={
		#TODO: Initialize Form Controls here
	}
	#region Scripts
		#reset Password
		#
	#endregion
	$buttonFind_Click={
		#TODO: Place custom script here
		#Write-Host  $textbox1.Text $textbox2.Text 
		$AdUser = Get-ADUser -filter {(GivenName -like $textbox1.Text ) -and (Surname -eq $textbox2.Text )} -Properties *
		$richtextbox1.Text = $AdUser.SamAccountName
	}
	$richtextbox1_TextChanged={
		#TODO: Place custom script here
	}
	$buttonStart_Click={
		#TODO: Place custom script here
		Set-ADAccountPassword -Identity $AdUser.SamAccountName -Reset -NewPassword (ConvertTo-SecureString -AsPlainText $textbox3.Text -Force) -Credential $cred 
		$richtextbox2.Text =  "==> Password is Changed."
		$a = get-ADUser $AdUser -Properties * | Select Memberof
		Foreach ($b in $a ) {
		$name = $b.Memberof
		$name	
		foreach ( $group in $name ) {
		remove-ADGroupMember -Identity $group -Members $AdUser.SamAccountName -Confirm:$false -Credential $cred }}
		$richtextbox2.Text += "`n"
		$richtextbox2.Text += "==> Groups removed from USers Account."
		$richtextbox2.Text += "`n"
		Move-ADObject -Identity $AdUser.DistinguishedName -TargetPath $ArchiveOu -Credential $cred
		$richtextbox2.Text += "==> User Account is moved to Archived Folder."
		$richtextbox2.Text += "`n"
		$richtextbox2.Text += "         |===> All Done <====|"
	}
	$richtextbox2_TextChanged={
		#TODO: Place custom script here
	}
	$labelfound_Click={
		#TODO: Place custom script here
	}
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formLeaversV1.WindowState = $InitialFormWindowState
	}
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$labelfound.remove_Click($labelfound_Click)
			$richtextbox2.remove_TextChanged($richtextbox2_TextChanged)
			$buttonStart.remove_Click($buttonStart_Click)
			$richtextbox1.remove_TextChanged($richtextbox1_TextChanged)
			$buttonFind.remove_Click($buttonFind_Click)
			$formLeaversV1.remove_Load($formLeaversV1_Load)
			$formLeaversV1.remove_Load($Form_StateCorrection_Load)
			$formLeaversV1.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch [Exception]
		{ }
	}
	#endregion Generated Events
	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	#
	# formLeaversV1
	#
	$formLeaversV1.Controls.Add($groupbox3)
	$formLeaversV1.Controls.Add($labelfound)
	$formLeaversV1.Controls.Add($labelActiveDirectoryModul)
	$formLeaversV1.Controls.Add($groupbox2)
	$formLeaversV1.Controls.Add($groupbox1)
	$formLeaversV1.BackColor = 'Control'
	$formLeaversV1.ClientSize = '373, 418'
	$formLeaversV1.Name = "formLeaversV1"
	$formLeaversV1.StartPosition = 'CenterScreen'
	$formLeaversV1.Text = "Leavers V.1"
	$formLeaversV1.add_Load($formLeaversV1_Load)
	#
	# groupbox3
	#
	$groupbox3.Location = '21, 37'
	$groupbox3.Name = "groupbox3"
	$groupbox3.Size = '334, 10'
	$groupbox3.TabIndex = 6
	$groupbox3.TabStop = $False
	#
	# labelfound
	#
	$labelfound.Font = "Microsoft Sans Serif, 8.25pt, style=Bold"
	$labelfound.Location = '224, 14'
	$labelfound.Name = "labelfound"
	$labelfound.Size = '100, 23'
	$labelfound.TabIndex = 5
	$labelfound.Text = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABmAG8AdQBuAGQA')))
	$labelfound.add_Click($labelfound_Click)
	#
	# labelActiveDirectoryModul
	#
	$labelActiveDirectoryModul.Font = "Microsoft Sans Serif, 9pt"
	$labelActiveDirectoryModul.Location = '34, 11'
	$labelActiveDirectoryModul.Name = "labelActiveDirectoryModul"
	$labelActiveDirectoryModul.Size = '199, 23'
	$labelActiveDirectoryModul.TabIndex = 4
	$labelActiveDirectoryModul.Text = "Active Directory Module Found ? :"
	#
	# groupbox2
	#
	$groupbox2.Controls.Add($labelInformation)
	$groupbox2.Controls.Add($richtextbox2)
	$groupbox2.Controls.Add($buttonStart)
	$groupbox2.Controls.Add($labelNewPassword)
	$groupbox2.Controls.Add($textbox3)
	$groupbox2.Location = '21, 211'
	$groupbox2.Name = "groupbox2"
	$groupbox2.Size = '337, 181'
	$groupbox2.TabIndex = 1
	$groupbox2.TabStop = $False
	$groupbox2.Text = "Leavers Process"
	#
	# labelInformation
	#
	$labelInformation.Location = '40, 84'
	$labelInformation.Name = "labelInformation"
	$labelInformation.Size = '100, 23'
	$labelInformation.TabIndex = 4
	$labelInformation.Text = "Information"
	#
	# richtextbox2
	#
	$richtextbox2.Location = '41, 109'
	$richtextbox2.Name = "richtextbox2"
	$richtextbox2.Size = '284, 60'
	$richtextbox2.TabIndex = 3
	$richtextbox2.Text = ""
	$richtextbox2.add_TextChanged($richtextbox2_TextChanged)
	#
	# buttonStart
	#
	$buttonStart.Location = '182, 70'
	$buttonStart.Name = "buttonStart"
	$buttonStart.Size = '75, 23'
	$buttonStart.TabIndex = 2
	$buttonStart.Text = "Start"
	$buttonStart.UseVisualStyleBackColor = $True
	$buttonStart.add_Click($buttonStart_Click)
	#
	# labelNewPassword
	#
	$labelNewPassword.Location = '38, 27'
	$labelNewPassword.Name = "labelNewPassword"
	$labelNewPassword.Size = '100, 23'
	$labelNewPassword.TabIndex = 1
	$labelNewPassword.Text = "New Password"
	#
	# textbox3
	#
	$textbox3.Location = '156, 27'
	$textbox3.Name = "textbox3"
	$textbox3.Size = '162, 20'
	$textbox3.TabIndex = 0
	#
	# groupbox1
	#
	$groupbox1.Controls.Add($richtextbox1)
	$groupbox1.Controls.Add($buttonFind)
	$groupbox1.Controls.Add($textbox2)
	$groupbox1.Controls.Add($labelLastName)
	$groupbox1.Controls.Add($labelFirstName)
	$groupbox1.Controls.Add($textbox1)
	$groupbox1.Location = '21, 57'
	$groupbox1.Name = "groupbox1"
	$groupbox1.Size = '337, 143'
	$groupbox1.TabIndex = 0
	$groupbox1.TabStop = $False
	$groupbox1.Text = "Find User First"
	#
	# richtextbox1
	#
	$richtextbox1.Location = '13, 93'
	$richtextbox1.Name = "richtextbox1"
	$richtextbox1.Size = '148, 36'
	$richtextbox1.TabIndex = 5
	$richtextbox1.Text = ""
	$richtextbox1.add_TextChanged($richtextbox1_TextChanged)
	#
	# buttonFind
	#
	$buttonFind.Location = '182, 99'
	$buttonFind.Name = "buttonFind"
	$buttonFind.Size = '75, 23'
	$buttonFind.TabIndex = 4
	$buttonFind.Text = "Find"
	$buttonFind.UseVisualStyleBackColor = $True
	$buttonFind.add_Click($buttonFind_Click)
	#
	# textbox2
	#
	$textbox2.Location = '99, 53'
	$textbox2.Name = "textbox2"
	$textbox2.Size = '147, 20'
	$textbox2.TabIndex = 3
	#
	# labelLastName
	#
	$labelLastName.Location = '13, 51'
	$labelLastName.Name = "labelLastName"
	$labelLastName.Size = '100, 23'
	$labelLastName.TabIndex = 2
	$labelLastName.Text = "Last Name"
	#
	# labelFirstName
	#
	$labelFirstName.Location = '13, 24'
	$labelFirstName.Name = "labelFirstName"
	$labelFirstName.Size = '80, 23'
	$labelFirstName.TabIndex = 1
	$labelFirstName.Text = "First Name :"
	#
	# textbox1
	#
	$textbox1.Location = '99, 24'
	$textbox1.Name = "textbox1"
	$textbox1.Size = '147, 20'
	$textbox1.TabIndex = 0
	#endregion Generated Form Code
	#----------------------------------------------
	#Save the initial state of the form
	$InitialFormWindowState = $formLeaversV1.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formLeaversV1.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formLeaversV1.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formLeaversV1.ShowDialog()
} #End Function
#Call OnApplicationLoad to initialize
if((OnApplicationLoad) -eq $true)
{
	#Call the form
	Call-Leavers_Processs_Community_pff | Out-Null
	#Perform cleanup
	OnApplicationExit
}
