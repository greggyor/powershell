﻿In some situations I would like to backup a subset of all existing database of a running Microsoft SQL Server instance. E.g. if I am in a project and the database for this have a main name indicator like HR for a Human Resources, then before I deploy changes I would like to run an additional backup for all concered database.
Or, all our databases for development & testing do have the preset DEV_ and in common those never be backup, because they are copies of productive database. But before doing main changes I run a backup to reduce may neccessary recovery time in case of failure.

For this I create a PowerShell script using a Regulary Expression (RegEx) to filter out those databases I would like to backup.


<# SYNOPSIS
      Backup all databases, where the name matches a regex pattern.
   DESCRIPTION
      Backup all databases, where the name matches a regex pattern.
      Works with SQL Server 2005 and higher version.
   NOTES
      Author  : Olaf Helper
      Requires: PowerShell Version 2.0, SMO assembly
#>

# Configuration variables.
[string]${10001101001100110} =$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAFMAUQBMAEUAWABQAFIARQBTAFMA')));  # Server instance name.
[string]${10011101101101000} ="";       # Folder to backup to. If empty the default backup folder is used.
[string]${00110111010000000}="\w";     # Regex pattern for database names. Use "\w" for all databases.
[bool]  ${00011010011110100}=1;        # 1 = Backup Log file, otherwise not.


# Reference to SMO
[void][System.Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAFMATQBPAA=='))));
# Referenced by SMO, so also requiered.
[void][System.Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAEMAbwBuAG4AZQBjAHQAaQBvAG4ASQBuAGYAbwA='))));
[void][System.Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBTAGQAawAuAFMAZgBjAA=='))));
[void][System.Reflection.Assembly]::LoadWithPartialName($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAFMATQBPAEUAeAB0AGUAbgBkAGUAZAA='))));

${00101111000011000} = New-Object Microsoft.SqlServer.Management.Smo.Server ${10001101001100110};

# If folder isn't defined use the default backup directory.
If (${10011101101101000} -eq "")
{ ${10011101101101000} = ${00101111000011000}.Settings.BackupDirectory + "\" };

echo ((Get-Date -format yyyy-MM-dd_HH-mm-ss) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgAgAFMAdABhAHIAdABlAGQAIAAuAC4ALgA='))));

foreach (${10001111001001000} in ${00101111000011000}.Databases)
{
    # Backup only if the database name matches the regex pattern. Non need to backup TempDB.
    IF ((![regex]::IsMatch(${10001111001001000}.Name, ${00110111010000000})) -or (${10001111001001000}.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABlAG0AcABkAGIA')))))
    { continue; };
    
    ${01001000100000011} = (Get-Date -format yyyy-MM-dd_HH-mm-ss);
    echo (${01001000100000011} + ": " + ${10001111001001000}.Name + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABmAHUAbABsACAAYgBhAGMAawB1AHAA'))));
    
    ${01001001001001011} = New-Object ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBTAG0AbwAuAEIAYQBjAGsAdQBwAA=='))));
    ${01001001001001011}.Action = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABBAFQAQQBCAEEAUwBFAA==')));
    ${01001001001001011}.Database = ${10001111001001000}.Name;
    ${01001001001001011}.Devices.AddDevice(${10011101101101000} + ${10001111001001000}.Name + "_" + ${01001000100000011} + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBmAHUAbABsAC4AYgBhAGsA'))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQA='))));
    ${01001001001001011}.BackupSetDescription = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgB1AGwAbAAgAGIAYQBjAGsAdQBwACAAbwBmACAA'))) + ${10001111001001000}.Name + " " + ${01001000100000011};
     # 0 = full backup.
    ${01001001001001011}.Incremental = 0;

    # Starting full backup process.
    ${01001001001001011}.SqlBackup(${00101111000011000});


    # If recovery model = simple, then a log backup isn't possible.
    If ((${10001111001001000}.RecoveryModel -eq 3) -or (${00011010011110100} -ne 1))
    { continue; }
    
    # Log backup.
    ${01001000100000011} = Get-Date -format yyyy-MM-dd_HH-mm-ss;
    echo (${01001000100000011} + ": " + ${10001111001001000}.Name + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IABsAG8AZwAgAGIAYQBjAGsAdQBwAA=='))));
    
    ${11000000100110011} = New-Object ($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALgBTAHEAbABTAGUAcgB2AGUAcgAuAE0AYQBuAGEAZwBlAG0AZQBuAHQALgBTAG0AbwAuAEIAYQBjAGsAdQBwAA=='))));
    ${11000000100110011}.Action = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABPAEcA')));
    ${11000000100110011}.Database = ${10001111001001000}.Name;
    ${11000000100110011}.Devices.AddDevice(${10011101101101000} + ${10001111001001000}.Name + "_" + ${01001000100000011} + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XwBsAG8AZwAuAHQAcgBuAA=='))), $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBpAGwAZQA='))));
    ${11000000100110011}.BackupSetDescription = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGcAIABiAGEAYwBrAHUAcAAgAG8AZgAgAA=='))) + ${10001111001001000}.Name + " " + ${01001000100000011};
    # Truncated log after backup.
    ${11000000100110011}.LogTruncation = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABSAFUATgBDAEEAVABFAA==')));
    
    # Start the log backup process.
    ${11000000100110011}.SqlBackup(${00101111000011000});
};

${00101111000011000}.Dispose;
echo ((Get-Date -format  yyyy-MM-dd_HH-mm-ss) + $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgAgAEYAaQBuAGkAcwBoAGUAZAA='))));