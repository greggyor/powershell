﻿#lists all columns with the specified column type from all lists / libraries in the collection
Add-PSSnapin Microsoft.SharePoint.PowerShell –ea SilentlyContinue
#Set variables
$site = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aAB0AHQAcAA6AC8ALwBtAG8AcwBzAA==')))
$columnType = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQB4AHQAZQByAG4AYQBsACAARABhAHQAYQA=')))
foreach ($web in (Get-SPSite  $site | Get-SPWeb -Limit All)) 
    {
    $lists = $web.Lists
    Foreach ($list in $lists)
           {
            $list.Fields | select Scope, ParentList, Title, TypeDisplayName  | where {$_.TypeDisplayName -eq $columnType} | ft -Wrap | Out-File -filepath C:\sitelists.txt -width 120 -append
           }
    }