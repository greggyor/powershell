﻿function Get-ShareSize {
    Param(
    [String[]]$ComputerName = $env:computername
    )

Begin{${3} = New-Object -com Scripting.FileSystemObject}

Process{
    foreach(${4} in $ComputerName){
        gwmi Win32_Share -ComputerName ${4} -Filter "not name like '%$'" | %{
            ${2} = $_.Path -replace 'C:',$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACQAewA0AH0AXABjACQA')))
            ${1} = (${3}.GetFolder(${2}).Size) / 1GB
            New-Object PSObject -Property @{
            Name = $_.Name
            Path = ${2}
            Description = $_.Description
            Size = ${1}
            }
        }
    }
}
}