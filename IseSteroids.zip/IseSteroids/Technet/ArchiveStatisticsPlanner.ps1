﻿# Exchange 2010 Mailbox PreArchive Statistics
# Purpose:  Query mailboxes for mail older than X days in order to plan archive database storage requirements.

## Organizational Management security group rights are required to execute this script
## Execution of the script from the Exchange Management Shell (EMS) will provide feedback on execution.

# =================================================
# ==========  CHOOSE CUSTOM SETTINGS  =============	
# =================================================

# Set the Mailbox variable to the query you wish to search
# Enable ONE of the following $Mailbox options.  They are ordered in such a way that if two
# options are enabled the last one set will be a smaller set of users than the previous.
	## Search all mailboxes in all databases
		# $Mailbox = Get-MailboxDatabase | Get-Mailbox
	## Search all mailboxes on a server (EDIT THE SERVER NAME)
		# $Mailbox = Get-MailboxDatabase -Server SERVERNAME | Get-Mailbox -ResultSize Unlimited
	## Search a single database (EDIT THE DATABASE NAME)
		# $Mailbox = Get-MailboxDatabase -Identity DATABASENAME | Get-Mailbox -ResultSize Unlimited
	## Search all users within an organization unit (EDIT THE OU CN)
		# $Mailbox = Get-Mailbox -OrganizationalUnit ou=OUNAME,dc=DOMAINNAME,dc=DOMAINSUFFIX -ResultSize Unlimited
###### The options below allow for a user generated list. If the value you search on results in multiple entries 
	## the script will log an error in the output.  The following attributes may be used:
	## GUID, Distinguished name (DN), Domain\Account, User principal name (UPN), LegacyExchangeDN, SmtpAddress, Alias
	## Provide a text file with a list of users.  One user per line.  $Mailbox will be setup later in the script.
		# Enable and configure the two lines below.  Include a path ending in "\" and a filename.
		# $TXTPath = $env:userprofile + "\" + "Desktop" + "\"
		# $TXTName = "InputList.txt"
	## Search mailboxes with a filter
		# $Mailbox = Get-Mailbox -Identity Smith* -ResultSize Unlimited
	## Search mailboxes out of an array
		# $Mailbox = @("Smith, John","ReceptionDeskUser")
	## Search a single mailbox.  
		# $Mailbox = "cowanl"
		
# Set the minimum mail age that should be collected.  Note:  Leap years are not automatically calculated.		
$MailOlderThanDays = 365

# Set your folder path.  Using '$env:userprofile + "\" + "Desktop" + "\"' puts the report on the desktop
# of the user that executes the script.
$filepath = $env:userprofile + "\" + "Desktop" + "\"
# Name your output file
$filename = "ArchiveStatisticsPlanner_Results.csv"

# =================================================
# ==========  End CUSTOM SETTINGS  ================	
# =================================================

#Capture the start time for the script.  Used to 
$StartTime = Get-Date -DisplayHint Time

# If both variables were setup in the text file input option we confirm the file exists.
If (($TXTPath) -and ($TXTName)) {
	$TXT = $TXTPath + $TXTName
	# If the file exists set $Mailbox to grab the content.  If not end script.
	If (test-path $TXT){
		$Mailbox = gc $TXT
		}
	else {
		Write-Host "The file " $TXT " does not exist." -foreground red
		Break
		}
	}

# Confirm $Mailbox was set properly and throw an error if not.
If (!$Mailbox) {
	Write-Host "The search option has not been properly configured or the text file is blank.  Please edit the search options and try again." -foreground red
	Break
	}
	
# Declare the array and hash to be used to capture and store the query returns for exporting
$Arr = @()
$Hash = @{}

# Compute the date to be used for minimum mail age.  
$QueryDate = [DateTime]::Now.Subtract([TimeSpan]::FromDays($MailOlderThanDays)).ToShortDateString()
# Cycle through each mailbox to begin your collection
Foreach ($MBX in $Mailbox) {

# Depending on your initial query choice we may or may not easily access the mailbox's database.
# First we attempt to set the value.  If the value turns out null we query for the information
$MBXDatabase = $MBX.Database

If (!$MBXDatabase){
	$MBXDBSearch = Get-Mailbox -Identity $MBX
	# Check to see if the value of $MBX results in multiple matches.  If it does log and move to the next item.
	If ($MBXDBSearch.GetType().IsArray) {
		$DuplicatesError = "The search for this user resulted in multiple matches.  Please run again with a unique value."
		$Hash = @{}
		$Hash.User = $MBX
		$Hash.Database = $DuplicatesError
		$Arr += new-object psobject -property $Hash
		Continue
		}
	$MBXDatabase = $MBXDBSearch.Database
	}

# Grab the folder statistics of the mailbox for the purpose of filtering out mailboxes with no data older than what you want.
$FolderStatistics = get-mailbox -identity $MBX | get-mailboxfolderstatistics -folderscope all -includeoldestandnewestitems

# Sort through the OldestItemReceiveDates for each folder and pick out only the oldest date.
$Oldest = $FolderStatistics | ? {$_.OldestItemReceivedDate} | sort OldestItemReceivedDate | select OldestItemReceivedDate -First 1

# Find out how old the oldest item is from today
If ($Oldest){
$OldestDays = New-TimeSpan -Start $Oldest.OldestItemReceivedDate
}
# Convert the oldest item age to simple days
$OldestDays = $OldestDays.Days

# If the oldest item age is greater than or equal to the minimum age set we'll query the mailbox
If ($OldestDays -ge $MailOlderThanDays)
	{
		# Search the mailbox for items sent on or before the query date.  EstimateResultOnly insures we just collect stats.
		$MBXSearch = Search-Mailbox -Identity $MBX -SearchQuery $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('cwBlAG4AdAA6ADwAPQAkAFEAdQBlAHIAeQBEAGEAdABlAA=='))) -EstimateResultOnly -DoNotIncludeArchive
			# Convert the size field to a more useable value
			$ArchiveItemSizeBytes = ([Microsoft.Exchange.Data.ByteQuantifiedSize]$MBXSearch.ResultItemsSize).ToBytes()
		
		# Query for today's mailbox size and item count for reference
		$MBXStats = Get-MailboxStatistics -Identity $MBX
			# Convert the size field to a more useable value
			$ItemSizeBytes = ([Microsoft.Exchange.Data.ByteQuantifiedSize]$MBXStats.TotalItemSize).ToBytes()
		
			# Save our collection to a hash table and write the entry to an array
			$Hash = @{}
			$Hash.User = $MBX
			$Hash.Database = $MBXDatabase
			$Hash.Identity = $MBXSearch.Identity
			$Hash.ItemsCount = $MBXStats.ItemCount
			$Hash.ItemsSizeBytes = "{0:n0}" -f $ItemSizeBytes
			$Hash.ItemsSizeMBs = "{0:n4}" -f ($ItemSizeBytes / 1MB)
			$Hash.ArchiveItemsCount = $MBXSearch.ResultItemsCount
			$Hash.ArchiveItemsSizeBytes = "{0:n0}" -f $ArchiveItemSizeBytes
			$Hash.ArchiveItemsSizeMBs = "{0:n4}" -f ($ArchiveItemSizeBytes / 1MB)
			$Arr += new-object psobject -property $Hash
	}
# If the mailbox has no archive data we pull the to date data for reference
Else
	{
		# Query for today's mailbox size and item count for reference
		$MBXStats = Get-MailboxStatistics -Identity $MBX
		# Convert the size field to a more useable value
		$ItemSizeBytes = ([Microsoft.Exchange.Data.ByteQuantifiedSize]$MBXStats.TotalItemSize).ToBytes()
		
		# Save our collection to a hash table and write the entry to an array
		$Hash = @{}
		$Hash.User = $MBX
		$Hash.Database = $MBXDatabase
		$Hash.Identity = $MBXSearch.Identity
		$Hash.ItemsCount = $MBXStats.ItemCount
		$Hash.ItemsSizeBytes = "{0:n0}" -f $ItemSizeBytes
		$Hash.ItemsSizeMBs = "{0:n4}" -f ($ItemSizeBytes / 1MB)
		$Arr += new-object psobject -property $Hash
	}
}
# Set the path and filename of your output file
$CSV = $filepath + $filename
# Order your array, sort your array, and export your array to a CSV file
$Arr
$Arr | select User,Database,Identity,ItemsCount,ItemsSizeBytes,ItemsSizeMBs,ArchiveItemsCount,ArchiveItemsSizeBytes,ArchiveItemsSizeMBs | sort User | Export-CSV $CSV -NoTypeInformation

# Display the start and end time of the script.
$EndTime = Get-Date -DisplayHint Time
Write-Host "The script has completed and your CSV file has been saved as" $CSV".  Data has been collected on items that are" $MailOlderThanDays "days or older.  This resulted in a collection of items sent on or before" $QueryDate"." -foreground yellow
Write-Host "Script Start time:  " $StartTime -foreground cyan
Write-Host "Script End time:  " $EndTime -foreground cyan