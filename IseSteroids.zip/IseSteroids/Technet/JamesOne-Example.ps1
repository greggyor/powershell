﻿PS> $Overlay = New-overlay -text "© James O'Neill 2009" -size 32 -TypeFace "Arial"  -color "red" -filename $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABQAHcAZABcAG8AdgBlAHIATABhAHkALgBqAHAAZwA=')))  

PS> $filter = new-Imagefilter |  
              Add-exifFilter       -passThru -ExifID   $ExifIDKeywords    -typeid   1101           -string    "Ocean,Bahamas"        |
              Add-exifFilter       -passThru -ExifID   $ExifIDTitle       -typeName "vectorofbyte" -string    "fish"                 |  
              Add-exifFilter       -passThru -ExifID   $ExifidCopyright   -typeName "String"       -value     "© James O'Neill 2009" | 
              Add-exifFilter       -passThru -ExifID   $ExifIDGPSAltitude -typeName "uRational"    -Numerator 123 -denominator 10    |
              Add-exifFilter       -passThru -ExifID   $ExifIDGPSAltRef   -typeName "Byte"         -value     1                      |
              Add-ScaleFilter      -passThru -height   800                -width    65535    | 
              Add-OverlayFilter    -passThru -top      0   -left    0     -image    $Overlay | 
              Add-ConversionFilter -passThru -typeName jpg -quality 70 

PS> Get-Image C:\Users\Jamesone\Pictures\IMG_3333.JPG  | Set-ImageFilter -passThru -filter $filter | Save-image -fileName {$_.FullName -replace ".jpg$","-small2.jpg"}

function Copy-Exif{
    Param  ( [Parameter(Mandatory=$true  ,valueFromPipeline=$true )] $DestinationPath,
             [Parameter(Mandatory=$true )] $SourcePath   ,
             [switch]$fixICE) 
    process {
        $destinationPath | foreach {               & 'C:\Program Files (x86)\EXIFutils\exifcopy.exe' "/bq" "/o" $SourcePath $_
                                                   & 'C:\Program Files (x86)\EXIFutils\exifedit'    "/b"   "/r" print-im    $_     
                                    if ($FixICE) { & 'C:\Program Files (x86)\EXIFutils\exifedit'    "/b"   "/a" "Firm-ver=Microsoft ICE v1.4.4.0" "/r" "orient" "/s" "/t" "a,160" $DestinationPath }
                                    }
    }
}

function Fix-ICeExif{
    Param  ( [Parameter(Mandatory=$true  ,valueFromPipeline=$true )] $DestinationPath)
& 'C:\Program Files (x86)\EXIFutils\exifedit'     "/b"   "/a" "Firm-ver=Microsoft ICE v1.4.4.0" "/r" "orient" "/s"  "/t" "a,160" $DestinationPath 
}



${00010001100110000}           = [system.environment]::GetFolderPath( [system.environment+specialFolder]::MyPictures )
${10100111100011101}           = "Exploring"
$sourcePath         = "E:\DCIM\100PENTX"
${01100101010101000}            = "F:\My Documents\My GPS\Track Log\20100404143612.log"
${01011001000010001}            = ([datetime]"04/04/2010 16:02:17 +1")
${01010111000010100} = "E:\DCIM\100PENTX\IMG43272.JPG"
${01100010110000100}             = $null 
${00010000011001110}         = $null 
${01001101011000011}           = $False
${00111110111100010}            = $True

if (${01011001000010001} -and ${01010111000010100}  ) {
        if  (-not (test-path ${01010111000010100}) )  {Write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABmAGkAbgBkACAAJAB7ADAAMQAwADEAMAAxADEAMQAwADAAMAAwADEAMAAxADAAMAB9ACwAIABlAHgAaQB0AGkAbgBnACAA'))); return }
        ${01011100001101110} = (get-image ${01010111000010100} | get-Exif).dateTaken
        ${01100010110000100}  = ( ${01011100001101110} -  ${01011001000010001}.ToUniversalTime() ).totalSeconds
}
if (${01100010110000100} -eq $null) {   # Not passed as a param or calculated
    switch  (Select-Item -Caption "Log to camera time offset " -TextChoices "Camera and log are &Sync'd", "&Calculate from a picture of the logger", "&Enter offset manually") 
       {   0 { ${01100010110000100} = 0 }
           1 { if (-not ${01011001000010001}) {${01011001000010001} = ([datetime]( Read-Host ("Please enter the Date & time, in the reference picture, formatted as" + [char]13 + [Char]10 +
                                                                      "Either MM/DD/yyyy HH:MM:SS ±Z or  dd MMMM yyyy HH:mm:ss ±Z")
                                               )).touniversalTime()}
                if (-not ${01010111000010100}) {${01010111000010100}  = Read-Host "Please enter the path to the picture"}
                if (${01010111000010100} -and (test-path ${01010111000010100}) -and ${01011001000010001}) { 
                   ${01011100001101110} =  (get-image ${01010111000010100} | get-Exif).dateTaken
                   ${01100010110000100} = ( ${01011100001101110} - ${01011001000010001}).totalSeconds
                }
                else  {Write-host "A valid reference image path and time are needed"; return }
             }
           2 {[long]${01100010110000100}  = Read-Host ("Please enter the offset in seconds:" + [char]13 + [char]10 + 
                                          "negative for logger before camera time, " + [char]13 + [char]10 + 
                                          "positive for camera time before logger.")  }
       }
}

if (-not ${01100101010101000}) {${01100101010101000} = Read-Host "Please enter the path to the log file"}
if (${01100101010101000} -and (test-path ${01100101010101000})) { 
############ Suunto 
   if     (${01001101011000011} )  { ${10011001001011010} =  Get-NMEAGPSData   -Path ${01100101010101000} -offset ${01100010110000100}  }
   elseif (${00111110111100010}  )  { ${10011001001011010} =  Get-EfficaGPSData -Path ${01100101010101000} -offset ${01100010110000100}  }
   else   {switch  (Select-Item -Message "What kind of data do you want to add " -TextChoices "GPS data from &Efficasoft", "GPS data in &NMEA format") 
                {   0 { ${10011001001011010} =  Get-EfficaGPSData -Path ${01100101010101000} -offset ${01100010110000100}  }
                    1 { ${10011001001011010} =  Get-NMEAGPSData   -Path ${01100101010101000} -offset ${01100010110000100}  }
                }
   }
}
else {Write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHUAbABkACAAbgBvAHQAIABmAGkAbgBkACAAbABvAGcAcABhAHQAaAA6ACAAJAB7ADAAMQAxADAAMAAxADAAMQAwADEAMAAxADAAMQAwADAAMAB9ACAAZQB4AGkAdABpAG4AZwAgAA=='))); return }

if (${01010111000010100} -and (Test-Path ${01010111000010100})) {write-host "Check the following data against the reference picture"
                    get-nearestPoint -DataPoints ${10011001001011010} -ColumnName "DateTime" -MatchingTime ${01011100001101110} | ft * -a | Out-Host
                    ${10010100010000001} = Split-Path -Path ${01010111000010100}
}

If (-not $SourcPath) {
    $SourcePath = read-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABsAGUAYQBzAGUAIABlAG4AdABlAHIAIAB0AGgAZQAgAHAAYQB0AGgAIAB0AG8AIAB0AGgAZQAgAHQAaABlACAAcABpAGMAdAB1AHIAZQBzACAALQAgACQAewAxADAAMAAxADAAMQAwADAAMAAxADAAMAAwADAAMAAwADEAfQA='))) 
    If (-not $SourcePath) {$SourcePath = ${10010100010000001}}
}

If (-not ${00010001100110000}) {
    ${10010100010000001}  = [system.environment]::GetFolderPath( [system.environment+specialFolder]::MyPictures )
    ${00010001100110000} = read-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBoAGUAcgBlACAAdwBvAHUAbABkACAAeQBvAHUAIABsAGkAawBlACAAdABoAGUAIAB0AGEAZwBnAGUAZAAgAFAAaQBjAHQAdQByAGUAcwAgAHQAbwAgAGIAZQAgAHMAYQB2AGUAZAAgAC0AIAAkAHsAMQAwADAAMQAwADEAMAAwADAAMQAwADAAMAAwADAAMAAxAH0A'))) 
    If (-not ${00010001100110000}) {${00010001100110000} = ${10010100010000001}}
}

Get-ChildItem -Path (Join-path -Path $SourcePath -ChildPath "*.JPG") | Select-List -Property Name -multiple | Copy-SuutoImage -points ${10011001001011010} -DestPath ${00010001100110000} -keywords "Ocean;Bahamas"


$VerbosePreference="Continue"
${10011001001011010} =  Get-EfficaGPSData  -offset 3607 -Path 'f:\My Documents\My GPS\Track Log\20100425115503.log'
dir E:\DCIM\100PENTX\*.jpg | select-list -pro name -mul | %{ Get-Image $_ | Copy-GPSImage -points ${10011001001011010} -DestPath 'C:\users\Jamesone\Pictures\New folder' -keywords "foo" subject "bar"



${10010001010000001} = New-Object -ComObject "Mappoint.Application"
${10010001010000001}.Visible = $true


${00101010110101011} = ${10010001010000001}.ActiveMap
merge-gpsPoints -points ${10011001001011010} | foreach-object { ${10100001110010110}=${00101010110101011}.GetLocation($_.AveLat, $_.AveLong)
                           ${10110110110110111} = ${00101010110101011}.AddPushpin(${10100001110010110}, ("{0} - {1:00} MPH " -f $_.Minute,$_.Aveknots*1.1508))
                           if     ($_.aveknots -lt 35) {${10110110110110111}.symbol= 5 }
                           elseif ($_.aveknots -gt 47) {${10110110110110111}.symbol= 7 }
                           else                      {${10110110110110111}.symbol= 6 }
                           }
                           

