﻿Function Get-SubNetItems
{
	[CmdletBinding(
		SupportsShouldProcess=$True,
		ConfirmImpact="Low" 
	)]	
	param(
		[parameter(Mandatory=$true)]
		[System.Net.IPAddress]$StartScanIP,
		[System.Net.IPAddress]$EndScanIP,
		[Int]$MaxJobs = 20,
		[Int[]]$Ports,
		[Switch]$ShowAll,
		[Switch]$ShowInstantly,
		[Int]$SleepTime = 5,
		[Int]$TimeOut = 90
	)
	Begin{}
	Process
	{
		if ($pscmdlet.ShouldProcess($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABTAHQAYQByAHQAUwBjAGEAbgBJAFAAIAAkAEUAbgBkAFMAYwBhAG4ASQBQAA=='))) ,$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAEkAUAAgAHIAYQBuAGcAZQAgAGYAbwByACAAYQBjAHQAaQB2AGUAIABtAGEAYwBoAGkAbgBlAHMA')))))
		{
			if(gjb -name *.*.*.*)
			{
				Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAG0AbwB2AGkAbgBnACAAbwBsAGQAIABqAG8AYgBzAC4A')))
				gjb -name *.*.*.* | rjb -Force
			}
			$ScanIPRange = @()
			if($EndScanIP -ne $null)
			{
				Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwBlAG4AZQByAGEAdABpAG4AZwAgAEkAUAAgAHIAYQBuAGcAZQAgAGwAaQBzAHQALgA=')))
				$StartIP = $StartScanIP -split '\.'
	  			[Array]::Reverse($StartIP)  
	  			$StartIP = ([System.Net.IPAddress]($StartIP -join '.')).Address 
				$EndIP = $EndScanIP -split '\.'
	  			[Array]::Reverse($EndIP)  
	  			$EndIP = ([System.Net.IPAddress]($EndIP -join '.')).Address 
				For ($x=$StartIP; $x -le $EndIP; $x++) {    
					$IP = [System.Net.IPAddress]$x -split '\.'
					[Array]::Reverse($IP)   
					$ScanIPRange += $IP -join '.' 
				}
			}
			else
			{
				$ScanIPRange = $StartScanIP
			}
			Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwByAGUAYQB0AGkAbgBnACAAbwB3AG4AIABsAGkAcwB0ACAAYwBsAGEAcwBzAC4A')))
			$Class = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkAcAB1AGIAbABpAGMAIABjAGwAYQBzAHMAIABTAHUAYgBOAGUAdABJAHQAZQBtACAAewANAAoACQAJAAkACQBwAHUAYgBsAGkAYwAgAGIAbwBvAGwAIABBAGMAdABpAHYAZQA7AA0ACgAJAAkACQAJAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIABIAG8AcwB0ADsADQAKAAkACQAJAAkAcAB1AGIAbABpAGMAIABTAHkAcwB0AGUAbQAuAE4AZQB0AC4ASQBQAEEAZABkAHIAZQBzAHMAIABJAFAAOwANAAoACQAJAAkACQBwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAATQBBAEMAOwANAAoACQAJAAkACQBwAHUAYgBsAGkAYwAgAFMAeQBzAHQAZQBtAC4ATwBiAGoAZQBjAHQAIABQAG8AcgB0AHMAOwANAAoACQAJAAkACQBwAHUAYgBsAGkAYwAgAHMAdAByAGkAbgBnACAATwBTAF8ATgBhAG0AZQA7AA0ACgAJAAkACQAJAHAAdQBiAGwAaQBjACAAcwB0AHIAaQBuAGcAIABPAFMAXwBWAGUAcgA7AA0ACgAJAAkACQAJAHAAdQBiAGwAaQBjACAAYgBvAG8AbAAgAFcATQBJADsADQAKAAkACQAJAAkAcAB1AGIAbABpAGMAIABiAG8AbwBsACAAVwBpAG4AUgBNADsADQAKAAkACQAJAH0A')))		
			Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB0AGEAcgB0ACAAcwBjAGEAbgBpAG4AZwAuAC4ALgA=')))	
			$ScanResult = @()
			$ScanCount = 0
			Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAEkAUAAgAFIAYQBuAGcAZQAgACQAUwB0AGEAcgB0AFMAYwBhAG4ASQBQACAAJABFAG4AZABTAGMAYQBuAEkAUAA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgBpAG4AZwA6AA=='))) -Percentcomplete (0)
			Foreach($IP in $ScanIPRange)
			{
	 			Write-Verbose "Starting job ($((gjb -name *.*.*.* | measure).Count+1)/$MaxJobs) for $IP."
				sajb -Name $IP -ArgumentList $IP,$Ports,$Class -ScriptBlock{ 
					param
					(
					[System.Net.IPAddress]$IP = $IP,
					[Int[]]$Ports = $Ports,
					$Class = $Class 
					)
					Add-Type -TypeDefinition $Class
					if(Test-Connection -ComputerName $IP -Quiet)
					{
						Try
						{
							$HostName = [System.Net.Dns]::GetHostbyAddress($IP).HostName
						}
						Catch
						{
							$HostName = $null
						}
						Try
						{
							$WMIObj = [WMISearcher]''  
							$WMIObj.options.timeout = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('MAA6ADAAOgAxADAA'))) 
							$WMIObj.scope.path = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('XABcACQASQBQAFwAcgBvAG8AdABcAGMAaQBtAHYAMgA=')))  
							$WMIObj.query = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBFAEwARQBDAFQAIAAqACAARgBSAE8ATQAgAFcAaQBuADMAMgBfAE8AcABlAHIAYQB0AGkAbgBnAFMAeQBzAHQAZQBtAA==')))  
							$Result = $WMIObj.get()  
							if($Result -ne $null)
							{
								$OS_Name = $Result | select -ExpandProperty Caption
								$OS_Ver = $Result | select -ExpandProperty Version
								$OS_CSDVer = $Result | select -ExpandProperty CSDVersion
								$OS_Ver += $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAkAE8AUwBfAEMAUwBEAFYAZQByAA==')))
								$WMIAccess = $true					
							}
							else
							{
								$WMIAccess = $false	
							}
						}	
						catch
						{
							$WMIAccess = $false					
						}
						if($HostName)
						{
							$Result = icm -ComputerName $HostName -ScriptBlock {systeminfo} -ErrorAction SilentlyContinue 
						}
						else
						{
							$Result = icm -ComputerName $IP -ScriptBlock {systeminfo} -ErrorAction SilentlyContinue 
						}
						if($Result -ne $null)
						{
							if($OS_Name -eq $null)
							{
								$OS_Name = ($Result[2..3] -split $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgBcAHMAKwA='))))[1]
								$OS_Ver = ($Result[2..3] -split $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('OgBcAHMAKwA='))))[3]
							}	
							$WinRMAccess = $true
						}
						else
						{
							$WinRMAccess = $false
						}
						Try
						{
							$result= nbtstat -A $IP | select-string $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBBAEMA')))
							$MAC = [string]([Regex]::Matches($result, $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABbADAALQA5AEEALQBGAF0AWwAwAC0AOQBBAC0ARgBdAC0AKQB7ADUAfQAoAFsAMAAtADkAQQAtAEYAXQBbADAALQA5AEEALQBGAF0AKQA=')))))
						}
						Catch
						{
							$MAC = $null
						}
						$PortsStatus = @()
						ForEach($Port in $Ports)
						{
							Try
							{							
								$TCPClient = new-object Net.Sockets.TcpClient
								$TCPClient.Connect($IP, $Port)
								$TCPClient.Close()
								$PortStatus = New-Object PSObject -Property @{            
		        					Port		= $Port
									Status      = $true
								}
								$PortsStatus += $PortStatus
							}	
							Catch
							{
								$PortStatus = New-Object PSObject -Property @{            
		        					Port		= $Port
									Status      = $false
								}	
								$PortsStatus += $PortStatus
							}
						}
						$HostObj = New-Object SubNetItem -Property @{            
		        					Active		= $true
									Host        = $HostName
									IP          = $IP 
									MAC         = $MAC
									Ports       = $PortsStatus
		        					OS_Name     = $OS_Name
									OS_Ver      = $OS_Ver               
		        					WMI         = $WMIAccess      
		        					WinRM       = $WinRMAccess      
		        		}
						$HostObj
					}
					else
					{
						$HostObj = New-Object SubNetItem -Property @{            
		        					Active		= $false
									Host        = $null
									IP          = $IP  
									MAC         = $null
									Ports       = $null
		        					OS_Name     = $null
									OS_Ver      = $null               
		        					WMI         = $null      
		        					WinRM       = $null      
		        		}
						$HostObj
					}
				} | Out-Null
				$ScanCount++
				Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAEkAUAAgAFIAYQBuAGcAZQAgACQAUwB0AGEAcgB0AFMAYwBhAG4ASQBQACAAJABFAG4AZABTAGMAYQBuAEkAUAA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgBpAG4AZwA6AA=='))) -Percentcomplete ([int](($ScanCount+$ScanResult.Count)/(($ScanIPRange | measure).Count) * 50))
				do
				{
					Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHkAaQBuAGcAIABnAGUAdAAgAHAAYQByAHQAIABvAGYAIABkAGEAdABhAC4A')))
					gjb -State Completed | Foreach {
						Write-Verbose "Geting job $($_.Name) result."
						$JobResult = rcjb -Id ($_.Id)
						if($ShowAll)
						{
							if($ShowInstantly)
							{
								if($JobResult.Active -eq $true)
								{
									Write-Host "$($JobResult.IP) is active." -ForegroundColor Green
								}
								else
								{
									Write-Host "$($JobResult.IP) is inactive." -ForegroundColor Red
								}
							}
							$ScanResult += $JobResult	
						}
						else
						{
							if($JobResult.Active -eq $true)
							{
								if($ShowInstantly)
								{
									Write-Host "$($JobResult.IP) is active." -ForegroundColor Green
								}
								$ScanResult += $JobResult
							}
						}
						Write-Verbose "Removing job $($_.Name)."
						rjb -Id ($_.Id)
						Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAEkAUAAgAFIAYQBuAGcAZQAgACQAUwB0AGEAcgB0AFMAYwBhAG4ASQBQACAAJABFAG4AZABTAGMAYQBuAEkAUAA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgBpAG4AZwA6AA=='))) -Percentcomplete ([int](($ScanCount+$ScanResult.Count)/(($ScanIPRange | measure).Count) * 50))
					}
					if((gjb -name *.*.*.*).Count -eq $MaxJobs)
					{
						Write-Verbose "Jobs are not completed ($((gjb -name *.*.*.* | measure).Count)/$MaxJobs), please wait..."
						Sleep $SleepTime
					}
				}
				while((gjb -name *.*.*.*).Count -eq $MaxJobs)
			}
			$timeOutCounter = 0
			do
			{
				Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHkAaQBuAGcAIABnAGUAdAAgAGwAYQBzAHQAIABwAGEAcgB0ACAAbwBmACAAZABhAHQAYQAuAA==')))
				gjb -State Completed | Foreach {
					Write-Verbose "Geting job $($_.Name) result."
					$JobResult = rcjb -Id ($_.Id)
					if($ShowAll)
					{
						if($ShowInstantly)
						{
							if($JobResult.Active -eq $true)
							{
								Write-Host "$($JobResult.IP) is active." -ForegroundColor Green
							}
							else
							{
								Write-Host "$($JobResult.IP) is inactive." -ForegroundColor Red
							}
						}
						$ScanResult += $JobResult	
					}
					else
					{
						if($JobResult.Active -eq $true)
						{
							if($ShowInstantly)
							{
								Write-Host "$($JobResult.IP) is active." -ForegroundColor Green
							}
							$ScanResult += $JobResult
						}
					}
					Write-Verbose "Removing job $($_.Name)."
					rjb -Id ($_.Id)
					Write-Progress -Activity $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAEkAUAAgAFIAYQBuAGcAZQAgACQAUwB0AGEAcgB0AFMAYwBhAG4ASQBQACAAJABFAG4AZABTAGMAYQBuAEkAUAA='))) -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgBpAG4AZwA6AA=='))) -Percentcomplete ([int](($ScanCount+$ScanResult.Count)/(($ScanIPRange | measure).Count) * 50))
				}
				if(gjb -name *.*.*.*)
				{
					Write-Verbose "All jobs are not completed ($((gjb -name *.*.*.* | measure).Count)/$MaxJobs), please wait... ($timeOutCounter)"
					Sleep $SleepTime
					$timeOutCounter += $SleepTime				
					if($timeOutCounter -ge $TimeOut)
					{
						Write-Verbose "Time out... $TimeOut. Can't finish some jobs  ($((gjb -name *.*.*.* | measure).Count)/$MaxJobs) try remove it manualy."
						Break
					}
				}
			}
			while(gjb -name *.*.*.*)
			Write-Verbose $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAGEAbgAgAGYAaQBuAGkAcwBoAGUAZAAuAA==')))
			Return $ScanResult | sort {$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('ewAwADoAZAAzAH0ALgB7ADEAOgBkADMAfQAuAHsAMgA6AGQAMwB9AC4AewAzADoAZAAzAH0A'))) -f @([int[]]([string]$_.IP).split('.'))}
		}
	}
	End{}
}
