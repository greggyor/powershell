﻿$configFileName=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAEMAbwBuAGYAaQBnAF8AQQB1AHQAbwBTAHkAbgBjAC4AeABtAGwA')))
$sleepTimeInMilliSecs=0
$sleepTimeValueInMin=0
$masterMode=$true

$bkmrkName=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABTAEQAaABjAHAAQQB1AHQAbwBTAHkAbgBjAEIAbwBvAGsAbQBhAHIAawA=')))


# Logs output to output screen and file $outputFileName.
# If color value is given output on screen is logged with the given color value.
function log([string]$outputString,[string]$color)
{
    if($color -ne "")
    {
        Write-Host $outputString -ForegroundColor $color  #To log output on screen.
    }
    else
    {
        Write-Host $outputString  #To log output on screen.
    }
    $outputString >> $script:outputFileName #To log output to file $outputFileName.
} 

# Help function.
function Help()
{
	Write-Host ""
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBTAEEARwBFADoAIABQAFMAIABDADoAXAA+AC4AXABEAGgAYwBwAEYAYQBpAGwAbwB2AGUAcgBBAHUAdABvAEMAbwBuAGYAaQBnAFMAeQBuAGMAVABvAG8AbAAuAHAAcwAxAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAXwBBAHUAdABvAFMAeQBuAGMALgB4AG0AbAAgAHAAcgBlAHMAZQBuAHQAIABpAG4AIABjAHUAcgByAGUAbgB0ACAAdwBvAHIAawBpAG4AZwAgAGQAaQByAGUAYwB0AG8AcgB5ACAAdwBpAGwAbAAgAGIAZQAgAHUAcwBlAGQAIABmAG8AcgAgAGMAbwBuAGYAaQBnAHUAcgBhAHQAaQBvAG4AIABwAGEAcgBhAG0AZQB0AGUAcgBzAC4A'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
	Write-Host ""
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuACAARABlAGYAYQB1AGwAdAAgAFIAZQBwAGwAaQBjAGEAdABpAG8AbgAgAE0AbwBkAGUA'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAtACAAVABoAGUAIAB0AG8AbwBsACAAdwBpAGwAbAAgAHMAeQBuAGMAIABhAG4AeQAgAHMAYwBvAHAAZQAgAGMAaABhAG4AZwBlACAAYgBlAGwAbwBuAGcAaQBuAGcAIAB0AG8AIABhAGwAbAAgAGYAYQBpAGwAbwB2AGUAcgAgAHIAZQBsAGEAdABpAG8AbgBzACAAbwBuACAAdABoAGkAcwAgAHMAZQByAHYAZQByAC4A'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAtACAATgBvACAAcwBwAGUAYwBpAGYAaQBjACAAYQBkAG0AaQBuACAAYQBjAHQAaQBvAG4AIABpAHMAIAByAGUAcQB1AGkAcgBlAGQALgAgAFQAaABlACAAdABvAG8AbAAgAHQAYQBrAGUAcwAgAGMAYQByAGUAIABvAGYAIABhAHUAdABvACAAcwB5AG4AYwAgAG8AZgAgAGEAbABsACAAcwBjAG8AcABlAHMAIABpAG4AIABhAGwAbAAgAEYAYQBpAGwAbwB2AGUAcgAgAHIAZQBsAGEAdABpAG8AbgBzAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
	Write-Host ""
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuACAAUwBlAGwAZQBjAHQAaQB2AGUAIABSAGUAcABsAGkAYwBhAHQAaQBvAG4AIABNAG8AZABlAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAtACAAVABoAGUAIAB0AG8AbwBsACAAdABhAGsAZQBzACAAYwBhAHIAZQAgAG8AZgAgAGEAdQB0AG8AIABzAHkAbgBjACAAbwBmACAATwBOAEwAWQAgAHQAaABlACAARgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuAHMAIABtAGUAbgB0AGkAbwBuAGUAZAAgAGkAbgAgAGMAbwBuAGYAaQBnACAAZgBpAGwAZQAuAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAtACAAQQBkAG0AaQBuACAAcwBoAG8AdQBsAGQAIABhAGQAZAAgAGUAbgB0AHIAaQBlAHMAIAB1AG4AZABlAHIAIAA8AEYAYQBpAGwAbwB2AGUAcgBSAGUAbABhAHQAaQBvAG4AcwBoAGkAcABzAD4ALgAgAE0AbwByAGUAIABkAGUAdABhAGkAbABzACAAYQByAGUAIABwAHIAbwB2AGkAZABlAGQAIABpAG4AIABDAG8AbgBmAGkAZwBfAEEAdQB0AG8AUwB5AG4AYwAuAHgAbQBsAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))	
	Write-Host ""
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAVwBoAGUAbgAgAHQAaABlACAAdABvAG8AbAAgAGkAcwAgAHIAdQBuAG4AaQBuAGcALAAgAGkAdAAgAHcAaQBsAGwAIABuAG8AdAAgAHAAaQBjAGsA'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
	Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAMQAuACAAQQBuAHkAIABjAGgAYQBuAGcAZQAgAGQAbwBuAGUAIABpAG4AIABDAG8AbgBmAGkAZwBfAEEAdQB0AG8AUwB5AG4AYwAuAHgAbQBsAC4AIABbAEEAcABwAGwAaQBjAGEAYgBsAGUAIABmAG8AcgAgAGIAbwB0AGgAIABEAGUAZgBhAHUAbAB0ACAAUgBlAHAAbABpAGMAYQB0AGkAbwBuACAATQBvAGQAZQAgAGEAbgBkACAAUwBlAGwAZQBjAHQAaQB2AGUAIABSAGUAcABsAGkAYwBhAHQAaQBvAG4AIABNAG8AZABlAF0A'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))	
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAMgAuACAAQQBuAHkAIABuAGUAdwAgAEYAYQBpAGwAbwB2AGUAcgAgAHIAZQBsAGEAdABpAG8AbgBzAGgAaQBwACAAaQBzACAAYwByAGUAYQB0AGUAZAAuACAAWwBBAHAAcABsAGkAYwBhAGIAbABlACAAbwBuAGwAeQAgAGkAbgAgAFMAZQBsAGUAYwB0AGkAdgBlACAAUgBlAHAAbABpAGMAYQB0AGkAbwBuACAATQBvAGQAZQBdAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))	
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAAgACAAIAAgACAAIAAgACAAUwBPAEwAVQBUAEkATwBOADoAIABTAHQAbwBwACAAdABoAGUAIAB0AG8AbwBsACAAKABCAHkAIABoAGkAdAB0AGkAbgBnACAAQwB0AHIAbAArAEMAKQAgAGEAbgBkACAAcgBlAC0AcgB1AG4AIAB0AGgAZQAgAHQAbwBvAGwAIQA='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
}

# Closes tool gracefully clearing all registry keys, values.
# Assumes sever will be in sync when tool starts again.
function CloseTool()
{
    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABvAG8AbAAgAGkAcwAgAGUAeABpAHQAaQBuAGcALgA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGkAbgBnACAAcgBlAGcAaQBzAHQAcgB5ACAAawBlAHkAIABtAGEAaQBuAHQAYQBpAG4AZQBkACAAYgB5ACAAdABoAGUAIAB0AG8AbwBsAC4A')))
    
	try
    {
        rd -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -ea stop
    }
    catch
    {
    }
	
    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBoAHUAdAB0AGkAbgBnACAAZABvAHcAbgAgAGMAbwBtAHAAbABlAHQAZQBkACAAcwB1AGMAYwBlAHMAcwBmAHUAbABsAHkALgA=')))
    exit
}

# Parse input configuration xml file.
function ParseInputXml()
{
    try
    {
        $inputXmlNode=[xml](gc $Script:configFileName)
        $documentNode=$inputXmlNode.PSDhcpAutoSync
        if($documentNode -ne $null)
        {
            $logFileNameValue=$documentNode.LogFileName
            if($logFileNameValue -ne $null)
            {
                $script:outputFileName=$logFileNameValue
                try
                {
                    "$(Get-Date)" >> $script:outputFileName
                }
                catch
                {
                    Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAVQBuAGEAYgBsAGUAIAB0AG8AIAB3AHIAaQB0AGUAIAB0AG8AIABsAG8AZwAgAGYAaQBsAGUAIAAkAHMAYwByAGkAcAB0ADoAbwB1AHQAcAB1AHQARgBpAGwAZQBOAGEAbQBlAA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
                    Write-host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAVwByAGkAdABpAG4AZwAgAHQAbwAgAGQAZQBmAGEAdQBsAHQAIABsAG8AZwAgAGYAaQBsAGUAIAAuAFwARABoAGMAcABBAHUAdABvAFMAeQBuAGMATABvAGcAZgBpAGwAZQAuAHQAeAB0AA=='))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
                    $script:outputFileName=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LgBcAEQAaABjAHAAQQB1AHQAbwBTAHkAbgBjAEwAbwBnAGYAaQBsAGUALgB0AHgAdAA=')))
                    "$(Get-Date)" >> $script:outputFileName
                }
            }
            else
            {
				log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIAA8AEwAbwBnAEYAaQBsAGUATgBhAG0AZQA+ACAAbgBvAGQAZQAgAGkAcwAgAG0AaQBzAHMAaQBuAGcAIABpAG4AIABDAG8AbgBmAGkAZwBfAEEAdQB0AG8AUwB5AG4AYwAuAHgAbQBsAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
				CloseTool
            }
            $script:sleepTimeValueInMin=$documentNode.PeriodicRetryInterval
            if($sleepTimeValueInMin -ne $null)
            {
                $script:sleepTimeInMilliSecs=([int]$script:sleepTimeValueInMin)*(60*1000)
            }
            else
            {
                log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIAA8AFAAZQByAGkAbwBkAGkAYwBSAGUAdAByAHkASQBuAHQAZQByAHYAYQBsAD4AIABuAG8AZABlACAAaQBzACAAbQBpAHMAcwBpAG4AZwAgAGkAbgAgAEMAbwBuAGYAaQBnAF8AQQB1AHQAbwBTAHkAbgBjAC4AeABtAGwA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
				CloseTool
            }
            $relationNode=$documentNode.FailoverRelationships
            $script:includeRelations=$relationNode.Include.Relation
            $script:excludeRelations=$relationNode.Exclude.Relation
        }
        else
        {
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIABVAG4AYQBiAGwAZQAgAHQAbwAgAHIAZQBhAGQAIABjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuACAAZgBpAGwAZQAgAEMAbwBuAGYAaQBnAF8AQQB1AHQAbwBTAHkAbgBjAC4AeABtAGwA'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
            CloseTool
        }
    }
    catch
    {
        Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIABVAG4AYQBiAGwAZQAgAHQAbwAgAHIAZQBhAGQAIABjAG8AbgBmAGkAZwB1AHIAYQB0AGkAbwBuACAAZgBpAGwAZQAgAEMAbwBuAGYAaQBnAF8AQQB1AHQAbwBTAHkAbgBjAC4AeABtAGwA'))) -ForegroundColor $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
        CloseTool
    }
}

# Checks input relation and makes sure if script is running on other side 
# it is not syncing scopes for this relation.
function CheckRelation($relationName)
{
    try
    {
        $failoverRelation=Get-DhcpServerv4Failover -Name $relationName -ea Stop
        $remoteServerName=$failoverRelation.PartnerServer
        $baseKey=[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABvAGMAYQBsAE0AYQBjAGgAaQBuAGUA'))),$remoteServerName)
        try
        {
            $dhcpAutoSyncKey=$baseKey.OpenSubKey($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBZAFMAVABFAE0AXABcAEMAdQByAHIAZQBuAHQAQwBvAG4AdAByAG8AbABTAGUAdABcAFwAUwBlAHIAdgBpAGMAZQBzAFwAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAXABQAGEAcgBhAG0AZQB0AGUAcgBzAFwAXABEAEgAQwBQAEEAdQB0AG8AUwB5AG4AYwA='))))
            if(($dhcpAutoSyncKey.GetValueNames() -contains $relationName) -or 
			   ($dhcpAutoSyncKey.GetValue($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAHMAdABlAHIATQBvAGQAZQA=')))) -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHUAZQA=')))))
            {
              log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABoAGMAcABGAGEAaQBsAG8AdgBlAHIAQQB1AHQAbwBDAG8AbgBmAGkAZwBTAHkAbgBjAFQAbwBvAGwAIABpAHMAIABhAGwAcgBlAGEAZAB5ACAAcgB1AG4AbgBpAG4AZwAgAG8AbgAgAHAAYQByAHQAbgBlAHIAIABzAGUAcgB2AGUAcgAgAGYAbwByACAARgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAJAByAGUAbABhAHQAaQBvAG4ATgBhAG0AZQAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
              log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBmACAAdABoAGUAIAB0AG8AbwBsACAAaQBzACAAbgBvAHQAIAByAHUAbgBuAGkAbgBnACAAbwBuACAAdABoAGUAIABwAGEAcgB0AG4AZQByACAAcwBlAHIAdgBlAHIAIABvAHIAIABzAG8AbQBlACAAbwB0AGgAZQByACAAZQByAHIAbwByACAAaABhAHMAIABvAGMAYwB1AHIAZQBkACwAIAB0AGgAZQBuACAAcABsAGUAYQBzAGUAIAByAGUAcwB0AGEAcgB0ACAA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
			  log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABoAGUAIAB0AG8AbwBsACAAbwBuACAAcwBlAHIAdgBlAHIAIAAkAHIAZQBtAG8AdABlAFMAZQByAHYAZQByAE4AYQBtAGUAIABvAHIAIABlAHgAYwBsAHUAZABlACAARgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAJAByAGUAbABhAHQAaQBvAG4ATgBhAG0AZQAgAGYAcgBvAG0AIABjAHUAcgByAGUAbgB0ACAAYwBvAG4AdABlAHgAdAAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
			  log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBSAFIATwBSADoAIABDAG8AbgBmAGwAaQBjAHQAIABEAGUAdABlAGMAdABlAGQAIQAgAEEAYgBvAHIAdABpAG4AZwAgAHMAYwByAGkAcAB0AC4ALgAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
              exit
            }
            log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAaQBuAGcAIAByAGUAbABhAHQAaQBvAG4AIAAkAHIAZQBsAGEAdABpAG8AbgBOAGEAbQBlACAAdABvACAAbABpAHMAdAAgAG8AZgAgAHIAZQBsAGEAdABpAG8AbgBzACAAdwBoAGkAYwBoACAAdwBpAGwAbAAgAGIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjAGUAZAAuAA==')))
            [System.Array]$script:allRelations += $relationName
        }
        catch # Tool not running on other side.
        {
            log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAaQBuAGcAIAByAGUAbABhAHQAaQBvAG4AIAAkAHIAZQBsAGEAdABpAG8AbgBOAGEAbQBlACAAdABvACAAbABpAHMAdAAgAG8AZgAgAHIAZQBsAGEAdABpAG8AbgBzACAAdwBoAGkAYwBoACAAdwBpAGwAbAAgAGIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjAGUAZAAuAA==')))
            [System.Array]$script:allRelations += $relationName
        }
    } # Relation is down or doesn't exist.
    catch
    {
        log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAUABhAHIAdABuAGUAcgAgAHMAZQByAHYAZQByACAAZgBvAHIAIAByAGUAbABhAHQAaQBvAG4AIAAkAHIAZQBsAGEAdABpAG8AbgBOAGEAbQBlACAAbgBvAHQAIABhAGMAYwBlAHMAcwBpAGIAbABlAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
        log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBkAGQAaQBuAGcAIAByAGUAbABhAHQAaQBvAG4AIAAkAHIAZQBsAGEAdABpAG8AbgBOAGEAbQBlACAAdABvACAAbABpAHMAdAAgAG8AZgAgAHIAZQBsAGEAdABpAG8AbgBzACAAdwBoAGkAYwBoACAAdwBpAGwAbAAgAGIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjAGUAZAAuAA==')))
        [System.Array]$script:allRelations += $relationName
    }
}

# Checks every relation considered for sync and makes sure script 
# is not running on other side/server also with this relation initially.
function CheckAllRelations()
{
    if($script:includeRelations -eq $null) # If no relation is given to be included than including all as default case.
    {
        $script:includeRelations=(Get-DhcpServerv4Failover).Name
        $Script:masterMode = $Script:masterMode -and $true
    }
    else
    {
        $Script:masterMode = $Script:masterMode -and $false
    }
    if($script:excludeRelations -eq $null)
    {
        $Script:masterMode = $Script:masterMode -and $true
    }
    else
    {
        $script:includeRelations= @($script:includeRelations| ? {$script:excludeRelations -notcontains $_})
        $Script:masterMode = $Script:masterMode -and $false
    }
    foreach($relationName in $script:includeRelations)
    {
        CheckRelation $relationName
    }
    if($Script:masterMode)
    {
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgB1AG4AbgBpAG4AZwAgAHMAYwByAGkAcAB0ACAAaQBuACAARABlAGYAYQB1AGwAdAAgAFIAZQBwAGwAaQBjAGEAdABpAG8AbgAgAE0AbwBkAGUALgA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBsAGwAIABzAGMAbwBwAGUAcwAgAGIAZQBsAG8AbgBnAGkAbgBnACAAdABvACAAYQBuAHkAIABmAGEAaQBsAG8AdgBlAHIAIAByAGUAbABhAHQAaQBvAG4AIAAoAGkAbgBjAGwAdQBkAGkAbgBnACAAdABoAGUAIABuAGUAdwBsAHkAIABhAGQAZABlAGQAIAByAGUAbABhAHQAaQBvAG4AcwApACAAdwBpAGwAbAAgAGIAZQAgAHMAeQBuAGMAZQBkACAAYQB1AHQAbwBtAGEAdABpAGMAYQBsAGwAeQAuAA==')))
    }
    else
    {
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgB1AG4AbgBpAG4AZwAgAHMAYwByAGkAcAB0ACAAaQBuACAAUwBlAGwAZQBjAHQAaQB2AGUAIABSAGUAcABsAGkAYwBhAHQAaQBvAG4AIABNAG8AZABlAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
        if($script:allRelations -eq $null)
        {
            log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAATgBvACAAZgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAZgBvAHUAbgBkACAAdABvACAAcwB5AG4AYwAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
            log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAGUAYQBuAGkAbgBnACAAYQBsAGwAIABhAG4AZAAgAGUAeABpAHQAaQBuAGcALgA=')))
            CloseTool
        }
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlACAAYgBlAGwAbwBuAGcAaQBuAGcAIAB0AG8AIABmAG8AbABsAG8AdwBpAG4AZwAgAGYAYQBpAGwAbwB2AGUAcgAgAHIAZQBsAGEAdABpAG8AbgBzACAAdwBpAGwAbAAgAGIAZQAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjAGUAZAA6AA==')))
        foreach($relationName in $script:allRelations)
        {
            log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAByAGUAbABhAHQAaQBvAG4ATgBhAG0AZQA=')))
        }
    }
}

# Initializes all variables and all 
# relations which this script will handle.
function Initialize()
{
    if($Script:args.count -gt 0)
    {
		Help
        exit
    }

    if(Test-Path $Script:configFileName)
    {
        Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHIAcwBpAG4AZwAgAFgAbQBsACAAQwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgAgAGYAaQBsAGUALgA=')))
        ParseInputXml
        Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgAgAGYAaQBsAGUAIABwAGEAcgBzAGUAZAAuAA==')))
    }
    else
    {
        Write-Host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgAgAGYAaQBsAGUAIAAkAFMAYwByAGkAcAB0ADoAYwBvAG4AZgBpAGcARgBpAGwAZQBOAGEAbQBlACAAbgBvAHQAIABmAG8AdQBuAGQALgA=')))
		Help
        exit
    }
    CheckAllRelations
	
	log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAGkAdABpAGEAbABpAHoAYQB0AGkAbwBuACAAQwBvAG0AcABsAGUAdABlAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwB5AGEAbgA=')))
}


# Initializing...
Initialize

# Tries to sync given scope $scopeName with recordId $recordId.
# If it fails due to network problem then it automatically tries again
# later else logs error with red color and scope has to be synced manually.
# In selective if scope belongs to relation not under consideration 
# than changes are ignored.
function TrySync([string]$scopeName,[int64]$recordId)
{
    try
    {
        $output=Get-DhcpServerv4Failover -ScopeId $scopeName -ea stop
        if($script:masterMode -or ($script:allRelations -contains $($output.Name)))
        {
            try
            {
                $output=Invoke-DhcpServerv4FailoverReplication -ScopeId $scopeName -Force -ea stop
                log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlACAAJABvAHUAdABwAHUAdAAgAHMAeQBuAGMAZQBkAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAGUAZQBuAA==')))
            }
            catch
            {
                if($Error[0].FullyQualifiedErrorId -match $script:networkDownError)
                {
                    log ""
                    log "ERROR: $($Error[0])" $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGEAYgBsAGUAIAB0AG8AIABzAHkAbgBjACAAcwBjAG8AcABlACAAJABzAGMAbwBwAGUATgBhAG0AZQAgAGIAZQBjAGEAdQBzAGUAIABvAGYAIABzAG8AbQBlACAAbgBlAHQAdwBvAHIAawAgAHAAcgBvAGIAbABlAG0ALgAgAFcAaQBsAGwAIABhAHUAdABvAG0AYQB0AGkAYwBhAGwAbAB5ACAAdAByAHkAIABhAGcAYQBpAG4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBmAHQAZQByACAAJABzAGMAcgBpAHAAdAA6AHMAbABlAGUAcABUAGkAbQBlAFYAYQBsAHUAZQBJAG4ATQBpAG4AIABNAGkAbgB1AHQAZQBzAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    try
                    {
                        $script:pendingScopesTable.Add($scopeName,"")
                    }
                    catch
                    {
                    }
                }
                else
                {
                    log ""
                    log "ERROR: $($Error[0])" $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlACAAJABzAGMAbwBwAGUATgBhAG0AZQAgAG4AbwB0ACAAcwB5AG4AYwBlAGQALgAgAFAAbABlAGEAcwBlACAAcwB5AG4AYwAgAGkAdAAgAG0AYQBuAHUAYQBsAGwAeQAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                }
            }
        }
        else
        {
            #log "WARNING: Scope $scopeName belongs to relation $($output.Name) which doesn't belong to set of relations being automatically synced." "Yellow"
			#log "Not syncing changes made to scope $scopeName." "Yellow"
        }
    }
    catch
    {
        # Scope doesn't belong to any relation please create a failover relation for it to ensure safety.
        log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAUwBjAG8AcABlACAAJABzAGMAbwBwAGUATgBhAG0AZQAgAGQAbwBlAHMAbgAnAHQAIABiAGUAbABvAG4AZwAgAHQAbwAgAGEAbgB5ACAAZgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAYQBuAGQAIAB0AGgAZQAgAGMAaABhAG4AZwBlAHMAIAB3AGkAbABsACAA'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
		log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('bgBvAHQAIABiAGUAIABzAHkAbgBjAGgAcgBvAG4AaQB6AGUAZAAuAFAAbABlAGEAcwBlACAAYwByAGUAYQB0AGUAIABhACAAZgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAZgBvAHIAIABpAHQAIAB0AG8AIABlAG4AcwB1AHIAZQAgAHMAYQBmAGUAdAB5AC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
    }
    $script:bkmrk=$recordId
}




# C# code for event subscription.
# Wait is done till new event is registered or timeout time $sleepTimeValueInMin is reached.

$EventSubscriptionCode = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dQBzAGkAbgBnACAAUwB5AHMAdABlAG0AOwANAAoAdQBzAGkAbgBnACAAUwB5AHMAdABlAG0ALgBUAGgAcgBlAGEAZABpAG4AZwA7AA0ACgB1AHMAaQBuAGcAIABTAHkAcwB0AGUAbQAuAEQAaQBhAGcAbgBvAHMAdABpAGMAcwAuAEUAdgBlAG4AdABpAG4AZwAuAFIAZQBhAGQAZQByADsADQAKAA0ACgBuAGEAbQBlAHMAcABhAGMAZQAgAFAAUwBEAEgAQwBQAEEAdQB0AG8AUwB5AG4AYwBFAHYAZQBuAHQAUwB1AGIAcwBjAHIAaQBwAHQAaQBvAG4ADQAKAHsADQAKACAAIAAgACAAcAB1AGIAbABpAGMAIABjAGwAYQBzAHMAIABFAHYAZQBuAHQAUwB1AGIAcwBjAHIAaQBwAHQAaQBvAG4ADQAKACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAQQB1AHQAbwBSAGUAcwBlAHQARQB2AGUAbgB0ACAAbgBlAHcARQB2AGUAbgB0AFIAZQBnAGkAcwB0AGUAcgBlAGQAIAA9ACAAbgBlAHcAIABBAHUAdABvAFIAZQBzAGUAdABFAHYAZQBuAHQAKABmAGEAbABzAGUAKQA7AA0ACgAgACAAIAAgACAAIAAgACAAcAB1AGIAbABpAGMAIABiAG8AbwBsACAAYwB0AHIAbABDAFAAcgBlAHMAcwBlAGQAPQBmAGEAbABzAGUAOwANAAoAIAAgACAAIAAgACAAIAAgAHAAdQBiAGwAaQBjACAAdgBvAGkAZAAgAFMAdQBiAHMAYwByAGkAYgBlAEUAdgBlAG4AdABzACgAKQANAAoAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEUAdgBlAG4AdABMAG8AZwBRAHUAZQByAHkAIABzAHUAYgBzAGMAcgBpAHAAdABpAG8AbgBRAHUAZQByAHkAIAA9ACAADQAKAAkACQAJAAkAbgBlAHcAIABFAHYAZQBuAHQATABvAGcAUQB1AGUAcgB5ACgAIgBNAGkAYwByAG8AcwBvAGYAdAAtAFcAaQBuAGQAbwB3AHMALQBEAGgAYwBwAC0AUwBlAHIAdgBlAHIALwBPAHAAZQByAGEAdABpAG8AbgBhAGwAIgAsACAAUABhAHQAaABUAHkAcABlAC4ATABvAGcATgBhAG0AZQAsACAAIgAqAFsAUwB5AHMAdABlAG0AWwBFAHYAZQBuAHQASQBEAD4APQAwAF0AXQAiACkAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAARQB2AGUAbgB0AEwAbwBnAFcAYQB0AGMAaABlAHIAIABzAGMAbwBwAGUAUgBlAGwAYQB0AGkAbwBuAEMAaABhAG4AZwBlAEUAdgBlAG4AdABXAGEAdABjAGgAZQByACAAPQAgAG4AZQB3ACAARQB2AGUAbgB0AEwAbwBnAFcAYQB0AGMAaABlAHIAKABzAHUAYgBzAGMAcgBpAHAAdABpAG8AbgBRAHUAZQByAHkAKQA7AA0ACgAgACAAIAAgACAAIAAgACAAIAAgACAAIABzAGMAbwBwAGUAUgBlAGwAYQB0AGkAbwBuAEMAaABhAG4AZwBlAEUAdgBlAG4AdABXAGEAdABjAGgAZQByAC4ARQB2AGUAbgB0AFIAZQBjAG8AcgBkAFcAcgBpAHQAdABlAG4AIAArAD0ADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3ACAARQB2AGUAbgB0AEgAYQBuAGQAbABlAHIAPABFAHYAZQBuAHQAUgBlAGMAbwByAGQAVwByAGkAdAB0AGUAbgBFAHYAZQBuAHQAQQByAGcAcwA+ACgAUwBjAG8AcABlAFIAZQBsAGEAdABpAG8AbgBDAGgAYQBuAGcAZQBFAHYAZQBuAHQAUgBlAGEAZAApADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAHMAYwBvAHAAZQBSAGUAbABhAHQAaQBvAG4AQwBoAGEAbgBnAGUARQB2AGUAbgB0AFcAYQB0AGMAaABlAHIALgBFAG4AYQBiAGwAZQBkACAAPQAgAHQAcgB1AGUAOwANAAoADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEMAbwBuAHMAbwBsAGUALgBUAHIAZQBhAHQAQwBvAG4AdAByAG8AbABDAEEAcwBJAG4AcAB1AHQAIAA9ACAAZgBhAGwAcwBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAEMAbwBuAHMAbwBsAGUALgBDAGEAbgBjAGUAbABLAGUAeQBQAHIAZQBzAHMAIAArAD0AIABuAGUAdwAgAEMAbwBuAHMAbwBsAGUAQwBhAG4AYwBlAGwARQB2AGUAbgB0AEgAYQBuAGQAbABlAHIAKABDAHQAcgBsAEMASABhAG4AZABsAGUAcgApADsADQAKACAAIAAgACAAIAAgACAAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAcAB1AGIAbABpAGMAIAB2AG8AaQBkACAAUwBjAG8AcABlAFIAZQBsAGEAdABpAG8AbgBDAGgAYQBuAGcAZQBFAHYAZQBuAHQAUgBlAGEAZAAoAG8AYgBqAGUAYwB0ACAAbwBiAGoALAAgAEUAdgBlAG4AdABSAGUAYwBvAHIAZABXAHIAaQB0AHQAZQBuAEUAdgBlAG4AdABBAHIAZwBzACAAYQByAGcAKQANAAoAIAAgACAAIAAgACAAIAAgAHsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAG4AZQB3AEUAdgBlAG4AdABSAGUAZwBpAHMAdABlAHIAZQBkAC4AUwBlAHQAKAApADsADQAKACAAIAAgACAAIAAgACAAIAB9AA0ACgAgACAAIAAgACAAIAAgACAAcAB1AGIAbABpAGMAIAB2AG8AaQBkACAAQwB0AHIAbABDAEgAYQBuAGQAbABlAHIAKABvAGIAagBlAGMAdAAgAHMAZQBuAGQAZQByACwAIABDAG8AbgBzAG8AbABlAEMAYQBuAGMAZQBsAEUAdgBlAG4AdABBAHIAZwBzACAAYQByAGcAcwApAA0ACgAgACAAIAAgACAAIAAgACAAewANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAYwB0AHIAbABDAFAAcgBlAHMAcwBlAGQAPQB0AHIAdQBlADsADQAKACAAIAAgACAAIAAgACAAIAAgACAAIAAgAGEAcgBnAHMALgBDAGEAbgBjAGUAbAA9AHQAcgB1AGUAOwANAAoAIAAgACAAIAAgACAAIAAgACAAIAAgACAAbgBlAHcARQB2AGUAbgB0AFIAZQBnAGkAcwB0AGUAcgBlAGQALgBTAGUAdAAoACkAOwANAAoAIAAgACAAIAAgACAAIAAgAH0ADQAKACAAIAAgACAAfQANAAoAfQANAAoA')))

# Adding C# code to PowerShell script and creating new object of this type.
Add-Type -TypeDefinition $EventSubscriptionCode -Language CSharp
$eventSubscriber = New-Object PSDHCPAutoSyncEventSubscription.EventSubscription

# Extracts current bookmark from registry. If it is not available than 
# assumes servers are already in sync and starts sync process from current time.
try
{
    $output=ni -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -ea stop
}
catch
{
    # Removing these warnings since they are irrelevant when integrated with schtask
    #log "WARNING: Encountered error while creating new Registry key." "Yellow"
    #log "         Possibly the tool was not closed properly during last execution." "Yellow"
	#log "         ERROR Value: $($Error[0])" "Yellow"
    
    # Cleaning all values in key except bookmark.
    try
    {
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBsAGUAYQBuAGkAbgBnACAAYQBsAGwAIABwAHIAZQB2AGkAbwB1AHMAIAB2AGEAbAB1AGUAcwAgAGkAbgAgAGsAZQB5ACAAZQB4AGMAZQBwAHQAIABiAG8AbwBrAG0AYQByAGsALgA=')))
        $baseKey=gi -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -ea stop
        $keyValueNames=$baseKey.GetValueNames()
        foreach($keyValueName in $keyValueNames)
        {
            if($keyValueName -ne $bkmrkName)
            {
                rp -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $keyValueName -ea stop 
            }
        }
    }
    catch
    {
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBBAFIATgBJAE4ARwA6ACAAVQBuAGEAYgBsAGUAIAB0AG8AIABjAGwAZQBhAG4AIAByAGUAZwBpAHMAdAByAHkALgA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('WQBlAGwAbABvAHcA')))
    }
}
if($masterMode)
{
    try
    {
        $output=New-ItemProperty -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBhAHMAdABlAHIATQBvAGQAZQA='))) -PropertyType String -Value $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VAByAHUAZQA='))) -ea stop
    }
    catch
    {
        # Removing these warnings since they are irrelevant when integrated with schtask
		#log "WARNING: Encountered error while creating new Registry value string MasterMode." "Yellow"
		#log "         ERROR Value: $($Error[0])" "Yellow"
    }
}
else
{
    foreach($relationName in $script:allRelations)
    {
        try
        {
            $output=New-ItemProperty -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $relationName -PropertyType String -Value "" -ea stop
        }
        catch
        {
            # Removing these warnings since they are irrelevant when integrated with schtask
			#log "WARNING: Encountered error while creating new Registry value string $relationName." "Yellow"
			#log "         ERROR Value: $($Error[0])" "Yellow"
        }
    }
}
try
{
    $output=New-ItemProperty -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAGsAbQByAGsATgBhAG0AZQA='))) -PropertyType String -Value "" -ea stop
}
catch
{
    # Removing these warnings since they are irrelevant when integrated with schtask
	#log "WARNING: Encountered error while creating new Registry value string for bookmark." "Yellow"
	#log "         ERROR Value: $($Error[0])" "Yellow"
}

try
{
    [PSCustomObject]$bkmrk=gp  -Path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAGsAbQByAGsATgBhAG0AZQA='))) -ea stop
    $bkmrk=$bkmrk.$bkmrkName
    if(($bkmrk -eq "") -or ($bkmrk -eq $null))
    {
        try
        {
            $bkmrk=Get-WinEvent -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALQBXAGkAbgBkAG8AdwBzAC0ARABoAGMAcAAtAFMAZQByAHYAZQByAC8ATwBwAGUAcgBhAHQAaQBvAG4AYQBsAA=='))) -MaxEvents 1
            $bkmrk=$bkmrk.RecordId
        }
        catch # No events in event log.
        {
            [int64]$bkmrk=-1
        }
    }
    else
    {    
        $bkmrk=[int64]$bkmrk
    }
}
catch #Registry corrupted
{
    try
    {
        $bkmrk=Get-WinEvent -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALQBXAGkAbgBkAG8AdwBzAC0ARABoAGMAcAAtAFMAZQByAHYAZQByAC8ATwBwAGUAcgBhAHQAaQBvAG4AYQBsAA=='))) -MaxEvents 1
        $bkmrk=$bkmrk.RecordId
    }
    catch # No events in event log.
    {
        [int64]$bkmrk=-1
    }
}

# Bool which is set if record id overflows max int64 value.
$recordIdOverflow=$false

# Network errors contain this string.
$networkDownError=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBJAE4AMwAyACAAMQA3AA==')))

# Scopes which do not get synced due to network errors
# are added to this hashtable. They are synced again whenever do while 
# loop starts again.
$pendingScopesTable=@{}

# Is set true if wait returns without timeout i.e. if new event occurs before $sleepTimeInMilliSecs.
$wait=$true

# Main code starts here...

# Suscribing to events.
$eventSubscriber.SubscribeEvents()

# Syncs all modified scopes whenever a scope modification event is 
# registered or timeout time $sleepTimeValueInMin is reached.
do
{
    $scopeNamePrev=$null
    $scopeNameCurr=$null
    $syncedScopesTable=@{}

    # Checking RecordId has not overflown.
    if($bkmrk -eq [System.Int64]::maxvalue)
    {
        $recordIdOverflow=$true
    }
    if($pendingScopesTable.Count -ne 0)
    {
        log ""
        log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AG4AYwBpAG4AZwAgAHMAYwBvAHAAZQBzACAAdwBoAGkAYwBoACAAdwBlAHIAZQAgAG4AbwB0ACAAcwB5AG4AYwBlAGQAIABlAGEAcgBsAGkAZQByACAAZAB1AGUAIAB0AG8AIABuAGUAdAB3AG8AcgBrACAAcAByAG8AYgBsAGUAbQAuAA==')))
        foreach($scopeName in $pendingScopesTable.Keys)
        {
            try
            {
                $output=Invoke-DhcpServerv4FailoverReplication -ScopeId $scopeName -Force -ea stop
                log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlACAAJABvAHUAdABwAHUAdAAgAHMAeQBuAGMAZQBkAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAGUAZQBuAA==')))
                try
                {
                    $syncedScopesTable.Add($scopeName,"")
                }
                catch
                {
                }
            }
            catch
            {
                if($Error[0].FullyQualifiedErrorId -match $networkDownError)
                {
                    log ""
                    log "Error: $($Error[0])" $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBuAGEAYgBsAGUAIAB0AG8AIABzAHkAbgBjACAAcwBjAG8AcABlACAAJABzAGMAbwBwAGUATgBhAG0AZQAgAGIAZQBjAGEAdQBzAGUAIABvAGYAIABzAG8AbQBlACAAbgBlAHQAdwBvAHIAawAgAHAAcgBvAGIAbABlAG0ALgAgAFcAaQBsAGwAIABhAHUAdABvAG0AYQB0AGkAYwBhAGwAbAB5ACAAdAByAHkAIABhAGcAYQBpAG4AIAA=')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBmAHQAZQByACAAJABzAGMAcgBpAHAAdAA6AHMAbABlAGUAcABUAGkAbQBlAFYAYQBsAHUAZQBJAG4ATQBpAG4AIABNAGkAbgB1AHQAZQBzAC4A')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                }
                else
                {
                    log ""
                    log "Error: $($Error[0])" $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBjAG8AcABlACAAJABzAGMAbwBwAGUATgBhAG0AZQBDAHUAcgByACAAbgBvAHQAIABzAHkAbgBjAGUAZAAuAFAAbABlAGEAcwBlACAAcwB5AG4AYwAgAGkAdAAgAG0AYQBuAHUAYQBsAGwAeQAuAA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBmACAAaQB0ACAAZABvAGUAcwAgAG4AbwB0ACAAYgBlAGwAbwBuAGcAIAB0AG8AIABhAG4AeQAgAHIAZQBsAGEAdABpAG8AbgAgAHAAbABlAGEAcwBlACAAYwByAGUAYQB0AGUAIABhACAAZgBhAGkAbABvAHYAZQByACAAcgBlAGwAYQB0AGkAbwBuACAAZgBvAHIAIABpAHQAIAB0AG8AIABlAG4AcwB1AHIAZQAgAHMAYQBmAGUAdAB5AC4A')))
                    log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('LQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAC0ALQAtAA==')))
                    try
                    {
                        $syncedScopesTable.Add($scopeName,"")
                    }
                    catch
                    {
                    }
                }
            }
        }
        foreach($scopeName in $syncedScopesTable.Keys)
        {
            $pendingScopesTable.Remove($scopeName)
        }
    }

    try
    {
        $eventarray=Get-WinEvent -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALQBXAGkAbgBkAG8AdwBzAC0ARABoAGMAcAAtAFMAZQByAHYAZQByAC8ATwBwAGUAcgBhAHQAaQBvAG4AYQBsAA=='))) -FilterXPath $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBbAFMAeQBzAHQAZQBtAFsAKABFAHYAZQBuAHQAUgBlAGMAbwByAGQASQBEACAAPgAgACQAYgBrAG0AcgBrACkAXQBdAA=='))) -Oldest -ea stop
    }
    catch
    {
        $eventarray=$null
    }
    foreach ($event in $eventarray)
    {
        $eventXmlNode = [xml] $event.ToXml()
        $eventScopeNameNode = $eventXmlNode.Event.EventData.Data | where { ($_.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQAF8AUwBjAG8AcABlAE4AYQBtAGUA')))) -or ($_.Name -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBQAF8ATgBhAG0AZQA=')))) }
        $eventScopeNameValue=$eventScopeNameNode.'#text'
        if($eventScopeNameValue -ne $null)
        {
            $eventScopeNameValueSplit=$eventScopeNameValue.Split("[").Split("]")
            $eventScopeNameValueSplit = $eventScopeNameValueSplit | where { $_ -ne ""}
            $scopeNameCurr=$eventScopeNameValueSplit[0]
            if(($scopeNamePrev -eq $null) -or ($scopeNamePrev -eq $scopeNameCurr))
            {
                $scopeNamePrev=$scopeNameCurr
            }
            else
            {
                TrySync $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABzAGMAbwBwAGUATgBhAG0AZQBQAHIAZQB2AA=='))) $($event.RecordId - 1 )
                $scopeNamePrev=$scopeNameCurr
            }
        }
    }
    if($scopeNameCurr -ne $null)
    {
        TrySync $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABzAGMAbwBwAGUATgBhAG0AZQBDAHUAcgByAA=='))) $event.RecordId
    }
    if($eventarray -ne $null)
    {
        $bkmrk=$event.RecordId
    }

    if($pendingScopesTable.Count -eq 0)
    {
        sp -path $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABLAEwATQA6AFwAUwBZAFMAVABFAE0AXABDAHUAcgByAGUAbgB0AEMAbwBuAHQAcgBvAGwAUwBlAHQAXABTAGUAcgB2AGkAYwBlAHMAXABEAEgAQwBQAFMAZQByAHYAZQByAFwAUABhAHIAYQBtAGUAdABlAHIAcwBcAEQASABDAFAAQQB1AHQAbwBTAHkAbgBjAA=='))) -Name $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAGsAbQByAGsATgBhAG0AZQA='))) -Value $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABiAGsAbQByAGsA')))
    }
    
    # Reseting signal for new events as all new events will be considered after this.
    $reset=$eventSubscriber.newEventRegistered.Reset()

    # Checks if log contains entry after bookmark than start sync process again without logging.
    # It is possible if new events are logged while earlier events were getting processed.
    try
    {
        $eventarray=Get-WinEvent -LogName $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBpAGMAcgBvAHMAbwBmAHQALQBXAGkAbgBkAG8AdwBzAC0ARABoAGMAcAAtAFMAZQByAHYAZQByAC8ATwBwAGUAcgBhAHQAaQBvAG4AYQBsAA=='))) -FilterXPath $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KgBbAFMAeQBzAHQAZQBtAFsAKABFAHYAZQBuAHQAUgBlAGMAbwByAGQASQBEACAAPgAgACQAYgBrAG0AcgBrACkAXQBdAA=='))) -Oldest -ea stop
    }
    catch
    {
        if(($eventarray -ne $null) -or 
		   ($pendingScopesTable.Count -ne 0) -or 
		   ($syncedScopesTable.Count -ne 0) -or ($wait)) # Check if anything happend in this loop.
        {
            if($pendingScopesTable.Count -eq 0)
            {
                log "Sync process complete at $(Get-Date)."
                log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAGwAbAAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjACAAYQBnAGEAaQBuACAAdwBoAGUAbgAgAG4AZQB3ACAAYwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgAgAGMAaABhAG4AZwBlAHMAIABhAHIAZQAgAG0AYQBkAGUALgA=')))
                log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AA=='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RwByAGUAZQBuAA==')))
            }
            else
            {
                log "Sync process complete at $(Get-Date)."
                log $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBpAGwAbAAgAGEAdQB0AG8AbQBhAHQAaQBjAGEAbABsAHkAIABzAHkAbgBjACAAYQBnAGEAaQBuACAAdwBoAGUAbgAgAG4AZQB3ACAAYwBvAG4AZgBpAGcAdQByAGEAdABpAG8AbgAgAGMAaABhAG4AZwBlAHMAIABhAHIAZQAgAG0AYQBkAGUAIABvAHIAIABhAGYAdABlAHIAIAAkAHMAYwByAGkAcAB0ADoAcwBsAGUAZQBwAFQAaQBtAGUAVgBhAGwAdQBlAEkAbgBNAGkAbgAgAE0AaQBuAHUAdABlAHMALgA=')))
                log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('PQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AD0APQA9AA==')))
            }
        }
        if($eventSubscriber.ctrlCPressed -eq $true)
        {
            CloseTool
        }
        $wait=$eventSubscriber.newEventRegistered.WaitOne($sleepTimeInMilliSecs, $true)
        if($eventSubscriber.ctrlCPressed -eq $true)
        {
            CloseTool
        }
    }
}
while(-not $recordIdOverflow)

# Record id has overflown. Stopping tool with warning.

log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGMAbwByAGQAIABJAGQAIABpAG4AIAB0AGgAZQAgAGUAdgBlAG4AdABzACAAbABvAGcAIABoAGEAcwAgAG8AdgBlAHIAZgBsAG8AdwBuAC4A'))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
log $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABsAGUAYQBzAGUAIABjAGwAZQBhAHIAIABsAG8AZwAgAE0AaQBjAHIAbwBzAG8AZgB0AC0AVwBpAG4AZABvAHcAcwAtAEQAaABjAHAALQBTAGUAcgB2AGUAcgAvAE8AcABlAHIAYQB0AGkAbwBuAGEAbAAgAGEAbgBkACAAcgBlAHMAdABhAHIAdAAgAHQAbwBvAGwALgA='))) $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAGQA')))
CloseTool
