﻿<#
.SYNOPSIS
Checks if home folder still has an enabled AD account and list size of the folder

.DESCRIPTION
This script queries AD with the name of the home folder. If this query does not result in an account or a disabled account the script will list the folder size with the folder path and error message. The script will output an array of PSObject which can be piped into various Format-* and Export-* Cmdlets.

.PARAMETER HomeFolderPath
This parameter determines which folder should be scanned. A list of all folders will be checked for matching samaccountnames in Active Directory. Any folders that do not have a name that matches a samaccount in AD or that match a disabled account are listed.

.PARAMETER FolderSize
This parameter determines if the folder size should be retrieved for orphaned home folders. Not specifying this parameter will significantly increase speed of execution.

.PARAMETER MoveFolderPath
Specifying this parameter will move all orphaned folders to the specified folder.

.PARAMETER MoveDisabled
This switch parameter works in combination with the MoveFolderPath parameter, it will also move the homefolders of disabled accounts.

.NOTES   
Name: Get-OrphanHomeFolder.ps1
Author: Jaap Brasser
Version: 1.4
DateCreated: 2012-10-19
DateUpdated: 2013-03-08

.LINK
http://www.jaapbrasser.com
    
.EXAMPLE   
.\Get-OrphanHomeFolder.ps1 -HomeFolderPath \\Server01\Home -FolderSize

Description:
Will list all the folders in the \\Server01\Home path. For each of these folders it will query AD using the foldername, if the query does not return an AD account or a disabled AD account an error will be logged and the size of the folder will be reported

.EXAMPLE   
.\Get-OrphanHomeFolder.ps1 -HomeFolderPath \\Server02\Fileshare\Home | Format-Table -AutoSize

Description:
Will list all the folders in the \\Server02\Fileshare\Home. Will wait until all folders are processed before piping the input into the Format-Table Cmdlet and displaying the results in the console.

.EXAMPLE   
.\Get-OrphanHomeFolder.ps1 -HomeFolderPath \\Server02\Fileshare\Home -MoveFolderPath \\Server03\Fileshare\MovedHomeFolders

Description:
Will list all the folders in the \\Server02\Fileshare\Home folder and will move orphaned folders to \\Server03\Fileshare\MovedHomeFolders while displaying results to console.
#>
param(
    [Parameter(Mandatory=$true)]
    $HomeFolderPath,
    $MoveFolderPath,
    [switch]$FolderSize,
    [switch]$MoveDisabled
)
# Check if HomeFolderPath is found, exit with warning message if path is incorrect
if (!(Test-Path -Path $HomeFolderPath)){
    Write-Warning $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SABvAG0AZQBGAG8AbABkAGUAcgBQAGEAdABoACAAbgBvAHQAIABmAG8AdQBuAGQAOgAgACQASABvAG0AZQBGAG8AbABkAGUAcgBQAGEAdABoAA==')))
    exit
}

# Check if MoveFolderPath is found, exit with warning message if path is incorrect
if ($MoveFolderPath) {
    if (!(Test-Path -Path $MoveFolderPath)){
        Write-Warning $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBvAHYAZQBGAG8AbABkAGUAcgBQAGEAdABoACAAbgBvAHQAIABmAG8AdQBuAGQAOgAgACQATQBvAHYAZQBGAG8AbABkAGUAcgBQAGEAdABoAA==')))
        exit
    }
}

# Main loop, for each folder found under home folder path AD is queried to find a matching samaccountname
Get-ChildItem -Path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEYAbwBsAGQAZQByAFAAYQB0AGgA'))) | Where-Object {$_.PSIsContainer} | ForEach-Object {
    ${01001100011000010} = Split-Path $_ -Leaf
    ${01110001100011010} = ([adsisearcher]$ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('KABzAGEAbQBhAGMAYwBvAHUAbgB0AG4AYQBtAGUAPQAkAHsAMAAxADAAMAAxADEAMAAwADAAMQAxADAAMAAwADAAMQAwAH0AKQA=')))).Findone()
    
    # If no matching samaccountname is found this code is executed and displayed
    if (!(${01110001100011010})) {
        ${00100010100111011} = @{
            'Error' = 'Account does not exist and has a home folder'
            'FullPath' = $_.FullName
        }
        if ($FolderSize) {
            ${00100010100111011}.SizeinBytes = [long](Get-ChildItem $_.Fullname -Recurse -Force -ErrorAction SilentlyContinue |
                Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue | Select-Object -Exp Sum)
            ${00100010100111011}.SizeinMegaBytes = "{0:n2}" -f (${00100010100111011}.SizeinBytes/1MB)
        }
        
        if ($MoveFolderPath) {
            ${00100010100111011}.DestinationFullPath = Join-Path -Path $MoveFolderPath -ChildPath (Split-Path $_.FullName -Leaf)
            Move-Item -Path ${00100010100111011}.FullPath -Destination ${00100010100111011}.DestinationFullPath -Force
        }

        # Output the object
        New-Object -TypeName PSCustomObject -Property ${00100010100111011}
    
    # If samaccountname is found but the account is disabled this information is displayed
    } elseif (([boolean](${01110001100011010}.Properties.useraccountcontrol[0] -band 2))) {
        ${00100010100111011} = @{
            'Error' = 'Account is disabled and has a home folder'
            'FullPath' = $_.FullName
        }
        if ($FolderSize) {
            ${00100010100111011}.SizeinBytes = [long](Get-ChildItem $_.Fullname -Recurse -Force -ErrorAction SilentlyContinue |
                Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue | Select-Object -Exp Sum)
            ${00100010100111011}.SizeinMegaBytes = "{0:n2}" -f (${00100010100111011}.SizeinBytes/1MB)
        }

        if ($MoveFolderPath -and $MoveDisabled) {
            ${00100010100111011}.DestinationFullPath = Join-Path -Path $MoveFolderPath -ChildPath (Split-Path $_.FullName -Leaf)
            Move-Item -Path ${00100010100111011}.FullPath -Destination ${00100010100111011}.DestinationFullPath -Force
        }

        # Output the object
        New-Object -TypeName PSCustomObject -Property ${00100010100111011}

    # Reserved for future use, folders that do have active user accounts
    } else {
    }
}