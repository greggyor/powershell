﻿param  
(  
[string] $URL,  
[boolean] $writeToFile = $true  
)  
Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue 
${2} = 0  
${1} = 0 
if($writeToFile -eq $true)  
{  
${5} = Read-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwB1AHQAcAB1AHQAcABhAHQAaAAgACgAZQAuAGcALgAgAEMAOgBcAGQAaQByAGUAYwB0AG8AcgB5AFwAZgBpAGwAZQBuAGEAbQBlAC4AdAB4AHQAKQA=')))  
}  
if(!$URL)  
{  
Get-SPSite -Limit All | % {${7} += $_.Allwebs}  
}  
else  
{  
${7} = Get-SPWeb $URL  
}  
if(${7}.count -ge 1 -OR ${7}.count -eq $null)  
{  
    foreach(${3} in ${7})  
    {  
    ${6} = ${3}.Lists     
    Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBlAGIAcwBpAHQAZQA=')))${3}.url -ForegroundColor Green   
    if($writeToFile -eq $true){ac -Path ${5} -Value "Website $(${3}.url)"}  
        foreach(${4} in ${6})  
        {  
            ${1} +=1    
            Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('IAATICAA')))${4}.Title            
            if($WriteToFile -eq $true){ac -Path ${5} -Value " – $(${4}.Title)"}  
        }  
    ${2} +=1  
    ${3}.Dispose()  
    }  
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBtAG8AdQBuAHQAIABvAGYAIAB3AGUAYgBzACAAYwBoAGUAYwBrAGUAZAA6AA==')))${2}  
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QQBtAG8AdQBuAHQAIABvAGYAIABsAGkAcwB0AHMAOgA=')))${1}  
}  
else  
{  
Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvACAAdwBlAGIAcwAgAHIAZQB0AHIAaQBlAHYAZQBkACwAIABwAGwAZQBhAHMAZQAgAGMAaABlAGMAawAgAHkAbwB1AHIAIABwAGUAcgBtAGkAcwBzAGkAbwBuAHMA'))) -ForegroundColor Red -BackgroundColor Black  
}