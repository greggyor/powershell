﻿






$HomeDrive = "H:\DesktopFiles" 



$WarningText = "The files you ahve stored on you desktop have been removed, please don't put files there later on, they'll just be removed anyway and you'll be scolded" 


$ScoldingText = "You naughty naughty user, you've already been told that nothing should be saved on the desktop, The files you recently put on the desktop have been moved, bad user"



$Desktop = [environment]::getfolderpath("desktop") 
$AppData = [environment]::getfolderpath("ApplicationData") 

$AppData = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAFwAQQBuAGcAcgB5AEQAZQBzAGsAdABvAHAA'))) 

$DesktopChildren = Get-childItem $Desktop 


$ScoldingNeeded = $False
$WarningNeeded = $False


If (-not (test-path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQA=')))))
{
    new-item -type directory $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQA=')))
}

If (-not (test-path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAA==')))))
{
    new-item -type directory $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAA==')))
    set-content $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAFwAYwBoAGEAbgBjAGUAcwAuAHQAeAB0AA=='))) "1"
}






Function NewShortCut ($Path, $Name, $Desktop)
{
    $wshshell = new-object -comobject wscript.shell
    $shortCut = $wshShell.CreateShortCut($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABEAGUAcwBrAHQAbwBwAFwAJABOAGEAbQBlAC4AbABuAGsA'))))
    $shortCut.TargetPath = $Path
    $shortCut.Description = $Path
    [void]$shortCut.Save()
}




$code = @' 
private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);  
private const int WM_SETTINGCHANGE = 0x1a;  
private const int SMTO_ABORTIFHUNG = 0x0002;  
 
 
[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)] 
static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, UIntPtr wParam, 
   IntPtr lParam); 
 
[System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]  
  private static extern IntPtr SendMessageTimeout ( IntPtr hWnd, int Msg, IntPtr wParam, string lParam, uint fuFlags, uint uTimeout, IntPtr lpdwResult );  
 
 
[System.Runtime.InteropServices.DllImport("Shell32.dll")]  
private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2); 
 
 
public static void Refresh()  { 
    SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero); 
    SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);  
} 
'@ 
[void](Add-Type -MemberDefinition $code -Namespace MyWinAPI -Name Explorer) 




function Messagebox ($title, $text, $type = "None", $buttons = [Windows.Forms.MessageBoxButtons]::YesNo) 
{
    [void][reflection.assembly]::LoadWithPartialName("System.Windows.Forms")
    $msg = [Windows.Forms.MessageBox]::Show($text, $title, $buttons,[Windows.Forms.MessageBoxIcon]::$type)
    return $msg
}

Function MoveFile ($Fullname, $Name, $HomeDrive, $Desktop, $IsChild = $False, $YesToAll = "No")
{
    $Continue = $True
    
    
    $Extensor = ($FullName.replace($Desktop, "")).replace($Name, "")
    
    
    $Collision = test-path $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQAkAEUAeAB0AGUAbgBzAG8AcgAkAE4AYQBtAGUA')))
    

    If ($Collision)
    {
        If (-not ($YesToAll -eq "Yes")) 
        { 
            If (-not ($YesToAll -eq "Cancel")) 
            {
                $Title = "Possbile collision detected"
                $Text = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABoAGUAcgBlACAAbQBhAHkAIABiAGUAIABhACAAcAByAG8AYgBsAGUAbQAsACAAJABOAGEAbQBlACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAaQB0AHMAIABpAG4AIAAkAEgAbwBtAGUARAByAGkAdgBlACQARQB4AHQAZQBuAHMAbwByACAAdwBvAHUAbABkACAAeQBvAHUAIABsAGkAawBlACAAdABvACAAYwBvAHAAeQAgAG8AdgBlAHIAIAB0AGgAZQAgAHQAbwBwACAAbwBmACAAaQB0AD8A')))
                $Descision = Messagebox $Title $Text "Error"
                If ($Descision -eq "no") 
                {
                    $Continue = $False
                }
                If ($IsChild) 
                {
                    $Title = "Possbile collision detected"
                    $Text = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VwBvAHUAbABkACAAeQBvAHUAIABsAGkAawBlACAAdABvACAAcgBlAHAAbABhAGMAZQAgAGEAbABsACAAZgBpAGwAZQBzACAAaQBuACAAJABIAG8AbQBlAEQAcgBpAHYAZQAkAEUAeAB0AGUAbgBzAG8AcgAgAHcAaQB0AGgAIAB0AGgAZQBpAHIAIABjAG8AdQBuAHQAZQByAHAAYQByAHQAcwAgAG8AbgAgAHQAaABlACAAZABlAHMAawB0AG8AcAA/ACAAKABDAGwAaQBjAGsAIABDAGEAbgBjAGUAbAAgAGkAZgAgAHkAbwB1ACAAZABvAG4AJwB0ACAAdwBhAG4AdAAgAHQAbwAgAGMAbwBwAHkAIABhAG4AZAAgAGQAdQBwAGwAaQBjAGEAdABlACAAZgBpAGwAZQBzACAAYQB0ACAAYQBsAGwAIAAoAFcAQQBSAE4ASQBOAEcAIABmAGkAbABlAHMAIAB0AGgAYQB0ACAAYQByAGUAIABuAG8AdAAgAGMAbwBwAGkAZQBkACAAdwBpAGwAbAAgAHMAdABpAGwAbAAgAGIAZQAgAGQAZQBsAGUAdABlAGQAKQApAA=='))) 
                    $Descision = Messagebox $Title $Text "Error" ([Windows.Forms.MessageBoxButtons]::YesNoCancel)
                    $YesToAll = $Descision
                }
            }
            else
            {
                $Continue = $False 
            }       
        }
    }
    
    If ($Continue) 
    {
        write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHAAeQBpAG4AZwAgAHQAbwAgACQASABvAG0AZQBEAHIAaQB2AGUAJABFAHgAdABlAG4AcwBvAHIAJABOAGEAbQBlAA=='))) 
        [void](xcopy $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABGAHUAbABsAG4AYQBtAGUA'))) $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQAkAGUAeAB0AGUAbgBzAG8AcgA='))) /Y) 
        [void](rd $FullName -Force -Recurse) 
        if (-not ($Collision -or $IsChild)) 
        {
            [void](NewShortCut $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQBcACQATgBhAG0AZQA='))) $Name $Desktop) 
        }
    }
    Else
    {
        write-host $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBrAGkAcABwAGkAbgBnACAAJABGAHUAbABsAG4AYQBtAGUA'))) 
    }
    Return $YesToAll 
}



While ($True) 
{
    Foreach ($Child in $DesktopChildren)
    {
        $Mode = $Child.Mode.ToCharArray() 
        $FullName = $Child.Fullname
        $Name = $Child.Name
        
        
        If ($Mode[0] -eq "d")
        {
            $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBvAHAAeQBpAG4AZwAgACQARgB1AGwAbABOAGEAbQBlAA==')))
            $FolderChildren = ls $FullName
            $YesToAll = "No"
            Foreach ($FolderChild in $FolderChildren)
            {
                $YesToAll = MoveFile $FolderChild.Fullname $FolderChild.Name $HomeDrive $Desktop $True $YesToAll
            }
            
            [void]([MyWinAPI.Explorer]::Refresh()) 

            rd $FullName -Force -Recurse 
            
            NewShortCut $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABIAG8AbQBlAEQAcgBpAHYAZQBcACQATgBhAG0AZQBcAA=='))) $Name $Desktop 
            
            [MyWinAPI.Explorer]::Refresh() 
            
            $ScoldingNeeded = $True 
        }
        else 
        {
            $Extension = $Child.Extension 
            if (-not($Extension -eq ".lnk")) 
            {
                [void](MoveFile $FullName $Name $HomeDrive $Desktop)
                
                [void]([MyWinAPI.Explorer]::Refresh()) 
                
                $ScoldingNeeded = $True 
            }
        }
    }




    $Chances = get-content $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAFwAYwBoAGEAbgBjAGUAcwAuAHQAeAB0AA==')))

    

    If ($Chances -eq "1")
    {
        $ScoldingNeeded = $False
        $WarningNeeded = $True
        set-content $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JABBAHAAcABEAGEAdABhAFwAYwBoAGEAbgBjAGUAcwAuAHQAeAB0AA=='))) "0"
    }

    If ($ScoldingNeeded)
    {
        $Title = "You've Been Naughty"

        $Type = "Error"
        $Buttons = [Windows.Forms.MessageBoxButtons]::Ok
        [void](MessageBox $Title $ScoldingText $Type $Buttons)
    }
    elseIf ($WarningNeeded)
    {
        $Title = "Warning"
        $Type = "Error"
        $Buttons = [Windows.Forms.MessageBoxButtons]::Ok
        [void](MessageBox $Title $WarningText $Type $Buttons)
    }
    sleep (10*60) 
}