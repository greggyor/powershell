﻿



Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
$SRVSettings = Get-ADServerSettings
if ($SRVSettings.ViewEntireForest -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RgBhAGwAcwBlAA=='))))
	{
		Set-ADServerSettings -ViewEntireForest $true
	}
$MsxServers = Get-ExchangeServer | where {$_.ServerRole -ne $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RQBkAGcAZQA='))) -AND $_.AdminDisplayVersion.major -eq "8"} | sort Name
$ClassHeaderRollup = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('aABlAGEAZABpAG4AZwAxAA==')))


if ($MsxServers -ne $NULL)
{
ForEach ($MsxServer in $MsxServers)
{
   
   	
	$MsxVersion = $MsxServer.ExchangeVersion

	
	$Srv = $MsxServer.Name
 
    $DetailRollup+=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkACQAJADwAdAByAD4A')))
    $DetailRollup+=  "					<th width='10%'><b>SERVER NAME : </b><font color='#0000FF'>$($Srv)</font></td>"

 
    
	$key = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBPAEYAVABXAEEAUgBFAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFwAQwB1AHIAcgBlAG4AdABWAGUAcgBzAGkAbwBuAFwASQBuAHMAdABhAGwAbABlAHIAXABVAHMAZQByAEQAYQB0AGEAXABTAC0AMQAtADUALQAxADgAXABQAHIAbwBkAHUAYwB0AHMAXAA0ADYAMQBDADIAQgA0ADIANgA2AEUARABFAEYANAA0ADQAQgA4ADYANABBAEQANgBEADkARQA1AEIANgAxADMAXABQAGEAdABjAGgAZQBzAFwA')))
	$type = [Microsoft.Win32.RegistryHive]::LocalMachine
	$regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($type, $Srv)
	$regKey = $regKey.OpenSubKey($key)

     if ($regKey.SubKeyCount -eq 0)
    {
               $DetailRollup+=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkACQAJAAkAPAB0AHIAPgA8AHQAZAAgAHcAaQBkAHQAaAA9ACcAMQAwACUAJwA+ADwAZgBvAG4AdAAgAGMAbwBsAG8AcgA9ACcAIwBGAEYAMAAwADAAMAAnAD4APABiAD4ATgBPACAAUgBPAEwATABVAFAAIABJAE4AUwBUAEEATABMAEUARAA8AC8AYgA+ADwALwBmAG8AbgB0AD4APAAvAHQAZAA+ADwAdAByAD4A')))
    }
    else
    {
	
	$ErrorActionPreference = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQA=')))

	ForEach($sub in $regKey.GetSubKeyNames())
	{
		$SUBkey = $key + $Sub
		$SUBregKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($type, $Srv)
		$SUBregKey = $SUBregKey.OpenSubKey($SUBkey)

		ForEach($SubX in $SUBRegkey.GetValueNames())
		{
			
			IF ($Subx -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBuAHMAdABhAGwAbABlAGQA'))))   {
				$d = $SUBRegkey.GetValue($SubX)
				$d = $d.substring(4,2) + "/" + $d.substring(6,2) + "/" + $d.substring(0,4)
			}
			IF ($Subx -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABpAHMAcABsAGEAeQBOAGEAbQBlAA==')))) {
            $cd = $SUBRegkey.GetValue($SubX)
            $DetailRollup+=  "						<tr><td width='10%'><b>Rollup Version : <font color='#0000FF'>$($d) - $($cd)</b></font></td><tr>"
            }
		}
	}
           $DetailRollup+=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkACQAJADwAdAByAD4A')))
}
    $DetailRollup+=  $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('CQAJAAkACQAJADwALwB0AHIAPgA=')))
}
	
$Report += @"
	</TABLE>
	    <div>
        <div>
    <div class='container'>
        <div class='$($ClassHeaderRollup)'>
            <SPAN class=sectionTitle tabIndex=0>Exchange Servers Rollup (E2K7 Only)</SPAN>
            <a class='expando' href='#'></a>
        </div>
        <div class='container'>
            <div class='tableDetail'>
                <table>
	  				<tr>
                         
	  				</tr>
                    $($DetailRollup)
                </table>
            </div>
        </div>
        <div class='filler'></div>
    </div>	
"@
}
else
{
$Report += @"
	</TABLE>
	    <div>
        <div>
    <div class='container'>
        <div class='$($ClassHeaderRollup)'>
            <SPAN class=sectionTitle tabIndex=0>Exchange Servers Rollup (E2K7 Only)</SPAN>
            <a class='expando' href='#'></a>
        </div>
        <div class='container'>
            <div class='tableDetail'>
                <table>
	  				<tr>
                         
	  				</tr>
                    No Exchange 2007 Servers Found in this Organization
                </table>
            </div>
        </div>
        <div class='filler'></div>
    </div>	
"@
}
Return $Report