﻿ 
ipmo ActiveDirectory
function Set-OSCADAccountPassword
{
	[CmdletBinding(SupportsShouldProcess=$true,
					ConfirmImpact="High",
					DefaultParameterSetName="OU")]
	param
	(
		[Parameter(Mandatory=$true,Position=0,ParameterSetName="Path")]
		[String]$Path,
		[Parameter(Mandatory=$True,Position=0,ParameterSetName="OU")]
		[String[]]$OrganizationalUnit,
		[Parameter(Mandatory=$false,Position=1,ParameterSetName="OU")]
		[String]$Password,
		[Parameter(Mandatory=$false,Position=2,ParameterSetName="OU")]
		[switch]$Recurse,
		[Parameter(Mandatory=$false,Position=3)]
		[String]$CSVPath="C:\Result$(Get-Date -Format $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TQBNAGQAZAB5AHkAeQB5AA==')))).csv"
	)
	process
	{
		Add-Type -Assembly System.Web
		$result=@()	
		$OUList=@() 
		$UserList=@()
		if ($Pscmdlet.ParameterSetName -eq $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UABhAHQAaAA='))))
		{
			if (Test-Path $Path)
			{
				$UserList=ipcsv $path
				$ProgressTitle="Reset password for users specified in $path"
			}
			else
			{
				$errorMsg="Could not find '$path'. Please make sure the path is correct."
				Write-Error -Message $errorMsg
				return
			}
		}
		else
		{
			foreach ($OU in $OrganizationalUnit)
			{
				$OUList+=Get-ADOrganizationalUnit -Filter 'name -like $OU'
			}
			$OUList|select Name,DistinguishedName
			if ($Recurse)
			{
				$SearchScope=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB1AGIAdAByAGUAZQA=')))
				Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBzACcAIABwAGEAcwBzAHcAbwByAGQAcwAsACAAaQBuACAAdABoAGUAcwBlACAATwBVAHMAIABhAG4AZAAgAHQAaABlAGkAcgAgAHMAdQBiAC0AbwB1AHMALAAgAHcAaQBsAGwAIABiAGUAIAByAGUAcwBlAHQALgA=')))
				$DNList+=$OUList|% {$_.distinguishedname}
				foreach ($TempOU in $OUList)
				{
					foreach ($DN in $DNList)
					{
						if ($TempOU.DistinguishedName -like "*?$DN")
						{
							$OUList= $OUList -notmatch $TempOU
							$verboseMsg = "Duplicate OU:$TempOU is a child OU of $DN."
							Write-Verbose -Message $verboseMsg
							break
						}
					}
				}
			}
			else
			{
				$SearchScope=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TwBuAGUAbABlAHYAZQBsAA==')))
				Write-Host $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VQBzAGUAcgBzACcAIABwAGEAcwBzAHcAbwByAGQAcwAsACAAaQBuACAAdABoAGUAcwBlACAATwBVAHMAIABhAGIAbwB2AGUALAAgAHcAaQBsAGwAIABiAGUAIAByAGUAcwBlAHQALgA=')))
			}
			foreach ($TempOU in $OUList)
			{
				$UserList+=Get-Aduser -Filter 'enabled -eq $true' -ResultSetSize $null -SearchBase $TempOU -SearchScope $SearchScope -Properties samaccountname
			}
			$ProgressTitle=$([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UgBlAHMAZQB0ACAAcABhAHMAcwB3AG8AcgBkACAAZgBvAHIAIAB1AHMAZQByAHMAIABpAG4AIABnAGkAdgBlAG4AIABPAFUAcwA=')))
		}
		if($PSCmdlet.ShouldProcess($([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('dABoAGUAcwBlACAAdQBzAGUAcgBzAA==')))))
		{
			foreach ($user in $UserList)
			{
				$Identity=$user.SamAccountName
				if ([System.String]::IsNullOrEmpty($Password))
				{
					if ([System.String]::IsNullOrEmpty($user.Password))
					{
						$NewPassword=[Web.Security.Membership]::GeneratePassword(10,3)
					}
					else
					{	
						$NewPassword=$user.Password
					}
				}
				else
				{
					$NewPassword=$Password
				}
				$Counter++
				Write-Progress -Activity $ProgressTitle -Status $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UAByAG8AYwBlAHMAcwBpAG4AZwA='))) -CurrentOperation $Identity -PercentComplete ($counter / ($Userlist.Count) * 100)
				Set-AdaccountPassword -Identity $Identity -Reset -NewPassword (ConvertTo-SecureString -AsPlainText $NewPassword -Force)
				$Account = New-Object PSObject
				$Account | Add-Member -MemberType NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('SQBkAGUAbgB0AGkAdAB5AA=='))) -Value $Identity
				$Account | Add-Member -MemberType NoteProperty -Name $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBlAHcAUABhAHMAcwB3AG8AcgBkAA=='))) -Value $NewPassword
				$result+=$Account
			}
			$result|epcsv -Path $CSVPath -NoTypeInformation -Force
		}
	} 
}