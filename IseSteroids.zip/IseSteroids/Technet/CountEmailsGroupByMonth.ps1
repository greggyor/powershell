﻿#$MailboxName = "nuno.mota@letsexchange.com" 
${2} = @{} 
${1} = @{} 
 
${24} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwA6AFwAUAByAG8AZwByAGEAbQAgAEYAaQBsAGUAcwBcAE0AaQBjAHIAbwBzAG8AZgB0AFwARQB4AGMAaABhAG4AZwBlAFwAVwBlAGIAIABTAGUAcgB2AGkAYwBlAHMAXAAxAC4AMABcAE0AaQBjAHIAbwBzAG8AZgB0AC4ARQB4AGMAaABhAG4AZwBlAC4AVwBlAGIAUwBlAHIAdgBpAGMAZQBzAC4AZABsAGwA'))) 
[void][Reflection.Assembly]::LoadFile(${24}) 
${11} = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2007_SP1) 
 
${23} = [System.Security.Principal.WindowsIdentity]::GetCurrent() 
${22} = $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TABEAEEAUAA6AC8ALwA8AFMASQBEAD0A'))) + ${23}.user.Value.ToString() + ">" 
${21} = [ADSI] ${22} 
 
${11}.AutodiscoverUrl(${21}.mail.ToString()) 
 
${20} = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::IsRead, $True) 
${19} = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::IsRead, $False) 
${8} = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+SearchFilterCollection([Microsoft.Exchange.WebServices.Data.LogicalOperator]::Or); 
${8}.add(${20}) 
${8}.add(${19}) 
 
 
[Int] ${18} = (Get-Mailbox -ResultSize Unlimited -Filter {CustomAttribute1 -eq "STAFF"}).Count 
#[Int] $intCount = (Get-Content C:\users1GB.csv | Get-Mailbox).Count 
[Int] ${3} = 0 
 
# We can check only mailboxes in a CSV for example 
#Get-Content C:\users1GB.csv | Get-Mailbox | ForEach { 
Get-Mailbox -ResultSize Unlimited -Filter {CustomAttribute1 -eq "STAFF"} | Select PrimarySmtpAddress | ForEach { 
    # Create a progress bar so we know how we are doing 
    Write-Progress -Activity "Checking ${18} Mailboxes" -Status "Mailboxes Successfully Processed: ${3}" 
     
    ${17} = ($_.PrimarySmtpAddress).ToString() 
 
    ${16} = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::MsgFolderRoot,${17}) 
    ${15} = [Microsoft.Exchange.WebServices.Data.Folder]::Bind(${11},${16}) 
    ${14} = New-Object Microsoft.Exchange.WebServices.Data.FolderView(100000); 
    ${14}.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Deep 
    ${14}.PropertySet = $Propset 
    ${13} = ${15}.FindFolders(${14}); 
 
    ForEach (${12} in ${13}.Folders) 
    { 
        #Write-Host $folder.Displayname  -ForegroundColor Green 
        If (${12}.DisplayName -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('QwBhAGwAZQBuAGQAYQByAA=='))) -and ${12}.DisplayName -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('TgBvAHQAZQBzAA=='))) -and ${12}.DisplayName -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('VABhAHMAawBzAA=='))) -and ${12}.DisplayName -notmatch $([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('RABlAGwAZQB0AGUAZAAgAEkAdABlAG0AcwA=')))) 
        { 
            ${10} = new-object  Microsoft.Exchange.WebServices.Data.FolderId(${12}.ID) 
            ${9} = [Microsoft.Exchange.WebServices.Data.Folder]::Bind(${11},${10}) 
            ${7} = new-object Microsoft.Exchange.WebServices.Data.ItemView(500000) 
 
            ${6} = ${9}.FindItems(${8},${7}) 
            ForEach (${4} in ${6}.Items) 
            { 
                [String] ${5} = (${4}.DateTimeCreated).ToShortDateString() 
                # To group only by month we remove the day. To group by year remove the month as well 
                ${5} = ${5}.Substring(3) 
                         
                ${2}.Set_Item(${5}, ${2}.Get_Item(${5}) + 1) 
                ${1}.Set_Item(${5}, ${1}.Get_Item(${5}) + [Int] ${4}.Size) 
            } 
        } 
    } 
     
    #$MailboxName >> C:\EmailDates_MbxProc_Big1GB.txt 
    ${3}++ 
} 
 
 
${2}.GetEnumerator() | sort Name | Export-CSV C:\EmailDates_Total.csv -NoTypeInformation 
${1}.GetEnumerator() | sort Name | Export-CSV C:\EmailDates_Total_Size.csv -NoTypeInformation