﻿
${3} = ".\LogonActivity.html"
${1} = New-Object system.Data.DataTable “Logon/Logoff Activity”
${18} = New-Object system.Data.DataColumn "Date",([string])
${17} = New-Object system.Data.DataColumn "Type",([string])
${16} = New-Object system.Data.DataColumn "Status",([string])
${15} = New-Object system.Data.DataColumn "User",([string])
${14} = New-Object system.Data.DataColumn "IPAddress",([string])
${1}.columns.add(${18})
${1}.columns.add(${17})
${1}.columns.add(${16})
${1}.columns.add(${15})
${1}.columns.add(${14})
${11} = read-host "Enter the IP or hostname of the computer you wish to scan (Leave blank for local)" 
if (${11}.length -eq 0){${11} = $env:computername} 
${13} = read-host "Enter the start date to scan from (MM/DD/YYYY, default 1/1/2000)" 
if (${13}.length -eq 0){${13} = "1/1/2000"} 
${10} = get-date ${13} 
${12} = read-host "Enter the end date to scan to (MM/DD/YYYY, default current time)" 
if (${12}.length -eq 0){${12} = get-date} 
${9} = get-date ${12} 
${8} = read-host "Print only failed logins (Y/N, default N)" 
if (${8}.length -eq 0){${8} = "N"} 
${2} = read-host "Output Type ((T)able, (G)ridview, (H)TML, default List)"
write-host "Hostname: "${11} "`tStart: "${10} "`tEnd: "${9} "`tOnly Failed Logins: "${8} "`n"
${7} = Get-Eventlog -LogName Security -ComputerName ${11} -after ${10} -before ${9} 
if (${8} -match "Y"){ 
    foreach (${6} in ${7}){ 
        if ((${6}.EventID -eq 4625 ) -and (${6}.ReplacementStrings[10] -eq 2)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Local"
            ${5}.status =  "Failure"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ""
            ${1}.Rows.Add(${5})
        } 
        if ((${6}.EventID -eq 4625 ) -and (${6}.ReplacementStrings[10] -eq 10)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Remote"
            ${5}.status =  "Failure"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ${6}.ReplacementStrings[19]
            ${1}.Rows.Add(${5})
        } 
    }         
} 
else{ 
    foreach (${6} in ${7}){ 
        if ((${6}.EventID -eq 4624 ) -and (${6}.ReplacementStrings[8] -eq 2)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Local"
            ${5}.status =  "Success"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ""
            ${1}.Rows.Add(${5})
        } 
        if ((${6}.EventID -eq 4624 ) -and (${6}.ReplacementStrings[8] -eq 10)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Remote"
            ${5}.status =  "Success"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ${6}.ReplacementStrings[18]
            ${1}.Rows.Add(${5})
        } 
        if ((${6}.EventID -eq 4625 ) -and (${6}.ReplacementStrings[10] -eq 2)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Local"
            ${5}.status =  "Failure"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ""
            ${1}.Rows.Add(${5})
        } 
        if ((${6}.EventID -eq 4625 ) -and (${6}.ReplacementStrings[10] -eq 10)){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logon - Remote"
            ${5}.status =  "Failure"
            ${5}.user =  ${6}.ReplacementStrings[5]
            ${5}.ipaddress = ${6}.ReplacementStrings[19]
            ${1}.Rows.Add(${5})
        } 
        if (${6}.EventID -eq 4647 ){ 
            ${5} = ${1}.NewRow()
            ${5}.date =  ${6}.TimeGenerated
            ${5}.type =  "Logoff"
            ${5}.status =  "Success"
            ${5}.user =  ${6}.ReplacementStrings[1]
            ${5}.ipaddress = ""
            ${1}.Rows.Add(${5})
        }  
    } 
}
if (${2} -match "T"){ 
    ${1} | ft
}
elseif (${2} -match "H"){ 
    ${4} = "<style>"
    ${4} = ${4} + "BODY{background-color:#F2F2F2;}"
    ${4} = ${4} + "TABLE{border-width: 1px;border-style: solid;border-color: black;}"
    ${4} = ${4} + "TH{border-width: 1px;padding: 0px;border-style: solid;border-color: black;background-color:#BDBDBD}"
    ${4} = ${4} + "TD{border-width: 1px;padding: 5px;border-style: solid;border-color: black;background-color:#D8D8D8}"
    ${4} = ${4} + "</style>"
    ${1} | select Date, Type, Status, User, IPAddress | ConvertTo-Html -head ${4} -body "<h2>Logon Activity:</h2>" | Out-File ${3}
    iex ${3}
}
elseif (${2} -match "G"){ 
    ${1} | ogv -Title "Logon Activity"
}
else{
    ${1}
}