﻿function Import-SPDesignPackage {
    #written by Ingo Karstein (http://blog.karstein-consulting.com)
    # v1.0

    #You can copy this function to your own script file or use the file as PowerShell module

    #See ... for details

    [CmdLetBinding(DefaultParameterSetName="Default")]
    param(
        [parameter(Mandatory=$true, Position=0, ParameterSetName="Default", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [string]
        $SiteUrl="",

        [parameter(Mandatory=$true, Position=0, ParameterSetName="Site", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [Microsoft.SharePoint.SPSite]
        $Site=$null,

        [parameter(Mandatory=$true, Position=1, ParameterSetName="Default", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [parameter(Mandatory=$true, Position=1, ParameterSetName="Site", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [string]
        $ImportFileName = "",

        [parameter(Mandatory=$true, Position=2, ParameterSetName="Default", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [parameter(Mandatory=$true, Position=2, ParameterSetName="Site", ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [bool]
        $Apply = $false,

        [parameter(Mandatory=$false, Position=3, ParameterSetName="Default", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [parameter(Mandatory=$false, Position=3, ParameterSetName="Site", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [string]
        $PackageName = "",


        [parameter(Mandatory=$false, ParameterSetName="Default", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [parameter(Mandatory=$false, ParameterSetName="Site", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [int]
        $MajorVersion = 1,

        [parameter(Mandatory=$false, ParameterSetName="Default", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [parameter(Mandatory=$false, ParameterSetName="Site", ValueFromPipeline=$false, ValueFromPipelineByPropertyName=$true)]
        [int]
        $MinorVersion = 0
    )

    begin {
        [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Publishing") | Out-Null
        [System.Reflection.Assembly]::LoadWithPartialName("System.Net") | Out-Null
    }

    process {
        ${10110111011011101} = $null
        ${01110000000000100} = ""

        if( $PSCmdlet.ParameterSetName -like "Default" ) {
            ${10110111011011101} = Get-SPSite $SiteUrl -ErrorAction 0
            ${01110000000000100} = $SiteUrl
        } else {
            ${10110111011011101} = $site
            ${01110000000000100} = $site.Url
        }
        
        ${00110000110111011} = new-object System.Management.Automation.PSObject
        ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "SiteUrl" -Value ${01110000000000100} -Force
        ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "Success" -Value $false -Force

        try {
            if( !(Test-Path $ImportFileName) ) {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InputFileFound" -Value $false -Force
                return
            } else {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InputFileFound" -Value $true -Force
            }

            if( [System.IO.Path]::GetExtension($ImportFileName) -ne ".wsp" ) {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InputFileExtensionValid" -Value $false -Force
                return
            } else {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InputFileExtensionValid" -Value $true -Force
            }

            if(${10110111011011101} -ne $null ) {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "SiteFound" -Value $true -Force

                ${00010101111001110} = [System.IO.Path]::GetFileName($ImportFileName)

                if( [string]::IsNullOrEmpty($PackageName) ) {
                    $PackageName = [System.IO.Path]::GetFileNameWithoutExtension($ImportFileName)
                }

                ${00010011100001100} = "{0}-v{1}.{2}.wsp" -f ($PackageName, $MajorVersion, $MinorVersion)

                ${10110100011111111} = $null
                ${10110100011111111} = ${10110111011011101}.RootWeb.GetFile("_catalogs/solutions/" + ${00010011100001100})

                if( ${10110100011111111} -ne $null -and ${10110100011111111}.Exists ) {
                    ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "PackageAlreadyExists" -Value $true -Force
                    return
                } else {
                    ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "PackageAlreadyExists" -Value $false -Force
                }
                
                ${00110000110001011} = new-object Microsoft.SharePoint.Publishing.DesignPackageInfo(${00010101111001110}, [Guid]::Empty, $MajorVersion, $MinorVersion)

                ${01100001000001100} = $null
                ${00111001000110101} = $null

                ${01010011010001100} = $false

                try {
                    ${01100001000001100} = ${10110111011011101}.RootWeb.RootFolder.SubFolders.Add("tmp_importspdesignpackage_15494B80-89A0-44FF-BA6C-208CB6A053D0")
                    
                    ${00111001000110101} = [System.IO.File]::OpenRead($ImportFileName)
                    
                    ${00010000001000000} = ${01100001000001100}.Files.Add(${00010101111001110}, ${00111001000110101}, $true)
                    
                    ${00111001000110101}.Close()
                    ${00111001000110101} = $null

                    [Microsoft.SharePoint.Publishing.DesignPackage]::Install(${10110111011011101}, ${00110000110001011}, ${00010000001000000}.Url)
                    ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InstallError" -Value [System.Exception]$null -Force
                    ${01010011010001100} = $true
                } catch {
                    ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "InstallError" -Value $_.Exception -Force
                } finally {
                    if( ${01100001000001100} -ne $null ) { ${01100001000001100}.Delete() }
                    if( ${00111001000110101} -ne $null ) { ${00111001000110101}.Close() }
                }
                
                if( ${01010011010001100} ) {
                    if( $Apply ) {
                        try {
                            [Microsoft.SharePoint.Publishing.DesignPackage]::Apply(${10110111011011101}, ${00110000110001011})
                            ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "ApplyError" -Value [System.Exception]$null -Force
                            ${00110000110111011}.Success = $true
                        } catch {
                            ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "ApplyError" -Value $_.Exception -Force
                        }
                    } else {
                        ${00110000110111011}.Success = $true
                    }
                }
            } else {
                ${00110000110111011} | Add-Member -MemberType NoteProperty -Name "SiteFound" -Value $false -Force
            }

        } finally {
            if( $PSCmdlet.ParameterSetName -like "Default*" ) {
                if( ${10110111011011101} -ne $null ) {
                    ${10110111011011101}.Dispose()
                }
            } else {
                if( $disposeSiteObject -eq $true -and $site -ne $null -and $site -is [Microsoft.SharePoint.SPSite] ) {
                    $site.Dispose()
                }
            }
            ${00110000110111011}
        }
    }

    end {}
}

function New-ObjectFromHashtable {
    #written by Ingo Karstein (http://blog.karstein-consulting.com)
    # v1.0

    #Use this function to convert a hashtable to a PowerShell object ("PSObject"), e.g. for using hashtables for property name binding in
    # PowerShell pipelines

    [CmdletBinding()]
    param(
        [parameter(Mandatory=$true, Position=1, ValueFromPipeline=$true)]
        [Hashtable]
        $Hashtable
    )

    begin {
        ${00011101111111100} = @()
    }

    process {
        ${01110001111111111} = new-object System.Management.Automation.PSObject
        $Hashtable.Keys | % {
            ${10111110111111100} = $_
            ${10111000111010111} = $Hashtable[${10111110111111100}]
            ${01110001111111111} | Add-Member -MemberType NoteProperty -Name ${10111110111111100} -Value ${10111000111010111} -Force
        }

        ${00011101111111100} += ${01110001111111111}
    }

    end {
        ${00011101111111100}
    }

}

${01110001111111111} = Import-SPDesignPackage -SiteUrl "http://sharepoint.local/publishingxyz" -ImportFileName "C:\temp\publishing2.wsp" -PackageName "P2" -Apply $true

(
    @{ SiteUrl = "http://sharepoint.local/publishing";
       ImportFileName = "C:\temp\publishing2.wsp";
       PackageName = "P2";
       Apply=$true
    },
    @{ SiteUrl = "http://sharepoint.local/sites/publishing2";
       ImportFileName = "C:\temp\publishing2.wsp";
       PackageName = "P2";
       Apply=$true
    }
) | New-ObjectFromHashtable | Import-SPDesignPackage