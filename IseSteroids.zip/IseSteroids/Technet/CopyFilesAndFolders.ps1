﻿${28} = $host | select version
if(${28}.version.major -gt 1) {$Host.Runspace.ThreadOptions = "ReuseThread"}
if(!(Get-PSSnapin Microsoft.SharePoint.PowerShell -ea 0))
{
Write-Progress -Activity "Loading Modules" -Status "Loading Microsoft.SharePoint.PowerShell"
Add-PSSnapin Microsoft.SharePoint.PowerShell
}
${27} = "http://sharepoint.rcormier.local"
${25} = "Shared Documents"
${15} = "http://sharepoint.rcormier.local/sites/sts_0"
${23} = "Shared Documents"
${26} = Get-SPWeb ${27}
${12} = ${26}.Lists | ? {$_.Title -eq ${25}}
${24} = Get-SPWeb ${15}
${13} = ${24}.Lists | ? {$_.title -like ${23}}
${19} = ${12}.Folders
${22} = ${12}.RootFolder
${21} = ${22}.files
foreach(${20} in ${21})
{
    ${5} = ${20}.OpenBinary()
    ${1} = ${13}.RootFolder.Files.Add(${20}.Name, ${5}, $true)
    ${4} = ${20}.Item.Fields | ? {!($_.sealed)}
    foreach(${2} in ${4})
    {
        if(${20}.Properties[${2}.Title])
        {
            if(!(${1}.Properties[${2}.title]))
            {
                ${1}.AddProperty(${2}.Title, ${20}.Properties[${2}.Title])
            }
            else
            {
                ${1}.Properties[${2}.Title] = ${20}.Properties[${2}.Title]
            }
        }
    }
    ${1}.Update()
}
foreach(${11} in ${19})
{
    rv ParentFolderURL
    ${17} = 0
    ${18} = ${11}.url.Split("/")
    while(${17} -lt (${18}.count-1))
    {
    ${14} = $ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEANAB9AC8A'))) + ${18}[${17}]
    ${17}++
    }
    ${16} = ${13}.Folders | ? {$_.url -eq ${14}.substring(1)}
    if(!(${16}.Folders | ? {$_.name -eq ${11}.Name}))
    {
        ${6} = ${13}.Folders.Add(($ExecutionContext.InvokeCommand.ExpandString([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('JAB7ADEANQB9AA=='))) + ${14}), [Microsoft.SharePoint.SPFileSystemObjectType]::Folder, ${11}.name)
        ${6}.update()
    }
    else
    {
        ${6} = ${13}.Folders | ? {$_.name -eq ${11}.Name}
    }
    ${8} = ${12}.Items
    ${10} = ${11}.folder.Files
    if(${11}.Folder.Files.count -gt 0)
    {
        foreach(${9} in ${10})
        {
            ${7} = (${9}.ServerRelativeUrl).substring(1)
            ${3} = ${8} | ? {$_.URL -eq ${7}}
            ${5} = ${3}.File.OpenBinary()
            ${1} = ${6}.Folder.Files.Add(${3}.Name, ${5}, $true)
            ${4} = ${3}.Fields | ? {!($_.sealed)}
            foreach(${2} in ${4})
            {
                if(${3}.Properties[${2}.Title])
                {
                    if(!(${1}.Properties[${2}.title]))
                    {
                        ${1}.AddProperty(${2}.Title, ${3}.Properties[${2}.Title])
                    }
                    else
                    {
                        ${1}.Properties[${2}.Title] = ${3}.Properties[${2}.Title]
                    }
                }
            }
            ${1}.Update()
                    }
    }
}