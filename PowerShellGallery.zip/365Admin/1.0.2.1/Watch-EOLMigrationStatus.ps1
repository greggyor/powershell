﻿function Watch-EOLMigrationStatus
{
  <#
    .SYNOPSIS
    Connects  to Exchange Online and grabs the status of any pending migrations.
    .DESCRIPTION
    Connects  to Exchange Online and grabs the status of any pending migrations.
    .EXAMPLE
    Watch-EOLMigrationStatus -SleepingMinutes 5
    Connects to EOL, reports back pending transfers, then sleeps 5 minutes.
  #>
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$false, Position=0)]
    [System.Int32]
    $SleepingMinutes = 5
  )
  
  if ((Get-ExchangeOnlineConnectionState) -eq 'Connected') {} ELSE {Connect-ExchangeOnline}
  while (1) {
    $MSGs = Get-MessageTrace -Status Pending;
    if ($MSGs.count -gt 10) {
      Write-Host 10 messages pending. Consider a reboot
      Write-Host ''
      
      $MSGs
      $n = 0
      while ($n -lt 10) {
        Start-Sleep -Seconds 3
        $n++
      }
    }
    Write-Host "Acceptable count of Pending Messages. PENDING: $(($MSGs).count). Sleeping for 5 minutes. $(Get-Date -displayhint datetime)"
    Start-Sleep -Seconds ($SleepingMinutes*60)
  }
}