﻿Function Get-ExchangeOnlineConnectionState {
  $ConnectionState = (Get-PSSession | ? {$_.ConfigurationName -eq 'Microsoft.Exchange' -and $_.State -eq 'Opened' -and $_.ComputerName -eq 'ps.outlook.com'}).count
  if ($ConnectionState -eq 0) {
    return 'Disconnected'
  }
  if ($ConnectionState -eq 1) {
    return 'Connected'
  }
}