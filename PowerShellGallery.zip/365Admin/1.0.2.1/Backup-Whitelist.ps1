﻿Function Backup-Whitelist 
{
  param(
    [System.Diagnostics.Switch]
      $Debugging,
    [Switch]
      $SendEmail,
    [Parameter(Mandatory = $False)]
    [String]
      $BackupPath = 'C:\scripts\powershell\EOL_WhitelistBackups\',
    [Parameter(Mandatory = $true)]
      [String]
        $EmailRecipient,
    [Parameter(Mandatory = $true)]
      [String]
        $EmailSenders,
    [Parameter(Mandatory = $true)]
      [String]
        $SMTPServer
  )

  #region Varialbes
        
  New-Item $BackupPath -ItemType Directory -ErrorAction SilentlyContinue -Force
  [String]$Runtime = Get-Date -Format yyyy.MM.dd_HH.mm.sstt
  $BackupZip = $BackupPath + $Runtime + '.zip'
  $StartingLocation = Get-Location

        
  #endregion


  #region Connect to Exchange Online
      [System.Management.Automation.PsCredential]$Credential = $Host.UI.PromptForCredential('Enter Global Admin Credential',
      'Enter the username and password of an Exchange Online Global Administrator account.',
      '',
    'userCreds')
        [System.Uri]$Uri = 'https://outlook.office365.com/powershell-liveid/' #'https://ps.outlook.com/powershell/'
  $session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $Uri -Credential $Credential -Authentication Basic -AllowRedirection -Verbose
  Import-PSSession -Session $session -AllowClobber -Verbose
  #endregion Connect to Exchange Online


    
  $AllPolicies = Get-HostedContentFilterPolicy

  foreach ($SpamPolicy in $AllPolicies) 
  {
    $OutFile = $BackupPath + $Runtime + '_' + $SpamPolicy.Name + '_AllowedSenderDomains.csv'
    $SpamPolicy.AllowedSenderDomains | Export-Csv -Path $OutFile -NoTypeInformation

    $OutFile = $BackupPath + $Runtime + '_' + $SpamPolicy.Name + '_AllowedSenders.csv'
    $SpamPolicy.AllowedSenders | Export-Csv -Path $OutFile -NoTypeInformation

    $OutFile = $BackupPath + $Runtime + '_' + $SpamPolicy.Name + '_BlockedSenderDomains.csv'
    $SpamPolicy.BlockedSenderDomains | Export-Csv -Path $OutFile -NoTypeInformation

    $OutFile = $BackupPath + $Runtime + '_' + $SpamPolicy.Name + '_BlockedSenders.csv'
    $SpamPolicy.BlockedSenders | Export-Csv -Path $OutFile -NoTypeInformation
  }

  Set-Location $BackupPath

  $BackupFiles = Get-ChildItem -Path $BackupPath*csv
  $BackupFiles | Write-Zip -Level 9 -OutputPath $BackupZip
  $BackupFiles | Remove-Item -Force -ErrorAction SilentlyContinue

  Set-Location $StartingLocation


  if ($SendEmail) 
  {
    Send-MailMessage -SmtpServer $SMTPServer -To $EmailRecipient -From $EmailSenders -Subject "Exchange Spam Filter Backups - $($Runtime)" -Attachments $BackupZip
  }
}