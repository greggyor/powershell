﻿function Add-FullAccessPermission


{
  <#
      .SYNOPSIS
      Adds FullAccess to target user
      .EXAMPLE
      Add-FullAccessPermission -enduser steve -targetmailbox bob
      Adds SendAs permission on bob's mailbox for end user steve WITHOUT AutoMapping.
      .EXAMPLE
      Add-FullAccessPermission -enduser steve -targetmailbox bob -AutoMapping
      Adds SendAs permission on bob's mailbox for end user steve WITH AutoMapping
  #>
  param
  (
    [String]
    [Parameter(Mandatory)]
    $enduser,

    [Parameter(Mandatory)]
    [String]
    $targetmailbox,

    [Switch]
    $AutoMapping
  )

  Confirm-ExchangeOnlineConnection -ConnectIfDisconnected
    
  try 
  {
    if ($AutoMapping) {
      Write-Output 'AutoMapping Flag Set. Automapping = $true'
      Add-MailboxPermission `
        -Identity $targetmailbox `
        -User $enduser `
        -AutoMapping $true `
        -AccessRights FullAccess `
        -Verbose
      }

    if (!$AutoMapping) {
      Write-Output 'AutoMapping Flag NOT Set. Automapping = $false'
      Add-MailboxPermission `
        -Identity $targetmailbox `
        -User $enduser `
        -AutoMapping $false `
        -AccessRights FullAccess `
        -Verbose
      }  
  }
  catch 
  {
    Write-Output -InputObject 'Error in adding FullAccess permissions.'
    Return $_.Exception
  }

}