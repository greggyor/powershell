﻿Function Start-ExternalEmailTester {
  param(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PsCredential]
    $Cred = $Host.UI.PromptForCredential('Enter Outlook.com Credential',
      'Enter the username and password of your outlook.com account.',
      '',
    'userCreds'),
    [String]
    [Parameter(Mandatory=$true)]
    $DestinationEmailAddress,
    [int32]
    $SecondDelay = 180
  )
  $counter = 0
  $subjectBase = 'Test Email '
    
  $SMTPServer = 'smtp-mail.outlook.com'
  #$Cred = Get-Credential
    
  while (1) {
    $subject = "[TESTING]External Email Tester - POSH on $($env:COMPUTERNAME)";
    $subjectBase + $counter + "- $(Get-Date -DisplayHint Time)"
    $body = "$($subjectBase) $($counter) - $(Get-Date -DisplayHint Time)
      Test sent at $(Get-Date -DisplayHint DateTime)
        
    Next Email Expected at $((Get-Date).AddSeconds(180))"
    
        
    Send-MailMessage -SmtpServer $SMTPServer -Subject $subject -Body $body -Credential $Cred `
    -To $DestinationEmailAddress `
    -From $cred.UserName `
    -UseSsl
        
    $counter++
    
    Start-Sleep -Seconds $SecondDelay
  }

}