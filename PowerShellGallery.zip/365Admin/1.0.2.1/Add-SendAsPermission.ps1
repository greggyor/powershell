﻿function Add-SendAsPermission
{
  <#
      .SYNOPSIS
      Adds SendAs Extended Right to target user
      .EXAMPLE
      Add-SendAsPermission -enduser steve -targetmailbox bob
      Adds SendAs permission on bob's mailbox for end user steve.
  #>
  param
  (
    [String]
    [Parameter(Mandatory)]
    $enduser,

    [Parameter(Mandatory)]
    [String]
    $targetmailbox
  )

  Confirm-ExchangeOnlineConnection -ConnectIfDisconnected
    
  try 
  {
    #Add-RecipientPermission -Identity "$($targetmailbox.samaccountname)" -Trustee  "$($enduser.samaccountname)" -AccessRights SendAs -Verbose
    Add-RecipientPermission -Identity $targetmailbox -Trustee $enduser -AccessRights SendAs -Verbose
  }
  catch 
  {
    Write-Output -InputObject 'Error in adding Recipient permissions.'
    Return $_.Exception
  }
}