﻿Function Connect-ExchangeComplianceOnline
{
  [CmdletBinding()]
  param 
  (
    [Parameter(Mandatory = $False)]
    [System.Management.Automation.PsCredential]$Credential = $Host.UI.PromptForCredential('Enter Global Admin Credential',
      'Enter the username and password of an Exchange Online Global Administrator account.',
      '',
    'userCreds'),

    [Parameter(Mandatory = $False)]
    [System.Uri]$Uri = 'https://ps.compliance.protection.outlook.com/powershell-liveid/'
  )

  $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $Uri -Credential $Credential -Authentication Basic -AllowRedirection
  Import-PSSession -Session $session -AllowClobber
  Return $session
}