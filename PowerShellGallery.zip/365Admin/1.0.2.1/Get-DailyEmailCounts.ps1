﻿function Get-DailyEmailCounts
{
  <#
    .SYNOPSIS
    Gathers a simple report of number/basic info of emails received by a certain Exchange Online address.
    .DESCRIPTION
    Connects to Exchange Online and gathers daily email counts for the last day ("Number of emails sent TO this email box from Midnight Yesterday to Midnight this morning") and sends an email report
    .EXAMPLE
    Get-DailyEmailCounts -AddressToQuery example@company.com -username admin@company.com -password 'Pa$$w0rd!' -SMTPServer webmail.company.com -email_from me@company.com -email_to you@company.com
    Sends a report for number of messages received, who from, and subject, for example@company.com and emails you@company.com a report
    .EXAMPLE
    Get-DailyEmailCounts -AddressToQuery example@company.com,example2@company.com,example3@company.com -username admin@company.com -password Pa$$w0rd! -SMTPServer webmail.company.com -email_from me@company.com -email_to you@company.com -DaysToQuery 3
    Sends a report for number of messages received, who from, and subject, for the last 3 days, for example@company.com, example2@company.com, and example3@company.com and emails you@company.com a report
    .EXAMPLE
    Get-DailyEmailCounts -AddressToQuery example@company.com -username admin@company.com -password 'Pa$$w0rd!' -SMTPServer webmail.company.com -email_from me@company.com -email_to you@company.com -Uri https://customURI.microsoft.com
    Sends a report for number of messages received, who from, and subject, for example@company.com and emails you@company.com a report. Utilizes the custom URI switch.

  #>
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$True, Position=0)]
    [String[]]
    $AddressToQuery,
    
    [Parameter(Mandatory=$True, Position=1, HelpMessage='Enter in an Administrator account that is able to query Exchange Online.')]
    [System.String]
    $username,
    
    [Parameter(Mandatory=$True, Position=2, HelpMessage='Enter the password for the Exchange Online Administrator Account')]
    [Object]
    $password,
    
    [Parameter(Mandatory=$false, Position=3, HelpMessage='Optionally specify the URI used to connect to Exchange Online. Default: https://outlook.office365.com/powershell-liveid/')]
    [System.Uri]
    $Uri = 'https://outlook.office365.com/powershell-liveid/',
    
    [Parameter(Mandatory=$True, Position=4, HelpMessage='Specify the SMTP Server address to use to send the email report')]
    [System.String]
    $SMTPServer,
    
    [Parameter(Mandatory=$True, Position=5, HelpMessage='Specify the sender address to use to send the email report')]
    [System.String]
    $email_from,
    
    [Parameter(Mandatory=$True, Position=6, HelpMessage='Specify the recipient address(es) to use to send the email report')]
    [System.String]
    $email_to,
    
    [Parameter(Mandatory=$false, Position=7, HelpMessage='Specify the Email subject address to use to send the email report')]
    [System.String]
    $email_subject = 'Daily Email Counts',

    [Parameter(Mandatory=$false, Position=8, HelpMessage='Number of historical Days to Query')]
    $DaysToQuery = 1
  )
  

  $spwd = ConvertTo-SecureString -AsPlainText $password -Force  
  $Credential = New-Object System.Management.Automation.PSCredential $username,$spwd 
  
  $session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $Uri -Credential $Credential -Authentication Basic -AllowRedirection #-Verbose
  Import-PSSession -Session $session -AllowClobber #-Verbose
  
  $body = "
    <strong>Script Runtime: $(Get-Date -DisplayHint DateTime)</strong><br/>
    <strong>Emails from: </strong>$(((Get-Date -Hour 0 -Minute 0 -Second 0).AddDays(-$DaysToQuery)))<br>
    <strong>Emails to:   </strong>$(((Get-Date -Hour 0 -Minute 0 -Second 0)))<br/><p/>
    <table style=`"width: 100%;`" border=`"1`">
    <tbody>
    <tr>
    <td style=`"width: 20%;`"><strong>Email</strong></td>
    <td style=`"width: 80%;`"><strong>Information</strong></td>
  </tr>"
  $body_emailrow = "        <tr>
    <td>{0}</td>
    <td>Daily Count = <strong><font color=`"blue`">{1}</font></strong><br>
    <br>
    {2}</td>
  </tr>"
  $body_Footer = '
    </tbody>
  </table>'
  
  foreach ($email in $AddressToQuery) {
    
    $email_results = Get-MessageTrace -RecipientAddress $email -StartDate ((Get-Date -Hour 0 -Minute 0 -Second 0).AddDays(-$DaysToQuery)) -EndDate ((Get-Date -Hour 0 -Minute 0 -Second 0)) 
    [String]$html_fragment = ($email_results | sort SenderAddress | Select SenderAddress,Subject | ConvertTo-Html -Fragment -As Table)
    $body += $body_emailrow -f $email, $($email_results.count), $($html_fragment); #$body
    
  }
  
  $body += $body_Footer
  
  Send-MailMessage -SmtpServer $SMTPServer -From $email_from -To $email_to -Subject $email_subject -Body $body -BodyAsHtml

  
  
  
  
  Remove-PSSession $session
}