﻿Function Connect-ExchangeOnline
{
  [CmdletBinding()]
  param 
  (
    [Parameter(Mandatory = $False)]
    [System.Management.Automation.PsCredential]$Credential = $Host.UI.PromptForCredential('Enter Global Admin Credential',
      'Enter the username and password of an Exchange Online Global Administrator account.',
      '',
    'userCreds'),

    [Parameter(Mandatory = $False)]
    [System.Uri]$Uri = 'https://outlook.office365.com/powershell-liveid/' #'https://ps.outlook.com/powershell/'
  )
  $progressActivity = 'Connecting to Exchange Online'
  $prog_pctcomplete = 0
  $prog_numofupdates = 3
  $pctIncrement = (100 / $prog_numofupdates)
  Write-Progress -Activity $progressActivity -Status 'Creating Session Link to Exchange Online' -PercentComplete ($prog_pctcomplete += $pctIncrement)
  $session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $Uri -Credential $Credential -Authentication Basic -AllowRedirection -Verbose
  Write-Progress -Activity $progressActivity -Status 'Sleeping' -PercentComplete ($prog_pctcomplete += $pctIncrement)
  Start-Sleep -Seconds 1
  Write-Progress -Activity $progressActivity -Status 'Importing the PowerShell Session' -PercentComplete ($prog_pctcomplete += $pctIncrement)
  Import-PSSession -Session $session -AllowClobber -Verbose
  Return $session
}