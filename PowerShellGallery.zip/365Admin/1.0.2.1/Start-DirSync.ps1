﻿function Start-DirSync
{
  <#
      .SYNOPSIS
      Kicks off AD Connect Sync Cycle
      .DESCRIPTION
      Kicks off AD Connect Sync Cycle of specified type on specified server.
      .EXAMPLE
      Start-DirSync -SyncType Initial
      Starts Initial (Full) DirSync on AD Sync Server scrp-nettools01 (Default Value)
      .EXAMPLE
      Start-DirSync -SyncType Delta -ADSyncServer scrp-dirsync01 -Debug
      Starts Delta DirSync on AD Sync Server scrp-dirsync01 with debugging options (Writes output of current steps.)
  #>
  [CmdletBinding()]
  param
  (
    # Define type of sync to start
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('Delta','Initial')]
    [string]
    $SyncType,
    # Define AD Connect Server
    [Parameter(Mandatory = $true, Position = 1)]
    [System.String]
    $ADSyncServer,
    # Wait switch
    [Parameter(Mandatory = $false, Position = 2)]
    [switch]
    $Wait = $false,
    [Parameter(Mandatory = $false, Position = 3)]
    [switch]
    $Debug = $false
  )

  $colors = 'Black', 'DarkBlue', 'DarkGreen', 'DarkCyan', 'DarkRed', 'DarkMagenta', 'DarkYellow', 'Gray', 'DarkGray', 'Blue', 'Green', 'Cyan', 'Red', 'Magenta', 'Yellow', 'White'
  
  if ($SyncType -eq 'Delta') 
  {
    $sb = {
      Start-ADSyncSyncCycle -PolicyType Initial
    }
  }
  if ($SyncType -eq 'Initial') 
  {
    $sb = {
      Start-ADSyncSyncCycle -PolicyType Delta
    }
  }
  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "Connecting to AD Sync Server $($ADSyncServer)" -PercentComplete 10
  if ($Debug) 
  {
    Write-Host -ForegroundColor Yellow -BackgroundColor Black -Object '-----------------------------------------------------'
    Write-Host -ForegroundColor Yellow -BackgroundColor Black -Object "-----Initiating Delta AADsync on  $($ADSyncServer)-----"  
    Write-Host -ForegroundColor Yellow -BackgroundColor Black -Object '-----------------------------------------------------'
  }
  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "Creating PSSession to $($ADSyncServer)" -PercentComplete 15
  $DirSyncServerSession = New-PSSession -ComputerName $ADSyncServer

  if ($Debug) 
  {
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'Session opened'
  }
  Start-Sleep -Seconds 5
  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "Entering PSSession to AD Sync Server $($ADSyncServer)" -PercentComplete 20
  Enter-PSSession $DirSyncServerSession

  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "Starting AD Sync Cyle on $($ADSyncServer)" -PercentComplete 50
  if ($Debug) 
  {
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'Entered Session'
  }
  Start-Sleep -Seconds 5
  if ($Debug) 
  {
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'Initiating AADsync'
  }

  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "AD Sync Cyle  finished starting on $($ADSyncServer)" -PercentComplete 80
  
  #icm -ScriptBlock {cmd /C "C:\Program Files\Microsoft Azure AD Sync\Bin\DirectorySyncClientCmd.exe" initial} -Session $nettools01session
  Invoke-Command -ScriptBlock $sb -Session $DirSyncServerSession
  
  if ($Debug) 
  {
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'AADsync Completed'
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'Exiting PSSession'
  }

  Exit-PSSession
  Start-Sleep -Seconds 5
  Remove-PSSession -Session $DirSyncServerSession -Verbose

  Write-Progress -Activity 'Invoking a DirSync Cycle' -Status "Exited & Closed PSSession on $($ADSyncServer)" -PercentComplete 100

  if ($Debug) 
  {
    Write-Host -ForegroundColor Magenta -BackgroundColor Black -Object 'Session Removed'
    Write-Host Run the following command to check status of the latest 20 messages associated with Azure AD Connect. -ForegroundColor Magenta -BackgroundColor Black
  }
  Write-Output -Object "Get-EventLog -ComputerName $($ADSyncServer) -LogName Application -Source `"Directory Synchronization`" -Newest 20 | select TimeGenerated,EntryType,Message"

  if ($Wait) {
    Write-Host "Wait flag set. Beginning query of $ADSyncServer Logs..." -ForegroundColor Green -BackgroundColor Black
    Start-Sleep -Seconds 5
    Write-Host "Still Working." -NoNewline -ForegroundColor Gray -BackgroundColor Black
    while ((Get-EventLog -ComputerName $ADSyncServer -LogName Application -Source "Directory Synchronization" -Newest 20 | select TimeGenerated, EntryType, Message | ? {$_.Message -contains "Finished" -and $_.TimeGenerated -gt (Get-Date).AddMinutes(-1)}).count -eq 0) {
      Write-Host '.' -NoNewline -ForegroundColor (Get-Random $colors) -BackgroundColor Black
      Start-Sleep -Seconds 3
    }
    
    #Print out finished message
    (Get-EventLog -ComputerName $ADSyncServer -LogName Application -Source "Directory Synchronization" -Newest 20 | select TimeGenerated, EntryType, Message | ? {$_.Message -contains "Finished" -and $_.TimeGenerated -gt (Get-Date).AddMinutes(-1)})

  }

}