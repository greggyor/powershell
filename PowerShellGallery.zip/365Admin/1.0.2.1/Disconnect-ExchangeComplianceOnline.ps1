﻿Function Disconnect-ExchangeComplianceOnline
{
  Get-PSSession | ?{$_.ComputerName -like '*ps.compliance.protection.outlook.com'} | Remove-PSSession
}