﻿Function Disconnect-ExchangeOnline
{
  Get-PSSession | ?{$_.ComputerName -like '*outlook.office365.com'} | Remove-PSSession
}