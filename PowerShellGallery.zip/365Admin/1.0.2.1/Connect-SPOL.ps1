﻿function Connect-SPOL
{
  <#
    .SYNOPSIS
    Connects to SharePoint Online
    .DESCRIPTION
    Connects to SharePoint Online
    REF: https://technet.microsoft.com/library/fp161372%28v=office.15%29.aspx?f=255&MSPPError=-2147217396
    REF: https://www.microsoft.com/en-us/download/confirmation.aspx?id=35588

    .EXAMPLE
    Connect-SPOL -adminUPN myaccount@myorg.co -orgName myco1
  #>
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$true, Position=0)]
    [System.String]
    $adminUPN = "",
    
    [Parameter(Mandatory=$true, Position=1)]
    [System.String]
    $orgName = ""
  )
    
  $userCredential = Get-Credential -UserName $adminUPN -Message "Type the password."
  Connect-SPOService -Url https://$orgName-admin.sharepoint.com -Credential $userCredential
}