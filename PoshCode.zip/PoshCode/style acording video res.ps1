@@---------------------------------------------------------------------------------------------------------------------------
@@ this code is copied from http://www.ti4fun.com/myouikar/JavaScript/rotina.aspx?r=JJiKNeLQlIA[[ti&l=STN[ti]5tehuTA[[ti
@@---------------------------------------------------------------------------------------------------------------------------
<script> 
	document.write('<div id="div_panel" style="width:100%; height:'+ (screen.height > 768 ? '380px' : (screen.height > 600 ? '280px' : '275px')) +'; overflow:auto;">');

</script>
@@--------------------------------------------------
@@ See more codes in http://www.ti4fun.com/myouikar
@@--------------------------------------------------
