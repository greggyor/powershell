hi	

i want a script in powershell that talks to the sharepoint and takes two arguments one is Ip address or server name other is config.xml file.

It checks if server exists and if yes it asks for user name and password and display error to the user accordingly . also it checks for duplicate entries in config.xml file.

any suggesions will be highly appreciated.
