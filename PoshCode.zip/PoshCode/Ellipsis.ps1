## Usage: ls | ... FullName
################################################
${function:...} = { process { $_.$($args[0]) } }
