A man is not old as long as he is seeking something. A man is not old until regrets take the place of dreams.
 
-----------------------------------
