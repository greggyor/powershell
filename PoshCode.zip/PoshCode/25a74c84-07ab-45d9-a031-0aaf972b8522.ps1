select * from sys.dm_db_index_physical_stats(db_id('vCenter'),null,null,null,null)
order by avg_fragmentation_in_percent desc

