Sow nothing, reap nothing.
 
-----------------------------------
